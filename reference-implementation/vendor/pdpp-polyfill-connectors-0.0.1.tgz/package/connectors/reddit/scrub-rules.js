// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
// Module-scoped regex (biome useTopLevelRegex).
const USER_MENTION_RE = /\b(?:\/?u\/|\/user\/)([A-Za-z0-9][A-Za-z0-9_-]{1,19})\b/g;
export const scrubRules = [
    // /u/name, u/name, /user/name → /u/[REDACTED_USER]. Matches Reddit's
    // 3-20 character username rule (starts alphanumeric, then
    // alphanumeric/underscore/hyphen).
    {
        pattern: USER_MENTION_RE,
        replacement: "/u/[REDACTED_USER]",
        scope: "all",
    },
];
