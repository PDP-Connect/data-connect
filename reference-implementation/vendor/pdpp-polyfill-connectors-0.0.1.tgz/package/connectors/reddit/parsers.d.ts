import type { CommentRecord, RedditChild, RedditChildData, RedditListing, SavedRecord, SubmittedRecord, VoteRecord } from "./types.ts";
/** Reddit's old web JSON caps per-page at 100 for listings. */
export declare const PAGE_LIMIT = 100;
/** Safety cap on pagination loops. 100 pages * 100 items = 10k records,
 *  plenty for any single stream in one run; incremental sync keeps
 *  subsequent runs cheap. */
export declare const MAX_PAGES = 100;
/** Bound on emitted text-field length. Reddit permits up to 40k chars in
 *  selftext and 10k in comments; truncating at 10k keeps records
 *  query-friendly without losing the overwhelming majority of content. */
export declare const TEXT_MAX_CHARS = 10000;
/** Narrow HTTP status to a connector-level error class. `null` means
 *  "status ok, treat response as data". Throwing is the caller's
 *  responsibility. */
export declare function classifyListingStatus(status: number): "auth_failed" | "rate_limited" | "http_error" | null;
export declare const isoFromUnix: (u: number | string | undefined | null) => string | null;
export declare const absolutePermalink: (permalink: string | null | undefined) => string | null;
/** Extract hostname from a URL, for link-post domain enrichment.
 *  Returns null for non-URL inputs and for self-posts (which Reddit
 *  gives a `self.<sub>` pseudo-domain that isn't useful downstream). */
export declare function domainOf(rawUrl: string | null | undefined): string | null;
/** Truncate free-form text before emit; preserves null semantics. */
export declare function truncateText(text: string | null | undefined): string | null;
/** UTF-16 code-unit length — matches what `slice()` above produces and
 *  what downstream JSON consumers see. For English-heavy Reddit text
 *  this is effectively character count; for emoji-heavy text it slightly
 *  over-counts, which is fine for a record-size signal. */
export declare function textLen(text: string | null | undefined): number | null;
/** A comment is top-level when its parent is the post itself — i.e.
 *  `parent_id` starts with `t3_`. Top-level vs reply is a useful
 *  semantic signal for analysis (participation depth, reply patterns). */
export declare function isTopLevelComment(parentId: string | null | undefined): boolean | null;
export declare function submittedRecord(d: RedditChildData, fetchedAt: string): SubmittedRecord;
export declare function commentRecord(d: RedditChildData, fetchedAt: string): CommentRecord;
export declare function savedRecord(c: RedditChild, fetchedAt: string): SavedRecord;
/** Shared builder for vote-like streams (upvoted, downvoted, hidden).
 *  Reddit returns posts (t3) and comments (t1) interleaved, and
 *  we preserve the kind + is_post discriminator so downstream queries
 *  can filter by content type. */
export declare function voteRecord(c: RedditChild, fetchedAt: string): VoteRecord;
/**
 * How a listing endpoint orders its children. This is a per-stream property
 * of Reddit, not a global one, and getting it wrong silently truncates
 * history — see `appendNewChildren`.
 *
 *   "created"  — ordered by the item's own `created_utc`, newest first.
 *                True for `submitted` and `comments`: the listing is the
 *                user's authorship timeline, so creation order IS listing
 *                order and an early stop at the cursor is sound.
 *
 *   "action"   — ordered by when the OWNER acted on the item (upvoted,
 *                saved, downvoted, hid), newest action first. True for
 *                `upvoted`/`saved`/`downvoted`/`hidden`. The item's
 *                `created_utc` is unrelated to its position: upvoting a
 *                2015 post today puts a 2015 `created_utc` at rank 1.
 */
export type RedditListingOrder = "action" | "created";
/**
 * Append children newer than the cursor into `out`, returning true to signal
 * "stop paging".
 *
 * The stop rule depends on {@link RedditListingOrder}:
 *
 * For `created`-ordered listings the first child at or below the cursor
 * proves every later child is older too (the listing is sorted by the very
 * field being compared), so stopping there is correct and keeps incremental
 * runs cheap.
 *
 * For `action`-ordered listings that inference is invalid, and acting on it
 * loses data. `created_utc` is NOT the sort key, so a single old item near
 * the top says nothing about what follows it. The pre-fix code stopped on the
 * first such item, which for `upvoted` meant halting on item one as soon as
 * the owner upvoted anything older than the stored high-water mark — the
 * observed defect. These streams therefore always walk the full listing and
 * rely on the caller deduping by fullname (`t3_`/`t1_` ids are stable), which
 * is cheap because the walk is bounded by Reddit's own end-of-listing.
 */
export declare function appendNewChildren(children: readonly RedditChild[], sinceEpochUtc: number | null, out: RedditChild[], order?: RedditListingOrder): boolean;
/**
 * Drop children already present by Reddit fullname (`t3_…`/`t1_…`), keeping
 * first-seen order. Fullnames are stable per item, so this is a safe identity
 * for the full-walk `action`-ordered streams, where the same item can appear
 * across runs and must not be double-counted. Children without a usable
 * fullname are kept rather than collapsed — dropping them would silently lose
 * data on a shape Reddit has not been observed to emit, and downstream
 * validation is the right place to judge them.
 */
export declare function dedupeByFullname(children: readonly RedditChild[]): RedditChild[];
/** Build the `?after=…&limit=100` path segment given an endpoint and
 *  the current pagination cursor. */
export declare function pagePath(endpoint: string, after: string | null, limit?: number): string;
/** Extract the `after` cursor from a listing response, normalizing
 *  empty string → null. */
export declare function nextAfter(listing: RedditListing | null | undefined): string | null;
/** Max created_utc epoch across a batch of children, clamped at `current`.
 *  Used to advance the per-stream STATE cursor. */
export declare function maxCreatedEpoch(children: readonly RedditChild[], current: number): number;
/** Resolve the since-cursor for a stream from the persisted state blob. */
export declare function sinceFromState(state: Record<string, unknown>, streamName: string): number | null;
//# sourceMappingURL=parsers.d.ts.map