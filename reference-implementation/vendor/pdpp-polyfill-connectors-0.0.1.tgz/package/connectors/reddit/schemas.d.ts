import { z } from "zod";
export declare const submittedSchema: z.ZodObject<{
    id: z.ZodString;
    subreddit: z.ZodNullable<z.ZodString>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    permalink: z.ZodNullable<z.ZodString>;
    url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    domain: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    selftext: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    selftext_len: z.ZodNullable<z.ZodNumber>;
    is_self: z.ZodNullable<z.ZodBoolean>;
    over_18: z.ZodNullable<z.ZodBoolean>;
    score: z.ZodNullable<z.ZodNumber>;
    num_comments: z.ZodNullable<z.ZodNumber>;
    upvote_ratio: z.ZodNullable<z.ZodNumber>;
    gilded: z.ZodNullable<z.ZodNumber>;
    created_utc: z.ZodString;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const commentSchema: z.ZodObject<{
    id: z.ZodString;
    subreddit: z.ZodNullable<z.ZodString>;
    body: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body_len: z.ZodNullable<z.ZodNumber>;
    link_id: z.ZodNullable<z.ZodString>;
    parent_id: z.ZodNullable<z.ZodString>;
    is_top_level: z.ZodNullable<z.ZodBoolean>;
    permalink: z.ZodNullable<z.ZodString>;
    score: z.ZodNullable<z.ZodNumber>;
    gilded: z.ZodNullable<z.ZodNumber>;
    created_utc: z.ZodString;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const savedSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        t1: "t1";
        t3: "t3";
    }>;
    is_post: z.ZodBoolean;
    subreddit: z.ZodNullable<z.ZodString>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body_len: z.ZodNullable<z.ZodNumber>;
    permalink: z.ZodNullable<z.ZodString>;
    url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    created_utc: z.ZodString;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const voteSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        t1: "t1";
        t3: "t3";
    }>;
    is_post: z.ZodBoolean;
    subreddit: z.ZodNullable<z.ZodString>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body_len: z.ZodNullable<z.ZodNumber>;
    url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    permalink: z.ZodNullable<z.ZodString>;
    score: z.ZodNullable<z.ZodNumber>;
    num_comments: z.ZodNullable<z.ZodNumber>;
    created_utc: z.ZodString;
    fetched_at: z.ZodString;
}, z.core.$strip>;
/** Map stream name → schema. Single source of truth for what streams this
 *  connector produces at shape-check time. upvoted/downvoted/hidden all
 *  share `voteSchema` (same server-side shape, different semantic label). */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map