/**
 * Scrub rules specific to Reddit fixtures. Applied AFTER the shared
 * defaults in src/scrub-defaults.ts. Order within this file matters —
 * earlier rules win when a span matches multiple patterns.
 *
 * What's risky in a Reddit fixture:
 *   - Usernames (u/<name>, /u/<name>, /user/<name>) — appear in
 *     permalinks, link_ids (sometimes), and free-form text.
 *   - Real-person names inside free-form post/comment bodies.
 *     The deterministic scrubber can't safely catch these;
 *     rely on LLM redaction plans for that layer (see §9.1 of
 *     connector-authoring-guide).
 *   - Subreddit names identify the owner's interests. Not PII on
 *     their own, but the mosaic is identifying — leave them alone
 *     unless a specific sub is a bad idea to commit.
 *   - External URLs: potentially linked personal sites. We preserve
 *     domain for analysis utility; if a specific URL is sensitive,
 *     add a one-off rule below.
 *
 * Authored fullnames (t3_* and t1_* prefixes) stay as-is — they're
 * stable public IDs, not sensitive.
 */
import type { ScrubRule } from "../../src/scrubber.ts";
export declare const scrubRules: readonly ScrubRule[];
//# sourceMappingURL=scrub-rules.d.ts.map