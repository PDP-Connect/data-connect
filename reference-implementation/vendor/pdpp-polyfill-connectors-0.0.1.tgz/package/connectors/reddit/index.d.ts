#!/usr/bin/env node
import type { Page } from "playwright";
import { type BrowserCollectContext, type EmittedMessage, type EnsureSessionArgs, type NormalizeTerminalError, type RecordData } from "../../src/connector-runtime.ts";
import type { CaptureSession } from "../../src/fixture-capture.ts";
import { createRepairBudget } from "../../src/repair-budget.ts";
import { type RedditListingOrder } from "./parsers.ts";
import type { RedditChild, RedditFetchResult } from "./types.ts";
/**
 * Exported (not just inline in `runConnector`) so a regression test can
 * assert every post-submit throw `src/auto-login/reddit.ts` can produce
 * fails to match this exact pattern — the same object the scheduler
 * classifier actually consults, not a duplicated literal that could drift.
 * Post-submit safety no longer depends on this pattern's vocabulary:
 * `redditEnsureSession` wires `onCredentialSubmit`, so any fault after the
 * password click is forced non-retryable by the runtime regardless of what
 * this matches. The non-collision tests over this pattern remain as
 * defense-in-depth for the literals Reddit throws, and the pattern still
 * fully owns PRE-submit and collect-phase retry classification.
 */
export declare const REDDIT_RETRYABLE_PATTERN: RegExp;
/**
 * Keep Reddit's browser-session failures actionable without exposing the
 * account name embedded in a listing endpoint. Auth and login challenges are
 * durable owner actions; rate limits remain retryable and must not be turned
 * into a false reconnect request.
 */
export declare const normalizeRedditTerminalError: NormalizeTerminalError;
interface ProgressExtra {
    cursor_present?: boolean;
    item_count?: number;
    page_index?: number;
    phase?: string;
    rate_limit_pressure?: number;
    stream?: string;
    total_seen?: number;
}
/**
 * Paginate a Reddit listing. Newest-first, opaque `after` cursor. Stops
 * once we cross the prior run's high-water created_utc (incremental), hit
 * an empty page, or run out of `after`. The fetch function is injected
 * so integration tests can run this against a fake listing server
 * without a browser.
 */
export type RedditListingFetch = (path: string) => Promise<RedditFetchResult>;
export interface RedditPaginationResult {
    children: RedditChild[];
    /** True only when MAX_PAGES stopped a walk that still had an `after` cursor. */
    truncated: boolean;
}
/**
 * Re-run the connector's existing session-establishment flow
 * (`ensureRedditSession`) and report whether the session is live afterward.
 * `ensureRedditSession` already no-ops when the current cookie is live, so
 * calling it speculatively mid-run is safe — it only does login work when
 * the cookie is actually gone or stale.
 */
export type RedditReauthFn = () => Promise<boolean>;
export declare function paginate(fetchPath: RedditListingFetch, endpoint: string, sinceEpochUtc: number | null, capture: CaptureSession | null, delay?: (ms: number) => Promise<void>, progress?: (message: string, extra?: ProgressExtra) => Promise<void>, streamName?: string, onAuthFailed?: RedditReauthFn, repairBudget?: ReturnType<typeof createRepairBudget>, order?: RedditListingOrder): Promise<RedditPaginationResult>;
/** Declarative description of one stream collectStream() knows how to
 *  fetch. Exported so integration tests can reuse the same table the
 *  runtime uses. */
export interface RedditStreamConfig {
    endpoint: string;
    name: string;
    /** How Reddit sorts this listing. Drives the pagination stop rule — see
     *  {@link RedditListingOrder}. Omitted means `created` (authorship
     *  timeline), the only ordering for which an early stop is sound. */
    order?: RedditListingOrder;
    progressMessage: string;
    toRecord: (c: RedditChild) => RecordData;
}
export interface CollectStreamArgs {
    capture: CaptureSession | null;
    /** Pacing delay between pages. Defaults to politeDelay(500ms). Tests
     *  inject a no-op so they don't sleep. */
    delay?: (ms: number) => Promise<void>;
    emit: (msg: EmittedMessage) => Promise<void>;
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    fetchPath: RedditListingFetch;
    /** Re-establish the session once on a mid-stream 401/403. Absent in tests
     *  that don't exercise the repair path — a 401/403 then fails immediately,
     *  matching pre-fix behavior. */
    onAuthFailed?: RedditReauthFn;
    progress: (message: string, extra?: ProgressExtra) => Promise<void>;
    /** RUN-scoped budget for `onAuthFailed` spends, shared by the caller across
     *  every stream in this run. Defaults to a fresh one-shot budget so direct
     *  callers (tests) that don't pass one keep today's per-call ceiling of 1. */
    repairBudget?: ReturnType<typeof createRepairBudget>;
    state: Record<string, unknown>;
    stream: RedditStreamConfig;
}
interface CollectStreamResult {
    considered: number;
    covered: number;
}
export declare function collectStream(args: CollectStreamArgs): Promise<CollectStreamResult>;
/** Build the list of streams this connector can populate, bound to a
 *  particular user path and emit timestamp. Exported for tests. */
export declare function buildStreamTable(userPath: string, emittedAt: string): RedditStreamConfig[];
/** Build a RedditListingFetch bound to a Playwright page. Extracted
 *  so tests can substitute a non-browser fetch.
 *
 *  Exported so `redditFetch`'s origin guard is directly testable: reaching it
 *  only through `collectAllStreams` means every listing/parsing fixture has to
 *  model navigation, which would bury the one behavior under test. */
export declare function makePageFetch(page: Page): RedditListingFetch;
/**
 * Build the mid-run reauth hook bound to a live browser context. Delegates
 * to `ensureRedditSession` — the same session-establishment flow already run
 * once at connector start — which no-ops when the cookie is still live, so
 * this is safe to invoke speculatively on a 401/403 rather than only at
 * startup.
 *
 * Gated strictly on `REDDIT_USERNAME`/`REDDIT_PASSWORD` being present in
 * `process.env`, mirroring the Amazon connector's
 * `attemptAutomatedSessionRepair`. Without both, `ensureRedditSession` falls
 * through to `ensureRedditManualSession` — an interactive owner hand-off
 * that can block up to 30 minutes and consume an OTP interaction slot. That
 * path is only safe at run start (`ensureSession`, before any owner-facing
 * timeout budget is in flight); triggering it speculatively mid-collect on a
 * background 401/403 is not. Note this checks `process.env` directly, not
 * `ctx.credentials` — a run whose credentials arrived via the interactive
 * `sendInteraction` prompt (rather than sealed-secret env injection) has a
 * populated `credentials` object but empty `process.env`, and must still be
 * refused here.
 *
 * `ensureRedditSession` never returns without either the session already
 * being probed live or throwing, so a bare "didn't throw" is already backed
 * by a probe internally — but that's an implementation detail of a function
 * this hook doesn't own. Re-probing explicitly with `isSessionLive` here is
 * cheap (one navigation, already-loaded page) and makes the truth this hook
 * reports self-contained rather than borrowed: if `ensureRedditSession`'s
 * internal contract ever changes, this still reports the real session state
 * instead of silently trusting a function that returned without error.
 *
 * Exported (in addition to being wired into `collectAllStreams`) so the
 * env-credential gate is directly unit-testable without needing a
 * Playwright-shaped `context`/`page` that would otherwise mask the gate
 * behind an unrelated thrown error from a stub object.
 */
export declare function makeReauth(ctx: BrowserCollectContext): RedditReauthFn;
export declare function collectAllStreams(ctx: BrowserCollectContext): Promise<void>;
/**
 * The production `ensureSession` hook. Exported (rather than inlined in the
 * `runConnector` config below) so the `onCredentialSubmit` forwarding is
 * itself under test: `src/auto-login/reddit.test.ts` drives the runtime's
 * real `establishSession` through this exact function and proves a
 * post-submit fault comes out non-retryable even when its message matches
 * `REDDIT_RETRYABLE_PATTERN`. An inline closure here would leave the
 * forwarding unreachable by any test (the `isMainModule` guard).
 */
export declare function redditEnsureSession({ assist, capture, checkpoint, completeAssistance, context, onCredentialSubmit, page, sendInteraction, }: EnsureSessionArgs): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map