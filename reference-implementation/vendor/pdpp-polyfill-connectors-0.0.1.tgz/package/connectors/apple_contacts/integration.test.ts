// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import { dirname, join } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";
import type {
	EmittedMessage,
	RecordData,
} from "../../src/connector-runtime.ts";
import { runConnectorProtocolSubprocess } from "../../src/test-harness.ts";
import { buildVCard, startFakeCardDavServer } from "./test-carddav-server.ts";

const __dirname = dirname(fileURLToPath(import.meta.url));
const CWD = join(__dirname, "..", "..");
const ENTRYPOINT = join(__dirname, "index.ts");
const USERNAME = "owner@example.com";
const PASSWORD = "app-specific-pw";

function startMessage(state: Record<string, unknown> = {}): {
	scope: { streams: Array<{ name: string }> };
	state: Record<string, unknown>;
	type: "START";
} {
	return {
		type: "START",
		scope: {
			streams: [
				{ name: "address_books" },
				{ name: "contacts" },
				{ name: "contact_groups" },
			],
		},
		state,
	};
}

function recordsOf(messages: EmittedMessage[], stream: string): RecordData[] {
	return messages
		.filter(
			(m): m is Extract<EmittedMessage, { type: "RECORD" }> =>
				m.type === "RECORD" && m.stream === stream,
		)
		.map((m) => m.data);
}

test("apple_contacts integration: discovers, syncs via sync-collection, and emits typed contacts + groups", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		server.contacts.set("alice", {
			uid: "alice",
			href: "/addressbooks/owner/card/alice.vcf",
			vcard: buildVCard({
				uid: "alice",
				fn: "Alice Example",
				email: "alice@example.com",
				categories: ["Friends"],
			}),
		});
		server.contacts.set("bob", {
			uid: "bob",
			href: "/addressbooks/owner/card/bob.vcf",
			vcard: buildVCard({
				uid: "bob",
				fn: "Bob Example",
				categories: ["Friends", "Work"],
			}),
		});

		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "succeeded");

		const addressBooks = recordsOf(result.messages, "address_books");
		assert.equal(addressBooks.length, 1);
		assert.equal(addressBooks[0]?.supports_sync_collection, true);

		const contacts = recordsOf(result.messages, "contacts");
		assert.equal(contacts.length, 2);
		const alice = contacts.find((c) => c.display_name === "Alice Example");
		assert.ok(alice);
		assert.deepEqual(alice?.emails, [
			{ types: ["HOME"], value: "alice@example.com" },
		]);

		const groups = recordsOf(result.messages, "contact_groups");
		const groupNames = groups
			.map((g) => g.name)
			.sort((a, b) => String(a).localeCompare(String(b)));
		assert.deepEqual(groupNames, ["Friends", "Work"]);
		const friends = groups.find((g) => g.name === "Friends");
		assert.ok(friends);
		assert.equal((friends.member_uids as string[]).length, 2);

		// contact_groups is a required, full_inventory stream — it must prove
		// its own coverage (not just emit records), otherwise it can never reach
		// `complete` regardless of how much real data it collected.
		const groupsCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contact_groups",
		);
		assert.ok(
			groupsCoverage && groupsCoverage.type === "DETAIL_COVERAGE",
			"contact_groups must emit DETAIL_COVERAGE",
		);
		assert.equal(groupsCoverage.considered, 2);
		assert.equal(groupsCoverage.covered, 2);

		// contacts must prove its own coverage the same way — otherwise a real
		// two-contact run and a run that silently enumerated nothing both read
		// as `unknown` coverage, indistinguishable from each other.
		const contactsCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(
			contactsCoverage && contactsCoverage.type === "DETAIL_COVERAGE",
			"contacts must emit DETAIL_COVERAGE",
		);
		assert.equal(contactsCoverage.considered, 2);
		assert.equal(contactsCoverage.covered, 2);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: a genuinely empty address book completes with proven-empty contacts coverage", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
		enforceRfc6578IncrementalSemantics: true,
	});
	try {
		// No contacts registered on the fake server at all — the address book
		// exists and enumerates cleanly, it is just genuinely empty.
		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(
			done.status,
			"succeeded",
			"a zero-contact account is a successful run, not a failure",
		);

		const contacts = recordsOf(result.messages, "contacts");
		assert.equal(contacts.length, 0);

		// The zero must be PROVEN (considered === covered === 0), not merely
		// absent — an empty stream with no DETAIL_COVERAGE reads as `unknown`
		// coverage downstream, indistinguishable from "never actually asked the
		// server." considered === covered === 0 is the only way a genuinely
		// empty address book can report `complete` rather than `partial`.
		const contactsCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(
			contactsCoverage && contactsCoverage.type === "DETAIL_COVERAGE",
			"contacts must emit DETAIL_COVERAGE",
		);
		assert.equal(contactsCoverage.considered, 0);
		assert.equal(contactsCoverage.covered, 0);

		// contact_groups derives entirely from contacts' CATEGORIES field, so a
		// zero-contact address book is also a zero-group address book — still
		// proven-empty, not merely absent.
		const groupsCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contact_groups",
		);
		assert.ok(
			groupsCoverage && groupsCoverage.type === "DETAIL_COVERAGE",
			"contact_groups must emit DETAIL_COVERAGE",
		);
		assert.equal(groupsCoverage.considered, 0);
		assert.equal(groupsCoverage.covered, 0);
		const groupsState = result.messages.find(
			(m) => m.type === "STATE" && m.stream === "contact_groups",
		);
		assert.ok(
			groupsState,
			"a successful empty group enumeration must stage its stream checkpoint",
		);

		const contactsState = result.messages.findLast(
			(m): m is Extract<EmittedMessage, { type: "STATE" }> =>
				m.type === "STATE" && m.stream === "contacts",
		);
		assert.ok(contactsState);
		const [bookState] = Object.values(
			contactsState.cursor as Record<
				string,
				{ initial_sync_completed?: boolean; sync_token?: string }
			>,
		);
		assert.equal(
			bookState?.initial_sync_completed,
			true,
			"the empty inventory still establishes a boundary",
		);
		assert.ok(bookState?.sync_token);

		// A true zero must not make every later ordinary sync walk the whole
		// collection. The marker makes this run resume the quiet token instead.
		const quiet = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage({ contacts: contactsState.cursor }),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});
		assert.equal(
			quiet.messages.find(
				(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
			),
			undefined,
			"the initialized empty book must use its quiet token instead of full-rescanning",
		);

		const addressBooksCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "address_books",
		);
		assert.ok(
			addressBooksCoverage && addressBooksCoverage.type === "DETAIL_COVERAGE",
		);
		assert.equal(
			addressBooksCoverage.considered,
			1,
			"the address book itself was discovered and enumerated",
		);
		assert.equal(addressBooksCoverage.covered, 1);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: falls back to bounded full snapshot when sync-collection is unsupported", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
		disableSyncCollection: true,
	});
	try {
		server.contacts.set("carol", {
			uid: "carol",
			href: "/addressbooks/owner/card/carol.vcf",
			vcard: buildVCard({ uid: "carol", fn: "Carol Example" }),
		});

		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "succeeded");

		const addressBooks = recordsOf(result.messages, "address_books");
		assert.equal(addressBooks[0]?.supports_sync_collection, false);

		const contacts = recordsOf(result.messages, "contacts");
		assert.equal(contacts.length, 1);
		assert.equal(contacts[0]?.display_name, "Carol Example");
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: a second run emits a tombstone for a server-side deletion (sync-collection path)", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		server.contacts.set("dave", {
			uid: "dave",
			href: "/addressbooks/owner/card/dave.vcf",
			vcard: buildVCard({ uid: "dave", fn: "Dave Example" }),
		});

		const first = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});
		const firstState = first.messages.findLast(
			(m): m is Extract<EmittedMessage, { type: "STATE" }> =>
				m.type === "STATE" && m.stream === "contacts",
		);
		assert.ok(firstState);

		server.contacts.delete("dave");
		server.deletedHrefs.add("/addressbooks/owner/card/dave.vcf");
		server.markChanged();

		const second = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage({
				contacts: (firstState as Extract<EmittedMessage, { type: "STATE" }>)
					.cursor,
			}),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const tombstone = second.messages.find(
			(m): m is Extract<EmittedMessage, { type: "RECORD" }> =>
				m.type === "RECORD" && m.stream === "contacts" && m.op === "delete",
		);
		assert.ok(tombstone, "expected a delete-op RECORD for the removed contact");
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: an initial sync of a genuinely empty address book proves verified-empty coverage", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		// No contacts at all, and no prior cursor: this run establishes the full
		// boundary, so `considered: 0` is a real measurement ("I enumerated the
		// address book and it held nothing") rather than a quiet change feed.
		// Withholding the claim here would turn a legitimately-empty required
		// stream into a permanent `unknown`, which is its own failure.
		const only = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = only.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "succeeded");
		assert.equal(recordsOf(only.messages, "contacts").length, 0);

		const contactsCoverage = only.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(
			contactsCoverage && contactsCoverage.type === "DETAIL_COVERAGE",
			"a boundary-establishing run must still emit contacts coverage for a genuine zero",
		);
		assert.equal(contactsCoverage.considered, 0);
		assert.equal(contactsCoverage.covered, 0);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: an unchanged incremental sync re-enumerates the group inventory", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		server.contacts.set("erin", {
			uid: "erin",
			href: "/addressbooks/owner/card/erin.vcf",
			vcard: buildVCard({
				uid: "erin",
				fn: "Erin Example",
				categories: ["Friends"],
			}),
		});

		const first = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});
		const firstState = first.messages.findLast(
			(m): m is Extract<EmittedMessage, { type: "STATE" }> =>
				m.type === "STATE" && m.stream === "contacts",
		);
		assert.ok(firstState);
		assert.ok(
			first.messages.some(
				(m) => m.type === "STATE" && m.stream === "contact_groups",
			),
		);

		const second = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage({ contacts: firstState.cursor }),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		assert.equal(recordsOf(second.messages, "contact_groups").length, 1);
		assert.equal(
			second.messages.some(
				(m) => m.type === "STATE" && m.stream === "contact_groups",
			),
			true,
		);
		const groupsCoverage = second.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contact_groups",
		);
		assert.ok(groupsCoverage && groupsCoverage.type === "DETAIL_COVERAGE");
		assert.equal(groupsCoverage.considered, 1);
		assert.equal(groupsCoverage.covered, 1);

		// The quiet incremental run enumerated nothing, so it must not claim a
		// contacts boundary. This is the shape observed in production on
		// cin_d344ba53d6d95c7dd343393d: a stored sync_token with an empty
		// fingerprint map, replaying as `considered: 0` forever.
		const contactsCoverage = second.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.equal(
			contactsCoverage,
			undefined,
			"an unchanged incremental sync must not claim a proven contacts boundary",
		);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: recovers a legacy sync token without an initialization boundary", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
		enforceRfc6578IncrementalSemantics: true,
		syncCollectionOmitsAddressData: true,
	});
	try {
		server.contacts.set("alice", {
			uid: "alice",
			href: "/addressbooks/owner/card/alice.vcf",
			vcard: buildVCard({ uid: "alice", fn: "Alice Example" }),
		});
		server.contacts.set("bob", {
			uid: "bob",
			href: "/addressbooks/owner/card/bob.vcf",
			vcard: buildVCard({ uid: "bob", fn: "Bob Example" }),
		});
		server.contacts.set("carol", {
			uid: "carol",
			href: "/addressbooks/owner/card/carol.vcf",
			vcard: buildVCard({ uid: "carol", fn: "Carol Example" }),
		});

		// This is the deployed legacy shape: a book-level token was persisted,
		// but no full-inventory boundary or contact fingerprints were recorded.
		// RFC 6578 returns an empty change feed for this quiet token even though
		// the address book is populated.
		const legacyState = {
			contacts: {
				[`${server.origin}/addressbooks/owner/card`]: {
					fingerprints: {},
					sync_token: "legacy-token",
				},
			},
		};
		const recovered = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(legacyState),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		assert.equal(recordsOf(recovered.messages, "contacts").length, 3);
		const recoveredCoverage = recovered.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(
			recoveredCoverage && recoveredCoverage.type === "DETAIL_COVERAGE",
		);
		assert.equal(recoveredCoverage.considered, 3);
		assert.equal(recoveredCoverage.covered, 3);

		const recoveredState = recovered.messages.findLast(
			(m): m is Extract<EmittedMessage, { type: "STATE" }> =>
				m.type === "STATE" && m.stream === "contacts",
		);
		assert.ok(recoveredState);
		const [recoveredBookState] = Object.values(
			recoveredState.cursor as Record<
				string,
				{ initial_sync_completed?: boolean; sync_token?: string }
			>,
		);
		assert.equal(recoveredBookState?.initial_sync_completed, true);
		assert.ok(recoveredBookState?.sync_token);

		// The recovery boundary is sticky. A genuinely empty account takes the
		// same first path, then this ordinary follow-up must resume its token
		// rather than full-rescanning forever.
		const quiet = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage({ contacts: recoveredState.cursor }),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});
		assert.equal(recordsOf(quiet.messages, "contacts").length, 0);
		assert.equal(
			quiet.messages.find(
				(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
			),
			undefined,
			"the initialized follow-up must use its token's quiet change feed, not re-establish a full boundary",
		);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: a full_refresh run re-enumerates and proves contacts coverage despite a stored sync token", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		server.contacts.set("erin", {
			uid: "erin",
			href: "/addressbooks/owner/card/erin.vcf",
			vcard: buildVCard({
				uid: "erin",
				fn: "Erin Example",
				categories: ["Friends"],
			}),
		});
		server.contacts.set("frank", {
			uid: "frank",
			href: "/addressbooks/owner/card/frank.vcf",
			vcard: buildVCard({ uid: "frank", fn: "Frank Example" }),
		});

		const first = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});
		const firstState = first.messages.findLast(
			(m): m is Extract<EmittedMessage, { type: "STATE" }> =>
				m.type === "STATE" && m.stream === "contacts",
		);
		assert.ok(firstState);

		// Same stored-token starting point as the quiet-incremental test above —
		// which asserts this run emits NO contacts coverage. The only difference
		// here is the owner-requested `collection_mode: "full_refresh"`, so this
		// pins the bypass itself rather than any change in the source data.
		const refreshed = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: {
				...startMessage({ contacts: firstState.cursor }),
				collection_mode: "full_refresh",
			},
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const contactsCoverage = refreshed.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(
			contactsCoverage && contactsCoverage.type === "DETAIL_COVERAGE",
			"a full_refresh run must re-establish the contacts boundary and claim coverage",
		);
		// The claim must be the real inventory (both contacts), not a `considered: 0`
		// artifact of a change feed — that distinction is the whole point.
		assert.equal(contactsCoverage.considered, 2);
		assert.equal(contactsCoverage.covered, 2);

		// The refreshed run must still write a usable token forward, so the next
		// ordinary run can resume incrementally rather than re-walking forever.
		const refreshedState = refreshed.messages.findLast(
			(m): m is Extract<EmittedMessage, { type: "STATE" }> =>
				m.type === "STATE" && m.stream === "contacts",
		);
		assert.ok(refreshedState);
		const [bookState] = Object.values(
			refreshedState.cursor as Record<string, { sync_token?: string }>,
		);
		assert.ok(
			bookState?.sync_token,
			"a full_refresh run must still persist a sync token for the next run",
		);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: incremental group requests re-enumerate a genuine empty inventory", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		const href = "/addressbooks/owner/card/erin.vcf";
		server.contacts.set("erin", {
			uid: "erin",
			href,
			vcard: buildVCard({
				uid: "erin",
				fn: "Erin Example",
				categories: ["Friends"],
			}),
		});

		const first = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});
		const firstState = first.messages.findLast(
			(m): m is Extract<EmittedMessage, { type: "STATE" }> =>
				m.type === "STATE" && m.stream === "contacts",
		);
		assert.ok(firstState);
		assert.equal(recordsOf(first.messages, "contact_groups").length, 1);

		server.contacts.clear();
		server.deletedHrefs.add(href);
		server.markChanged();

		const second = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage({ contacts: firstState.cursor }),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = second.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "succeeded");
		const contactRecords = second.messages.filter(
			(m): m is Extract<EmittedMessage, { type: "RECORD" }> =>
				m.type === "RECORD" && m.stream === "contacts",
		);
		assert.equal(
			contactRecords.filter((message) => message.op !== "delete").length,
			0,
		);
		assert.equal(recordsOf(second.messages, "contact_groups").length, 0);

		// The incremental contact delta is not a CONTACT boundary either. This run
		// saw one deletion and zero live resources, which is a change feed, not an
		// enumeration of the address book. Emitting `considered: 0, covered: 0`
		// here would hand the coherence contract a fabricated
		// `enumeration_boundary` proof and paint a required stream green off a
		// quiet sync. The honest move is to emit no contacts coverage at all and
		// let the stream read `unknown` until a run actually establishes the
		// boundary.
		const contactsCoverage = second.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.equal(
			contactsCoverage,
			undefined,
			"an incremental contact delta must not claim a proven-empty contacts inventory",
		);

		// The incremental contact delta is not a group boundary. The connector
		// must obtain a full snapshot before proving that the now-empty group
		// inventory is complete.
		const groupsState = second.messages.find(
			(m) => m.type === "STATE" && m.stream === "contact_groups",
		);
		assert.ok(
			groupsState,
			"a successful full group re-enumeration must stage contact_groups state",
		);
		const groupsCoverage = second.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contact_groups",
		);
		assert.ok(groupsCoverage && groupsCoverage.type === "DETAIL_COVERAGE");
		assert.equal(groupsCoverage.considered, 0);
		assert.equal(groupsCoverage.covered, 0);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: fails cleanly on rejected credentials", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: "wrong-password",
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
			allowFailedDone: true,
		});
		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "failed");
		// The stable machine code rides error.code (the typed, non-redacted
		// channel); error.message is human-readable free-form text that still
		// goes through the same redaction as any other connector diagnostic.
		assert.equal(done.error?.code, "auth_failed");
		assert.equal(
			done.error?.message,
			"Apple ID or app-specific password was rejected",
		);
		assert.equal(
			result.messages.some(
				(m) => m.type === "STATE" && m.stream === "contact_groups",
			),
			false,
			"a failed scan must not stage contact_groups coverage",
		);
		// No vCard or credential content leaked into the terminal error/progress trace.
		const serialized = JSON.stringify(result.messages);
		assert.equal(serialized.includes("wrong-password"), false);
		assert.equal(serialized.includes(PASSWORD), false);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: an unsafe-redirect refusal on sync-collection is a non-retryable terminal failure", async () => {
	// End-to-end proof through the real subprocess (not just the unit-level
	// carddav-client.test.ts coverage): a structural davRequest failure
	// surfacing through resolveSyncResult's .catch site must land on DONE
	// as retryable: false. Before the fix this call site blanket-set
	// retryable: true for every caught error, which would have silently
	// told the scheduler to keep retrying a security control that is firing
	// correctly and cannot succeed on retry (review finding P1).
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
		syncReportRedirectsToUnsafeOrigin: true,
	});
	try {
		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
			allowFailedDone: true,
		});
		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "failed");
		assert.equal(done.error?.code, "carddav_request_failed");
		assert.equal(
			done.error?.retryable,
			false,
			"an unsafe-redirect refusal cannot self-resolve on retry",
		);
		assert.ok(done.error?.message?.startsWith("carddav_unsafe_redirect"));
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: an unsafe-redirect refusal on the bounded-snapshot fallback query is a non-retryable terminal failure", async () => {
	// Same structural class, surfacing through addressbookQueryAll's .catch
	// site instead of resolveSyncResult's — proves call-site consistency,
	// not just one spot check (review finding P1).
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
		disableSyncCollection: true,
		syncReportRedirectsToUnsafeOrigin: true,
	});
	try {
		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
			allowFailedDone: true,
		});
		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "failed");
		assert.equal(done.error?.code, "carddav_request_failed");
		assert.equal(
			done.error?.retryable,
			false,
			"an unsafe-redirect refusal cannot self-resolve on retry",
		);
		assert.ok(done.error?.message?.startsWith("carddav_unsafe_redirect"));
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: an unparseable vCard resource is counted in coverage but withholds a complete claim", async () => {
	// A resource the server DID enumerate (it appears in the multistatus
	// response) but whose <address-data> is not a well-formed vCard must
	// still count toward `considered` — the coverage denominator — even
	// though it can never be `covered` (parsed, emitted-or-suppressed).
	// Before the fix, contactsConsidered was aliased to the parsed-count
	// variable, so this resource silently vanished from both considered and
	// covered and the run reported a fabricated `complete` (review finding
	// P2).
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		server.contacts.set("good", {
			uid: "good",
			href: "/addressbooks/owner/card/good.vcf",
			vcard: buildVCard({ uid: "good", fn: "Good Contact" }),
		});
		// Not a well-formed vCard (no BEGIN:VCARD/END:VCARD block) — parseVCards
		// will return zero cards for this resource's address-data.
		server.contacts.set("malformed", {
			uid: "malformed",
			href: "/addressbooks/owner/card/malformed.vcf",
			vcard: "NOT-A-VALID-VCARD-BODY",
		});

		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(
			done.status,
			"succeeded",
			"a parse failure on one resource does not fail the whole run",
		);

		const contacts = recordsOf(result.messages, "contacts");
		assert.equal(
			contacts.length,
			1,
			"only the well-formed vCard is emitted as a contact record",
		);

		const contactsCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(contactsCoverage && contactsCoverage.type === "DETAIL_COVERAGE");
		// Both resources the server enumerated count toward considered; only
		// the one that actually parsed counts toward covered. considered >
		// covered is the honest signal — a fabricated considered === covered
		// would read as proven-complete despite the silently dropped input.
		assert.equal(contactsCoverage.considered, 2);
		assert.equal(contactsCoverage.covered, 1);

		// The parse failure must be surfaced, not silently swallowed.
		const progressMessages = result.messages.filter(
			(m) => m.type === "PROGRESS",
		);
		const sawParseFailureNotice = progressMessages.some(
			(m) =>
				m.type === "PROGRESS" &&
				m.message.toLowerCase().includes("unparseable"),
		);
		assert.equal(
			sawParseFailureNotice,
			true,
			"an honest shape/parse-failure signal must be emitted",
		);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: never logs credentials or vCard field values in PROGRESS messages", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		server.contacts.set("erin", {
			uid: "erin",
			href: "/addressbooks/owner/card/erin.vcf",
			vcard: buildVCard({
				uid: "erin",
				fn: "Erin Secretname",
				email: "erin-secret@example.com",
			}),
		});
		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});
		const progressMessages = result.messages.filter(
			(m) => m.type === "PROGRESS",
		);
		const serialized = JSON.stringify(progressMessages);
		assert.equal(serialized.includes(PASSWORD), false);
		assert.equal(serialized.includes("Erin Secretname"), false);
		assert.equal(serialized.includes("erin-secret@example.com"), false);
	} finally {
		await server.close();
	}
});

/**
 * Live-shape regression (probe against p196-contacts.icloud.com, 2026-08-19).
 *
 * iCloud answers a `sync-collection` REPORT by enumerating each member with
 * `getetag` ONLY — it does not inline the `address-data` the request asked
 * for — and it also lists the collection's own href beside its members. That
 * is RFC-legal (RFC 6578 §3.2 requires enumeration, not inlining), so the
 * client must fetch bodies via `addressbook-multiget` (RFC 6352 §8.7).
 *
 * Before this was handled, the connector dropped every member that arrived
 * without an inlined body, and a populated address book reported a *measured*
 * zero — the most dangerous possible failure, because a proven zero is
 * indistinguishable downstream from a genuinely empty account.
 */
test("apple_contacts integration: collects contacts when sync-collection enumerates members without inlining address-data", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
		syncCollectionOmitsAddressData: true,
	});
	try {
		server.contacts.set("frank", {
			uid: "frank",
			href: "/addressbooks/owner/card/frank.vcf",
			vcard: buildVCard({
				uid: "frank",
				fn: "Frank Example",
				email: "frank@example.com",
				categories: ["Family"],
			}),
		});

		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "succeeded");

		const contacts = recordsOf(result.messages, "contacts");
		assert.equal(
			contacts.length,
			1,
			"the enumerated member's body must be fetched, not dropped",
		);
		assert.equal(contacts[0]?.display_name, "Frank Example");

		// The collection's own href is enumerated alongside its members; it must
		// not be mistaken for a contact resource.
		assert.equal(
			contacts.some((c) => String(c.id).endsWith("/addressbooks/owner/card")),
			false,
			"the collection itself must not be emitted as a contact",
		);

		const contactsCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(contactsCoverage && contactsCoverage.type === "DETAIL_COVERAGE");
		assert.equal(contactsCoverage.considered, 1);
		assert.equal(contactsCoverage.covered, 1);

		// Groups derive from CATEGORIES, which only exist once bodies are hydrated.
		const groups = recordsOf(result.messages, "contact_groups");
		assert.deepEqual(
			groups.map((g) => g.name),
			["Family"],
		);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: an enumerated member whose body never arrives is an honest partial, not a proven zero", async () => {
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
		syncCollectionOmitsAddressData: true,
		multigetReturnsNoBodies: true,
	});
	try {
		server.contacts.set("ghost", {
			uid: "ghost",
			href: "/addressbooks/owner/card/ghost.vcf",
			vcard: buildVCard({ uid: "ghost", fn: "Ghost Example" }),
		});
		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "succeeded");

		assert.equal(recordsOf(result.messages, "contacts").length, 0);

		const contactsCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(contactsCoverage && contactsCoverage.type === "DETAIL_COVERAGE");
		assert.equal(
			contactsCoverage.considered,
			1,
			"the member the server enumerated must stay in the denominator",
		);
		assert.equal(contactsCoverage.covered, 0);
		assert.equal(
			contactsCoverage.considered > contactsCoverage.covered,
			true,
			"an unfetchable member must read as an honest partial, never a proven zero",
		);
	} finally {
		await server.close();
	}
});

test("apple_contacts integration: an iCloud group vCard becomes a group, not a phantom contact", async () => {
	// The defect this closes: iCloud stores each group as its own vCard
	// resource marked `X-ADDRESSBOOKSERVER-KIND:group`, but the connector read
	// only the vCard-standard CATEGORIES property. So the group's own resource
	// was emitted AS A CONTACT — a phantom whose display_name is the group's
	// name, counted as a covered contact — while `contact_groups`, a REQUIRED
	// stream, stayed empty. The fake server could not synthesize this shape
	// until now, which is why the whole suite passed while the connector was
	// blind.
	const server = await startFakeCardDavServer({
		username: USERNAME,
		password: PASSWORD,
	});
	try {
		server.contacts.set("alice", {
			uid: "alice",
			href: "/addressbooks/owner/card/alice.vcf",
			vcard: buildVCard({ uid: "alice", fn: "Alice Example" }),
		});
		server.contacts.set("bob", {
			uid: "bob",
			href: "/addressbooks/owner/card/bob.vcf",
			vcard: buildVCard({ uid: "bob", fn: "Bob Example" }),
		});
		server.contacts.set("family-group", {
			uid: "family-group",
			href: "/addressbooks/owner/card/family-group.vcf",
			vcard: buildVCard({
				uid: "family-group",
				fn: "Family",
				groupMemberUids: ["alice", "bob"],
			}),
		});

		const result = await runConnectorProtocolSubprocess({
			cwd: CWD,
			entrypoint: ENTRYPOINT,
			start: startMessage(),
			env: {
				APPLE_ID: USERNAME,
				APPLE_APP_SPECIFIC_PASSWORD: PASSWORD,
				APPLE_CARDDAV_ORIGIN: server.origin,
			},
		});

		const done = result.messages.findLast((m) => m.type === "DONE");
		assert.ok(done && done.type === "DONE");
		assert.equal(done.status, "succeeded");

		const contacts = recordsOf(result.messages, "contacts");
		const contactNames = contacts
			.map((c) => String(c.display_name))
			.sort((a, b) => a.localeCompare(b));
		assert.deepEqual(contactNames, ["Alice Example", "Bob Example"]);
		assert.equal(
			contacts.some((c) => c.display_name === "Family"),
			false,
			"the group vCard leaked into the contacts stream as a phantom contact",
		);

		// The group the connector was previously blind to must now be a record,
		// with the membership the SERVER stated rather than one inferred from
		// contact bodies.
		const groups = recordsOf(result.messages, "contact_groups");
		assert.deepEqual(
			groups.map((g) => g.name),
			["Family"],
		);
		const memberUids = groups[0]?.member_uids as string[] | undefined;
		assert.ok(memberUids);
		assert.deepEqual(
			[...memberUids].sort((a, b) => a.localeCompare(b)),
			["alice", "bob"],
		);

		// The group resource must leave the contacts denominator too: counting
		// it as considered-but-not-covered would manufacture a permanent
		// shortfall out of correct behaviour.
		const contactsCoverage = result.messages.find(
			(m) => m.type === "DETAIL_COVERAGE" && m.stream === "contacts",
		);
		assert.ok(contactsCoverage && contactsCoverage.type === "DETAIL_COVERAGE");
		assert.equal(contactsCoverage.considered, 2);
		assert.equal(contactsCoverage.covered, 2);
	} finally {
		await server.close();
	}
});
