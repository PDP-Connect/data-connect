import type { DiscoveryFetch } from "./discovery.ts";
export interface AddressBookInfo {
    ctag?: string;
    displayName?: string;
    syncToken?: string;
    url: string;
}
export interface VCardResource {
    etag?: string;
    href: string;
    vcardText: string;
}
export interface SyncCollectionResult {
    deletedHrefs: string[];
    /**
     * Hrefs the REPORT enumerated as present-and-current but for which the
     * server returned NO `address-data` body, even though the request asked for
     * it. RFC 6578 §3.2 does not oblige a server to inline arbitrary properties
     * in a sync-collection response, and iCloud in fact does not: its
     * sync-collection multistatus carries `getetag` only. These hrefs are real
     * members whose bodies must be fetched in a follow-up
     * `addressbook-multiget` (RFC 6352 §8.7) — dropping them silently is how a
     * populated address book reports as empty.
     */
    hrefsMissingBodies: string[];
    resources: VCardResource[];
    supportsSyncCollection: boolean;
    syncToken?: string;
    truncated: boolean;
}
/**
 * A structural, non-transient `davRequest` failure: the server's response
 * shape itself is the problem (missing/unsafe redirect location, oversized
 * body, redirect loop) rather than a status code that might clear on retry.
 * Every `davRequest` call site (sync-collection, addressbook-query,
 * list-addressbooks) throws this same class for these four shapes so
 * retryable-classification can dispatch by `instanceof` once, consistently,
 * instead of re-deriving it from message text at each call site.
 */
export declare class CardDavStructuralError extends Error {
    constructor(message: string);
}
/** List address book collections under the home-set URL (RFC 6352 §7.1). */
export declare function listAddressBooks(args: {
    authHeader: string;
    fetchImpl: DiscoveryFetch;
    homeUrl: string;
    trustedOrigins: string[];
}): Promise<AddressBookInfo[]>;
/**
 * Attempt RFC 6578 `sync-collection` REPORT. `priorSyncToken` empty string
 * means "initial sync" per RFC 6578 §3.2. Returns
 * `supportsSyncCollection: false` (never throws for this reason) when the
 * server responds 405/501/415 or omits a `sync-token` in the multistatus —
 * the caller falls back to a full `addressbook-query` snapshot.
 */
export declare function syncCollectionReport(args: {
    authHeader: string;
    bookUrl: string;
    fetchImpl: DiscoveryFetch;
    priorSyncToken: string;
    trustedOrigins: string[];
}): Promise<SyncCollectionResult>;
/**
 * Fetch vCard bodies for an explicit set of member hrefs
 * (RFC 6352 §8.7 `addressbook-multiget`). This is the companion to
 * `syncCollectionReport` for servers — iCloud among them — that enumerate
 * members in a sync-collection response without inlining `address-data`.
 *
 * Requests are chunked so a large change set cannot produce a single
 * unbounded request or response body.
 */
export declare function addressbookMultiget(args: {
    authHeader: string;
    bookUrl: string;
    fetchImpl: DiscoveryFetch;
    hrefs: readonly string[];
    trustedOrigins: string[];
}): Promise<VCardResource[]>;
/** Bounded full snapshot via `addressbook-query` (RFC 6352 §8.6) — the
 *  fallback path when sync-collection is unsupported. "Bounded" here means
 *  the caller (index.ts) applies the fingerprint cursor to the full result;
 *  this function itself does not paginate because CardDAV has no
 *  standardized paging mechanism (unlike CalDAV time-range limits) — an
 *  owner's address book is expected to be small enough (hundreds to low
 *  thousands of contacts) for one full multistatus response. */
export declare function addressbookQueryAll(args: {
    authHeader: string;
    bookUrl: string;
    fetchImpl: DiscoveryFetch;
    trustedOrigins: string[];
}): Promise<VCardResource[]>;
//# sourceMappingURL=carddav-client.d.ts.map