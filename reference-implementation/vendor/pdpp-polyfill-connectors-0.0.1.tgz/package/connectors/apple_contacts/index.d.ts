#!/usr/bin/env node
import { type RecordData } from "../../src/connector-runtime.ts";
import { type FingerprintCursor } from "../../src/fingerprint-cursor.ts";
import { type VCardResource } from "./carddav-client.ts";
import { type DiscoveryFetch } from "./discovery.ts";
import { type GroupAnchor } from "./group-vcards.ts";
import { type ParsedVCard } from "./vcard.ts";
export declare function addressBookRecord(book: {
    url: string;
    displayName?: string;
}, supportsSync: boolean): RecordData;
export declare function contactRecord(bookUrl: string, resource: VCardResource, card: ParsedVCard): RecordData;
export declare function contactTombstone(bookUrl: string, href: string): RecordData;
export declare function groupRecord(bookUrl: string, name: string, memberUids: string[], providerUid?: string): RecordData;
/**
 * Derive group-membership records from BOTH mechanisms a CardDAV server may
 * use.
 *
 *  1. Apple's group vCards — a resource in the collection carrying
 *     `X-ADDRESSBOOKSERVER-KIND:group` and `X-ADDRESSBOOKSERVER-MEMBER`
 *     lines. This is how iCloud actually stores groups.
 *  2. The vCard-standard `CATEGORIES` property on each contact
 *     (RFC 6350 §6.7.1).
 *
 * Only (2) was previously read. For an iCloud account that meant
 * `contact_groups` — a manifest-REQUIRED stream — could never emit a record
 * no matter how many groups the account had, and the resulting zero was
 * indistinguishable from a genuinely empty address book.
 *
 * A group vCard wins over a same-named CATEGORIES group: the server's own
 * membership list is authoritative over one inferred from contact bodies.
 */
export declare function deriveGroups(bookUrl: string, cards: ReadonlyArray<{
    card: ParsedVCard;
    uid: string;
}>): RecordData[];
interface AddressBookCollectionCtx {
    authHeader: string;
    book: {
        url: string;
        displayName?: string;
    };
    bookCursor: FingerprintCursor;
    /** See `BaseCollectContext.collectionMode`. `"full_refresh"` makes this book
     *  ignore its stored `sync_token` for this run. `undefined` means
     *  `"incremental"`, matching that contract. */
    collectionMode: "full_refresh" | "incremental" | undefined;
    emit: (msg: {
        type: "STATE";
        stream: string;
        cursor: unknown;
    }) => Promise<void>;
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    fetchImpl: DiscoveryFetch;
    newState: Record<string, unknown>;
    progress: (message: string, extra?: {
        count?: number;
        stream?: string;
        total?: number;
    }) => Promise<void>;
    requested: Map<string, unknown>;
    state: Record<string, unknown>;
    trustedOrigins: string[];
}
/**
 * Collect one address book: probe sync capability, fetch (sync-collection or
 * bounded full snapshot), emit the address-book entity record plus contact +
 * group records, and advance this book's contacts-stream cursor. Extracted
 * from collect() to keep the top-level function's branching bounded — this
 * is the whole per-book unit of work in one place.
 */
export declare function collectAddressBook(ctx: AddressBookCollectionCtx): Promise<{
    contactsBoundaryEstablished: boolean;
    contactsConsidered: number;
    contactsCovered: number;
    covered: boolean;
    groupAnchor: GroupAnchor;
    groupsEmitted: number;
    groupsBoundaryEstablished: boolean;
    hadUnparseableResource: boolean;
}>;
export {};
//# sourceMappingURL=index.d.ts.map