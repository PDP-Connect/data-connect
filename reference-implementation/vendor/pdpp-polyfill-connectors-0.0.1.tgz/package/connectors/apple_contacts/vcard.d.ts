/**
 * Minimal RFC 6350 (vCard 3.0/4.0) parser for the Apple Contacts connector.
 *
 * Scope is bounded to what CardDAV contact collection needs: line
 * unfolding, `\,`/`\;`/`\n` value escaping, TYPE parameters (for
 * typed emails/phones/addresses), and the handful of properties Apple's
 * CardDAV vCards actually carry (FN, N, EMAIL, TEL, ADR, ORG, TITLE,
 * NOTE, BDAY, PHOTO, UID, REV, CATEGORIES). It is not a general-purpose
 * vCard library — unknown properties are preserved in `rawProperties` but
 * not individually modeled.
 */
export interface VCardTypedValue {
    types: string[];
    value: string;
}
export interface VCardAddress extends VCardTypedValue {
    city?: string;
    country?: string;
    extended?: string;
    poBox?: string;
    postalCode?: string;
    region?: string;
    street?: string;
}
export interface VCardPhoto {
    base64: string;
    mediaType?: string;
}
export interface ParsedVCard {
    addresses: VCardAddress[];
    birthday?: string;
    emails: VCardTypedValue[];
    familyName?: string;
    fn?: string;
    givenName?: string;
    note?: string;
    org?: string;
    phones: VCardTypedValue[];
    photo?: VCardPhoto;
    rawProperties: Array<{
        name: string;
        params: Record<string, string[]>;
        value: string;
    }>;
    rev?: string;
    title?: string;
    uid?: string;
}
/** Unescape a vCard TEXT value: `\,` `\;` `\\` `\n`/`\N` per RFC 6350 §3.4. */
export declare function unescapeVCardValue(value: string): string;
/** Escape a value for emission inside a vCard TEXT property. */
export declare function escapeVCardValue(value: string): string;
/** Parse a single vCard's unfolded content lines (excluding BEGIN/END:VCARD). */
export declare function parseVCardLines(lines: string[]): ParsedVCard;
export interface VCardWithGroupInfo extends ParsedVCard {
    /** CATEGORIES property values, if present — used as a lightweight
     *  group-membership signal when the server exposes groups as vCard
     *  group vCards (kind=group) rather than a separate collection. */
    categories: string[];
}
/** Parse a full CardDAV multi-vCard text blob (a REPORT response embeds
 *  one vCard per `calendar-data`/`address-data` element, but some server
 *  responses concatenate). Returns one ParsedVCard per BEGIN/END:VCARD block. */
export declare function parseVCards(raw: string): ParsedVCard[];
/** CATEGORIES parsed out of rawProperties, kept separate from ParsedVCard's
 *  core fields since group membership is a distinct concern (see index.ts). */
export declare function categoriesOf(card: ParsedVCard): string[];
//# sourceMappingURL=vcard.d.ts.map