// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/** RFC 6350 §6.1.4 defines `KIND`; Apple ships the pre-standard
 *  `X-ADDRESSBOOKSERVER-KIND` on iCloud. Both are accepted so a standards
 *  -compliant server and iCloud are read the same way. */
const KIND_PROPERTY_NAMES = ["X-ADDRESSBOOKSERVER-KIND", "KIND"];
/** Apple's member property. RFC 6350 §6.6.5 standardises `MEMBER`; iCloud
 *  ships the `X-ADDRESSBOOKSERVER-` prefixed form. */
const MEMBER_PROPERTY_NAMES = ["X-ADDRESSBOOKSERVER-MEMBER", "MEMBER"];
/** Members are listed as `urn:uuid:<uid>`. The prefix is stripped so a
 *  member uid compares equal to the `UID` the same server reports on the
 *  member's own vCard, which `vcard.ts` already strips identically. */
const URN_UUID_PREFIX_RE = /^urn:uuid:/i;
function rawValues(card, names) {
    const wanted = new Set(names.map((n) => n.toUpperCase()));
    return card.rawProperties
        .filter((p) => wanted.has(p.name.toUpperCase()))
        .map((p) => p.value.trim());
}
/**
 * True when this vCard is a GROUP rather than a person.
 *
 * Fails SAFE toward "contact": a resource is only treated as a group when
 * the server explicitly said so. An unrecognised or absent KIND means the
 * resource keeps its existing treatment as a contact, so this predicate can
 * never silently remove a real person from `contacts`.
 */
export function isGroupVCard(card) {
    return rawValues(card, KIND_PROPERTY_NAMES).some((v) => v.toLowerCase() === "group");
}
/**
 * The member UIDs a group vCard lists, `urn:uuid:` prefix stripped and
 * blanks dropped. Order is preserved and duplicates are removed, so the
 * result is a stable set-like list suitable for a record body.
 */
export function groupMemberUids(card) {
    const out = [];
    const seen = new Set();
    for (const value of rawValues(card, MEMBER_PROPERTY_NAMES)) {
        const uid = value.replace(URN_UUID_PREFIX_RE, "").trim();
        if (uid && !seen.has(uid)) {
            seen.add(uid);
            out.push(uid);
        }
    }
    return out;
}
/**
 * Split an enumerated collection into person vCards and group vCards.
 *
 * This is the single place that decides what a resource IS, so the contact
 * emitter and the group anchor cannot disagree about it — the phantom-contact
 * defect was precisely such a disagreement, with no partition at all.
 */
export function partitionVCards(resources) {
    const contacts = [];
    const groups = [];
    for (const resource of resources) {
        if (isGroupVCard(resource.card)) {
            groups.push(resource);
        }
        else {
            contacts.push(resource);
        }
    }
    return { contacts, groups };
}
/**
 * Turn the measured anchor into a verdict.
 *
 * The comparison is one-directional on purpose. Emitting MORE groups than
 * the server enumerated as group vCards is normal and correct: CATEGORIES
 * groups have no server-side resource, so they legitimately add to the
 * emitted count without adding to the measured denominator. Only "the server
 * holds groups we did not emit" is a gap.
 *
 * This mirrors the deletion-safe reasoning used elsewhere in the fleet: a
 * two-way equality would flag correct behaviour as failure.
 */
export function groupAnchorVerdict(anchor) {
    if (!anchor.boundaryEstablished) {
        return { status: "unproven", reason: "boundary_not_established" };
    }
    if (anchor.serverGroupVCards === 0 &&
        anchor.derivedCategoryGroups === 0 &&
        anchor.emitted === 0) {
        return { status: "empty_confirmed" };
    }
    const considered = anchor.serverGroupVCards;
    const covered = Math.min(anchor.emitted, considered);
    if (covered < considered) {
        return {
            status: "short",
            considered,
            covered,
            missing: considered - covered,
        };
    }
    return { status: "complete", considered, covered };
}
