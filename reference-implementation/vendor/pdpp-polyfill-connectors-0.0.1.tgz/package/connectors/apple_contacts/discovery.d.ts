export interface DiscoveryFetchResponse {
    body: ReadableStream<Uint8Array> | null;
    headers: {
        get: (name: string) => string | null;
    };
    status: number;
}
export type DiscoveryFetch = (url: string, init: {
    headers: Record<string, string>;
    method: string;
    body?: string;
    redirect?: "manual";
}) => Promise<DiscoveryFetchResponse>;
/** Adapt the global `fetch` to {@link DiscoveryFetch}. `Response` already
 *  structurally satisfies {@link DiscoveryFetchResponse} (a `headers.get`
 *  method and a `body` stream), so this is a plain call-through — no cast
 *  needed, real or double. Shared by the connector and its tests so neither
 *  has to reach for `as unknown as`. */
export declare const nativeFetchAdapter: DiscoveryFetch;
export interface CardDavDiscoveryResult {
    addressBookHomeUrl: string;
    principalUrl: string;
    /** Every origin visited during discovery, in order — surfaced for
     *  diagnostics/tests, never logged with credentials attached. */
    visitedOrigins: string[];
}
export declare class CardDavRedirectOriginError extends Error {
    constructor(fromOrigin: string, toOrigin: string);
}
export declare class CardDavDiscoveryError extends Error {
    constructor(message: string);
}
/** Ceiling for every authenticated XML/vCard response body this connector
 *  reads (PROPFIND/REPORT multistatus, which embeds vCards, which can embed
 *  a base64 PHOTO). 8 MiB comfortably covers a large address book's full
 *  snapshot or sync-collection page while bounding worst-case memory
 *  against a hostile or misbehaving server. See bounded-response-read.ts. */
export declare const MAX_RESPONSE_BYTES: number;
/** Validate that a redirect target is safe to follow with the caller's
 *  credentials still attached. Exported for unit testing independent of
 *  network I/O.
 *
 *  Order of checks, all required, no fallback to a broader heuristic:
 *    1. Scheme must be HTTPS (or loopback, for local test servers only).
 *    2. Userinfo in either URL is refused outright (URL-confusion guard).
 *    3. Exact same origin is always safe.
 *    4. An explicitly caller-supplied trusted origin is safe (a prior hop
 *       this same discovery run already validated).
 *    5. The narrow icloud.com-subdomain carve-out (isIcloudRegionalRedirect)
 *       is the ONLY remaining widening rule. There is no general
 *       "same registrable domain" fallback — see the module doc comment
 *       for why that heuristic was removed. */
export declare function isSafeRedirectTarget(fromUrl: string, toUrl: string, trustedOrigins: readonly string[]): boolean;
/**
 * Run full RFC 6764 discovery from an owner-entered origin (e.g.
 * `https://contacts.icloud.com` or any CardDAV-capable origin the owner
 * types in). Does not assume iCloud; any RFC 6764-compliant server works.
 */
export declare function discoverCardDav(args: {
    authHeader: string;
    fetchImpl: DiscoveryFetch;
    originUrl: string;
}): Promise<CardDavDiscoveryResult>;
//# sourceMappingURL=discovery.d.ts.map