/**
 * Bounded-size response body reader for the Apple Contacts CardDAV client.
 *
 * Every authenticated request this connector makes reads an XML multistatus
 * body (PROPFIND/REPORT) that embeds vCards, which in turn can embed a
 * base64 PHOTO property. None of those three layers has a protocol-enforced
 * size ceiling: a misbehaving or compromised CardDAV server (or a
 * man-in-the-middle on a redirect hop that slipped past origin validation)
 * could return an arbitrarily large body and force this connector to
 * allocate unbounded memory before any content is even inspected.
 *
 * This module is the single choke point every response body passes through.
 * It is deliberately NOT a generic "bounded fetch" package — Apple Contacts
 * is the only consumer today (per the standing rule: don't build a shared
 * abstraction before a second consumer exists). If a second CardDAV-ish
 * connector shows up, promote this to `src/` then.
 *
 * Two independent guards, because either one alone is insufficient:
 *   1. `Content-Length`, when present, is checked BEFORE reading a single
 *      body byte — the fast rejection path for a server that discloses an
 *      oversized body up front.
 *   2. A streaming byte-count cap is enforced while consuming the body
 *      regardless of what `Content-Length` claimed (or omitted) — this is
 *      the ONLY guard that catches a missing or dishonest Content-Length
 *      (a server that under-reports the header, or omits it and chunks
 *      indefinitely). The stream is aborted as soon as the cap is crossed,
 *      so memory usage is bounded by `maxBytes` even against a hostile body.
 */
export type BoundedReadOutcome = {
    kind: "ok";
    text: string;
} | {
    kind: "content_length_exceeded";
    declaredBytes: number;
    maxBytes: number;
} | {
    kind: "content_length_missing_stream_exceeded";
    maxBytes: number;
} | {
    kind: "content_length_understated_stream_exceeded";
    declaredBytes: number;
    maxBytes: number;
};
export interface BoundedReadableResponse {
    body: ReadableStream<Uint8Array> | null;
    headers: {
        get: (name: string) => string | null;
    };
}
/**
 * Read a response body as text, enforcing `maxBytes` two ways: an upfront
 * `Content-Length` check (when the header is present and parses cleanly),
 * and a streaming byte-count cap that is authoritative regardless of what
 * the header said. Never buffers more than `maxBytes` (+ one chunk's worth
 * of overrun before the cap trips, since chunk boundaries aren't caller
 * controlled) before returning a rejection.
 */
export declare function readBoundedText(res: BoundedReadableResponse, maxBytes: number): Promise<BoundedReadOutcome>;
/** Human-readable summary for a rejected outcome, safe to include in a
 *  thrown error message — carries no response body content, only sizes. */
export declare function describeBoundedReadRejection(outcome: Exclude<BoundedReadOutcome, {
    kind: "ok";
}>): string;
//# sourceMappingURL=bounded-response-read.d.ts.map