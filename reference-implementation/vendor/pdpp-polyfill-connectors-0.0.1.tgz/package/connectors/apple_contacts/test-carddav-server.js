// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Deterministic local fake CardDAV server for Apple Contacts connector
 * tests. Implements just enough of RFC 5785 well-known discovery, RFC 6764
 * bootstrap PROPFINDs, RFC 6352 address book listing, and RFC 6578
 * sync-collection REPORT (plus a bounded addressbook-query fallback) to
 * exercise the connector end-to-end without any network access or real
 * Apple account.
 */
import { createServer, } from "node:http";
import { unescapeVCardValue } from "./vcard.js";
const TRAILING_SLASH_RE = /\/$/;
const ABSOLUTE_HREF_RE = /^https?:\/\//i;
const NS_D = "DAV:";
const NS_CS = "http://calendarserver.org/ns/";
const PRINCIPAL_PATH = "/principals/owner/";
const HOME_PATH = "/addressbooks/owner/";
const BOOK_PATH = "/addressbooks/owner/card/";
function xmlEscape(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function multistatus(inner) {
    return `<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="${NS_D}" xmlns:CS="${NS_CS}" xmlns:C="urn:ietf:params:xml:ns:carddav">${inner}</D:multistatus>`;
}
/**
 * Read the `<D:sync-token>` value out of a sync-collection REPORT body.
 * RFC 6578 §3.2 distinguishes an EMPTY token (send me the whole collection)
 * from a non-empty one (send me only what changed since then), so the fake
 * server needs the actual value, not merely its presence.
 */
const SYNC_TOKEN_RE = /<(?:[A-Za-z0-9]+:)?sync-token>([\s\S]*?)<\/(?:[A-Za-z0-9]+:)?sync-token>/;
function extractSyncTokenFromRequest(body) {
    const match = SYNC_TOKEN_RE.exec(body);
    return match?.[1]?.trim() ?? "";
}
function readBody(req) {
    return new Promise((resolve, reject) => {
        let data = "";
        req.on("data", (chunk) => {
            data += chunk.toString();
        });
        req.on("end", () => resolve(data));
        req.on("error", reject);
    });
}
function checkAuth(req, username, password) {
    const header = req.headers.authorization;
    if (!header?.startsWith("Basic ")) {
        return false;
    }
    const decoded = Buffer.from(header.slice(6), "base64").toString("utf8");
    return decoded === `${username}:${password}`;
}
/**
 * Start a fake CardDAV server. Address book state (contacts, deletions) is
 * mutable on the returned handle so tests can simulate multi-run sync
 * scenarios (add / edit / delete between two connector runs).
 */
export async function startFakeCardDavServer(options) {
    const { username, password, disableSyncCollection = false, enforceRfc6578IncrementalSemantics = false, regionalHost = false, wellKnownAnswersInlineWithoutPrincipal = false, syncReportRedirectsToUnsafeOrigin = false, syncCollectionOmitsAddressData = false, multigetReturnsNoBodies = false, } = options;
    const contacts = new Map();
    const deletedHrefs = new Set();
    const requestLog = [];
    let authRejectedCount = 0;
    let changeCounter = 1;
    let regionalOrigin = null;
    const respondWellKnownPrincipalNotFound = (res) => {
        // Mirrors the real iCloud shape: 207 Multi-Status, single <response>
        // for the well-known resource itself, current-user-principal reported
        // via a 404 propstat (RFC 4918 §14.22) rather than populated.
        const responseBody = multistatus("<D:response><D:href>/.well-known/carddav/</D:href><D:propstat><D:prop><D:current-user-principal/></D:prop><D:status>HTTP/1.1 404 Not Found</D:status></D:propstat></D:response>");
        res.writeHead(207, { "Content-Type": "application/xml" });
        res.end(responseBody);
    };
    const respondWellKnown = (res, thisOrigin) => {
        if (wellKnownAnswersInlineWithoutPrincipal) {
            respondWellKnownPrincipalNotFound(res);
            return;
        }
        const target = regionalOrigin && regionalOrigin !== thisOrigin()
            ? regionalOrigin
            : thisOrigin();
        res.writeHead(302, { Location: `${target}${PRINCIPAL_PATH}` });
        res.end();
    };
    const respondCurrentUserPrincipal = (res, atHref) => {
        const responseBody = multistatus(`<D:response><D:href>${atHref}</D:href><D:propstat><D:prop><D:current-user-principal><D:href>${PRINCIPAL_PATH}</D:href></D:current-user-principal></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`);
        res.writeHead(207, { "Content-Type": "application/xml" });
        res.end(responseBody);
    };
    const respondAddressbookHomeSet = (res) => {
        const responseBody = multistatus(`<D:response><D:href>${PRINCIPAL_PATH}</D:href><D:propstat><D:prop><C:addressbook-home-set><D:href>${HOME_PATH}</D:href></C:addressbook-home-set></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`);
        res.writeHead(207, { "Content-Type": "application/xml" });
        res.end(responseBody);
    };
    const respondAddressbookList = (res) => {
        const responseBody = multistatus(`<D:response><D:href>${BOOK_PATH}</D:href><D:propstat><D:prop><D:resourcetype><D:collection/><C:addressbook/></D:resourcetype><D:displayname>Contacts</D:displayname><CS:getctag>"ctag-${String(changeCounter)}"</CS:getctag></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`);
        res.writeHead(207, { "Content-Type": "application/xml" });
        res.end(responseBody);
    };
    const contactResponseBlocks = () => [...contacts.values()]
        .map((c) => `<D:response><D:href>${c.href}</D:href><D:propstat><D:prop><D:getetag>"${c.uid}-${String(changeCounter)}"</D:getetag><C:address-data>${xmlEscape(c.vcard)}</C:address-data></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`)
        .join("");
    /** Members enumerated with `getetag` only — no inlined `address-data`. */
    const etagOnlyResponseBlocks = () => [...contacts.values()]
        .map((c) => `<D:response><D:href>${c.href}</D:href><D:propstat><D:prop><D:getetag>"${c.uid}-${String(changeCounter)}"</D:getetag></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`)
        .join("");
    const HREF_RE = /<[^:>]*:?href[^>]*>([\s\S]*?)<\/[^:>]*:?href>/gi;
    /** RFC 6352 §8.7 addressbook-multiget: return bodies for exactly the
     *  requested hrefs, and 404 any href the collection does not hold. */
    const respondAddressbookMultiget = (res, body) => {
        const requestedHrefs = [...body.matchAll(HREF_RE)].map((m) => (m[1] ?? "").trim());
        // iCloud answers 400 to an absolute <D:href> inside a multiget and 207 to
        // the path form (probe against p196-contacts.icloud.com, 2026-08-19).
        // Enforce that here so a regression to absolute hrefs fails in tests
        // instead of only against the real provider.
        if (requestedHrefs.some((href) => ABSOLUTE_HREF_RE.test(href))) {
            res.writeHead(400, { "Content-Type": "text/plain" });
            res.end("Bad Request");
            return;
        }
        const blocks = requestedHrefs
            .map((href) => {
            const path = (() => {
                try {
                    return new URL(href, "http://placeholder.invalid").pathname;
                }
                catch {
                    return href;
                }
            })();
            const contact = multigetReturnsNoBodies
                ? undefined
                : [...contacts.values()].find((c) => c.href === path);
            if (!contact) {
                return `<D:response><D:href>${href}</D:href><D:status>HTTP/1.1 404 Not Found</D:status></D:response>`;
            }
            return `<D:response><D:href>${contact.href}</D:href><D:propstat><D:prop><D:getetag>"${contact.uid}-${String(changeCounter)}"</D:getetag><C:address-data>${xmlEscape(contact.vcard)}</C:address-data></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`;
        })
            .join("");
        res.writeHead(207, { "Content-Type": "application/xml" });
        res.end(multistatus(blocks));
    };
    const respondSyncCollection = (res, requestedSyncToken) => {
        if (syncReportRedirectsToUnsafeOrigin) {
            res.writeHead(302, {
                Location: "https://attacker.example/steal-carddav-creds",
            });
            res.end();
            return;
        }
        if (disableSyncCollection) {
            res.writeHead(501, { "Content-Type": "text/plain" });
            res.end("not implemented");
            return;
        }
        const newToken = `sync-token-${String(changeCounter)}`;
        const deleted = [...deletedHrefs]
            .map((href) => `<D:response><D:href>${href}</D:href><D:status>HTTP/1.1 404 Not Found</D:status></D:response>`)
            .join("");
        // RFC 6578 §3.2: a non-empty sync-token requests only what changed since
        // that token. Nothing has changed in this fixture, so the change feed is
        // empty — while the collection itself still holds every contact.
        const quiet = enforceRfc6578IncrementalSemantics && requestedSyncToken.length > 0;
        const populatedMembers = syncCollectionOmitsAddressData
            ? etagOnlyResponseBlocks()
            : contactResponseBlocks();
        const members = quiet ? "" : populatedMembers;
        // iCloud reports the collection's own href (without a trailing slash)
        // beside its members. A client must not mistake it for a contact.
        const collectionBlock = syncCollectionOmitsAddressData && !quiet
            ? `<D:response><D:href>${BOOK_PATH.replace(TRAILING_SLASH_RE, "")}</D:href><D:propstat><D:prop><D:getetag>collection-${String(changeCounter)}</D:getetag></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`
            : "";
        const responseBody = multistatus(`${collectionBlock}${members}${deleted}<D:sync-token>${newToken}</D:sync-token>`);
        res.writeHead(207, { "Content-Type": "application/xml" });
        res.end(responseBody);
    };
    const respondAddressbookQuery = (res) => {
        if (syncReportRedirectsToUnsafeOrigin) {
            res.writeHead(302, {
                Location: "https://attacker.example/steal-carddav-creds",
            });
            res.end();
            return;
        }
        res.writeHead(207, { "Content-Type": "application/xml" });
        res.end(multistatus(contactResponseBlocks()));
    };
    const routes = [
        {
            match: (_req, url) => url === "/.well-known/carddav",
            respond: (_req, res, thisOrigin) => respondWellKnown(res, thisOrigin),
        },
        {
            match: (req, url, body) => req.method === "PROPFIND" &&
                url === PRINCIPAL_PATH &&
                body.includes("current-user-principal"),
            respond: (_req, res) => respondCurrentUserPrincipal(res, PRINCIPAL_PATH),
        },
        {
            // Origin-root fallback target: only reached (in real discoverCardDav
            // usage) when the well-known step answered inline without the
            // property, per wellKnownAnswersInlineWithoutPrincipal above.
            match: (req, url, body) => req.method === "PROPFIND" &&
                url === "/" &&
                body.includes("current-user-principal"),
            respond: (_req, res) => respondCurrentUserPrincipal(res, "/"),
        },
        {
            match: (req, url, body) => req.method === "PROPFIND" &&
                url === PRINCIPAL_PATH &&
                body.includes("addressbook-home-set"),
            respond: (_req, res) => respondAddressbookHomeSet(res),
        },
        {
            match: (req, url) => req.method === "PROPFIND" &&
                url === HOME_PATH &&
                req.headers.depth === "1",
            respond: (_req, res) => respondAddressbookList(res),
        },
        {
            match: (req, url, body) => req.method === "REPORT" &&
                url === BOOK_PATH &&
                body.includes("sync-collection"),
            respond: (_req, res, _origin, body) => respondSyncCollection(res, extractSyncTokenFromRequest(body ?? "")),
        },
        {
            match: (req, url, body) => req.method === "REPORT" &&
                url === BOOK_PATH &&
                body.includes("addressbook-multiget"),
            respond: (_req, res, _origin, body) => respondAddressbookMultiget(res, body ?? ""),
        },
        {
            match: (req, url, body) => req.method === "REPORT" &&
                url === BOOK_PATH &&
                body.includes("addressbook-query"),
            respond: (_req, res) => respondAddressbookQuery(res),
        },
    ];
    const makeHandler = (thisOrigin) => async (req, res) => {
        const url = req.url ?? "/";
        requestLog.push({ method: req.method ?? "GET", url });
        if (!checkAuth(req, username, password)) {
            authRejectedCount += 1;
            res.writeHead(401, {
                "Content-Type": "text/plain",
                "WWW-Authenticate": 'Basic realm="carddav"',
            });
            res.end("unauthorized");
            return;
        }
        const body = await readBody(req);
        const route = routes.find((r) => r.match(req, url, body));
        if (route) {
            route.respond(req, res, thisOrigin, body);
            return;
        }
        res.writeHead(404, { "Content-Type": "text/plain" });
        res.end("not found");
    };
    let server;
    let regionalServer = null;
    server = createServer((req, res) => {
        makeHandler(() => `http://127.0.0.1:${String(port)}`)(req, res).catch(() => {
            if (!res.headersSent) {
                res.writeHead(500);
            }
            res.end("internal error");
        });
    });
    await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
    const address = server.address();
    if (!address || typeof address === "string") {
        throw new Error("fake_carddav_server_no_port");
    }
    const { port } = address;
    const origin = `http://127.0.0.1:${String(port)}`;
    if (regionalHost) {
        regionalServer = createServer((req, res) => {
            makeHandler(() => regionalOrigin ?? origin)(req, res).catch(() => {
                if (!res.headersSent) {
                    res.writeHead(500);
                }
                res.end("internal error");
            });
        });
        await new Promise((resolve) => regionalServer.listen(0, "127.0.0.1", resolve));
        const regionalAddress = regionalServer.address();
        if (regionalAddress && typeof regionalAddress !== "string") {
            regionalOrigin = `http://127.0.0.1:${String(regionalAddress.port)}`;
        }
    }
    return {
        port,
        origin,
        contacts,
        deletedHrefs,
        requestLog,
        get regionalOrigin() {
            return regionalOrigin;
        },
        get authRejectedCount() {
            return authRejectedCount;
        },
        url: (path) => `${origin}${path}`,
        markChanged: () => {
            changeCounter += 1;
        },
        close: async () => {
            await new Promise((resolve, reject) => server.close((err) => (err ? reject(err) : resolve())));
            if (regionalServer) {
                await new Promise((resolve, reject) => regionalServer.close((err) => err ? reject(err) : resolve()));
            }
        },
    };
}
export function buildVCard(fields) {
    const lines = [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `UID:${fields.uid}`,
        `FN:${unescapeVCardValue(fields.fn)}`,
    ];
    if (fields.email) {
        lines.push(`EMAIL;TYPE=HOME:${fields.email}`);
    }
    if (fields.categories?.length) {
        lines.push(`CATEGORIES:${fields.categories.join(",")}`);
    }
    if (fields.groupMemberUids) {
        lines.push("X-ADDRESSBOOKSERVER-KIND:group");
        for (const member of fields.groupMemberUids) {
            lines.push(`X-ADDRESSBOOKSERVER-MEMBER:urn:uuid:${member}`);
        }
    }
    if (fields.photo) {
        lines.push(`PHOTO;ENCODING=b;TYPE=${fields.photo.mediaType.toUpperCase()}:${fields.photo.base64}`);
    }
    lines.push("END:VCARD");
    return lines.join("\r\n");
}
