export interface FakeContact {
    href: string;
    uid: string;
    vcard: string;
}
export interface FakeServerOptions {
    /** When true, REPORT sync-collection returns 501 (unsupported); the
     *  server still answers addressbook-query so the fallback path works. */
    disableSyncCollection?: boolean;
    /**
     * When true, sync-collection obeys RFC 6578 §3.2 faithfully: a request
     * carrying a NON-EMPTY `<D:sync-token>` returns only the members that
     * changed since that token — for a quiet collection, an EMPTY response with
     * a fresh token — while a request with an empty token still returns every
     * member. The default (false) returns all contacts for any token, which is
     * a permissive fiction convenient for most tests.
     *
     * Set this to reproduce the class of defect where an empty CHANGE FEED is
     * mistaken for an empty INVENTORY.
     */
    enforceRfc6578IncrementalSemantics?: boolean;
    /** When true, `addressbook-multiget` answers 404 for every requested href.
     *  Models a member the server enumerated but whose body it will not hand
     *  over, so the client must report considered-but-not-covered rather than a
     *  proven zero. */
    multigetReturnsNoBodies?: boolean;
    password: string;
    /** When true, /.well-known/carddav redirects to a second listener
     *  simulating iCloud's regional-host resolution, instead of a
     *  same-origin redirect. */
    regionalHost?: boolean;
    /**
     * When true, the sync-collection REPORT enumerates members with `getetag`
     * ONLY — it does not inline the requested `address-data` — and additionally
     * reports the collection's own href alongside its members. This is the
     * behavior observed live against iCloud (p196-contacts.icloud.com, probe
     * 2026-08-19) and it is RFC-legal: RFC 6578 §3.2 obliges the server to
     * enumerate changed members, not to inline arbitrary properties. Bodies are
     * then only obtainable via `addressbook-multiget` (RFC 6352 §8.7).
     *
     * Set this to reproduce the class of defect where a client drops every
     * enumerated member that arrived without an inlined body, turning a
     * populated address book into a measured zero.
     */
    syncCollectionOmitsAddressData?: boolean;
    /** When true, the sync-collection REPORT (and addressbook-query REPORT)
     *  respond with a 302 to an untrusted, unrelated origin instead of the
     *  normal multistatus body — models a compromised/misconfigured server
     *  attempting a credential-stealing redirect mid-sync, after discovery
     *  has already completed successfully. */
    syncReportRedirectsToUnsafeOrigin?: boolean;
    username: string;
    /** When true, /.well-known/carddav answers PROPFIND inline (207, no
     *  redirect) with `current-user-principal` 404'd in its propstat — the
     *  real behavior observed live against iCloud — instead of the
     *  RFC-6764-typical redirect. `current-user-principal` is only answered
     *  at the bare origin root ("/") in this mode, so the test exercises
     *  discoverCardDav's origin-root fallback. */
    wellKnownAnswersInlineWithoutPrincipal?: boolean;
}
export interface FakeCardDavServer {
    readonly authRejectedCount: number;
    close: () => Promise<void>;
    contacts: Map<string, FakeContact>;
    deletedHrefs: Set<string>;
    markChanged: () => void;
    origin: string;
    port: number;
    regionalOrigin: string | null;
    requestLog: Array<{
        method: string;
        url: string;
    }>;
    url: (path: string) => string;
}
/**
 * Start a fake CardDAV server. Address book state (contacts, deletions) is
 * mutable on the returned handle so tests can simulate multi-run sync
 * scenarios (add / edit / delete between two connector runs).
 */
export declare function startFakeCardDavServer(options: FakeServerOptions): Promise<FakeCardDavServer>;
export declare function buildVCard(fields: {
    categories?: string[];
    email?: string;
    fn: string;
    /** Member UIDs. Presence makes this a group vCard in Apple's wire shape
     *  (`X-ADDRESSBOOKSERVER-KIND:group`), which is how iCloud actually stores
     *  groups. Without this the fixture could only synthesize CATEGORIES, so a
     *  connector blind to group vCards still passed every test — the fixture
     *  gap that let the `contact_groups` defect hide. */
    groupMemberUids?: string[];
    photo?: {
        base64: string;
        mediaType: string;
    };
    uid: string;
}): string;
//# sourceMappingURL=test-carddav-server.d.ts.map