import type { ParsedVCard } from "./vcard.ts";
/**
 * True when this vCard is a GROUP rather than a person.
 *
 * Fails SAFE toward "contact": a resource is only treated as a group when
 * the server explicitly said so. An unrecognised or absent KIND means the
 * resource keeps its existing treatment as a contact, so this predicate can
 * never silently remove a real person from `contacts`.
 */
export declare function isGroupVCard(card: ParsedVCard): boolean;
/**
 * The member UIDs a group vCard lists, `urn:uuid:` prefix stripped and
 * blanks dropped. Order is preserved and duplicates are removed, so the
 * result is a stable set-like list suitable for a record body.
 */
export declare function groupMemberUids(card: ParsedVCard): string[];
/** The enumerated collection, partitioned by what each resource actually is. */
export interface VCardPartition<T> {
    contacts: T[];
    groups: T[];
}
/**
 * Split an enumerated collection into person vCards and group vCards.
 *
 * This is the single place that decides what a resource IS, so the contact
 * emitter and the group anchor cannot disagree about it — the phantom-contact
 * defect was precisely such a disagreement, with no partition at all.
 */
export declare function partitionVCards<T extends {
    card: ParsedVCard;
}>(resources: readonly T[]): VCardPartition<T>;
/**
 * The `contact_groups` completeness anchor for one address book.
 *
 * `serverGroupVCards` is the MEASURED denominator: group resources the
 * server itself enumerated. `derivedCategoryGroups` is reported alongside it
 * but deliberately kept separate — it is derived from contact bodies, not
 * measured at the boundary, and merging the two would manufacture a
 * denominator partly out of the data it is meant to verify.
 */
export interface GroupAnchor {
    /** True only when the enumeration reached a complete boundary. */
    boundaryEstablished: boolean;
    /** Distinct group names derived from contacts' CATEGORIES. Derived, not measured. */
    derivedCategoryGroups: number;
    /** Group records actually emitted this run. */
    emitted: number;
    /** Group vCards the server enumerated. Measured at the source boundary. */
    serverGroupVCards: number;
}
export type GroupAnchorVerdict = 
/** Enumeration was incomplete; no claim about completeness is possible. */
{
    status: "unproven";
    reason: "boundary_not_established";
}
/** The server enumerated no groups and no CATEGORIES groups were derived.
 *  This is a CHECKED zero — genuine evidence of an empty account. */
 | {
    status: "empty_confirmed";
}
/** Every group the server holds is accounted for in what was emitted. */
 | {
    status: "complete";
    considered: number;
    covered: number;
}
/** The server holds groups that were not emitted. */
 | {
    status: "short";
    considered: number;
    covered: number;
    missing: number;
};
/**
 * Turn the measured anchor into a verdict.
 *
 * The comparison is one-directional on purpose. Emitting MORE groups than
 * the server enumerated as group vCards is normal and correct: CATEGORIES
 * groups have no server-side resource, so they legitimately add to the
 * emitted count without adding to the measured denominator. Only "the server
 * holds groups we did not emit" is a gap.
 *
 * This mirrors the deletion-safe reasoning used elsewhere in the fleet: a
 * two-way equality would flag correct behaviour as failure.
 */
export declare function groupAnchorVerdict(anchor: GroupAnchor): GroupAnchorVerdict;
//# sourceMappingURL=group-vcards.d.ts.map