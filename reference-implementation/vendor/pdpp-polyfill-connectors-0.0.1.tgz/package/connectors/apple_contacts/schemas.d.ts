/**
 * Zod schemas for Apple Contacts stream records. See
 * docs/reference/connector-authoring-guide.md §3: records that don't match
 * the schema become SKIP_RESULT events instead of RECORD events.
 */
import { z } from "zod";
export declare const contactsSchema: z.ZodObject<{
    id: z.ZodString;
    addressbook_url: z.ZodString;
    uid: z.ZodNullable<z.ZodString>;
    display_name: z.ZodNullable<z.ZodString>;
    family_name: z.ZodNullable<z.ZodString>;
    given_name: z.ZodNullable<z.ZodString>;
    org: z.ZodNullable<z.ZodString>;
    title: z.ZodNullable<z.ZodString>;
    note: z.ZodNullable<z.ZodString>;
    birthday: z.ZodNullable<z.ZodString>;
    emails: z.ZodArray<z.ZodObject<{
        types: z.ZodArray<z.ZodString>;
        value: z.ZodString;
    }, z.core.$strip>>;
    phones: z.ZodArray<z.ZodObject<{
        types: z.ZodArray<z.ZodString>;
        value: z.ZodString;
    }, z.core.$strip>>;
    addresses: z.ZodArray<z.ZodObject<{
        types: z.ZodArray<z.ZodString>;
        value: z.ZodString;
        city: z.ZodNullable<z.ZodString>;
        country: z.ZodNullable<z.ZodString>;
        extended: z.ZodNullable<z.ZodString>;
        po_box: z.ZodNullable<z.ZodString>;
        postal_code: z.ZodNullable<z.ZodString>;
        region: z.ZodNullable<z.ZodString>;
        street: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    has_photo: z.ZodBoolean;
    photo_media_type: z.ZodNullable<z.ZodString>;
    photo_base64: z.ZodNullable<z.ZodString>;
    etag: z.ZodNullable<z.ZodString>;
    rev: z.ZodNullable<z.ZodString>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const addressBooksSchema: z.ZodObject<{
    id: z.ZodString;
    display_name: z.ZodNullable<z.ZodString>;
    url: z.ZodString;
    supports_sync_collection: z.ZodBoolean;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const contactGroupsSchema: z.ZodObject<{
    id: z.ZodString;
    addressbook_url: z.ZodString;
    name: z.ZodString;
    member_uids: z.ZodArray<z.ZodString>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map