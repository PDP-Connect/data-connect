// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
const CONTENT_LENGTH_DIGITS_RE = /^\d+$/;
/** Parse a `Content-Length` header value. Returns `null` for anything that
 *  is not a non-negative integer (missing, empty, non-numeric, negative,
 *  or a value with trailing garbage) — treated identically to "absent" by
 *  the caller, which is the safe direction (falls through to the streaming
 *  guard rather than trusting a malformed declaration). */
function parseContentLength(raw) {
    if (raw === null) {
        return null;
    }
    const trimmed = raw.trim();
    if (!CONTENT_LENGTH_DIGITS_RE.test(trimmed)) {
        return null;
    }
    const value = Number(trimmed);
    return Number.isSafeInteger(value) ? value : null;
}
/**
 * Read a response body as text, enforcing `maxBytes` two ways: an upfront
 * `Content-Length` check (when the header is present and parses cleanly),
 * and a streaming byte-count cap that is authoritative regardless of what
 * the header said. Never buffers more than `maxBytes` (+ one chunk's worth
 * of overrun before the cap trips, since chunk boundaries aren't caller
 * controlled) before returning a rejection.
 */
export async function readBoundedText(res, maxBytes) {
    const declaredBytes = parseContentLength(res.headers.get("content-length"));
    if (declaredBytes !== null && declaredBytes > maxBytes) {
        return { kind: "content_length_exceeded", declaredBytes, maxBytes };
    }
    if (!res.body) {
        return { kind: "ok", text: "" };
    }
    const reader = res.body.getReader();
    const chunks = [];
    let total = 0;
    try {
        for (;;) {
            const { done, value } = await reader.read();
            if (done) {
                break;
            }
            total += value.length;
            if (total > maxBytes) {
                return declaredBytes === null
                    ? { kind: "content_length_missing_stream_exceeded", maxBytes }
                    : {
                        kind: "content_length_understated_stream_exceeded",
                        declaredBytes,
                        maxBytes,
                    };
            }
            chunks.push(value);
        }
    }
    finally {
        // Release the reader lock and cancel any remaining backpressure so a
        // rejected (oversized) body doesn't keep pulling bytes off the wire.
        reader.releaseLock();
        await res.body.cancel().catch(() => undefined);
    }
    const buffer = Buffer.concat(chunks.map((c) => Buffer.from(c.buffer, c.byteOffset, c.byteLength)));
    return { kind: "ok", text: buffer.toString("utf8") };
}
/** Human-readable summary for a rejected outcome, safe to include in a
 *  thrown error message — carries no response body content, only sizes. */
export function describeBoundedReadRejection(outcome) {
    switch (outcome.kind) {
        case "content_length_exceeded":
            return `declared Content-Length ${String(outcome.declaredBytes)} exceeds cap ${String(outcome.maxBytes)}`;
        case "content_length_missing_stream_exceeded":
            return `response body exceeded cap ${String(outcome.maxBytes)} with no Content-Length header`;
        case "content_length_understated_stream_exceeded":
            return `response body exceeded cap ${String(outcome.maxBytes)} (declared Content-Length ${String(outcome.declaredBytes)} understated the real size)`;
        default:
            return "response body exceeded the size cap";
    }
}
