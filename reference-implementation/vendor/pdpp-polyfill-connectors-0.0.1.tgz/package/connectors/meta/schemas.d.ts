import { z } from "zod";
/**
 * profile stream (manifest required: id, username). One record — the user's own
 * profile. `username` is the handle (a short structural token, not prose);
 * `full_name` / `bio` are free-form human text; counts are non-negative ints;
 * `is_verified` is a tri-state boolean (nullable).
 */
export declare const profileSchema: z.ZodObject<{
    id: z.ZodString;
    username: z.ZodString;
    full_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    bio: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    follower_count: z.ZodNullable<z.ZodNumber>;
    following_count: z.ZodNullable<z.ZodNumber>;
    post_count: z.ZodNullable<z.ZodNumber>;
    is_verified: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
/**
 * posts stream (manifest required: id). One record per post on the user's
 * timeline. `caption` is free-form human text; `media_type` is a short
 * structural label (the manifest does not fix the enum, so it is a bounded
 * string — whoever wires extraction should pin it to IMAGE/VIDEO/CAROUSEL_ALBUM
 * once the real values are confirmed); counts are non-negative ints;
 * `location_name` is free-form; `taken_at` is an ISO datetime.
 */
export declare const postsSchema: z.ZodObject<{
    id: z.ZodString;
    caption: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    media_type: z.ZodNullable<z.ZodString>;
    like_count: z.ZodNullable<z.ZodNumber>;
    comment_count: z.ZodNullable<z.ZodNumber>;
    location_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    taken_at: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the streams this
 * connector declares (and will emit once extraction is wired).
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map