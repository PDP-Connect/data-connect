import type { EmittedMessage } from "@pdpp/connector-protocol";
/**
 * A record `emitRecord()` rejected via schema validation — the direct-call
 * counterpart of a real runtime SKIP_RESULT. Drivers that call a connector's
 * exported function directly (Reddit, Amazon, GroupMe, YNAB) use
 * `makeRecordingEmit`, whose `emitRecord` shape-check failures land in its
 * own `.skipped` bookkeeping array, NOT in the `messages`/`emit()` stream —
 * the real runtime would emit an actual SKIP_RESULT protocol message for the
 * same failure, but `makeRecordingEmit` (by design, for ordinary unit tests)
 * never synthesizes one. `runDirectImportDriver` surfaces these
 * automatically so `deriveStreamEnvelope` sees the same "this stream had an
 * unresolved validation failure" fact the runtime's SKIP_RESULT would carry
 * — omitting this silently drops evidence and lets a stream with 100%
 * invalid records still read as `checkpoint_only`/`enumeration_boundary`
 * proven, because the shared oracle never saw the failure.
 */
export interface SkippedRecordFact {
    readonly stream: string;
}
export type DriverResult = {
    exercised: true;
    messages: readonly EmittedMessage[];
    skippedRecords?: readonly SkippedRecordFact[];
} | {
    exercised: false;
    reason: string;
};
export declare const APPLE_CONTACTS_AUTH_FAILURE_DRIVER: ConnectorDriver;
/**
 * Genuinely empty archive (`gmcli chats list` returns zero conversations):
 * proves the `considered === covered === 0` verified-empty shape is
 * reachable through the real subprocess path for a `snapshot_import_receipt`
 * stream, not merely a nonzero run that happens to pass.
 */
export declare const GOOGLE_MESSAGES_EMPTY_DRIVER: ConnectorDriver;
/**
 * gmcli returns messages output missing required fields for the one fetched
 * conversation: the connector's real schema-drift handling emits a genuine
 * `SKIP_RESULT` for the `messages` stream itself (reason `gmcli_query_failed`
 * — see connectors/google_messages/integration.test.ts's "schema drift:
 * malformed messages output" test), proving the mutation-detection path for
 * this strategy runs through real production error handling, not a
 * synthetic envelope.
 */
export declare const GOOGLE_MESSAGES_MALFORMED_DRIVER: ConnectorDriver;
/**
 * gmcli reports the device as unpaired: the connector cannot enumerate any
 * conversation, so it emits a real `SKIP_RESULT` (reason `gmcli_not_paired`)
 * for `messages` — but this connector treats an unpaired device as a soft,
 * user-actionable skip rather than a hard run failure, so DONE still reports
 * `status: "succeeded"` (verified against
 * connectors/google_messages/integration.test.ts's own "not paired" test).
 * This is a second, independent real-production route to `unresolved_attempt`
 * distinct from the schema-drift mutation above — proves the gate reads the
 * SKIP_RESULT itself, not the run's overall success/failure, as what
 * withholds proof for this stream.
 */
export declare const GOOGLE_MESSAGES_NOT_PAIRED_DRIVER: ConnectorDriver;
/** The required-stream driver: all four required GroupMe streams run through
 * the real collector and are judged by the shared conformance oracle. */
export declare const GROUPME_ALL_STREAMS_DRIVER: ConnectorDriver;
/** A non-degenerate empty-direct-inventory fixture. The groups side still
 * completes with one message, so `0/0` on both direct streams is measured
 * absence, not a run that did no work at all. */
export declare const GROUPME_ZERO_DIRECT_INVENTORY_DRIVER: ConnectorDriver;
/** Multi-page, multi-group fixture used by the capability pin below. Its
 * exact total makes dropped pages, duplicated pages, and emitted-count
 * substitution observable at the shared terminal boundary. */
export declare const GROUPME_HIGH_VOLUME_DRIVER: ConnectorDriver;
/** Not registered in `CONNECTOR_DRIVERS`: `attachments` is `required: false`
 *  in groupme.json, so it never appears in `allRequiredStreamPairs()` — its
 *  proof lives entirely in the dedicated capability-pin tests below, the
 *  same pattern `AMAZON_ZERO_RESULT_DRIVER`/`REDDIT_MALFORMED_DRIVER` use for
 *  claims the aggregate gate's required-stream loop cannot itself express. */
export declare const GROUPME_ATTACHMENTS_SHORTFALL_DRIVER: ConnectorDriver;
export declare const GROUPME_ATTACHMENTS_WITHHELD_DRIVER: ConnectorDriver;
export declare const YNAB_ACCOUNT_STATS_ZERO_BUDGETS_DRIVER: ConnectorDriver;
export declare const YNAB_ACCOUNT_STATS_TWO_BUDGETS_ONE_MALFORMED_DRIVER: ConnectorDriver;
export interface ConnectorDriver {
    /** Manifest stream names this driver actually exercises. A driver may
     *  cover a subset of the connector's required streams; the gate reports
     *  the remainder unexercised. */
    coveredStreams: readonly string[];
    run: () => Promise<DriverResult>;
}
export declare const CONNECTOR_DRIVERS: Record<string, ConnectorDriver>;
/**
 * Standalone drivers used only by their respective discriminating tests —
 * not registered in `CONNECTOR_DRIVERS` (the aggregate gate exercises each
 * connector once, via its normal nonzero fixture above).
 */
export declare const AMAZON_ZERO_RESULT_DRIVER: ConnectorDriver;
/**
 * Every one of Reddit's 6 streams sees one considered, schema-invalid
 * record; proves the gate correctly fails these streams (unresolved_attempt)
 * rather than laundering a validation-rejected record into proven coverage.
 */
export declare const REDDIT_MALFORMED_DRIVER: ConnectorDriver;
export declare const KNOWN_UNEXERCISED_COVERAGE: ReadonlySet<string>;
//# sourceMappingURL=coverage-conformance-drivers.d.ts.map