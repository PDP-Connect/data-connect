#!/usr/bin/env node
import type { Page } from "playwright";
import { type CollectContext, type CollectionRateProgress, type NormalizeTerminalError, type RecordData } from "../../src/connector-runtime.ts";
import type { CaptureSession } from "../../src/fixture-capture.ts";
import { ProviderBudgetController, type ProviderBudgetGate } from "../../src/provider-budget.ts";
import { type ConversationDetail } from "./parsers.ts";
import type { ChatGptApi, ChatGptAuth, ChatGptFetchResult, ConversationListItem } from "./types.ts";
export declare const normalizeChatGptTerminalError: NormalizeTerminalError;
/**
 * Resolve the cumulative served-429 count at which the detail lane treats the
 * account as hot and WAITS OUT a bounded cool-down before resuming (deferring the
 * tail as upstream_pressure DETAIL_GAP records only on the bounded-wait fallback).
 * Unset/invalid → the conservative default. An explicit value < 1 disables the
 * density stop (returns Infinity), preserving exhaustion-only behavior.
 */
export declare function resolveChatGptRateLimitDensityStop(env?: NodeJS.ProcessEnv): number;
/**
 * Tiny run-scoped accumulator for served 429s. Pure and lane-agnostic so the
 * stop decision is unit-testable without standing up the adaptive lane: feed it
 * the lane's `rate_limited` cooldown events, ask `shouldStop()` before each
 * launch. `threshold` of Infinity (the disable sentinel) never trips.
 *
 * `initialCount` seeds the accumulator with served 429s the run already absorbed
 * BEFORE the detail lane started — list pagination and the other streams run
 * their fetches OUTSIDE any adaptive lane, so their served 429s never reach the
 * lane's cooldown event. Carrying that pre-detail pressure into the tracker lets
 * the detail phase wait out the account's cool-down sooner on an account the run
 * has already shown to be hot, instead of resetting to zero and grinding up to
 * `threshold` more served 429s before the first wait. Strictly safer: a higher
 * starting count can only ever make the lane pause-to-cool sooner, never launch
 * more requests into a hot account.
 */
export declare class ChatGptRateLimitDensityTracker {
    private rateLimitedCount;
    readonly threshold: number;
    constructor(threshold: number, initialCount?: number);
    /** Record one served 429 (a `rate_limited` cooldown reported by the lane). */
    recordRateLimited(): void;
    get count(): number;
    /** True once cumulative served 429s have reached the stop threshold. */
    shouldStop(): boolean;
    /**
     * Discharge the accumulator after the lane has WAITED OUT the account's
     * cool-down in-run (SLVP-ideal density wait-resume). The wait paid down the
     * hot bucket, so the lane re-earns its way to the next stop from zero — exactly
     * as a fresh run would. Does NOT change the threshold.
     */
    resetAfterWaitOut(): void;
}
/**
 * Resolve the maximum conversation-detail provider requests a single run may
 * admit before deferring the remaining tail as resumable DETAIL_GAP records.
 *
 * **Default: `Infinity` (off).** Unset or any value < 1 returns Infinity — the
 * cap is inactive and the run terminates on work-drained or source pressure.
 * This is an OPT-IN unattended-scheduling envelope, NOT a safety invariant.
 * The single authored safety number is the rate ceiling
 * (PDPP_CHATGPT_PACING_MIN_INTERVAL_MS). A positive integer opts into this
 * envelope. The env var keeps its legacy detail-fetch name because this lane
 * has a one-detail-fetch-to-one-provider-request mapping.
 */
export declare function resolveChatGptMaxDetailFetchesPerRun(env?: NodeJS.ProcessEnv): number;
/**
 * Resolve the maximum wall-clock (ms) the conversation-detail phase may spend
 * before deferring the remaining tail as resumable DETAIL_GAP records.
 *
 * **Default: `Infinity` (off).** Unset or any value <= 0 returns Infinity —
 * the cap is inactive and the run terminates on work-drained or source
 * pressure. This is an OPT-IN unattended-scheduling envelope, NOT a safety
 * invariant. The single authored safety number is the rate ceiling
 * (PDPP_CHATGPT_PACING_MIN_INTERVAL_MS). A positive value opts into this
 * envelope. The budget spans the gap-recovery pass and the forward-walk pass
 * of a single run.
 */
export declare function resolveChatGptMaxRunWallClockMs(env?: NodeJS.ProcessEnv): number;
/**
 * Resolve the maximum number of per-key `DETAIL_GAP` rows a single run may write
 * for the cap-tail deferral before folding the remaining older tail into ONE
 * durable backlog gap (carrying a content-derived `before_update_time`
 * watermark the next run re-lists from). This bounds the *foreground burn* of a
 * cap trip: a huge cold account no longer spends a long run writing thousands of
 * gap rows after it has already stopped fetching details.
 *
 * Resolution:
 * - explicit `PDPP_CHATGPT_MAX_TAIL_DEFERRAL_GAPS_PER_RUN` (positive integer) wins;
 * - unset but a fetch cap is configured → derived `max(fetchCap, 50)` so an owner
 *   who set only a fetch cap still gets a bounded tail;
 * - otherwise (no fetch cap either) → `Infinity`: today's per-key behavior is
 *   byte-for-byte preserved. The bound is inert until an owner opts into a cap.
 */
export declare function resolveChatGptMaxTailDeferralGapsPerRun(env?: NodeJS.ProcessEnv): number;
export declare function resolveChatGptProviderBudget(env?: NodeJS.ProcessEnv, persistedPacing?: {
    intervalMs: number;
    recordedAtMs?: number;
} | number | null): ProviderBudgetController | null;
interface ChatGptPersistedPacing {
    intervalMs: number;
    recordedAtMs: number;
}
/** Read the persisted learned interval from the messages cursor, if present. */
export declare function readChatGptPersistedPacing(state: CollectContext["state"] | undefined): ChatGptPersistedPacing | null;
/**
 * Build the STATE event fields that persist the controller's final learned
 * interval alongside the messages cursor, so the next run warm-starts from it.
 * Returns an empty object when there is nothing to persist (no pacing).
 *
 * SEED-POISONING GUARD: the persisted interval is CAPPED at the cold-start
 * baseline (`initialIntervalMs`). Warm-start exists only to let the next run
 * START FASTER than a cold start by reusing a learned healthy operating rate — it
 * must never make the next run start SLOWER than cold. A run that ended deep in
 * throttle (e.g. a multi-second interval the AIMD backed off to, or a provider
 * Retry-After spike) would otherwise persist that transient backoff as the seed,
 * and the next run would crawl back toward the ceiling from an interval worse than
 * cold-start — the descent compounding across runs we observed live (a 14.3s seed
 * needing ~140 successful fetches just to re-reach the ceiling). Capping at
 * cold-start means a healthy run persists its fast learned interval (faster next
 * start) while a throttled run persists at most the cold-start baseline (a clean
 * cold re-entry, no poisoning). The within-run backoff still protects the live
 * account; only the CROSS-run seed is floored.
 */
export declare function buildChatGptPacingStateFields(providerBudget: ProviderBudgetController | null | undefined, now?: () => number): Record<string, number>;
/**
 * Run-scoped budget for the ChatGPT connector's bounded-run budget. Thin adapter
 * over the shared `RunBudget` that preserves the connector-specific API
 * (`maxFetches`, `recordDetailFetch`, `reason`) for backward compat with
 * existing tests and call sites. New code should use `RunBudget` directly.
 */
export declare class ChatGptRunBudget {
    readonly maxFetches: number;
    readonly maxWallClockMs: number;
    private readonly inner;
    constructor(options?: {
        maxFetches?: number;
        maxWallClockMs?: number;
        now?: () => number;
    });
    /** Record one admitted conversation-detail request against the run budget. */
    recordDetailFetch(): void;
    get count(): number;
    /** Wall-clock spent since the budget was first consulted, in ms. */
    elapsedMs(): number;
    /**
     * Wall-clock budget still available before the time cap trips, in ms
     * (`Infinity` when uncapped). Lets a transient back-off — e.g. waiting out an
     * open upstream-pressure circuit — bound its sleep by the time the run truly
     * has left, so a provider slow-down is never mistaken for budget exhaustion.
     */
    remainingWallClockMs(): number;
    /** Returns the trip reason or null. Anchors clock on first call. */
    reason(): "max_detail_fetches" | "max_wall_clock" | null;
    /** True once any cap has been reached. */
    shouldStop(): boolean;
}
export declare const CHATGPT_RETRYABLE_ERROR_PATTERN: RegExp;
export type ChatGptRunCapReason = "circuit_open" | "max_detail_fetches" | "max_wall_clock" | "provider_retry_budget";
export type ChatGptRetryExhaustedClass = "rate_limited" | "temporary_unavailable" | "upstream_pressure";
export interface ChatGptNetworkPressureDiagnostic {
    attempt?: number;
    endpoint_route: string;
    error_class: string;
    max_attempts?: number;
    method: string;
    retry_after_ms?: number;
    safe_headers?: Record<string, string | number>;
    status?: number;
}
export declare class ChatGptRecoverableRetryExhaustedError extends Error {
    readonly class: ChatGptRetryExhaustedClass;
    readonly httpStatus: number | null;
    readonly networkPressure: ChatGptNetworkPressureDiagnostic | undefined;
    constructor(message: string, details: {
        class: ChatGptRetryExhaustedClass;
        httpStatus?: number | null;
        networkPressure?: ChatGptNetworkPressureDiagnostic;
    });
}
export declare class ChatGptPlannedProviderBudgetDeferredError extends Error {
    readonly gate: (ProviderBudgetGate & {
        ok: false;
    }) | null;
    readonly reason: ChatGptRunCapReason;
    constructor(message: string, reason: ChatGptRunCapReason, gate?: (ProviderBudgetGate & {
        ok: false;
    }) | null);
}
interface ChatGptBackendFetchArgs {
    auth: ChatGptAuth;
    body?: unknown;
    method: string;
    parseJson?: boolean;
    path: string;
    timeoutMs: number;
}
export declare function resolveChatGptBackendFetchTimeoutMs(env?: NodeJS.ProcessEnv): number;
export declare function chatGptBackendFetchInBrowser({ auth, body, method, parseJson, path, timeoutMs, }: ChatGptBackendFetchArgs): Promise<ChatGptFetchResult>;
/**
 * `retryHttp` early-stop predicate implementing the bare-429 source-pressure
 * fast-open. Returns `false` (stop retrying, exhaust now) once a bare 429 —
 * status 429 with no `Retry-After` — has been seen on
 * `CHATGPT_BARE_429_FAST_OPEN_ATTEMPTS` attempts. Every other retryable
 * response (429 + `Retry-After`, 408, 5xx) keeps the full budget.
 *
 * Exported for direct unit testing of the boundary; `retryHttp` owns the
 * exhaustion accounting and error shape.
 */
export declare function shouldKeepRetryingChatGptDetail({ attempt, response, retryAfterMs, }: {
    attempt: number;
    response: {
        status: number;
    };
    retryAfterMs: number | null;
}): boolean;
export declare function consumeChatGptProviderRetryBudget(providerBudget?: ProviderBudgetController | null): ChatGptPlannedProviderBudgetDeferredError | null;
/**
 * Build the operator-legible `collection_rate` progress from the controller's
 * pacing snapshot. PURE; carries no account content — only rate numbers and the
 * last back-off reason (SLVP ideal §5: the controller's state is legible).
 */
export declare function buildChatGptCollectionRateProgress(providerBudget: ProviderBudgetController | null | undefined): CollectionRateProgress | null;
export declare function createChatGptApi({ capture, emit, onUnlanedRateLimited, page, providerBudget, }: {
    capture: CaptureSession | null;
    emit?: CollectContext["emit"];
    onUnlanedRateLimited?: () => void;
    page: Page;
    providerBudget?: ProviderBudgetController | null;
}): ChatGptApi;
interface ChatGptConversationProbeItem {
    create_time: number | null;
    current_node: string | null;
    id: string | null;
    index: number;
    update_time: number | null;
}
interface ChatGptSideEffectProbeResult {
    after1?: ChatGptConversationProbeItem[];
    after2?: ChatGptConversationProbeItem[];
    before?: ChatGptConversationProbeItem[];
    detail?: {
        create_time: number | null;
        current_node: string | null;
        status: number;
        update_time: number | null;
    };
    ok: boolean;
    stage?: string;
    status?: number;
    target_id?: string | null;
}
export declare function summarizeChatGptSideEffectProbe(result: ChatGptSideEffectProbeResult): string;
/** Per-run dependency bag threaded through every emit-path helper. Mirrors
 *  the amazon/chase pattern: one stable bag so collect() becomes pure
 *  orchestration and the helpers are individually testable. */
export interface StreamDeps {
    api: ChatGptApi;
    detailGaps?: CollectContext["detailGaps"];
    emit: CollectContext["emit"];
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    preDetailPressure?: ChatGptPreDetailPressure;
    progress: CollectContext["progress"];
    providerBudget?: ProviderBudgetController | null;
    /**
     * SLVP-ideal §4.3: when true, `runConversationsAndMessagesStreams` MUST run
     * the gap-recovery pass then return before any forward walk / list-phase
     * fetches. Prevents the recovery lane from re-pressuring the source the
     * source-pressure cooldown is protecting (§4.4 mandatory sequencing guard).
     * Threaded from CollectContext.recoveryOnly → collect() → StreamDeps.
     */
    recoveryOnly?: boolean;
    requestDetailGapPage?: CollectContext["requestDetailGapPage"];
    requested: CollectContext["requested"];
    runBudget?: ChatGptRunBudget;
}
/** Mutable holder for the run-scoped pre-detail served-429 count. */
export interface ChatGptPreDetailPressure {
    rateLimited: number;
}
/**
 * Fetch /memories and emit one record per entry.
 *
 * Invariants:
 *   - On http !== 200, emits a SKIP_RESULT and no records, no STATE, no coverage.
 *   - On a 200 whose body fails to parse or has the wrong shape, emits a
 *     `parse_error` SKIP_RESULT — distinct from `http_error` — and no
 *     records, no STATE, no coverage: an unreadable/wrong-shape body is not a
 *     proven-empty list.
 *   - On success, emits records in list order, then a STATE heartbeat and a
 *     DETAIL_COVERAGE. `considered` counts every raw entry the source listed;
 *     `covered` counts only entries actually emitted — a listed entry with no
 *     usable id (`buildMemoryRecord` returns `null`) is neither emitted nor
 *     suppressed-as-unchanged (there is no fingerprint gate here), so it is
 *     NOT counted toward `covered`. This deliberately leaves
 *     `considered > covered` on a run with any rejected entry, so the run
 *     reads `partial` rather than falsely `complete`
 *     (`DetailCoverageParams.covered`'s documented contract) — a bounded
 *     `shape_check_failed` SKIP_RESULT is also emitted per rejected entry so
 *     the drop is diagnosable, not silent.
 */
export declare function runMemoriesStream(deps: StreamDeps): Promise<void>;
/**
 * Fetch /user_system_messages and emit at most one custom_instructions
 * record (there is only one per user). 404/403 → SKIP "not_available";
 * other non-200 → SKIP "http_error".
 *
 * A 200 with an unreadable body (see isUnreadableJsonBody) is NOT a genuine
 * "user cleared their instructions" state: `buildCustomInstructionsRecord`
 * treats `res.json` as `{}` when it's falsy, so a malformed body previously
 * built the exact same all-null-field record a real cleared-instructions
 * account would produce — and that synthetic record would pass the
 * fingerprint gate, advance STATE, and (on a second run) silently prune the
 * prior fingerprint as if the clear were genuinely observed. A `parse_error`
 * SKIP_RESULT now short-circuits before any of that: no record, no
 * fingerprint/STATE advancement. A genuinely empty/cleared body (a real 200
 * whose fields are actually null/absent) still builds and evaluates the
 * record exactly as before — it remains representable and, via the
 * fingerprint gate, distinguishable from a byte-identical no-op re-emit.
 */
export declare function runCustomInstructionsStream(deps: StreamDeps, state?: CollectContext["state"]): Promise<void>;
/**
 * Process a single fetched conversation detail payload: emit the merged
 * conversation record first, then emit messages along the current branch
 * (if the messages stream was requested).
 *
 * Parent-first emit order per Tranche C decision 2026-04-23 — matches the
 * rest of the connector fleet (amazon, chase, usaa, slack, codex). Consumers
 * that upsert conversations + messages see the conversation row before any
 * of its messages.
 *
 * When `detail.status !== 200` or the mapping is missing, emits a
 * `SKIP_RESULT` on the messages stream and falls back to a list-only
 * conversation record (null detail) so the conversation itself still
 * lands downstream.
 */
export declare function processConversationDetail(deps: StreamDeps, c: ConversationListItem, detail: ChatGptFetchResult, emitConversation: (c: ConversationListItem, detail: ConversationDetail | null) => Promise<void>): Promise<void>;
export declare function runCustomGptsStream(deps: StreamDeps): Promise<void>;
export declare function runSharedConversationsStream(deps: StreamDeps, state?: CollectContext["state"]): Promise<void>;
export interface ChatGptDetailLaneTuning {
    initialConcurrency: number;
    maxConcurrency: number;
    pauseMaxMs: number;
    pauseMinMs: number;
}
/**
 * Resolve the conversation-detail lane tuning. With no probe env vars set this
 * returns the frozen production defaults; the OpenSpec concurrency constraint is
 * therefore preserved by default. Invalid values fall back to the default for
 * that knob. `maxConcurrency` is capped at `CHATGPT_DETAIL_PROBE_MAX_CONCURRENCY_CEILING`
 * and clamped to be >= `initialConcurrency`; `pauseMaxMs` is clamped to be >=
 * `pauseMinMs` so the lane's jitter window is always valid.
 */
export declare function resolveChatGptDetailLaneTuning(env?: NodeJS.ProcessEnv): ChatGptDetailLaneTuning;
export interface ChatGptSourcePressureClassification {
    attempted: number;
    classification: "cold" | "pressured";
    rateLimited: number;
}
/**
 * Fire up to `probeCount` SERIAL, content-free detail probes and classify the
 * account, then optionally replay the same ids as one bounded burst canary that
 * matches the requested raised concurrency. Any 429 (or required-detail HTTP
 * failure) marks the account `pressured`; an all-200 sweep marks it `cold`.
 * Stops at the first serial 429 — one rate-limit signal is enough to force the
 * conservative posture, and continuing would add load to an already-pressured
 * bucket.
 *
 * Probes reuse the connector's own `api.fetchStatus` (so they ride the same
 * browser transport, auth, and `retryHttp`/fast-open path the real lane uses).
 * The browser fetch does not parse response JSON; only `status` is inspected.
 */
export declare function classifyChatGptSourcePressure(deps: Pick<StreamDeps, "api">, probeIds: readonly string[], probeCount?: number, burstConcurrency?: number): Promise<ChatGptSourcePressureClassification>;
/**
 * Decide the effective detail-lane tuning for this run. When the requested
 * tuning is the serial production default (maxConcurrency === 1) this is a
 * no-op: it returns the requested tuning without firing any probe, so a normal
 * run is byte-for-byte unchanged. When the owner has opted into a faster A/B
 * posture (maxConcurrency > 1), it runs a content-free serial preflight and
 * forces the run back to serial if the account is pressured.
 */
export declare function applyChatGptColdStatePreflight(deps: StreamDeps, convosToSync: readonly ConversationListItem[], requestedTuning: ChatGptDetailLaneTuning): Promise<ChatGptDetailLaneTuning>;
interface ConversationDetailPacingOptions {
    densityStopThreshold?: number;
    preDetailRateLimited?: number;
    providerBudget?: ProviderBudgetController | null;
    random?: () => number;
    runBudget?: ChatGptRunBudget;
    sleep?: (ms: number) => Promise<void> | void;
    tailGapBound?: number;
    tuning?: ChatGptDetailLaneTuning;
}
interface ConversationDetailCoverage {
    backlogGapKey?: string;
    gapKeys: Array<string | number>;
    hydratedKeys: Array<string | number>;
}
/**
 * Fetch details one-at-a-time. ChatGPT's private detail endpoint appears to
 * throttle per authenticated account/session, and parallel retry loops keep
 * pressure on the same hot bucket. Prefer predictable low pressure over a
 * faster first-run that fails near the end and cannot commit its cursor.
 */
export declare function runMessagesAndConversationsWithDetail(deps: StreamDeps, convosToSync: ConversationListItem[], emitConversation: (c: ConversationListItem, detail: ConversationDetail | null) => Promise<void>, pacing?: ConversationDetailPacingOptions): Promise<ConversationDetailCoverage>;
export declare function runConversationsAndMessagesStreams(deps: StreamDeps, state: CollectContext["state"], options?: {
    detailPacing?: ConversationDetailPacingOptions;
}): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map