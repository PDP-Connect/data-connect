import type { RecordData } from "../../src/connector-runtime.ts";
import type { ChatGptContent, ChatGptMessage, ChatGptNode, ConversationListItem, RawCustomInstructionsBody, RawGizmo, RawMemoryEntry, RawSharedConversation } from "./types.ts";
/**
 * ChatGPT times are unix seconds (number). Some responses use ISO strings.
 * Normalize both to ISO-8601; swallow malformed inputs.
 *
 * A non-positive epoch is a sentinel for "no time", not the instant
 * 1970-01-01 — returning null keeps "unknown" falsifiable downstream instead
 * of sorting a timeless record to the beginning of time.
 */
export declare function tsToIso(v: unknown): string | null;
export interface FlattenedNode {
    node: ChatGptNode;
    nodeId: string;
}
/**
 * Walk the conversation tree from `currentNodeId` up to the root, then
 * reverse so the returned list is ordered root→tip along the current branch.
 */
export declare function flattenTreeCurrentBranch(mapping: Record<string, ChatGptNode>, currentNodeId: string | null | undefined): FlattenedNode[];
/**
 * Extract a string from a ChatGPT message content object. ChatGPT has many
 * content_type shapes; the previous implementation only handled `text` and
 * silently returned null for everything else (67% of records). Each branch
 * returns a string; we return null only if the payload is truly empty.
 *
 * Two safe-landing passes run after extraction so a single pathological
 * message never becomes a terminal shape_check_failed SKIP: control-rich
 * payloads collapse to null (toSafeFullContent), and safe-but-oversized
 * payloads truncate in-band with a recovery marker (toBoundedContent).
 */
export declare function extractContent(content: ChatGptContent | undefined): string | null;
/**
 * Derive tool_calls for a message. ChatGPT does not emit an OpenAI-API-style
 * `tool_calls` array on assistant messages; instead, the model "addresses" a
 * tool via `message.recipient` (e.g. "python", "browser.search", "bio") and
 * the content body carries the call. Synthesize a normalized array.
 */
export declare function extractToolCalls(m: ChatGptMessage | undefined): unknown[];
export declare function extractMessage(nodeId: string, node: ChatGptNode, conversationId: string, onCurrentBranch: boolean): RecordData | null;
export declare function buildMemoryRecord(m: RawMemoryEntry): RecordData | null;
/**
 * /gizmos/mine returns one of several wrapper shapes per item, in priority order:
 *   { resource: { gizmo: {...} } }   (newer)
 *   { gizmo: {...} }                 (rarer)
 *   { info: {...}, list: {...} }     (live shape drift, run_1786417045973 —
 *                                      `list` is listing-only metadata, e.g.
 *                                      is_starred; intentionally not read)
 *   { resource: {...} }              (some tenants)
 *   {...} flat                        (oldest)
 * Picks the first *object-valued* candidate so a malformed/scalar higher-priority
 * field can't mask a valid lower-priority one.
 */
export declare function unwrapGizmo(raw: unknown): RawGizmo | null;
/** Pick `is_public` from the boolean flag or from the string `sharing` enum. */
export declare function resolveGizmoIsPublic(g: RawGizmo): boolean | null;
export declare function buildGizmoRecord(raw: unknown): RecordData | null;
export declare function buildCustomInstructionsRecord(j: RawCustomInstructionsBody | null | undefined): RecordData;
export declare function buildSharedConversationRecord(s: RawSharedConversation): RecordData | null;
export interface ConversationDetail {
    create_time?: number | string | null;
    current_node?: string | null;
    gizmo_id?: string | null;
    is_archived?: boolean | null;
    is_starred?: boolean | null;
    mapping?: Record<string, ChatGptNode> | null;
    title?: string | null;
    update_time?: number | string | null;
    workspace_id?: string | null;
}
/**
 * Count the messages on the conversation's current branch (i.e. excluding
 * off-branch alternatives). Returns null when we have no detail mapping.
 */
export declare function countBranchMessages(mapping: Record<string, ChatGptNode> | null | undefined, currentNode: string | null | undefined): number | null;
/**
 * Merge the list-endpoint and detail-endpoint views into a single conversation
 * record. Fields that only appear on detail (gizmo_id, workspace_id,
 * current_node, message_count_on_current_branch) fall back to list when
 * `detail` is null (conversations-only sync path).
 */
export declare function buildConversationRecord(c: ConversationListItem, detail: ConversationDetail | null): RecordData;
/**
 * Pick the largest ISO update_time across conversations. Used when committing
 * the conversations cursor at the end of a run.
 */
export declare function maxUpdateTimeIso(items: readonly ConversationListItem[]): string | null;
export declare function minUpdateTimeIso(items: readonly ConversationListItem[]): string | null;
//# sourceMappingURL=parsers.d.ts.map