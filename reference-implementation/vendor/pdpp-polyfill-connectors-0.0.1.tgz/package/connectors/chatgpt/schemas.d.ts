import { z } from "zod";
export declare const conversationSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    create_time: z.ZodNullable<z.ZodString>;
    update_time: z.ZodNullable<z.ZodString>;
    is_archived: z.ZodNullable<z.ZodBoolean>;
    is_starred: z.ZodNullable<z.ZodBoolean>;
    workspace_id: z.ZodNullable<z.ZodString>;
    current_node: z.ZodNullable<z.ZodString>;
    message_count_on_current_branch: z.ZodNullable<z.ZodNumber>;
    gizmo_id: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const messageSchema: z.ZodObject<{
    id: z.ZodString;
    conversation_id: z.ZodString;
    parent_id: z.ZodNullable<z.ZodString>;
    children_ids: z.ZodArray<z.ZodString>;
    role: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    model_slug: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    create_time: z.ZodNullable<z.ZodString>;
    finish_reason: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    citations: z.ZodArray<z.ZodUnknown>;
    tool_calls: z.ZodArray<z.ZodUnknown>;
    attachment_ids: z.ZodArray<z.ZodString>;
    on_current_branch: z.ZodBoolean;
}, z.core.$strip>;
export declare const memorySchema: z.ZodObject<{
    id: z.ZodString;
    content: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    created_at: z.ZodNullable<z.ZodString>;
    updated_at: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const customGptSchema: z.ZodObject<{
    id: z.ZodString;
    short_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    display_description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    display_welcome_message: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    instructions: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    tools: z.ZodArray<z.ZodUnknown>;
    created_at: z.ZodNullable<z.ZodString>;
    updated_at: z.ZodNullable<z.ZodString>;
    author_id: z.ZodNullable<z.ZodString>;
    author_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    is_public: z.ZodNullable<z.ZodBoolean>;
    category: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    tags: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
export declare const customInstructionsSchema: z.ZodObject<{
    id: z.ZodString;
    about_user: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    response_style: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    enabled: z.ZodNullable<z.ZodBoolean>;
    updated_at: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const sharedConversationSchema: z.ZodObject<{
    id: z.ZodString;
    conversation_id: z.ZodNullable<z.ZodString>;
    share_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    created_at: z.ZodNullable<z.ZodString>;
    anonymous: z.ZodNullable<z.ZodBoolean>;
    is_public: z.ZodNullable<z.ZodBoolean>;
    highlighted_text: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map