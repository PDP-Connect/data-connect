#!/usr/bin/env node
import { type Stats } from "node:fs";
import { type EnumerationScope } from "../../src/collection-scope-enumeration.ts";
import { type CollectContext, type RecordData, type StreamScope } from "../../src/connector-runtime.ts";
import { type KnownLocalStore } from "../../src/local-source-inventory.ts";
import type { JsonlObject, JsonlObservations, SessionAccumulator } from "./types.ts";
export type { JsonlObservations } from "./types.ts";
export declare const CLAUDE_CODE_KNOWN_LOCAL_STORES: KnownLocalStore[];
/** Running observations from a single JSONL file's lines. The session id
 *  tracks the current line unless a forced id is supplied for subagent files.
 *  Metadata is first-non-null within the file; timestamps widen to cover the
 *  full observed file span. */
export declare function makeJsonlObservations(forcedSessionId: string | null): JsonlObservations;
/**
 * Fold one JSONL object into running observations. Pure, no emit. Top-level
 * agent JSONL files can contain lines for more than one session, so the
 * session id intentionally follows the current line unless a `forcedSessionId`
 * is set. Other metadata fields follow first-non-null semantics; timestamps
 * widen the observed [first, last] range.
 */
export declare function observeJsonlFields(obj: JsonlObject, obs: JsonlObservations, forcedSessionId: string | null): void;
export declare function isMessageType(type: string | undefined): boolean;
export declare function isAttachmentType(type: string | undefined): boolean;
export declare function buildMessageRecord(obj: JsonlObject, sessionId: string, uuid: string): RecordData;
export declare function buildAttachmentRecord(obj: JsonlObject, sessionId: string, uuid: string): RecordData;
/** Injected deps threaded through every per-line emit helper. Mirrors the
 *  codex/gmail pattern: one stable bag so parseJsonlFile becomes pure
 *  orchestration and the helper is individually testable. */
export interface LineEmitDeps {
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    requested: Map<string, StreamScope>;
}
export interface ProcessJsonlLineArgs {
    /**
     * When `true`, update `obs` (including `obs.messageCount`) but do not
     * emit message/attachment records. Used by the parent-first two-pass
     * orchestration: pass 1 builds session accumulators silently, pass 2
     * emits messages/attachments after sessions have landed.
     */
    buildOnly?: boolean;
    deps: LineEmitDeps;
    obj: JsonlObject;
    obs: JsonlObservations;
}
/**
 * Dispatch one JSONL line. The caller is expected to have already folded
 * the object into `obs` via `observeJsonlFields` so `obs.sessionId` is
 * pinned before this runs.
 *
 * Invariants:
 *   - No session id yet (malformed rollout order) → no emits.
 *   - message types ("user", "assistant") → bump `obs.messageCount`
 *     unconditionally, emit only if the `messages` stream is requested.
 *   - attachment types (attachment, file-history-snapshot,
 *     permission-mode, last-prompt) → emit only if the `attachments`
 *     stream is requested.
 *   - Any other type → silent no-op (metadata-only lines like the
 *     `summary` header).
 *   - No uuid → no record (uuid is the emitted record id).
 */
export declare function processJsonlLine({ buildOnly, deps, obj, obs, }: ProcessJsonlLineArgs): Promise<void>;
export interface EmitSessionsFromAccumulatorsArgs {
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    requested: Map<string, StreamScope>;
    sessionAccumulators: Map<string, SessionAccumulator>;
}
/**
 * I/O-free sessions emitter: given a fully-built accumulator map, emit
 * one `sessions` record per accumulator.
 *
 * Invariants:
 *   - Gated by `requested.has("sessions")` — no emit when off.
 *   - One record per session id; accumulator-map order is preserved so
 *     downstream sees sessions in insertion order (per-JS-Map semantics).
 *   - The record is a shallow copy — mutating the accumulator after this
 *     returns must not mutate the emitted record.
 */
export declare function emitSessionsFromAccumulators({ emitRecord, requested, sessionAccumulators, }: EmitSessionsFromAccumulatorsArgs): Promise<void>;
export interface EmitToolResultFileArgs {
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    full: string;
    projectDir: string;
    sessionId: string;
    st: Stats;
    toolResultsDir: string;
}
export declare function emitToolResultFile(args: EmitToolResultFileArgs): Promise<void>;
type SymlinkSkipped = (path: string) => Promise<void>;
type DirectoryReadFailure = (path: string, error: unknown) => Promise<void>;
export interface ScanProjectDirsArgs {
    scope?: EnumerationScope | null;
    onSymlink?: SymlinkSkipped;
    onDirectoryError?: DirectoryReadFailure;
    baseDir: string;
    /** Threaded through to parseJsonlFile/processJsonlLine so pass 1 is
     *  silent (accumulator-only) and pass 2 emits messages/attachments. */
    buildOnly: boolean;
    emit: CollectContext["emit"];
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    fileMtimes: Record<string, number>;
    memoryNoteMtimes?: Record<string, number>;
    /** Mutated in place: total memory-note files examined across all project
     *  dirs, for derived coverage_diagnostics reporting (see emitDerivedCoverage). */
    memoryNotesExamined?: DerivedStreamCounts;
    newMemoryNoteMtimes?: Record<string, number>;
    newMtimes: Record<string, number>;
    requested: Map<string, StreamScope>;
    sessionAccumulators: Map<string, SessionAccumulator>;
    /** Use the established memory/tool-result walkers without re-reading JSONL. */
    skipJsonl?: boolean;
}
export declare function scanProjectDirs(args: ScanProjectDirsArgs): Promise<void>;
interface ClaudeJsonlSource {
    forcedSessionId: string | null;
    path: string;
    projectDir: string;
}
/**
 * Examined/emitted counts for a stream that is parsed out of the same
 * on-disk files as another top-level-scanned stream (`sessions`), so it has
 * no `KnownLocalStore` entry of its own and would otherwise never produce a
 * `coverage_diagnostics` row — see {@link buildDerivedCoverageRecord}.
 */
interface DerivedStreamCounts {
    emitted: number;
    examined: number;
}
/**
 * Enumerate the JSONL sources a run may read, bounded by the owner-declared
 * scope BEFORE any file is opened.
 *
 * The bound applied here is `source_roots` against the project directory, which
 * is exact: a project dir either is a selected root or it is not, so a pruned
 * subtree is never listed and its transcripts are never opened, read, or
 * parsed. That is the difference between a bounded run and a full-corpus scan
 * whose output is filtered afterwards.
 *
 * A `since` is deliberately NOT applied here. Claude Code's project layout does
 * not encode a date in the path, and a transcript's mtime is not a sound upper
 * bound on the timestamps its lines carry, so skipping a file on mtime would
 * risk silently not reading in-range owner data while still reporting the
 * stream as collected. Time bounding for this connector stays at the emission
 * gate, where it is correct; `source_roots` is what bounds the work.
 */
export declare function discoverClaudeJsonlSources(baseDir: string, emit: CollectContext["emit"], scope?: EnumerationScope | null, onDirectoryError?: DirectoryReadFailure, onSymlink?: SymlinkSkipped): Promise<ClaudeJsonlSource[] | null>;
//# sourceMappingURL=index.d.ts.map