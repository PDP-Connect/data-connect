import { z } from "zod";
export declare const sessionsSchema: z.ZodObject<{
    id: z.ZodString;
    project_path: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    cwd: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    git_branch: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    version: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    started_at: z.ZodNullable<z.ZodString>;
    last_event_at: z.ZodNullable<z.ZodString>;
    message_count: z.ZodNullable<z.ZodNumber>;
    user_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    entrypoint: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
export declare const messagesSchema: z.ZodObject<{
    id: z.ZodString;
    session_id: z.ZodString;
    parent_uuid: z.ZodNullable<z.ZodString>;
    role: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    timestamp: z.ZodNullable<z.ZodString>;
    is_sidechain: z.ZodBoolean;
    user_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    agent_id: z.ZodNullable<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
}, z.core.$strip>;
export declare const attachmentsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    session_id: z.ZodString;
    parent_uuid: z.ZodNullable<z.ZodString>;
    event_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    hook_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    tool_use_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content_preview: z.ZodNullable<z.ZodString>;
    content_binary_reason: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    content_bytes: z.ZodNullable<z.ZodNumber>;
    timestamp: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const skillsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    source: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    path: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    frontmatter: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    mtime_epoch: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const memoryNotesSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    project_path: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    note_path: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    path: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    frontmatter: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    mtime_epoch: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const slashCommandsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    path: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    frontmatter: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    mtime_epoch: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const inventorySchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    store: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    relative_path: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    path_hash: z.ZodString;
    type: z.ZodEnum<{
        directory: "directory";
        file: "file";
        missing: "missing";
        other: "other";
    }>;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    mtime_epoch: z.ZodNullable<z.ZodNumber>;
    classification: z.ZodEnum<{
        defer: "defer";
        inventory_only: "inventory_only";
    }>;
    reason: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
export declare const coverageDiagnosticsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    store: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    stream: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodEnum<{
        collected: "collected";
        deferred: "deferred";
        excluded: "excluded";
        inventory_only: "inventory_only";
        missing: "missing";
        unsupported: "unsupported";
    }>;
    reason: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
/** Map stream name → schema. Single source of truth for what streams this
 *  connector produces at shape-check time. */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map