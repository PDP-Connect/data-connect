import type { LocalJsonlPhysicalCursorV1 } from "../../src/local-jsonl-cursor.ts";
export interface JsonlObject {
    agentId?: string | null;
    attachment?: {
        hookName?: string | null;
        toolUseID?: string | null;
        content?: unknown;
        toolUseResult?: unknown;
    };
    cwd?: string;
    entrypoint?: string;
    gitBranch?: string;
    isSidechain?: boolean | null;
    message?: unknown;
    parentUuid?: string | null;
    sessionId?: string;
    timestamp?: string;
    type?: string;
    userType?: string;
    uuid?: string;
    version?: string;
}
export interface ContentPart {
    name?: string;
    text?: string;
    type?: string;
}
export interface SessionAccumulator {
    cwd: string | null;
    entrypoint: string | null;
    git_branch: string | null;
    id: string;
    last_event_at: string | null;
    message_count: number;
    project_path: string;
    started_at: string | null;
    user_type: string | null;
    version: string | null;
}
/** Parser continuation at a physical JSONL cursor boundary. */
export interface JsonlObservations {
    cwd: string | null;
    entrypoint: string | null;
    firstTimestamp: string | null;
    gitBranch: string | null;
    lastTimestamp: string | null;
    messageCount: number;
    sessionId: string | null;
    userType: string | null;
    version: string | null;
}
export interface ClaudeJsonlGap {
    path: string;
    line_number: number;
    byte_offset: number;
    reason: "malformed_jsonl_line" | "non_object_jsonl_record" | "truncated_jsonl_tail";
}
export interface ClaudeChildFileCursorV1 extends LocalJsonlPhysicalCursorV1 {
    jsonl_gaps?: ClaudeJsonlGap[];
    current_session_id: string | null;
}
export interface ClaudeSessionFileCursorV1 extends LocalJsonlPhysicalCursorV1 {
    session_ids?: string[];
    jsonl_gaps?: ClaudeJsonlGap[];
    observation: JsonlObservations;
}
export interface ClaudeSourceGap {
    path: string;
    reason: "source_read_error";
    error_code: string;
}
export interface ClaudeMessagesCursorV1 {
    source_gaps?: Record<string, ClaudeSourceGap>;
    fetched_at: string;
    file_cursors: Record<string, ClaudeChildFileCursorV1>;
    file_mtimes: Record<string, number>;
    local_jsonl_cursor_version: 1;
}
export interface ClaudeSessionsCursorV1 {
    source_gaps?: Record<string, ClaudeSourceGap>;
    session_rebuild_required?: boolean;
    fetched_at: string;
    file_cursors: Record<string, ClaudeSessionFileCursorV1>;
    file_mtimes: Record<string, number>;
    local_jsonl_cursor_version: 1;
    session_aggregates: Record<string, SessionAccumulator>;
}
export interface ClaudeCodeState {
    file_mtimes?: Record<string, number>;
    memory_notes?: {
        file_mtimes?: Record<string, number>;
    };
    messages?: Partial<ClaudeMessagesCursorV1>;
    sessions?: Partial<ClaudeSessionsCursorV1>;
    skills?: {
        file_mtimes?: Record<string, number>;
    };
    slash_commands?: {
        file_mtimes?: Record<string, number>;
    };
    [stream: string]: {
        fingerprints?: Record<string, string>;
        fetched_at?: string;
    } | unknown;
}
export interface ParsedFrontmatter {
    body: string;
    frontmatter: Record<string, string>;
}
//# sourceMappingURL=types.d.ts.map