// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import {
	mkdir,
	mkdtemp,
	readFile,
	rename,
	rm,
	truncate,
	utimes,
	writeFile,
} from "node:fs/promises";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { runCollectorConnector } from "@pdpp/collector-runtime";
import type { EmittedMessage } from "../../src/connector-runtime.ts";
import { resolveExecutionRoot } from "../../src/execution-root.ts";
import { scanLocalJsonl } from "../../src/local-jsonl-cursor.ts";
import { runConnectorProtocolSubprocess } from "../../src/test-harness.ts";

const SESSION_ID = "11111111-1111-4111-8111-111111111111";
const IDS: Record<string, string> = {
	partial: "00000000-0000-4000-8000-000000000005",
	"sub-1": "00000000-0000-4000-8000-000000000002",
	"sub-later": "00000000-0000-4000-8000-000000000007",
	"sub-new": "00000000-0000-4000-8000-000000000006",
	"top-1": "00000000-0000-4000-8000-000000000001",
	"top-2": "00000000-0000-4000-8000-000000000003",
	"top-3": "00000000-0000-4000-8000-000000000004",
};

function transcriptLine(
	id: string,
	timestamp: string,
	extra: Record<string, unknown> = {},
): string {
	return JSON.stringify({
		message: { content: "x" },
		isSidechain: false,
		sessionId: SESSION_ID,
		timestamp: timestamp.replace("Z", ".000Z"),
		type: "user",
		uuid: IDS[id] ?? id,
		...extra,
	});
}

async function makeSource(): Promise<{
	claudeHome: string;
	projects: string;
	top: string;
	subagent: string;
}> {
	const claudeHome = await mkdtemp(join(tmpdir(), "pdpp-claude-incremental-"));
	const projects = join(claudeHome, "projects");
	const project = join(projects, "-tmp-incremental");
	const top = join(project, `${SESSION_ID}.jsonl`);
	const subagent = join(project, SESSION_ID, "subagents", "worker.jsonl");
	await mkdir(join(project, SESSION_ID, "subagents"), { recursive: true });
	await writeFile(
		top,
		`${transcriptLine("top-1", "2026-07-21T00:00:00Z", { padding: "x".repeat(70_000) })}\n`,
	);
	await writeFile(
		subagent,
		`${transcriptLine("sub-1", "2026-07-21T00:01:00Z", { sessionId: "wrong-sidechain" })}\n`,
	);
	return { claudeHome, projects, subagent, top };
}

async function makeAttachmentSource(): Promise<{
	claudeHome: string;
	projects: string;
	subagent: string;
	toolResult: string;
	top: string;
}> {
	const source = await makeSource();
	const toolResults = join(
		source.projects,
		"-tmp-incremental",
		SESSION_ID,
		"tool-results",
	);
	await mkdir(toolResults, { recursive: true });
	const toolResult = join(toolResults, "result-1.txt");
	await writeFile(toolResult, "tool result body\n");
	return { ...source, toolResult };
}

async function run(input: {
	claudeHome: string;
	/** Set when the run is expected to fail, e.g. a malformed complete JSONL
	 * line. Every other caller keeps the default success assertion. */
	expectFailure?: boolean;
	projects: string;
	state?: Record<string, unknown>;
	streams?: string[];
}) {
	const result = await runConnectorProtocolSubprocess({
		allowFailedDone: true,
		cwd: join(import.meta.dirname, "../.."),
		entrypoint: "connectors/claude_code/index.ts",
		env: {
			CLAUDE_CODE_HOME: input.claudeHome,
			CLAUDE_CODE_PROJECTS_DIR: input.projects,
		},
		start: {
			scope: {
				streams: (input.streams ?? ["sessions", "messages"]).map((name) => ({
					name,
				})),
			},
			...(input.state ? { state: input.state } : {}),
			type: "START",
		},
	});
	if (input.expectFailure) {
		assert.equal(result.code, 1, result.stderr);
	} else {
		assert.equal(result.code, 0, result.stderr);
	}
	const states = Object.fromEntries(
		result.messages
			.filter(
				(message): message is Extract<EmittedMessage, { type: "STATE" }> =>
					message.type === "STATE",
			)
			.map((message) => [message.stream, message.cursor]),
	);
	const records = result.messages.filter(
		(message): message is Extract<EmittedMessage, { type: "RECORD" }> =>
			message.type === "RECORD",
	);
	return { code: result.code, messages: result.messages, records, states };
}

async function scanLines(
	path: string,
	prior?: Awaited<ReturnType<typeof scanLocalJsonl>>["cursor"],
) {
	const lines: string[] = [];
	const result = await scanLocalJsonl({
		path,
		prior,
		onLine: (line) => {
			lines.push(line.toString("utf8"));
			return Promise.resolve();
		},
	});
	return { lines, result };
}

test("M1: unchanged rich cursor fast-skips without a transcript replay", async () => {
	const source = await makeSource();
	const first = await run(source);
	const second = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	assert.equal(second.records.length, 0);
});

test("M2: an mtime-only touch verifies the prefix and emits no transcript record", async () => {
	const source = await makeSource();
	const first = await run(source);
	await utimes(
		source.top,
		new Date(Date.now() + 20_000),
		new Date(Date.now() + 20_000),
	);
	const touched = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	assert.equal(touched.records.length, 0);
});

test("M3: a complete append emits only the suffix", async () => {
	const source = await makeSource();
	const first = await run(source);
	await writeFile(
		source.top,
		`${await readFile(source.top, "utf8")}${transcriptLine("top-2", "2026-07-21T00:02:00Z")}\n`,
	);
	const appended = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	assert.deepEqual(
		appended.records
			.filter((record) => record.stream === "messages")
			.map((record) => record.data.id),
		[IDS["top-2"]],
	);
});

test("M4: a committed-prefix mutation beyond 64 KiB rebuilds", async () => {
	const root = await mkdtemp(join(tmpdir(), "pdpp-m4-"));
	const path = join(root, "events.jsonl");
	await writeFile(
		path,
		`${JSON.stringify({ id: "one", padding: "x".repeat(70_000) })}\n`,
	);
	const first = await scanLines(path);
	const bytes = await readFile(path, "utf8");
	await writeFile(path, `${bytes.slice(0, 66_000)}y${bytes.slice(66_001)}`);
	assert.equal(
		(await scanLines(path, first.result.cursor)).result.decision.kind,
		"rebuild",
	);
});

test("M5: a same-size committed-prefix rewrite rebuilds", async () => {
	const root = await mkdtemp(join(tmpdir(), "pdpp-m5-"));
	const path = join(root, "events.jsonl");
	await writeFile(path, '{"id":"one"}\n');
	const first = await scanLines(path);
	await writeFile(path, '{"id":"two"}\n');
	assert.equal(
		(await scanLines(path, first.result.cursor)).result.decision.kind,
		"rebuild",
	);
});

test("M6: replacement with a matching prefix tails only the replacement suffix", async () => {
	const root = await mkdtemp(join(tmpdir(), "pdpp-m6-"));
	const path = join(root, "events.jsonl");
	await writeFile(path, '{"id":"one"}\n');
	const first = await scanLines(path);
	const replacement = `${path}.replacement`;
	await writeFile(replacement, '{"id":"one"}\n{"id":"two"}\n');
	await rename(replacement, path);
	assert.deepEqual((await scanLines(path, first.result.cursor)).lines, [
		'{"id":"two"}',
	]);
});

test("M7: truncation rebuilds from the current source", async () => {
	const root = await mkdtemp(join(tmpdir(), "pdpp-m7-"));
	const path = join(root, "events.jsonl");
	await writeFile(path, '{"id":"one"}\n');
	const first = await scanLines(path);
	await truncate(path, 0);
	await writeFile(path, '{"id":"new"}\n');
	assert.deepEqual((await scanLines(path, first.result.cursor)).lines, [
		'{"id":"new"}',
	]);
});

test("M8: an unterminated line is not committed until its LF arrives", async () => {
	const root = await mkdtemp(join(tmpdir(), "pdpp-m8-"));
	const path = join(root, "events.jsonl");
	await writeFile(path, '{"id":"partial');
	const first = await scanLines(path);
	assert.equal(first.result.cursor.committed_offset_bytes, 0);
	await writeFile(path, '{"id":"partial"}\n');
	assert.deepEqual((await scanLines(path, first.result.cursor)).lines, [
		'{"id":"partial"}',
	]);
});

test("M9: malformed LF-terminated JSON reports a gap and does not advance its physical boundary", async () => {
	const source = await makeSource();
	const first = await run(source);
	await writeFile(
		source.top,
		`${await readFile(source.top, "utf8")}not-json\n`,
	);
	const malformed = await run({
		...source,
		expectFailure: true,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	// A complete malformed line is not an in-flight tail: silently consuming it
	// would lose the record forever. The connector must fail the run, disclose
	// the unresolved streams, and write no cursor past that line.
	assert.equal(malformed.code, 1);
	assert.equal(malformed.records.length, 0);
	assert.equal(
		malformed.messages.filter((message) => message.type === "SKIP_RESULT")
			.length,
		2,
		"sessions and messages both disclose the malformed source gap",
	);
	assert.equal(
		malformed.states.messages,
		undefined,
		"no messages cursor may commit past the malformed line",
	);
	assert.equal(
		malformed.states.sessions,
		undefined,
		"no sessions cursor may commit past the malformed line",
	);
});

test("M10: a tail without sessionId inherits saved parser continuation", async () => {
	const source = await makeSource();
	const first = await run(source);
	await writeFile(
		source.top,
		`${await readFile(source.top, "utf8")}${transcriptLine("top-2", "2026-07-21T00:02:00Z", { sessionId: undefined })}\n`,
	);
	const appended = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	assert.equal(
		appended.records.find((record) => record.stream === "messages")?.data
			.session_id,
		SESSION_ID,
	);
});

test("M11: one changed contributor retains its unchanged contributor in the aggregate", async () => {
	const source = await makeSource();
	const first = await run(source);
	await writeFile(
		source.top,
		`${await readFile(source.top, "utf8")}${transcriptLine("top-2", "2026-07-21T00:02:00Z")}\n`,
	);
	const appended = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	assert.equal(
		appended.records.find((record) => record.stream === "sessions")?.data
			.message_count,
		3,
	);
});

test("M12: rewriting one of two contributors rebuilds the aggregate to the clean full fold", async () => {
	const source = await makeSource();
	const first = await run(source);
	const rewritten = (await readFile(source.top, "utf8")).replace(
		"x".repeat(70_000),
		"y".repeat(70_000),
	);
	await writeFile(source.top, rewritten);
	const incremental = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	const full = await run({ ...source, streams: ["sessions"] });
	assert.deepEqual(
		(
			incremental.states.sessions as {
				session_aggregates: Record<string, unknown>;
			}
		).session_aggregates,
		(full.states.sessions as { session_aggregates: Record<string, unknown> })
			.session_aggregates,
	);
});

test("M13: a new contributor for an existing session folds into the existing aggregate", async () => {
	const source = await makeSource();
	const first = await run(source);
	const later = join(
		source.projects,
		"-tmp-incremental",
		SESSION_ID,
		"subagents",
		"later.jsonl",
	);
	await writeFile(
		later,
		`${transcriptLine("sub-later", "2026-07-21T00:05:00Z")}\n`,
	);
	const changed = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	assert.equal(
		changed.records.find((record) => record.stream === "sessions")?.data
			.message_count,
		3,
	);
});

test("M15: concurrent rewrite plus growth rejects the scan and a retry rebuilds", async () => {
	const root = await mkdtemp(join(tmpdir(), "pdpp-m15-"));
	const path = join(root, "events.jsonl");
	await writeFile(path, '{"id":"one"}\n');
	await assert.rejects(
		scanLocalJsonl({
			path,
			prior: undefined,
			onLine: async () => {
				await writeFile(path, '{"id":"rewritten"}\n{"id":"grown"}\n');
			},
		}),
		/committed prefix changed/,
	);
	assert.deepEqual((await scanLines(path)).lines, [
		'{"id":"rewritten"}',
		'{"id":"grown"}',
	]);
});

test("M17: matching legacy mtimes establish rich state without transcript replay", async () => {
	const source = await makeSource();
	const topMtime = (await (await import("node:fs/promises")).stat(source.top))
		.mtimeMs;
	const subMtime = (
		await (await import("node:fs/promises")).stat(source.subagent)
	).mtimeMs;
	const migrated = await run({
		...source,
		state: {
			messages: {
				file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
			},
			sessions: {
				file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
			},
		},
	});
	assert.equal(migrated.records.length, 0);
	assert.equal(
		(migrated.states.messages as { local_jsonl_cursor_version: number })
			.local_jsonl_cursor_version,
		1,
	);
});

test("M17 live legacy shape: 11,378 mtime entries baseline matching sources while replaying only 58 changed contributors", async () => {
	// Payload-free reproduction of the preserved 11:43 checkpoint: both
	// stream maps have 11,378 mtime entries, no v1/file_cursors, and a small
	// changed subset. The 10,000 stable rows make an accidental all-source
	// migration replay conspicuous without carrying any real transcript data.
	const source = await makeSource();
	const stableRows = Array.from({ length: 10_000 }, (_value, index) =>
		transcriptLine(
			`00000000-0000-4000-8000-${String(index).padStart(12, "0")}`,
			"2026-07-21T00:00:00Z",
		),
	);
	await writeFile(source.top, `${stableRows.join("\n")}\n`);
	const subagentsDir = join(
		source.projects,
		"-tmp-incremental",
		SESSION_ID,
		"subagents",
	);
	const changedSources = await Promise.all(
		Array.from({ length: 58 }, async (_value, index) => {
			const path = join(
				subagentsDir,
				`forensic-changed-${String(index).padStart(2, "0")}.jsonl`,
			);
			await writeFile(
				path,
				`${transcriptLine(`00000000-0000-4000-8000-${String(20_000 + index).padStart(12, "0")}`, "2026-07-21T00:01:00Z")}\n`,
			);
			return path;
		}),
	);
	const sourcePaths = [source.top, source.subagent, ...changedSources];
	const legacyMtimes: Record<string, number> = Object.fromEntries(
		Array.from({ length: 11_378 - sourcePaths.length }, (_value, index) => [
			`/forensic-only/${index}.jsonl`,
			0,
		]),
	);
	legacyMtimes[source.top] = (
		await (await import("node:fs/promises")).stat(source.top)
	).mtimeMs;
	legacyMtimes[source.subagent] = (
		await (await import("node:fs/promises")).stat(source.subagent)
	).mtimeMs;
	for (const path of changedSources) {
		legacyMtimes[path] = 0;
	}
	assert.equal(
		Object.keys(legacyMtimes).length,
		11_378,
		"fixture preserves the forensic legacy map count",
	);

	const migrated = await run({
		...source,
		state: {
			messages: { file_mtimes: legacyMtimes },
			sessions: { file_mtimes: structuredClone(legacyMtimes) },
		},
	});
	assert.equal(
		migrated.records.filter((record) => record.stream === "messages").length,
		58,
		"only mtime-mismatched sources replay; 10,001 matching rows establish cursors without records",
	);
	assert.equal(
		migrated.records.filter((record) => record.stream === "sessions").length,
		1,
	);
	for (const stream of ["messages", "sessions"] as const) {
		const cursor = migrated.states[stream] as {
			file_cursors: Record<string, { committed_offset_bytes: number }>;
			file_mtimes: Record<string, number>;
			local_jsonl_cursor_version: number;
		};
		assert.equal(cursor.local_jsonl_cursor_version, 1, `${stream} writes v1`);
		assert.equal(
			Object.keys(cursor.file_cursors).length,
			60,
			`${stream} cursorizes every current source`,
		);
		assert.equal(
			Object.keys(cursor.file_mtimes).length,
			60,
			`${stream} prunes absent legacy paths`,
		);
		assert.equal(
			cursor.file_cursors[source.top]?.committed_offset_bytes,
			(await (await import("node:fs/promises")).stat(source.top)).size,
		);
	}
	const noOp = await run({
		...source,
		state: {
			messages: migrated.states.messages,
			sessions: migrated.states.sessions,
		},
	});
	assert.equal(
		noOp.records.length,
		0,
		"the v1 checkpoint makes the next run a no-op",
	);
});

test("M18/B: stale messages evidence replays even when sessions evidence is current", async () => {
	const source = await makeSource();
	const topMtime = (await (await import("node:fs/promises")).stat(source.top))
		.mtimeMs;
	const subMtime = (
		await (await import("node:fs/promises")).stat(source.subagent)
	).mtimeMs;
	const replayed = await run({
		...source,
		state: {
			messages: { file_mtimes: { [source.top]: 0, [source.subagent]: 0 } },
			sessions: {
				file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
			},
		},
	});
	assert.equal(
		replayed.records.filter((record) => record.stream === "messages").length,
		2,
	);
});

test("M17/A: sessions-only legacy evidence never baselines messages", async () => {
	const source = await makeSource();
	const topMtime = (await (await import("node:fs/promises")).stat(source.top))
		.mtimeMs;
	const subMtime = (
		await (await import("node:fs/promises")).stat(source.subagent)
	).mtimeMs;
	const migrated = await run({
		...source,
		state: {
			sessions: {
				file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
			},
		},
	});
	assert.equal(
		migrated.records.filter((record) => record.stream === "messages").length,
		2,
		"a missing messages state replays its current sources",
	);
});

test("M17/C: messages-only legacy evidence never baselines sessions", async () => {
	const source = await makeSource();
	const topMtime = (await (await import("node:fs/promises")).stat(source.top))
		.mtimeMs;
	const subMtime = (
		await (await import("node:fs/promises")).stat(source.subagent)
	).mtimeMs;
	const migrated = await run({
		...source,
		state: {
			messages: {
				file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
			},
		},
	});
	assert.equal(
		migrated.records.filter((record) => record.stream === "sessions").length,
		1,
		"a missing sessions state emits its complete current aggregate",
	);
});

test("M16: restarting from the pre-STATE cursor replays a stable logical key", async () => {
	const source = await makeSource();
	const first = await run(source);
	await writeFile(
		source.top,
		`${await readFile(source.top, "utf8")}${transcriptLine("top-2", "2026-07-21T00:02:00Z")}\n`,
	);
	const prior = {
		messages: first.states.messages,
		sessions: first.states.sessions,
	};
	const interruptedAttempt = await run({ ...source, state: prior });
	const restart = await run({ ...source, state: prior });
	assert.deepEqual(
		restart.records
			.filter((record) => record.stream === "messages")
			.map((record) => record.key),
		interruptedAttempt.records
			.filter((record) => record.stream === "messages")
			.map((record) => record.key),
	);
});

test("rich state contains neither transcript content nor child-key ledgers", async () => {
	const source = await makeSource();
	const result = await run(source);
	const state = JSON.stringify({
		messages: result.states.messages,
		sessions: result.states.sessions,
	});
	assert.equal(state.includes("top-1"), false);
	assert.equal(state.includes("sub-1"), false);
	assert.equal(state.includes("x".repeat(70_000)), false);
	assert.equal(state.includes("hmac"), false);
});

test("M21: device-token changes do not alter rich cursor behavior", async () => {
	const source = await makeSource();
	const first = await run(source);
	const saved = process.env.PDPP_LOCAL_DEVICE_TOKEN;
	process.env.PDPP_LOCAL_DEVICE_TOKEN = "rotated-test-token";
	try {
		const second = await run({
			...source,
			state: {
				messages: first.states.messages,
				sessions: first.states.sessions,
			},
		});
		assert.equal(second.records.length, 0);
	} finally {
		if (saved === undefined) {
			delete process.env.PDPP_LOCAL_DEVICE_TOKEN;
		} else {
			process.env.PDPP_LOCAL_DEVICE_TOKEN = saved;
		}
	}
});

test("M22: sessions backfill independently without advancing the child cursor", async () => {
	const source = await makeSource();
	const first = await run(source);
	const sessionOnly = await run({
		...source,
		state: { messages: first.states.messages },
		streams: ["sessions"],
	});
	assert.ok(sessionOnly.states.sessions);
	assert.equal(sessionOnly.states.messages, undefined);
});

test("M23: fixed-seed append, rewrite, truncate, and rotation fold equals a clean full scan", async () => {
	const source = await makeSource();
	const first = await run(source);
	await writeFile(
		source.top,
		`${await readFile(source.top, "utf8")}${transcriptLine("top-2", "2026-07-21T00:02:00Z")}\n`,
	);
	const append = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	await truncate(source.subagent, 0);
	await writeFile(
		source.subagent,
		`${transcriptLine("sub-new", "2026-07-21T00:03:00Z")}\n`,
	);
	const truncated = await run({
		...source,
		state: {
			messages: append.states.messages,
			sessions: append.states.sessions,
		},
	});
	const replacement = `${source.subagent}.replacement`;
	await writeFile(
		replacement,
		`${await readFile(source.subagent, "utf8")}${transcriptLine("sub-later", "2026-07-21T00:04:00Z")}\n`,
	);
	await rename(replacement, source.subagent);
	const incremental = await run({
		...source,
		state: {
			messages: truncated.states.messages,
			sessions: truncated.states.sessions,
		},
	});
	const full = await run({ ...source, streams: ["sessions"] });
	assert.deepEqual(
		(
			incremental.states.sessions as {
				session_aggregates: Record<string, unknown>;
			}
		).session_aggregates,
		(full.states.sessions as { session_aggregates: Record<string, unknown> })
			.session_aggregates,
	);
});

test("incremental touch and append preserve parent-first session aggregation", async () => {
	const source = await makeSource();
	const first = await run(source);
	assert.equal(
		first.records.filter((record) => record.stream === "messages").length,
		2,
	);
	const state = {
		messages: first.states.messages,
		sessions: first.states.sessions,
	};

	const touchedAt = new Date(Date.now() + 20_000);
	await utimes(source.top, touchedAt, touchedAt);
	const touched = await run({ ...source, state });
	assert.equal(
		touched.records.length,
		0,
		"M1/M2: a touch emits no transcript records",
	);

	await writeFile(
		source.top,
		`${await readFile(source.top, "utf8")}${transcriptLine("top-2", "2026-07-21T00:02:00Z", { sessionId: undefined })}\n`,
	);
	const appended = await run({
		...source,
		state: {
			messages: touched.states.messages,
			sessions: touched.states.sessions,
		},
	});
	const messages = appended.records.filter(
		(record) => record.stream === "messages",
	);
	assert.deepEqual(
		messages.map((record) => record.data.id),
		[IDS["top-2"]],
		"M3: only the appended child key emits",
	);
	assert.equal(
		messages[0]?.data.session_id,
		SESSION_ID,
		"M10: tail inherits the prior session id",
	);
	const session = appended.records.find(
		(record) => record.stream === "sessions",
	);
	assert.equal(
		session?.data.message_count,
		3,
		"M11/M13: aggregate keeps unchanged subagent plus top-level tail",
	);
	assert.equal(session?.data.last_event_at, "2026-07-21T00:02:00.000Z");

	const sessionOnly = await run({
		...source,
		state: { messages: appended.states.messages },
		streams: ["sessions"],
	});
	assert.equal(
		sessionOnly.records.filter((record) => record.stream === "sessions").length,
		1,
		"M22: sessions backfill independently",
	);
	assert.ok(sessionOnly.states.sessions);
});

test("source mutations, partial tails, and malformed terminated lines retain physical cursor safety", async () => {
	const source = await makeSource();
	const first = await run(source);
	const state = {
		messages: first.states.messages,
		sessions: first.states.sessions,
	};
	const original = await readFile(source.top, "utf8");
	await writeFile(
		source.top,
		`${original.replace("x", "y")}${transcriptLine("top-2", "2026-07-21T00:02:00Z")}\n`,
	);
	const rewritten = await run({ ...source, state });
	assert.equal(
		rewritten.records.filter((record) => record.stream === "messages").length,
		2,
		"M4/M5: changed prefix rebuilds current file",
	);
	assert.equal(
		rewritten.records.find((record) => record.stream === "sessions")?.data
			.message_count,
		3,
		"M12: rebuilt aggregate is complete",
	);

	await writeFile(
		source.top,
		`${await readFile(source.top, "utf8")}{"sessionId":"${SESSION_ID}","type":"user","uuid":"${IDS.partial}`,
	);
	const partial = await run({
		...source,
		state: {
			messages: rewritten.states.messages,
			sessions: rewritten.states.sessions,
		},
	});
	assert.equal(
		partial.records.length,
		0,
		"M8: unterminated JSONL does not emit",
	);

	// M9: once the pending tail is terminated, a malformed complete line follows
	// it. The malformed line is NOT an in-flight tail, so consuming it would lose
	// that record forever. The run must fail and commit no cursor, which also
	// withholds the now-complete line that precedes it -- a failed run proves
	// nothing rather than proving a subset.
	const beforeMalformed = await readFile(source.top, "utf8");
	await writeFile(
		source.top,
		`${beforeMalformed}","isSidechain":false}\nnot-json\n`,
	);
	const malformedTail = await run({
		...source,
		expectFailure: true,
		state: {
			messages: partial.states.messages,
			sessions: partial.states.sessions,
		},
	});
	assert.equal(
		malformedTail.code,
		1,
		"M9: a malformed complete line fails the run",
	);
	assert.equal(
		malformedTail.records.length,
		0,
		"M9: a failed run emits no records",
	);
	assert.equal(
		malformedTail.states.messages,
		undefined,
		"M9: no messages cursor may commit past the malformed line",
	);

	// M8/M9 recovery: with the malformed line repaired at the source, the
	// previously-completed tail and the following line both emit exactly once.
	await writeFile(
		source.top,
		`${beforeMalformed}","isSidechain":false}\n${transcriptLine("top-3", "2026-07-21T00:03:00Z")}\n`,
	);
	const completed = await run({
		...source,
		state: {
			messages: partial.states.messages,
			sessions: partial.states.sessions,
		},
	});
	assert.deepEqual(
		completed.records
			.filter((record) => record.stream === "messages")
			.map((record) => record.data.id),
		[IDS.partial, IDS["top-3"]],
		"M8/M9: once the source is repaired, completed and following lines advance once",
	);

	await truncate(source.subagent, 0);
	await writeFile(
		source.subagent,
		`${transcriptLine("sub-new", "2026-07-21T00:04:00Z")}\n`,
	);
	const truncated = await run({
		...source,
		state: {
			messages: completed.states.messages,
			sessions: completed.states.sessions,
		},
	});
	assert.ok(
		truncated.records.some(
			(record) =>
				record.stream === "messages" && record.data.id === IDS["sub-new"],
		),
		"M7: truncation rebuilds",
	);
	const replacement = `${source.subagent}.replacement`;
	await writeFile(
		replacement,
		`${await readFile(source.subagent, "utf8")}${transcriptLine("sub-later", "2026-07-21T00:05:00Z")}\n`,
	);
	await rename(replacement, source.subagent);
	const rotated = await run({
		...source,
		state: {
			messages: truncated.states.messages,
			sessions: truncated.states.sessions,
		},
	});
	assert.deepEqual(
		rotated.records
			.filter((record) => record.stream === "messages")
			.map((record) => record.data.id),
		[IDS["sub-later"]],
		"M6: identical prefix replacement tails safely",
	);
});

test("legacy baseline migration writes bounded private rich state", async () => {
	const source = await makeSource();
	const topMtime = (await (await import("node:fs/promises")).stat(source.top))
		.mtimeMs;
	const subMtime = (
		await (await import("node:fs/promises")).stat(source.subagent)
	).mtimeMs;
	const legacyState = {
		messages: {
			file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
		},
		sessions: {
			file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
		},
	};
	const migrated = await run({ ...source, state: legacyState });
	assert.equal(
		migrated.records.length,
		0,
		"M17: matching legacy mtimes baseline without replay",
	);
	const childCursor = migrated.states.messages as {
		file_cursors?: Record<string, unknown>;
		local_jsonl_cursor_version?: number;
	};
	const sessionCursor = migrated.states.sessions as {
		file_cursors?: Record<string, unknown>;
		session_aggregates?: Record<string, unknown>;
	};
	assert.equal(childCursor.local_jsonl_cursor_version, 1);
	assert.equal(Object.keys(childCursor.file_cursors ?? {}).length, 2);
	assert.equal(Object.keys(sessionCursor.session_aggregates ?? {}).length, 1);
	const serialized = JSON.stringify(migrated.states.messages);
	assert.ok(
		!(serialized.includes("top-1") || serialized.includes("sub-1")),
		"M20: child state has no record keys or fingerprints",
	);
});

test("M20: ten thousand child rows retain constant per-file cursor state", async () => {
	const source = await makeSource();
	const rows = Array.from({ length: 10_000 }, (_, index) =>
		transcriptLine(
			`00000000-0000-4000-8000-${String(index).padStart(12, "0")}`,
			"2026-07-21T00:00:00Z",
		),
	);
	await writeFile(source.top, `${rows.join("\n")}\n`);
	const topMtime = (await (await import("node:fs/promises")).stat(source.top))
		.mtimeMs;
	const subMtime = (
		await (await import("node:fs/promises")).stat(source.subagent)
	).mtimeMs;
	const state = {
		messages: {
			file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
		},
		sessions: {
			file_mtimes: { [source.top]: topMtime, [source.subagent]: subMtime },
		},
	};
	const migrated = await run({ ...source, state });
	const child = migrated.states.messages as {
		file_cursors?: Record<string, unknown>;
	};
	assert.equal(Object.keys(child.file_cursors ?? {}).length, 2);
	assert.ok(
		JSON.stringify(child).length < 2000,
		"child STATE is O(files), not O(child records)",
	);
});

test("M19: corrupt rich session cursor rebuilds every contributor instead of doubling its aggregate", async () => {
	const source = await makeSource();
	const first = await run(source);
	const sessions = structuredClone(first.states.sessions) as {
		file_cursors: Record<string, { committed_prefix_sha256: string }>;
	};
	const topCursor = sessions.file_cursors[source.top];
	assert.ok(topCursor);
	topCursor.committed_prefix_sha256 = "not-a-sha256";
	const repaired = await run({
		...source,
		state: { messages: first.states.messages, sessions },
	});
	assert.equal(
		repaired.records.filter((record) => record.stream === "sessions").length,
		0,
		"same fold is not re-emitted",
	);
	assert.equal(
		(
			repaired.states.sessions as {
				session_aggregates: Record<string, { message_count: number }>;
			}
		).session_aggregates[SESSION_ID]?.message_count,
		2,
	);
});

test("partial rich session cursor state rebuilds all current contributors", async () => {
	const source = await makeSource();
	const first = await run(source);
	const sessions = structuredClone(first.states.sessions) as {
		file_cursors: Record<string, unknown>;
	};
	delete sessions.file_cursors[source.subagent];
	const repaired = await run({
		...source,
		state: { messages: first.states.messages, sessions },
	});
	assert.equal(
		(
			repaired.states.sessions as {
				session_aggregates: Record<string, { message_count: number }>;
			}
		).session_aggregates[SESSION_ID]?.message_count,
		2,
	);
});

test("aggregate-only local JSONL telemetry contains counts but no source identifiers", async () => {
	const source = await makeSource();
	const result = await run(source);
	const telemetry = result.messages.find(
		(message) =>
			message.type === "PROGRESS" &&
			message.message.startsWith("Claude Code local_jsonl "),
	);
	assert.ok(telemetry && telemetry.type === "PROGRESS");
	assert.match(
		telemetry.message,
		/fast_skip_files=\d+ verified_noop_files=\d+ append_files=\d+ rebuild_files=\d+ session_rebuild_all=\d+ prefix_bytes_hashed=\d+ tail_bytes_parsed=\d+ transcript_records_emitted=\d+ cursor_state_bytes=\d+/,
	);
	assert.equal(telemetry.message.includes(source.top), false);
	assert.equal(telemetry.message.includes(source.subagent), false);
});

test("M14: removed sources are pruned from rich and dual-written mtime state", async () => {
	const source = await makeSource();
	const first = await run(source);
	await (await import("node:fs/promises")).rm(source.subagent);
	const second = await run({
		...source,
		state: { messages: first.states.messages, sessions: first.states.sessions },
	});
	for (const stream of ["messages", "sessions"] as const) {
		const cursor = second.states[stream] as {
			file_cursors: Record<string, unknown>;
			file_mtimes: Record<string, number>;
		};
		assert.equal(cursor.file_cursors[source.subagent], undefined);
		assert.equal(cursor.file_mtimes[source.subagent], undefined);
		assert.equal(Object.keys(cursor.file_cursors).length, 1);
		assert.equal(Object.keys(cursor.file_mtimes).length, 1);
	}
	assert.equal(
		second.records.find((record) => record.stream === "sessions")?.data
			.message_count,
		1,
	);
});

test("tool-result mtime state skips unchanged attachments and prunes deleted paths in both ownership modes", async () => {
	for (const streams of [
		["sessions", "messages", "attachments"],
		["messages", "attachments"],
	]) {
		const source = await makeAttachmentSource();
		const first = await run({ ...source, streams });
		const state = {
			messages: first.states.messages,
			sessions: first.states.sessions,
		};
		for (const stream of streams.includes("sessions")
			? ["sessions", "messages"]
			: ["messages"]) {
			const cursor = first.states[stream] as {
				file_mtimes: Record<string, number>;
			};
			assert.ok(
				cursor.file_mtimes[source.toolResult] !== undefined,
				`${stream} retains current tool-result mtime`,
			);
		}
		const second = await run({ ...source, state, streams });
		assert.equal(
			second.records.filter((record) => record.stream === "attachments").length,
			0,
			`${streams.join("+")} unchanged attachment is skipped`,
		);
		await rm(source.toolResult);
		const third = await run({
			...source,
			state: {
				messages: second.states.messages,
				sessions: second.states.sessions,
			},
			streams,
		});
		for (const stream of streams.includes("sessions")
			? ["sessions", "messages"]
			: ["messages"]) {
			const cursor = third.states[stream] as {
				file_mtimes: Record<string, number>;
			};
			assert.equal(
				cursor.file_mtimes[source.toolResult],
				undefined,
				`${stream} prunes deleted tool-result path`,
			);
		}
	}
});

test("M24: Claude mtime touch queues no transcript records while advancing its durable checkpoint", async () => {
	const source = await makeSource();
	const topMtime = (await (await import("node:fs/promises")).stat(source.top))
		.mtimeMs;
	// Start the real runner at a pre-v1 checkpoint with one unchanged and one
	// changed contributor. The first pass must stage rich STATE through the
	// normal checkpoint barrier, not merely return it from the connector.
	let persistedState: Record<string, unknown> = {
		messages: { file_mtimes: { [source.top]: topMtime, [source.subagent]: 0 } },
		sessions: { file_mtimes: { [source.top]: topMtime, [source.subagent]: 0 } },
	};
	let statePuts = 0;
	const ingested: Array<{ records?: Array<{ stream?: string }> }> = [];
	const server = createServer(async (request, response) => {
		const chunks: Buffer[] = [];
		for await (const chunk of request) {
			chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
		}
		const body =
			chunks.length === 0
				? null
				: (JSON.parse(Buffer.concat(chunks).toString("utf8")) as Record<
						string,
						unknown
					>);
		if (request.url?.endsWith("/state")) {
			if (request.method === "GET") {
				response.end(JSON.stringify({ state: persistedState }));
			} else {
				persistedState = {
					...persistedState,
					...(body?.state as Record<string, unknown>),
				};
				statePuts += 1;
				response.end(JSON.stringify({ state: persistedState }));
			}
			return;
		}
		if (request.url?.includes("/ingest-batches")) {
			ingested.push(body as { records?: Array<{ stream?: string }> });
			response.end(
				JSON.stringify({
					status: "accepted",
					accepted_record_count: body?.records
						? (body.records as unknown[]).length
						: 0,
				}),
			);
			return;
		}
		response.end(JSON.stringify({ status: "accepted" }));
	});
	await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
	const address = server.address();
	assert.ok(address && typeof address === "object");
	const queuePath = join(source.claudeHome, "runner-outbox.sqlite");
	const config = {
		baseUrl: `http://127.0.0.1:${address.port}`,
		batchSize: 10,
		connector: {
			args: ["connectors/claude_code/index.ts"],
			command: "tsx",
			connector_id: "claude_code",
			env: {
				CLAUDE_CODE_HOME: source.claudeHome,
				CLAUDE_CODE_PROJECTS_DIR: source.projects,
			},
			protocol_capabilities: [],
			runtime_requirements: { bindings: {} },
			streams: ["sessions", "messages"],
		},
		deviceId: "device-test",
		deviceToken: "test-token",
		executionRoot: resolveExecutionRoot({
			args: ["connectors/claude_code/index.ts"],
		}),
		queuePath,
		sourceInstanceId: "claude-mtime-touch",
	} as const;
	try {
		const first = await runCollectorConnector(config);
		assert.ok(first.recordsQueued > 0);
		assert.equal(
			ingested
				.flatMap((batch) => batch.records ?? [])
				.filter((record) => record.stream === "messages").length,
			1,
			"legacy migration queues only the genuinely changed transcript contributor",
		);
		assert.equal(
			(persistedState.messages as { local_jsonl_cursor_version?: number })
				.local_jsonl_cursor_version,
			1,
			"first migration commits the child v1 cursor",
		);
		assert.equal(
			(persistedState.sessions as { local_jsonl_cursor_version?: number })
				.local_jsonl_cursor_version,
			1,
			"first migration commits the session v1 cursor",
		);
		assert.ok(
			statePuts >= 1,
			"first migration crosses the durable checkpoint barrier",
		);
		ingested.length = 0;
		const noOp = await runCollectorConnector(config);
		assert.equal(
			noOp.recordsQueued,
			0,
			"the checkpointed migration is a no-op on the next run",
		);
		assert.equal(ingested.length, 0, "the no-op queues no record batches");
		const beforeTouch = structuredClone(persistedState);
		await utimes(
			source.top,
			new Date(Date.now() + 30_000),
			new Date(Date.now() + 30_000),
		);
		ingested.length = 0;
		const touched = await runCollectorConnector(config);
		assert.equal(touched.recordsQueued, 0);
		assert.equal(
			ingested
				.flatMap((batch) => batch.records ?? [])
				.filter((record) => record.stream === "messages").length,
			0,
			"touch-only Claude pass creates no transcript record_batch entries",
		);
		assert.ok(
			statePuts >= 2,
			"touch-only pass commits its refreshed cursor checkpoint",
		);
		assert.notDeepEqual(persistedState, beforeTouch);
	} finally {
		await new Promise<void>((resolve) => server.close(() => resolve()));
	}
});
