import type { ParsedFrontmatter, SessionAccumulator } from "./types.ts";
export declare const SHORT_PREVIEW_CHARS = 300;
export declare const ATTACHMENT_PREVIEW_CHARS = 500;
export declare const TOOL_RESULT_PREVIEW_CHARS = 500;
export declare const MESSAGE_CONTENT_PREVIEW_CHARS = 5000;
export declare const SKILL_BODY_MAX_CHARS = 20000;
export declare const LINE_PROGRESS_INTERVAL = 2000;
export declare const BYTES_PER_MB: number;
export declare const SESSION_DIR_PREFIX_RE: RegExp;
export declare function textPreview(s: unknown, max?: number): string | null;
export declare function truncateBody(body: string, max?: number): string;
export declare function extractContent(obj: unknown): string | null;
/**
 * Minimal YAML-ish frontmatter parser — no external deps.
 * Supports flat `key: value` pairs and folded multi-line values introduced
 * with `>` or `|`. Returns { frontmatter, body }.
 */
export declare function parseFrontmatter(text: string): ParsedFrontmatter;
export declare function makeEmptySessionAccumulator(id: string, projectPath: string): SessionAccumulator;
interface ObservedFields {
    cwd: string | null;
    entrypoint: string | null;
    gitBranch: string | null;
    userType: string | null;
    version: string | null;
}
export declare function mergeSessionObservations(acc: SessionAccumulator, obs: ObservedFields): void;
export declare function widenSessionTimeRange(acc: SessionAccumulator, firstTimestamp: string | null, lastTimestamp: string | null): void;
export declare function buildSkillRecord(args: {
    name: string;
    frontmatter: Record<string, string>;
    body: string;
    path: string;
    mtimeMs: number;
}): Record<string, unknown>;
export declare function buildMemoryNoteRecord(args: {
    projectDir: string;
    relPath: string;
    frontmatter: Record<string, string>;
    body: string;
    path: string;
    mtimeMs: number;
}): Record<string, unknown>;
export declare function buildSlashCommandRecord(args: {
    idPath: string;
    base: string;
    frontmatter: Record<string, string>;
    body: string;
    path: string;
    mtimeMs: number;
}): Record<string, unknown>;
export declare function applyProjectDirScope(dirs: string[], include: readonly string[], exclude: readonly string[]): string[];
export declare function parseCsvEnv(value: string | undefined): string[];
export {};
//# sourceMappingURL=parsers.d.ts.map