import { z } from "zod";
export declare const cyclesResponseSchema: z.ZodPipe<z.ZodUnion<readonly [z.ZodArray<z.ZodObject<{
    cycle: z.ZodObject<{
        id: z.ZodNumber;
        days: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        scaled_strain: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        day_kilojoules: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        day_avg_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        day_max_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>;
    recovery: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        hrv_rmssd: z.ZodNumber;
        recovery_score: z.ZodNumber;
        created_at: z.ZodString;
        resting_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        spo2: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        skin_temp_celsius: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
    sleeps: z.ZodArray<z.ZodObject<{
        activity_id: z.ZodString;
        during: z.ZodString;
        time_in_bed: z.ZodNumber;
        light_sleep_duration: z.ZodNumber;
        slow_wave_sleep_duration: z.ZodNumber;
        rem_sleep_duration: z.ZodNumber;
        wake_duration: z.ZodNumber;
        respiratory_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        score: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    workouts: z.ZodOptional<z.ZodArray<z.ZodObject<{
        activity_id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        during: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        timezone_offset: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        sport_id: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        kilojoules: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        average_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        max_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
}, z.core.$strip>>, z.ZodObject<{
    records: z.ZodArray<z.ZodObject<{
        cycle: z.ZodObject<{
            id: z.ZodNumber;
            days: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            scaled_strain: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            day_kilojoules: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            day_avg_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            day_max_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        }, z.core.$strip>;
        recovery: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            hrv_rmssd: z.ZodNumber;
            recovery_score: z.ZodNumber;
            created_at: z.ZodString;
            resting_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            spo2: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            skin_temp_celsius: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        }, z.core.$strip>>>;
        sleeps: z.ZodArray<z.ZodObject<{
            activity_id: z.ZodString;
            during: z.ZodString;
            time_in_bed: z.ZodNumber;
            light_sleep_duration: z.ZodNumber;
            slow_wave_sleep_duration: z.ZodNumber;
            rem_sleep_duration: z.ZodNumber;
            wake_duration: z.ZodNumber;
            respiratory_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            score: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        workouts: z.ZodOptional<z.ZodArray<z.ZodObject<{
            activity_id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            during: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            timezone_offset: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            sport_id: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            kilojoules: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            average_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            max_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        }, z.core.$strip>>>;
    }, z.core.$strip>>;
}, z.core.$strip>]>, z.ZodTransform<{
    cycle: {
        id: number;
        days?: string | null | undefined;
        scaled_strain?: number | null | undefined;
        day_kilojoules?: number | null | undefined;
        day_avg_heart_rate?: number | null | undefined;
        day_max_heart_rate?: number | null | undefined;
    };
    recovery?: {
        hrv_rmssd: number;
        recovery_score: number;
        created_at: string;
        resting_heart_rate?: number | null | undefined;
        spo2?: number | null | undefined;
        skin_temp_celsius?: number | null | undefined;
    } | null | undefined;
    sleeps: {
        activity_id: string;
        during: string;
        time_in_bed: number;
        light_sleep_duration: number;
        slow_wave_sleep_duration: number;
        rem_sleep_duration: number;
        wake_duration: number;
        respiratory_rate?: number | null | undefined;
        score?: number | undefined;
    }[];
    workouts?: {
        activity_id?: string | null | undefined;
        during?: string | null | undefined;
        timezone_offset?: string | null | undefined;
        sport_id?: number | null | undefined;
        kilojoules?: number | null | undefined;
        average_heart_rate?: number | null | undefined;
        max_heart_rate?: number | null | undefined;
    }[] | undefined;
}[], {
    cycle: {
        id: number;
        days?: string | null | undefined;
        scaled_strain?: number | null | undefined;
        day_kilojoules?: number | null | undefined;
        day_avg_heart_rate?: number | null | undefined;
        day_max_heart_rate?: number | null | undefined;
    };
    recovery?: {
        hrv_rmssd: number;
        recovery_score: number;
        created_at: string;
        resting_heart_rate?: number | null | undefined;
        spo2?: number | null | undefined;
        skin_temp_celsius?: number | null | undefined;
    } | null | undefined;
    sleeps: {
        activity_id: string;
        during: string;
        time_in_bed: number;
        light_sleep_duration: number;
        slow_wave_sleep_duration: number;
        rem_sleep_duration: number;
        wake_duration: number;
        respiratory_rate?: number | null | undefined;
        score?: number | undefined;
    }[];
    workouts?: {
        activity_id?: string | null | undefined;
        during?: string | null | undefined;
        timezone_offset?: string | null | undefined;
        sport_id?: number | null | undefined;
        kilojoules?: number | null | undefined;
        average_heart_rate?: number | null | undefined;
        max_heart_rate?: number | null | undefined;
    }[] | undefined;
}[] | {
    records: {
        cycle: {
            id: number;
            days?: string | null | undefined;
            scaled_strain?: number | null | undefined;
            day_kilojoules?: number | null | undefined;
            day_avg_heart_rate?: number | null | undefined;
            day_max_heart_rate?: number | null | undefined;
        };
        recovery?: {
            hrv_rmssd: number;
            recovery_score: number;
            created_at: string;
            resting_heart_rate?: number | null | undefined;
            spo2?: number | null | undefined;
            skin_temp_celsius?: number | null | undefined;
        } | null | undefined;
        sleeps: {
            activity_id: string;
            during: string;
            time_in_bed: number;
            light_sleep_duration: number;
            slow_wave_sleep_duration: number;
            rem_sleep_duration: number;
            wake_duration: number;
            respiratory_rate?: number | null | undefined;
            score?: number | undefined;
        }[];
        workouts?: {
            activity_id?: string | null | undefined;
            during?: string | null | undefined;
            timezone_offset?: string | null | undefined;
            sport_id?: number | null | undefined;
            kilojoules?: number | null | undefined;
            average_heart_rate?: number | null | undefined;
            max_heart_rate?: number | null | undefined;
        }[] | undefined;
    }[];
}>>;
export declare const bootstrapResponseSchema: z.ZodObject<{
    account: z.ZodObject<{
        id: z.ZodNumber;
        username: z.ZodString;
        email: z.ZodString;
        type: z.ZodString;
        user_id: z.ZodNumber;
        created_at: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    user: z.ZodObject<{
        id: z.ZodNumber;
        first_name: z.ZodString;
        last_name: z.ZodString;
        country: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        city: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>;
    profile: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        user_id: z.ZodNumber;
        height: z.ZodNullable<z.ZodNumber>;
        weight: z.ZodNullable<z.ZodNumber>;
        gender: z.ZodNullable<z.ZodString>;
        unit_system: z.ZodString;
        birthday: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        timezone_offset: z.ZodString;
        fitness_level: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        created_at: z.ZodOptional<z.ZodString>;
        updated_at: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>>;
    bio_data: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        max_heart_rate: z.ZodNumber;
        min_heart_rate: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        resting_heart_rate: z.ZodNumber;
    }, z.core.$strip>>>;
    membership: z.ZodObject<{
        status: z.ZodString;
        in_effect: z.ZodBoolean;
    }, z.core.$strip>;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map