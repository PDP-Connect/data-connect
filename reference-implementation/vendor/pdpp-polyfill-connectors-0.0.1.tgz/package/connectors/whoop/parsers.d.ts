import type { RecordData } from "../../src/connector-runtime.ts";
import type { WhoopBootstrap, WhoopCycleRecord } from "./types.ts";
export declare function parseCyclesResponse(value: unknown): WhoopCycleRecord[];
export declare function parseBootstrapResponse(value: unknown): WhoopBootstrap;
export declare function rangeStart(value: string | null | undefined): string | null;
export declare function rangeEnd(value: string | null | undefined): string | null;
export declare function profileRecord(source: WhoopBootstrap): RecordData;
export declare function bodyRecord(source: WhoopBootstrap): RecordData;
export declare function cycleRecord(source: WhoopCycleRecord): RecordData;
export declare function recoveryRecord(source: WhoopCycleRecord): RecordData | null;
export declare function sleepRecords(source: WhoopCycleRecord): RecordData[];
export declare function workoutRecords(source: WhoopCycleRecord): RecordData[];
//# sourceMappingURL=parsers.d.ts.map