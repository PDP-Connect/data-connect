#!/usr/bin/env node
import type { Page } from "playwright";
import { manualAction } from "../../src/browser-handoff.ts";
import { type EmittedMessage, type InteractionRequest, type InteractionResponse, type RecordData } from "../../src/connector-runtime.ts";
import type { WhoopBootstrap, WhoopFetchResult } from "./types.ts";
export type WhoopFetch = (path: string) => Promise<WhoopFetchResult>;
interface CollectWhoopArgs {
    emit: (message: EmittedMessage) => Promise<void>;
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    fetchPath: WhoopFetch;
    now: Date;
    requested: ReadonlySet<string>;
    state: Record<string, unknown>;
}
declare function decodeJsonResponse(status: number, text: string): WhoopFetchResult;
export declare function makeWhoopPageFetch(page: Page): WhoopFetch;
export declare function fetchBootstrap(fetchPath: WhoopFetch): Promise<WhoopBootstrap>;
export declare function whoopAllowsInteractiveAuthRepair(env?: NodeJS.ProcessEnv): boolean;
export declare function ensureWhoopSession(args: {
    capture?: Parameters<typeof manualAction>[0]["capture"];
    fetchPath: WhoopFetch;
    interactive: boolean;
    manualLogin?: () => Promise<void>;
    page: Page;
    sendInteraction: (request: InteractionRequest) => Promise<InteractionResponse>;
}): Promise<void>;
export declare function collectWhoop(args: CollectWhoopArgs): Promise<void>;
export declare const parseFetchTextForTest: typeof decodeJsonResponse;
export {};
//# sourceMappingURL=index.d.ts.map