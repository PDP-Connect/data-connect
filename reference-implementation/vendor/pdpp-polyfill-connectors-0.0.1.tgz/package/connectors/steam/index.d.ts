#!/usr/bin/env node
import { type CollectContext, type RecordData } from "../../src/connector-runtime.ts";
import { openFingerprintCursor } from "../../src/fingerprint-cursor.ts";
/**
 * Runtime pattern that gates cross-run retry cooldown in `retryablePattern`
 * (see runConnector below). steam_rate_limited must stay listed here or 429s
 * become terminal instead of retried.
 */
export declare const STEAM_RETRYABLE_PATTERN: RegExp;
export type SteamHttpClassification = {
    kind: "ok";
} | {
    kind: "error";
    message: string;
    status: number;
};
export declare class SteamHttpError extends Error {
    readonly status: number;
    readonly path: string;
    constructor(path: string, status: number, message: string);
}
/**
 * Pure status/body classifier used by steamApiRequest. Kept separate (and
 * exported) so tests exercise the exact production decision instead of a
 * re-implementation that can silently drift from it.
 */
export declare function classifySteamHttpResponse(status: number, _body: string): SteamHttpClassification;
export declare function isSteamId64(value: string): boolean;
export interface SteamSnapshotCoverage {
    considered: number;
    covered: number;
    emitted: number;
}
/**
 * Account for every record in a full Steam snapshot independently of the
 * fingerprint cursor's changed-record emission decision. An unchanged record
 * is still covered because the source returned it and the cursor confirmed
 * that its prior state is identical. Invalid records remain a real coverage
 * shortfall instead of being counted from the raw API length.
 */
export declare function emitSteamSnapshotRecords(stream: string, records: readonly RecordData[], cursor: ReturnType<typeof openFingerprintCursor>, emitRecord: (stream: string, data: RecordData) => Promise<void>): Promise<SteamSnapshotCoverage>;
export declare function resolveRawSteamIdFromCredentials(credentials: Record<string, string | undefined>, env: NodeJS.ProcessEnv): string | undefined;
export declare function steamCollect({ state, requested, credentials, emit, emitRecord, progress, }: Pick<CollectContext, "state" | "requested" | "credentials" | "emit" | "emitRecord" | "progress">): Promise<void>;
//# sourceMappingURL=index.d.ts.map