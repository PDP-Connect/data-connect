import { type SchemaRegistry } from "../../src/schema-registry.ts";
export declare const SCHEMAS: SchemaRegistry;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map