import { z } from "zod";
/**
 * conversations stream (manifest required: id). mutable_state, cursor
 * update_time.
 */
export declare const conversationsSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    create_time: z.ZodNullable<z.ZodString>;
    update_time: z.ZodNullable<z.ZodString>;
    project_id: z.ZodNullable<z.ZodString>;
    model: z.ZodNullable<z.ZodString>;
    message_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * messages stream (manifest required: id, conversation_id). append_only,
 * cursor create_time. `content` is the full message body → pdppSafeText.
 */
export declare const messagesSchema: z.ZodObject<{
    id: z.ZodString;
    conversation_id: z.ZodString;
    role: z.ZodNullable<z.ZodString>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    model: z.ZodNullable<z.ZodString>;
    create_time: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * projects stream (manifest required: id, name). mutable_state, cursor
 * update_time.
 */
export declare const projectsSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    create_time: z.ZodNullable<z.ZodString>;
    update_time: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the streams this
 * connector declares (and will emit once the Claude API extraction is wired).
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map