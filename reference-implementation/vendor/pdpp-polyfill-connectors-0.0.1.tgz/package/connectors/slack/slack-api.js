// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Direct Slack Web API calls for the four streams slackdump's archive mode
 * cannot produce: `stars`, `user_groups`, `reminders`, `dm_read_states`.
 *
 * Every other Slack stream reads from the slackdump SQLite archive (see
 * index.ts); these four call `stars.list`, `usergroups.list`,
 * `reminders.list`, and `conversations.info` directly against
 * `https://slack.com/api/`, authenticated with the SAME session credential
 * the connector already captures for slackdump (`SLACK_TOKEN` xoxc token +
 * `SLACK_COOKIE` the `d` cookie) and the same browser-shaped request
 * posture slackdump uses (derived `d-s` cookie + browser UA) — no new auth
 * modality. See openspec/changes/complete-slack-bundled-connector-coverage
 * for the evidence that these methods are reachable with that credential
 * and are not exposed by slackdump's own CLI.
 */
import { createConnectorHttpGovernor, } from "../../src/connector-http-governor.js";
import { slackApiPacingProfile } from "../../src/provider-profile.js";
const API_BASE = "https://slack.com/api/";
function slackBrowserUserAgent() {
    switch (process.platform) {
        case "darwin":
            return "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";
        case "win32":
            return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";
        default:
            return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";
    }
}
const USER_AGENT = slackBrowserUserAgent();
export const SLACK_API_RETRYABLE_FAILURE_RE = /slack_rate_limited|ECONN|ETIMEDOUT|timeout/i;
/**
 * Typed marker for a durable Slack session-credential rejection — a 401, or
 * an `invalid_auth`/`not_authed`/`token_revoked` API response body. Never
 * transient: retrying the same call with the same rejected credential
 * repeats the same outcome forever. Callers classify with `instanceof`
 * rather than matching on `.message`, so the classification survives a
 * message-copy edit and cannot silently drift out of sync with the actual
 * throw site the way a standalone regex can.
 *
 * `slackApiErrorCode` preserves the specific Slack-reported reason
 * (`invalid_auth` / `not_authed` / `token_revoked`, or `null` for a bare
 * HTTP 401 with no parsed body) as structured data, not string-embedded —
 * a caller that wants the exact reason reads the field, it doesn't re-parse
 * the message.
 */
export class SlackApiAuthError extends Error {
    slackApiErrorCode;
    constructor(slackApiErrorCode, options) {
        super("slack_auth_failed", options);
        this.name = "SlackApiAuthError";
        this.slackApiErrorCode = slackApiErrorCode;
    }
}
// slackdump's `makeCookie` (auth/value.go) treats these as already URL-safe
// for a cookie value (note the literal `%`, so a pre-encoded input is left
// alone); anything else is escaped via `goQueryEscape` before the wire.
const SLACKDUMP_COOKIE_URL_SAFE_RE = /^[-._~%a-zA-Z0-9]*$/;
// Go `net/url.QueryEscape` (encodeQueryComponent mode) unreserved set —
// alphanumerics and `-_.~` only. NOT the same set as JS `encodeURIComponent`:
// space encodes to `+` here (not `%20`), and `!'()*` are escaped here (JS
// leaves them unescaped). See this file's tests for byte-level proof.
const GO_QUERY_UNRESERVED_RE = /^[A-Za-z0-9\-_.~]$/;
/** Exact port of Go's `net/url.QueryEscape` (encodeQueryComponent mode). */
function goQueryEscape(value) {
    let out = "";
    for (const byte of new TextEncoder().encode(value)) {
        const char = String.fromCharCode(byte);
        if (char === " ") {
            out += "+";
        }
        else if (GO_QUERY_UNRESERVED_RE.test(char)) {
            out += char;
        }
        else {
            out += `%${byte.toString(16).toUpperCase().padStart(2, "0")}`;
        }
    }
    return out;
}
/**
 * Percent-encode a `d` cookie value the way slackdump's Go client does
 * before putting it on the wire. An already-URL-safe value (including one
 * with valid `%XX` escapes) is returned unchanged.
 */
export function encodeSlackCookieValue(value) {
    return SLACKDUMP_COOKIE_URL_SAFE_RE.test(value)
        ? value
        : goQueryEscape(value);
}
/**
 * Mirror slackdump's client-token cookie shape.
 *
 * Slackdump's upstream auth provider sends both the `d` cookie and a derived
 * `d-s` cookie for client tokens. The latter is generated from the current
 * Unix timestamp and acts as an expected session freshness marker.
 */
export function buildSlackSessionCookieHeader(cookie, nowSeconds = Math.floor(Date.now() / 1000)) {
    return `d=${encodeSlackCookieValue(cookie)}; d-s=${String(nowSeconds - 10)}`;
}
let httpGovernor = createConnectorHttpGovernor({
    name: "slack",
    maxAttempts: 4,
    profile: slackApiPacingProfile(),
});
/** Reset the module governor to a cold start. Test-only seam. */
export function resetSlackApiGovernor() {
    httpGovernor = createConnectorHttpGovernor({
        name: "slack",
        maxAttempts: 4,
        profile: slackApiPacingProfile(),
    });
}
/**
 * POST a Slack Web API method with `application/x-www-form-urlencoded`
 * params, authenticated as `token` (matches `rusq/slack`'s `postForm` —
 * the same call shape slackdump's own dependency uses for these methods)
 * plus the derived session cookie pair (`d` + `d-s`) and browser UA that
 * Slackdump's auth substrate sends for client tokens.
 */
async function slackApiPost(method, token, cookie, params) {
    const body = new URLSearchParams({ token, ...params });
    let raw;
    try {
        const r = await httpGovernor.request(async () => {
            const res = await fetch(`${API_BASE}${method}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    Cookie: buildSlackSessionCookieHeader(cookie),
                    "User-Agent": USER_AGENT,
                },
                body: body.toString(),
            });
            const retryAfter = res.headers.get("retry-after");
            return {
                body: await res.text().catch(() => ""),
                status: res.status,
                ...(retryAfter === null ? {} : { retryAfter }),
            };
        }, (resp) => ({
            status: resp.status,
            ...(resp.retryAfter === undefined
                ? {}
                : { headers: { "retry-after": resp.retryAfter } }),
            value: resp,
        }));
        raw = r.value;
    }
    catch (error) {
        throw error instanceof Error ? error : new Error(String(error));
    }
    return parseSlackApiResponse(raw);
}
/**
 * GET a Slack Web API method (query-string params), authenticated with
 * `Authorization: Bearer <token>` (matches `rusq/slack`'s `getResource`)
 * plus the derived session cookie pair (`d` + `d-s`) and browser UA.
 */
async function slackApiGet(method, token, cookie, params) {
    const query = new URLSearchParams(params).toString();
    let raw;
    try {
        const r = await httpGovernor.request(async () => {
            const res = await fetch(`${API_BASE}${method}?${query}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    Cookie: buildSlackSessionCookieHeader(cookie),
                    "User-Agent": USER_AGENT,
                },
            });
            const retryAfter = res.headers.get("retry-after");
            return {
                body: await res.text().catch(() => ""),
                status: res.status,
                ...(retryAfter === null ? {} : { retryAfter }),
            };
        }, (resp) => ({
            status: resp.status,
            ...(resp.retryAfter === undefined
                ? {}
                : { headers: { "retry-after": resp.retryAfter } }),
            value: resp,
        }));
        raw = r.value;
    }
    catch (error) {
        throw error instanceof Error ? error : new Error(String(error));
    }
    return parseSlackApiResponse(raw);
}
function parseSlackApiResponse(raw) {
    if (raw.status === 401) {
        throw new SlackApiAuthError(null);
    }
    if (raw.status < 200 || raw.status >= 300) {
        throw new Error(`slack_api_http_${String(raw.status)}: ${raw.body.slice(0, 200)}`);
    }
    let parsed;
    try {
        parsed = JSON.parse(raw.body);
    }
    catch (err) {
        throw new Error(`slack_api_invalid_json: ${raw.body.slice(0, 200)}`, {
            cause: err,
        });
    }
    if (!parsed.ok) {
        if (parsed.error === "invalid_auth" ||
            parsed.error === "not_authed" ||
            parsed.error === "token_revoked") {
            throw new SlackApiAuthError(parsed.error);
        }
        throw new Error(`slack_api_error_${parsed.error ?? "unknown"}`);
    }
    return parsed;
}
// ─── stars.list ──────────────────────────────────────────────────────────
const STARS_PAGE_COUNT = "100";
export async function fetchAllStars(token, cookie) {
    const items = [];
    let cursor;
    do {
        const params = { count: STARS_PAGE_COUNT };
        if (cursor) {
            params.cursor = cursor;
        }
        const resp = await slackApiPost("stars.list", token, cookie, params);
        items.push(...(resp.items ?? []));
        cursor = resp.response_metadata?.next_cursor || undefined;
    } while (cursor);
    return items;
}
// ─── usergroups.list ─────────────────────────────────────────────────────
export async function fetchAllUserGroups(token, cookie) {
    const resp = await slackApiPost("usergroups.list", token, cookie, {
        include_users: "true",
        include_count: "true",
        include_disabled: "true",
    });
    return resp.usergroups ?? [];
}
// ─── reminders.list ──────────────────────────────────────────────────────
export async function fetchAllReminders(token, cookie) {
    const resp = await slackApiPost("reminders.list", token, cookie, {});
    return resp.reminders ?? [];
}
/**
 * One `conversations.info` call per DM/MPIM channel ID. Callers scope
 * `channelIds` to `is_im`/`is_mpim` channels only (see
 * `collectDmReadStates` in index.ts) — this function does not filter by
 * channel type itself, keeping it a pure per-ID fetch.
 */
export async function fetchDmReadStates(token, cookie, channelIds) {
    const out = [];
    for (const channelId of channelIds) {
        const resp = await slackApiGet("conversations.info", token, cookie, {
            channel: channelId,
        });
        const ch = resp.channel;
        out.push({
            channelId,
            lastRead: ch?.last_read ?? null,
            unreadCount: ch?.unread_count ?? null,
            unreadCountDisplay: ch?.unread_count_display ?? null,
        });
    }
    return out;
}
