import type { SlackReminder, SlackStarItem, SlackUserGroup } from "./types.ts";
export declare const SLACK_API_RETRYABLE_FAILURE_RE: RegExp;
/**
 * Typed marker for a durable Slack session-credential rejection — a 401, or
 * an `invalid_auth`/`not_authed`/`token_revoked` API response body. Never
 * transient: retrying the same call with the same rejected credential
 * repeats the same outcome forever. Callers classify with `instanceof`
 * rather than matching on `.message`, so the classification survives a
 * message-copy edit and cannot silently drift out of sync with the actual
 * throw site the way a standalone regex can.
 *
 * `slackApiErrorCode` preserves the specific Slack-reported reason
 * (`invalid_auth` / `not_authed` / `token_revoked`, or `null` for a bare
 * HTTP 401 with no parsed body) as structured data, not string-embedded —
 * a caller that wants the exact reason reads the field, it doesn't re-parse
 * the message.
 */
export declare class SlackApiAuthError extends Error {
    readonly slackApiErrorCode: string | null;
    constructor(slackApiErrorCode: string | null, options?: ErrorOptions);
}
/**
 * Percent-encode a `d` cookie value the way slackdump's Go client does
 * before putting it on the wire. An already-URL-safe value (including one
 * with valid `%XX` escapes) is returned unchanged.
 */
export declare function encodeSlackCookieValue(value: string): string;
/**
 * Mirror slackdump's client-token cookie shape.
 *
 * Slackdump's upstream auth provider sends both the `d` cookie and a derived
 * `d-s` cookie for client tokens. The latter is generated from the current
 * Unix timestamp and acts as an expected session freshness marker.
 */
export declare function buildSlackSessionCookieHeader(cookie: string, nowSeconds?: number): string;
/** Reset the module governor to a cold start. Test-only seam. */
export declare function resetSlackApiGovernor(): void;
export declare function fetchAllStars(token: string, cookie: string): Promise<SlackStarItem[]>;
export declare function fetchAllUserGroups(token: string, cookie: string): Promise<SlackUserGroup[]>;
export declare function fetchAllReminders(token: string, cookie: string): Promise<SlackReminder[]>;
export interface DmReadState {
    channelId: string;
    lastRead: string | null;
    unreadCount: number | null;
    unreadCountDisplay: number | null;
}
/**
 * One `conversations.info` call per DM/MPIM channel ID. Callers scope
 * `channelIds` to `is_im`/`is_mpim` channels only (see
 * `collectDmReadStates` in index.ts) — this function does not filter by
 * channel type itself, keeping it a pure per-ID fetch.
 */
export declare function fetchDmReadStates(token: string, cookie: string, channelIds: readonly string[]): Promise<DmReadState[]>;
//# sourceMappingURL=slack-api.d.ts.map