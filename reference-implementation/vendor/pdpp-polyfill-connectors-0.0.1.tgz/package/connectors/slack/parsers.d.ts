import type { RecordData } from "../../src/connector-runtime.ts";
import type { DmReadState } from "./slack-api.ts";
import type { CanvasRow, ChannelCanvasMeta, ChannelRow, ChannelUserRow, FileRow, MessageRow, SlackDataBlob, SlackReminder, SlackStarItem, SlackUserGroup, TimeRangeLike, UserRow, WorkspaceRow } from "./types.ts";
export declare const WORKSPACE_LIST_ARROW: RegExp;
/**
 * Slackdump stores most of the richness inside a DATA BLOB (full Slack
 * API JSON). node:sqlite returns BLOB as Uint8Array, not Buffer — use
 * TextDecoder. Malformed / missing blobs return an empty object.
 */
export declare function parseBlob(blob: Uint8Array | string | null | undefined): SlackDataBlob;
/** Slack "seconds.micros" string → ISO-8601 string (or null). A zero or
 *  unparseable ts is absence, not 1970 — those feed `sent_at`/`last_read`,
 *  which the manifest declares as the semantic-time source. */
export declare function tsToIso(ts: string | null | undefined): string | null;
/** Epoch seconds → ISO-8601 string (or null). Zero is Slack's "unset", not
 *  1970-01-01 — see tsToIso. */
export declare function epochToIso(sec: number | null | undefined): string | null;
/**
 * slackdump time format is 'YYYY-MM-DDTHH:MM:SS' (no Z, UTC implied).
 * Strip trailing fractional seconds and the trailing Z if present.
 */
export declare function toSlackTime(iso: string | null): string | null;
export declare function buildWorkspaceRecord(r: WorkspaceRow, emittedAt: string): RecordData;
/**
 * Channel entity record: structural and identity fields only.
 * `num_members` (a sampled metric) is projected into `channel_stats` to
 * avoid creating false entity versions when only the membership count changes.
 * See design: split-point-in-time-observation-streams.
 */
export declare function buildChannelRecord(r: ChannelRow): RecordData;
/**
 * Channel stats observation record: sampled metrics keyed by
 * {channel_id}:{YYYY-MM-DD}. One record per channel per calendar day (UTC).
 * Idempotent within a day; accumulates a time series of member counts.
 */
export declare function buildChannelStatsRecord(r: ChannelRow, observedOn: string): RecordData;
export declare function buildChannelMembershipRecord(r: ChannelUserRow, emittedAt: string): RecordData;
export declare function buildUserRecord(r: UserRow): RecordData;
/** Derived shape for the single-pass MESSAGE co-traversal. Mutated fields
 * (sent_at, id) are captured once, reused for reactions + attachments. */
export interface ParsedMessage {
    attachments: Record<string, unknown>[];
    blob: SlackDataBlob;
    channelId: string;
    messageId: string;
    row: MessageRow;
    sentAt: string;
    ts: string;
}
/**
 * Decode a MessageRow + its DATA blob into the normalized fields the
 * per-stream record builders need. `sentAtFallback` is used when the row's
 * ts is unparseable — callers pass `nowIso()` to preserve prior behavior.
 */
export declare function parseMessageRow(r: MessageRow, sentAtFallback: string): ParsedMessage;
export declare function buildMessageRecord(parsed: ParsedMessage): RecordData;
/** Flatten a parsed message's reactions into one record per (emoji, user). */
export declare function buildReactionRecords(parsed: ParsedMessage): RecordData[];
/** Flatten a parsed message's attachments into one record per index. */
export declare function buildMessageAttachmentRecords(parsed: ParsedMessage): RecordData[];
export declare function buildFileRecord(r: FileRow): RecordData;
/**
 * Build channel_id → canvas-meta map from the latest-chunk CHANNEL rows.
 * Used by the canvases stream to surface is_empty / quip_thread_id that
 * sit on the channel record rather than the file record.
 */
export declare function buildChannelCanvasIndex(chanRows: readonly ChannelRow[]): Map<string, ChannelCanvasMeta>;
export declare function buildCanvasRecord(r: CanvasRow, channelCanvasIndex: ReadonlyMap<string, ChannelCanvasMeta>): RecordData;
/**
 * `stars.list` items carry no stable ID of their own — build a composite
 * key from the starred entity's own identifiers so repeated runs produce
 * the same `id` for the same star. Mirrors the manifest's declared
 * `target_id`/`channel_id`/`message_ts`/`file_id` fields.
 */
export declare function buildStarRecord(item: SlackStarItem): RecordData;
export declare function buildUserGroupRecord(g: SlackUserGroup): RecordData;
export declare function buildReminderRecord(r: SlackReminder): RecordData;
/**
 * `conversations.info`'s `last_read` is a Slack "seconds.micros" ts string
 * (same format as message `ts`), not ISO — the manifest declares
 * `last_read`/`last_read_at` as `format: date-time`, so convert via
 * `tsToIso` (mirrors how the `messages` stream derives `sent_at` from `ts`).
 */
export declare function buildDmReadStateRecord(state: DmReadState, emittedAt: string): RecordData;
/**
 * Pick the committed `messages.last_ts` cursor, preserving the prior value
 * if nothing newer was seen this run (otherwise the cursor would go
 * backward on a no-op resume). Slack ts strings compare lexicographically
 * in the same order they compare numerically.
 */
export declare function selectCommittedMaxTs(priorMaxTs: string | null, runMaxTs: string | null): string | null;
export declare function extractMessageTimeRange(timeRange: TimeRangeLike | undefined): {
    timeFrom: string | null;
    timeTo: string | null;
};
//# sourceMappingURL=parsers.d.ts.map