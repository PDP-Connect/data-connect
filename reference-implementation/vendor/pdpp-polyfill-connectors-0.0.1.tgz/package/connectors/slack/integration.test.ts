// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

/**
 * Integration tests for the Slack connector's `collect()` emit path —
 * specifically the unified messages/reactions/message_attachments pass
 * (`emitMessagesPass`) that shares a single co-traversal of the MESSAGE
 * table across three streams.
 *
 * These tests DON'T spawn slackdump. Most construct a fake `MessagesPassDeps`
 * that captures every (stream, data) pair pushed through `emitRecord`, then
 * assert on the observable invariants: per-row
 * emit order (message before reactions before attachments), cross-stream
 * scope gating (disabling one stream doesn't break the other two), null-
 * enrichment fallback (message with no reactions / no attachments still
 * emits a messages row), dedup-is-upstream (same row twice → two emits),
 * emittedAt propagation, and maxMessageTs tracking across rows.
 *
 * Imports directly from ./index.ts — `runConnector({...})` is guarded by
 * `isMainModule(import.meta.url)` so it only fires when index.ts is the
 * process entry point, not when a test imports it.
 *
 * Why bother: parsers.test.ts proves each record *shape* is correct from
 * an individual MessageRow. Integration tests on the emit pass prove the
 * cross-stream invariants consumers observe: "messages, reactions, and
 * attachments share one pass but each has its own scope gate", "a bare
 * message without enrichment still lands". Regressing any of these would
 * be a silent data shape bug parsers.test.ts can't catch.
 *
 * NOTE on workspace/channel ordering (invariant 1 from the task brief):
 * the workspace → channels → messages ordering is owned by
 * `runRequestedStreams` in index.ts. The coverage regression below drives
 * that sqlite-bound orchestrator directly; the remaining emit-order tests
 * cover the narrower "parent-before-child within a single row" seam.
 */

import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { test } from "node:test";
import type { StreamScope } from "../../src/connector-runtime.ts";
import { openFingerprintCursor } from "../../src/fingerprint-cursor.ts";
import {
	type EmittedRecord,
	makeRecordingEmit,
} from "../../src/test-harness.ts";
import {
	buildMessageRowsQuery,
	emitMessagesPass,
	type MessagesPassDeps,
	parseIsoInstantToSlackTs,
	runChannelsStream,
	runRequestedStreams,
	type StreamDeps,
} from "./index.ts";
import type { MessageRow, SlackDataBlob } from "./types.ts";

interface RecordingHarness {
	deps: MessagesPassDeps;
	emitted: EmittedRecord[];
	progressCalls: { extra: { stream?: string } | undefined; message: string }[];
}

/** Build a MessagesPassDeps that records every emitRecord() + progress()
 *  call. `requested` is a Map<stream,StreamScope> — match the runtime
 *  shape exactly so we aren't hiding a coercion. slack does not ship a
 *  validateRecord today, so makeRecordingEmit runs in pass-through
 *  mode; this matches runtime semantics. */
function makeHarness({
	requested = ["messages", "reactions", "message_attachments"],
	emittedAt = "2026-04-22T12:00:00.000Z",
}: {
	emittedAt?: string;
	requested?: readonly string[];
} = {}): RecordingHarness {
	const harness = makeRecordingEmit();
	const progressCalls: {
		extra: { stream?: string } | undefined;
		message: string;
	}[] = [];
	const requestedMap = new Map<string, StreamScope>(
		requested.map((name) => [name, { name }]),
	);
	const deps: MessagesPassDeps = {
		emitRecord: harness.emitRecord,
		emittedAt,
		progress: (message: string, extra?: { stream?: string }): Promise<void> => {
			progressCalls.push({ message, extra });
			return Promise.resolve();
		},
		requested: requestedMap,
	};
	return { deps, emitted: harness.emitted, progressCalls };
}

/** Encode a SlackDataBlob → Uint8Array the same way slackdump's sqlite
 *  archive stores it. parseBlob decodes via TextDecoder. */
function encodeBlob(blob: SlackDataBlob): Uint8Array {
	return new TextEncoder().encode(JSON.stringify(blob));
}

/** Synthetic MessageRow. All fields match slackdump's sqlite column
 *  shape; DATA is a real encoded blob so parseMessageRow / parseBlob
 *  round-trip through the production decoder. */
function makeRow(
	overrides: Partial<MessageRow> = {},
	blob: SlackDataBlob = {},
): MessageRow {
	return {
		CHANNEL_ID: "C0001",
		TS: "1700000000.000100",
		THREAD_TS: null,
		IS_PARENT: null,
		TXT: "hello",
		NUM_FILES: null,
		DATA: encodeBlob(blob),
		...overrides,
	};
}

function makeChannelDb(): DatabaseSync {
	const db = new DatabaseSync(":memory:");
	db.exec(
		"CREATE TABLE CHANNEL (ID TEXT, NAME TEXT, DATA TEXT, CHUNK_ID INTEGER)",
	);
	db.prepare(
		"INSERT INTO CHANNEL (ID, NAME, DATA, CHUNK_ID) VALUES (?, ?, ?, ?)",
	).run(
		"C0001",
		"general",
		JSON.stringify({
			created: 1_700_000_000,
			is_channel: true,
			name: "general",
			name_normalized: "general",
			num_members: 12,
		}),
		1,
	);
	return db;
}

function makeMessageDb(rows: MessageRow[]): DatabaseSync {
	const db = new DatabaseSync(":memory:");
	db.exec(
		"CREATE TABLE MESSAGE (CHANNEL_ID TEXT, TS TEXT, THREAD_TS TEXT, IS_PARENT INTEGER, TXT TEXT, NUM_FILES INTEGER, DATA BLOB, CHUNK_ID INTEGER)",
	);
	const insert = db.prepare(
		"INSERT INTO MESSAGE (CHANNEL_ID, TS, THREAD_TS, IS_PARENT, TXT, NUM_FILES, DATA, CHUNK_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
	);
	for (const row of rows) {
		insert.run(
			row.CHANNEL_ID,
			row.TS,
			row.THREAD_TS,
			row.IS_PARENT,
			row.TXT,
			row.NUM_FILES,
			row.DATA,
			1,
		);
	}
	return db;
}

function makeChannelDeps(requestedStreams: readonly string[]): {
	close: () => void;
	deps: StreamDeps;
	emitted: EmittedRecord[];
	coverage: { stream: string; considered?: number; covered?: number }[];
} {
	const db = makeChannelDb();
	const harness = makeRecordingEmit();
	const coverage: { stream: string; considered?: number; covered?: number }[] =
		[];
	const requested = new Map<string, StreamScope>(
		requestedStreams.map((name) => [name, { name }]),
	);
	return {
		close: () => db.close(),
		deps: {
			db,
			emit: (message) => {
				coverage.push({
					stream: message.stream,
					...(message.considered === undefined
						? {}
						: { considered: message.considered }),
					...(message.covered === undefined
						? {}
						: { covered: message.covered }),
				});
				return Promise.resolve();
			},
			emitRecord: harness.emitRecord,
			emittedAt: "2026-06-03T12:00:00.000Z",
			failedStreams: new Set(),
			fingerprintCursors: new Map([
				["channels", openFingerprintCursor({}, { excludeFromFingerprint: [] })],
			]),
			progress: () => Promise.resolve(),
			requested,
		},
		emitted: harness.emitted,
		coverage,
	};
}

test("runChannelsStream: channel_stats-only scope emits no channels entity records", async () => {
	const { close, deps, emitted } = makeChannelDeps(["channel_stats"]);
	try {
		await runChannelsStream(deps);
	} finally {
		close();
	}

	assert.deepEqual(
		emitted.map((r) => r.stream),
		["channel_stats"],
	);
	assert.equal(emitted[0]?.data.channel_id, "C0001");
	assert.equal(emitted[0]?.data.num_members, 12);
});

test("runChannelsStream: channels-only scope emits no channel_stats observations", async () => {
	const { close, deps, emitted } = makeChannelDeps(["channels"]);
	try {
		await runChannelsStream(deps);
	} finally {
		close();
	}

	assert.deepEqual(
		emitted.map((r) => r.stream),
		["channels"],
	);
	assert.equal(emitted[0]?.data.id, "C0001");
	assert.equal("num_members" in (emitted[0]?.data ?? {}), false);
});

test("runChannelsStream: channel_stats uses the channel enumeration as honest 1/1 coverage", async () => {
	const { close, deps, coverage } = makeChannelDeps(["channel_stats"]);
	try {
		await runChannelsStream(deps);
	} finally {
		close();
	}
	assert.deepEqual(coverage, [
		{ stream: "channel_stats", considered: 1, covered: 1 },
	]);
});

test("runChannelsStream: an empty channel enumeration proves 0/0, not unknown", async () => {
	const { close, deps, coverage } = makeChannelDeps(["channel_stats"]);
	deps.db.exec("DELETE FROM CHANNEL");
	try {
		await runChannelsStream(deps);
	} finally {
		close();
	}
	assert.deepEqual(coverage, [
		{ stream: "channel_stats", considered: 0, covered: 0 },
	]);
});

test("runChannelsStream: archive enumeration failure emits no empty coverage claim", async () => {
	const { close, deps, coverage } = makeChannelDeps(["channel_stats"]);
	deps.db.exec("DROP TABLE CHANNEL");
	try {
		await runChannelsStream(deps);
	} finally {
		close();
	}
	assert.deepEqual(coverage, []);
});

test("runRequestedStreams: archive message enumeration bounds both derived streams", async () => {
	const rows = [
		makeRow(
			{ TS: "1700000000.000100" },
			{
				reactions: [{ name: "tada", users: ["U1", "U2", "U3"] }],
				attachments: [{ fallback: "preview" }, { fallback: "bot card" }],
			},
		),
		makeRow({ TS: "1700000001.000100" }, {}),
	];
	const db = makeMessageDb(rows);
	const harness = makeRecordingEmit();
	const requested = new Map<string, StreamScope>(
		["messages", "reactions", "message_attachments"].map((name) => [
			name,
			{ name },
		]),
	);
	const deps: StreamDeps = {
		db,
		emit: harness.emit,
		emitRecord: harness.emitRecord,
		emittedAt: "2026-06-03T12:00:00.000Z",
		failedStreams: new Set(),
		fingerprintCursors: new Map(),
		progress: () => Promise.resolve(),
		requested,
	};

	let result: Awaited<ReturnType<typeof runRequestedStreams>>;
	try {
		result = await runRequestedStreams(
			deps,
			{},
			{} as Parameters<typeof runRequestedStreams>[2],
			harness.emit,
		);
	} finally {
		db.close();
	}

	// runRequestedStreams itself no longer emits the messages/reactions/
	// message_attachments DETAIL_COVERAGE (see
	// openspec/changes/fix-slack-scoped-archive-coverage-duplication): a
	// scoped-archive fold calls this function once per archive, and emitting
	// here made every call after the first a duplicate (state_stream, stream)
	// pair the runtime rejects. The caller now emits once, after every archive
	// is folded into one merged total. What's still true here, and what this
	// test asserts: the two retained MESSAGE rows are the boundary BOTH
	// derived streams' eventual coverage is measured against, carried on the
	// returned `considered`, not the emitted child-record counts (3 reactions,
	// 2 attachments).
	assert.equal(
		harness.protocolMessages.some(
			(message) => message.type === "DETAIL_COVERAGE",
		),
		false,
	);
	assert.equal(
		result.considered,
		2,
		"considered is the two retained MESSAGE rows, not the child counts",
	);
});

// ─── Invariant 7a: parent-before-child within a single row ───────────────
// (The task brief's workspace → channels → messages ordering lives in
// runRequestedStreams, not this seam. The seam-local parent-before-child
// contract is: within one MessageRow, the `messages` record emits before
// its `reactions` and `message_attachments` children.)

test("emitMessagesPass: messages record for a row emits BEFORE its reactions + attachments", async () => {
	const { deps, emitted } = makeHarness();
	const row = makeRow(
		{},
		{
			reactions: [{ name: "tada", users: ["U1", "U2"] }],
			attachments: [{ fallback: "att-0", title: "Attached" }],
		},
	);
	await emitMessagesPass(deps, [row], null);

	const messagesIdx = emitted.findIndex((r) => r.stream === "messages");
	const firstReactionIdx = emitted.findIndex((r) => r.stream === "reactions");
	const firstAttachmentIdx = emitted.findIndex(
		(r) => r.stream === "message_attachments",
	);
	assert.notEqual(messagesIdx, -1, "expected a messages record");
	assert.notEqual(
		firstReactionIdx,
		-1,
		"expected at least one reactions record",
	);
	assert.notEqual(
		firstAttachmentIdx,
		-1,
		"expected at least one message_attachments record",
	);
	assert.ok(
		messagesIdx < firstReactionIdx,
		"messages record must precede its reactions",
	);
	assert.ok(
		messagesIdx < firstAttachmentIdx,
		"messages record must precede its attachments",
	);
});

// ─── Invariant 7b: cross-stream unified-pass correctness ─────────────────

test("emitMessagesPass: reactions disabled — messages + attachments still flow in the same pass", async () => {
	const { deps, emitted } = makeHarness({
		requested: ["messages", "message_attachments"],
	});
	const row = makeRow(
		{},
		{
			reactions: [{ name: "tada", users: ["U1"] }],
			attachments: [{ fallback: "att-0" }],
		},
	);
	await emitMessagesPass(deps, [row], null);

	assert.equal(
		emitted.filter((r) => r.stream === "messages").length,
		1,
		"messages still emits",
	);
	assert.equal(
		emitted.filter((r) => r.stream === "reactions").length,
		0,
		"reactions suppressed by scope",
	);
	assert.equal(
		emitted.filter((r) => r.stream === "message_attachments").length,
		1,
		"attachments still emits",
	);
});

test("emitMessagesPass: messages disabled — reactions + attachments still flow (sibling streams not dropped)", async () => {
	// This is the unified-pass invariant: a stream's gate is local; when
	// one of the three is off the other two still see every row.
	const { deps, emitted } = makeHarness({
		requested: ["reactions", "message_attachments"],
	});
	const row = makeRow(
		{},
		{
			reactions: [{ name: "heart", users: ["U9"] }],
			attachments: [{ fallback: "att-0" }],
		},
	);
	await emitMessagesPass(deps, [row], null);

	assert.equal(
		emitted.filter((r) => r.stream === "messages").length,
		0,
		"messages suppressed by scope",
	);
	assert.equal(
		emitted.filter((r) => r.stream === "reactions").length,
		1,
		"reactions flow in shared pass",
	);
	assert.equal(
		emitted.filter((r) => r.stream === "message_attachments").length,
		1,
		"attachments flow in shared pass",
	);
});

// ─── Invariant 3: all three streams disabled → nothing emitted ───────────

test("emitMessagesPass: all three streams disabled — no records emit, rows still iterate", async () => {
	// Production caller guards entry on `requested.has("messages" | ...)`,
	// so this is the defense-in-depth contract: if called with none of the
	// three requested, the loop runs silently.
	//
	// The DURABLE cursor must NOT advance here. This assertion previously
	// required the opposite ("ts tracking still advances") on the reasoning
	// that it kept the caller's STATE checkpoint accurate — but a checkpoint
	// over rows that were never emitted is precisely what makes them
	// unreachable on the next run, whose query is `TS > cursor`. Accurate
	// meant "matches what we collected", and we collected nothing.
	// The walked ts stays visible via `iteratedChannelMaxTs`.
	const { deps, emitted } = makeHarness({ requested: ["channels"] });
	const row = makeRow(
		{},
		{
			reactions: [{ name: "fire", users: ["U1"] }],
			attachments: [{ fallback: "x" }],
		},
	);
	const result = await emitMessagesPass(deps, [row], null);
	assert.equal(
		emitted.length,
		0,
		"no records emit when no relevant stream requested",
	);
	assert.equal(
		result.maxMessageTs,
		null,
		"an unemitted row must not raise the durable cursor",
	);
	assert.equal(
		result.iteratedChannelMaxTs[row.CHANNEL_ID],
		"1700000000.000100",
		"the walked ts stays observable for progress reporting",
	);
});

// ─── Invariant 4: null/missing enrichment fallback ───────────────────────

test("emitMessagesPass: message with no reactions + no attachments still emits its messages record", async () => {
	// `reactions` + `attachments` absent from the blob entirely — the
	// record builders should yield [] silently and the core messages row
	// must still land. This is the enrichment-is-additive contract.
	const { deps, emitted } = makeHarness();
	const row = makeRow({}, {}); // bare blob
	await emitMessagesPass(deps, [row], null);

	assert.equal(emitted.filter((r) => r.stream === "messages").length, 1);
	assert.equal(emitted.filter((r) => r.stream === "reactions").length, 0);
	assert.equal(
		emitted.filter((r) => r.stream === "message_attachments").length,
		0,
	);
	const msg = emitted.find((r) => r.stream === "messages");
	assert.ok(msg, "messages record present");
	assert.equal(msg.data.has_attachments, false);
	assert.equal(msg.data.reaction_count, 0);
});

test("emitMessagesPass: message with reactions but no attachments — reactions emit, no attachments", async () => {
	const { deps, emitted } = makeHarness();
	const row = makeRow(
		{},
		{
			reactions: [{ name: "wave", users: ["U1", "U2", "U3"] }],
		},
	);
	await emitMessagesPass(deps, [row], null);

	assert.equal(emitted.filter((r) => r.stream === "messages").length, 1);
	assert.equal(
		emitted.filter((r) => r.stream === "reactions").length,
		3,
		"one reaction record per (emoji, user) pair",
	);
	assert.equal(
		emitted.filter((r) => r.stream === "message_attachments").length,
		0,
	);
});

// ─── Invariant 5: no hidden dedup at this seam ───────────────────────────

test("emitMessagesPass: the same MessageRow passed twice emits twice (dedup is upstream in iterateMessageRows)", async () => {
	// Slackdump can store (CHANNEL_ID, TS) across multiple CHUNK_IDs; the
	// MAX(CHUNK_ID) GROUP BY in iterateMessageRows collapses those. This seam
	// is faithful to its input — a future optimization that caches by
	// message id would land here and change the contract, so pin it.
	const { deps, emitted } = makeHarness();
	const row = makeRow({ TS: "1700000005.000200" }, {});
	await emitMessagesPass(deps, [row, row], null);

	assert.equal(
		emitted.filter((r) => r.stream === "messages").length,
		2,
		"duplicate row processed twice → two emits (no hidden dedup at this layer)",
	);
});

// ─── Invariant 6: timestamps thread through correctly ────────────────────

test("emitMessagesPass: row TS propagates into the messages record's ts + sent_at fields", async () => {
	const { deps, emitted } = makeHarness();
	const row = makeRow({ TS: "1700000000.000100" }, {});
	await emitMessagesPass(deps, [row], null);

	const msg = emitted.find((r) => r.stream === "messages");
	assert.ok(msg);
	assert.equal(
		msg.data.ts,
		"1700000000.000100",
		"row TS pinned into the record's ts field",
	);
	// 1700000000 * 1000 = 1700000000000 → 2023-11-14T22:13:20.000Z
	assert.equal(
		msg.data.sent_at,
		"2023-11-14T22:13:20.000Z",
		"ts → ISO threaded into sent_at",
	);
});

test("emitMessagesPass: returns maxMessageTs — the largest row TS seen across the pass", async () => {
	const { deps } = makeHarness();
	const rows: MessageRow[] = [
		makeRow({ TS: "1700000000.000100" }, {}),
		makeRow({ TS: "1700000200.000050" }, {}), // latest
		makeRow({ TS: "1700000100.999999" }, {}),
	];
	const result = await emitMessagesPass(deps, rows, null);
	assert.equal(
		result.maxMessageTs,
		"1700000200.000050",
		"max ts seen across all rows returned for STATE cursor",
	);
});

// ─── Progress + incremental filtering signal ─────────────────────────────

test("emitMessagesPass: priorTs triggers a progress emit tagged to the messages stream", async () => {
	// The incremental progress signal is part of the observable contract:
	// callers wire it to the STATE cursor display. Pin the shape so a
	// future refactor that drops the extra={stream} tag lands as a failing
	// test.
	const { deps, progressCalls } = makeHarness();
	await emitMessagesPass(deps, [makeRow({}, {})], "1699999999.000000");

	assert.equal(
		progressCalls.length,
		1,
		"one progress emit on incremental runs",
	);
	assert.match(progressCalls[0]?.message ?? "", /incremental.*1699999999/);
	assert.equal(
		progressCalls[0]?.extra?.stream,
		"messages",
		"progress tagged with the messages stream for UI routing",
	);
});

test("emitMessagesPass: priorTs=null — no incremental progress emit (full-run mode)", async () => {
	const { deps, progressCalls } = makeHarness();
	await emitMessagesPass(deps, [makeRow({}, {})], null);
	assert.equal(
		progressCalls.length,
		0,
		"full-run mode doesn't fire the incremental progress signal",
	);
});

// ─── SQL-layer collection_scope.since filtering (buildMessageRowsQuery) ─────

test("buildMessageRowsQuery: since boundary composed with legacy cursor via AND", () => {
	// The since predicate is baked into the SQL WHERE clause via AND with cursor
	// predicates. A row must satisfy BOTH to be included. The since predicate uses
	// numeric comparison on parsed epoch seconds and microseconds to handle
	// variable-width epochs correctly.
	const thresholds = {
		channelLastTs: {},
		legacyLastTs: "1700000000.000000",
		sinceTs: "1700000200.500000", // Slack ts format: seconds.microseconds
	};
	const query = buildMessageRowsQuery(thresholds);
	// The query should include both predicates composed via AND:
	// - m.TS > ? (from legacyLastTs, lexical for cursor)
	// - numeric comparison on CAST(SUBSTR(...)) for sinceTs
	assert.match(query.sql, /m\.TS\s+>\s+/);
	assert.match(query.sql, /CAST.*SUBSTR.*AS INTEGER/); // numeric parsing
	assert.match(query.sql, /AND/);
	// Params should include legacy cursor, then epochSeconds and microseconds for since
	assert.ok(
		query.params.includes("1700000000.000000"),
		"has legacy cursor param",
	);
	assert.ok(
		query.params.includes("1700000200"),
		"has since epochSeconds param",
	);
	assert.ok(query.params.includes("500000"), "has since microseconds param");
});

test("buildMessageRowsQuery: since boundary alone (no cursor)", () => {
	// When no cursor is present, only the numeric since predicate applies.
	const thresholds = {
		channelLastTs: {},
		legacyLastTs: null,
		sinceTs: "1700000200.500000",
	};
	const query = buildMessageRowsQuery(thresholds);
	assert.match(query.sql, /WHERE[\s\S]*CAST[\s\S]*SUBSTR[\s\S]*AS INTEGER/); // numeric comparison
	assert.ok(
		query.params.includes("1700000200"),
		"has since epochSeconds param",
	);
	assert.ok(query.params.includes("500000"), "has since microseconds param");
});

test("buildMessageRowsQuery + SQLite execution: since boundary with cursor (cross-width epochs)", () => {
	// Real SQLite execution test: verify numeric comparison handles variable-width
	// epoch seconds correctly. Lexical comparison fails on cross-width rows:
	//   "978307200.000000" (9 digits, 2001-01-01, pre-9999999999)
	//   "1723248385.500000" (10 digits, 2024-08-09)
	// Lexically: "978..." < "172..." (wrong), but numerically: 978M < 1723M (correct).
	const db = new DatabaseSync(":memory:");
	db.exec(`
    CREATE TABLE MESSAGE (
      CHANNEL_ID TEXT NOT NULL,
      TS TEXT NOT NULL,
      THREAD_TS TEXT,
      IS_PARENT INTEGER,
      TXT TEXT,
      NUM_FILES INTEGER,
      DATA BLOB,
      CHUNK_ID INTEGER NOT NULL
    );
  `);
	// Insert rows covering pre-2001 (9-digit epoch), current (10-digit), and
	// same-second sub-microsecond cases. Insert in scrambled order.
	const rows = [
		{ ts: "1723248385.500000", expected: true }, // 2024-08-09 at boundary (inserted first)
		{ ts: "978307200.123456", expected: false }, // 2001-01-01 pre-2001 9-digit (inserted second)
		{ ts: "1723248385.400000", expected: false }, // same second, before boundary (inserted third)
		{ ts: "978307300.000000", expected: false }, // 2001-01-01 later time, still 9-digit (inserted fourth)
		{ ts: "1723248385.600000", expected: true }, // 2024-08-09 after boundary (inserted fifth)
	];
	rows.forEach((row, idx) => {
		db.prepare(`
      INSERT INTO MESSAGE (CHANNEL_ID, TS, THREAD_TS, IS_PARENT, TXT, NUM_FILES, DATA, CHUNK_ID)
      VALUES (?, ?, NULL, NULL, ?, NULL, NULL, ?)
    `).run("C0001", row.ts, `msg-${idx}`, 1);
	});

	// Build query with no cursor (first run) + numeric since predicate at 2024 time.
	// Boundary is "1723248385.500000" (10-digit epoch). The numeric comparison must
	// include only rows where: epochSeconds > 1723248385 OR
	// (epochSeconds == 1723248385 AND microsecs >= 500000).
	const thresholds = {
		channelLastTs: {},
		legacyLastTs: null, // No cursor: full archive scan
		sinceTs: "1723248385.500000", // Since boundary at .5 seconds in 2024
	};
	const query = buildMessageRowsQuery(thresholds);
	const stmt = db.prepare(query.sql);
	const results = stmt.all(...query.params) as Array<{ TS: string }>;

	// Verify only rows >= boundary are returned, regardless of epoch width.
	// Pre-2001 rows (978...) must be excluded even though they sort before 172...
	// lexically. The numeric predicate must include only rows where:
	//   epochSeconds > 1723248385 OR (epochSeconds == 1723248385 AND microsecs >= 500000)
	const returnedTs = results
		.map((r) => r.TS)
		.sort((a, b) => {
			if (a < b) {
				return -1;
			}
			return a > b ? 1 : 0;
		});
	assert.deepEqual(
		returnedTs,
		["1723248385.500000", "1723248385.600000"],
		"numeric comparison filters correctly across epoch widths: pre-2001 9-digit excluded, current 10-digit at/after included",
	);
});

test("parseIsoInstantToSlackTs: direct tests (exact production function)", () => {
	// Calls the exact production function, not a copy of its logic.
	// Tests: milliseconds, microseconds, no fraction, timezone offset, and errors.

	// ISO with milliseconds (3 decimal places) → pad to 6 digits
	const iso500ms = "2024-08-09T22:26:25.500Z";
	const result500 = parseIsoInstantToSlackTs(iso500ms);
	assert.match(result500, /^\d+\.500000$/, "milliseconds padded to 6 digits");

	// ISO with microseconds (6 decimal places) → no padding needed
	const iso6digits = "2024-08-09T22:26:25.123456Z";
	const result6 = parseIsoInstantToSlackTs(iso6digits);
	assert.match(result6, /^\d+\.123456$/, "microseconds unchanged");

	// ISO without fractional seconds → defaults to .000000
	const isoNoFrac = "2024-08-09T22:26:25Z";
	const resultNoFrac = parseIsoInstantToSlackTs(isoNoFrac);
	assert.match(
		resultNoFrac,
		/^\d+\.000000$/,
		"no fraction defaults to .000000",
	);

	// ISO with timezone offset (not Z) → same parsing
	const isoWithTz = "2024-08-09T22:26:25.250-05:00";
	const resultTz = parseIsoInstantToSlackTs(isoWithTz);
	assert.match(resultTz, /^\d+\.250000$/, "timezone offset handled");

	// Malformed: invalid date string → throws
	assert.throws(
		() => parseIsoInstantToSlackTs("not-a-date"),
		Error,
		"rejects invalid ISO instant",
	);

	// Malformed: empty string → throws (Date.parse returns NaN)
	assert.throws(
		() => parseIsoInstantToSlackTs(""),
		Error,
		"rejects empty string",
	);

	// Pre-epoch (negative epoch seconds) → throws
	const preEpoch = "1969-12-31T23:59:59Z"; // Before Unix epoch
	assert.throws(
		() => parseIsoInstantToSlackTs(preEpoch),
		Error,
		"rejects pre-epoch timestamps",
	);

	// Verify output format is always "seconds.6digits"
	const epoch = "2024-01-01T00:00:00.123Z";
	const result = parseIsoInstantToSlackTs(epoch);
	assert.match(
		result,
		/^\d+\.\d{6}$/,
		"output format is seconds.6-digit-fraction",
	);
});

test("emitMessagesPass: non-monotonic row order with SQL-filtered since boundary", async () => {
	// Rows are already filtered at the SQL layer (WHERE m.TS >= since), so
	// emitMessagesPass must emit all filtered rows regardless of order.
	// If rows arrive out-of-order (not newest-first), emitMessagesPass cannot
	// safely break on the first old ts — it must process every row.
	const { deps, emitted } = makeHarness();
	// Simulate SQL returning rows in non-chronological order (SQLite chose a
	// query plan that sorted differently). All are in-scope (>= 1700000200):
	const rows: MessageRow[] = [
		makeRow({ TS: "1700000300.000000" }, {}), // middle
		makeRow({ TS: "1700000500.000000" }, {}), // latest
		makeRow({ TS: "1700000250.000000" }, {}), // just after boundary
	];
	const result = await emitMessagesPass(deps, rows, null);

	const messages = emitted.filter((r) => r.stream === "messages");
	assert.equal(
		messages.length,
		3,
		"all in-scope rows emitted regardless of arrival order (SQL already filtered)",
	);
	assert.equal(
		result.maxMessageTs,
		"1700000500.000000",
		"maxMessageTs is the true max",
	);
});
