#!/usr/bin/env node
import { DatabaseSync } from "node:sqlite";
import { type CollectContext, type EmittedMessage, type RecordData } from "../../src/connector-runtime.ts";
import { type FingerprintCursor } from "../../src/fingerprint-cursor.ts";
import type { MessageRow, SlackdumpRunResult } from "./types.ts";
export declare function formatSlackdumpMissingError(bin: string): string;
/**
 * Slack's archive normalizer marks a deletion-shaped message with the exact
 * boolean `is_tombstone` field. Do not infer deletion from omission, text,
 * timestamps, or any other subtype: a false positive would delete the
 * owner's retained message. The stream guard also prevents this message
 * marker from affecting derived Slack streams.
 */
export declare function isSlackMessageTombstone(stream: string, data: RecordData): boolean;
/**
 * Channels present in the archive's inventory whose message history
 * slackdump never proved it finished walking.
 *
 * Deliberately a SET difference over channel ids, not a count comparison.
 * A count cannot distinguish "we are short N channels" from "we hold N
 * extra" from "N are duplicated", and — critically for a preservation
 * product — a channel we hold history for that Slack has since archived or
 * deleted must NOT read as loss. This asks only the one-directional
 * question: which channels does the SOURCE list that we cannot prove we
 * finished? Channels we hold but Slack no longer lists never appear here.
 */
export declare function unprovenChannelIds(inventory: ReadonlySet<string>, finalized: ReadonlySet<string>): string[];
/** Per-channel membership facts needed to classify an unproven channel. */
export interface ChannelReachability {
    isArchived: boolean;
    isMember: boolean;
}
/**
 * Does `-member-only` cause slackdump to skip this channel?
 *
 * Mirrors slackdump's own filter exactly. In v4.4.2
 * (`internal/chunk/control/processors.go`):
 *
 *     if c.memberOnly && !structures.IsMember(&ch) { continue }
 *
 * and `structures.IsMember` (`internal/structures/conversation.go`):
 *
 *     if ChannelType(*ch) != CPublic || (ch.ID != "" && ch.ID[0] != 'C') {
 *         return true    // member of any non-public channel by assumption
 *     }
 *     return ch.IsMember
 *
 * Two facts follow, and both were previously stated backwards in this file:
 *
 *   1. The filter reads ONLY `is_member`. `is_archived` is never consulted,
 *      here or anywhere else in slackdump. Archiving a channel does not
 *      remove the account's membership, so an archived channel the account
 *      belongs to IS walked under `-member-only` — verified on this owner's
 *      own Aug-17 archive, where all 15 archived channels were members and
 *      all 15 finished with 16,173 messages collected.
 *   2. Only `C`-prefixed public channels can ever be skipped. DMs, MPIMs and
 *      private channels are unconditionally in scope.
 *
 * So `-member-only` excludes exactly: public channels the account has left or
 * never joined. That is the real axis, and it is orthogonal to archived.
 */
export declare function memberOnlySkipsChannel(id: string, facts: ChannelReachability): boolean;
/**
 * Split unproven channels by whether this run could ever have walked them.
 *
 * `outOfScope` — the run's own configuration guaranteed slackdump would never
 * request this channel's history, so a re-run changes nothing. Under
 * `-member-only` that is precisely the public channels the account is not a
 * member of (see `memberOnlySkipsChannel`). With member-only OFF, nothing is
 * out of scope: slackdump requests every channel Slack enumerates, archived
 * included.
 *
 * `inScope` — slackdump was allowed to walk it and still did not finish. This
 * is the only genuinely unexplained bucket, and the only one a re-archive can
 * close.
 *
 * Being ARCHIVED is deliberately NOT a reason to call a channel out of scope.
 * Slack's `conversations.list` includes archived channels by default
 * (`exclude_archived` defaults to false and slackdump never sets it), so an
 * archived channel that went unwalked is a real gap that must be reported as
 * one. Treating archived as "explained" is what buried this owner's 95
 * archived channels behind a message telling him they were absent by design.
 *
 * A channel missing from `reachability` is treated as IN scope: absent
 * evidence must never silently downgrade a gap into "explained".
 */
export declare function partitionUnprovenChannels(unproven: readonly string[], reachability: ReadonlyMap<string, ChannelReachability>, memberOnly: boolean): {
    inScope: string[];
    outOfScope: string[];
};
interface SlackdumpProgressSnapshot {
    archiveBytes: number;
    archiveMtimeMs: number;
}
export declare function readSlackdumpProgressSnapshot(sqlitePath: string): SlackdumpProgressSnapshot | null;
export declare function slackdumpProgressChanged(previous: SlackdumpProgressSnapshot | null, current: SlackdumpProgressSnapshot | null): boolean;
export declare function runSlackdump(args: string[], { env, maxRuntimeMs, progress, progressIntervalMs, progressLabel, sqlitePath, timeoutMs, }: {
    env: NodeJS.ProcessEnv;
    maxRuntimeMs?: number;
    progress?: CollectContext["progress"];
    progressIntervalMs?: number;
    progressLabel?: string;
    sqlitePath?: string;
    timeoutMs?: number;
}): Promise<SlackdumpRunResult>;
interface SlackCredentials {
    cookie: string;
    token: string;
    workspace: string;
}
export declare const SLACK_RETRYABLE_FAILURE_RE: RegExp;
export declare function normalizeSlackWorkspace(raw: string): string;
export declare function normalizeSlackToken(raw: string): string;
export declare function normalizeSlackCookie(raw: string): string;
export declare function extractSlackCredentials(credentials: Record<string, string>): SlackCredentials;
export declare function reclaimUploads(archivePath: string): Promise<number>;
/**
 * Whether this archive still owes a full `archive` enumeration.
 *
 * `resume` is the right tool for an archive whose enumeration finished: it
 * carries every channel forward cheaply within its lookback. It is the WRONG
 * tool for an archive whose enumeration never finished, because the channels
 * that enumeration never reached are not in the archive for `resume` to walk.
 * Choosing resume purely on `existsSync(archivePath)` — which is what this
 * connector did — makes that state permanent: the directory exists, so every
 * subsequent run resumes, so the missing channels are never requested, so the
 * directory keeps existing in exactly the same incomplete shape.
 *
 * The archive records the fact needed to tell the two apart. slackdump writes
 * a SESSION row per invocation with its own `FINISHED` flag and `MODE`. An
 * archive whose `MODE = 'archive'` session never set `FINISHED = 1` is one
 * whose enumeration was cut short, and it stays owed until an `archive` pass
 * actually completes.
 *
 * Reads as "not owed" when the archive carries no SESSION bookkeeping at all.
 * An archive that cannot report its own session state cannot prove it was
 * interrupted either, and forcing a multi-GB re-archive off absent evidence is
 * the same defect in the other direction.
 */
/**
 * `archiveEnumerationIncomplete` for an archive on disk, by path.
 *
 * Opens read-only and always closes. A path that does not exist, or a file
 * too damaged to open, reports `false` — same absent-evidence rule as the
 * in-DB check: never force a multi-GB re-archive off a failure to read.
 */
export declare function archivePathEnumerationIncomplete(sqlitePath: string): boolean;
/**
 * Incremental via slackdump resume, full via archive.
 * Resume path: (a) explicit state.archive_dir from a prior successful run,
 * or (b) an archive directory already exists on disk from a timed-out or
 * crashed prior run. Resuming salvages partial progress — slackdump picks
 * up from the last recorded chunk for each channel it already holds.
 *
 * `forceFullArchive` overrides both: an archive whose enumeration never
 * completed (see `archiveEnumerationIncomplete`) must re-run `archive`, not
 * resume, or the channels enumeration never reached stay unreachable forever.
 * slackdump's `archive` is itself resumable against the same directory, so
 * this finishes the interrupted enumeration rather than discarding the 4.8 GB
 * already on disk.
 */
export declare function pickResumeTarget(state: CollectContext["state"], archivePath: string, { allowStateArchive, forceFullArchive, }?: {
    allowStateArchive?: boolean;
    forceFullArchive?: boolean;
}): {
    resumeTarget: string | null;
    priorArchive: string | undefined;
};
/**
 * Emits one record, optionally reporting whether it was accepted.
 *
 * Resolving `false` means the record was deliberately dropped downstream
 * and never reached the runtime. Resolving anything else — including no
 * value at all, which is what every non-filtering caller does — means it
 * landed.
 *
 * The reported outcome exists so that dropping a record is VISIBLE to the
 * cursor logic. While the drop was silent, the messages pass advanced the
 * durable watermark past rows it had not emitted, and the next run — which
 * queries `TS > cursor` — could never fetch them again.
 *
 * Written as a union of two Promise types rather than `Promise<boolean |
 * void>`: it keeps `void` in return position (where it is not the
 * confusing-union that Biome's noConfusingVoidType rejects) while letting
 * the many existing `Promise<void>` callbacks satisfy it unchanged.
 */
type EmitRecordFn = (stream: string, data: RecordData) => Promise<boolean> | Promise<void>;
/**
 * Subset of the per-stream dependency bag that the unified messages pass
 * actually needs. The sqlite-bound helpers in this file extend this with a
 * `db: DatabaseSync` field; tests can satisfy this narrower interface
 * without opening a DB. Mirrors the gmail/chase/usaa EmitDeps shape.
 */
export interface MessagesPassDeps {
    /**
     * Only a record this reports as accepted may advance the emitting
     * channel's durable cursor. See `EmitRecordFn`.
     */
    emitRecord: EmitRecordFn;
    emittedAt: string;
    progress: CollectContext["progress"];
    requested: CollectContext["requested"];
}
export interface MessagesPassResult {
    /**
     * The DURABLE per-channel cursor contribution: the max Slack ts among
     * rows this pass actually EMITTED and had accepted, per channel. A row
     * that was iterated but dropped (out of channel scope, or `messages` not
     * requested) contributes nothing here, because the next run refetches
     * strictly above this value — advancing it past an unemitted row makes
     * that row permanently unreachable.
     *
     * Distinct from `iteratedChannelMaxTs`, which is progress reporting only.
     */
    channelMaxTs: Record<string, string>;
    considered: number;
    /**
     * Rows this pass actually accounted for: enumerated AND successfully
     * shaped into a record. Measured per-row from the parse outcome, never
     * aliased to `considered` — a row whose timestamp could not be parsed is
     * counted in `considered` but not here, so it reads an honest `partial`
     * instead of the tautological `complete` the prior `covered: considered`
     * produced.
     */
    covered: number;
    /**
     * The max Slack ts per channel among rows this pass WALKED, emitted or
     * not. Observational: safe for progress/diagnostics, never durable.
     * Kept separate from `channelMaxTs` so neither can be mistaken for the
     * other at a call site.
     */
    iteratedChannelMaxTs: Record<string, string>;
    /**
     * Durable global cursor contribution: max Slack ts among EMITTED rows.
     * Same rule as `channelMaxTs` — it is written to `messages.last_ts`, which
     * the next run uses as a floor, so an unemitted row must not raise it.
     */
    maxMessageTs: string | null;
    /** Child records derived from every message row the pass enumerated. */
    messageAttachmentCoverage: MessageDetailCoverage;
    /** Child records derived from every message row the pass enumerated. */
    reactionCoverage: MessageDetailCoverage;
}
interface MessageDetailCoverage {
    considered: number;
    covered: number;
}
/**
 * Single-pass co-traversal of pre-loaded MESSAGE rows, emitting into
 * messages, reactions, and message_attachments streams as requested.
 *
 * Cursor rule (the load-bearing invariant): the DURABLE watermarks
 * (`maxMessageTs`, `channelMaxTs`) advance only for rows this pass actually
 * emitted AND had accepted. Rows that were merely walked feed
 * `iteratedChannelMaxTs`, which is observational only.
 *
 * Why the split exists: the archive query the next run issues is
 * `TS > cursor`. A row that raises the cursor without being emitted is
 * therefore never fetched again — silent, permanent loss. This pass walks
 * rows for channels outside the run's scope (a scoped run reads the whole
 * base archive), so "walked" and "emitted" genuinely differ, and conflating
 * them lost data rather than merely mis-reporting it.
 *
 * Contract pinned by integration.test.ts:
 *   - Per row, the `messages` record emits BEFORE its reactions and
 *     attachments (parent-before-children within the row).
 *   - Scope gating is per-stream: disabling one of the three does not
 *     suppress the other two — they share the pass but not the guard.
 *   - When all three are disabled, the loop still runs (rows are iterated)
 *     but emits nothing, and the DURABLE watermarks stay put — an
 *     unemitted row must not be checkpointed as collected. Only
 *     `iteratedChannelMaxTs` moves. The caller guards entry on
 *     `requested.has("messages" | "reactions" | "message_attachments")`,
 *     so an all-disabled call is a no-op in practice either way.
 *   - A message with no reactions / no attachments still emits its
 *     messages record; enrichment is additive, not gating.
 *   - This function does not dedupe — dedup happens in `iterateMessageRows`
 *     at the sqlite layer via `MAX(CHUNK_ID) GROUP BY (CHANNEL_ID, TS)`.
 *     Passing the same row twice emits twice on purpose.
 *   - `deps.emittedAt` is the pinned emit-time; `parseMessageRow` uses
 *     nowIso() only as a fallback when the row's TS is unparseable,
 *     which threads into the record's `sent_at` (distinct from
 *     `emitted_at`, which the runtime stamps on the RECORD envelope).
 *   - Rows are already filtered by collection_scope.since at the SQL layer
 *     (buildMessageRowsQuery), so this function only emits in-scope rows.
 */
export declare function emitMessagesPass(deps: MessagesPassDeps, rows: Iterable<MessageRow>, priorTs: string | null): Promise<MessagesPassResult>;
/**
 * Shared deps bag for every per-stream helper. Mirrors gmail/usaa EmitDeps —
 * bundle the few things every stream needs so helper signatures stay 2 args.
 *
 * `fingerprintCursors` carry the per-record semantic fingerprints across
 * runs for the workspace/users/files streams via the shared
 * `openFingerprintCursor` primitive. Without them, slackdump's
 * archive-rebuild churn produces a fresh RECORD per (record, run) pair
 * even when source state hasn't moved. One cursor per fingerprinted
 * stream; cursors for streams not requested this run carry forward
 * untouched (their `dropUnseenIds` is never called).
 */
export interface StreamDeps {
    db: DatabaseSync;
    /**
     * Protocol-message side-channel (non-RECORD). Used today only to declare a
     * list stream's enumerated `considered` denominator via a self-coverage
     * DETAIL_COVERAGE (see `declareListConsidered`). Narrowed to the single
     * message kind this connector emits through it so a future RECORD emit can't
     * accidentally route here instead of `emitRecord`.
     */
    emit: (msg: Extract<EmittedMessage, {
        type: "DETAIL_COVERAGE";
    }>) => Promise<void>;
    /**
     * Reports whether the record landed — today a `messages` record outside
     * the run's channel scope is dropped and reports `false`.
     * `emitMessagesPass` needs that to keep the durable cursor off unemitted
     * rows. See `EmitRecordFn`.
     */
    emitRecord: EmitRecordFn;
    emittedAt: string;
    /** Streams whose source enumeration failed; failed streams must not prove
     * coverage, prune fingerprints, or checkpoint STATE in this run. */
    failedStreams: Set<string>;
    fingerprintCursors: Map<string, FingerprintCursor>;
    progress: CollectContext["progress"];
    requested: CollectContext["requested"];
}
/**
 * Streams that use the per-record fingerprint cursor. Workspace + users +
 * files were re-emitting on every slackdump pass even when source state
 * hadn't moved — see record-version-churn-data-quality-report.md
 * (31k+ versions/key on workspace, 250 versions/key on users, bimodal on
 * files). Channels, canvases, messages, reactions and message_attachments
 * are intentionally NOT on this list:
 *   - channels: low cardinality, low version count today; out of scope
 *     for this batch.
 *   - canvases: tied to channel index; low cardinality.
 *   - messages/reactions/message_attachments: already incremental via
 *     last_ts cursor.
 *
 * `channel_memberships` WAS deferred here on the assumption that its churn
 * was not load-bearing. Live retained-history later contradicted that: its
 * record body is `{id, channel_id, user_id, fetched_at}`, so the per-run
 * `fetched_at` forced a brand-new version of every membership on every run,
 * and it grew into the single largest churn stream by absolute history
 * volume (tens of thousands of `record_changes` rows for a membership set
 * that barely moves). It is the exact `fetched_at`-volatility class already
 * fixed for `workspace`, so it now joins the fingerprinted set with the same
 * `fetched_at` exclusion. A membership only re-emits when it actually
 * appears or disappears.
 */
export declare const FINGERPRINTED_STREAMS: readonly ["workspace", "users", "files", "channel_memberships", "channels"];
type FingerprintedStream = (typeof FINGERPRINTED_STREAMS)[number];
/**
 * Per-stream emitted-record fields that participate in the emitted shape
 * but must NOT participate in change detection — typically run-clock
 * fields like `fetched_at` whose value is "when this run happened",
 * not "when the source row changed". Without exclusion, the fingerprint
 * would never match across runs even when the source has not moved.
 *
 *   workspace: fetched_at advances on every run by design.
 *   users / files: no run-clock fields, fingerprint covers the whole record.
 *   channel_memberships: fetched_at is the run clock; the only other fields
 *     (id, channel_id, user_id) are the membership identity itself, so
 *     excluding fetched_at means the fingerprint moves only when a
 *     membership is added or removed.
 */
export declare const FINGERPRINT_EXCLUDE: Record<FingerprintedStream, readonly string[]>;
/**
 * Per-stream fingerprint gate. Computes the record's fingerprint against
 * the prior cursor (with `FINGERPRINT_EXCLUDE[stream]` removed from the
 * input) and emits only when the fingerprint moved or there is no prior.
 * Records whose fingerprint matches the prior one do NOT emit — that
 * suppression is the load-bearing line for the workspace/users/files
 * churn fix.
 *
 * Records without an id pass through unconditionally (they cannot be
 * fingerprinted; the cursor leaves its state alone).
 */
export declare function emitWithFingerprint(deps: StreamDeps, stream: FingerprintedStream, record: RecordData): Promise<boolean>;
export declare function runChannelsStream(deps: StreamDeps): Promise<void>;
export declare function runUsersStream(deps: StreamDeps): Promise<void>;
/**
 * Stream message rows from slackdump's sqlite, deduping by (CHANNEL_ID, TS)
 * on latest CHUNK_ID and optionally filtering incrementally on ts>priorTs.
 *
 * The MESSAGE table is the only slackdump table that grows unbounded with
 * workspace history (10+ year workspaces, DMs + channel history). Iterating
 * row-by-row (`.iterate()`) keeps process memory bounded by a single row
 * rather than the whole materialized result set; this mirrors the codex
 * collector's `queryThreadsRows` shape. The bounded lookup tables
 * (S_USER, FILE, CHANNEL, WORKSPACE) keep `.all()` via `safeAll`: their
 * cardinality is members/files/channels, not message volume.
 */
interface MessageCursorThresholds {
    channelLastTs: Record<string, string>;
    legacyLastTs: string | null;
    sinceTs: string | null;
}
export declare function buildMessageRowsQuery(thresholds: MessageCursorThresholds): {
    params: string[];
    sql: string;
};
/**
 * Parses an ISO 8601 instant to Slack ts format ("seconds.microseconds").
 * Exported for testing.
 *
 * Slack ts is stored as "seconds.microseconds" where seconds is Unix epoch
 * and microseconds are 6 decimal digits (from archive records). ISO instants
 * can have milliseconds (3 places), microseconds (6 places), or no fraction —
 * all are normalized to 6 digits: "2026-08-09T22:26:25.500Z" → epoch.500000,
 * or "2026-08-09T22:26:25Z" → epoch.000000.
 *
 * Throws Error if the instant is malformed (invalid date syntax, non-finite
 * epoch, or negative timestamp). Absent input (empty/null) is NOT an error;
 * return null to signal no bound, allowing the caller to distinguish between
 * "no since declared" (null → unbounded collection) and "since declared but
 * broken" (throws → configuration error).
 *
 * Comparison: Slack ts comparison is lexical on the formatted string. Numeric
 * comparison of (epochSeconds, fractionalPart as a string) is equivalent, since
 * both preserve chronological order for timestamps in the same second. We use
 * numeric logic to avoid assuming the archive format is fixed-width (though we
 * produce fixed-width output consistently).
 */
export declare function parseIsoInstantToSlackTs(instant: string): string;
export declare function runFilesStream(deps: StreamDeps): Promise<void>;
export declare function runCanvasesStream(deps: StreamDeps): Promise<void>;
/**
 * `stars`, `user_groups`, `reminders`, `dm_read_states` are not producible
 * from the slackdump archive (see `slack-api.ts` header). They collect via
 * direct Slack Web API calls using the same session credential the
 * connector already captured for slackdump.
 */
export declare function runStarsStream(deps: StreamDeps, token: string, cookie: string): Promise<void>;
export declare function runUserGroupsStream(deps: StreamDeps, token: string, cookie: string): Promise<void>;
export declare function runRemindersStream(deps: StreamDeps, token: string, cookie: string): Promise<void>;
/**
 * Scoped to `is_im`/`is_mpim` channel IDs — NOT the full channel inventory.
 * `conversations.info` is a per-channel call (Tier 3), and read-state is
 * specifically a DM/MPIM concept; sweeping every public/private channel
 * would multiply calls with no stream-relevant payoff. See design.md
 * Decision 3.
 */
export declare function runDmReadStatesStream(deps: StreamDeps, token: string, cookie: string): Promise<void>;
export interface StateEmitDeps {
    archivePath: string;
    baseArchiveResumedAt: Record<string, string>;
    channelLastTs: Record<string, string>;
    committedMaxTs: string | null;
    emit: CollectContext["emit"];
    failedStreams: ReadonlySet<string>;
    fingerprintCursors: Map<string, FingerprintCursor>;
    observedChannelIds: readonly string[];
    requested: CollectContext["requested"];
    scopedArchiveResumedAt: Record<string, string>;
}
/**
 * Per-stream STATE checkpoints. Per Collection Profile spec, STATE is emitted
 * per stream with a cursor object opaque to the runtime but interpreted by
 * this connector on the next run.
 *
 * - messages: `last_ts` is the max Slack ts seen this run. `archive_dir`
 *   moves onto the messages cursor so `-resume` continues to work; it's
 *   workspace-global but messages is the canonical stream for slackdump
 *   state on the PDPP side.
 * - workspace / users / files / channel_memberships: persist the per-record
 *   fingerprint map alongside the freshness marker so the next run can skip
 *   emitting records whose semantic shape hasn't moved (see
 *   emitWithFingerprint). A legacy cursor (no `fingerprints` key) is
 *   tolerated on the read side; the first post-deploy run rebuilds the map.
 * - other mutable_state streams (channels, canvases):
 *   low cardinality, we full-sync each run; the cursor is just a freshness
 *   marker for visibility.
 */
export declare function emitStateCheckpoints(deps: StateEmitDeps): void;
/** Prune only fingerprints from streams that completed their full source
 * enumeration. A failed read leaves the prior map intact for the retry. */
export declare function pruneRequestedFingerprintCursors(requested: CollectContext["requested"], failedStreams: ReadonlySet<string>, fingerprintCursors: Map<string, FingerprintCursor>): void;
/**
 * `stars`, `user_groups`, `reminders`, `dm_read_states` are declared
 * `required: false` in the manifest (they are supplementary streams a
 * direct Slack Web API call collects on top of the slackdump archive, not
 * part of the connector's core value). A thrown error from one of these
 * four must not propagate to `collect()`'s caller — `connector-runtime.ts`
 * has exactly one top-level catch (`run().catch(...)`), and anything that
 * reaches it fails the ENTIRE run, including the required streams that
 * already succeeded and committed earlier in this same pass. Catching here
 * and reporting a SKIP_RESULT keeps that failure stream-scoped: the run
 * still completes and the gap is visible in the Collection Report instead
 * of taking down messages/channels/files/etc. with it.
 *
 * Requiredness is a manifest-only concept — `StreamScope`/START never
 * threads a `required` bit into the connector subprocess (only
 * `reference-implementation/`'s post-run health rollup reads the
 * manifest's `required` field) — so this wrapper is intentionally
 * connector-local rather than a `connector-runtime.ts` primitive.
 */
export declare function runOptionalStream(emit: CollectContext["emit"], stream: string, run: () => Promise<void>): Promise<void>;
/**
 * Run every requested record stream against the open sqlite DB in emit
 * order. Returns the max message TS for the post-loop STATE checkpoint.
 */
export declare function runRequestedStreams(deps: StreamDeps, state: CollectContext["state"], credentials: SlackCredentials, emit: CollectContext["emit"], options?: {
    allowLegacyMessageCursorFallback?: boolean;
    ignoreMessageChannelCursors?: boolean;
    sinceTs?: string | null;
}): Promise<MessagesPassResult>;
export {};
//# sourceMappingURL=index.d.ts.map