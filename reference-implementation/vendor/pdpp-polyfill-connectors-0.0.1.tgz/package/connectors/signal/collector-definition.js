// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
export const SIGNAL_DEFAULT_STREAMS = [
    "messages",
    "conversations",
    "reactions",
    "attachments",
];
/**
 * Only `messages` declares a `consent_time_field` (`sent_at`). Conversations
 * are standing entities (full resnapshot every run), and reactions/
 * attachments carry no owner-moment of their own — all three are collected
 * whole, same as imessage's `participants`/`attachments`.
 */
export const SIGNAL_TIME_SCOPABLE_STREAMS = ["messages"];
export const signalCollectorDefinition = {
    connector_id: "signal",
    entry: "signal",
    bindings: { filesystem: { required: true } },
    protocol_capabilities: [],
    streams: SIGNAL_DEFAULT_STREAMS,
    time_scopable_streams: SIGNAL_TIME_SCOPABLE_STREAMS,
};
