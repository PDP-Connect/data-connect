#!/usr/bin/env node
import { type ReferenceBlobRef } from "../../src/reference-blob-uploader.ts";
export declare const DEFAULT_MAX_ATTACHMENT_BYTES: number;
export declare function resolveMaxAttachmentBytes(env?: NodeJS.ProcessEnv): number;
export declare function resolveSigtopBin(env?: NodeJS.ProcessEnv): string;
export declare function formatSigtopMissingError(bin: string): string;
interface SigtopRunResult {
    code: number | null;
    stderr: string;
    stdout: string;
}
/**
 * Spawn `sigtop <args>` and collect its output. Deliberately simple: a
 * single total-runtime timeout, no stall-detection budget, no retry
 * machinery — see this file's module doc for why slack's heavier
 * subprocess runtime is not copied here. `check-database`/
 * `export-database`/`export-attachments` are all bounded, single-shot
 * operations against a local file, not a multi-hour network archive dump.
 */
export declare function runSigtop(args: string[], { timeoutMs }?: {
    timeoutMs?: number;
}): Promise<SigtopRunResult>;
/**
 * Validate + coerce a STATE-supplied cursor value to a non-negative
 * integer. Even though this connector now queries via bound `?`
 * parameters (no manual SQL-string interpolation — see
 * `openExportedDatabase`'s callers), an untrusted STATE cursor is still
 * coerced defensively before use: anything that is not a finite
 * non-negative integer (NaN, Infinity, negative, non-numeric) coerces to
 * 0, matching imessage's since-defaults-to-0 behavior on first run or a
 * malformed cursor.
 */
export declare function parseCursorMs(value: unknown): number;
/**
 * Validate a source-measured row total: must be a finite, non-negative
 * integer. Fail closed — a missing or malformed count is NOT zero and NOT
 * "complete". Mirrors jellyfin's `validateTotalRecordCount` discipline
 * (connectors/jellyfin/index.ts), minus the monotonicity rule: Signal
 * Desktop legitimately DELETES rows (disappearing messages expire, the
 * owner deletes a thread), so a decreasing total here is ordinary source
 * behavior rather than the provider-side anomaly it is for Jellyfin.
 */
export declare function validateSourceTotal(value: unknown, label: string): number;
/**
 * Read the durable emitted-id cursor tolerantly. A missing, malformed, or
 * legacy (pre-cursor) value yields an EMPTY set, which is safe: an empty
 * prior set combined with a `since` of 0 (the only state a cold start can
 * be in) puts nothing below the watermark, so no false gap can be reported.
 * A legacy cursor that DOES carry `last_sent_at_ms` but no `emitted_ids`
 * would report every below-watermark id as unreachable on its first
 * post-deploy run — see `readPriorEmittedIds`'s caller, which suppresses
 * the finding in exactly that case.
 */
export declare function parseEmittedIds(value: unknown): Set<string>;
/**
 * Merge the prior emitted-id set with this run's, newest-last, bounded.
 *
 * The bound matters: this set is a durable cursor, and an unbounded one
 * grows without limit on a large account. Keeping the NEWEST ids is the
 * right truncation because the check only ever asks about ids at or below
 * the watermark — and the watermark advances, so the oldest ids are the
 * ones least likely to be re-offered by a backfill. When truncation is in
 * force the check degrades to "cannot prove", never to a false clean bill:
 * `reconcileMessageAnchor`'s caller reports the truncation explicitly.
 */
export declare function mergeEmittedIds(prior: ReadonlySet<string>, current: readonly string[]): string[];
export interface AttachmentHydrationResult {
    blobRef: ReferenceBlobRef | null;
    bytes: Buffer | null;
    contentSha256: string | null;
    hydrationError: string | null;
    hydrationStatus: "deferred" | "hydrated" | "failed" | "too_large" | "missing";
    sizeBytes: number | null;
}
/**
 * Bounded local read with the check-then-read (TOCTOU) window closed —
 * verbatim port of imessage/index.ts's `readAttachmentFileSync`. See that
 * file's doc comment for the full O_NOFOLLOW rationale; it applies
 * unchanged here since the threat model (canonicalize-then-verify
 * followed by a separate read syscall) is identical. Linux (this
 * connector's development/test platform) supports O_NOFOLLOW
 * unconditionally, and so do macOS/Windows (sigtop's other supported
 * platforms per Node's fs module) — untested here, see module doc.
 */
export declare function readAttachmentFileSync(localPath: string, maxBytes: number): AttachmentHydrationResult;
export {};
//# sourceMappingURL=index.d.ts.map