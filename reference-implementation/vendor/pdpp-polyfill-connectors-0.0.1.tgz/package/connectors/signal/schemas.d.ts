import { z } from "zod";
/**
 * messages stream: one record per Signal message row.
 * Cursor: sent_at (epoch-ms high-water mark tracked in STATE).
 */
export declare const messagesSchema: z.ZodObject<{
    id: z.ZodString;
    conversation_id: z.ZodString;
    sender: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    sent_at: z.ZodString;
    body: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    has_attachments: z.ZodBoolean;
    is_edited: z.ZodBoolean;
}, z.core.$strip>;
/**
 * conversations stream: one record per Signal conversation (direct or
 * group). Semantics: mutable_state — full resnapshot each run, no
 * incremental cursor (standing entity, no natural per-row date bound).
 */
export declare const conversationsSchema: z.ZodObject<{
    id: z.ZodString;
    type: z.ZodNullable<z.ZodEnum<{
        group: "group";
        private: "private";
    }>>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    member_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * reactions stream: one record per (message, emoji, sender) reaction.
 * Semantics: append_only. Composite id, matching slack.reactions' shape.
 */
export declare const reactionsSchema: z.ZodObject<{
    id: z.ZodString;
    message_id: z.ZodString;
    emoji: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    sender: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
/**
 * attachments stream: one record per attachment exported by
 * `sigtop export-attachments`. Bytes are hydrated via a local read bounded
 * to a trusted root (sigtop's own output directory — see index.ts's
 * resolveSafeAttachmentPath call, reusing imessage's O_NOFOLLOW primitive
 * verbatim) + BlobRef upload; hydration_status/hydration_error report the
 * outcome without leaking the local filesystem path.
 */
export declare const attachmentsSchema: z.ZodObject<{
    id: z.ZodString;
    message_id: z.ZodNullable<z.ZodString>;
    conversation_id: z.ZodNullable<z.ZodString>;
    filename: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    content_type: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    content_sha256: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    hydration_status: z.ZodEnum<{
        deferred: "deferred";
        failed: "failed";
        hydrated: "hydrated";
        missing: "missing";
        too_large: "too_large";
    }>;
    hydration_error: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    blob_ref: z.ZodNullable<z.ZodObject<{
        blob_id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        mime_type: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        sha256: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        size_bytes: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map