export interface FixtureMessage {
    body: string | null;
    conversationId: string;
    id: string;
    json?: string | null;
    receivedAtMs?: number | null;
    sentAt: number | null;
    sourceServiceId?: string | null;
    type?: string | null;
}
export interface FixtureConversation {
    e164?: string | null;
    groupId?: string | null;
    id: string;
    name?: string | null;
    serviceId?: string | null;
    type: "private" | "group";
}
export interface FixtureMessageAttachment {
    contentType: string | null;
    fileName: string | null;
    messageId: string;
    size: number | null;
}
export interface SignalExportFixtureOptions {
    conversations?: FixtureConversation[];
    /** Omit the `message_attachments` table entirely (simulates a pre-1360 schema). */
    includeMessageAttachmentsTable?: boolean;
    messageAttachments?: FixtureMessageAttachment[];
    messages: FixtureMessage[];
}
/**
 * Builds a SQLite file at `dbPath` mirroring the real, minimal shape of
 * Signal Desktop's `messages`/`conversations`/`message_attachments` tables
 * this connector actually queries (column names verified against sigtop's
 * signal/{message,recipient,attachment}.go — see this file's module doc).
 * This is the file `sigtop export-database` would produce; the mock sigtop
 * script (`writeMockSigtopScript`) copies it verbatim in place of a real
 * export.
 */
export declare function buildSignalExportFixture(dbPath: string, opts: SignalExportFixtureOptions): void;
export interface MockSigtopAttachmentFile {
    bytes: Buffer;
    /** Conversation subdirectory name sigtop's own export would create. */
    conversationDir: string;
    filename: string;
}
export interface MockSigtopOptions {
    attachments?: MockSigtopAttachmentFile[];
    checkDatabaseExitCode?: number;
    checkDatabaseStdout?: string;
    exportDatabaseExitCode?: number;
    fixtureDbPath: string;
}
/**
 * Writes a Node script at `scriptPath` that stands in for the real
 * `sigtop` binary. Understands exactly the three subcommands+flag shapes
 * this connector actually invokes:
 *
 *   check-database                       -> exits 0, or checkDatabaseExitCode
 *   export-database <file>                -> copies fixtureDbPath to <file>
 *                                            (fails if <file> already exists,
 *                                            matching real sigtop's O_EXCL)
 *   export-attachments -i <dir>           -> writes each configured
 *                                            attachment file under
 *                                            <dir>/<conversationDir>/<filename>
 *
 * Any other invocation exits non-zero with a message on stderr, so a test
 * asserting on an unexpected sigtop call fails loudly instead of silently
 * no-op'ing.
 */
export declare function writeMockSigtopScript(scriptPath: string, opts: MockSigtopOptions): void;
/** Convenience: build the fixture DB + mock script together under `dir`. */
export declare function setupMockSigtop(dir: string, dbOpts: SignalExportFixtureOptions, mockOpts?: Omit<MockSigtopOptions, "fixtureDbPath">): string;
export declare function copyForFixture(from: string, to: string): void;
//# sourceMappingURL=fixtures.d.ts.map