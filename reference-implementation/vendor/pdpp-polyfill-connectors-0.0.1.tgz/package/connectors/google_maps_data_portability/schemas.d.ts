import { z } from "zod";
export declare const archiveJobsSchema: z.ZodObject<{
    access_type: z.ZodNullable<z.ZodString>;
    archive_job_id: z.ZodNullable<z.ZodString>;
    download_url_count: z.ZodNumber;
    export_time: z.ZodNullable<z.ZodString>;
    id: z.ZodString;
    resource_group: z.ZodString;
    source: z.ZodLiteral<"google_data_portability_api">;
    start_time: z.ZodNullable<z.ZodString>;
    state: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map