#!/usr/bin/env node
import { type CollectContext } from "../../src/connector-runtime.ts";
import { type AccessTypeResult, GoogleDataPortabilityClient, type InitiateArchiveResult } from "./api.ts";
interface DataPortabilityClientLike {
    checkAccessType: () => Promise<AccessTypeResult>;
    getArchiveState: (archiveJobId: string) => ReturnType<GoogleDataPortabilityClient["getArchiveState"]>;
    initiateArchive: (input: Parameters<GoogleDataPortabilityClient["initiateArchive"]>[0]) => Promise<InitiateArchiveResult>;
}
interface GoogleDataPortabilityCollectOptions {
    readonly clientFactory?: (accessToken: string) => DataPortabilityClientLike;
    readonly env?: NodeJS.ProcessEnv | Record<string, string | undefined>;
}
export declare function collectGoogleMapsDataPortability(ctx: CollectContext, options?: GoogleDataPortabilityCollectOptions): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map