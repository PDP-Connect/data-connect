export declare const GOOGLE_MAPS_DATA_PORTABILITY_RESOURCE_GROUPS: readonly string[];
export declare const GOOGLE_MAPS_DATA_PORTABILITY_OAUTH_SCOPES: readonly string[];
export type DataPortabilityFetch = (url: string, init: RequestInit) => Promise<Response>;
export interface DataPortabilityClientOptions {
    readonly accessToken: string;
    readonly baseUrl?: string;
    readonly fetch?: DataPortabilityFetch;
}
export interface InitiateArchiveInput {
    readonly endTime?: string;
    readonly resources: readonly string[];
    readonly startTime?: string;
}
export interface InitiateArchiveResult {
    readonly accessType: string | null;
    readonly archiveJobId: string;
}
export interface ArchiveStateResult {
    readonly exportTime: string | null;
    readonly name: string;
    readonly startTime: string | null;
    readonly state: string;
    readonly urls: readonly string[];
}
export interface AccessTypeResult {
    readonly oneTimeResources: readonly string[];
    readonly timeBasedResources: readonly string[];
}
export declare class DataPortabilityApiError extends Error {
    readonly bodySnippet: string;
    readonly status: number;
    constructor(status: number, bodySnippet: string);
}
export declare class GoogleDataPortabilityClient {
    private readonly accessToken;
    private readonly baseUrl;
    private readonly fetchImpl;
    constructor(options: DataPortabilityClientOptions);
    checkAccessType(): Promise<AccessTypeResult>;
    initiateArchive(input: InitiateArchiveInput): Promise<InitiateArchiveResult>;
    getArchiveState(archiveJobId: string): Promise<ArchiveStateResult>;
    private request;
}
//# sourceMappingURL=api.d.ts.map