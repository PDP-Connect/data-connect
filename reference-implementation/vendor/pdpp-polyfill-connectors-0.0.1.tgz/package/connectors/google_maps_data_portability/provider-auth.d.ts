import type { ProviderAuthAdapter } from "../../src/provider-auth-adapter.ts";
export declare class GoogleDataPortabilityProviderAuthError extends Error {
    readonly code: string;
    readonly status: number;
    constructor(code: string, message: string, status?: number);
}
export declare const GOOGLE_DATA_PORTABILITY_EXCHANGER_KIND = "oauth2_access_type_resource_groups";
export declare const googleDataPortabilityAdapter: ProviderAuthAdapter;
//# sourceMappingURL=provider-auth.d.ts.map