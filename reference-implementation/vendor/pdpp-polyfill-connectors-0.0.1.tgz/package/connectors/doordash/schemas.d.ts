import { z } from "zod";
/**
 * orders stream (manifest required: id). One record per DoorDash delivery
 * order. All money fields are non-negative cent integers; `restaurant_name` is
 * free-form; `status` / `payment_method_summary` are short labels;
 * `delivery_address` is free-form human text; `order_date` is an ISO datetime.
 */
export declare const ordersSchema: z.ZodObject<{
    id: z.ZodString;
    order_date: z.ZodNullable<z.ZodString>;
    restaurant_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodNullable<z.ZodString>;
    subtotal_cents: z.ZodNullable<z.ZodNumber>;
    tax_cents: z.ZodNullable<z.ZodNumber>;
    tip_cents: z.ZodNullable<z.ZodNumber>;
    delivery_fee_cents: z.ZodNullable<z.ZodNumber>;
    service_fee_cents: z.ZodNullable<z.ZodNumber>;
    total_cents: z.ZodNullable<z.ZodNumber>;
    delivery_address: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    payment_method_summary: z.ZodNullable<z.ZodString>;
    item_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * order_items stream (manifest required: id, order_id, name, quantity,
 * customizations). One record per line item. `name` is the free-form item
 * name; `quantity` is a required non-negative integer (manifest declares plain
 * integer, not nullable); `customizations` is an array of free-form
 * modifier strings (manifest declares a bare array — element shape unverified,
 * so each element is bounded free text rather than `z.any()`).
 */
export declare const orderItemsSchema: z.ZodObject<{
    id: z.ZodString;
    order_id: z.ZodString;
    name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    quantity: z.ZodNumber;
    unit_price_cents: z.ZodNullable<z.ZodNumber>;
    customizations: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the streams this
 * connector declares (and will emit once extraction is wired).
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map