/**
 * Zod schemas for Chase stream records. Used for shape-check-before-emit
 * per docs/reference/connector-authoring-guide.md §3: records that fail the schema
 * become SKIP_RESULT events instead of RECORD events, so the RS never
 * receives data that looks right but isn't.
 *
 * Chase's connector parses QFX (Quicken Web Connect) files downloaded
 * from chase.com. The shapes below defend against:
 *   - QFX parser drift (ofx-js behavior changes)
 *   - DOM changes on the download-statement UI (for statements stream)
 *   - Off-by-one currency parsing (cents as float vs integer)
 *   - QFX FITID collisions (FITID is Chase's stable transaction id;
 *     the connector hashes (account, fitid) for the record key)
 */
import { z } from "zod";
export declare const accountSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodNullable<z.ZodString>;
    type: z.ZodNullable<z.ZodString>;
    last_four: z.ZodNullable<z.ZodString>;
    balance_cents: z.ZodNullable<z.ZodNumber>;
    available_balance_cents: z.ZodNullable<z.ZodNumber>;
    credit_limit_cents: z.ZodNullable<z.ZodNumber>;
    available_credit_cents: z.ZodNullable<z.ZodNumber>;
    statement_balance_cents: z.ZodNullable<z.ZodNumber>;
    status: z.ZodNullable<z.ZodString>;
    balance_as_of: z.ZodNullable<z.ZodString>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const transactionSchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodString;
    account_name: z.ZodNullable<z.ZodString>;
    fitid: z.ZodString;
    date: z.ZodString;
    amount: z.ZodNumber;
    currency: z.ZodString;
    type: z.ZodNullable<z.ZodString>;
    name: z.ZodNullable<z.ZodString>;
    memo: z.ZodNullable<z.ZodString>;
    check_number: z.ZodNullable<z.ZodString>;
    reference_number: z.ZodNullable<z.ZodString>;
    source: z.ZodString;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const currentActivitySchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodString;
    account_name: z.ZodNullable<z.ZodString>;
    status: z.ZodEnum<{
        pending: "pending";
        posted: "posted";
        unknown: "unknown";
    }>;
    activity_date: z.ZodString;
    posted_date: z.ZodNullable<z.ZodString>;
    amount: z.ZodNumber;
    currency: z.ZodString;
    description: z.ZodString;
    memo: z.ZodNullable<z.ZodString>;
    ui_transaction_id: z.ZodNullable<z.ZodString>;
    source: z.ZodLiteral<"chase_activity_ui">;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const statementSchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodNullable<z.ZodString>;
    title: z.ZodString;
    date_delivered: z.ZodNullable<z.ZodString>;
    account_reference: z.ZodNullable<z.ZodString>;
    document_url: z.ZodNullable<z.ZodURL>;
    pdf_path: z.ZodNullable<z.ZodString>;
    pdf_sha256: z.ZodNullable<z.ZodString>;
    pdf_text_sha256: z.ZodNullable<z.ZodString>;
    pdf_page_count: z.ZodNullable<z.ZodNumber>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const balanceSchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodString;
    as_of: z.ZodString;
    ledger_balance_cents: z.ZodNullable<z.ZodNumber>;
    available_balance_cents: z.ZodNullable<z.ZodNumber>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map