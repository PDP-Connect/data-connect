// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

/**
 * Integration tests for the Chase connector's `collect()` emit path —
 * the per-stream helpers exported from index.ts (emitAccountsStream,
 * emitTransactionsForAccount, emitStatementIndexOnly) and the pure
 * scope gates (filterAccountsByScope, statementRowOutsideTimeRange,
 * emitTransactionsStateIfAny).
 *
 * These tests DON'T drive Playwright. They construct a fake `EmitDeps`
 * backed by `makeRecordingEmit(validateRecord)` — records go through
 * the real zod schema so fixture drift here fails the test instead of
 * silently passing. Captures every (stream, data) pair pushed through
 * emitRecord plus every non-RECORD EmittedMessage pushed through emit,
 * then asserts on the observable invariants: ordering across streams,
 * stream-scope suppression, res-filter + time_range gating, cursor
 * propagation, and the index-only fallback when PDF download fails.
 *
 * Imports directly from ./index.ts — `runConnector({...})` is guarded by
 * `isMainModule(import.meta.url)` so it only fires when index.ts is the
 * process entry point, not when a test imports it.
 *
 * Why bother: parsers.test.ts proves record *shapes* are correct from
 * QFX/DOM input. Integration tests on the emit path prove the
 * invariants downstream consumers observe:
 *   - accounts emit before transactions/balances/statements (parent
 *     before children),
 *   - stream-scope flags each gate their own stream without breaking
 *     siblings,
 *   - the accounts res-filter narrows ALL per-account work (including
 *     statement-row account resolution), not just the `accounts` stream,
 *   - statements time_range skips out-of-window rows BEFORE the PDF
 *     click path (so we don't pay the download cost),
 *   - a failed PDF download still emits a statement index row (never
 *     silently drops the fact that the statement exists),
 *   - fetched_at = emittedAt on every record (not Date.now() reads
 *     scattered through the helpers),
 *   - STATE cursor reflects MAX(seen dates) per account across a run.
 * Regressing any of these is a real data-integrity bug.
 */

import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";
import { parseHTML } from "linkedom";
import { buildBrowserSurfaceDiagnostic } from "../../src/browser-surface-diagnostic.ts";
import type {
	EmittedMessage,
	StreamScope,
} from "../../src/connector-runtime.ts";
import type { CaptureSession } from "../../src/fixture-capture.ts";
import { savePlaywrightDownload } from "../../src/playwright-download.ts";
import {
	type EmittedRecord,
	makeRecordingEmit,
} from "../../src/test-harness.ts";
import {
	buildChaseDurableFailureDiagnostic,
	CHASE_CURRENT_ACTIVITY_ROW_SELECTOR,
	CHASE_QFX_ACTIVITY_SELECT_SELECTOR,
	CHASE_QFX_ACTIVITY_SELECT_SELECTORS,
	CHASE_QFX_FILE_TYPE_SELECT_SELECTOR,
	CHASE_QFX_FILE_TYPE_SELECT_SELECTORS,
	chaseLocatorProbesForLabel,
	chaseNoAccountsDiagnosticMessage,
	chaseTimeRangeField,
	classifyChaseAccountsSurface,
	collectChaseAccountInventory,
	type EmitDeps,
	emitAccountsStream,
	emitCurrentActivityForAccount,
	emitNoActivityProgress,
	emitStatementIndexOnly,
	emitTransactionsForAccount,
	emitTransactionsStateIfAny,
	filterAccountsByScope,
	isLikelyChaseQfxResponse,
	isLikelyPdfResponseBody,
	redactChaseDashboardDiagnostics,
	runCurrentActivity,
	runTransactionsAndBalances,
	snapshotDashboardHtmlForCurrentActivity,
	statementRowOutsideTimeRange,
} from "./index.ts";
import { validateRecord } from "./schemas.ts";
import type {
	ChaseAccount,
	DashboardDiagnostics,
	QfxTransaction,
	StatementRow,
	TransactionCursor,
	TransactionsStateShape,
} from "./types.ts";

interface RecordingHarness {
	deps: EmitDeps;
	emitted: EmittedRecord[];
	messages: EmittedMessage[];
}

const FROZEN_EMITTED_AT = "2026-04-22T12:00:00.000Z";
const __dirname = dirname(fileURLToPath(import.meta.url));
const FIXTURE_DIR = join(__dirname, "__fixtures__");
const CHASE_MANIFEST_PATH = join(
	__dirname,
	"..",
	"..",
	"manifests",
	"chase.json",
);

interface HarnessOverrides {
	maxSeenByAccount?: Record<string, TransactionCursor>;
	requestedStreams?: readonly StreamScope[];
	resFilters?: Map<string, ReadonlySet<string> | null>;
	txState?: TransactionsStateShape;
	wantsAccounts?: boolean;
	wantsBalances?: boolean;
	wantsCurrentActivity?: boolean;
	wantsStatements?: boolean;
	wantsTransactions?: boolean;
}

function htmlMatchesAnySelector(
	html: string,
	selectors: readonly string[],
): boolean {
	const { document } = parseHTML(html);
	return selectors.some((selector) => document.querySelector(selector));
}

function evaluateAgainstFixtureDocument<T>(
	document: Document,
	url: string,
	callback: () => T,
): T {
	const documentDescriptor = Object.getOwnPropertyDescriptor(
		globalThis,
		"document",
	);
	const locationDescriptor = Object.getOwnPropertyDescriptor(
		globalThis,
		"location",
	);
	Object.defineProperty(globalThis, "document", {
		configurable: true,
		value: document,
	});
	Object.defineProperty(globalThis, "location", {
		configurable: true,
		value: { href: url },
	});
	try {
		return callback();
	} finally {
		if (documentDescriptor) {
			Object.defineProperty(globalThis, "document", documentDescriptor);
		} else {
			Reflect.deleteProperty(globalThis, "document");
		}
		if (locationDescriptor) {
			Object.defineProperty(globalThis, "location", locationDescriptor);
		} else {
			Reflect.deleteProperty(globalThis, "location");
		}
	}
}

test("income-capture interstitial is classified only from the observed authenticated checkpoint", () => {
	const html = readFileSync(
		join(FIXTURE_DIR, "dashboard-income-capture-interstitial.html"),
		"utf8",
	);
	const { document } = parseHTML(html);
	const diagnostics: DashboardDiagnostics = {
		body_preview: document.body.textContent.replace(/\s+/gu, " ").trim(),
		income_capture_description_count: 1,
		income_capture_heading_count: 1,
		title: document.title,
		url: "https://secure.chase.com/web/auth/dashboard#/dashboard/interstitial/income-capture",
	};

	assert.equal(
		classifyChaseAccountsSurface(diagnostics),
		"income_capture_interstitial",
	);
	assert.match(
		chaseNoAccountsDiagnosticMessage(classifyChaseAccountsSurface(diagnostics)),
		/captured action selector/i,
	);
	assert.equal(
		classifyChaseAccountsSurface({
			...diagnostics,
			url: "https://secure.chase.com/web/auth/dashboard#/dashboard/overview",
		}),
		"unknown",
		"the income text alone must not classify the accounts overview",
	);
	assert.equal(
		classifyChaseAccountsSurface({
			...diagnostics,
			income_capture_description_count: 0,
			body_preview: "Update Income Confirm or update your income",
		}),
		"unknown",
		"phrase-substring body text must not substitute for paragraph structure",
	);
	for (const url of [
		"http://secure.chase.com/web/auth/dashboard#/dashboard/interstitial/income-capture",
		"https://secure.chase.com:8443/web/auth/dashboard#/dashboard/interstitial/income-capture",
		"https://secure.chase.com/web/auth/dashboard?surface=income#/dashboard/interstitial/income-capture",
	]) {
		assert.equal(
			classifyChaseAccountsSurface({ ...diagnostics, url }),
			"unknown",
			`must reject ${url}`,
		);
	}
});

test("zero-account collection captures the interstitial checkpoint before emitting its matching skip", async () => {
	const html = readFileSync(
		join(FIXTURE_DIR, "dashboard-income-capture-interstitial.html"),
		"utf8",
	);
	const { document } = parseHTML(html);
	const fixtureUrl =
		"https://secure.chase.com/web/auth/dashboard#/dashboard/interstitial/income-capture";
	const events: string[] = [];
	const messages: EmittedMessage[] = [];
	const evaluation: { diagnostics: DashboardDiagnostics | null } = {
		diagnostics: null,
	};
	const page = {
		content: async (): Promise<string> => html,
		evaluate: (
			callback: (args: {
				description: string;
				heading: string;
			}) => DashboardDiagnostics,
			args: { description: string; heading: string },
		): Promise<DashboardDiagnostics> => {
			const diagnostics = evaluateAgainstFixtureDocument(
				document,
				fixtureUrl,
				() => callback(args),
			);
			evaluation.diagnostics = diagnostics;
			return Promise.resolve(diagnostics);
		},
		goto: (url: string): Promise<null> => {
			events.push(`goto:${url}`);
			return Promise.resolve(null);
		},
		locator: (): { first: () => { waitFor: () => Promise<never> } } => ({
			first: () => ({
				waitFor: async (): Promise<never> =>
					Promise.reject(new Error("account selector absent")),
			}),
		}),
	};
	const capture: CaptureSession = {
		baseDir: "/tmp/chase-income-capture-test",
		captureDom: (_page, label): Promise<void> => {
			events.push(`capture:${label}`);
			return Promise.resolve();
		},
		captureHttp: (): void => undefined,
		captureLocatorProbe: (_page, label, _probes): Promise<void> => {
			events.push(`probe:${label}`);
			return Promise.resolve();
		},
		finalize: (): void => undefined,
		keepOnSuccess: true,
		markSucceeded: (): void => undefined,
		recordRecord: (): void => undefined,
		hasRegisteredSecrets: (): boolean => false,
		registerSecrets: (): void => undefined,
		runId: "test-income-capture",
	};

	const accounts = await collectChaseAccountInventory({
		capture,
		emit: (message): Promise<void> => {
			events.push(`emit:${message.type}`);
			messages.push(message);
			return Promise.resolve();
		},
		page: page as never,
	});

	assert.deepEqual(accounts, []);
	assert.deepEqual(events, [
		"goto:https://secure.chase.com/web/auth/dashboard#/dashboard/overview",
		"capture:dashboard-income-capture-interstitial",
		"probe:dashboard-income-capture-interstitial",
		"emit:SKIP_RESULT",
	]);
	const skip = messages.find(
		(message): message is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			message.type === "SKIP_RESULT" && message.stream === "accounts",
	);
	assert.ok(skip);
	assert.equal(skip.reason, "selectors_pending");
	assert.match(skip.message, /income-capture interstitial/i);
	assert.deepEqual(skip.diagnostics, evaluation.diagnostics);
	assert.equal(evaluation.diagnostics?.income_capture_heading_count, 1);
	assert.equal(evaluation.diagnostics?.income_capture_description_count, 1);
});

test("Chase dashboard diagnostics retain interstitial counts but redact page text, title, and URL", () => {
	const redacted = redactChaseDashboardDiagnostics({
		body_preview: "CUSTOMER NAME and account ending 1234",
		income_capture_description_count: 1,
		income_capture_heading_count: 2,
		title: "Income for Customer Name",
		url: "https://secure.chase.com/dashboard?account=private",
	});

	assert.deepEqual(redacted, {
		body_preview: "",
		income_capture_description_count: 1,
		income_capture_heading_count: 2,
		title: "",
		url: "",
	});
	assert.doesNotMatch(
		JSON.stringify(redacted),
		/CUSTOMER|1234|chase\.com|private/,
	);
});

test("Chase dashboard redaction drops unknown provider diagnostic keys", () => {
	const redacted = redactChaseDashboardDiagnostics({
		body_preview: "private body",
		income_capture_description_count: 1,
		income_capture_heading_count: 1,
		title: "private title",
		url: "https://secure.chase.com/private",
		provider_secret: "must not cross the durable boundary",
	} as DashboardDiagnostics & { provider_secret: string });

	assert.deepEqual(redacted, {
		body_preview: "",
		income_capture_description_count: 1,
		income_capture_heading_count: 1,
		title: "",
		url: "",
	});
	assert.doesNotMatch(JSON.stringify(redacted), /provider_secret|private/);
});

test("Chase durable failure diagnostics keep only structural recovery facts", () => {
	const diagnostic = buildChaseDurableFailureDiagnostic(
		"qfx",
		"qfx_download_failed",
		new Error(
			"https://secure.chase.com/private/path?account=owner; header=private label",
		),
	);

	assert.deepEqual(diagnostic, {
		artifact: "qfx",
		error_class: "Error",
		failure_code: "qfx_download_failed",
	});
	assert.doesNotMatch(
		JSON.stringify(diagnostic),
		/secure\.chase\.com|private\/path|account=owner|header=private/,
	);
});

test("runTransactionsAndBalances: QFX failure emits only the allowlisted durable diagnostic", async () => {
	const { deps, messages } = makeHarness();
	const privateError =
		"https://secure.chase.com/private/path?account=owner; header=private label";
	const page = {
		getByRole: () => ({
			first: () => ({
				click: async (): Promise<never> =>
					Promise.reject(new Error(privateError)),
			}),
		}),
		goto: async (): Promise<null> => null,
		locator: () => ({
			first: () => ({
				click: async (): Promise<never> =>
					Promise.reject(new Error(privateError)),
				waitFor: async (): Promise<void> => undefined,
			}),
		}),
	} as never;

	await runTransactionsAndBalances(deps, page, [makeAccount()]);

	const skip = messages.find(
		(message): message is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			message.type === "SKIP_RESULT" &&
			message.reason === "qfx_download_failed",
	);
	assert.ok(skip);
	assert.deepEqual(skip.diagnostics, {
		account_index: 1,
		account_total: 1,
		artifact: "qfx",
		error_class: "unknown",
		failure_code: "qfx_download_failed",
	});
	assert.doesNotMatch(
		JSON.stringify(messages),
		/secure\.chase\.com|private\/path|account=owner|header=private/,
	);
});

test("income-capture checkpoint probes only observed structure and never guesses an action", () => {
	const probes = chaseLocatorProbesForLabel(
		"dashboard-income-capture-interstitial",
	);
	assert.deepEqual(
		probes.map((probe) => probe.id),
		[
			"dashboard-account-selector",
			"income-capture-heading",
			"income-capture-description",
		],
	);
	assert.deepEqual(
		probes.filter((probe) => probe.kind === "role" && probe.role === "button"),
		[],
		"no button selector is evidence-backed for this interstitial",
	);
});

test("QFX dropdown selectors support both observed Chase id families", () => {
	const oldFixture = `
    <mds-select id="select-downloadActivityOptionId"></mds-select>
    <mds-select id="select-downloadFileTypeOption"></mds-select>
  `;
	const currentFixture = `
    <mds-select id="downloadActivityOptionId"></mds-select>
    <mds-select id="downloadFileTypeOption"></mds-select>
  `;

	assert.equal(
		htmlMatchesAnySelector(oldFixture, CHASE_QFX_ACTIVITY_SELECT_SELECTORS),
		true,
	);
	assert.equal(
		htmlMatchesAnySelector(oldFixture, CHASE_QFX_FILE_TYPE_SELECT_SELECTORS),
		true,
	);
	assert.equal(
		htmlMatchesAnySelector(currentFixture, CHASE_QFX_ACTIVITY_SELECT_SELECTORS),
		true,
	);
	assert.equal(
		htmlMatchesAnySelector(
			currentFixture,
			CHASE_QFX_FILE_TYPE_SELECT_SELECTORS,
		),
		true,
	);
	assert.equal(
		htmlMatchesAnySelector(oldFixture, [CHASE_QFX_ACTIVITY_SELECT_SELECTOR]),
		true,
	);
	assert.equal(
		htmlMatchesAnySelector(currentFixture, [
			CHASE_QFX_ACTIVITY_SELECT_SELECTOR,
		]),
		true,
	);
});

test("Activity control exposes an accessible-label fallback when the CSS id churns", () => {
	const rehomedFixture = `<mds-select id="downloadActivitySelectorV3" label="Activity"></mds-select>`;

	assert.equal(
		htmlMatchesAnySelector(rehomedFixture, CHASE_QFX_ACTIVITY_SELECT_SELECTORS),
		false,
		"expected the CSS id selectors to miss a re-homed control",
	);
	const { document } = parseHTML(rehomedFixture);
	const control = document.querySelector("mds-select");
	assert.ok(control, "expected an mds-select control in the fixture");
	assert.match(
		control.getAttribute("label") ?? "",
		/activity/i,
		"expected the accessible label the combobox fallback keys on to be present",
	);
});

test("QFX form-loaded wait uses the same file-type selector family as selection", () => {
	const oldFixture = `<mds-select id="select-downloadFileTypeOption"></mds-select>`;
	const currentFixture = `<mds-select id="downloadFileTypeOption"></mds-select>`;

	assert.equal(
		htmlMatchesAnySelector(oldFixture, [CHASE_QFX_FILE_TYPE_SELECT_SELECTOR]),
		true,
	);
	assert.equal(
		htmlMatchesAnySelector(currentFixture, [
			CHASE_QFX_FILE_TYPE_SELECT_SELECTOR,
		]),
		true,
	);
	assert.equal(
		CHASE_QFX_FILE_TYPE_SELECT_SELECTOR,
		CHASE_QFX_FILE_TYPE_SELECT_SELECTORS.join(", "),
	);
});

/** Build an EmitDeps that records every emit() and emitRecord() call.
 *  capture/progress/tmpDir are unused by the helpers under test — the
 *  recording harness fills them with inert defaults. */
function makeHarness(overrides: HarnessOverrides = {}): RecordingHarness {
	const harness = makeRecordingEmit(validateRecord);
	const requestedStreams = overrides.requestedStreams ?? [
		{ name: "accounts" },
		{ name: "transactions" },
		{ name: "balances" },
		{ name: "statements" },
	];
	const requested = new Map<string, StreamScope>(
		requestedStreams.map((s) => [s.name, s]),
	);
	const deps: EmitDeps = {
		capture: null,
		emit: harness.emit,
		emitRecord: harness.emitRecord,
		emittedAt: FROZEN_EMITTED_AT,
		maxSeenByAccount: overrides.maxSeenByAccount ?? {},
		progress: (): Promise<void> => Promise.resolve(),
		requested,
		resFilters: overrides.resFilters ?? new Map(),
		tmpDir: "/tmp/pdpp-chase-test-noop",
		txState: overrides.txState ?? {},
		wantsAccounts: overrides.wantsAccounts ?? true,
		wantsBalances: overrides.wantsBalances ?? true,
		wantsCurrentActivity: overrides.wantsCurrentActivity ?? true,
		wantsStatements: overrides.wantsStatements ?? true,
		wantsTransactions: overrides.wantsTransactions ?? true,
	};
	return { deps, emitted: harness.emitted, messages: harness.protocolMessages };
}

function makeAccount(overrides: Partial<ChaseAccount> = {}): ChaseAccount {
	return {
		internal_id: "INTACC123",
		last_four: "9241",
		name: "Sapphire Preferred",
		type: "credit_card",
		...overrides,
	};
}

function makeTx(overrides: Partial<QfxTransaction> = {}): QfxTransaction {
	return {
		amount_cents: -1299,
		check_number: null,
		currency: "USD",
		date: "2026-04-10",
		fitid: "FITID-0001",
		memo: null,
		name: "STARBUCKS #42",
		reference_number: null,
		type: "DEBIT",
		...overrides,
	};
}

function makeStatementRow(overrides: Partial<StatementRow> = {}): StatementRow {
	return {
		account_reference: "...9241",
		date_delivered_raw: "Apr 13, 2026",
		doc_kind: "Statement",
		rowAnchorId:
			"accountsTable-0-row0-cell3-requestThisDocumentAnchor-download",
		rowIdx: "0",
		tableIdx: "0",
		title: "April 2026 statement",
		...overrides,
	};
}

// ─── Invariant 1: parent-before-child (accounts before transactions) ─────

test("emit order: accounts stream emits before transactions for the same run", async () => {
	const { deps, emitted } = makeHarness();
	const account = makeAccount();
	await emitAccountsStream(deps, [account]);
	await emitTransactionsForAccount(deps, account, "all", [makeTx()]);

	const accountIdx = emitted.findIndex((r) => r.stream === "accounts");
	const txIdx = emitted.findIndex((r) => r.stream === "transactions");
	assert.notEqual(accountIdx, -1, "expected an accounts record");
	assert.notEqual(txIdx, -1, "expected a transactions record");
	assert.ok(accountIdx < txIdx, "accounts must emit before transactions");
});

// ─── Invariant 2: stream-scope filters cleanly ───────────────────────────

test("emitTransactionsForAccount: iterates every dated tx — caller gates on wantsTransactions", async () => {
	// The helper itself is faithful to its input; the gate is at the
	// collect() call site (see index.ts `if (deps.wantsTransactions) ...`).
	// This test pins the helper's contract: don't silently skip when
	// wantsTransactions is false — the caller is responsible.
	const { deps, emitted } = makeHarness({ wantsTransactions: false });
	const account = makeAccount();
	await emitTransactionsForAccount(deps, account, "all", [
		makeTx(),
		makeTx({ fitid: "FITID-0002" }),
	]);
	assert.equal(emitted.filter((r) => r.stream === "transactions").length, 2);
});

test("emitAccountsStream: still emits when only accounts stream is in scope", async () => {
	const { deps, emitted } = makeHarness({
		requestedStreams: [{ name: "accounts" }],
		wantsBalances: false,
		wantsCurrentActivity: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	await emitAccountsStream(deps, [
		makeAccount(),
		makeAccount({ internal_id: "INTACC456" }),
	]);
	const accountRecords = emitted.filter((r) => r.stream === "accounts");
	assert.equal(
		accountRecords.length,
		2,
		"both accounts emit when only that stream is requested",
	);
	assert.equal(accountRecords[0]?.data.id, "INTACC123");
	assert.equal(accountRecords[1]?.data.id, "INTACC456");
});

test("emitCurrentActivityForAccount: emits pending and posted rows only to current_activity", async () => {
	const { deps, emitted } = makeHarness({
		requestedStreams: [{ name: "current_activity" }],
		wantsAccounts: false,
		wantsBalances: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	const account = makeAccount();
	const count = await emitCurrentActivityForAccount(
		deps,
		account,
		readFileSync(join(FIXTURE_DIR, "current-activity-minimal.html"), "utf8"),
	);
	assert.equal(count, 2);
	assert.equal(
		emitted.filter((r) => r.stream === "current_activity").length,
		2,
	);
	assert.equal(emitted.filter((r) => r.stream === "transactions").length, 0);
	const pending = emitted.find(
		(r) => r.stream === "current_activity" && r.data.status === "pending",
	);
	assert.ok(pending);
	assert.equal(pending.data.id, `${account.internal_id}|txn_20260514_A1`);
	assert.equal(pending.data.posted_date, null);
	assert.equal(pending.data.source, "chase_activity_ui");
});

test("chaseTimeRangeField: current_activity filters by activity_date without changing transactions", () => {
	assert.equal(chaseTimeRangeField("current_activity"), "activity_date");
	assert.equal(chaseTimeRangeField("transactions"), "date");
	assert.equal(chaseTimeRangeField("unknown_stream"), "date");
});

test("chase manifest: current_activity nullable fields are required-present", () => {
	const manifest = JSON.parse(readFileSync(CHASE_MANIFEST_PATH, "utf8")) as {
		streams?: Array<{ name?: string; schema?: { required?: string[] } }>;
	};
	const stream = manifest.streams?.find((s) => s.name === "current_activity");
	assert.ok(stream);
	const required = new Set(stream.schema?.required ?? []);
	for (const field of [
		"account_name",
		"posted_date",
		"memo",
		"ui_transaction_id",
	]) {
		assert.ok(
			required.has(field),
			`${field} must be required in manifest because Zod requires a present nullable key`,
		);
	}
});

test("chase manifest: successful manual runs have a bounded freshness window", () => {
	const manifest = JSON.parse(readFileSync(CHASE_MANIFEST_PATH, "utf8")) as {
		capabilities?: {
			refresh_policy?: {
				maximum_staleness_seconds?: number;
				recommended_mode?: string;
			};
		};
	};
	const policy = manifest.capabilities?.refresh_policy;
	assert.equal(policy?.recommended_mode, "manual");
	assert.equal(policy?.maximum_staleness_seconds, 86_400);
});

test("savePlaywrightDownload: persists via saveAs without depending on Playwright temp artifact path", async () => {
	const dir = await mkdtemp(join(tmpdir(), "pdpp-chase-download-test-"));
	try {
		const source = join(dir, "source.pdf");
		const target = join(dir, "nested", "statement.pdf");
		await writeFile(source, Buffer.from("%PDF-1.7\nfixture\n"));

		await savePlaywrightDownload(
			{
				async saveAs(path: string): Promise<void> {
					await writeFile(path, await readFile(source));
				},
			},
			target,
		);

		assert.equal(existsSync(target), true);
		assert.equal(await readFile(target, "utf8"), "%PDF-1.7\nfixture\n");
	} finally {
		await rm(dir, { recursive: true, force: true });
	}
});

test("isLikelyPdfResponseBody: accepts PDF signatures and PDF response headers", () => {
	assert.equal(
		isLikelyPdfResponseBody(Buffer.from("%PDF-1.7\nfixture\n"), {}),
		true,
	);
	assert.equal(
		isLikelyPdfResponseBody(Buffer.from("fixture"), {
			"content-type": "application/pdf",
		}),
		true,
	);
	assert.equal(
		isLikelyPdfResponseBody(Buffer.from("fixture"), {
			"content-disposition": 'attachment; filename="statement.pdf"',
		}),
		true,
	);
	assert.equal(
		isLikelyPdfResponseBody(Buffer.from("<html></html>"), {
			"content-type": "text/html",
		}),
		false,
	);
});

test("isLikelyChaseQfxResponse: accepts attachment headers and Chase download routes", () => {
	assert.equal(
		isLikelyChaseQfxResponse({
			"content-disposition": 'attachment; filename="activity.qfx"',
		}),
		true,
	);
	assert.equal(
		isLikelyChaseQfxResponse(
			{ "content-type": "text/html" },
			"https://secure.chase.com/web/auth/dashboard#/dashboard/accountDetails/downloadAccountTransactions/confirmDownloadAccountActivity;params=CARD,BAC,1212486749",
		),
		true,
	);
	assert.equal(
		isLikelyChaseQfxResponse(
			{ "content-type": "text/html" },
			"https://secure.chase.com/web/auth/dashboard",
		),
		false,
	);
});

// ─── Invariant 3: all-streams-disabled emits nothing ─────────────────────

test("all helpers over an empty input set emit nothing", async () => {
	const { deps, emitted, messages } = makeHarness({ wantsTransactions: false });
	await emitAccountsStream(deps, []);
	await emitTransactionsForAccount(deps, makeAccount(), "all", []);
	await emitTransactionsStateIfAny(deps);
	assert.equal(
		emitted.length,
		0,
		"no records emitted when there's nothing to emit",
	);
	assert.equal(messages.length, 0, "no STATE/PROGRESS messages for empty runs");
});

// ─── Invariant 4: index-only fallback when PDF download fails ────────────

test("emitStatementIndexOnly: emits a statement record with null pdf_path + null document_url", async () => {
	const { deps, emitted } = makeHarness();
	const row = makeStatementRow();
	await emitStatementIndexOnly(
		deps,
		"stmt-id-123",
		row,
		"INTACC123",
		"2026-04-13",
	);

	const stmtRecord = emitted.find((r) => r.stream === "statements");
	assert.ok(
		stmtRecord,
		"a statements record must still emit when PDF download fails",
	);
	assert.equal(stmtRecord.data.id, "stmt-id-123");
	assert.equal(stmtRecord.data.account_id, "INTACC123");
	assert.equal(stmtRecord.data.date_delivered, "2026-04-13");
	assert.equal(
		stmtRecord.data.pdf_path,
		null,
		"null pdf_path marks the fallback",
	);
	assert.equal(stmtRecord.data.pdf_sha256, null);
	assert.equal(stmtRecord.data.document_url, null);
	assert.equal(
		stmtRecord.data.title,
		row.title,
		"title survives to the index-only record",
	);
});

// ─── Invariant 5: transactions cursor propagation (MAX of seen dates) ────

test("emitTransactionsForAccount: cursor max_seen_date reflects MAX of the emitted tx dates", async () => {
	const { deps } = makeHarness();
	const account = makeAccount();
	await emitTransactionsForAccount(deps, account, "all", [
		makeTx({ date: "2026-03-15", fitid: "A" }),
		makeTx({ date: "2026-04-10", fitid: "B" }),
		makeTx({ date: "2026-02-28", fitid: "C" }),
	]);
	assert.equal(
		deps.maxSeenByAccount[account.internal_id]?.max_seen_date,
		"2026-04-10",
	);
	assert.equal(
		deps.maxSeenByAccount[account.internal_id]?.last_activity,
		"all",
	);
	assert.equal(
		deps.maxSeenByAccount[account.internal_id]?.last_fetched_at,
		FROZEN_EMITTED_AT,
	);
});

test("emitTransactionsForAccount: prior cursor is preserved when new tx dates are all older", async () => {
	const { deps } = makeHarness({
		maxSeenByAccount: {
			INTACC123: {
				max_seen_date: "2026-05-01",
				last_activity: "since_last_statement",
			},
		},
	});
	await emitTransactionsForAccount(deps, makeAccount(), "all", [
		makeTx({ date: "2026-03-01", fitid: "OLD" }),
	]);
	assert.equal(
		deps.maxSeenByAccount.INTACC123?.max_seen_date,
		"2026-05-01",
		"older tx must not regress the cursor",
	);
});

test("emitTransactionsForAccount: tx with date=null is skipped (no emit, no cursor update)", async () => {
	const { deps, emitted } = makeHarness();
	const account = makeAccount();
	await emitTransactionsForAccount(deps, account, "all", [
		makeTx({ date: null, fitid: "DATELESS" }),
	]);
	assert.equal(emitted.filter((r) => r.stream === "transactions").length, 0);
	assert.equal(
		deps.maxSeenByAccount[account.internal_id],
		undefined,
		"no cursor write for a dateless-only batch",
	);
});

test("emitNoActivityProgress: reports checked/no-activity without advancing cursor or SKIP_RESULT", async () => {
	const { deps, emitted, messages } = makeHarness({
		maxSeenByAccount: {
			INTACC123: {
				max_seen_date: "2026-04-10",
				last_activity: "since_last_statement",
			},
		},
	});
	await emitNoActivityProgress(deps, "date_range");

	assert.equal(
		emitted.length,
		0,
		"no transaction records emit for a Chase no-activity confirmation",
	);
	assert.equal(
		deps.maxSeenByAccount.INTACC123?.max_seen_date,
		"2026-04-10",
		"no-activity must not advance max_seen",
	);
	assert.equal(
		messages.filter((m) => m.type === "SKIP_RESULT").length,
		0,
		"no-activity is a checked empty result, not a failure",
	);
	assert.ok(
		messages.some(
			(m) =>
				m.type === "PROGRESS" &&
				m.stream === "transactions" &&
				m.message.includes("no activity found") &&
				m.message.includes("activity=date_range"),
		),
		"expected a no-activity progress diagnostic",
	);
});

// ─── Invariant 6: emittedAt propagates into every record's fetched_at ────

test("emittedAt propagates into accounts.fetched_at + transactions.fetched_at + statements.fetched_at", async () => {
	const { deps, emitted } = makeHarness();
	const account = makeAccount();
	await emitAccountsStream(deps, [account]);
	await emitTransactionsForAccount(deps, account, "all", [makeTx()]);
	await emitStatementIndexOnly(
		deps,
		"stmt-id",
		makeStatementRow(),
		"INTACC123",
		"2026-04-13",
	);

	for (const r of emitted) {
		assert.equal(
			r.data.fetched_at,
			FROZEN_EMITTED_AT,
			`fetched_at on stream=${r.stream} must be the frozen emittedAt, got ${String(r.data.fetched_at)}`,
		);
	}
});

// ─── Invariant 7a: accountsResFilter narrows the filtered-accounts list ──

test("filterAccountsByScope: resFilter on 'accounts' stream narrows to matching internal_ids", () => {
	const accounts = [
		makeAccount({ internal_id: "KEEP-1" }),
		makeAccount({ internal_id: "DROP-1" }),
		makeAccount({ internal_id: "KEEP-2" }),
	];
	const resFilters = new Map<string, ReadonlySet<string> | null>([
		["accounts", new Set(["KEEP-1", "KEEP-2"])],
	]);
	const { accountsResFilter, filteredAccounts } = filterAccountsByScope(
		accounts,
		resFilters,
	);
	assert.equal(filteredAccounts.length, 2);
	assert.deepEqual(
		filteredAccounts.map((a) => a.internal_id),
		["KEEP-1", "KEEP-2"],
	);
	assert.ok(accountsResFilter?.has("KEEP-1"));
	assert.ok(!accountsResFilter?.has("DROP-1"));
});

test("filterAccountsByScope: falls back to transactions res-filter when 'accounts' has none", () => {
	const accounts = [
		makeAccount({ internal_id: "A" }),
		makeAccount({ internal_id: "B" }),
	];
	const resFilters = new Map<string, ReadonlySet<string> | null>([
		["transactions", new Set(["A"])],
	]);
	const { accountsResFilter, filteredAccounts } = filterAccountsByScope(
		accounts,
		resFilters,
	);
	assert.equal(filteredAccounts.length, 1);
	assert.equal(filteredAccounts[0]?.internal_id, "A");
	assert.ok(accountsResFilter?.has("A"));
});

// ─── Invariant 7b: statement time_range skips out-of-window rows ─────────

test("statementRowOutsideTimeRange: dateIso before time_range.since returns true", () => {
	const { deps } = makeHarness({
		requestedStreams: [
			{ name: "statements", time_range: { since: "2026-03-01T00:00:00.000Z" } },
		],
	});
	assert.equal(
		statementRowOutsideTimeRange(deps, "2026-02-15"),
		true,
		"February is before March-since",
	);
	assert.equal(
		statementRowOutsideTimeRange(deps, "2026-03-01"),
		false,
		"on-boundary since is inclusive",
	);
	assert.equal(
		statementRowOutsideTimeRange(deps, "2026-04-10"),
		false,
		"after since is in-range",
	);
});

test("statementRowOutsideTimeRange: dateIso on/after time_range.until returns true (until is exclusive)", () => {
	const { deps } = makeHarness({
		requestedStreams: [
			{ name: "statements", time_range: { until: "2026-04-01T00:00:00.000Z" } },
		],
	});
	assert.equal(
		statementRowOutsideTimeRange(deps, "2026-03-31"),
		false,
		"day before until is in-range",
	);
	assert.equal(
		statementRowOutsideTimeRange(deps, "2026-04-01"),
		true,
		"on-boundary until is exclusive",
	);
	assert.equal(
		statementRowOutsideTimeRange(deps, "2026-05-10"),
		true,
		"after until is out-of-range",
	);
});

test("statementRowOutsideTimeRange: null dateIso is always considered in-range", () => {
	const { deps } = makeHarness({
		requestedStreams: [
			{
				name: "statements",
				time_range: {
					since: "2026-03-01T00:00:00.000Z",
					until: "2026-04-01T00:00:00.000Z",
				},
			},
		],
	});
	// Null date can't be compared — we keep the row rather than silently drop it,
	// so the PDF's content-addressed path is still the single source of truth
	// and a bad date parse doesn't hide a statement that exists.
	assert.equal(statementRowOutsideTimeRange(deps, null), false);
});

// ─── Invariant 8: transactions STATE is emitted iff there's something to say ─

test("emitTransactionsStateIfAny: emits STATE with per_account cursor when txs were emitted", async () => {
	const { deps, messages } = makeHarness({
		maxSeenByAccount: {
			INTACC123: {
				max_seen_date: "2026-04-10",
				last_activity: "all",
				last_fetched_at: FROZEN_EMITTED_AT,
			},
		},
	});
	await emitTransactionsStateIfAny(deps);
	const stateMsg = messages.find((m) => m.type === "STATE");
	assert.ok(stateMsg, "STATE must emit when per-account cursor is non-empty");
	assert.equal(stateMsg.stream, "transactions");
	assert.deepEqual(stateMsg.cursor, {
		per_account: {
			INTACC123: {
				max_seen_date: "2026-04-10",
				last_activity: "all",
				last_fetched_at: FROZEN_EMITTED_AT,
			},
		},
	});
});

test("emitTransactionsStateIfAny: skipped when wantsTransactions=false (avoids clobbering prior STATE)", async () => {
	const { deps, messages } = makeHarness({
		maxSeenByAccount: {
			INTACC123: { max_seen_date: "2026-04-10" },
		},
		wantsTransactions: false,
	});
	await emitTransactionsStateIfAny(deps);
	assert.equal(
		messages.length,
		0,
		"don't emit STATE when the client didn't ask for transactions",
	);
});

// ─── Invariant 9: current_activity routing on dashboard overview ─────────
//
// `runCurrentActivity` is the wiring under audit for the failing run on
// 2026-05-15. It takes pre-captured dashboard HTML (no Page) so the routing
// decision can be unit-tested without Playwright. Three cases must be
// distinguished, with different observable outputs.

test("runCurrentActivity: single account + parseable overview HTML → emits rows and STATE", async () => {
	const { deps, emitted, messages } = makeHarness({
		requestedStreams: [{ name: "current_activity" }],
		wantsAccounts: false,
		wantsBalances: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	const html = readFileSync(
		join(FIXTURE_DIR, "current-activity-dashboard-overview-real.html"),
		"utf8",
	);
	const account = makeAccount({
		internal_id: "1212486749",
		name: "Sapphire Preferred (...9241)",
	});
	await runCurrentActivity(deps, html, [account]);

	// Records: one per MDS row (5 from the real-capture extract).
	const activityRecords = emitted.filter(
		(r) => r.stream === "current_activity",
	);
	assert.equal(
		activityRecords.length,
		5,
		"expected 5 emitted rows from the dashboard overview extract",
	);
	for (const r of activityRecords) {
		assert.equal(
			r.data.account_id,
			"1212486749",
			"all overview rows attributed to the single filtered account",
		);
		assert.equal(r.data.source, "chase_activity_ui");
	}

	// No SKIP_RESULT in this branch; STATE must be present.
	const skips = messages.filter((m) => m.type === "SKIP_RESULT");
	assert.equal(
		skips.length,
		0,
		"single-account + parseable rows: no SKIP_RESULT",
	);
	const state = messages.find(
		(m) => m.type === "STATE" && m.stream === "current_activity",
	);
	assert.ok(state, "STATE for current_activity must emit at end of branch");

	// A successful, populated enumeration must declare full-scan coverage:
	// considered = covered = the parsed row count, so the Collection Report
	// proves `complete` instead of leaving current_activity at `unknown`
	// forever (the reported defect for run_1786335882008).
	const coverage = messages.find(
		(m): m is Extract<EmittedMessage, { type: "DETAIL_COVERAGE" }> =>
			m.type === "DETAIL_COVERAGE" && m.stream === "current_activity",
	);
	assert.ok(
		coverage,
		"expected a DETAIL_COVERAGE message for current_activity on a successful populated scan",
	);
	assert.equal(
		coverage.state_stream,
		"current_activity",
		"full-scan coverage is self-referential",
	);
	assert.equal(
		coverage.considered,
		5,
		"considered must equal the enumerated row count",
	);
	assert.equal(
		coverage.covered,
		5,
		"covered must equal considered on a full-scan stream",
	);
	assert.deepEqual(
		coverage.required_keys,
		[],
		"full-scan coverage carries no per-key detail lane",
	);
	assert.deepEqual(coverage.hydrated_keys, []);
});

test("runCurrentActivity: multiple filtered accounts → ambiguous_multi_account_overview SKIP, zero records", async () => {
	const { deps, emitted, messages } = makeHarness({
		requestedStreams: [{ name: "current_activity" }],
		wantsAccounts: false,
		wantsBalances: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	const html = readFileSync(
		join(FIXTURE_DIR, "current-activity-dashboard-overview-real.html"),
		"utf8",
	);
	// Two accounts present; even though the overview HTML has rows, attribution
	// is ambiguous because the MDS table aggregates across accounts.
	const a = makeAccount({ internal_id: "A1", name: "Account A" });
	const b = makeAccount({ internal_id: "B2", name: "Account B" });
	await runCurrentActivity(deps, html, [a, b]);

	assert.equal(
		emitted.filter((r) => r.stream === "current_activity").length,
		0,
		"must NOT emit records when attribution is ambiguous (no false-attribution to first account)",
	);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT" && m.stream === "current_activity",
	);
	assert.ok(
		skip,
		"expected SKIP_RESULT for current_activity in multi-account case",
	);
	assert.equal(skip.reason, "ambiguous_multi_account_overview");
	assert.match(skip.message, /multiple accounts/i);
	assert.equal(
		(skip.diagnostics as { account_count: number } | undefined)?.account_count,
		2,
	);
	// STATE still emits so the run records that current_activity was visited.
	const state = messages.find(
		(m) => m.type === "STATE" && m.stream === "current_activity",
	);
	assert.ok(state);
});

test("runCurrentActivity: empty filteredAccounts → no-op (no SKIP, no STATE)", async () => {
	const { deps, emitted, messages } = makeHarness({
		requestedStreams: [{ name: "current_activity" }],
		wantsAccounts: false,
		wantsBalances: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	await runCurrentActivity(deps, "<html><body></body></html>", []);
	assert.equal(emitted.length, 0);
	assert.equal(messages.length, 0);
});

test("runCurrentActivity: single account + broken-surface HTML → selectors_pending SKIP with overview-accurate message", async () => {
	const { deps, emitted, messages } = makeHarness({
		requestedStreams: [{ name: "current_activity" }],
		wantsAccounts: false,
		wantsBalances: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	// Broken surface fixture mirrors the QFX-download-page DOM that the pre-fix
	// wiring was scraping. parseCurrentActivityDom returns 0 rows from it; the
	// SKIP_RESULT must reference the dashboard OVERVIEW (the actual target
	// surface), not the old misleading "Chase account activity DOM" wording.
	const html = readFileSync(
		join(FIXTURE_DIR, "current-activity-download-form-no-rows.html"),
		"utf8",
	);
	const account = makeAccount({
		internal_id: "1212486749",
		name: "Sapphire Preferred (...9241)",
	});
	await runCurrentActivity(deps, html, [account]);

	assert.equal(
		emitted.filter((r) => r.stream === "current_activity").length,
		0,
	);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT" && m.stream === "current_activity",
	);
	assert.ok(skip);
	assert.equal(skip.reason, "selectors_pending");
	assert.match(
		skip.message,
		/dashboard overview/i,
		"selectors_pending must reference the dashboard overview (the actual scraped surface)",
	);
	assert.doesNotMatch(
		skip.message,
		/account activity DOM/i,
		"the misleading 'Chase account activity DOM' wording must be gone",
	);
	assert.equal(
		(skip.diagnostics as { account_count: number } | undefined)?.account_count,
		1,
		"diagnostics carry only non-PII account count",
	);
});

test("runCurrentActivity: parser-zero diagnostic is persisted without changing selectors_pending", async () => {
	const { deps, messages } = makeHarness({
		requestedStreams: [{ name: "current_activity" }],
		wantsAccounts: false,
		wantsBalances: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	const surfaceDiagnostic = buildBrowserSurfaceDiagnostic({
		activityTableMarkerCount: 1,
		dashboardMarkerCount: 1,
		kind: "chase_current_activity",
		managedSurface: "unknown",
		parserCount: 0,
		readCount: 2,
		route: "expected",
		waitOutcome: "timed_out",
	});
	assert.ok(surfaceDiagnostic);

	await runCurrentActivity(
		deps,
		"<table></table>",
		[makeAccount()],
		surfaceDiagnostic,
	);

	const skip = messages.find(
		(message): message is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			message.type === "SKIP_RESULT" && message.stream === "current_activity",
	);
	assert.ok(skip);
	assert.equal(skip.reason, "selectors_pending");
	assert.deepEqual(
		(skip.diagnostics as { browser_surface?: unknown }).browser_surface,
		surfaceDiagnostic,
		"the durable skip keeps only the shared structural diagnostic",
	);

	// An interrupted/failed scan (zero rows is indistinguishable from a parse
	// failure here) must NEVER fabricate coverage — proving 15 records were
	// "retained" on a prior successful run says nothing about THIS run's
	// boundary, so a selectors_pending skip must carry no DETAIL_COVERAGE.
	const coverage = messages.find(
		(m) => m.type === "DETAIL_COVERAGE" && m.stream === "current_activity",
	);
	assert.equal(
		coverage,
		undefined,
		"selectors_pending must never emit DETAIL_COVERAGE (no false coverage)",
	);
});

test("runCurrentActivity: ambiguous multi-account skip never emits DETAIL_COVERAGE (no false coverage)", async () => {
	const { deps, messages } = makeHarness({
		requestedStreams: [{ name: "current_activity" }],
		wantsAccounts: false,
		wantsBalances: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	const html = readFileSync(
		join(FIXTURE_DIR, "current-activity-dashboard-overview-real.html"),
		"utf8",
	);
	const a = makeAccount({ internal_id: "A1", name: "Account A" });
	const b = makeAccount({ internal_id: "B2", name: "Account B" });
	await runCurrentActivity(deps, html, [a, b]);

	const coverage = messages.find(
		(m) => m.type === "DETAIL_COVERAGE" && m.stream === "current_activity",
	);
	assert.equal(
		coverage,
		undefined,
		"attribution is ambiguous, not proven — ambiguous_multi_account_overview must never emit DETAIL_COVERAGE",
	);
});

test("runCurrentActivity: empty filteredAccounts no-op never emits DETAIL_COVERAGE (no false coverage)", async () => {
	const { deps, messages } = makeHarness({
		requestedStreams: [{ name: "current_activity" }],
		wantsAccounts: false,
		wantsBalances: false,
		wantsStatements: false,
		wantsTransactions: false,
	});
	await runCurrentActivity(deps, "<html><body></body></html>", []);

	const coverage = messages.find(
		(m) => m.type === "DETAIL_COVERAGE" && m.stream === "current_activity",
	);
	assert.equal(
		coverage,
		undefined,
		"no accounts in scope means nothing was enumerated — no coverage to declare",
	);
});

const REFERENCE_DATE_ISO = "2026-07-10";

test("snapshotDashboardHtmlForCurrentActivity: parseable HTML on first read is accepted without waiting on the locator", async () => {
	// A live run proved the row-wait locator can time out for its full budget
	// even when page.content() was already parseable the moment the wait
	// began — the locator and the parser can disagree. The locator must never
	// be consulted when the immediate parse already yields rows.
	let locatorCalled = false;
	const page = {
		locator(selector: string) {
			locatorCalled = true;
			assert.equal(selector, CHASE_CURRENT_ACTIVITY_ROW_SELECTOR);
			return {
				first() {
					return {
						waitFor() {
							return Promise.reject(
								new Error(
									"locator must not be consulted when the immediate parse has rows",
								),
							);
						},
					};
				},
			};
		},
		content() {
			return Promise.resolve(
				readFileSync(
					join(FIXTURE_DIR, "current-activity-dashboard-overview-real.html"),
					"utf8",
				),
			);
		},
		url() {
			return "https://secure.chase.com/web/auth/dashboard#/dashboard/overview";
		},
	};

	const snapshot = await snapshotDashboardHtmlForCurrentActivity(
		page,
		REFERENCE_DATE_ISO,
	);

	assert.equal(
		locatorCalled,
		false,
		"the row-wait locator must not be consulted when content() is already parseable",
	);
	assert.equal(snapshot.rowSurfaceReady, true);
	assert.match(snapshot.html, /mds-activity-table__row/);
});

test("snapshotDashboardHtmlForCurrentActivity: empty first read falls back to the bounded row-wait, then re-parses", async () => {
	let waited = false;
	let secondReadRequested = false;
	const page = {
		locator(selector: string) {
			assert.equal(selector, CHASE_CURRENT_ACTIVITY_ROW_SELECTOR);
			return {
				first() {
					return {
						waitFor(options: { state: string; timeout: number }) {
							assert.equal(options.state, "attached");
							assert.ok(options.timeout > 0);
							waited = true;
							return Promise.resolve();
						},
					};
				},
			};
		},
		content() {
			if (!waited) {
				secondReadRequested = false;
				return Promise.resolve(
					readFileSync(
						join(FIXTURE_DIR, "current-activity-download-form-no-rows.html"),
						"utf8",
					),
				);
			}
			secondReadRequested = true;
			return Promise.resolve(
				readFileSync(
					join(FIXTURE_DIR, "current-activity-dashboard-overview-real.html"),
					"utf8",
				),
			);
		},
		url() {
			return "https://secure.chase.com/web/auth/dashboard#/dashboard/overview";
		},
	};

	const snapshot = await snapshotDashboardHtmlForCurrentActivity(
		page,
		REFERENCE_DATE_ISO,
	);

	assert.equal(
		waited,
		true,
		"must fall back to the row-wait when the immediate parse yields zero rows",
	);
	assert.equal(
		secondReadRequested,
		true,
		"must re-read content() after the wait resolves",
	);
	assert.equal(
		snapshot.rowSurfaceReady,
		true,
		"rowSurfaceReady must reflect the re-parsed html, not just the wait resolving",
	);
	assert.match(snapshot.html, /mds-activity-table__row/);
});

test("snapshotDashboardHtmlForCurrentActivity: rowSurfaceReady is false when the wait resolves but the re-parsed html still has zero rows", async () => {
	// Proves rowSurfaceReady tracks the PARSED result, not merely whether the
	// locator promise resolved — a locator resolving attached() does not
	// guarantee parseCurrentActivityDom finds rows in whatever page.content()
	// returns afterward (e.g. a different row shape or a race).
	const page = {
		locator(selector: string) {
			assert.equal(selector, CHASE_CURRENT_ACTIVITY_ROW_SELECTOR);
			return {
				first() {
					return {
						waitFor() {
							return Promise.resolve();
						},
					};
				},
			};
		},
		content() {
			return Promise.resolve(
				readFileSync(
					join(FIXTURE_DIR, "current-activity-download-form-no-rows.html"),
					"utf8",
				),
			);
		},
		url() {
			return "https://secure.chase.com/web/auth/dashboard#/download-account-activity";
		},
	};

	const snapshot = await snapshotDashboardHtmlForCurrentActivity(
		page,
		REFERENCE_DATE_ISO,
	);

	assert.equal(snapshot.rowSurfaceReady, false);
	assert.match(snapshot.html, /Download account activity/);
	assert.equal(
		snapshot.diagnostic.route,
		"unknown",
		"the committed QFX download-form fixture is not the overview route",
	);
	assert.equal(snapshot.diagnostic.posture, "unexpected");
	assert.equal(
		snapshot.diagnostic.verified_empty_marker_count,
		0,
		"no source-verified empty marker is claimed",
	);
});

test("snapshotDashboardHtmlForCurrentActivity: unexpected route gets one fresh dashboard navigation before declaring a gap", async () => {
	let navigated = false;
	let waitedForRows = false;
	const page = {
		goto(
			url: string,
			options: { state?: string; timeout: number; waitUntil: string },
		) {
			assert.equal(
				url,
				"https://secure.chase.com/web/auth/dashboard#/dashboard/overview",
			);
			assert.equal(options.waitUntil, "domcontentloaded");
			navigated = true;
			return Promise.resolve();
		},
		locator(selector: string) {
			return {
				count: () => Promise.resolve(5),
				first() {
					return {
						waitFor(options: { state: string; timeout: number }) {
							if (selector === CHASE_CURRENT_ACTIVITY_ROW_SELECTOR) {
								waitedForRows = true;
								return Promise.reject(
									new Error("rows were absent on the stale document"),
								);
							}
							assert.notEqual(selector, CHASE_CURRENT_ACTIVITY_ROW_SELECTOR);
							assert.equal(options.state, "attached");
							return Promise.resolve();
						},
					};
				},
			};
		},
		content() {
			return Promise.resolve(
				navigated
					? readFileSync(
							join(
								FIXTURE_DIR,
								"current-activity-dashboard-overview-real.html",
							),
							"utf8",
						)
					: readFileSync(
							join(FIXTURE_DIR, "current-activity-download-form-no-rows.html"),
							"utf8",
						),
			);
		},
		url() {
			return navigated
				? "https://secure.chase.com/web/auth/dashboard#/dashboard/overview"
				: "https://secure.chase.com/web/auth/dashboard#/dashboard/accountDetails/downloadAccountTransactions";
		},
	};

	const snapshot = await snapshotDashboardHtmlForCurrentActivity(
		page,
		REFERENCE_DATE_ISO,
	);

	assert.equal(waitedForRows, true);
	assert.equal(navigated, true);
	assert.equal(snapshot.rowSurfaceReady, true);
	assert.equal(snapshot.diagnostic.read_count, 3);
	assert.equal(snapshot.diagnostic.route, "expected");
	assert.equal(snapshot.diagnostic.wait_outcome, "unknown");
	assert.match(snapshot.html, /mds-activity-table__row/);
});

test("snapshotDashboardHtmlForCurrentActivity: parser-zero expected route gets one fresh dashboard navigation", async () => {
	let navigated = false;
	let rowWaits = 0;
	const page = {
		goto(url: string, options: { timeout: number; waitUntil: string }) {
			assert.equal(
				url,
				"https://secure.chase.com/web/auth/dashboard#/dashboard/overview",
			);
			assert.equal(options.waitUntil, "domcontentloaded");
			navigated = true;
			return Promise.resolve();
		},
		locator(selector: string) {
			return {
				count: () => Promise.resolve(navigated ? 5 : 0),
				first() {
					return {
						waitFor() {
							if (selector === CHASE_CURRENT_ACTIVITY_ROW_SELECTOR) {
								rowWaits += 1;
								return Promise.reject(
									new Error("row locator did not prove readiness"),
								);
							}
							return Promise.resolve();
						},
					};
				},
			};
		},
		content() {
			return Promise.resolve(
				readFileSync(
					join(
						FIXTURE_DIR,
						navigated
							? "current-activity-dashboard-overview-real.html"
							: "current-activity-download-form-no-rows.html",
					),
					"utf8",
				),
			);
		},
		url() {
			return "https://secure.chase.com/web/auth/dashboard#/dashboard/overview";
		},
	};

	const snapshot = await snapshotDashboardHtmlForCurrentActivity(
		page,
		REFERENCE_DATE_ISO,
	);

	assert.equal(rowWaits, 1);
	assert.equal(navigated, true);
	assert.equal(snapshot.rowSurfaceReady, true);
	assert.equal(snapshot.diagnostic.read_count, 3);
	assert.equal(snapshot.diagnostic.route, "expected");
	assert.equal(snapshot.diagnostic.wait_outcome, "unknown");
	assert.match(snapshot.html, /mds-activity-table__row/);
});

test("snapshotDashboardHtmlForCurrentActivity: parser-zero expected route stays parser-zero when refresh remains empty", async () => {
	let navigated = false;
	const emptyHtml = readFileSync(
		join(FIXTURE_DIR, "current-activity-known-table-parser-zero.html"),
		"utf8",
	);
	const page = {
		goto() {
			navigated = true;
			return Promise.resolve();
		},
		locator(selector: string) {
			return {
				count: () => Promise.resolve(0),
				first() {
					return {
						waitFor() {
							if (selector === CHASE_CURRENT_ACTIVITY_ROW_SELECTOR) {
								return Promise.resolve();
							}
							return Promise.resolve();
						},
					};
				},
			};
		},
		content() {
			return Promise.resolve(emptyHtml);
		},
		url() {
			return "https://secure.chase.com/web/auth/dashboard#/dashboard/overview";
		},
	};

	const snapshot = await snapshotDashboardHtmlForCurrentActivity(
		page,
		REFERENCE_DATE_ISO,
	);

	assert.equal(navigated, true);
	assert.equal(snapshot.rowSurfaceReady, false);
	assert.equal(snapshot.diagnostic.parser_count, 0);
	assert.equal(snapshot.diagnostic.posture, "parser_zero");
	assert.equal(snapshot.diagnostic.verified_empty_marker_count, 0);
});

test("snapshotDashboardHtmlForCurrentActivity: a known table with changed rows is parser_zero", async () => {
	const page = {
		locator(selector: string) {
			assert.equal(selector, CHASE_CURRENT_ACTIVITY_ROW_SELECTOR);
			return {
				count() {
					return Promise.resolve(0);
				},
				first() {
					return { waitFor: () => Promise.resolve() };
				},
			};
		},
		content() {
			return Promise.resolve(
				readFileSync(
					join(FIXTURE_DIR, "current-activity-known-table-parser-zero.html"),
					"utf8",
				),
			);
		},
		url() {
			return "https://secure.chase.com/web/auth/dashboard#/dashboard/overview";
		},
	};

	const snapshot = await snapshotDashboardHtmlForCurrentActivity(
		page,
		REFERENCE_DATE_ISO,
	);

	assert.equal(snapshot.rowSurfaceReady, false);
	assert.equal(snapshot.diagnostic.route, "expected");
	assert.equal(snapshot.diagnostic.dashboard_marker_count, 1);
	assert.equal(snapshot.diagnostic.activity_table_marker_count, 1);
	assert.equal(snapshot.diagnostic.target_count, 0);
	assert.equal(snapshot.diagnostic.parser_count, 0);
	assert.equal(snapshot.diagnostic.posture, "parser_zero");
});

test("snapshotDashboardHtmlForCurrentActivity: falls through when recent-activity rows never appear", async () => {
	const page = {
		locator(selector: string) {
			assert.equal(selector, CHASE_CURRENT_ACTIVITY_ROW_SELECTOR);
			return {
				first() {
					return {
						waitFor() {
							return Promise.reject(
								new Error("timeout waiting for recent activity rows"),
							);
						},
					};
				},
			};
		},
		content() {
			return Promise.resolve(
				readFileSync(
					join(FIXTURE_DIR, "current-activity-download-form-no-rows.html"),
					"utf8",
				),
			);
		},
		url() {
			return "https://secure.chase.com/web/auth/dashboard#/download-account-activity";
		},
	};

	const snapshot = await snapshotDashboardHtmlForCurrentActivity(
		page,
		REFERENCE_DATE_ISO,
	);

	assert.equal(snapshot.rowSurfaceReady, false);
	assert.match(snapshot.html, /Download account activity/);
});
