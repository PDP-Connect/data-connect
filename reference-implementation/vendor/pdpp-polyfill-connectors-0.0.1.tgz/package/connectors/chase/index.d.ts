#!/usr/bin/env node
import type { Page } from "playwright";
import { isLikelyPdfResponseBody as isLikelyPdfResponseBodyShared } from "../../src/browser-artifact-response.ts";
import { type BrowserSurfaceDiagnostic, type BrowserSurfaceManagedState } from "../../src/browser-surface-diagnostic.ts";
import { type BrowserCollectContext, type DetailGapMessage } from "../../src/connector-runtime.ts";
import { type FingerprintCursor } from "../../src/fingerprint-cursor.ts";
import type { LocatorProbe } from "../../src/fixture-capture.ts";
import { type StatementHydration, type StatementHydrationCursor } from "../../src/statement-hydration-carry-forward.ts";
import { extractFromQfx } from "./parsers.ts";
import type { ActivityKind, ChaseAccount, DashboardDiagnostics, StatementRow, TransactionCursor, TransactionsStateShape } from "./types.ts";
export declare const CHASE_CURRENT_ACTIVITY_ROW_SELECTOR = "tr.mds-activity-table__row[data-values], tr[id*=\"activity\" i][data-values]";
export declare const CHASE_QFX_ACTIVITY_SELECT_SELECTORS: readonly ["#downloadActivityOptionId", "#select-downloadActivityOptionId"];
export declare const CHASE_QFX_FILE_TYPE_SELECT_SELECTORS: readonly ["#downloadFileTypeOption", "#select-downloadFileTypeOption"];
export declare const CHASE_QFX_FILE_TYPE_SELECT_SELECTOR: string;
export declare const CHASE_QFX_ACTIVITY_SELECT_SELECTOR: string;
export declare function chaseTimeRangeField(stream: string): string;
export type ChaseAccountsSurface = "income_capture_interstitial" | "unknown";
/**
 * Identify the exact authenticated dashboard interstitial observed in a
 * failed account-enumeration run. This is deliberately stricter than a
 * route-only check: the route, title, and two visible structural markers must
 * all agree before collection treats the page as the income-capture surface.
 *
 * No control is inferred here. The observed capture does not identify a
 * dismissal or deferral affordance, so callers preserve selectors_pending and
 * retain a dedicated checkpoint for the next evidence-backed repair.
 */
export declare function classifyChaseAccountsSurface(diagnostics: DashboardDiagnostics | null): ChaseAccountsSurface;
export declare function chaseNoAccountsDiagnosticMessage(surface: ChaseAccountsSurface): string;
/** Classify with the live page facts, but persist only structural counts. */
export declare function redactChaseDashboardDiagnostics(diagnostics: DashboardDiagnostics | null): DashboardDiagnostics | null;
export type ChaseDurableFailureArtifact = "qfx" | "statement";
export type ChaseDurableFailureCode = "qfx_download_failed" | "qfx_parse_failed" | "row_exception" | "statements_scrape_failed";
/** Durable failure evidence is a closed structural shape; error text stays local. */
export declare function buildChaseDurableFailureDiagnostic(artifact: ChaseDurableFailureArtifact, failureCode: ChaseDurableFailureCode, error: unknown): {
    artifact: ChaseDurableFailureArtifact;
    error_class: "Error" | "unknown";
    failure_code: ChaseDurableFailureCode;
};
interface CurrentActivitySnapshotPage {
    content: () => Promise<string>;
    goto?: (url: string, options: {
        timeout: number;
        waitUntil: "domcontentloaded";
    }) => Promise<unknown>;
    locator: (selector: string) => {
        count?: () => Promise<number>;
        first: () => {
            waitFor: (options: {
                state: "attached";
                timeout: number;
            }) => Promise<unknown>;
        };
    };
    url: () => string;
}
/** Never retain a final URL: classify the known overview route in memory. */
export declare function classifyChaseCurrentActivityRoute(value: string): BrowserSurfaceDiagnostic["route"];
/**
 * Snapshot the dashboard overview DOM for `current_activity`.
 *
 * Parse-first: the serialized DOM bytes are read and parsed immediately,
 * because the parser's own verdict on those exact bytes is the only
 * authoritative readiness signal — a separate locator wait can disagree with
 * what `page.content()` actually yields. The row-selector wait below is only
 * a bounded retry trigger for the still-hydrating case, not a proof; after it
 * resolves (or times out) the content is re-read and re-parsed, and
 * `rowSurfaceReady` always reflects that final parse, never the locator alone.
 * Zero rows after the fallback does not prove a provider empty state — it
 * still routes to `selectors_pending` in the caller.
 */
export declare function snapshotDashboardHtmlForCurrentActivity(page: CurrentActivitySnapshotPage, referenceDateIso: string, managedSurface?: BrowserSurfaceManagedState): Promise<{
    diagnostic: BrowserSurfaceDiagnostic;
    html: string;
    rowSurfaceReady: boolean;
}>;
/**
 * Click the QFX Download button. `mds-button` is a custom element — its
 * label and interactive target live in shadow DOM, so a host-element CSS
 * click (`mds-button#download`) is only as reliable as the host's own
 * click-forwarding. Mirror the two-tier strategy already used for the
 * Activity/File Type controls: CSS id first, then the semantic role
 * locator (`getByRole` pierces shadow DOM), so a host element that resolves
 * but does not forward the click to its shadow-DOM button still finds the
 * button via its accessible role.
 */
export declare function clickDownloadButton(page: Page): Promise<void>;
export declare function isLikelyChaseQfxResponse(headers: Record<string, string>, url?: string): boolean;
export declare const isLikelyPdfResponseBody: typeof isLikelyPdfResponseBodyShared;
export declare function chaseLocatorProbesForLabel(label: string): readonly LocatorProbe[];
export type EmitFn = BrowserCollectContext["emit"];
export type EmitRecordFn = BrowserCollectContext["emitRecord"];
export type ProgressFn = BrowserCollectContext["progress"];
export type CaptureDep = BrowserCollectContext["capture"];
export type RequestedScopes = BrowserCollectContext["requested"];
/** Per-run dependency bag threaded through every emit-path helper. Mirrors
 *  the amazon pattern: one stable bag so collect() becomes pure
 *  orchestration and the helpers are individually testable. */
export interface EmitDeps {
    capture: CaptureDep;
    /** Per-row fingerprint cursor for `current_activity` (excludes the
     *  run-clock `fetched_at`). One cursor for the whole stream because row
     *  ids (`account_id|ui_transaction_id` or an account-scoped fallback
     *  hash) are globally unique. Optional so legacy callers/tests emit
     *  unconditionally. */
    currentActivityFingerprintCursor?: FingerprintCursor | undefined;
    emit: EmitFn;
    emitRecord: EmitRecordFn;
    emittedAt: string;
    maxSeenByAccount: Record<string, TransactionCursor>;
    progress: ProgressFn;
    requested: RequestedScopes;
    resFilters: Map<string, ReadonlySet<string> | null>;
    /** Pending account-level detail gaps the runtime served this run at START,
     *  keyed by `account_id` → served `gap_id`. When the normal QFX pass reaches
     *  one of these accounts (hydrated or source-limited no-activity), the
     *  connector emits `DETAIL_GAP_RECOVERED` with the served `gap_id` so the
     *  durable gap moves to `recovered` instead of being reset to `pending` by
     *  runtime cleanup. Empty on an ordinary run with no served gaps. */
    servedAccountGaps?: ReadonlyMap<string, string> | undefined;
    /** Pending `statements` PDF gaps the runtime served this run at START,
     *  keyed by statement `id` → served `gap_id`. When a served statement's
     *  PDF is hydrated again this run, the connector emits `DETAIL_GAP_RECOVERED`
     *  with the served `gap_id` so the durable gap moves to `recovered` instead
     *  of staying `pending` forever. Empty on an ordinary run with no served
     *  statement gaps. */
    servedStatementGaps?: ReadonlyMap<string, string> | undefined;
    tmpDir: string;
    /** Per-transaction fingerprint cursor (excludes the run-clock
     *  `fetched_at`). Shared across all accounts for the whole transactions
     *  stream because record ids (`account_id|fitid`) are globally unique.
     *  Optional so legacy callers/tests emit unconditionally. */
    transactionsFingerprintCursor?: FingerprintCursor | undefined;
    txState: TransactionsStateShape;
    wantsAccounts: boolean;
    wantsBalances: boolean;
    wantsCurrentActivity: boolean;
    wantsStatements: boolean;
    wantsTransactions: boolean;
}
/**
 * Pick the res filter that applies to per-account work. Falls back
 * across accounts → transactions → balances so a client asking for just
 * one of those still narrows the account enumeration.
 */
export declare function filterAccountsByScope(accounts: ChaseAccount[], resFilters: Map<string, ReadonlySet<string> | null>): {
    accountsResFilter: ReadonlySet<string> | null;
    filteredAccounts: ChaseAccount[];
};
/**
 * Emit one `accounts` record per filtered account. Balance fields are
 * null here; they're populated later from QFX LEDGERBAL/AVAILBAL as
 * separate `balances` records.
 *
 * Every field except `fetched_at` is stable across runs (the account
 * identity; all balance fields are hardcoded `null` and live in the
 * `balances` stream). Without a gate, the run-clock `fetched_at` forced
 * a fresh version of every account on every run (~20 versions/record of
 * pure run-clock churn). The fingerprint cursor excludes `fetched_at`,
 * so an account re-emits only when its identity actually changes.
 *
 * Emits a per-stream STATE carrying the fingerprint map so the next run
 * can suppress unchanged accounts. When no cursor is supplied
 * (legacy callers/tests) the records emit unconditionally and no STATE
 * is written.
 */
export declare function emitAccountsStream(deps: EmitDeps, filteredAccounts: readonly ChaseAccount[], fingerprintCursor?: FingerprintCursor): Promise<void>;
/**
 * Parse the prior `accounts` STATE cursor's `fingerprints` map. Keyed by
 * Chase internal account id. Legacy/missing cursors decode to an empty
 * map; the first post-deploy run rebuilds it and re-emits every account
 * exactly once.
 */
export declare function readPriorAccountFingerprints(state: Record<string, unknown>): Map<string, string>;
/**
 * Parse the prior `statements` STATE cursor's `fingerprints` map. Keyed
 * by statement `id` (hash of account_reference|date|title). Legacy
 * cursors (only `{ fetched_at }`) decode to an empty map, so the first
 * post-deploy run rebuilds the map and re-emits every statement exactly
 * once.
 */
export declare function readPriorStatementFingerprints(state: Record<string, unknown>): Map<string, string>;
/**
 * Parse the prior `current_activity` STATE cursor's `fingerprints` map.
 * Keyed by the row `id` (`account_id|ui_transaction_id`, or an
 * account-scoped fallback hash). Legacy cursors (only `{ fetched_at }`)
 * decode to an empty map, so the first post-deploy run rebuilds the map
 * and re-emits every still-listed activity row exactly once.
 */
export declare function readPriorCurrentActivityFingerprints(state: Record<string, unknown>): Map<string, string>;
/**
 * Parse the prior `transactions` STATE cursor's `fingerprints` map. Keyed
 * by transaction `id` (`account_id|fitid`). The cursor shape is
 * `{ per_account, fingerprints }`; `collect()` may also see the bare
 * inner shape (legacy state), so both `state.transactions.fingerprints`
 * and `state.fingerprints` are tolerated. Legacy cursors (only
 * `per_account`) decode to an empty map, so the first post-deploy run
 * rebuilds the map and re-emits every in-window transaction exactly once.
 */
export declare function readPriorTransactionFingerprints(state: Record<string, unknown>): Map<string, string>;
/**
 * Emit one `transactions` record per QFX tx, maintain the per-account
 * max_seen_date cursor, and skip rows with no date.
 *
 * Invariants (tested in integration.test.ts):
 *   - one emit per non-null-dated tx (dedup happens at the runtime's
 *     RECORD key layer, not here; this helper is faithful to the QFX
 *     slice it's given),
 *   - cursor's max_seen_date is the MAX of the input dates (string
 *     compare is safe on ISO yyyy-mm-dd),
 *   - emittedAt propagates into every record's fetched_at.
 */
export declare function emitTransactionsForAccount(deps: EmitDeps, account: ChaseAccount, activity: ActivityKind, transactions: ReturnType<typeof extractFromQfx>["transactions"], fingerprintCursor?: FingerprintCursor): Promise<void>;
export declare function emitCurrentActivityForAccount(deps: EmitDeps, account: ChaseAccount, html: string, fingerprintCursor?: FingerprintCursor): Promise<number>;
/**
 * True iff this statement's delivered date falls outside the
 * `statements` stream's time_range. The comparison intentionally
 * slices to yyyy-mm-dd so a user-specified `since=2025-01-01T00:00Z`
 * still includes statements delivered 2025-01-01 (the date_delivered
 * field is date-only).
 */
export declare function statementRowOutsideTimeRange(deps: EmitDeps, dateIso: string | null): boolean;
/**
 * Emit a `statements` record when the PDF could not be hydrated this run —
 * the caller still wants a record that the statement exists so the owner
 * can see it in the archive, even though this run did not fetch the bytes.
 *
 * Carry-forward: if the statement was previously hydrated, re-emit the
 * prior `document_url`/`pdf_path`/`pdf_sha256` (which point at content-
 * addressed bytes a prior run stored and that never move) instead of null.
 * A statement that was never hydrated stays all-null (honest index-only).
 * Either way the statement detail-coverage report remains the authoritative
 * record of whether PDF bytes were present this run. The carried body asserts
 * the artifact's last known location, not that this run re-verified it. This
 * stops the `value -> null` hydration-availability flap from re-versioning an
 * immutable statement.
 *
 * Gated on the per-statement fingerprint cursor (excludes `fetched_at`) so a
 * re-listed statement that is byte-identical modulo the run clock does not
 * append a fresh version every run; with carry-forward the carried body
 * matches the prior hydrated body, so the cursor suppresses the re-emit.
 */
export declare function emitStatementIndexOnly(deps: EmitDeps, id: string, row: StatementRow, accountId: string | null, dateIso: string | null, fingerprintCursor?: FingerprintCursor, hydrationCursor?: StatementHydrationCursor): Promise<StatementHydration>;
export type StatementDetailOutcome = {
    kind: "hydrated";
    id: string;
} | {
    kind: "gap";
    id: string;
    reason: DetailGapMessage["reason"];
    errorClass: string;
};
/**
 * Emit the per-run `statements` DETAIL_COVERAGE. `outcomes` is built from
 * every row `runStatements` enumerated this run. `enumerateStatementRows`
 * propagates page-content and parser failures, so `runStatements` emits its
 * `statements_scrape_failed` SKIP_RESULT and returns BEFORE reaching this
 * function on an enumeration failure. Therefore `outcomes.length === 0`
 * here means "enumeration completed and found zero statement rows," never
 * "enumeration failed." Always emits when statements are in scope — including
 * the zero-outcome steady-state case (considered: 0, covered: 0, empty key
 * sets) — so a run that legitimately enumerated its denominator to zero
 * stays measured instead of silently unreported.
 */
export declare function emitStatementDetailCoverage(deps: EmitDeps, outcomes: readonly StatementDetailOutcome[]): Promise<void>;
/**
 * Build the `statement_id → served gap_id` lookup from the pending detail
 * gaps the runtime served this run at START (`ctx.detailGaps`). Filtered to
 * Chase statement-PDF gaps — the exact shape `emitStatementDetailCoverage`
 * writes via `buildDetailGap`: `stream === "statements"`,
 * `detail_locator.kind === "chase.statement"`, and a non-empty
 * `statement_id`. Any other served gap (a different connector's locator, a
 * non-statements stream, a malformed locator) is ignored so the connector can
 * only ever recover a gap it actually understands. Sourcing the `gap_id` from
 * the served gap — never synthesizing one — is what guarantees the connector
 * cannot mark an unrelated or unserved gap recovered.
 */
export declare function buildServedStatementGapLookup(detailGaps: readonly BrowserCollectContext["detailGaps"][number][]): Map<string, string>;
/**
 * Emit `DETAIL_GAP_RECOVERED` for each served statement gap whose PDF is
 * hydrated again this run. `hydratedKeys` is the honest input: it is exactly
 * the set `emitStatementDetailCoverage` already proved hydrated
 * (`outcome.kind === "hydrated"`, driven by `isHydrated` at the download
 * site), the same predicate feeding the coverage numerator, so recovery and
 * coverage cannot drift apart. A statement whose PDF is still missing this
 * run is left on the `DETAIL_GAP` re-emit path and is never recovered here —
 * lose-no-data preserved.
 */
export declare function recoverServedStatementGaps(deps: EmitDeps, hydratedKeys: readonly string[]): Promise<void>;
/**
 * Emit the transactions STATE cursor iff we actually emitted
 * transactions this run. Skipping the emit on empty runs keeps
 * downstream state files from accumulating empty `per_account: {}`
 * entries that erase any prior cursor.
 */
export declare function emitTransactionsStateIfAny(deps: EmitDeps): Promise<void>;
/**
 * Emit the per-run DETAIL_COVERAGE for the account -> balances detail
 * fan-out, using the same `AccountDetailOutcome[]` and key derivation
 * (`accountDetailCoverageKeys`) as `emitTransactionsDetailCoverage` — both
 * ride the same per-account QFX pass, so a `hydrated` account (balance
 * emitted, or QFX parsed with no balance block per `extractBalance`'s null
 * path — rare but possible) or a `no_activity` account (Chase's no-activity
 * confirmation page never serves a QFX response, so there is no
 * LEDGERBAL/AVAILBAL block to read this run, regardless of prior runs) are
 * both real coverage of this run's balance pass, never a gap. Only a `gap`
 * (transient QFX failure) is unaccounted.
 *
 * Only emitted when balances and accounts are both in scope. Unlike
 * `emitTransactionsDetailCoverage`, this does NOT require `wantsTransactions`:
 * the QFX detail pass runs whenever either transactions or balances is in
 * scope, so a balances-only scoped run still produces `outcomes` and owes
 * balances coverage independent of transactions.
 *
 * Deliberately does NOT suppress on `outcomes.length === 0` — see
 * `accountDetailCoverageKeys` and `runTransactionsAndBalances`'s doc comment
 * for why an empty `outcomes` here always means a real resource filter
 * narrowed a genuine, non-empty account enumeration to zero eligible
 * accounts (a proven 0/0), never an unknown/session-dead scope.
 */
export declare function emitBalancesDetailCoverage(deps: EmitDeps, outcomes: readonly AccountDetailOutcome[]): Promise<void>;
export declare function emitNoActivityProgress(deps: Pick<EmitDeps, "emit">, activity: ActivityKind): Promise<void>;
export declare function collectChaseAccountInventory({ capture, emit, page, }: Pick<BrowserCollectContext, "capture" | "emit" | "page">): Promise<ChaseAccount[]>;
/**
 * Per-account outcome of the QFX (transactions/balances) detail pass. The
 * `accounts` stream is Chase's enumerated inventory — a known denominator —
 * and each account is one key considered for the per-account QFX detail
 * fetch. The runtime turns these outcomes into an honest DETAIL_COVERAGE
 * report (`required_keys` = accounts considered; `hydrated_keys` = accounts
 * the connector successfully reached; `gap_keys` = retryable failures).
 *
 * Three outcomes, deliberately distinct:
 *   - `hydrated`: QFX downloaded and parsed for this account. Includes the
 *     0-transaction parse — the account WAS reached; an empty ledger is
 *     real coverage, not a failure.
 *   - `no_activity`: Chase reported no activity for an explicit bounded
 *     window. This is source-limited completeness, not a gap.
 *   - `gap`: the QFX download or parse failed transiently. A retryable
 *     DETAIL_GAP is emitted so the next run retries this account, and the
 *     key lands in `gap_keys` — partial, not complete, and not silently
 *     dropped.
 */
export type AccountDetailOutcome = {
    kind: "hydrated";
    accountId: string;
    balanceEmitted?: boolean;
} | {
    kind: "no_activity";
    accountId: string;
    balanceEmitted?: boolean;
} | {
    kind: "gap";
    accountId: string;
    reason: DetailGapMessage["reason"];
    errorClass: string;
};
export declare function classifyNoActivityOutcome(accountId: string, activity: ActivityKind): AccountDetailOutcome;
/**
 * Build the retryable DETAIL_GAP for an account whose QFX download or parse
 * failed transiently. `record_key` is the account id — the next run's detail
 * pass retries exactly this account. Mirrors the chatgpt DETAIL_GAP contract
 * (reference_only, retryable, pending) so the runtime persists one resumable
 * gap per failed key and the per-account coverage stays honest.
 */
export declare function buildAccountDetailGap(outcome: {
    accountId: string;
    reason: DetailGapMessage["reason"];
    errorClass: string;
}): DetailGapMessage;
/**
 * Emit the per-run DETAIL_COVERAGE for the account -> transactions detail
 * fan-out. `accounts` is Chase's enumerated inventory (a known denominator),
 * so this reports honest partial-vs-complete coverage of the QFX detail pass
 * without inferring it from gaps alone:
 *   - `required_keys`: every account considered for the QFX detail fetch.
 *   - `hydrated_keys`: accounts reached, including source-limited no-activity
 *     ones (won't-backfill is coverage, never a broken signal).
 *   - `gap_keys`: accounts whose QFX failed transiently; each also carries a
 *     pending DETAIL_GAP so the runtime's coverage invariant is satisfied and
 *     the next run retries them.
 * Only emitted when transactions AND accounts are both in scope. Deliberately
 * does NOT suppress on `outcomes.length === 0` — see
 * `runTransactionsAndBalances`'s doc comment: this function's only caller
 * only ever reaches it after a completed, non-empty account enumeration, so
 * an empty `outcomes` here always means a real resource filter narrowed a
 * genuine enumeration to zero eligible accounts (a proven 0/0), never an
 * unknown denominator.
 */
export declare function emitTransactionsDetailCoverage(deps: EmitDeps, outcomes: readonly AccountDetailOutcome[]): Promise<void>;
/**
 * Build the `account_id → served gap_id` lookup from the pending detail gaps the
 * runtime served this run at START (`ctx.detailGaps`). Filtered to Chase
 * account-level transaction gaps — the exact shape `buildAccountDetailGap`
 * writes: `stream === "transactions"`, `detail_locator.kind === "chase.account"`,
 * and a non-empty `account_id`. Any other served gap (a different connector's
 * locator, a non-transactions stream, a malformed locator) is ignored so the
 * connector can only ever recover a gap it actually understands. Sourcing the
 * `gap_id` from the served gap — never synthesizing one — is what guarantees the
 * connector cannot mark an unrelated or unserved gap recovered.
 */
export declare function buildServedAccountGapLookup(detailGaps: readonly BrowserCollectContext["detailGaps"][number][]): Map<string, string>;
/**
 * Emit `DETAIL_GAP_RECOVERED` for each served account gap whose account this run
 * reached. An account is "reached" when its QFX pass produced a `hydrated`
 * outcome (parsed, including a 0-transaction ledger) or a `no_activity` outcome
 * (source-limited completeness) — both are real coverage of that account's
 * ledger for the window, mirroring how `emitTransactionsDetailCoverage` counts
 * them as `hydrated_keys`. A `gap` outcome is left on the `DETAIL_GAP` re-emit
 * path in `runTransactionsAndBalances` and is never recovered here. A served gap
 * whose account was not reached (still failing, or no longer enumerated) is left
 * untouched so the runtime's existing served-but-unrecovered reset returns it to
 * `pending` — lose-no-data preserved.
 */
export declare function recoverServedAccountGaps(deps: EmitDeps, outcomes: readonly AccountDetailOutcome[]): Promise<void>;
/**
 * Drive the per-account QFX detail pass and declare transactions + balances
 * coverage. `filteredAccounts` is only ever empty here as a genuine,
 * known-zero result: the caller returns early via `emitNoAccountsDiagnostic`
 * BEFORE reaching this function when `discoverAccounts()` itself found zero
 * accounts (session-dead/broken-enumeration, unknown scope), so an empty
 * `filteredAccounts` reaching this function always means a real resource
 * filter narrowed a genuine non-empty enumeration to zero eligible accounts
 * — exported so that distinction is provable at this exact caller boundary,
 * not just inside the unit-level DETAIL_COVERAGE builders.
 */
export declare function runTransactionsAndBalances(deps: EmitDeps, page: Page, filteredAccounts: readonly ChaseAccount[]): Promise<void>;
/**
 * Emit current_activity rows scraped from the Chase dashboard overview MDS
 * activity table (`<tr class="mds-activity-table__row" data-values=...>`),
 * which is the surface that visibly contains pending and recent posted
 * rows — verified against the captured run on 2026-05-15 in
 * `fixtures/chase/raw/2026-05-15T13-48-45-588Z/dom/dashboard-accounts.html`
 * (5 MDS rows). The QFX download page does not contain these rows; the
 * pre-fix code re-navigated to the overview hash-route after the download
 * form had already loaded, which is a same-document hash change that does
 * NOT re-render the SPA — so it ended up scraping the download form's DOM
 * and emitting `selectors_pending` against the wrong surface.
 *
 * Attribution policy:
 *   - 1 filtered account: overview rows belong to that account.
 *   - >1 filtered accounts: rows from the overview table mix activity
 *     across all visible accounts and cannot be safely attributed
 *     without a per-account activity surface. Emit a single SKIP_RESULT
 *     `ambiguous_multi_account_overview` instead of guessing.
 *   - 0 parseable rows: emit `selectors_pending` with a message that
 *     references the dashboard overview (the actual surface), not the
 *     account-activity DOM.
 *
 * Takes pre-captured dashboard HTML (Page is no longer required) so this
 * helper is unit-testable and avoids fragile SPA re-routing. The caller
 * is responsible for grabbing `page.content()` while the dashboard
 * overview is still loaded — see collect().
 */
export declare function runCurrentActivity(deps: EmitDeps, dashboardHtml: string, filteredAccounts: readonly ChaseAccount[], surfaceDiagnostic?: BrowserSurfaceDiagnostic): Promise<void>;
export declare function runStatements(deps: EmitDeps, page: Page, filteredAccounts: readonly ChaseAccount[], accounts: readonly ChaseAccount[], accountsResFilter: ReadonlySet<string> | null, fingerprintCursor?: FingerprintCursor, hydrationCursor?: StatementHydrationCursor): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map