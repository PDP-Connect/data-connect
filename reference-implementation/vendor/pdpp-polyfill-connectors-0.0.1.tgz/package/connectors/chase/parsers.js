// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
// Pure parsers for the Chase connector. Kept free of Playwright / Node
// I/O (except sha256 + fs path helpers that are purely computational)
// so they can be unit-tested in isolation.
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";
import { parseHTML } from "linkedom";
// ─── Tunables shared with the connector entry ────────────────────────────
const HASH_SLUG_LEN = 32;
const CENTS_MULTIPLIER = 100;
// ─── Shared module-scope regexes (Biome useTopLevelRegex) ────────────────
// These were hoisted from page.evaluate() callbacks when we moved DOM
// parsing from the browser bridge to linkedom. In-Node regexes can live
// at module scope; they previously had to be redeclared inside the
// browser callback because module-scoped values can't cross the
// serialization boundary.
const DASHBOARD_ACCOUNT_ID_RE = /^accounts-name-link-button-(\d+)(?:-label)?$/;
const CARD_RE = /(Sapphire|Freedom|Ink|Amazon|Southwest|United|Hyatt|Disney|Marriott|IHG|Prime|Platinum|Slate)/i;
const CHECKING_RE = /(Checking|Total Checking|Premier Checking)/i;
const SAVINGS_RE = /(Savings|Premier Savings)/i;
const WS_RE = /\s+/g;
const LAST4_RE = /\.\.\.(\d{3,4})/;
const ANCHOR_ID_RE = /accountsTable-\d+-row\d+-cell\d+-requestThisDocumentAnchor-download/;
const ACCORDION_ID_RE = /documentsAccordion-(\d+)/;
const TABLE_ROW_RE = /accountsTable-(\d+)-row(\d+)-/;
const STATEMENT_RE = /statement/i;
const ACCOUNT_SLUG_SAFE_RE = /^[A-Za-z0-9_-]+$/;
const STATEMENT_LAST_FOUR_RE = /\.\.\.(\d{3,4})/;
const AMOUNT_RE = /(?:[-+]?\s*\$\s*\d[\d,]*(?:\.\d{2})?|\(\s*\$?\s*\d[\d,]*(?:\.\d{2})?\s*\))/;
const DATE_NUMERIC_RE = /\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/;
const DATE_MONTH_RE = /\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?\s+(\d{1,2})(?:,\s*(\d{4}))?\b/i;
const ACTIVITY_DEBIT_RE = /-|\(|\bwithdrawal\b|\bpurchase\b|\bdebit\b/i;
const PENDING_RE = /\bpending\b/i;
const POSTED_RE = /\bposted\b|\bcompleted\b/i;
const MONTH_DOT_RE = /\.$/;
const DIGIT_RE = /\d/;
const CURRENT_ACTIVITY_SELECTOR = '[data-testid*="transaction" i], [data-testid*="activity" i], [id*="transaction" i], [id*="activity" i], tr';
const CURRENT_ACTIVITY_MDS_ROW_SELECTOR = 'tr.mds-activity-table__row[data-values], tr[id*="activity" i][data-values]';
const UI_TRANSACTION_ID_ATTRS = [
    "data-transaction-id",
    "data-transactionid",
    "data-activity-id",
    "data-id",
    "id",
];
const HASHED_ID_RE = /^(?:row-|transaction-|activity-)?[A-Za-z0-9_-]{8,}$/;
const POSITIONAL_CURRENT_ACTIVITY_ID_RE = /^ovd-recent-activity-table-dataTableId-row-\d+$/;
const MONTH_INDEX = {
    jan: "01",
    january: "01",
    feb: "02",
    february: "02",
    mar: "03",
    march: "03",
    apr: "04",
    april: "04",
    may: "05",
    jun: "06",
    june: "06",
    jul: "07",
    july: "07",
    aug: "08",
    august: "08",
    sep: "09",
    sept: "09",
    september: "09",
    oct: "10",
    october: "10",
    nov: "11",
    november: "11",
    dec: "12",
    december: "12",
};
// ─── Text helpers ─────────────────────────────────────────────────────────
function textOf(el) {
    if (!el) {
        return "";
    }
    // linkedom exposes innerText on HTMLElement-ish nodes; fall back to
    // textContent for safety. Both collapse similarly after /\s+/ normalization.
    const maybe = el.innerText;
    return typeof maybe === "string" ? maybe : (el.textContent ?? "");
}
function normWhitespace(s) {
    return s.replace(WS_RE, " ").trim();
}
// ─── Error-message helpers (also used by the runtime entry) ──────────────
export function errMessage(err) {
    return err instanceof Error ? err.message : String(err);
}
export function truncate(s, max) {
    return s.length > max ? s.slice(0, max) : s;
}
// ─── Hash + URL helpers ──────────────────────────────────────────────────
export function sha256Hex(buf) {
    return createHash("sha256").update(buf).digest("hex");
}
/**
 * True when a downloaded statement buffer is a usable PDF: non-empty and
 * carrying the `%PDF` magic header. A 0-byte (or HTML/error-page) download
 * is otherwise hashed and recorded as a "successful" hydration — the empty
 * buffer yields the empty-string sha256
 * (e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855),
 * which then flips back and forth with the real sha across runs and
 * manufactures version churn on an immutable statement (and leaves the
 * owner pointing at a 0-byte file they believe is captured). Guarding the
 * persist path turns an empty/garbage download into an honest index-only
 * fallback instead of a fake capture. PDFs always begin with `%PDF-` per
 * the PDF spec; we check the magic bytes rather than only length so an
 * HTML error page served with a 200 is also rejected.
 */
export function isUsablePdfBuffer(buf) {
    if (buf.length < PDF_MAGIC.length) {
        return false;
    }
    for (let i = 0; i < PDF_MAGIC.length; i += 1) {
        if (buf[i] !== PDF_MAGIC[i]) {
            return false;
        }
    }
    return true;
}
// "%PDF" — the leading magic bytes every PDF file carries (PDF spec §7.5.2).
const PDF_MAGIC = Buffer.from("%PDF", "ascii");
export function shortHash(s) {
    return createHash("sha256").update(s).digest("hex").slice(0, HASH_SLUG_LEN);
}
export function fileUrl(p) {
    if (!p) {
        return null;
    }
    return pathToFileURL(p).href;
}
// ─── Date helpers ─────────────────────────────────────────────────────────
/**
 * "YYYY-MM-DD" → "MMDDYYYY" (Chase date-picker's accepted packed form).
 * Returns null if the input is missing any of the three date parts.
 */
export function isoToPacked(iso) {
    const parts = iso.split("-");
    const [y, m, d] = parts;
    if (!(y && m && d)) {
        return null;
    }
    return `${m}${d}${y}`;
}
/**
 * Chase's Statements page renders dates like "Apr 13, 2026". v8's Date
 * parser handles that reliably; we lower-cap into YYYY-MM-DD.
 */
export function parseDateDelivered(raw) {
    if (!raw) {
        return null;
    }
    const d = new Date(raw);
    if (Number.isNaN(d.getTime())) {
        return null;
    }
    return d.toISOString().slice(0, 10);
}
export function yearMonthFromIso(iso) {
    return iso ? iso.slice(0, 7) : "unknown";
}
export function accountSlug(accountId) {
    if (!accountId) {
        return "unknown";
    }
    if (ACCOUNT_SLUG_SAFE_RE.test(accountId)) {
        return accountId;
    }
    return shortHash(accountId);
}
// ─── OFX value helpers ────────────────────────────────────────────────────
export function isOfxRecord(v) {
    return typeof v === "object" && v !== null && !Array.isArray(v);
}
export function ofxGet(v, key) {
    return isOfxRecord(v) ? v[key] : undefined;
}
export function ofxString(v) {
    if (v === null || v === undefined) {
        return null;
    }
    if (typeof v === "string") {
        return v;
    }
    if (typeof v === "number" || typeof v === "boolean") {
        return String(v);
    }
    return null;
}
export function ofxNumber(v) {
    if (v === null || v === undefined) {
        return null;
    }
    let s;
    if (typeof v === "string") {
        s = v;
    }
    else if (typeof v === "number") {
        s = String(v);
    }
    else {
        s = "";
    }
    if (!s) {
        return null;
    }
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
}
// OFX datetime format: YYYYMMDDHHMMSS[.sss][TZ] — strip to YYYY-MM-DD.
export function ofxDateToIso(raw) {
    const src = ofxString(raw);
    if (!src) {
        return null;
    }
    const s = src.trim();
    if (s.length < 8) {
        return null;
    }
    const y = s.slice(0, 4);
    const m = s.slice(4, 6);
    const d = s.slice(6, 8);
    return `${y}-${m}-${d}`;
}
export function ofxDateToFullIso(raw) {
    const src = ofxString(raw);
    if (!src) {
        return null;
    }
    const s = src.trim();
    if (s.length < 8) {
        return null;
    }
    const date = ofxDateToIso(s);
    if (!date) {
        return null;
    }
    const hh = s.slice(8, 10) || "00";
    const mm = s.slice(10, 12) || "00";
    const ss = s.slice(12, 14) || "00";
    return `${date}T${hh}:${mm}:${ss}Z`;
}
// ─── Dashboard DOM parsing (accounts list) ────────────────────────────────
function classifyAccountType(displayName) {
    if (CARD_RE.test(displayName)) {
        return "credit_card";
    }
    if (CHECKING_RE.test(displayName)) {
        return "checking";
    }
    if (SAVINGS_RE.test(displayName)) {
        return "savings";
    }
    return "unknown";
}
/**
 * Parse the Chase dashboard-overview HTML into ChaseAccount rows. Mirrors
 * the former page.evaluate() callback but runs in Node via linkedom so it
 * can be unit-tested offline.
 *
 * Chase has rendered account cards in two observed shapes:
 *   <span id="accounts-name-link-button-<INTERNAL_ID>-label">...</span>
 *   <button id="accounts-name-link-button-<INTERNAL_ID>">...</button>
 *
 * The INTERNAL_ID is stable and is what the download form's account selector
 * expects. We pull every supported label/button, extract the id, name, last
 * four, and heuristic type.
 */
export function parseDashboardAccountsDom(html) {
    const { document } = parseHTML(html);
    const labels = [
        ...document.querySelectorAll('[id^="accounts-name-link-button-"][id$="-label"], button[id^="accounts-name-link-button-"], button[data-testid^="accounts-name-link-button-"]'),
    ];
    const results = [];
    const seen = new Set();
    for (const el of labels) {
        const id = el.id || el.getAttribute("data-testid") || "";
        const idMatch = DASHBOARD_ACCOUNT_ID_RE.exec(id);
        if (!idMatch?.[1]) {
            continue;
        }
        if (seen.has(idMatch[1])) {
            continue;
        }
        seen.add(idMatch[1]);
        const displayName = normWhitespace(textOf(el));
        const lastFourMatch = LAST4_RE.exec(displayName);
        results.push({
            internal_id: idMatch[1],
            name: displayName,
            type: classifyAccountType(displayName),
            last_four: lastFourMatch?.[1] ?? null,
        });
    }
    return results;
}
function parseVisibleAmount(text) {
    const match = AMOUNT_RE.exec(text.replace(/\u2212/g, "-"));
    if (!match?.[0]) {
        return null;
    }
    const [raw] = match;
    const sign = ACTIVITY_DEBIT_RE.test(text) ? -1 : 1;
    const normalized = raw.replace(/[$,\s+-]/g, "");
    const n = Number(normalized);
    return Number.isFinite(n) ? Math.round(n * CENTS_MULTIPLIER) * sign : null;
}
function inferActivityStatus(text) {
    if (PENDING_RE.test(text)) {
        return "pending";
    }
    if (POSTED_RE.test(text)) {
        return "posted";
    }
    return "unknown";
}
function parseVisibleDate(text, referenceDateIso) {
    const month = DATE_MONTH_RE.exec(text);
    if (month?.[1] && month[2]) {
        const monthNum = MONTH_INDEX[month[1].toLowerCase().replace(MONTH_DOT_RE, "")];
        const year = month[3] ?? referenceDateIso.slice(0, 4);
        if (monthNum) {
            return `${year.padStart(4, "20")}-${monthNum}-${month[2].padStart(2, "0")}`;
        }
    }
    const numeric = DATE_NUMERIC_RE.exec(text);
    if (numeric?.[1] && numeric[2]) {
        const yearRaw = numeric[3] ?? referenceDateIso.slice(0, 4);
        const year = yearRaw.length === 2 ? `20${yearRaw}` : yearRaw;
        return `${year}-${numeric[1].padStart(2, "0")}-${numeric[2].padStart(2, "0")}`;
    }
    return null;
}
function extractUiTransactionId(el) {
    for (const attr of UI_TRANSACTION_ID_ATTRS) {
        const value = el.getAttribute(attr);
        if (value &&
            HASHED_ID_RE.test(value) &&
            !POSITIONAL_CURRENT_ACTIVITY_ID_RE.test(value)) {
            return value;
        }
    }
    return null;
}
function normalizeDescription(text) {
    return normWhitespace(text
        .replace(AMOUNT_RE, " ")
        .replace(DATE_MONTH_RE, " ")
        .replace(DATE_NUMERIC_RE, " ")
        .replace(/\b(Pending|Posted|Completed)\b/gi, " "));
}
function firstVisibleAmountIndex(parts) {
    for (let i = parts.length - 1; i >= 0; i -= 1) {
        if (AMOUNT_RE.test(parts[i] ?? "")) {
            return i;
        }
    }
    return -1;
}
function parseMdsActivityDataValues(raw, referenceDateIso) {
    const parts = raw
        .split(",")
        .map((part) => normWhitespace(part))
        .filter(Boolean);
    if (parts.length < 3) {
        return null;
    }
    const amountIndex = firstVisibleAmountIndex(parts);
    if (amountIndex < 0) {
        return null;
    }
    let activityDate = null;
    let descriptionStart = 1;
    let status = inferActivityStatus(parts[0] ?? "");
    const first = parts[0] ?? "";
    const second = parts[1] ?? "";
    if (status === "pending") {
        // Chase's dashboard activity table renders pending authorizations with
        // "Pending (N)" in the Date column and no per-row date. Use the fetch date
        // as the UI-visible activity date while keeping status=pending.
        activityDate = referenceDateIso;
    }
    else if (DATE_MONTH_RE.test(`${first}, ${second}`)) {
        activityDate = parseVisibleDate(`${first}, ${second}`, referenceDateIso);
        descriptionStart = 2;
        status = "posted";
    }
    else {
        activityDate = parseVisibleDate(first, referenceDateIso);
        status = activityDate ? "posted" : status;
    }
    if (!activityDate) {
        return null;
    }
    const amountCents = parseVisibleAmount(parts[amountIndex] ?? "");
    if (amountCents === null) {
        return null;
    }
    const description = normalizeDescription(parts.slice(descriptionStart, amountIndex).join(", "));
    if (!description || description.length > 240) {
        return null;
    }
    return {
        activity_date: activityDate,
        amount_cents: amountCents,
        description,
        memo: null,
        posted_date: status === "posted" ? activityDate : null,
        status,
    };
}
function isParseableCurrentActivityText(text, referenceDateIso) {
    return Boolean(text &&
        DIGIT_RE.test(text) &&
        parseVisibleDate(text, referenceDateIso) &&
        parseVisibleAmount(text) !== null);
}
function hasParseableCurrentActivityDescendant(el, referenceDateIso) {
    for (const child of el.querySelectorAll(CURRENT_ACTIVITY_SELECTOR)) {
        if (isParseableCurrentActivityText(normWhitespace(textOf(child)), referenceDateIso)) {
            return true;
        }
    }
    return false;
}
export function currentActivityId(accountId, row) {
    if (row.ui_transaction_id) {
        return `${accountId}|${row.ui_transaction_id}`;
    }
    return `${accountId}|fallback:${shortHash([
        row.status,
        row.activity_date,
        row.posted_date ?? "",
        row.amount_cents,
        row.description.toLowerCase(),
    ].join("|"))}`;
}
function currentActivityDedupeKey(row) {
    return [
        row.ui_transaction_id ?? "",
        row.status,
        row.activity_date,
        row.amount_cents,
        row.description,
    ].join("|");
}
function addCurrentActivityRow(rows, seen, row) {
    const dedupeKey = currentActivityDedupeKey(row);
    if (seen.has(dedupeKey)) {
        return;
    }
    seen.add(dedupeKey);
    rows.push(row);
}
function parseMdsCurrentActivityRow(el, referenceDateIso) {
    const parsed = parseMdsActivityDataValues(el.getAttribute("data-values") ?? "", referenceDateIso);
    if (!parsed) {
        return null;
    }
    return {
        ...parsed,
        ui_transaction_id: extractUiTransactionId(el),
    };
}
function parseGenericCurrentActivityRow(el, referenceDateIso) {
    const text = normWhitespace(textOf(el));
    if (!isParseableCurrentActivityText(text, referenceDateIso)) {
        return null;
    }
    if (hasParseableCurrentActivityDescendant(el, referenceDateIso)) {
        return null;
    }
    const activityDate = parseVisibleDate(text, referenceDateIso);
    const amountCents = parseVisibleAmount(text);
    if (!(activityDate && amountCents !== null)) {
        return null;
    }
    const description = normalizeDescription(text);
    if (!description || description.length > 240) {
        return null;
    }
    const status = inferActivityStatus(text);
    return {
        activity_date: activityDate,
        amount_cents: amountCents,
        description,
        memo: null,
        posted_date: status === "posted" ? activityDate : null,
        status,
        ui_transaction_id: extractUiTransactionId(el),
    };
}
/**
 * Parse Chase account-activity DOM visible to the signed-in UI. This parser is
 * intentionally conservative: a candidate row must contain both a recognizable
 * date and amount, and the remaining text becomes the visible descriptor.
 */
export function parseCurrentActivityDom(html, referenceDateIso) {
    const { document } = parseHTML(html);
    const rows = [];
    const seen = new Set();
    for (const el of document.querySelectorAll(CURRENT_ACTIVITY_MDS_ROW_SELECTOR)) {
        const row = parseMdsCurrentActivityRow(el, referenceDateIso);
        if (row) {
            addCurrentActivityRow(rows, seen, row);
        }
    }
    for (const el of document.querySelectorAll(CURRENT_ACTIVITY_SELECTOR)) {
        if (el.matches(CURRENT_ACTIVITY_MDS_ROW_SELECTOR)) {
            continue;
        }
        // Chase activity tables often put broad "activity" ids/testids on
        // containers. Only parse leaf candidates so a wrapper around multiple
        // rows cannot synthesize duplicate aggregate rows.
        const row = parseGenericCurrentActivityRow(el, referenceDateIso);
        if (row) {
            addCurrentActivityRow(rows, seen, row);
        }
    }
    return rows;
}
function collectAccordions(document) {
    const accordions = [
        ...document.querySelectorAll('[id^="button-documentsAccordion-"]'),
    ].map((b) => {
        const m = ACCORDION_ID_RE.exec(b.id);
        return {
            tableIdx: m?.[1],
            label: normWhitespace(textOf(b)),
        };
    });
    const accountByTableIdx = new Map();
    for (const a of accordions) {
        if (a.tableIdx) {
            accountByTableIdx.set(a.tableIdx, a.label);
        }
    }
    return accountByTableIdx;
}
function findParentRow(el) {
    let tr = el;
    while (tr && tr.tagName !== "TR") {
        tr = tr.parentElement;
    }
    return tr;
}
/**
 * Enumerate the statement rows rendered on Chase's Statements & Documents
 * page. Mirrors the prior page.evaluate() body, now run via linkedom in
 * Node. Each statement row maps to one monthly PDF download anchor.
 *
 * Only rows whose doc_kind matches /statement/i are returned — tax
 * documents and other row kinds are skipped at the parse layer so the
 * caller doesn't need to filter.
 */
export function parseStatementsListDom(html) {
    const { document } = parseHTML(html);
    const accountByTableIdx = collectAccordions(document);
    const anchors = [...document.querySelectorAll("a[id]")].filter((el) => ANCHOR_ID_RE.test(el.id ?? ""));
    const rows = [];
    for (const a of anchors) {
        const anchorId = a.id ?? "";
        const m = TABLE_ROW_RE.exec(anchorId);
        const tableIdx = m?.[1];
        const rowIdx = m?.[2];
        const tr = findParentRow(a);
        const cells = tr ? [...tr.querySelectorAll("td, th")] : [];
        const date_delivered_raw = textOf(cells[0]).trim();
        const doc_kind = textOf(cells[1]).trim();
        if (!(doc_kind && STATEMENT_RE.test(doc_kind))) {
            continue;
        }
        const account_reference = tableIdx
            ? (accountByTableIdx.get(tableIdx) ?? null)
            : null;
        const title = [date_delivered_raw, doc_kind, account_reference]
            .filter(Boolean)
            .join(" ");
        rows.push({
            rowAnchorId: anchorId,
            tableIdx,
            rowIdx,
            date_delivered_raw,
            doc_kind,
            account_reference,
            title,
        });
    }
    return rows;
}
/**
 * Resolve a statement row's `account_reference` text (e.g.
 * "SAPPHIRE PREFERRED (...9241)") to the stable Chase internal account id
 * from our accounts array. Matches last-four first, then name substring.
 */
export function resolveAccountIdForRow(row, accounts) {
    if (!row.account_reference) {
        return null;
    }
    const last4Match = STATEMENT_LAST_FOUR_RE.exec(row.account_reference);
    if (last4Match?.[1]) {
        const byLast4 = accounts.find((a) => a.last_four === last4Match[1]);
        if (byLast4) {
            return byLast4.internal_id;
        }
    }
    const refLower = row.account_reference.toLowerCase();
    const byName = accounts.find((a) => a.name && refLower.includes(a.name.toLowerCase()));
    return byName ? byName.internal_id : null;
}
// ─── QFX structural extraction ───────────────────────────────────────────
function extractTransactions(stmt, currency) {
    const trList = ofxGet(stmt, "BANKTRANLIST");
    const rawTxns = ofxGet(trList, "STMTTRN");
    let txnArray;
    if (Array.isArray(rawTxns)) {
        txnArray = rawTxns;
    }
    else if (rawTxns) {
        txnArray = [rawTxns];
    }
    else {
        txnArray = [];
    }
    const transactions = [];
    for (const t of txnArray) {
        const amtStr = (ofxString(ofxGet(t, "TRNAMT")) ?? "0").trim();
        const amountCents = Math.round(Number(amtStr) * CENTS_MULTIPLIER);
        const fitid = ofxString(ofxGet(t, "FITID")) ?? "";
        const date = ofxDateToIso(ofxGet(t, "DTPOSTED"));
        if (!(fitid && date)) {
            continue;
        }
        transactions.push({
            fitid,
            date,
            amount_cents: amountCents,
            currency,
            type: ofxString(ofxGet(t, "TRNTYPE")),
            name: ofxString(ofxGet(t, "NAME")),
            memo: ofxString(ofxGet(t, "MEMO")),
            check_number: ofxString(ofxGet(t, "CHECKNUM")),
            reference_number: ofxString(ofxGet(t, "REFNUM")),
        });
    }
    return transactions;
}
function extractBalance(stmt) {
    const ledgerBal = ofxGet(stmt, "LEDGERBAL");
    const availBal = ofxGet(stmt, "AVAILBAL");
    if (!(ledgerBal || availBal)) {
        return null;
    }
    const asOf = ofxDateToFullIso(ofxGet(ledgerBal, "DTASOF") ?? ofxGet(availBal, "DTASOF"));
    if (!asOf) {
        return null;
    }
    const ledgerAmt = ofxNumber(ofxGet(ledgerBal, "BALAMT"));
    const availAmt = ofxNumber(ofxGet(availBal, "BALAMT"));
    return {
        as_of: asOf,
        ledger_cents: ledgerAmt === null ? null : Math.round(ledgerAmt * CENTS_MULTIPLIER),
        available_cents: availAmt === null ? null : Math.round(availAmt * CENTS_MULTIPLIER),
    };
}
/**
 * Walk an ofx-js parsed structure and extract our canonical shape.
 * Credit cards live under CREDITCARDMSGSRSV1 > CCSTMTTRNRS > CCSTMTRS;
 * checking/savings under BANKMSGSRSV1 > STMTTRNRS > STMTRS. Structures
 * are otherwise parallel.
 */
export function extractFromQfx(parsed) {
    const root = ofxGet(parsed, "OFX") ?? parsed;
    if (!isOfxRecord(root)) {
        return { transactions: [], balance: null };
    }
    const cc = ofxGet(ofxGet(ofxGet(root, "CREDITCARDMSGSRSV1"), "CCSTMTTRNRS"), "CCSTMTRS");
    const bank = ofxGet(ofxGet(ofxGet(root, "BANKMSGSRSV1"), "STMTTRNRS"), "STMTRS");
    let stmt = null;
    if (isOfxRecord(cc)) {
        stmt = cc;
    }
    else if (isOfxRecord(bank)) {
        stmt = bank;
    }
    if (!stmt) {
        return { transactions: [], balance: null };
    }
    const currency = ofxString(ofxGet(stmt, "CURDEF")) ?? "USD";
    const transactions = extractTransactions(stmt, currency);
    const balance = extractBalance(stmt);
    return { transactions, balance };
}
/**
 * How stale a cursor may be before "Since last statement" stops being a safe
 * incremental choice.
 *
 * Chase's "Since last statement" option covers the current statement cycle
 * only — roughly 30 days. If a cursor is older than that, the option's window
 * no longer reaches back to where collection left off, and every scheduled
 * run silently skips the gap between them: the run succeeds, downloads a
 * QFX, and never sees the missing period. Nothing in the run reports a
 * problem, because from the connector's point of view it asked for
 * everything new and got it.
 *
 * 25 days is deliberately shorter than the ~30-day cycle so a cursor that is
 * merely at the edge of the window still falls back to a bounded
 * `date_range` export rather than gambling on the cycle boundary. Being
 * early costs one wider export; being late costs a silent hole.
 */
const SINCE_LAST_STATEMENT_MAX_CURSOR_AGE_DAYS = 25;
const MS_PER_DAY = 86_400_000;
/**
 * Whole days between two YYYY-MM-DD dates, or null when either is not a
 * usable date. Returning null (rather than 0 or Infinity) keeps an
 * unparseable cursor from being read as "fresh" — the caller treats null as
 * "cannot prove freshness" and takes the safe path.
 */
export function cursorAgeInDays(maxSeenDate, runDate) {
    const seen = Date.parse(`${maxSeenDate.slice(0, 10)}T00:00:00Z`);
    const now = Date.parse(`${runDate.slice(0, 10)}T00:00:00Z`);
    if (!(Number.isFinite(seen) && Number.isFinite(now))) {
        return null;
    }
    return Math.floor((now - seen) / MS_PER_DAY);
}
/**
 * Pick the QFX download "activity" option for a given account based on
 * (1) an explicit scope time_range, (2) an existing cursor's
 * max_seen_date — but only while that cursor is still fresh enough for
 * "Since last statement" to actually reach it — or (3) "all" as the
 * bootstrap default.
 *
 * The staleness check is the load-bearing part. Without it, the mere
 * EXISTENCE of a cursor pinned every future run to "Since last statement",
 * so once a gap opened no scheduled run could ever reach back across it.
 * A stale cursor now produces a bounded `date_range` export that starts
 * where collection actually left off.
 */
export function chooseActivity(requested, state, stream, accountId, runDate) {
    const streamScope = requested.get(stream);
    const timeRange = streamScope?.time_range;
    if (timeRange?.since || timeRange?.until) {
        return {
            activity: "date_range",
            dateRange: {
                from: timeRange.since?.slice(0, 10),
                to: timeRange.until?.slice(0, 10) ?? runDate.slice(0, 10),
            },
        };
    }
    const cursor = state.per_account?.[accountId];
    if (cursor?.max_seen_date) {
        const age = cursorAgeInDays(cursor.max_seen_date, runDate);
        if (age !== null &&
            age >= 0 &&
            age <= SINCE_LAST_STATEMENT_MAX_CURSOR_AGE_DAYS) {
            return { activity: "since_last_statement" };
        }
        // The cursor is stale (or unparseable, or in the future — a clock skew
        // that makes freshness unprovable). "Since last statement" would not
        // reach back to it, so export a bounded date range that starts AT the
        // cursor instead. Starting at the cursor rather than after it keeps a
        // one-day overlap, which is harmless: transaction ids are stable, so a
        // re-seen transaction is suppressed rather than duplicated.
        return {
            activity: "date_range",
            dateRange: {
                from: cursor.max_seen_date.slice(0, 10),
                to: runDate.slice(0, 10),
            },
        };
    }
    return { activity: "all" };
}
/**
 * Drop `per_account` cursors for accounts the current run did not discover,
 * and report which ones were dropped.
 *
 * Why this matters: the cursor map was carried forward wholesale, so an
 * account that disappeared from `discoverAccounts()` kept its cursor
 * forever. That is not merely untidy — the stale entry is indistinguishable
 * from a live one, so the account is skipped silently with no gap emitted
 * and nothing ever reports that it stopped being collected.
 *
 * `dropped` is returned rather than logged here so the caller can surface it
 * as a real finding. An account vanishing from discovery is exactly the kind
 * of event that should be visible: it may be a closed account (fine) or a
 * discovery regression (not fine), and this function deliberately does not
 * guess which.
 *
 * `known` is the set of accounts discovered THIS run. When discovery itself
 * failed the caller must not call this with an empty set — pruning against a
 * failed discovery would erase every cursor. See the caller's guard.
 */
export function prunePerAccountCursors(perAccount, known) {
    const kept = {};
    const dropped = [];
    for (const [accountId, cursor] of Object.entries(perAccount)) {
        if (known.has(accountId)) {
            kept[accountId] = cursor;
        }
        else {
            dropped.push(accountId);
        }
    }
    return { kept, dropped };
}
// ─── Public labels used by the click-path (exported for entry point) ──────
export const ACTIVITY_LABELS = {
    all: "All transactions",
    since_last_statement: "Since last statement",
    year_to_date: "Year to date",
    last_year: "Last year",
    current: "Current display, including filters",
    date_range: "Choose a date range",
};
