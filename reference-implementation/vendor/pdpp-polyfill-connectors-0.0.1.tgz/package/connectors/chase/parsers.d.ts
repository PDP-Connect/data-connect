import type { ActivityChoice, ActivityKind, ChaseAccount, CurrentActivityRow, OfxRecord, OfxValue, QfxExtracted, StatementRow, TransactionCursor, TransactionsStateShape } from "./types.ts";
export declare function errMessage(err: unknown): string;
export declare function truncate(s: string, max: number): string;
export declare function sha256Hex(buf: Buffer | Uint8Array): string;
/**
 * True when a downloaded statement buffer is a usable PDF: non-empty and
 * carrying the `%PDF` magic header. A 0-byte (or HTML/error-page) download
 * is otherwise hashed and recorded as a "successful" hydration — the empty
 * buffer yields the empty-string sha256
 * (e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855),
 * which then flips back and forth with the real sha across runs and
 * manufactures version churn on an immutable statement (and leaves the
 * owner pointing at a 0-byte file they believe is captured). Guarding the
 * persist path turns an empty/garbage download into an honest index-only
 * fallback instead of a fake capture. PDFs always begin with `%PDF-` per
 * the PDF spec; we check the magic bytes rather than only length so an
 * HTML error page served with a 200 is also rejected.
 */
export declare function isUsablePdfBuffer(buf: Buffer | Uint8Array): boolean;
export declare function shortHash(s: string): string;
export declare function fileUrl(p: string | null | undefined): string | null;
/**
 * "YYYY-MM-DD" → "MMDDYYYY" (Chase date-picker's accepted packed form).
 * Returns null if the input is missing any of the three date parts.
 */
export declare function isoToPacked(iso: string): string | null;
/**
 * Chase's Statements page renders dates like "Apr 13, 2026". v8's Date
 * parser handles that reliably; we lower-cap into YYYY-MM-DD.
 */
export declare function parseDateDelivered(raw: string | null | undefined): string | null;
export declare function yearMonthFromIso(iso: string | null): string;
export declare function accountSlug(accountId: string | null): string;
export declare function isOfxRecord(v: OfxValue): v is OfxRecord;
export declare function ofxGet(v: OfxValue, key: string): OfxValue;
export declare function ofxString(v: OfxValue): string | null;
export declare function ofxNumber(v: OfxValue): number | null;
export declare function ofxDateToIso(raw: OfxValue): string | null;
export declare function ofxDateToFullIso(raw: OfxValue): string | null;
/**
 * Parse the Chase dashboard-overview HTML into ChaseAccount rows. Mirrors
 * the former page.evaluate() callback but runs in Node via linkedom so it
 * can be unit-tested offline.
 *
 * Chase has rendered account cards in two observed shapes:
 *   <span id="accounts-name-link-button-<INTERNAL_ID>-label">...</span>
 *   <button id="accounts-name-link-button-<INTERNAL_ID>">...</button>
 *
 * The INTERNAL_ID is stable and is what the download form's account selector
 * expects. We pull every supported label/button, extract the id, name, last
 * four, and heuristic type.
 */
export declare function parseDashboardAccountsDom(html: string): ChaseAccount[];
export declare function currentActivityId(accountId: string, row: CurrentActivityRow): string;
/**
 * Parse Chase account-activity DOM visible to the signed-in UI. This parser is
 * intentionally conservative: a candidate row must contain both a recognizable
 * date and amount, and the remaining text becomes the visible descriptor.
 */
export declare function parseCurrentActivityDom(html: string, referenceDateIso: string): CurrentActivityRow[];
/**
 * Enumerate the statement rows rendered on Chase's Statements & Documents
 * page. Mirrors the prior page.evaluate() body, now run via linkedom in
 * Node. Each statement row maps to one monthly PDF download anchor.
 *
 * Only rows whose doc_kind matches /statement/i are returned — tax
 * documents and other row kinds are skipped at the parse layer so the
 * caller doesn't need to filter.
 */
export declare function parseStatementsListDom(html: string): StatementRow[];
/**
 * Resolve a statement row's `account_reference` text (e.g.
 * "SAPPHIRE PREFERRED (...9241)") to the stable Chase internal account id
 * from our accounts array. Matches last-four first, then name substring.
 */
export declare function resolveAccountIdForRow(row: StatementRow, accounts: readonly ChaseAccount[]): string | null;
/**
 * Walk an ofx-js parsed structure and extract our canonical shape.
 * Credit cards live under CREDITCARDMSGSRSV1 > CCSTMTTRNRS > CCSTMTRS;
 * checking/savings under BANKMSGSRSV1 > STMTTRNRS > STMTRS. Structures
 * are otherwise parallel.
 */
export declare function extractFromQfx(parsed: unknown): QfxExtracted;
interface TimeRange {
    since?: string;
    until?: string;
}
export interface StreamScopeLike {
    time_range?: TimeRange;
}
/**
 * Whole days between two YYYY-MM-DD dates, or null when either is not a
 * usable date. Returning null (rather than 0 or Infinity) keeps an
 * unparseable cursor from being read as "fresh" — the caller treats null as
 * "cannot prove freshness" and takes the safe path.
 */
export declare function cursorAgeInDays(maxSeenDate: string, runDate: string): number | null;
/**
 * Pick the QFX download "activity" option for a given account based on
 * (1) an explicit scope time_range, (2) an existing cursor's
 * max_seen_date — but only while that cursor is still fresh enough for
 * "Since last statement" to actually reach it — or (3) "all" as the
 * bootstrap default.
 *
 * The staleness check is the load-bearing part. Without it, the mere
 * EXISTENCE of a cursor pinned every future run to "Since last statement",
 * so once a gap opened no scheduled run could ever reach back across it.
 * A stale cursor now produces a bounded `date_range` export that starts
 * where collection actually left off.
 */
export declare function chooseActivity(requested: Map<string, StreamScopeLike>, state: TransactionsStateShape, stream: string, accountId: string, runDate: string): ActivityChoice;
/**
 * Drop `per_account` cursors for accounts the current run did not discover,
 * and report which ones were dropped.
 *
 * Why this matters: the cursor map was carried forward wholesale, so an
 * account that disappeared from `discoverAccounts()` kept its cursor
 * forever. That is not merely untidy — the stale entry is indistinguishable
 * from a live one, so the account is skipped silently with no gap emitted
 * and nothing ever reports that it stopped being collected.
 *
 * `dropped` is returned rather than logged here so the caller can surface it
 * as a real finding. An account vanishing from discovery is exactly the kind
 * of event that should be visible: it may be a closed account (fine) or a
 * discovery regression (not fine), and this function deliberately does not
 * guess which.
 *
 * `known` is the set of accounts discovered THIS run. When discovery itself
 * failed the caller must not call this with an empty set — pruning against a
 * failed discovery would erase every cursor. See the caller's guard.
 */
export declare function prunePerAccountCursors(perAccount: Record<string, TransactionCursor>, known: ReadonlySet<string>): {
    kept: Record<string, TransactionCursor>;
    dropped: string[];
};
export declare const ACTIVITY_LABELS: Record<ActivityKind, string>;
export {};
//# sourceMappingURL=parsers.d.ts.map