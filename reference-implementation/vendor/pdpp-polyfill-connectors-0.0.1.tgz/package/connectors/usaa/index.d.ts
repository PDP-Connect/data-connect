#!/usr/bin/env node
import type { BrowserContext, Page } from "playwright";
import { type BrowserSurfaceManagedState } from "../../src/browser-surface-diagnostic.ts";
import { type BrowserCollectContext, type DetailGapMessage } from "../../src/connector-runtime.ts";
import { type FingerprintCursor } from "../../src/fingerprint-cursor.ts";
import { type StatementHydrationCursor } from "../../src/statement-hydration-carry-forward.ts";
import { type StatementCoverageRow } from "./statement-coverage.ts";
import type { DashboardAccount, DiagnosticInfo, DocRow, DriveExportOptions, HydrationResult, HydrationResultSuccess, IndexRow, NoExportAffordanceObservation, ParseMeta } from "./types.ts";
/** Keep unknown-PDF diagnostics useful for recovery without persisting
 * statement text, which can contain names, merchants, amounts, and balances. */
export declare function buildPdfTemplateUnknownDiagnostics(statementId: string, parseMeta: ParseMeta): Record<string, unknown>;
export type EmitFn = BrowserCollectContext["emit"];
export type EmitRecordFn = BrowserCollectContext["emitRecord"];
export type RequestedScopes = BrowserCollectContext["requested"];
/** Per-run dependency bag for the emit-path helpers. */
export interface EmitDeps {
    browserSurface?: BrowserSurfaceManagedState;
    capture?: BrowserCollectContext["capture"];
    /** The run-scoped credential bundle resolved by the runtime. */
    credentials?: Readonly<Record<string, string>>;
    emit: EmitFn;
    emitRecord: EmitRecordFn;
    reauthenticate?: (input: {
        context: BrowserContext;
        page: Page;
        sendInteraction: BrowserCollectContext["sendInteraction"];
    }) => Promise<void>;
    /** Pending USAA account transaction gaps served by the runtime this run.
     * A reached account emits recovery for its supplied gap id; this prevents a
     * successful later export from leaving the durable gap pending forever. */
    servedAccountTransactionGaps?: ReadonlyMap<string, string>;
    /** Pending USAA credit-card billing/stats gaps served by the runtime this
     * run, one map per stream (see `buildServedCreditCardGapLookups`). A
     * successfully-navigated-and-scraped card emits recovery for its supplied
     * gap id on whichever stream(s) had one — see `recoverServedCreditCardGaps`. */
    servedCreditCardGaps?: {
        billing: ReadonlyMap<string, string>;
        billingStats: ReadonlyMap<string, string>;
    };
    /** Pending USAA `statements` PDF gaps served by the runtime this run. A
     * statement whose PDF is present again emits recovery for its supplied gap
     * id; without this a downloaded statement leaves its gap pending forever
     * (see `recoverServedStatementGaps`). */
    servedStatementGaps?: ReadonlyMap<string, string>;
}
/** Aggregate shape from the PDF hydration pass. Exposed so the emit-
 *  path caller can thread successes/attempts into the per-run PROGRESS. */
export interface HydrationSummary {
    attempts: number;
    results: Map<number, HydrationResult>;
    successes: number;
}
/** Streams scaffolded in design-notes but without live selectors. Each
 *  requested-but-deferred stream gets a SKIP_RESULT so the client sees
 *  the intent without data. */
export declare const DEFERRED_STREAMS: readonly string[];
/** True iff we should try to extract transactions from this statement
 *  title. USAA's document index mixes statements with agreements /
 *  disclosures — the parser only understands the former. */
export declare function shouldParseStatementTitle(title: string): boolean;
/** Narrow a HydrationResult to the success branch. Used by the record-
 *  emit path to decide between a hydrated row and an index-only row. */
export declare function hydrationSuccess(h: HydrationResult | undefined): HydrationResultSuccess | null;
/** Build `statements` IndexRows from scraped DocRows. Rows missing a
 *  `date_delivered` are dropped — we can't reliably key them. Account
 *  resolution falls through last-four then name substring. */
export declare function buildIndexRows(docs: readonly DocRow[], accounts: readonly DashboardAccount[]): IndexRow[];
/** Options controlling which of the two account streams emit. The entity
 *  (`accounts`) and the observation (`account_stats`) are independently
 *  scoped: a client may request the entity, the daily balances, or both.
 *  `observedOn` is the UTC date (`YYYY-MM-DD`) the balances were sampled.
 *  `emitEntity` defaults to `true` so legacy callers (and tests that pass no
 *  options) keep emitting the entity record + STATE unchanged. */
export interface AccountsEmitOptions {
    emitEntity?: boolean;
    emitStats?: boolean;
    observedOn?: string;
}
/** Emit one `accounts` entity record per dashboard account (gated), and
 *  optionally one `account_stats` observation record per account, followed
 *  by per-stream STATE checkpoints. Record `fetched_at` threads the
 *  run-level emittedAt so every record in a run shares one timestamp; STATE
 *  cursors use `nowIso()` at emit time since they're heartbeats, not record
 *  fields.
 *
 *  Entity gate: a per-account fingerprint that excludes the run-clock
 *  `fetched_at`. After the Family-2 split the entity body carries only
 *  identity/settings (id, type, name, last_four, status), so it re-emits
 *  only on a real identity/settings change — a balance-only tick no longer
 *  versions the entity. The point-in-time `balance_cents` /
 *  `available_balance_cents` live on `account_stats`, keyed
 *  `{account_id}:{observed_on}` so same-day re-pulls are idempotent and a
 *  later day appends a new point in the balance time series. When no cursor
 *  is supplied (legacy callers/tests) the entity record always emits and no
 *  entity STATE is written. */
export declare function emitAccountsStream(deps: EmitDeps, accounts: readonly DashboardAccount[], emittedAt: string, fingerprintCursor?: FingerprintCursor, options?: AccountsEmitOptions): Promise<void>;
/**
 * Parse the prior `accounts` STATE cursor's `fingerprints` map. Keyed by
 * account `id` (the dashboard account id, or a hash of the raw text when
 * USAA does not expose one). Legacy cursors (only `{ fetched_at }`) decode
 * to an empty map, so the first post-deploy run rebuilds the map and
 * re-emits every account exactly once.
 */
export declare function readPriorAccountFingerprints(state: Record<string, unknown>): Map<string, string>;
/** Emit a SKIP_RESULT for every requested-but-deferred stream. Keeps
 *  the client informed that we understood the request but can't fulfil
 *  it in this revision — rather than silently dropping the scope. */
export declare function emitDeferredStreams(emit: EmitFn, requested: RequestedScopes): Promise<void>;
/**
 * Terminal outcome class for an exhausted export ladder. The ladder reaches
 * `emitExportFailure` only when no CSV was produced AND the source never
 * returned an explicit "nothing to export" response (that honest-empty path
 * short-circuits in `processAccountTransactions` and is never a gap). What
 * remains is genuinely ambiguous, so we split it by the last diagnostic phase
 * the ladder recorded:
 *
 *   - `source_structure_changed` — the export affordance or its date-range
 *     dialog was missing/unrecognized (`no_export_affordance`,
 *     `export_dialog_unexpected_shape`). These are the two phases the ladder
 *     already treats as fatal (`isFatalDiagPhase`): they don't get better with
 *     a shorter window, so retrying is pointless until the connector's
 *     selectors are revisited. This is the "source UI/API changed or terminally
 *     unsupported" outcome.
 *   - `export_pressure` — the affordance and dialog were found and the export
 *     was submitted, but the download/body never materialized, the click
 *     failed, or the dialog reported a transient error
 *     (`export_artifact_wait_failed`, `export_dialog_error`,
 *     `export_click_failed`). This is the "temporary export/source pressure"
 *     outcome — a later run may succeed.
 *   - `unknown` — every window failed without leaving a diagnostic phase
 *     (`lastDiag === null`). We don't claim to know which of the above it was.
 *
 * This is a within-protocol refinement: `SKIP_RESULT.reason` is a free-form
 * string and `diagnostics` is open, so the only thing that changes is which
 * vetted reason/copy the dashboard sees and a machine-readable `outcome`
 * discriminator on the diagnostics object. No new protocol field is added.
 */
export type ExportLadderOutcome = "export_pressure" | "source_structure_changed" | "unknown";
/** Map the ladder's last diagnostic phase to a terminal outcome class. */
export declare function classifyExportLadderOutcome(lastDiag: DiagnosticInfo | null): ExportLadderOutcome;
/**
 * Emit the "backfill ladder exhausted" SKIP_RESULT for transactions.
 * Called when `tryExportLadder` returns no CSV across every candidate
 * start without an explicit "nothing to export" source response.
 *
 * The honest-empty case (the source explicitly said "no transactions") never
 * reaches here — `processAccountTransactions` returns before calling this when
 * `exportEmpty` is true — so this function never turns a genuinely empty
 * account/window into a retryable gap.
 */
export declare function emitExportFailure(deps: EmitDeps, a: DashboardAccount, lastDiag: DiagnosticInfo | null): Promise<void>;
/**
 * Emit one `statements` record per index row. A hydrated row gets a
 * populated `pdf_path` / `pdf_sha256` / `document_url`. A failed hydration
 * falls back to an index-only row so the client never loses the fact that
 * the statement exists — and, if the statement was previously hydrated,
 * carries the prior content-addressed pointers forward (instead of null)
 * so a transient re-download failure does not flap them `value -> null` and
 * re-version an immutable statement. A statement that was never hydrated
 * stays all-null (honest index-only). Emits a final PROGRESS + STATE.
 *
 * Body-honesty: a carried-forward body asserts the artifact's last known
 * content-addressed location (bytes a prior run stored, which never move),
 * not that this run re-verified it; the failed-download SKIP_RESULT emitted
 * by the hydration path remains the authoritative per-run record.
 *
 * Invariants (tested in integration.test.ts + statements-fingerprint.test.ts):
 *   - same number of records emitted as rows in, regardless of
 *     hydration success (carry-forward/null fallback, not drop),
 *   - hydrated rows set pdf_path + pdf_sha256 + document_url; a
 *     never-hydrated failed row leaves all three null; a previously-
 *     hydrated failed row carries the prior pointers forward,
 *   - STATE emits exactly once after all records.
 */
export declare function emitStatementRecords(deps: EmitDeps, indexRows: readonly IndexRow[], hydrationResults: Map<number, HydrationResult>, summary: HydrationSummary, fingerprintCursor?: FingerprintCursor, hydrationCursor?: StatementHydrationCursor): Promise<void>;
/**
 * Emit the per-run `statements` detail-coverage evidence: a redacted, pending
 * DETAIL_GAP for each statement-document row whose PDF is not present this run,
 * then one DETAIL_COVERAGE whose `required_keys` is the real denominator (the
 * statement-document rows the run saw on the documents index). The denominator
 * never includes disclosures/agreements (index-only by design) and never
 * carries account/title text — only opaque statement id hashes. See
 * statement-coverage.ts for the contract.
 *
 * Always emits when called — including a steady-state run that enumerated the
 * documents index and found zero statement-document candidates (considered: 0,
 * covered: 0, empty key sets). The caller only invokes this once the index
 * enumeration has actually completed (`runStatementsStream`'s scrape try/catch
 * short-circuits to a SKIP_RESULT and never reaches this function on a failed
 * scrape — see index.ts's `runStatementsStream`), so "zero candidates here"
 * always means "the run measured the denominator and it was zero," never
 * "enumeration never happened." Suppressing on zero would leave the stream
 * permanently unmeasured on an every-run-empty account.
 */
export declare function emitStatementCoverage(deps: EmitDeps, coverageRows: readonly StatementCoverageRow[]): Promise<void>;
/**
 * Parse the prior `statements` STATE cursor's `fingerprints` map. Keyed
 * by statement `id`. Legacy cursors (only `{ fetched_at }`) decode to an
 * empty map, so the first post-deploy run rebuilds the map and re-emits
 * every statement exactly once.
 */
export declare function readPriorStatementFingerprints(state: Record<string, unknown>): Map<string, string>;
/**
 * Parse the prior `transactions` STATE cursor's `fingerprints` map. Keyed
 * by the transaction record `id` (`hashId(accountId|date|amount|original|
 * #ord)`), shared across the CSV-export and PDF-statement emit paths
 * (both hash the same logical transaction to the same id). The cursor is
 * otherwise a flat `accountKey -> { last_date }` map, so `fingerprints` is
 * a reserved sibling key. Legacy cursors (no `fingerprints`) decode to an
 * empty map, so the first post-deploy run rebuilds the map and re-emits
 * every in-window transaction exactly once.
 */
export declare function readPriorTransactionFingerprints(state: Record<string, unknown>): Map<string, string>;
/**
 * Parse the prior `inbox_messages` STATE cursor's `fingerprints` map.
 * Keyed by the message record `id` (`hashId(date_short|preview[:120])`).
 * Legacy cursors (only `{ fetched_at }`) decode to an empty map, so the
 * first post-deploy run rebuilds the map and re-emits every still-listed
 * message exactly once.
 */
export declare function readPriorInboxMessageFingerprints(state: Record<string, unknown>): Map<string, string>;
/**
 * Extract the dashboard account list. Exported purely so its mid-run
 * session-repair wiring is directly testable with a mocked Page/
 * BrowserContext. See singleton-checkpoint-coverage-wiring.test.ts.
 *
 * `streamState` is threaded in (constructed by the caller BEFORE this runs —
 * accounts is the FIRST stream `collect()` reaches) so a dashboard-stage
 * session death latches `sessionDeadMidRun` immediately: every downstream
 * stream reads `accounts` from this call's return value regardless of
 * whether extraction actually succeeded, so without this latch a dead
 * session here would silently proceed through transactions/statements/
 * inbox/credit-card-billing with an empty account list, each independently
 * discovering the same dead session and re-spending (or, pre-fix, uselessly
 * re-attempting) repair — the root of the N-logins defect this run-scoped
 * budget closes. See `UsaaRunState`.
 */
export declare function extractAccounts(deps: EmitDeps, context: BrowserContext, page: Page, sendInteraction: BrowserCollectContext["sendInteraction"], streamState: UsaaRunState): Promise<DashboardAccount[]>;
/** Classify in memory only; no URL or route fragment reaches durable evidence. */
export declare function classifyUsaaNoExportRoute(value: string, hasKnownAccountOrTransactionMarker: boolean): NoExportAffordanceObservation["route"];
/**
 * If `finalUrl` is a USAA marketing interstitial, return the account URL to
 * retry; otherwise `null` (we are already where we asked to be, or somewhere
 * this function has no honest opinion about).
 *
 * Pure and exported so the escape decision is testable without Playwright.
 *
 * The retry target is the interstitial's own `goto` param when it names a USAA
 * account-detail route, else the `accountUrl` originally requested. Both are
 * URLs the caller already had or USAA itself supplied; a `goto` pointing
 * off-host or at some other section is refused rather than followed, so a
 * redirect chain can never steer the connector somewhere it did not intend to
 * go. Returns `null` when the escape target matches the URL we just loaded, so
 * a self-referential offer page cannot produce an infinite retry.
 */
export declare function resolveUsaaOfferInterstitialEscape(finalUrl: string, accountUrl: string): string | null;
type DriveExportResult = {
    kind: "artifact";
    path: string;
} | {
    kind: "empty";
} | {
    kind: "failed";
};
export declare function isNoDataExportMessage(text: string): boolean;
export declare function driveExport(page: Page, accountUrl: string, options: DriveExportOptions): Promise<DriveExportResult>;
interface StatementsSubDeps extends EmitDeps {
    page: Page;
}
/**
 * Run-scoped state shared across every USAA stream (accounts, transactions,
 * statements, inbox, credit-card billing) — constructed once in `collect()`
 * BEFORE the first stream runs, so every stream (including the very first,
 * `extractAccounts`) can both latch a session death for later streams to see
 * and consult the shared repair budget before spending a bank login.
 *
 * `sessionRepairAttempted` is the fix for the N-cards-N-logins defect: at
 * most one automated `ensureUsaaSession`/`reauthenticate` call is allowed per
 * run, no matter how many of the five stream entry points (or, within
 * credit-card billing, how many individual cards) hit a logon bounce.
 * `gotoOrRepairSession` is the sole spender of this budget — see there.
 */
export interface UsaaRunState {
    sessionDeadMidRun: boolean;
    sessionRepairAttempted: boolean;
}
/**
 * Navigate to `url`; if the final URL bounces to USAA's logon/OAuth-authorize
 * flow (`LOGON_REDIRECT_RE`) — the same mid-run session-death signal the
 * transactions export ladder already detects (`SessionDeadRedirectError`,
 * above) — re-run the connector's existing session-establishment flow
 * exactly once (`ensureUsaaSession`, idempotent: no-ops when the cookie is
 * still live) and retry the SAME navigation exactly once. A second redirect,
 * or a failed repair, reports session death to the caller instead of looping
 * or silently scraping the logon page as if it were data.
 *
 * `streamState.sessionRepairAttempted` is a RUN-scoped budget, not a
 * per-call one: this is the sole spender, and it is shared across every one
 * of this run's five stream entry points (accounts, transactions, statements,
 * inbox, and — critically — once per CARD in the credit-card billing loop,
 * which calls this function once per card). Without a run-scoped budget here,
 * a session that dies once before the credit-card loop would otherwise drive
 * one full automated bank login per remaining card. If the budget is already
 * spent (a prior call this run already attempted repair, whether it
 * succeeded or failed), a subsequent logon bounce returns `{ ok: false }`
 * immediately after detecting the bounce — it neither calls
 * `ensureUsaaSession`/`reauthenticate` again nor spends the post-repair retry
 * navigation. The caller must treat that identically to "repair attempted
 * and failed."
 *
 * Distinct from `SessionDeadRedirectError`/`reauthAfterSessionLapse` above
 * (which is transactions-specific and threads a `NoExportAffordanceObservation`
 * for its own diagnostic) — this is the shared, stream-agnostic version used
 * by accounts/statements/inbox/credit-card navigation, which have no
 * equivalent export-dialog diagnostic to capture.
 */
export declare function gotoOrRepairSession(deps: EmitDeps, context: BrowserContext, page: Page, sendInteraction: BrowserCollectContext["sendInteraction"], url: string, navOptions: {
    timeout: number;
}, streamForProgress: string, streamState: UsaaRunState, 
/** Set when the caller already navigated to `url` and confirmed the
 *  logon bounce itself (e.g. `navigateToCardOrGap`, which needs the
 *  distinct "goto rejected" vs "goto landed on logon" cases either way) —
 *  skips this function's own redundant first navigation. */
alreadyLandedOnLogon?: boolean): Promise<{
    ok: true;
} | {
    ok: false;
}>;
/** Try each candidate `sinceDate` in the ladder; stop on success or fatal diagnostic. */
interface LadderAttemptArgs {
    a: DashboardAccount;
    accountOrdinal: number;
    accountTotal: number;
    attemptOrdinal: number;
    attemptTotal: number;
    context: BrowserContext;
    deps: EmitDeps;
    onDiagnostics: (info: DiagnosticInfo) => void;
    onSessionDead: () => void;
    page: Page;
    sendInteraction: BrowserCollectContext["sendInteraction"];
    settleDelayMs?: number;
    sinceDate: string;
    streamState: UsaaRunState;
    todayIso: string;
}
export type AttemptOutcome = {
    kind: "empty";
} | {
    kind: "retry";
} | {
    kind: "session_dead";
} | {
    kind: "success";
    csvPath: string;
};
/** Run one iteration of the backfill ladder: drive export + translate errors. */
export declare function runSingleLadderAttempt({ deps, context, page, sendInteraction, a, accountOrdinal, accountTotal, attemptOrdinal, attemptTotal, sinceDate, streamState, todayIso, onDiagnostics, onSessionDead, settleDelayMs, }: LadderAttemptArgs): Promise<AttemptOutcome>;
interface CsvTransactionEmitResult {
    dataRows: number;
    latest: string | null;
    usableCount: number;
}
/** Parse the downloaded CSV, emit each transaction, and return parse outcome metadata. */
export declare function emitCsvTransactions(deps: EmitDeps, csvPath: string, a: DashboardAccount, priorLastDate: string | null, accountOrdinal: number, accountTotal: number, fingerprintCursor?: FingerprintCursor): Promise<CsvTransactionEmitResult>;
/**
 * Per-account outcome of the transactions detail pass, mirroring chase's
 * `AccountDetailOutcome` in spirit: one entry per transaction-eligible
 * account this run considered, classifying how (or whether) it was
 * covered. `kind` decides both the DETAIL_COVERAGE `hydrated_keys`
 * membership and whether a retryable DETAIL_GAP is owed:
 *   - `hydrated`: the CSV export downloaded and parsed with usable rows
 *     (fresh coverage of this account's ledger for the window).
 *   - `no_activity`: the source gave a real, source-limited "nothing here"
 *     answer — either the export dialog explicitly reported "no
 *     transactions" (`exportEmpty`) or the export downloaded a headers-only
 *     CSV with zero data rows (a dormant account's steady state). Both
 *     count as covered, never as a failure.
 *   - `gap`: the export ladder was exhausted without a download, or the
 *     downloaded CSV had data rows but none parsed to a usable transaction
 *     (header mismatch / unparseable rows) — genuinely unreached this run,
 *     retryable.
 * Accounts skipped because the session died mid-run are NOT recorded here
 * at all (see `runTransactionsStream`): they were never reached, so
 * `required_keys` only ever lists accounts the run actually attempted,
 * keeping the denominator honest for a partial-run cutoff.
 */
export type AccountTransactionOutcome = {
    accountId: string;
    kind: "gap";
    reason: DetailGapMessage["reason"];
    errorClass: string;
} | {
    accountId: string;
    kind: "hydrated" | "no_activity";
};
/** Build the retryable DETAIL_GAP for a USAA transaction account whose CSV
 *  export failed this run — the ladder produced no download, or the CSV had
 *  data rows but none parsed usable (a headers-only CSV is NOT a gap; see
 *  `classifyCsvTransactionResult`). `record_key` is the account id — the
 *  next run's detail pass retries exactly this account. Mirrors chase's
 *  `buildAccountDetailGap` (reference_only, retryable, pending) so the
 *  runtime persists one resumable gap per failed key and the per-account
 *  coverage stays honest. */
export declare function buildAccountTransactionDetailGap(outcome: {
    accountId: string;
    errorClass: string;
    reason: DetailGapMessage["reason"];
}): DetailGapMessage;
/**
 * Keep only USAA account-level transaction gaps the runtime actually served
 * this run. The connector may recover only these supplied ids: synthesizing
 * one, or accepting a foreign/malformed locator, could close unrelated work.
 */
export declare function buildServedAccountTransactionGapLookup(detailGaps: readonly BrowserCollectContext["detailGaps"][number][]): Map<string, string>;
/**
 * Keep only `statements` PDF gaps the runtime actually served this run. Locator
 * shape is `buildStatementDetailGap`'s (`usaa.statement` / `statement_id`).
 */
export declare function buildServedStatementGapLookup(detailGaps: readonly BrowserCollectContext["detailGaps"][number][]): Map<string, string>;
/**
 * Keep only USAA credit-card billing/stats gaps the runtime actually served
 * this run, one lookup per stream (a card's `credit_card_billing` gap and its
 * `credit_card_billing_stats` gap are independent DETAIL_GAP rows, served and
 * recovered independently — see `emitCreditCardNavFailureGaps`).
 */
export declare function buildServedCreditCardGapLookups(detailGaps: readonly BrowserCollectContext["detailGaps"][number][]): {
    billing: Map<string, string>;
    billingStats: Map<string, string>;
};
/**
 * A served account gap is recovered only after this run reaches that same
 * account. `hydrated` and source-limited `no_activity` are both complete
 * account coverage; a fresh `gap` is deliberately re-deferred instead.
 */
export declare function recoverServedAccountTransactionGaps(deps: EmitDeps, outcomes: readonly AccountTransactionOutcome[]): Promise<void>;
/**
 * Emit the per-run DETAIL_COVERAGE for the account -> transactions detail
 * fan-out, mirroring chase's `emitTransactionsDetailCoverage`. `outcomes` is
 * built from the accounts this run actually attempted (session-dead
 * cutoffs are excluded), so it is a real, honest denominator:
 *   - `required_keys`: every transaction-eligible account attempted.
 *   - `hydrated_keys`: accounts reached, including source-limited
 *     no-activity ones (won't-backfill is coverage, never a broken signal).
 *   - `gap_keys`: accounts whose export failed transiently; each also
 *     carries a pending DETAIL_GAP so the runtime's coverage invariant is
 *     satisfied and the next run retries them.
 *
 * `enumerationComplete` disambiguates the two ways `outcomes` can be empty:
 *   - `true`: the account loop ran to completion (never cut short by a
 *     session death) — zero outcomes here means the run genuinely enumerated
 *     zero transaction-eligible accounts, a real measured denominator. Emits
 *     considered: 0 / covered: 0 with empty key sets rather than staying
 *     silent, so an account with no checking/savings/credit-card accounts
 *     stays measured instead of permanently unreported.
 *   - `false`: the session died before any account was attempted (or mid-run,
 *     before this stream's denominator was fully walked) — the denominator is
 *     genuinely unknown this run, so nothing is emitted rather than inventing
 *     a zero.
 * Only emitted when transactions was requested. `state_stream: "accounts"`
 * mirrors chase: the accounts cursor commit is gated on this stream's detail
 * coverage being honestly accounted for (hydrated or a same-run DETAIL_GAP),
 * never silently advanced past an unreached account.
 */
export declare function emitTransactionsDetailCoverage(deps: EmitDeps, outcomes: readonly AccountTransactionOutcome[], enumerationComplete: boolean): Promise<void>;
export interface AccountTransactionResult {
    last_date: string | null;
    outcome: AccountTransactionOutcome;
}
/**
 * Classify a downloaded-and-parsed CSV into the account's per-run detail
 * outcome + cursor decision. Pure — exported so the coverage classification
 * is testable without driving the Playwright export flow. The distinction
 * that matters (`csvResult` comes straight from `emitCsvTransactions`):
 *   - `usableCount > 0`: real transactions parsed → `hydrated`; the cursor
 *     advances to the latest parsed date (or the window start).
 *   - `usableCount === 0 && dataRows === 0`: the export produced a
 *     headers-only CSV — the source genuinely had no transactions for the
 *     window. A dormant account exports exactly this every run, so it is
 *     the same source-limited answer as the explicit "nothing to export"
 *     dialog → `no_activity` (covered), NEVER a gap. Classifying it as a
 *     gap would pin a pending retryable DETAIL_GAP on a healthy dormant
 *     account forever (permanent Degraded).
 *   - `usableCount === 0 && dataRows > 0`: data rows were present but none
 *     parsed to a usable transaction (header mismatch / unparseable rows)
 *     → genuine parse trouble, a retryable `gap` so a parser fix can
 *     recover it next run. (`emitCsvTransactions` already emitted the
 *     matching `csv_no_usable_transactions` SKIP_RESULT.)
 * In both zero-usable cases `last_date` stays at the prior watermark
 * (possibly null → the caller writes no cursor entry), preserving the
 * pre-coverage behavior of never advancing the cursor on a run that parsed
 * nothing.
 */
export declare function classifyCsvTransactionResult(accountId: string, priorLastDate: string | null, usedSince: string | null, csvResult: {
    dataRows: number;
    latest: string | null;
    usableCount: number;
}): AccountTransactionResult;
/**
 * Exported purely so its mid-run session-repair wiring is directly
 * testable with a mocked Page/BrowserContext. See
 * singleton-checkpoint-coverage-wiring.test.ts.
 *
 * Return value means "no USAA logon bounce was observed navigating this
 * stream" — NOT "the session is definitively alive." The catch block below
 * returns `true` for any non-navigation scrape error (DOM parse failure,
 * network blip mid-scrape, etc.) without re-checking `page.url()`, since
 * those are unrelated to session death. A caller relying on this value to
 * mean "confirmed alive" would be wrong in that catch path; it correctly
 * means only "not confirmed dead."
 */
export declare function runStatementsStream(deps: StatementsSubDeps, context: BrowserContext, sendInteraction: BrowserCollectContext["sendInteraction"], accounts: readonly DashboardAccount[], requested: BrowserCollectContext["requested"], streamState: UsaaRunState, statementsFingerprintCursor?: FingerprintCursor, transactionsFingerprintCursor?: FingerprintCursor, statementsHydrationCursor?: StatementHydrationCursor): Promise<boolean>;
/**
 * Exported (in addition to being called from `collect()`) purely so its
 * DETAIL_COVERAGE emit-path wiring is directly testable with a mocked Page —
 * never emit coverage after a caught scrape failure, only after a
 * successful enumeration. See singleton-checkpoint-coverage.test.ts.
 *
 * Return value semantics match `runStatementsStream`: "no logon bounce was
 * observed," not "confirmed alive" — a caught non-navigation scrape error
 * also returns `true`.
 */
export declare function runInboxStream(deps: EmitDeps, context: BrowserContext, page: Page, sendInteraction: BrowserCollectContext["sendInteraction"], state: Record<string, unknown>, streamState: UsaaRunState): Promise<boolean>;
/**
 * Parse the prior `credit_card_billing` STATE cursor's `fingerprints`
 * map. Keyed by the billing record `id` (the account id, last-four, or a
 * hash of the raw text). Legacy cursors (only `{ fetched_at }`) decode to
 * an empty map, so the first post-deploy run rebuilds the map and re-emits
 * every card exactly once.
 */
export declare function readPriorCreditCardBillingFingerprints(state: Record<string, unknown>): Map<string, string>;
/** Which of the two credit-card streams to emit. The entity
 *  (`credit_card_billing`) and the observation (`credit_card_billing_stats`)
 *  are independently scoped. `observedOn` is the UTC sample date. The entity
 *  cursor is only supplied when the entity is requested. */
export interface CreditCardBillingEmitOptions {
    emitEntity: boolean;
    emitStats: boolean;
    fingerprintCursor: FingerprintCursor | undefined;
    observedOn: string;
}
/** The credit-card boundary both streams enumerate: dashboard accounts whose
 *  type matches USAA's credit-card route. Exported so the coverage
 *  `considered`/`covered` arithmetic (`considered === covered ===
 *  creditCardAccounts(accounts).length`, including 0 when the owner holds no
 *  credit cards) is independently unit-testable without driving a live page
 *  through `runCreditCardBillingStream`'s multi-second per-card settle delay. */
export declare function creditCardAccounts(accounts: readonly DashboardAccount[]): DashboardAccount[];
/** Exported (in addition to being called from `collect()`) purely so its
 *  DETAIL_COVERAGE emit-path wiring is directly testable with a mocked Page —
 *  never emit coverage after a caught scrape failure, only after a
 *  successful enumeration. See singleton-checkpoint-coverage.test.ts. */
export declare function runCreditCardBillingStream(deps: EmitDeps, context: BrowserContext, page: Page, sendInteraction: BrowserCollectContext["sendInteraction"], accounts: readonly DashboardAccount[], streamState: UsaaRunState, options: CreditCardBillingEmitOptions): Promise<void>;
export declare const USAA_RETRYABLE_PATTERN: RegExp;
/**
 * Orchestrate every USAA stream for one run. Exported (in addition to being
 * wired as `runConnector`'s `collect`) purely so the cross-stream
 * session-death latch/budget behavior is directly testable end-to-end with a
 * mocked Page/BrowserContext, without needing to drive `runConnector`'s CLI
 * entry point. See `singleton-checkpoint-coverage-wiring.test.ts`'s
 * `collectUsaa` block for the collect()-level proof that a statements/inbox
 * session death actually suppresses later streams (not just the per-stream
 * unit behavior already covered in `late-auth-self-heal.test.ts`).
 */
export declare function collectUsaa(ctx: BrowserCollectContext): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map