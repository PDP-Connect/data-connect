// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/** Compute the inbox `considered`/`covered` pair from the resolved rows.
 *  `considered` is every row the enumeration saw; `covered` counts only rows
 *  that resolved into a record (emitted or suppressed-unchanged — the caller
 *  does not need to distinguish those two here, since both are "accounted
 *  for"). A row that failed to resolve (unparseable date) lowers `covered`
 *  below `considered`, so the caller reads an honest `partial`, not a false
 *  `complete`. `rows.length === 0` (a genuinely empty inbox) still returns
 *  `{ considered: 0, covered: 0 }` — verified-empty, not unmeasured. */
export function computeInboxCoverage(rows) {
    let covered = 0;
    for (const row of rows) {
        if (row.resolved) {
            covered += 1;
        }
    }
    return { considered: rows.length, covered };
}
