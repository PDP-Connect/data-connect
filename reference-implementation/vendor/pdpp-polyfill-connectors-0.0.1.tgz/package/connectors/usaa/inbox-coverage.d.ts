/** One inbox row the page listed, already resolved to whether it produced a
 *  record (`buildInboxMessageRecord` returned non-null) — passed in so this
 *  module never imports the connector's own parsing or `index.ts`. */
export interface InboxCoverageRow {
    resolved: boolean;
}
export interface InboxCoverageResult {
    considered: number;
    covered: number;
}
/** Compute the inbox `considered`/`covered` pair from the resolved rows.
 *  `considered` is every row the enumeration saw; `covered` counts only rows
 *  that resolved into a record (emitted or suppressed-unchanged — the caller
 *  does not need to distinguish those two here, since both are "accounted
 *  for"). A row that failed to resolve (unparseable date) lowers `covered`
 *  below `considered`, so the caller reads an honest `partial`, not a false
 *  `complete`. `rows.length === 0` (a genuinely empty inbox) still returns
 *  `{ considered: 0, covered: 0 }` — verified-empty, not unmeasured. */
export declare function computeInboxCoverage(rows: readonly InboxCoverageRow[]): InboxCoverageResult;
//# sourceMappingURL=inbox-coverage.d.ts.map