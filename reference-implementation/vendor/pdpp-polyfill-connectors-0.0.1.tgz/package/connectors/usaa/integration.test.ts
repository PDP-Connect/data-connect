// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

/**
 * Integration tests for the USAA connector's `collect()` emit path —
 * the per-stream helpers in index.ts (emitAccountsStream,
 * emitStatementRecords, emitDeferredStreams, emitExportFailure) plus
 * the pure buildIndexRows / hydrationSuccess / shouldParseStatementTitle
 * filters.
 *
 * These tests DON'T drive Playwright. They construct a fake EmitDeps
 * backed by `makeRecordingEmit(validateRecord)` — every emitted record
 * is run through the real zod schema so fixture drift fails the test
 * instead of silently passing. Captures every (stream, data) pair
 * pushed through emitRecord plus every non-RECORD EmittedMessage
 * pushed through emit, then asserts on the observable invariants:
 * parent-before-child ordering,
 * stream-scope suppression, null-enrichment fallback (failed PDF
 * hydration → index-only row), backfill-ladder-exhausted SKIP shape,
 * and emittedAt propagation into account records.
 *
 * Imports directly from ./index.ts — `runConnector({...})` is guarded by
 * `isMainModule(import.meta.url)` so it only fires when index.ts is the
 * process entry point, not when a test imports it.
 *
 * Why bother: parsers.test.ts proves record *shapes* are correct from
 * DOM/CSV/PDF input. Integration tests on the emit path prove the
 * invariants downstream consumers observe:
 *   - accounts emit before transactions/statements in a single run,
 *   - deferred streams emit SKIP_RESULT only when the client asked,
 *   - a requested-but-empty scope produces zero records,
 *   - a failed PDF hydration still emits the statement record
 *     (index-only: pdf_path/pdf_sha256/document_url all null),
 *   - emittedAt on account records threads the run-level timestamp
 *     (not a scattered Date.now() read),
 *   - ladder-exhausted SKIP_RESULT carries the last diagnostic (so
 *     the owner can see the failing phase without re-running),
 *   - duplicate index rows dedupe to one record per rowIndex (the
 *     hydration map keys by rowIndex, so a row emitted twice with the
 *     same result emits the same record — verified as non-regression).
 * Regressing any of these is a real data-integrity bug.
 */

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import type { BrowserContext, Page } from "playwright";
import type { BodyResponseDiagnostics } from "../../src/browser-artifact-response.ts";
import type {
	EmittedMessage,
	StreamScope,
} from "../../src/connector-runtime.ts";
import type { CaptureSession } from "../../src/fixture-capture.ts";
import {
	type EmittedRecord,
	makeRecordingEmit,
} from "../../src/test-harness.ts";
import {
	buildIndexRows,
	buildPdfTemplateUnknownDiagnostics,
	buildServedStatementGapLookup,
	classifyUsaaNoExportRoute,
	DEFERRED_STREAMS,
	driveExport,
	type EmitDeps,
	emitAccountsStream,
	emitDeferredStreams,
	emitExportFailure,
	emitStatementCoverage,
	emitStatementRecords,
	type HydrationSummary,
	hydrationSuccess,
	isNoDataExportMessage,
	resolveUsaaOfferInterstitialEscape,
	runSingleLadderAttempt,
	shouldParseStatementTitle,
	USAA_RETRYABLE_PATTERN,
	type UsaaRunState,
} from "./index.ts";
import { validateRecord } from "./schemas.ts";
import {
	buildUsaaStatementMenuDiagnostic,
	hydrateStatementPdfs,
	summarizeUsaaStatementResponseDiagnostics,
} from "./statement-pdfs.ts";
import type {
	DashboardAccount,
	DiagnosticInfo,
	DocRow,
	HydrationResult,
	HydrationResultSuccess,
	IndexRow,
} from "./types.ts";

interface RecordingHarness {
	deps: EmitDeps;
	emitted: EmittedRecord[];
	messages: EmittedMessage[];
}

const USAA_MANIFEST_PATH = new URL(
	"../../manifests/usaa.json",
	import.meta.url,
);
const FROZEN_EMITTED_AT = "2026-04-22T12:00:00.000Z";

/** Build an EmitDeps that records every emit() + emitRecord() call
 *  through the real zod schema the runtime applies in production.
 *  The helpers under test are Playwright-free, so no tmpDir/progress/
 *  capture fakes are needed. */
function makeHarness(): RecordingHarness {
	const harness = makeRecordingEmit(validateRecord);
	const deps: EmitDeps = {
		emit: harness.emit,
		emitRecord: harness.emitRecord,
	};
	return { deps, emitted: harness.emitted, messages: harness.protocolMessages };
}

function makeAccount(
	overrides: Partial<DashboardAccount> = {},
): DashboardAccount {
	return {
		account_id_raw: "ACCT-CHK-0001",
		account_type: "checking",
		account_url: "/my/checking?accountId=ACCT-CHK-0001",
		balance_cents: 123_456,
		last_four: "9241",
		name: "USAA CLASSIC CHECKING",
		raw_text: "USAA CLASSIC CHECKING Ending in *9241 $1,234.56",
		...overrides,
	};
}

function makeDocRow(overrides: Partial<DocRow> = {}): DocRow {
	return {
		account_reference: "USAA CLASSIC CHECKING *9241",
		date_delivered: "Apr 13, 2026",
		rowIndex: 0,
		title: "April 2026 STATEMENT",
		...overrides,
	};
}

function makeIndexRow(overrides: Partial<IndexRow> = {}): IndexRow {
	return {
		account_id: "ACCT-CHK-0001",
		account_reference: "USAA CLASSIC CHECKING *9241",
		date_delivered: "2026-04-13",
		id: "IDX-ID-0001",
		rowIndex: 0,
		title: "April 2026 STATEMENT",
		...overrides,
	};
}

function makeHydrationOk(
	overrides: Partial<HydrationResultSuccess> = {},
): HydrationResultSuccess {
	return {
		buffer: Buffer.from("pdf-bytes"),
		pdfPath: "/tmp/usaa-test/statement-0.pdf",
		pdfSha256: "deadbeef".repeat(8),
		content: { pdf_text_sha256: null, pdf_page_count: null },
		...overrides,
	};
}

function makeNoExportPage(
	finalUrl: string,
	counts: {
		account_detail_marker_count: number;
		navigation_marker_count: number;
		target_count: number;
		transaction_marker_count: number;
	},
): Page {
	return Object.assign({} as Page, {
		evaluate() {
			return Promise.resolve(counts);
		},
		goto() {
			return Promise.resolve(null);
		},
		locator() {
			return {
				count() {
					return Promise.resolve(0);
				},
				filter() {
					return this;
				},
			};
		},
		url() {
			return finalUrl;
		},
	});
}

function requestedWith(names: readonly string[]): Map<string, StreamScope> {
	return new Map<string, StreamScope>(names.map((n) => [n, { name: n }]));
}

test("runtime retry classification includes source-unavailable login failures", () => {
	assert.match(
		"source_unavailable: USAA reported its login system is currently unavailable after Next click.",
		USAA_RETRYABLE_PATTERN,
	);
});

// ─── Invariant 1: parent-before-child (accounts before statements) ───────

test("emit order: accounts stream emits before statements for the same run", async () => {
	const { deps, emitted } = makeHarness();
	const accounts = [makeAccount()];
	const indexRows = [makeIndexRow()];
	const hydration = new Map<number, HydrationResult>([[0, makeHydrationOk()]]);
	const summary: HydrationSummary = {
		attempts: 1,
		successes: 1,
		results: hydration,
	};

	await emitAccountsStream(deps, accounts, FROZEN_EMITTED_AT);
	await emitStatementRecords(deps, indexRows, hydration, summary);

	const accountIdx = emitted.findIndex((r) => r.stream === "accounts");
	const stmtIdx = emitted.findIndex((r) => r.stream === "statements");
	assert.notEqual(accountIdx, -1, "expected an accounts record");
	assert.notEqual(stmtIdx, -1, "expected a statements record");
	assert.ok(accountIdx < stmtIdx, "accounts must emit before statements");
});

// ─── Invariant 2: stream-scope filters cleanly ───────────────────────────

test("emitDeferredStreams: only emits for streams the client actually requested", async () => {
	const { deps, messages } = makeHarness();
	// Client asks for a subset of deferred streams (transfers + bill_payments)
	// plus unrelated streams (accounts, statements).
	const requested = requestedWith([
		"accounts",
		"statements",
		"transfers",
		"bill_payments",
	]);
	await emitDeferredStreams(deps.emit, requested);

	const skipStreams = messages
		.filter(
			(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
				m.type === "SKIP_RESULT",
		)
		.map((m) => m.stream)
		.sort((a, b) => a.localeCompare(b));
	assert.deepEqual(
		skipStreams,
		["bill_payments", "transfers"],
		"only the requested deferred streams emit SKIP",
	);
});

test("emitDeferredStreams: every SKIP_RESULT carries reason='selectors_pending'", async () => {
	const { deps, messages } = makeHarness();
	const requested = requestedWith([...DEFERRED_STREAMS]);
	await emitDeferredStreams(deps.emit, requested);
	const skips = messages.filter(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT",
	);
	assert.equal(
		skips.length,
		DEFERRED_STREAMS.length,
		"one SKIP per deferred stream when all are requested",
	);
	for (const s of skips) {
		assert.equal(
			s.reason,
			"selectors_pending",
			`stream=${s.stream} should flag selectors_pending`,
		);
	}
});

// ─── Invariant 3: all-streams-disabled → nothing ─────────────────────────

test("emitDeferredStreams: empty requested scope emits nothing", async () => {
	const { deps, messages } = makeHarness();
	const requested = requestedWith([]);
	await emitDeferredStreams(deps.emit, requested);
	assert.equal(
		messages.length,
		0,
		"no SKIP_RESULTs when client didn't request any deferred streams",
	);
});

test("emitAccountsStream over zero accounts emits only the STATE heartbeat (no records)", async () => {
	const { deps, emitted, messages } = makeHarness();
	await emitAccountsStream(deps, [], FROZEN_EMITTED_AT);
	assert.equal(
		emitted.length,
		0,
		"no accounts records emitted when there are no accounts",
	);
	const states = messages.filter((m) => m.type === "STATE");
	assert.equal(
		states.length,
		1,
		"STATE heartbeat still emits on empty runs (marks the stream as attempted)",
	);
});

// ─── Invariant 4: null-enrichment fallback (failed PDF → index-only row) ─

test("emitStatementRecords: failed hydration emits index-only record (all pdf fields null)", async () => {
	const { deps, emitted } = makeHarness();
	const indexRows = [makeIndexRow()];
	// No entry in the hydration map at all — the helper must still emit.
	const hydration = new Map<number, HydrationResult>();
	const summary: HydrationSummary = {
		attempts: 1,
		successes: 0,
		results: hydration,
	};
	await emitStatementRecords(deps, indexRows, hydration, summary);

	const stmt = emitted.find((r) => r.stream === "statements");
	assert.ok(
		stmt,
		"a statements record must still emit when PDF hydration failed",
	);
	assert.equal(stmt.data.pdf_path, null, "null pdf_path marks the fallback");
	assert.equal(stmt.data.pdf_sha256, null);
	assert.equal(stmt.data.document_url, null);
	assert.equal(
		stmt.data.title,
		"April 2026 STATEMENT",
		"title survives to the index-only record",
	);
	assert.equal(stmt.data.id, "IDX-ID-0001");
});

test("emitStatementRecords: hydrated rows populate pdf_path + pdf_sha256 + document_url", async () => {
	const { deps, emitted } = makeHarness();
	const indexRows = [makeIndexRow()];
	const ok = makeHydrationOk({
		pdfPath: "/tmp/usaa-test/hydrated.pdf",
		pdfSha256: "cafef00d".repeat(8),
	});
	const hydration = new Map<number, HydrationResult>([[0, ok]]);
	const summary: HydrationSummary = {
		attempts: 1,
		successes: 1,
		results: hydration,
	};
	await emitStatementRecords(deps, indexRows, hydration, summary);

	const stmt = emitted.find((r) => r.stream === "statements");
	assert.ok(stmt);
	assert.equal(stmt.data.pdf_path, "/tmp/usaa-test/hydrated.pdf");
	assert.equal(stmt.data.pdf_sha256, "cafef00d".repeat(8));
	// document_url is a file:// URL derived from pdfPath — we assert the prefix rather than the full
	// platform-dependent path to keep the test portable.
	assert.match(
		String(stmt.data.document_url),
		/^file:\/\//,
		"document_url should be a file:// URL",
	);
});

// ─── Invariant 4c: per-run detail-coverage evidence on the emit path ─────

function statementCoverage(
	messages: readonly EmittedMessage[],
): EmittedMessage | undefined {
	return messages.find(
		(m) => m.type === "DETAIL_COVERAGE" && m.stream === "statements",
	);
}
function statementGaps(messages: readonly EmittedMessage[]): EmittedMessage[] {
	return messages.filter(
		(m) => m.type === "DETAIL_GAP" && m.stream === "statements",
	);
}

test("emitStatementRecords: fully hydrated statement run emits DETAIL_COVERAGE with required === hydrated, no gaps", async () => {
	const { deps, messages } = makeHarness();
	const indexRows = [
		makeIndexRow({ rowIndex: 0, id: "S0" }),
		makeIndexRow({ rowIndex: 1, id: "S1" }),
	];
	const hydration = new Map<number, HydrationResult>([
		[0, makeHydrationOk()],
		[1, makeHydrationOk({ pdfPath: "/tmp/usaa-test/statement-1.pdf" })],
	]);
	const summary: HydrationSummary = {
		attempts: 2,
		successes: 2,
		results: hydration,
	};
	await emitStatementRecords(deps, indexRows, hydration, summary);

	const coverage = statementCoverage(messages);
	assert.ok(
		coverage && coverage.type === "DETAIL_COVERAGE",
		"a DETAIL_COVERAGE must be emitted",
	);
	assert.equal(coverage.reference_only, true);
	assert.equal(coverage.state_stream, "statements");
	assert.deepEqual([...coverage.required_keys].sort(), ["S0", "S1"]);
	assert.deepEqual([...coverage.hydrated_keys].sort(), ["S0", "S1"]);
	assert.equal(coverage.considered, 2);
	assert.equal(coverage.covered, 2);
	assert.equal(
		coverage.gap_keys,
		undefined,
		"no gap_keys when every PDF is present",
	);
	assert.equal(
		statementGaps(messages).length,
		0,
		"no DETAIL_GAP when fully hydrated",
	);
});

test("emitStatementRecords: a failed statement PDF surfaces a DETAIL_GAP + gap_key (partial, not complete)", async () => {
	const { deps, messages } = makeHarness();
	const indexRows = [
		makeIndexRow({ rowIndex: 0, id: "OK" }),
		makeIndexRow({ rowIndex: 1, id: "MISS" }),
	];
	// Only row 0 hydrated; row 1 has no map entry and no carry-forward cursor.
	const hydration = new Map<number, HydrationResult>([[0, makeHydrationOk()]]);
	const summary: HydrationSummary = {
		attempts: 2,
		successes: 1,
		results: hydration,
	};
	await emitStatementRecords(deps, indexRows, hydration, summary);

	const coverage = statementCoverage(messages);
	assert.ok(coverage && coverage.type === "DETAIL_COVERAGE");
	assert.deepEqual([...coverage.required_keys].sort(), ["MISS", "OK"]);
	assert.deepEqual(coverage.hydrated_keys, ["OK"]);
	assert.equal(coverage.considered, 2);
	assert.equal(coverage.covered, 1);
	assert.deepEqual(coverage.gap_keys, ["MISS"]);

	const gaps = statementGaps(messages);
	assert.equal(gaps.length, 1, "exactly one DETAIL_GAP for the missing PDF");
	const [gap] = gaps;
	assert.ok(gap && gap.type === "DETAIL_GAP");
	assert.equal(gap.record_key, "MISS");
	assert.equal(gap.status, "pending");
	assert.equal(gap.retryable, true);
	assert.equal(gap.reference_only, true);
});

test("emitStatementRecords: required_keys === hydrated_keys ∪ gap_keys (runtime coverage-completeness invariant)", async () => {
	const { deps, messages } = makeHarness();
	const indexRows = [
		makeIndexRow({ rowIndex: 0, id: "H0" }),
		makeIndexRow({ rowIndex: 1, id: "G1" }),
		makeIndexRow({ rowIndex: 2, id: "H2" }),
	];
	const hydration = new Map<number, HydrationResult>([
		[0, makeHydrationOk()],
		[2, makeHydrationOk({ pdfPath: "/tmp/usaa-test/statement-2.pdf" })],
	]);
	const summary: HydrationSummary = {
		attempts: 3,
		successes: 2,
		results: hydration,
	};
	await emitStatementRecords(deps, indexRows, hydration, summary);

	const coverage = statementCoverage(messages);
	assert.ok(coverage && coverage.type === "DETAIL_COVERAGE");
	const union = new Set([
		...coverage.hydrated_keys,
		...(coverage.gap_keys ?? []),
	]);
	assert.equal(union.size, coverage.required_keys.length);
	for (const key of coverage.required_keys) {
		assert.ok(
			union.has(key),
			`required key ${String(key)} is hydrated or a pending gap`,
		);
	}
	// Every gap_key has exactly one matching pending DETAIL_GAP.
	const gapKeys = new Set(
		statementGaps(messages).map((g) => g.type === "DETAIL_GAP" && g.record_key),
	);
	for (const key of coverage.gap_keys ?? []) {
		assert.ok(gapKeys.has(key), `gap key ${String(key)} has a DETAIL_GAP`);
	}
});

test("emitStatementRecords: a run with only disclosures (no statement docs) still emits a zero-candidate DETAIL_COVERAGE", async () => {
	const { deps, messages } = makeHarness();
	// Titles the statement-parse predicate rejects (agreement/disclosure).
	const indexRows = [
		makeIndexRow({ rowIndex: 0, id: "D0", title: "CARDHOLDER AGREEMENT" }),
		makeIndexRow({ rowIndex: 1, id: "D1", title: "PRIVACY DISCLOSURE" }),
	];
	const hydration = new Map<number, HydrationResult>();
	const summary: HydrationSummary = {
		attempts: 0,
		successes: 0,
		results: hydration,
	};
	await emitStatementRecords(deps, indexRows, hydration, summary);

	// Enumeration completed (the documents index was scraped; it just had zero
	// statement-document candidates), so the run measured its denominator and
	// must report it — considered: 0 / covered: 0 — rather than staying silent.
	const coverage = statementCoverage(messages);
	assert.ok(
		coverage && coverage.type === "DETAIL_COVERAGE",
		"a zero-candidate run still emits DETAIL_COVERAGE",
	);
	assert.deepEqual(coverage.required_keys, []);
	assert.deepEqual(coverage.hydrated_keys, []);
	assert.equal(coverage.considered, 0);
	assert.equal(coverage.covered, 0);
	assert.equal(
		coverage.gap_keys,
		undefined,
		"no gaps when there is no real denominator",
	);
	assert.equal(
		statementGaps(messages).length,
		0,
		"no DETAIL_GAP for non-statement rows",
	);
	// The statement records themselves still emit (index-only) — coverage is additive.
	// (The disclosure rows are honest `statements` records; the PDF-detail
	//  coverage report now reflects the measured zero denominator instead of
	//  being suppressed.)
});

test("emitStatementRecords: zero statement-document rows scraped still emits a zero-candidate DETAIL_COVERAGE", async () => {
	const { deps, messages } = makeHarness();
	const hydration = new Map<number, HydrationResult>();
	const summary: HydrationSummary = {
		attempts: 0,
		successes: 0,
		results: hydration,
	};
	await emitStatementRecords(deps, [], hydration, summary);

	const coverage = statementCoverage(messages);
	assert.ok(
		coverage && coverage.type === "DETAIL_COVERAGE",
		"an empty documents index still emits DETAIL_COVERAGE",
	);
	assert.deepEqual(coverage.required_keys, []);
	assert.deepEqual(coverage.hydrated_keys, []);
	assert.equal(coverage.considered, 0);
	assert.equal(coverage.covered, 0);
});

test("emitStatementRecords: DETAIL_GAP and DETAIL_COVERAGE never interpolate statement title or account text", async () => {
	const { deps, messages } = makeHarness();
	const indexRows = [
		makeIndexRow({
			rowIndex: 0,
			id: "S0",
			title: "April 2026 STATEMENT",
			account_reference: "USAA CLASSIC CHECKING *9241",
		}),
	];
	const hydration = new Map<number, HydrationResult>();
	const summary: HydrationSummary = {
		attempts: 1,
		successes: 0,
		results: hydration,
	};
	await emitStatementRecords(deps, indexRows, hydration, summary);

	const refMessages = [
		statementCoverage(messages),
		...statementGaps(messages),
	].filter(Boolean);
	assert.ok(refMessages.length >= 1, "coverage + at least one gap emitted");
	const serialized = JSON.stringify(refMessages);
	// Target the fixture's document-title + account-reference PII (e.g. "April",
	// "CHECKING", "*9241"), NOT the legitimate lowercase `statements` /
	// `statement_id` protocol identifiers, which are not PII.
	assert.doesNotMatch(
		serialized,
		/April|CHECKING|CLASSIC|\*9241/,
		"no title/account text leaks into coverage evidence",
	);
	assert.match(serialized, /S0/, "only the opaque statement id appears");
});

// ─── Invariant 4b: buildIndexRows drops rows missing date_delivered ──────

test("buildIndexRows: rows without a date_delivered are dropped (no undated keys)", () => {
	const docs: DocRow[] = [
		makeDocRow({ rowIndex: 0, title: "January 2026 STATEMENT" }),
		makeDocRow({ rowIndex: 1, date_delivered: "", title: "BROKEN STATEMENT" }),
		makeDocRow({ rowIndex: 2, title: "February 2026 STATEMENT" }),
	];
	const rows = buildIndexRows(docs, [makeAccount()]);
	assert.equal(rows.length, 2, "undated row dropped; dated rows kept");
	const kept = rows.map((r) => r.rowIndex);
	assert.deepEqual(kept, [0, 2]);
});

test("buildIndexRows: blank account reference normalizes to null", () => {
	const rows = buildIndexRows(
		[makeDocRow({ account_reference: "   " })],
		[makeAccount()],
	);
	assert.equal(rows.length, 1);
	assert.equal(rows[0]?.account_reference, null);
	assert.equal(rows[0]?.account_id, null);
});

// ─── Invariant 5: dedup — repeated hydration map key yields one emit per row ─

test("emitStatementRecords: duplicate rowIndex in indexRows emits once per row entry (no hidden dedupe)", async () => {
	// The helper is faithful to its input — if the same indexRow is passed twice,
	// it emits twice. Dedup happens at the index-row build layer (via hashId),
	// not the emit layer. This test pins that contract: regressing it would
	// either introduce a surprising dedup in the emit path or silently drop
	// a second occurrence.
	const { deps, emitted } = makeHarness();
	const row = makeIndexRow();
	const hydration = new Map<number, HydrationResult>([[0, makeHydrationOk()]]);
	const summary: HydrationSummary = {
		attempts: 1,
		successes: 1,
		results: hydration,
	};
	await emitStatementRecords(deps, [row, row], hydration, summary);
	const stmts = emitted.filter((r) => r.stream === "statements");
	assert.equal(
		stmts.length,
		2,
		"each indexRow entry produces one emit; dedup is upstream",
	);
	assert.equal(
		stmts[0]?.data.id,
		stmts[1]?.data.id,
		"both emits share the same hashId",
	);
});

// ─── Invariant 6: emittedAt propagation into the accounts record ─────────

test("emitAccountsStream: emittedAt propagates into every accounts record's fetched_at", async () => {
	const { deps, emitted } = makeHarness();
	const frozen = "2026-01-15T08:00:00.000Z";
	const accounts = [
		makeAccount({ account_id_raw: "A1" }),
		makeAccount({
			account_id_raw: "A2",
			name: "USAA SAVINGS",
			account_type: "savings",
		}),
	];
	await emitAccountsStream(deps, accounts, frozen);
	const accountRecords = emitted.filter((r) => r.stream === "accounts");
	assert.equal(accountRecords.length, 2);
	for (const r of accountRecords) {
		assert.equal(
			r.data.fetched_at,
			frozen,
			`fetched_at on account id=${String(r.data.id)} must be the frozen emittedAt`,
		);
	}
});

// ─── Invariant 7: backfill ladder exhausted → SKIP_RESULT shape ──────────

test("emitExportFailure: a missing export affordance is reported as a structure-changed outcome, not export_no_download", async () => {
	// `no_export_affordance` is one of the two fatal phases the ladder breaks on:
	// the export button/page was never located, so a shorter date window can't
	// help. That is the "source UI/API changed" outcome, and it must be visible
	// to the dashboard as a distinct reason — not collapsed into the transient
	// `export_no_download` bucket — so a structurally-broken connector is not
	// mistaken for momentary export pressure.
	const { deps, messages } = makeHarness();
	const diag: DiagnosticInfo = {
		phase: "no_export_affordance",
		no_export_observation: {
			account_detail_marker_count: 1,
			navigation_marker_count: 2,
			route: "expected",
			target_count: 0,
			transaction_marker_count: 1,
		},
		diag: {
			url: "https://www.usaa.com/my/checking?accountId=ACCT-CHK-0001",
			title: "Checking",
			has_utility_bar: false,
			export_candidates: [],
			nav_candidates: [],
			dialogs_open: 0,
		},
	};
	await emitExportFailure(deps, makeAccount(), diag);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT",
	);
	assert.ok(skip, "SKIP_RESULT must emit when the ladder is exhausted");
	assert.equal(
		skip.stream,
		"transactions",
		"export failure is charged to the transactions stream",
	);
	assert.equal(
		skip.reason,
		"export_affordance_missing",
		"a missing affordance/dialog is a structure-changed outcome",
	);
	assert.equal(
		skip.message,
		"USAA transaction export affordance was not found on the observed browser surface",
	);
	const emittedDiag = skip.diagnostics as {
		browser_surface: Record<string, unknown>;
	};
	assert.deepEqual(emittedDiag, {
		browser_surface: {
			account_detail_marker_count: 1,
			activity_table_marker_count: 0,
			dashboard_marker_count: 0,
			managed_surface: "unknown",
			navigation_marker_count: 2,
			parser_count: 0,
			phase: "no_export_affordance",
			posture: "recognized",
			read_count: 1,
			route: "expected",
			surface: "usaa_transaction_export",
			target_count: 0,
			transaction_marker_count: 1,
			verified_empty_marker_count: 0,
			wait_outcome: "not_needed",
		},
	});
	const serialized = JSON.stringify({
		message: skip.message,
		diagnostics: skip.diagnostics,
	});
	assert.doesNotMatch(
		serialized,
		/accountId=|https?:\/\/|Checking|BUTTON|ACCT-CHK-0001/,
	);
});

test("classifyUsaaNoExportRoute requires both a closed account route and structural marker", () => {
	assert.equal(
		classifyUsaaNoExportRoute(
			"https://www.usaa.com/my/checking?accountId=private",
			true,
		),
		"expected",
	);
	assert.equal(
		classifyUsaaNoExportRoute(
			"https://www.usaa.com/my/checking?accountId=private",
			false,
		),
		"unknown",
	);
	assert.equal(
		classifyUsaaNoExportRoute("https://www.usaa.com/challenge/step", true),
		"interstitial",
	);
	assert.equal(
		classifyUsaaNoExportRoute("https://www.usaa.com/my/logon", true),
		"interstitial",
	);
	assert.equal(
		classifyUsaaNoExportRoute("https://www.usaa.com/my/dashboard", true),
		"unknown",
	);
	assert.equal(
		classifyUsaaNoExportRoute("https://private.example/my/checking", true),
		"unknown",
	);
});

const STATEMENT_HYDRATED = {
	document_url:
		"file:///home/user/.pdpp/usaa-statements/chk/2026-04-aaaaaaaa.pdf",
	pdf_path: "/home/user/.pdpp/usaa-statements/chk/2026-04-aaaaaaaa.pdf",
	pdf_sha256: "aa".repeat(32),
};
const STATEMENT_NOT_HYDRATED = {
	document_url: null,
	pdf_path: null,
	pdf_sha256: null,
};

/** A served pending `statements` gap in the shape the runtime supplies. */
function servedStatementGap(statementId: string, gapId: string) {
	return {
		gap_id: gapId,
		record_key: statementId,
		status: "pending",
		stream: "statements",
		detail_locator: { kind: "usaa.statement", statement_id: statementId },
	};
}

/**
 * A pending detail gap only leaves `pending` on an explicit
 * `DETAIL_GAP_RECOVERED`. This connector emitted that for `transactions` and
 * the credit-card streams but never for `statements`, so a statement PDF that
 * failed once and downloaded fine afterwards kept its gap forever.
 *
 * Owner-visible symptom: 4 `statements` gaps pending from a 2026-08-04 run
 * (three never even re-attempted, `attempt_count = 0`) while the same stream
 * reported `covered: 10 / considered: 10, checkpoint: committed` — and all four
 * of those statements had a durable `pdf_sha256` on their record. Fully
 * collected and showing a retryable gap at the same time.
 */
test("emitStatementCoverage: recovers a served statement gap once the PDF is present again", async () => {
	const { deps, messages } = makeHarness();
	await emitStatementCoverage(
		{
			...deps,
			servedStatementGaps: new Map([["stmt-recovered", "gap-recovered"]]),
		},
		[{ id: "stmt-recovered", isCandidate: true, pointers: STATEMENT_HYDRATED }],
	);

	assert.deepEqual(
		messages.filter((m) => m.type === "DETAIL_GAP_RECOVERED"),
		[
			{
				type: "DETAIL_GAP_RECOVERED",
				reference_only: true,
				gap_id: "gap-recovered",
				stream: "statements",
				record_key: "stmt-recovered",
			},
		],
		"a statement whose PDF is present again must close its served gap, or the gap stays pending forever",
	);
});

test("emitStatementCoverage: never closes a gap for a statement still missing its PDF", async () => {
	const { deps, messages } = makeHarness();
	await emitStatementCoverage(
		{
			...deps,
			// Both ids are served, but only one statement actually has its PDF.
			servedStatementGaps: new Map([
				["stmt-have", "gap-have"],
				["stmt-missing", "gap-missing"],
			]),
		},
		[
			{ id: "stmt-have", isCandidate: true, pointers: STATEMENT_HYDRATED },
			{
				id: "stmt-missing",
				isCandidate: true,
				pointers: STATEMENT_NOT_HYDRATED,
			},
		],
	);

	assert.deepEqual(
		messages
			.filter((m) => m.type === "DETAIL_GAP_RECOVERED")
			.map((m) => m.gap_id),
		["gap-have"],
		"recovery must follow the hydration proof, never merely the fact that a gap was served",
	);
	assert.ok(
		messages.some(
			(m) => m.type === "DETAIL_GAP" && m.record_key === "stmt-missing",
		),
		"the still-missing statement must keep a pending gap",
	);
});

test("emitStatementCoverage: only closes gaps the runtime actually served", async () => {
	const { deps, messages } = makeHarness();
	await emitStatementCoverage({ ...deps, servedStatementGaps: new Map() }, [
		{ id: "stmt-unserved", isCandidate: true, pointers: STATEMENT_HYDRATED },
	]);

	assert.deepEqual(
		messages.filter((m) => m.type === "DETAIL_GAP_RECOVERED"),
		[],
		"a gap id the runtime did not serve must never be synthesized — that could close unrelated work",
	);
});

test("buildServedStatementGapLookup: accepts only well-formed pending usaa.statement gaps", () => {
	const lookup = buildServedStatementGapLookup([
		servedStatementGap("stmt-ok", "gap-ok"),
		// Wrong stream, wrong locator kind, non-pending, and a locator/record_key
		// disagreement must all be refused.
		{
			...servedStatementGap("stmt-other-stream", "gap-x"),
			stream: "transactions",
		},
		{
			...servedStatementGap("stmt-bad-kind", "gap-y"),
			detail_locator: { kind: "usaa.account", account_id: "a" },
		},
		{ ...servedStatementGap("stmt-recovered", "gap-z"), status: "recovered" },
		{
			...servedStatementGap("stmt-mismatch", "gap-w"),
			record_key: "different-id",
		},
	] as never);

	assert.deepEqual(
		[...lookup.entries()],
		[["stmt-ok", "gap-ok"]],
		"only a pending usaa.statement gap whose locator agrees with its record_key may be recoverable",
	);
});

/**
 * USAA serves a marketing offer in front of an account page. The session is
 * alive; the member is simply being shown "Depositing cash just got more
 * convenient!" before the page they asked for.
 *
 * Regression (owner-reported, USAA `transactions` stuck at 2 of 4 accounts):
 * BOTH checking accounts landed on
 * `/my/banking-offer/atm-deposit?...&accountType=checking&goto=...` instead of
 * `/my/checking`, so no Export button was found and the run reported
 * `source_structure_changed` — "USAA changed their UI" — for two accounts that
 * were perfectly fine. Credit cards, which are not offered ATM deposits,
 * exported normally. Captured live 2026-07-14 (page title "Find an ATM | USAA").
 */
test("resolveUsaaOfferInterstitialEscape: prefers the offer page's own goto target", () => {
	assert.equal(
		resolveUsaaOfferInterstitialEscape(
			"https://www.usaa.com/my/banking-offer/atm-deposit?accountId=private&accountType=checking&goto=https://www.usaa.com/my/checking%3FaccountId%3Dprivate",
			"https://www.usaa.com/my/checking?accountId=fallback",
		),
		"https://www.usaa.com/my/checking?accountId=private",
		"the offer page states where the member was headed; that is the honest way back",
	);
});

test("resolveUsaaOfferInterstitialEscape: falls back to the requested account URL", () => {
	// A `goto` that is off-host or points somewhere other than an account detail
	// route is REFUSED, so a redirect chain cannot steer the connector.
	for (const goto of [
		"https://www.usaa.com/inet/ent_home/CpHome",
		"https://evil.example/my/checking",
		"%%not-a-url%%",
	]) {
		assert.equal(
			resolveUsaaOfferInterstitialEscape(
				`https://www.usaa.com/my/banking-offer/atm-deposit?goto=${encodeURIComponent(goto)}`,
				"https://www.usaa.com/my/checking?accountId=private",
			),
			"https://www.usaa.com/my/checking?accountId=private",
			`goto=${goto} must not be followed`,
		);
	}
});

test("resolveUsaaOfferInterstitialEscape: only offer routes escape, and never into a loop", () => {
	// Pages that are already the destination, or that this function has no
	// honest opinion about, must NOT trigger a re-navigation.
	for (const finalUrl of [
		"https://www.usaa.com/my/checking?accountId=private",
		"https://www.usaa.com/challenge/step",
		"https://www.usaa.com/my/dashboard",
		"https://evil.example/my/banking-offer/atm-deposit",
		"not-a-url",
	]) {
		assert.equal(
			resolveUsaaOfferInterstitialEscape(
				finalUrl,
				"https://www.usaa.com/my/checking?accountId=private",
			),
			null,
			`${finalUrl} must not be treated as an escapable offer interstitial`,
		);
	}
	// A self-referential offer page cannot produce an infinite retry.
	assert.equal(
		resolveUsaaOfferInterstitialEscape(
			"https://www.usaa.com/my/banking-offer/atm-deposit",
			"https://www.usaa.com/my/banking-offer/atm-deposit",
		),
		null,
		"an escape target identical to the page just loaded must be refused",
	);
});

/** A page that serves the ATM-deposit offer first and the real account page
 *  (with a working Export button) only after the connector navigates through
 *  it — exactly the live sequence. Records every `goto` so the test proves the
 *  connector actually navigated rather than merely tolerating the offer. */
function makeOfferInterstitialPage(visited: string[]): Page {
	const offerUrl =
		"https://www.usaa.com/my/banking-offer/atm-deposit?accountId=private&accountType=checking" +
		"&goto=https%3A%2F%2Fwww.usaa.com%2Fmy%2Fchecking%3FaccountId%3Dprivate";
	return Object.assign({} as Page, {
		evaluate() {
			return Promise.resolve({
				account_detail_marker_count: 0,
				navigation_marker_count: 0,
				target_count: 0,
				transaction_marker_count: 0,
			});
		},
		goto(target: string) {
			visited.push(target);
			return Promise.resolve(null);
		},
		keyboard: {
			press: () => Promise.resolve(),
		},
		locator(selector: string) {
			// The Export button exists ONLY once we are off the offer page.
			const onAccountPage = visited.length > 1;
			if (
				selector === "button.ent-as-utility-bar__item.export" &&
				onAccountPage
			) {
				return {
					click: () => Promise.resolve(),
					count: () => Promise.resolve(1),
					first() {
						return this;
					},
				};
			}
			return {
				count: () => Promise.resolve(0),
				filter() {
					return this;
				},
				first() {
					return this;
				},
				innerHTML: () => Promise.reject(new Error("no dialog")),
				waitFor: () => Promise.reject(new Error("timeout waiting for select")),
			};
		},
		url() {
			return visited.length > 1
				? "https://www.usaa.com/my/checking?accountId=private"
				: offerUrl;
		},
	});
}

test("driveExport navigates through the ATM-deposit offer instead of reporting a missing export affordance", async () => {
	const visited: string[] = [];
	const diagnostics: DiagnosticInfo[] = [];
	await driveExport(
		makeOfferInterstitialPage(visited),
		"https://www.usaa.com/my/checking?accountId=private",
		{
			onDiagnostics: (info) => diagnostics.push(info),
			settleDelayMs: 0,
			sinceDate: "2026-01-01",
			untilDate: "2026-07-16",
		},
	);

	assert.deepEqual(
		visited,
		[
			"https://www.usaa.com/my/checking?accountId=private",
			"https://www.usaa.com/my/checking?accountId=private",
		],
		"the connector must re-navigate to the account page after landing on the offer",
	);
	// The point of the fix: this account is NOT reported as a structural change.
	assert.equal(
		diagnostics.find((info) => info.phase === "no_export_affordance"),
		undefined,
		"an offer interstitial must never be reported as a missing export affordance — that is the false " +
			"`source_structure_changed` that held USAA transactions at 2 of 4 accounts",
	);
});

/**
 * The offer page can itself bounce to logon — the session may die DURING the
 * escape hop, not only before it. That must surface as the existing
 * session-dead outcome (which triggers re-auth and excludes the account from
 * the coverage denominator), never as a missing export affordance, which would
 * blame the source's UI for an expired session.
 */
test("driveExport reports a session death that happens during the offer escape, not a missing affordance", async () => {
	const visited: string[] = [];
	const diagnostics: DiagnosticInfo[] = [];
	const offerUrl =
		"https://www.usaa.com/my/banking-offer/atm-deposit?goto=https%3A%2F%2Fwww.usaa.com%2Fmy%2Fchecking%3FaccountId%3Dprivate";
	const page = Object.assign({} as Page, {
		evaluate: () =>
			Promise.resolve({
				account_detail_marker_count: 0,
				navigation_marker_count: 0,
				target_count: 0,
				transaction_marker_count: 0,
			}),
		goto(target: string) {
			visited.push(target);
			return Promise.resolve(null);
		},
		keyboard: { press: () => Promise.resolve() },
		locator: () => ({
			count: () => Promise.resolve(0),
			filter() {
				return this;
			},
			first() {
				return this;
			},
		}),
		// First load lands on the offer; the escape hop lands on logon.
		url: () =>
			visited.length > 1 ? "https://www.usaa.com/my/logon" : offerUrl,
	});

	const outcome = await driveExport(
		page,
		"https://www.usaa.com/my/checking?accountId=private",
		{
			onDiagnostics: (info) => diagnostics.push(info),
			settleDelayMs: 0,
			sinceDate: "2026-01-01",
			untilDate: "2026-07-16",
		},
	).then(
		() => "resolved",
		(err: unknown) => (err instanceof Error ? err.message : String(err)),
	);

	assert.equal(
		outcome,
		"session_dead_redirect_to_logon",
		"a logon bounce during the escape hop must raise the session-dead signal",
	);
	assert.equal(
		diagnostics.find((info) => info.phase === "no_export_affordance"),
		undefined,
		"an expired session must never be reported as USAA changing their export UI",
	);
});

test("driveExport records account, challenge, and unrelated routes through the actual no-export path", async () => {
	for (const { counts, finalUrl, route } of [
		{
			counts: {
				account_detail_marker_count: 1,
				navigation_marker_count: 1,
				target_count: 0,
				transaction_marker_count: 0,
			},
			finalUrl: "https://www.usaa.com/my/checking?accountId=private",
			route: "expected",
		},
		{
			counts: {
				account_detail_marker_count: 0,
				navigation_marker_count: 0,
				target_count: 0,
				transaction_marker_count: 0,
			},
			finalUrl: "https://www.usaa.com/challenge/step",
			route: "interstitial",
		},
		{
			counts: {
				account_detail_marker_count: 0,
				navigation_marker_count: 0,
				target_count: 0,
				transaction_marker_count: 0,
			},
			finalUrl: "https://www.usaa.com/my/dashboard",
			route: "unknown",
		},
	]) {
		const diagnostics: DiagnosticInfo[] = [];
		const outcome = await driveExport(
			makeNoExportPage(finalUrl, counts),
			"https://www.usaa.com/my/checking",
			{
				onDiagnostics: (info) => diagnostics.push(info),
				settleDelayMs: 0,
				sinceDate: "2026-01-01",
				untilDate: "2026-07-16",
			},
		);

		assert.deepEqual(outcome, { kind: "failed" });
		assert.deepEqual(diagnostics, [
			{
				diag: null,
				no_export_observation: { ...counts, route },
				phase: "no_export_affordance",
			},
		]);
	}
});

/** A page with a recognized export button but no date-range select ever
 *  rendering in the resulting dialog — drives driveExport into the
 *  "dialog-not-open" branch, which presses Escape after failing to find
 *  the select. Tracks call order so the test can prove the checkpoint
 *  capture happens on the still-intact page, before Escape mutates it. */
function makeDialogNotOpenPage(callOrder: string[]): Page {
	return Object.assign({} as Page, {
		evaluate() {
			return Promise.resolve({
				dialog_html_preview: null,
				dialogs_open: 0,
				export_candidates: [],
				has_utility_bar: false,
				nav_candidates: [],
				title: "",
				url: "https://www.usaa.com/my/checking?accountId=private",
			});
		},
		goto() {
			return Promise.resolve(null);
		},
		keyboard: {
			press(key: string) {
				callOrder.push(`keyboard:${key}`);
				return Promise.resolve();
			},
		},
		locator(selector: string) {
			if (selector === "button.ent-as-utility-bar__item.export") {
				return {
					click() {
						return Promise.resolve();
					},
					count() {
						return Promise.resolve(1);
					},
					first() {
						return this;
					},
				};
			}
			// Every other locator (the dialog select, the unexpected-shape
			// dialog probe) reports not found — the select never renders, so the
			// bounded wait times out exactly like a real never-appearing select.
			return {
				count() {
					return Promise.resolve(0);
				},
				filter() {
					return this;
				},
				first() {
					return this;
				},
				innerHTML() {
					return Promise.reject(new Error("no dialog"));
				},
				waitFor() {
					return Promise.reject(new Error("timeout waiting for select"));
				},
			};
		},
		url() {
			return "https://www.usaa.com/my/checking?accountId=private";
		},
	});
}

test("driveExport captures the dialog-not-open checkpoint before pressing Escape", async () => {
	const callOrder: string[] = [];
	const outcome = await driveExport(
		makeDialogNotOpenPage(callOrder),
		"https://www.usaa.com/my/checking",
		{
			capture: {
				baseDir: "/tmp/unused",
				captureDom: (_page: Page, label: string) => {
					callOrder.push(`capture:${label}`);
					return Promise.resolve();
				},
				captureHttp: (): void => undefined,
				finalize: (): void => undefined,
				keepOnSuccess: true,
				markSucceeded: (): void => undefined,
				recordRecord: (): void => undefined,
				hasRegisteredSecrets: (): boolean => false,
				registerSecrets: (): void => undefined,
				runId: "test-dialog-not-open",
			} satisfies CaptureSession,
			captureLabel: "usaa-export",
			settleDelayMs: 0,
			sinceDate: "2026-01-01",
			untilDate: "2026-07-16",
		},
	);

	assert.deepEqual(outcome, { kind: "failed" });
	const captureIdx = callOrder.indexOf("capture:usaa-export-dialog-not-open");
	const escapeIdx = callOrder.indexOf("keyboard:Escape");
	assert.notEqual(
		captureIdx,
		-1,
		"expected a dialog-not-open checkpoint capture",
	);
	assert.notEqual(
		escapeIdx,
		-1,
		"expected an Escape keypress to dismiss the dialog",
	);
	assert.ok(
		captureIdx < escapeIdx,
		`checkpoint capture must run before Escape mutates the page (capture=${captureIdx}, escape=${escapeIdx})`,
	);
});

/** A page whose date-range select renders slightly after the Export click —
 *  simulating ordinary client-side render variance rather than a genuinely
 *  missing/changed export affordance. The select locator's `count()` would
 *  read 0 if sampled immediately (as the old fixed-sleep-then-one-shot-count
 *  check did), but `waitFor({ state: "visible" })` resolves once it renders.
 *  Exercises the fix for the false `export_dialog_unexpected_shape` this
 *  timing gap produced live (run_1787007889181): a slow-but-real render must
 *  not be reported as `export_affordance_missing`. */
function makeSlowRenderingSelectPage(): Page {
	return Object.assign({} as Page, {
		evaluate() {
			return Promise.resolve({
				dialog_html_preview: null,
				dialogs_open: 1,
				export_candidates: [],
				has_utility_bar: false,
				nav_candidates: [],
				title: "",
				url: "https://www.usaa.com/my/checking?accountId=private",
			});
		},
		goto() {
			return Promise.resolve(null);
		},
		keyboard: {
			press() {
				return Promise.resolve();
			},
		},
		locator(selector: string) {
			if (selector === "button.ent-as-utility-bar__item.export") {
				return {
					click() {
						return Promise.resolve();
					},
					count() {
						return Promise.resolve(1);
					},
					first() {
						return this;
					},
				};
			}
			if (selector.includes("selectionType")) {
				// Simulates a select that has not yet rendered the instant it is
				// checked, but appears shortly after (ordinary client-side render
				// variance): `.count()` reads 0 until `waitFor` has resolved once,
				// matching how a real Playwright locator's count reflects the live
				// DOM only once the element has actually mounted. The old
				// fixed-sleep-then-one-shot-count code called `.count()` directly
				// without ever calling `waitFor`, so it always saw 0 here and
				// misclassified the dialog as unexpected-shape; the fix awaits
				// `waitFor` first and only then re-checks `count()`, observing 1.
				let renderedAfterWait = false;
				return {
					count() {
						return Promise.resolve(renderedAfterWait ? 1 : 0);
					},
					first() {
						return this;
					},
					waitFor() {
						renderedAfterWait = true;
						return Promise.resolve();
					},
				};
			}
			return {
				count() {
					return Promise.resolve(0);
				},
				filter() {
					return this;
				},
				first() {
					return this;
				},
				innerHTML() {
					return Promise.reject(new Error("no dialog"));
				},
				waitFor() {
					return Promise.reject(new Error("timeout"));
				},
			};
		},
		url() {
			return "https://www.usaa.com/my/checking?accountId=private";
		},
	});
}

test("driveExport treats a slow-but-real date-range select render as ready, not a structure change", async () => {
	const diagnostics: DiagnosticInfo[] = [];
	await driveExport(
		makeSlowRenderingSelectPage(),
		"https://www.usaa.com/my/checking",
		{
			onDiagnostics: (info) => diagnostics.push(info),
			captureLabel: "usaa-export",
			settleDelayMs: 0,
			sinceDate: "2026-01-01",
			untilDate: "2026-07-16",
		},
	).catch((): undefined => undefined); // downstream submit machinery is unmocked past this point; only the
	// dialog-open decision under test needs to run cleanly.

	const fatalPhases = diagnostics.map((d) => d.phase);
	assert.ok(
		!fatalPhases.includes("export_dialog_unexpected_shape"),
		`a select that renders within the wait budget must not be reported as a structure change; saw phases: ${fatalPhases.join(", ")}`,
	);
});

test("runSingleLadderAttempt retains a logon interstitial on the existing re-auth failure outcome", async () => {
	const { deps, messages } = makeHarness();
	deps.browserSurface = "managed";
	deps.reauthenticate = () =>
		Promise.reject(new Error("private reauth failure must not persist"));
	let sessionDead = false;
	const outcome = await runSingleLadderAttempt({
		a: makeAccount(),
		accountOrdinal: 1,
		accountTotal: 1,
		attemptOrdinal: 1,
		attemptTotal: 1,
		context: {} as BrowserContext,
		deps,
		onDiagnostics() {
			// The logon redirect must reach re-auth, not the ordinary no-export callback.
		},
		onSessionDead() {
			sessionDead = true;
		},
		page: makeNoExportPage("https://www.usaa.com/my/logon", {
			account_detail_marker_count: 0,
			navigation_marker_count: 0,
			target_count: 0,
			transaction_marker_count: 0,
		}),
		sendInteraction: async () => ({
			request_id: "test",
			status: "success",
			type: "INTERACTION_RESPONSE",
		}),
		settleDelayMs: 0,
		sinceDate: "2026-01-01",
		streamState: {
			sessionDeadMidRun: false,
			sessionRepairAttempted: false,
		} satisfies UsaaRunState,
		todayIso: "2026-07-16",
	});

	assert.deepEqual(outcome, { kind: "session_dead" });
	assert.equal(
		sessionDead,
		true,
		"the existing session-dead control flow is preserved",
	);
	const skip = messages.find(
		(message): message is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			message.type === "SKIP_RESULT" &&
			message.reason === "session_dead_reauth_failed",
	);
	assert.ok(skip);
	assert.deepEqual(skip.diagnostics, {
		browser_surface: {
			account_detail_marker_count: 0,
			activity_table_marker_count: 0,
			dashboard_marker_count: 0,
			managed_surface: "managed",
			navigation_marker_count: 0,
			parser_count: 0,
			phase: "no_export_affordance",
			posture: "unexpected",
			read_count: 1,
			route: "interstitial",
			surface: "usaa_transaction_export",
			target_count: 0,
			transaction_marker_count: 0,
			verified_empty_marker_count: 0,
			wait_outcome: "not_needed",
		},
	});
	assert.doesNotMatch(
		JSON.stringify(skip),
		/private reauth|https?:\/\/|accountId/i,
	);
});

test("emitExportFailure: the dialog-unexpected-shape phase is also a structure-changed outcome", async () => {
	const { deps, messages } = makeHarness();
	const diag: DiagnosticInfo = {
		phase: "export_dialog_unexpected_shape",
		diag: {
			url: "https://www.usaa.com/my/checking?accountId=ACCT-CHK-0001",
			title: "Checking",
			has_utility_bar: false,
			export_candidates: [],
			nav_candidates: [],
			dialogs_open: 1,
			dialog_html_preview: "<div>unexpected</div>",
		},
	};
	await emitExportFailure(deps, makeAccount(), diag);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT",
	);
	assert.ok(skip);
	assert.equal(
		skip.reason,
		"export_affordance_missing",
		"an unrecognized export dialog is a structure-changed outcome",
	);
	const emittedDiag = skip.diagnostics as DiagnosticInfo & { outcome: string };
	assert.equal(emittedDiag.outcome, "source_structure_changed");
});

test("emitExportFailure: a transient artifact-wait failure stays export_no_download (pressure outcome)", async () => {
	// The affordance and dialog were found and the export submitted; only the
	// download/body never materialized. That is recoverable on a later run, so
	// it must NOT be reported as a structure change.
	const { deps, messages } = makeHarness();
	const diag: DiagnosticInfo = {
		artifact: { cdpError: null, cdpReady: true, candidates: [] },
		diag: null,
		error: "download_empty",
		phase: "export_artifact_wait_failed",
	};
	await emitExportFailure(deps, makeAccount(), diag);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT",
	);
	assert.ok(skip);
	assert.equal(
		skip.reason,
		"export_no_download",
		"submitted-but-no-download stays the transient pressure reason",
	);
	assert.match(
		skip.message,
		/export_pressure/,
		"message names the pressure outcome class",
	);
	const emittedDiag = skip.diagnostics as DiagnosticInfo & { outcome: string };
	assert.equal(emittedDiag.outcome, "export_pressure");
});

test("emitExportFailure: no diagnostic at all is an honest unknown outcome (still retryable)", async () => {
	// Every window failed without leaving a diagnostic phase. We don't claim to
	// know whether it was structural or transient, so the reason stays the
	// retryable `export_no_download` and the message says so plainly.
	const { deps, messages } = makeHarness();
	await emitExportFailure(deps, makeAccount(), null);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT",
	);
	assert.ok(skip);
	assert.equal(
		skip.reason,
		"export_no_download",
		"an unknown exhaustion stays retryable, not a structure change",
	);
	assert.match(
		skip.message,
		/outcome unknown/,
		"message is honest that the outcome could not be determined",
	);
	const emittedDiag = skip.diagnostics as { outcome: string };
	assert.equal(emittedDiag.outcome, "unknown");
});

test("unknown PDF template diagnostics keep structural recovery facts but never statement text", () => {
	const privateStatementText =
		"OWNER NAME | MERCHANT NAME | $9,999.99 | BALANCE 1234.56";
	const parseMeta = {
		era: "unknown" as const,
		year: 2026,
		// The parser no longer returns this field, but this fixture protects the
		// emission boundary if an older parser shape is supplied at runtime.
		rawTextSample: privateStatementText,
	};
	const diagnostics = buildPdfTemplateUnknownDiagnostics(
		"opaque-statement-hash",
		parseMeta,
	);

	assert.deepEqual(diagnostics, {
		parser_era: "unknown",
		statement_id: "opaque-statement-hash",
		year: 2026,
	});
	assert.doesNotMatch(
		JSON.stringify(diagnostics),
		/OWNER NAME|MERCHANT NAME|9,999\.99|1234\.56/,
	);
});

test("statement PDF download diagnostics keep only allowlisted menu and response structure", () => {
	const menu = buildUsaaStatementMenuDiagnostic({
		downloadCandidateCount: 0,
		menuActionCount: 3,
		menuItemCount: 2,
		menuPresent: true,
	});
	const responseDiagnostics: BodyResponseDiagnostics = {
		candidates: [
			{
				bodyError: "private response header and owner label",
				contentDisposition: 'attachment; filename="PRIVATE-OWNER.pdf"',
				contentType: "text/html; private-label",
				method: "POST",
				reason: "body_error",
				source: "playwright",
				status: 500,
				url: "https://www.usaa.com/private/path?account=owner",
			},
		],
		cdpError: "private cdp endpoint",
		cdpReady: true,
	};
	const response =
		summarizeUsaaStatementResponseDiagnostics(responseDiagnostics);

	assert.deepEqual(menu, {
		menu: {
			action_count: 3,
			download_candidate_count: 0,
			item_count: 2,
			present: true,
		},
	});
	assert.deepEqual(response, {
		response: {
			body_error_count: 1,
			candidate_count: 1,
			cdp_error: true,
			cdp_ready: true,
			matched_count: 0,
			source_counts: { cdp: 0, playwright: 1 },
			status_codes: [500],
		},
	});
	assert.doesNotMatch(
		JSON.stringify({ menu, response }),
		/menu_html|PRIVATE-OWNER|private response|usaa\.com|private\/path|account=owner|content-disposition|POST/,
	);
});

test("hydrateStatementPdfs: missing Download menuitem emits structural menu facts only", async () => {
	const locator = (count: number) => ({
		click: async (): Promise<void> => undefined,
		count: async (): Promise<number> => count,
		filter: () => locator(0),
		first: () => locator(count),
		last: () => locator(count),
		locator: () => locator(count),
		nth: () => locator(count),
	});
	const page = {
		keyboard: { press: async (): Promise<void> => undefined },
		locator: (selector: string, options?: unknown) => {
			if (options) {
				return locator(0);
			}
			if (selector === '[role="menu"]') {
				return locator(1);
			}
			if (selector === "tbody tr") {
				return locator(1);
			}
			if (selector === '[role="menu"] [role="menuitem"]') {
				return locator(2);
			}
			if (selector === '[role="menu"] a, [role="menu"] button') {
				return locator(3);
			}
			return locator(0);
		},
		url: (): string => "https://www.usaa.com/my/documents",
	} as never;
	const skipped: Array<{ diag: unknown; reason: string }> = [];

	const hydrated = await hydrateStatementPdfs({
		page,
		statements: [
			{
				account_id: null,
				date_delivered: "2026-04-01",
				id: "opaque-statement-id",
				rowIndex: 0,
				title: null,
			},
		],
		onSkip: ({ diag, reason }) => {
			skipped.push({ diag, reason });
		},
	});

	assert.deepEqual(hydrated, []);
	assert.deepEqual(skipped, [
		{
			diag: {
				menu: {
					action_count: 3,
					download_candidate_count: 0,
					item_count: 2,
					present: true,
				},
			},
			reason: "no_download_menuitem",
		},
	]);
	assert.doesNotMatch(
		JSON.stringify(skipped),
		/menu_html|innerHTML|usaa\.com|opaque-statement-id/,
	);
});

test("emitExportFailure: artifact diagnostics are summarized when page diagnostics are unavailable", async () => {
	const { deps, messages } = makeHarness();
	const diag: DiagnosticInfo = {
		artifact: {
			cdpError: null,
			cdpReady: true,
			candidates: [
				{
					bodyBytes: 128,
					contentDisposition: "",
					contentType: "text/plain",
					method: "POST",
					reason: "not_expected_body",
					source: "cdp",
					status: 200,
					url: "https://www.usaa.com/export",
				},
				{
					bodyError: "Protocol error",
					contentDisposition: "",
					contentType: "text/csv",
					method: "POST",
					reason: "body_error",
					source: "playwright",
					status: 200,
					url: "https://www.usaa.com/export",
				},
			],
		},
		diag: null,
		error: "body_response_timeout after 45000ms",
		phase: "export_artifact_wait_failed",
	};
	await emitExportFailure(deps, makeAccount(), diag);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT",
	);
	assert.ok(skip);
	assert.match(skip.message, /export_artifact_wait_failed/);
	assert.match(skip.message, /page=unavailable/);
	assert.match(
		skip.message,
		/artifact cdpReady=true candidates=2 matched=0 bodyErrors=1/,
	);
	assert.doesNotMatch(
		skip.message,
		/secure\.usaa\.com|text\/plain|not_expected_body/,
	);
	assert.doesNotMatch(skip.message, /url=https?:\/\//);
	assert.doesNotMatch(
		skip.message,
		/body_response_timeout|Protocol error|secure\.usaa\.com/,
	);
	const emittedDiag = skip.diagnostics as DiagnosticInfo;
	assert.deepEqual(emittedDiag.artifact, {
		body_error_count: 1,
		candidate_count: 2,
		cdp_error: false,
		cdp_ready: true,
		matched_count: 0,
		source_counts: { cdp: 1, playwright: 1 },
		status_codes: [200],
	});
});

test("emitExportFailure: download diagnostics surface non-PII wait evidence when present", async () => {
	// Live-run regression: when `download_empty` fires under remote n.eko,
	// the candidates list is dominated by Adobe analytics beacons and the
	// real export URL is invisible. This test confirms non-PII download-side
	// evidence (byte count, source path, downloadFailure)
	// reaches the SKIP_RESULT message text so the next run can be triaged
	// offline without a second human OTP cycle.
	const { deps, messages } = makeHarness();
	const diag: DiagnosticInfo = {
		artifact: {
			cdpError: null,
			cdpReady: true,
			candidates: [],
		},
		diag: null,
		download: {
			url: "https://www.usaa.com/inet/ent_logon/bnk/dmd/chk/transactionDownload",
			suggestedFilename: "transaction_history.csv",
			bytes: 0,
			source: "createReadStream",
			saveAsError: "saveAs_returned_zero_bytes",
			streamError: null,
			downloadFailure: "Download canceled by remote",
		},
		error: "download_empty",
		phase: "export_artifact_wait_failed",
	};
	await emitExportFailure(deps, makeAccount(), diag);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT",
	);
	assert.ok(skip);
	assert.match(skip.message, /export_artifact_wait_failed/);
	assert.doesNotMatch(skip.message, /https?:\/\/|transaction_history\.csv/);
	assert.match(skip.message, /bytes=0/);
	assert.match(skip.message, /source=createReadStream/);
	assert.doesNotMatch(
		skip.message,
		/saveAs_returned_zero_bytes|Download canceled by remote/,
	);
	const emittedDiag = skip.diagnostics as DiagnosticInfo;
	assert.deepEqual(emittedDiag.download, {
		bytes: 0,
		has_download_failure: true,
		has_save_as_error: true,
		has_stream_error: false,
		source: "createReadStream",
	});
});

test("emitExportFailure: credit-card account uses credit_card_export_unverified reason", async () => {
	const { deps, messages } = makeHarness();
	const cc = makeAccount({
		account_id_raw: "ACCT-CC-0001",
		account_type: "credit-card",
		name: "USAA REWARDS AMEX",
		last_four: "0001",
	});
	await emitExportFailure(deps, cc, null);
	const skip = messages.find(
		(m): m is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
			m.type === "SKIP_RESULT",
	);
	assert.ok(skip);
	assert.equal(
		skip.reason,
		"credit_card_export_unverified",
		"credit-card export flow is not yet live-verified",
	);
	assert.match(
		skip.message,
		/credit-card export flow not verified/,
		"message carries the design-notes pointer",
	);
});

test("isNoDataExportMessage: distinguishes source-empty export dialogs from generic failures", () => {
	assert.equal(
		isNoDataExportMessage(
			"There are no transactions for the selected date range.",
		),
		true,
	);
	assert.equal(
		isNoDataExportMessage("Nothing to export for this account."),
		true,
	);
	assert.equal(
		isNoDataExportMessage("We couldn't process your request right now."),
		false,
	);
});

// ─── Invariant 8: pure filters ───────────────────────────────────────────

test("shouldParseStatementTitle: keeps statement titles, drops agreements/disclosures/terms", () => {
	assert.equal(shouldParseStatementTitle("April 2026 STATEMENT"), true);
	assert.equal(shouldParseStatementTitle("Monthly Statement"), true);
	assert.equal(
		shouldParseStatementTitle("CARDHOLDER AGREEMENT"),
		false,
		"agreement should be filtered",
	);
	assert.equal(shouldParseStatementTitle("Privacy NOTICE"), false);
	assert.equal(shouldParseStatementTitle("Important DISCLOSURE"), false);
	assert.equal(shouldParseStatementTitle("Terms and CONDITIONs"), false);
	assert.equal(
		shouldParseStatementTitle("Some random doc"),
		false,
		"no STATEMENT token → drop",
	);
});

test("hydrationSuccess: narrows ok branch, returns null for err branch + undefined", () => {
	const ok = makeHydrationOk();
	assert.equal(hydrationSuccess(ok), ok, "ok branch passes through");
	assert.equal(
		hydrationSuccess({ err: "download_timed_out" }),
		null,
		"err branch narrows to null",
	);
	assert.equal(
		hydrationSuccess(undefined),
		null,
		"missing entry narrows to null",
	);
});

test("usaa manifest: successful manual runs have a bounded freshness window", () => {
	const manifest = JSON.parse(readFileSync(USAA_MANIFEST_PATH, "utf8")) as {
		capabilities?: {
			refresh_policy?: {
				maximum_staleness_seconds?: number;
				recommended_mode?: string;
			};
		};
	};
	const policy = manifest.capabilities?.refresh_policy;
	assert.equal(policy?.recommended_mode, "manual");
	assert.equal(policy?.maximum_staleness_seconds, 86_400);
});
