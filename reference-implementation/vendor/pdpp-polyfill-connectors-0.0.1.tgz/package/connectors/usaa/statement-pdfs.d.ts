import type { BrowserContext, Page } from "playwright";
import { type BodyResponseDiagnostics } from "../../src/browser-artifact-response.ts";
import type { CaptureSession } from "../../src/fixture-capture.ts";
import { currencyToCentsFromStatement as _currencyFromStatement, detectStatementYear, parseCreditCardEra, parseModernCheckingEra } from "./parsers.ts";
import { type StatementReconciliation } from "./statement-reconciliation.ts";
import type { DownloadFailReason, HydratedStatement, ParseMeta, StatementDownloadDiagnostic, StatementResponseDiagnostic, StatementRow, StatementTxnRecord } from "./types.ts";
export declare function buildUsaaStatementMenuDiagnostic({ downloadCandidateCount, menuActionCount, menuItemCount, menuPresent, }: {
    downloadCandidateCount: number;
    menuActionCount: number;
    menuItemCount: number;
    menuPresent: boolean;
}): StatementDownloadDiagnostic;
export declare function summarizeUsaaStatementResponseDiagnostics(diagnostics: BodyResponseDiagnostics): {
    response: StatementResponseDiagnostic;
};
/**
 * Hydrate every row in the currently-loaded /my/documents table. Callers
 * pass `onRecord({ index, statement, result })` to react per-row as we go
 * (so the main connector can emit hydrated statement records incrementally
 * and still make progress if the page/session dies partway through).
 *
 * Returns an array of { statement, pdfPath, pdfSha256, buffer } for every
 * successful download, and emits SKIP-equivalent diagnostics via onSkip
 * for rows that failed.
 */
export declare function hydrateStatementPdfs({ page, statements, onProgress, onSkip, context, capture, }: {
    page: Page;
    statements: StatementRow[];
    onProgress?: (p: {
        index: number;
        total: number;
        title: string | null;
    }) => void;
    onSkip?: (p: {
        statement: StatementRow;
        reason: DownloadFailReason;
        diag: StatementDownloadDiagnostic | null;
    }) => void;
    /**
     * Optional. When supplied together with `capture`, arms a context-level
     * `page` event watcher for the whole hydration batch — the direct test of
     * the pdf_download_timeout hypothesis (does the Download menuitem open a
     * new page the page-scoped download/response queues can't see). Neither
     * changes collection behavior; both are diagnostic-only and no-op unless
     * PDPP_CAPTURE_FIXTURES=1 / PDPP_CAPTURE_ON_FAILURE=1 armed `capture`.
     */
    context?: BrowserContext | undefined;
    capture?: CaptureSession | null | undefined;
}): Promise<HydratedStatement[]>;
export declare function fileUrlForPath(p: string): string;
/**
 * Parse one statement PDF's bytes into transaction records. Caller supplies
 *   accountId, accountName, period (YYYY-MM for provenance), originalDescription
 *   fallback.
 *
 * Returns { txns: Array<TxnRecord>, parseMeta: { era, year } }.
 * When no parser matches, txns is [] and parseMeta.era === "unknown"; the
 * connector surfaces a bounded structural SKIP_RESULT without statement text.
 */
export declare function parsePdfStatement({ buffer, accountId, accountName, period, }: {
    buffer: Buffer;
    accountId: string;
    accountName: string | null;
    period: string | null;
}): Promise<{
    txns: StatementTxnRecord[];
    parseMeta: ParseMeta;
    reconciliation: StatementReconciliation;
}>;
export declare const _internals: {
    parseModernCheckingEra: typeof parseModernCheckingEra;
    parseCreditCardEra: typeof parseCreditCardEra;
    detectStatementYear: typeof detectStatementYear;
    currencyToCentsFromStatement: typeof _currencyFromStatement;
    STATEMENT_ROOT: string;
};
//# sourceMappingURL=statement-pdfs.d.ts.map