#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * PDPP USAA Connector (v0.2.0)
 *
 * Uses shared Playwright persistent profile. Drives real selectors captured
 * from a live session on 2026-04-19.
 *
 * Streams: accounts, transactions, transfers, bill_payments,
 *          scheduled_transactions, credit_card_billing, statements,
 *          inbox_messages, external_accounts.
 *
 * Transactions path: drive the USAA "Export" button → "Select Date Range"
 * CSV flow. Primary key is a synthetic SHA-256 hash since USAA does not
 * expose transaction IDs (documented design choice — see design-notes/usaa.md).
 *
 * Session: cookie-based probe on UsaaMbWebMemberLoggedIn + LtpaToken2.
 * On session death, emits INTERACTION manual_action → inbox.
 */
import { mkdtempSync, rmSync } from "node:fs";
import { readdir, readFile, unlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { isMainModule } from "@pdpp/connector-protocol";
import { ensureUsaaSession } from "../../src/auto-login/usaa.js";
import { attachBodyResponseQueue, waitForOptionalBodyResponse, } from "../../src/browser-artifact-response.js";
import { browserSurfaceManagedState, buildBrowserSurfaceDiagnostic, } from "../../src/browser-surface-diagnostic.js";
import { emitDetailCoverage, emitDetailGap, nowIso, politeDelay, runConnector, } from "../../src/connector-runtime.js";
import { attachDownloadQueue, } from "../../src/download-queue.js";
import { openFingerprintCursor, } from "../../src/fingerprint-cursor.js";
import { readPlaywrightDownloadBufferDetailed } from "../../src/playwright-download.js";
import { statementFingerprintExcludeKeys } from "../../src/statement-content-fingerprint.js";
import { openStatementHydrationCursor, readPriorStatementHydration, } from "../../src/statement-hydration-carry-forward.js";
import { computeInboxCoverage, } from "./inbox-coverage.js";
import { buildAccountRecord, buildAccountStatsRecord, buildCandidateStarts, buildCreditCardBillingRecord, buildCreditCardBillingStatsRecord, buildInboxMessageRecord, creditCardId, hashId, isoDate, mmddyyyy, BACKFILL_17MO as PARSERS_BACKFILL_17MO, INCREMENTAL_OVERLAP_MS as PARSERS_INCREMENTAL_OVERLAP_MS, parseCsv, resolveAccountIdForRef, rowsToTransactions, } from "./parsers.js";
import { validateRecord as validateRecordRaw } from "./schemas.js";
import { computeStatementCoverage, } from "./statement-coverage.js";
import { fileUrlForPath, hydrateStatementPdfs, parsePdfStatement, } from "./statement-pdfs.js";
import { buildReconciliationDiagnostics } from "./statement-reconciliation.js";
// Explicit, literal-per-branch mapping from the statement-PDF download
// driver's internal DownloadFailReason to the SKIP_RESULT reason code this
// connector emits. Every value here is a plain string literal (never a
// template composed from the helper's own reason) so the connector
// reason-code completeness scan can see every emitted code statically — see
// packages/polyfill-connectors/src/reason-display-messages.ts.
const PDF_DOWNLOAD_SKIP_REASON = {
    direct_link_failed: "pdf_download_direct_link_failed",
    download_click_failed: "pdf_download_click_failed",
    download_empty: "pdf_download_empty",
    download_timeout: "pdf_download_timeout",
    no_download_menuitem: "pdf_download_no_download_menuitem",
    no_options_affordance: "pdf_download_no_options_affordance",
    options_click_failed: "pdf_download_options_click_failed",
    persist_failed: "pdf_download_persist_failed",
    row_missing: "pdf_download_row_missing",
};
const validateRecord = validateRecordRaw;
/** Keep unknown-PDF diagnostics useful for recovery without persisting
 * statement text, which can contain names, merchants, amounts, and balances. */
export function buildPdfTemplateUnknownDiagnostics(statementId, parseMeta) {
    return {
        parser_era: parseMeta.era,
        statement_id: statementId,
        year: parseMeta.year,
    };
}
// ─── Module-scope regexes ────────────────────────────────────────────────
const ACCOUNT_URL_PREFIXES = 'a[href^="/my/checking"], a[href^="/my/savings"], a[href^="/my/credit-card"], a[href^="/my/external-account"], a[href^="/my/loan"], a[href^="/my/mortgage"], a[href^="/my/investing"], a[href^="/my/retirement"]';
const DASHBOARD_SELECTOR_WAIT = 'a[href^="/my/checking"], a[href^="/my/credit-card"], a[href^="/my/external-account"]';
const LOGON_REDIRECT_RE = /\/my\/logon|\/access-management\/oauth2\/member\/authorize/;
const TRANSACTION_ACCOUNT_TYPE_RE = /checking|savings|credit-card/;
const CREDIT_CARD_TYPE_RE = /credit-card/;
const TEMP_DIR_PREFIX_RE = /\/[^/]+$/;
const UNSAFE_FILENAME_RE = /[\\/]/g;
const EXPORT_BUTTON_TEXT_RE = /^\s*Export\s*$/i;
const CSV_DOWNLOAD_HINT_RE = /filename|attachment|octet-stream|csv|export/iu;
const CSV_HEAD_RE = /date|description|amount|transaction/iu;
const EXPORT_DIALOG_MESSAGE_SELECTOR = '[role="dialog"] [class*="errorMessage"]:not(:empty), [role="dialog"] :text-matches("no transactions|nothing to export", "i")';
const EXPORT_NO_DATA_RE = /no transactions|nothing to export/iu;
const USAA_ACCOUNT_DETAIL_ROUTE_RE = /^\/my\/(?:checking|savings|credit-card)(?:\/|$)/u;
const USAA_INTERSTITIAL_ROUTE_RE = /\/(?:my\/logon|access-management\/oauth2\/member\/authorize|security(?:\/|$)|challenge(?:\/|$)|my\/banking-offer(?:\/|$))/iu;
/**
 * Marketing interstitials USAA injects in FRONT of an account page. Distinct
 * from the auth/challenge interstitials above: the session is perfectly alive,
 * the member is simply being shown an offer (e.g. `/my/banking-offer/atm-deposit`,
 * "Depositing cash just got more convenient!") before the page they asked for.
 *
 * Observed live on the owner's mailbox 2026-07-14: BOTH checking accounts
 * landed here instead of `/my/checking`, so `findExportAffordance` found no
 * Export button and the run reported `source_structure_changed` — "USAA changed
 * their UI" — for two accounts that were fine. Credit-card accounts, which are
 * not offered ATM deposits, exported normally. That is the whole of the
 * long-standing USAA `transactions` 2-of-4 coverage gap.
 *
 * These pages carry the originally-requested URL in their own `goto` query
 * param, which is the honest way back: it is USAA's own statement of where the
 * member was headed, not a URL this connector guessed.
 */
const USAA_OFFER_INTERSTITIAL_ROUTE_RE = /^\/my\/banking-offer(?:\/|$)/iu;
const USAA_ACCOUNT_DETAIL_MARKER_SELECTOR = ".ent-as-utility-bar, .as_credit__utility-bar";
const USAA_TRANSACTION_MARKER_SELECTOR = 'table[aria-label*="transaction" i], [data-testid*="transaction" i], [id*="transaction" i]';
const USAA_NAVIGATION_MARKER_SELECTOR = 'a[href*="/my/credit-card"], a[role="tab"], [role="tab"]';
const USAA_EXPORT_AFFORDANCE_SELECTOR = "button.ent-as-utility-bar__item.export, button.as_credit__utility-bar-item.as_credit__export";
// ─── Timing + limits ────────────────────────────────────────────────────
const DASHBOARD_NAV_TIMEOUT_MS = 30_000;
const DASHBOARD_SELECTOR_TIMEOUT_MS = 20_000;
const DASHBOARD_SETTLE_DELAY_MS = 4000;
const DOCUMENTS_NAV_TIMEOUT_MS = 25_000;
const DOCUMENTS_SETTLE_DELAY_MS = 5000;
const ACCOUNT_NAV_TIMEOUT_MS = 30_000;
const ACCOUNT_SETTLE_DELAY_MS = 6000;
const INBOX_NAV_TIMEOUT_MS = 25_000;
const CC_SETTLE_DELAY_MS = 6000;
const EXPORT_DIALOG_DELAY_MS = 2500;
const EXPORT_STATE_DELAY_MS = 1500;
const EXPORT_CLICK_TIMEOUT_MS = 5000;
const DOWNLOAD_TIMEOUT_MS = 45_000;
const RESPONSE_FALLBACK_GRACE_MS = 3000;
const KEY_TYPE_DELAY_MS = 30;
const BACKFILL_17MO = PARSERS_BACKFILL_17MO;
const INCREMENTAL_OVERLAP_MS = PARSERS_INCREMENTAL_OVERLAP_MS;
const ID_TEXT_SNIP = 160;
const HTML_PREVIEW_MAX = 600;
// Module-scope regexes (Biome useTopLevelRegex). CREDIT_CARD_TYPE_RE is
// defined above in the existing regex block; reuse it here rather than
// redeclare to avoid a lint collision.
const STATEMENT_TITLE_RE = /STATEMENT/i;
const NON_STATEMENT_TITLE_RE = /(TERMS\b|AGREEMENT\b|NOTICE\b|DISCLOSURE\b|CONDITION)/i;
/** Streams scaffolded in design-notes but without live selectors. Each
 *  requested-but-deferred stream gets a SKIP_RESULT so the client sees
 *  the intent without data. */
export const DEFERRED_STREAMS = [
    "transfers",
    "bill_payments",
    "scheduled_transactions",
    "external_accounts",
];
/** True iff we should try to extract transactions from this statement
 *  title. USAA's document index mixes statements with agreements /
 *  disclosures — the parser only understands the former. */
export function shouldParseStatementTitle(title) {
    return STATEMENT_TITLE_RE.test(title) && !NON_STATEMENT_TITLE_RE.test(title);
}
/** Narrow a HydrationResult to the success branch. Used by the record-
 *  emit path to decide between a hydrated row and an index-only row. */
export function hydrationSuccess(h) {
    if (h && "pdfPath" in h) {
        return h;
    }
    return null;
}
/** Build `statements` IndexRows from scraped DocRows. Rows missing a
 *  `date_delivered` are dropped — we can't reliably key them. Account
 *  resolution falls through last-four then name substring. */
export function buildIndexRows(docs, accounts) {
    return docs
        .filter((d) => d.date_delivered)
        .map((d) => {
        const accountReference = d.account_reference.trim() || null;
        return {
            rowIndex: d.rowIndex,
            id: hashId(`${accountReference ?? ""}|${d.date_delivered}|${d.title}`),
            account_id: resolveAccountIdForRef(accountReference ?? "", accounts),
            title: d.title,
            date_delivered: isoDate(d.date_delivered),
            account_reference: accountReference,
        };
    });
}
/** Emit one `accounts` entity record per dashboard account (gated), and
 *  optionally one `account_stats` observation record per account, followed
 *  by per-stream STATE checkpoints. Record `fetched_at` threads the
 *  run-level emittedAt so every record in a run shares one timestamp; STATE
 *  cursors use `nowIso()` at emit time since they're heartbeats, not record
 *  fields.
 *
 *  Entity gate: a per-account fingerprint that excludes the run-clock
 *  `fetched_at`. After the Family-2 split the entity body carries only
 *  identity/settings (id, type, name, last_four, status), so it re-emits
 *  only on a real identity/settings change — a balance-only tick no longer
 *  versions the entity. The point-in-time `balance_cents` /
 *  `available_balance_cents` live on `account_stats`, keyed
 *  `{account_id}:{observed_on}` so same-day re-pulls are idempotent and a
 *  later day appends a new point in the balance time series. When no cursor
 *  is supplied (legacy callers/tests) the entity record always emits and no
 *  entity STATE is written. */
export async function emitAccountsStream(deps, accounts, emittedAt, fingerprintCursor, options = {}) {
    const emitEntity = options.emitEntity ?? true;
    const emitStats = options.emitStats ?? false;
    const observedOn = options.observedOn ?? emittedAt.slice(0, 10);
    // `covered` is the in-boundary accounts this entity run accounted for: emitted
    // plus suppressed-because-unchanged. Counted independently at the loop site
    // from objective per-record outcomes, never aliased to the emitted count —
    // `buildAccountRecord` never drops a row, so every enumerated account reaches
    // the gate; a future pre-gate drop would raise `considered` (accounts.length)
    // without raising `covered`, leaving an honest `partial`.
    let entityCovered = 0;
    for (const a of accounts) {
        if (emitEntity) {
            const rec = buildAccountRecord(a, emittedAt);
            if (!fingerprintCursor || fingerprintCursor.shouldEmit(rec)) {
                await deps.emitRecord("accounts", rec);
            }
            // Emitted or suppressed-unchanged: either way the account was accounted
            // for. Only the fingerprint-gated entity path (not the legacy no-cursor
            // path) declares coverage below.
            if (fingerprintCursor) {
                entityCovered += 1;
            }
        }
        // Observation stream: append-keyed daily balance snapshot, emitted
        // unconditionally (the runtime byte-equivalence check collapses an
        // unchanged same-day re-pull). Not fingerprint-gated — the append key
        // already makes same-day re-pulls idempotent.
        if (emitStats) {
            await deps.emitRecord("account_stats", buildAccountStatsRecord(a, observedOn));
        }
    }
    if (emitStats) {
        await deps.emit({
            type: "STATE",
            stream: "account_stats",
            cursor: { observed_on: observedOn, fetched_at: nowIso() },
        });
        // `account_stats` is `singleton_presence`: a daily snapshot re-derived
        // from the same full account-dashboard scan every run. buildAccountStatsRecord
        // never drops a row, so every enumerated account is accounted for —
        // `considered === covered === accounts.length`, including 0/0 on a
        // genuinely empty account list (verified-empty, not unmeasured). Without
        // this, the STATE commit above is a checkpoint with no measurement behind
        // it, and the Collection Report reads `unknown` forever regardless of how
        // many successful runs commit it (define-connector-progress-evidence-contract).
        await emitDetailCoverage(deps, {
            stream: "account_stats",
            stateStream: "account_stats",
            requiredKeys: [],
            hydratedKeys: [],
            considered: accounts.length,
            covered: accounts.length,
        });
    }
    if (!emitEntity) {
        return;
    }
    if (!fingerprintCursor) {
        await deps.emit({
            type: "STATE",
            stream: "accounts",
            cursor: { fetched_at: nowIso() },
        });
        return;
    }
    // The dashboard scan re-enumerates the full account boundary every run and
    // suppresses unchanged accounts via the per-record fingerprint, so on a
    // steady-state run `collected` is a churn-reduced subset (often 0), not a
    // coverage count. Declare `considered = accounts.length` (the enumerated
    // boundary) with the objective `covered` count so the Collection Report reads
    // `complete` instead of a false `partial`
    // (define-connector-progress-evidence-contract task 4.4). This self-coverage
    // message (`stream === state_stream === "accounts"`, empty required/hydrated
    // keys) describes the entity inventory; `account_stats` is an append-keyed
    // daily observation, not an inventory, so it declares no denominator.
    await emitDetailCoverage(deps, {
        stream: "accounts",
        stateStream: "accounts",
        requiredKeys: [],
        hydratedKeys: [],
        considered: accounts.length,
        covered: entityCovered,
    });
    // Accounts enumeration is a full dashboard scan: prune fingerprints for
    // accounts no longer present so a re-added account re-emits.
    fingerprintCursor.dropUnseenIds();
    const cursor = { fetched_at: nowIso() };
    if (fingerprintCursor.size() > 0) {
        cursor.fingerprints = fingerprintCursor.toState();
    }
    await deps.emit({
        type: "STATE",
        stream: "accounts",
        cursor,
    });
}
/** Run the `accounts` entity and/or `account_stats` observation streams
 *  based on the requested scope. The entity fingerprint cursor is only
 *  opened when the entity stream is requested; the observation stream is
 *  append-keyed and needs no cursor. Extracted from `collect()` to keep that
 *  orchestrator under the cognitive-complexity budget. */
async function maybeRunAccountsStreams(deps, accounts, state, requested, emittedAt) {
    const wantsAccounts = requested.has("accounts");
    const wantsAccountStats = requested.has("account_stats");
    if (!(wantsAccounts || wantsAccountStats)) {
        return;
    }
    const accountsFingerprintCursor = wantsAccounts
        ? openFingerprintCursor(state.accounts, {
            excludeFromFingerprint: ["fetched_at"],
            priorFingerprints: readPriorAccountFingerprints(state),
        })
        : undefined;
    await emitAccountsStream(deps, accounts, emittedAt, accountsFingerprintCursor, {
        emitEntity: wantsAccounts,
        emitStats: wantsAccountStats,
    });
}
/**
 * Parse the prior `accounts` STATE cursor's `fingerprints` map. Keyed by
 * account `id` (the dashboard account id, or a hash of the raw text when
 * USAA does not expose one). Legacy cursors (only `{ fetched_at }`) decode
 * to an empty map, so the first post-deploy run rebuilds the map and
 * re-emits every account exactly once.
 */
export function readPriorAccountFingerprints(state) {
    const streamState = (state.accounts ?? {});
    const raw = streamState.fingerprints;
    const out = new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
/** Emit a SKIP_RESULT for every requested-but-deferred stream. Keeps
 *  the client informed that we understood the request but can't fulfil
 *  it in this revision — rather than silently dropping the scope. */
export async function emitDeferredStreams(emit, requested) {
    for (const s of DEFERRED_STREAMS) {
        if (requested.has(s)) {
            const msg = {
                type: "SKIP_RESULT",
                stream: s,
                reason: "selectors_pending",
                message: `${s} stream scaffolded in design-notes; click-chain or SPA-component wiring deferred.`,
            };
            await emit(msg);
        }
    }
}
/** Map the ladder's last diagnostic phase to a terminal outcome class. */
export function classifyExportLadderOutcome(lastDiag) {
    if (!lastDiag) {
        return "unknown";
    }
    if (isFatalDiagPhase(lastDiag)) {
        return "source_structure_changed";
    }
    return "export_pressure";
}
/**
 * Emit the "backfill ladder exhausted" SKIP_RESULT for transactions.
 * Called when `tryExportLadder` returns no CSV across every candidate
 * start without an explicit "nothing to export" source response.
 *
 * The honest-empty case (the source explicitly said "no transactions") never
 * reaches here — `processAccountTransactions` returns before calling this when
 * `exportEmpty` is true — so this function never turns a genuinely empty
 * account/window into a retryable gap.
 */
export async function emitExportFailure(deps, a, lastDiag) {
    const isCreditCard = CREDIT_CARD_TYPE_RE.test(a.account_type);
    const outcome = classifyExportLadderOutcome(lastDiag);
    const isNoExportAffordance = lastDiag?.phase === "no_export_affordance";
    let baseMessage = "USAA transaction export affordance was not found on the observed browser surface";
    if (!isNoExportAffordance) {
        baseMessage = lastDiag
            ? `Export ladder exhausted (${outcome}); ${formatDiagnosticInfo(lastDiag)}`
            : "Export dialog did not produce a download across all ranges; outcome unknown (transient pressure or shifted selectors)";
    }
    const ccSuffix = isCreditCard
        ? ' (credit-card export flow not verified live 2026-04-19 — see design-notes/usaa.md "Fallback path: DOM scrape")'
        : "";
    // Credit-card exports keep their own unverified-flow reason regardless of
    // outcome (the flow itself was never confirmed live), but still carry the
    // structural-vs-pressure discriminator in diagnostics. For non-credit-card
    // accounts, a missing affordance/dialog is reported as a distinct
    // structure-changed reason so the dashboard stops conflating "the connector
    // is broken" with "the export was momentarily unavailable".
    let reason;
    if (isCreditCard) {
        reason = "credit_card_export_unverified";
    }
    else if (outcome === "source_structure_changed") {
        reason = "export_affordance_missing";
    }
    else {
        reason = "export_no_download";
    }
    const noExportDiagnostic = isNoExportAffordance
        ? noExportAffordanceDiagnostic(lastDiag, deps.browserSurface ?? "unknown")
        : null;
    const baseDiagnostics = !isNoExportAffordance && lastDiag ? sanitizeDiagnosticInfo(lastDiag) : null;
    const durableDiagnostics = noExportDiagnostic
        ? { browser_surface: noExportDiagnostic }
        : { outcome };
    if (baseDiagnostics) {
        for (const [key, value] of Object.entries(baseDiagnostics)) {
            durableDiagnostics[key] = value;
        }
    }
    await deps.emit({
        type: "SKIP_RESULT",
        stream: "transactions",
        reason,
        message: `${baseMessage}${ccSuffix}`,
        diagnostics: durableDiagnostics,
    });
}
function sanitizeDiagnosticInfo(diag) {
    const sanitized = { phase: diag.phase };
    if (diag.diag) {
        sanitized.page = {
            dialogs_open: diag.diag.dialogs_open,
            export_candidate_count: diag.diag.export_candidates.length,
            has_utility_bar: diag.diag.has_utility_bar,
            nav_candidate_count: diag.diag.nav_candidates.length,
        };
    }
    if (diag.artifact) {
        const sourceCounts = { cdp: 0, playwright: 0 };
        for (const candidate of diag.artifact.candidates) {
            sourceCounts[candidate.source] += 1;
        }
        sanitized.artifact = {
            body_error_count: diag.artifact.candidates.filter((candidate) => candidate.reason === "body_error").length,
            candidate_count: diag.artifact.candidates.length,
            cdp_error: diag.artifact.cdpError !== null,
            cdp_ready: diag.artifact.cdpReady,
            matched_count: diag.artifact.candidates.filter((candidate) => candidate.reason === "matched").length,
            source_counts: sourceCounts,
            status_codes: [
                ...new Set(diag.artifact.candidates.map((candidate) => candidate.status)),
            ]
                .filter((status) => Number.isInteger(status))
                .slice(0, 8),
        };
    }
    if (diag.download) {
        sanitized.download = {
            bytes: typeof diag.download.bytes === "number" ? diag.download.bytes : null,
            has_download_failure: Boolean(diag.download.downloadFailure),
            has_save_as_error: Boolean(diag.download.saveAsError),
            has_stream_error: Boolean(diag.download.streamError),
            source: diag.download.source ?? null,
        };
    }
    return sanitized;
}
function summarizeArtifactDiagnostics(diag) {
    const { artifact } = diag;
    if (!artifact) {
        return null;
    }
    const matched = artifact.candidates.filter((candidate) => candidate.reason === "matched").length;
    const bodyErrors = artifact.candidates.filter((candidate) => candidate.reason === "body_error").length;
    const inspected = artifact.candidates.length;
    const parts = [
        `artifact cdpReady=${artifact.cdpReady ? "true" : "false"} candidates=${inspected} matched=${matched} bodyErrors=${bodyErrors}`,
    ];
    if (artifact.cdpError) {
        parts.push("cdpError=true");
    }
    return parts.join(" ");
}
function summarizeDownloadDiagnostics(diag) {
    const dl = diag.download;
    if (!dl) {
        return null;
    }
    const parts = [];
    if (typeof dl.bytes === "number") {
        parts.push(`bytes=${dl.bytes}`);
    }
    if (dl.source) {
        parts.push(`source=${dl.source}`);
    }
    if (dl.saveAsError) {
        parts.push("hasSaveAsError=true");
    }
    if (dl.streamError) {
        parts.push("hasStreamError=true");
    }
    if (dl.downloadFailure) {
        parts.push("hasDownloadFailure=true");
    }
    return parts.length ? `download ${parts.join(",")}` : null;
}
function formatDiagnosticInfo(diag) {
    const parts = [diag.phase];
    parts.push(`page=${diag.diag ? "captured" : "unavailable"}`);
    const artifact = summarizeArtifactDiagnostics(diag);
    if (artifact) {
        parts.push(artifact);
    }
    const download = summarizeDownloadDiagnostics(diag);
    if (download) {
        parts.push(download);
    }
    return parts.join("; ");
}
function failureDiagnostic(failureCode, error) {
    return {
        error_class: error instanceof Error ? "Error" : "unknown",
        failure_code: failureCode,
    };
}
/**
 * Emit one `statements` record per index row. A hydrated row gets a
 * populated `pdf_path` / `pdf_sha256` / `document_url`. A failed hydration
 * falls back to an index-only row so the client never loses the fact that
 * the statement exists — and, if the statement was previously hydrated,
 * carries the prior content-addressed pointers forward (instead of null)
 * so a transient re-download failure does not flap them `value -> null` and
 * re-version an immutable statement. A statement that was never hydrated
 * stays all-null (honest index-only). Emits a final PROGRESS + STATE.
 *
 * Body-honesty: a carried-forward body asserts the artifact's last known
 * content-addressed location (bytes a prior run stored, which never move),
 * not that this run re-verified it; the failed-download SKIP_RESULT emitted
 * by the hydration path remains the authoritative per-run record.
 *
 * Invariants (tested in integration.test.ts + statements-fingerprint.test.ts):
 *   - same number of records emitted as rows in, regardless of
 *     hydration success (carry-forward/null fallback, not drop),
 *   - hydrated rows set pdf_path + pdf_sha256 + document_url; a
 *     never-hydrated failed row leaves all three null; a previously-
 *     hydrated failed row carries the prior pointers forward,
 *   - STATE emits exactly once after all records.
 */
export async function emitStatementRecords(deps, indexRows, hydrationResults, summary, fingerprintCursor, hydrationCursor) {
    // Per-run detail-coverage evidence. Each statement-document row's resolved
    // hydration outcome (fresh, carried, or all-null) is the numerator input;
    // `shouldParseStatementTitle` is the candidacy (denominator) input. See
    // statement-coverage.ts. Collected here because this loop already resolves
    // both for every row; emitted once after the loop (below).
    const coverageRows = [];
    for (const row of indexRows) {
        const ok = hydrationSuccess(hydrationResults.get(row.rowIndex));
        // On success use this run's fresh pointers; on failure carry the prior
        // hydrated pointers forward if the statement was previously hydrated,
        // else stay all-null.
        let pointers;
        if (ok) {
            pointers = {
                document_url: fileUrlForPath(ok.pdfPath),
                pdf_path: ok.pdfPath,
                pdf_sha256: ok.pdfSha256,
                pdf_text_sha256: ok.content.pdf_text_sha256,
                pdf_page_count: ok.content.pdf_page_count,
            };
        }
        else if (hydrationCursor) {
            pointers = hydrationCursor.resolveOnFailure(row.id);
        }
        else {
            pointers = {
                document_url: null,
                pdf_path: null,
                pdf_sha256: null,
                pdf_text_sha256: null,
                pdf_page_count: null,
            };
        }
        coverageRows.push({
            id: row.id,
            isCandidate: shouldParseStatementTitle(row.title),
            pointers,
        });
        const rec = {
            id: row.id,
            account_id: row.account_id,
            title: row.title,
            date_delivered: row.date_delivered,
            account_reference: row.account_reference,
            document_url: pointers.document_url,
            pdf_sha256: pointers.pdf_sha256,
            pdf_path: pointers.pdf_path,
            pdf_text_sha256: pointers.pdf_text_sha256 ?? null,
            pdf_page_count: pointers.pdf_page_count ?? null,
            fetched_at: nowIso(),
        };
        // Record the resolved pointers (fresh, carried, or all-null) so the
        // next run's prior map stays complete and the prune step is correct.
        hydrationCursor?.note(row.id, pointers);
        // Gate on a per-statement fingerprint that excludes the run-clock
        // `fetched_at`. A statement's identity fields (id, account_id, title,
        // date_delivered) are immutable, and pdf_path/pdf_sha256/document_url
        // are content-addressed (the path embeds the sha256 prefix), so a
        // re-hydrated identical statement produces a byte-identical body
        // modulo `fetched_at`. With carry-forward, a transient failure also
        // produces a body identical to the prior hydrated one, so the cursor
        // suppresses the re-emit. Without this gate every run appended a fresh
        // version of every statement (~15 versions/record of pure run-clock
        // churn). When no cursor is supplied (legacy callers/tests) the
        // record always emits.
        if (!fingerprintCursor || fingerprintCursor.shouldEmit(rec)) {
            await deps.emitRecord("statements", rec);
        }
    }
    // Statements is a full scan of the documents index: prune fingerprints
    // (and the carried hydration pointers, in lockstep) for statements no
    // longer listed so a re-appearance re-emits and a delisted statement
    // stops being carried forever.
    fingerprintCursor?.dropUnseenIds();
    hydrationCursor?.dropUnseenIds();
    // Honest per-run detail coverage for the statement-PDF detail pass. Emitted
    // only when the run saw at least one statement-document row (a real
    // denominator). Each gap candidate (a statement whose PDF is not present this
    // run) is a pending, retryable DETAIL_GAP — so the run reads "partial, will
    // retry" instead of "complete", and the runtime's coverage-completeness
    // invariant (required === hydrated ∪ pending-gap) holds. Reference-only:
    // these reuse DETAIL_GAP / DETAIL_COVERAGE without promoting them to portable
    // protocol. Strictly additive — no statement RECORD or STATE changes.
    await emitStatementCoverage(deps, coverageRows);
    const progressMsg = {
        type: "PROGRESS",
        stream: "statements",
        message: `Hydrated ${summary.successes}/${summary.attempts || indexRows.length} PDFs`,
        count: summary.successes,
        total: summary.attempts || indexRows.length,
    };
    await deps.emit(progressMsg);
    const cursor = { fetched_at: nowIso() };
    if (fingerprintCursor && fingerprintCursor.size() > 0) {
        cursor.fingerprints = fingerprintCursor.toState();
    }
    if (hydrationCursor && hydrationCursor.size() > 0) {
        cursor.hydration = hydrationCursor.toState();
    }
    await deps.emit({
        type: "STATE",
        stream: "statements",
        cursor,
    });
}
/**
 * Emit the per-run `statements` detail-coverage evidence: a redacted, pending
 * DETAIL_GAP for each statement-document row whose PDF is not present this run,
 * then one DETAIL_COVERAGE whose `required_keys` is the real denominator (the
 * statement-document rows the run saw on the documents index). The denominator
 * never includes disclosures/agreements (index-only by design) and never
 * carries account/title text — only opaque statement id hashes. See
 * statement-coverage.ts for the contract.
 *
 * Always emits when called — including a steady-state run that enumerated the
 * documents index and found zero statement-document candidates (considered: 0,
 * covered: 0, empty key sets). The caller only invokes this once the index
 * enumeration has actually completed (`runStatementsStream`'s scrape try/catch
 * short-circuits to a SKIP_RESULT and never reaches this function on a failed
 * scrape — see index.ts's `runStatementsStream`), so "zero candidates here"
 * always means "the run measured the denominator and it was zero," never
 * "enumeration never happened." Suppressing on zero would leave the stream
 * permanently unmeasured on an every-run-empty account.
 */
export async function emitStatementCoverage(deps, coverageRows) {
    const result = computeStatementCoverage(coverageRows);
    for (const gap of result.gaps) {
        await deps.emit(gap);
    }
    await recoverServedStatementGaps(deps, result.coverage.hydratedKeys);
    await emitDetailCoverage(deps, result.coverage);
}
/**
 * Close the served `statements` gaps whose PDF is present again this run.
 *
 * A statement gap is opened whenever a run does not hold that statement's PDF,
 * and it is genuinely retryable — the next run re-attempts every row. But
 * nothing ever CLOSED one: a pending detail gap only leaves `pending` on an
 * explicit `DETAIL_GAP_RECOVERED` (see `connector-detail-gap-store.ts`), and
 * this connector emitted that message for `transactions` and the credit-card
 * streams while `statements` was left out.
 *
 * The result on the owner's instance: 4 `statements` gaps sat `pending` from a
 * 2026-08-04 run, three of them never re-attempted (`attempt_count = 0`), while
 * every one of those four statements had in fact been downloaded — each has a
 * durable `pdf_sha256` on its record, and the same stream reported
 * `covered: 10 / considered: 10, checkpoint: committed`. The stream was fully
 * collected and simultaneously showed a retryable gap, purely as stale
 * bookkeeping.
 *
 * `hydratedKeys` is the honest input: it is exactly the set
 * `computeStatementCoverage` proved artifact-present this run (`isHydrated` on
 * the resolved body), the same predicate that put those keys in the coverage
 * numerator. Only ids the runtime actually served as pending gaps are closed —
 * the lookup enforces that, so a recovery can never close unrelated work.
 */
async function recoverServedStatementGaps(deps, hydratedKeys) {
    const served = deps.servedStatementGaps;
    if (!served || served.size === 0) {
        return;
    }
    for (const key of hydratedKeys) {
        const statementId = String(key);
        const gapId = served.get(statementId);
        if (!gapId) {
            continue;
        }
        await deps.emit({
            type: "DETAIL_GAP_RECOVERED",
            reference_only: true,
            gap_id: gapId,
            stream: "statements",
            record_key: statementId,
        });
    }
}
/**
 * Parse the prior `statements` STATE cursor's `fingerprints` map. Keyed
 * by statement `id`. Legacy cursors (only `{ fetched_at }`) decode to an
 * empty map, so the first post-deploy run rebuilds the map and re-emits
 * every statement exactly once.
 */
export function readPriorStatementFingerprints(state) {
    const streamState = (state.statements ?? {});
    const raw = streamState.fingerprints;
    const out = new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
/**
 * Parse the prior `transactions` STATE cursor's `fingerprints` map. Keyed
 * by the transaction record `id` (`hashId(accountId|date|amount|original|
 * #ord)`), shared across the CSV-export and PDF-statement emit paths
 * (both hash the same logical transaction to the same id). The cursor is
 * otherwise a flat `accountKey -> { last_date }` map, so `fingerprints` is
 * a reserved sibling key. Legacy cursors (no `fingerprints`) decode to an
 * empty map, so the first post-deploy run rebuilds the map and re-emits
 * every in-window transaction exactly once.
 */
export function readPriorTransactionFingerprints(state) {
    const streamState = (state.transactions ?? {});
    const raw = streamState.fingerprints;
    const out = new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
/**
 * Parse the prior `inbox_messages` STATE cursor's `fingerprints` map.
 * Keyed by the message record `id` (`hashId(date_short|preview[:120])`).
 * Legacy cursors (only `{ fetched_at }`) decode to an empty map, so the
 * first post-deploy run rebuilds the map and re-emits every still-listed
 * message exactly once.
 */
export function readPriorInboxMessageFingerprints(state) {
    const streamState = (state.inbox_messages ?? {});
    const raw = streamState.fingerprints;
    const out = new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
// ─── Account extraction from the /my/usaa dashboard ───────────────────────
/**
 * Extract the dashboard account list. Exported purely so its mid-run
 * session-repair wiring is directly testable with a mocked Page/
 * BrowserContext. See singleton-checkpoint-coverage-wiring.test.ts.
 *
 * `streamState` is threaded in (constructed by the caller BEFORE this runs —
 * accounts is the FIRST stream `collect()` reaches) so a dashboard-stage
 * session death latches `sessionDeadMidRun` immediately: every downstream
 * stream reads `accounts` from this call's return value regardless of
 * whether extraction actually succeeded, so without this latch a dead
 * session here would silently proceed through transactions/statements/
 * inbox/credit-card-billing with an empty account list, each independently
 * discovering the same dead session and re-spending (or, pre-fix, uselessly
 * re-attempting) repair — the root of the N-logins defect this run-scoped
 * budget closes. See `UsaaRunState`.
 */
export async function extractAccounts(deps, context, page, sendInteraction, streamState) {
    const nav = await gotoOrRepairSession(deps, context, page, sendInteraction, "https://www.usaa.com/my/usaa", { timeout: DASHBOARD_NAV_TIMEOUT_MS }, "accounts", streamState);
    if (!nav.ok) {
        streamState.sessionDeadMidRun = true;
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "accounts",
            reason: "session_dead_reauth_failed",
            message: "USAA session expired before accounts could be extracted and re-auth failed.",
        });
        return [];
    }
    await page
        .waitForSelector(DASHBOARD_SELECTOR_WAIT, {
        timeout: DASHBOARD_SELECTOR_TIMEOUT_MS,
    })
        .catch(() => undefined);
    await politeDelay(DASHBOARD_SETTLE_DELAY_MS);
    return page.evaluate((linkSelector) => {
        // biome-ignore-start lint/performance/useTopLevelRegex: runs in browser context (page.evaluate); module-scoped regexes in Node cannot cross the bridge.
        const WHITESPACE_RE = /\s+/g;
        const SKIP_TEXT_RE = /^(Get started|Add account|View|Manage|Open|Apply|Browse)/i;
        const TYPE_URL_RE = /^\/my\/([^/?]+)/;
        const ACCOUNT_ID_RE = /(?:accountId|acctId)=([^&]+)/;
        const LAST4_RE = /\*(\d{4})/;
        const ENDING_IN_RE = /\bEnding in\b|\bending in\b/i;
        const DOLLAR_RE = /\$([\d,]+\.\d{2})/g;
        const COMMA_RE_LOCAL = /,/g;
        // biome-ignore-end lint/performance/useTopLevelRegex: runs in browser context (page.evaluate); module-scoped regexes in Node cannot cross the bridge.
        const out = [];
        const links = [...document.querySelectorAll(linkSelector)];
        for (const a of links) {
            const href = a.getAttribute("href") || "";
            const text = (a.innerText || "").replace(WHITESPACE_RE, " ").trim();
            // Skip nav/CTA links that happen to match the URL prefix but have generic text.
            if (!text || text.length < 12 || SKIP_TEXT_RE.test(text)) {
                continue;
            }
            const typeMatch = href.match(TYPE_URL_RE);
            const accountType = typeMatch?.[1] ?? "unknown";
            const idMatch = href.match(ACCOUNT_ID_RE);
            const accountId = idMatch?.[1] ? decodeURIComponent(idMatch[1]) : null;
            const last4Match = text.match(LAST4_RE);
            const splitByEnding = text.split(ENDING_IN_RE);
            const namePart = splitByEnding[0] ?? "";
            const name = namePart.trim();
            const amounts = [...text.matchAll(DOLLAR_RE)]
                .map((m) => (m[1] ? m[1] : null))
                .filter((v) => Boolean(v));
            const [firstAmount] = amounts;
            const balanceCents = firstAmount
                ? Math.round(Number(firstAmount.replace(COMMA_RE_LOCAL, "")) * 100)
                : null;
            out.push({
                account_id_raw: accountId,
                account_url: href,
                account_type: accountType,
                name: name || null,
                last_four: last4Match?.[1] ?? null,
                balance_cents: balanceCents,
                raw_text: text.slice(0, 200),
            });
        }
        return out;
    }, ACCOUNT_URL_PREFIXES);
}
// ─── CSV export driver for transactions ───────────────────────────────────
async function findExportAffordance(page) {
    const bankClass = page.locator("button.ent-as-utility-bar__item.export");
    if (await bankClass.count().catch(() => 0)) {
        return bankClass.first();
    }
    const creditClass = page.locator("button.as_credit__utility-bar-item.as_credit__export");
    if (await creditClass.count().catch(() => 0)) {
        return creditClass.first();
    }
    const buttonText = page
        .locator('button, [role="button"]')
        .filter({ hasText: EXPORT_BUTTON_TEXT_RE });
    if (await buttonText.count().catch(() => 0)) {
        return buttonText.first();
    }
    return null;
}
/** Classify in memory only; no URL or route fragment reaches durable evidence. */
export function classifyUsaaNoExportRoute(value, hasKnownAccountOrTransactionMarker) {
    try {
        const url = new URL(value);
        if (url.hostname !== "www.usaa.com") {
            return "unknown";
        }
        if (USAA_INTERSTITIAL_ROUTE_RE.test(url.pathname)) {
            return "interstitial";
        }
        return USAA_ACCOUNT_DETAIL_ROUTE_RE.test(url.pathname) &&
            hasKnownAccountOrTransactionMarker
            ? "expected"
            : "unknown";
    }
    catch {
        return "unknown";
    }
}
async function captureNoExportAffordanceObservation(page) {
    const counts = await page
        .evaluate(({ accountDetail, exportAffordance, navigation, transaction }) => ({
        account_detail_marker_count: document.querySelectorAll(accountDetail).length,
        navigation_marker_count: document.querySelectorAll(navigation).length,
        target_count: document.querySelectorAll(exportAffordance).length,
        transaction_marker_count: document.querySelectorAll(transaction).length,
    }), {
        accountDetail: USAA_ACCOUNT_DETAIL_MARKER_SELECTOR,
        exportAffordance: USAA_EXPORT_AFFORDANCE_SELECTOR,
        navigation: USAA_NAVIGATION_MARKER_SELECTOR,
        transaction: USAA_TRANSACTION_MARKER_SELECTOR,
    })
        .catch(() => ({
        account_detail_marker_count: 0,
        navigation_marker_count: 0,
        target_count: 0,
        transaction_marker_count: 0,
    }));
    const hasKnownAccountOrTransactionMarker = counts.account_detail_marker_count > 0 ||
        counts.transaction_marker_count > 0;
    return {
        ...counts,
        route: classifyUsaaNoExportRoute(page.url(), hasKnownAccountOrTransactionMarker),
    };
}
function noExportAffordanceDiagnostic(diag, managedSurface) {
    const observation = diag?.no_export_observation;
    const diagnostic = buildBrowserSurfaceDiagnostic({
        accountDetailMarkerCount: observation?.account_detail_marker_count,
        kind: "usaa_transaction_export",
        managedSurface,
        navigationMarkerCount: observation?.navigation_marker_count,
        parserCount: 0,
        readCount: 1,
        route: observation?.route ?? "unknown",
        targetCount: observation?.target_count,
        transactionMarkerCount: observation?.transaction_marker_count,
        verifiedEmptyMarkerCount: 0,
        waitOutcome: "not_needed",
    });
    if (!diagnostic) {
        throw new Error("closed USAA browser-surface diagnostic input was invalid");
    }
    return diagnostic;
}
class SessionDeadRedirectError extends Error {
    observation;
    constructor(observation) {
        super("session_dead_redirect_to_logon");
        this.name = "SessionDeadRedirectError";
        this.observation = observation;
    }
}
function capturePageDiagnostics(page) {
    return page
        .evaluate(() => {
        // biome-ignore-start lint/performance/useTopLevelRegex: runs in browser context (page.evaluate); module-scoped regexes in Node cannot cross the bridge.
        const WS_RE = /\s+/g;
        const EXPORT_OR_DL_RE = /export|download/i;
        // biome-ignore-end lint/performance/useTopLevelRegex: runs in browser context (page.evaluate); module-scoped regexes in Node cannot cross the bridge.
        const take = (sel, max = 8) => {
            const els = [...document.querySelectorAll(sel)];
            return els.slice(0, max).map((el) => ({
                tag: el.tagName,
                text: (el.innerText || "").replace(WS_RE, " ").trim().slice(0, 50),
                cls: (el.className ? String(el.className) : "").slice(0, 80),
                id: el.id || null,
            }));
        };
        return {
            url: location.href,
            title: document.title,
            has_utility_bar: Boolean(document.querySelector('.ent-as-utility-bar, [class*="utility-bar" i]')),
            export_candidates: take('button, [role="button"]').filter((c) => EXPORT_OR_DL_RE.test(c.text)),
            nav_candidates: take('a[href*="/my/credit-card"], a[role="tab"], [role="tab"]'),
            dialogs_open: document.querySelectorAll('[role="dialog"]').length,
        };
    })
        .catch(() => null);
}
/**
 * If `finalUrl` is a USAA marketing interstitial, return the account URL to
 * retry; otherwise `null` (we are already where we asked to be, or somewhere
 * this function has no honest opinion about).
 *
 * Pure and exported so the escape decision is testable without Playwright.
 *
 * The retry target is the interstitial's own `goto` param when it names a USAA
 * account-detail route, else the `accountUrl` originally requested. Both are
 * URLs the caller already had or USAA itself supplied; a `goto` pointing
 * off-host or at some other section is refused rather than followed, so a
 * redirect chain can never steer the connector somewhere it did not intend to
 * go. Returns `null` when the escape target matches the URL we just loaded, so
 * a self-referential offer page cannot produce an infinite retry.
 */
export function resolveUsaaOfferInterstitialEscape(finalUrl, accountUrl) {
    let parsed;
    try {
        parsed = new URL(finalUrl);
    }
    catch {
        return null;
    }
    if (parsed.hostname !== "www.usaa.com" ||
        !USAA_OFFER_INTERSTITIAL_ROUTE_RE.test(parsed.pathname)) {
        return null;
    }
    let target = accountUrl;
    const goto = parsed.searchParams.get("goto");
    if (goto) {
        try {
            const gotoUrl = new URL(goto, "https://www.usaa.com");
            if (gotoUrl.hostname === "www.usaa.com" &&
                USAA_ACCOUNT_DETAIL_ROUTE_RE.test(gotoUrl.pathname)) {
                target = gotoUrl.toString();
            }
        }
        catch {
            // Unparseable `goto` — fall back to the requested account URL.
        }
    }
    return target === finalUrl ? null : target;
}
/**
 * Ensure the just-loaded page is the account page we asked for, navigating
 * through a USAA marketing offer if one was served in front of it.
 *
 * Returns `false` when this candidate URL should be abandoned (the escape
 * navigation itself failed); `true` when the caller should look for the export
 * affordance on the current page.
 *
 * Throws {@link SessionDeadRedirectError} if the session died — before OR
 * after the escape hop, since an offer page can itself redirect to logon.
 *
 * Exactly one escape hop is attempted. If the offer re-serves itself, the
 * caller's ordinary no-affordance path reports it rather than looping.
 */
async function settleOnAccountPage(page, accountUrl, settleDelayMs) {
    const assertSessionAlive = async () => {
        if (LOGON_REDIRECT_RE.test(page.url())) {
            throw new SessionDeadRedirectError(await captureNoExportAffordanceObservation(page));
        }
    };
    await assertSessionAlive();
    const escapeUrl = resolveUsaaOfferInterstitialEscape(page.url(), accountUrl);
    if (!escapeUrl) {
        return true;
    }
    try {
        await page.goto(escapeUrl, {
            waitUntil: "domcontentloaded",
            timeout: ACCOUNT_NAV_TIMEOUT_MS,
        });
    }
    catch {
        return false;
    }
    await politeDelay(settleDelayMs);
    await assertSessionAlive();
    return true;
}
async function locateExportPage(page, accountUrl, settleDelayMs) {
    const candidates = [accountUrl];
    const seen = new Set();
    for (const url of candidates) {
        if (seen.has(url)) {
            continue;
        }
        seen.add(url);
        try {
            await page.goto(url, {
                waitUntil: "domcontentloaded",
                timeout: ACCOUNT_NAV_TIMEOUT_MS,
            });
        }
        catch {
            continue;
        }
        await politeDelay(settleDelayMs);
        if (!(await settleOnAccountPage(page, url, settleDelayMs))) {
            continue;
        }
        const btn = await findExportAffordance(page);
        if (btn) {
            return { url, export: btn };
        }
    }
    return null;
}
const DIALOG_HTML_WS_RE = /\s+/g;
async function emitExportClickFailedDiagnostic(page, onDiagnostics, err) {
    if (!onDiagnostics) {
        return;
    }
    const diag = await capturePageDiagnostics(page);
    const msg = err instanceof Error ? err.message : String(err);
    onDiagnostics({
        phase: "export_click_failed",
        diag,
        error: msg.slice(0, ID_TEXT_SNIP),
    });
}
async function emitDialogUnexpectedShapeDiagnostic(page, onDiagnostics) {
    const base = await capturePageDiagnostics(page);
    const dialogHtml = await page
        .locator('[role="dialog"]')
        .first()
        .innerHTML()
        .catch(() => null);
    const preview = dialogHtml
        ? dialogHtml.replace(DIALOG_HTML_WS_RE, " ").slice(0, HTML_PREVIEW_MAX)
        : null;
    onDiagnostics({
        phase: "export_dialog_unexpected_shape",
        diag: base
            ? { ...base, dialog_html_preview: preview }
            : {
                url: "",
                title: "",
                has_utility_bar: false,
                export_candidates: [],
                nav_candidates: [],
                dialogs_open: 0,
                dialog_html_preview: preview,
            },
    });
}
async function isVisibleActionableField(field) {
    try {
        await field.waitFor({ state: "visible", timeout: EXPORT_DIALOG_DELAY_MS });
        return (await field.isEnabled()) && (await field.isEditable());
    }
    catch {
        return false;
    }
}
/** Click Export, select date-range when offered, then confirm the date fields.
 *
 * Both waits are bounded. The selection control is optional, but when it is
 * present it must be applied before checking the date fields because USAA can
 * render or enable those fields as a consequence of choosing date-range.
 * The date-field check is therefore the post-selection structural gate.
 */
async function openExportDialog(page, located, options) {
    const { onDiagnostics } = options;
    try {
        await located.export.click({ timeout: EXPORT_CLICK_TIMEOUT_MS });
    }
    catch (err) {
        await emitExportClickFailedDiagnostic(page, onDiagnostics, err);
        return false;
    }
    const dialog = page.locator('[role="dialog"]').first();
    const dialogCount = await dialog.count().catch(() => 0);
    if (dialogCount === 0) {
        if (onDiagnostics) {
            await emitDialogUnexpectedShapeDiagnostic(page, onDiagnostics);
        }
        // Capture before Escape: the keypress below can dismiss/mutate the
        // dialog surface, so the checkpoint must run on the still-intact page.
        await captureExportCheckpoint(page, options, "dialog-not-open");
        await page.keyboard.press("Escape").catch(() => undefined);
        return false;
    }
    const selectLocator = dialog.locator('select[name="selectionType"]');
    const rendered = await selectLocator
        .first()
        .waitFor({ state: "visible", timeout: EXPORT_DIALOG_DELAY_MS })
        .then(() => true)
        .catch(() => false);
    const selectCount = rendered
        ? await selectLocator.count().catch(() => 0)
        : 0;
    if (selectCount > 0) {
        try {
            await selectLocator.first().selectOption("date-range");
        }
        catch {
            if (onDiagnostics) {
                await emitDialogUnexpectedShapeDiagnostic(page, onDiagnostics);
            }
            await captureExportCheckpoint(page, options, "dialog-not-open");
            await page.keyboard.press("Escape").catch(() => undefined);
            return false;
        }
        await politeDelay(EXPORT_STATE_DELAY_MS);
    }
    const startInput = dialog
        .locator('input[name="fromDate"], input[name="startDate"]')
        .first();
    const endInput = dialog.locator('input[name="endDate"]').first();
    const hasActionableDateRange = (await isVisibleActionableField(startInput)) &&
        (await isVisibleActionableField(endInput));
    if (!hasActionableDateRange) {
        if (onDiagnostics) {
            await emitDialogUnexpectedShapeDiagnostic(page, onDiagnostics);
        }
        // Capture before Escape: the keypress below can dismiss/mutate the
        // dialog surface, so the checkpoint must run on the still-intact page.
        await captureExportCheckpoint(page, options, "dialog-not-open");
        await page.keyboard.press("Escape").catch(() => undefined);
        return false;
    }
    // A missing selection control is tolerated after the dialog has proved it
    // contains the visible, enabled, editable date-range pair used by the fill
    // path. A present control was selected above before this gate ran.
    return true;
}
/** Fill the date-range inputs via clear → type.
 *
 * Resilient to USAA dialog structure changes: the selection control is
 * optional, but both date fields must be in the active dialog and every fill
 * operation must succeed before submission is allowed.
 */
async function fillExportDateRange(page, dialog, sinceDate, untilDate) {
    const fromIn = dialog
        .locator('input[name="fromDate"], input[name="startDate"]')
        .first();
    const endIn = dialog.locator('input[name="endDate"]').first();
    // Do not catch these operations: an incomplete range must fail before
    // submitExportAndAwait rather than silently producing an unbounded export.
    await fromIn.click();
    await page.keyboard.press("Control+A");
    await page.keyboard.press("Delete");
    await fromIn.pressSequentially(mmddyyyy(sinceDate), {
        delay: KEY_TYPE_DELAY_MS,
    });
    await endIn.click();
    await page.keyboard.press("Control+A");
    await page.keyboard.press("Delete");
    await endIn.pressSequentially(mmddyyyy(untilDate), {
        delay: KEY_TYPE_DELAY_MS,
    });
    await politeDelay(EXPORT_STATE_DELAY_MS);
    await politeDelay(EXPORT_STATE_DELAY_MS);
}
async function tryFillExportDateRange(page, dialog, sinceDate, untilDate, onDiagnostics) {
    try {
        await fillExportDateRange(page, dialog, sinceDate, untilDate);
        return true;
    }
    catch (err) {
        if (onDiagnostics) {
            const message = err instanceof Error ? err.message : String(err);
            onDiagnostics({
                diag: await capturePageDiagnostics(page),
                error: message.slice(0, ID_TEXT_SNIP),
                phase: "export_dialog_fill_failed",
            });
        }
        return false;
    }
}
async function captureExportCheckpoint(page, options, suffix) {
    if (!(options.capture && options.captureLabel)) {
        return;
    }
    await options.capture
        .captureDom(page, `${options.captureLabel}-${suffix}`)
        .catch(() => undefined);
}
/**
 * Error subclass used by `waitForCsvArtifact` so failure callers can read
 * the download-side evidence (Playwright Download URL, suggestedFilename,
 * remote `failure()`, byte count, fallback source) without re-deriving it.
 */
class CsvArtifactError extends Error {
    download;
    constructor(message, download, cause) {
        super(message, cause === undefined ? undefined : { cause });
        this.name = "CsvArtifactError";
        this.download = download;
    }
}
export function isNoDataExportMessage(text) {
    return EXPORT_NO_DATA_RE.test(text);
}
/**
 * Skip Adobe Analytics / SiteCatalyst beacon hosts when filtering candidate
 * response bodies. USAA tracks the "export" click as a pageName analytics
 * event, so the keyword `export` ends up in the URL query string of every
 * beacon hit — which was matching `CSV_DOWNLOAD_HINT_RE` and crowding the
 * real CSV endpoint out of the diagnostics candidate list when an export
 * actually failed. Beacons return `image/gif` and never carry the CSV body,
 * so excluding them costs us nothing.
 */
const ANALYTICS_HOST_RE = /^https?:\/\/(da|smetrics|tags|tms)\.usaa\.com\//iu;
const ANALYTICS_CONTENT_TYPE_RE = /image\/gif/iu;
function isAnalyticsBeacon(headers, url) {
    if (ANALYTICS_HOST_RE.test(url)) {
        return true;
    }
    const contentType = headers["content-type"]?.toLowerCase() ?? "";
    return ANALYTICS_CONTENT_TYPE_RE.test(contentType);
}
function attachCsvResponseQueue(page) {
    return attachBodyResponseQueue(page, {
        isExpectedBody(body, headers) {
            if (body.length === 0) {
                return false;
            }
            const contentType = headers["content-type"]?.toLowerCase() ?? "";
            if (contentType.includes("text/html") ||
                contentType.includes("application/json")) {
                return false;
            }
            const head = body.subarray(0, 2048).toString("utf8");
            return CSV_HEAD_RE.test(head) && head.includes(",");
        },
        shouldInspect(headers, url) {
            if (isAnalyticsBeacon(headers, url)) {
                return false;
            }
            const hint = `${headers["content-disposition"] ?? ""} ${headers["content-type"] ?? ""} ${url}`;
            return CSV_DOWNLOAD_HINT_RE.test(hint);
        },
    });
}
async function snapshotDownloadFailure(download) {
    const failure = await download.failure().catch(() => null);
    let url;
    try {
        url = download.url();
    }
    catch {
        url = null;
    }
    let suggestedFilename;
    try {
        suggestedFilename = download.suggestedFilename();
    }
    catch {
        suggestedFilename = null;
    }
    return { url, suggestedFilename, downloadFailure: failure };
}
async function waitForCsvArtifact(downloadQueue, responseQueue) {
    const responsePromise = responseQueue.waitForNextResponse({
        timeoutMs: DOWNLOAD_TIMEOUT_MS,
    });
    const downloadPromise = downloadQueue.waitForNextDownload({
        timeoutMs: DOWNLOAD_TIMEOUT_MS,
    });
    const result = await Promise.any([
        responsePromise.then((response) => ({
            kind: "response",
            response,
        })),
        downloadPromise.then((downloadResult) => ({
            download: downloadResult,
            kind: "download",
        })),
    ]);
    if (result.kind === "response") {
        return {
            buffer: result.response.body,
            suggestedFilename: result.response.suggestedFilename,
        };
    }
    const { download } = result;
    try {
        const { buffer, outcome } = await readPlaywrightDownloadBufferDetailed(download);
        if (buffer.length > 0) {
            return { buffer, suggestedFilename: download.suggestedFilename() };
        }
        // saveAs + createReadStream both produced zero bytes. Capture the
        // download-side evidence (URL, suggested filename, remote failure)
        // before falling through to the response-queue grace window.
        const baseDiag = await snapshotDownloadFailure(download);
        const downloadDiag = {
            ...baseDiag,
            bytes: outcome.bytes,
            source: outcome.source,
            saveAsError: outcome.saveAsError ?? null,
            streamError: outcome.streamError ?? null,
        };
        const response = await waitForOptionalBodyResponse(responsePromise, RESPONSE_FALLBACK_GRACE_MS);
        if (response) {
            return {
                buffer: response.body,
                suggestedFilename: response.suggestedFilename,
            };
        }
        throw new CsvArtifactError("download_empty", downloadDiag);
    }
    catch (err) {
        if (err instanceof CsvArtifactError) {
            throw err;
        }
        const baseDiag = await snapshotDownloadFailure(download).catch(() => ({}));
        const downloadDiag = {
            ...baseDiag,
            bytes: 0,
            saveAsError: err instanceof Error ? err.message : String(err),
        };
        const response = await waitForOptionalBodyResponse(responsePromise, RESPONSE_FALLBACK_GRACE_MS);
        if (response) {
            return {
                buffer: response.body,
                suggestedFilename: response.suggestedFilename,
            };
        }
        throw new CsvArtifactError(err instanceof Error ? err.message : String(err), downloadDiag, err);
    }
}
/** Submit the export dialog, race the downloadable artifact against an inline error. */
async function submitExportAndAwait(page) {
    const downloadQueue = attachDownloadQueue(page);
    const responseQueue = attachCsvResponseQueue(page);
    await responseQueue.ready;
    const submit = page.locator('[role="dialog"] button[type="submit"]').first();
    try {
        await submit.click().catch(() => undefined);
        const dialogMessage = page.locator(EXPORT_DIALOG_MESSAGE_SELECTOR).first();
        const readDialogOutcome = async () => {
            const message = ((await dialogMessage.textContent().catch(() => null)) ??
                "").trim();
            return isNoDataExportMessage(message)
                ? { kind: "empty", message }
                : { kind: "dialog_error", message };
        };
        const errorPromise = page
            .locator(EXPORT_DIALOG_MESSAGE_SELECTOR)
            .first()
            .waitFor({ state: "visible", timeout: DOWNLOAD_TIMEOUT_MS })
            .then(readDialogOutcome)
            .catch(() => new Promise(() => undefined));
        return await Promise.race([
            waitForCsvArtifact(downloadQueue, responseQueue).then((artifact) => ({
                buffer: artifact.buffer,
                kind: "artifact",
                suggestedFilename: artifact.suggestedFilename,
            })),
            errorPromise,
        ]);
    }
    catch (err) {
        return {
            artifact: responseQueue.diagnostics(),
            download: err instanceof CsvArtifactError ? err.download : null,
            error: err instanceof Error ? err.message : String(err),
            kind: "artifact_failed",
        };
    }
    finally {
        downloadQueue.detach();
        responseQueue.detach();
    }
}
async function noExportAffordanceFailure(page, options) {
    await captureExportCheckpoint(page, options, "no-export-affordance");
    if (options.onDiagnostics) {
        const noExportObservation = await captureNoExportAffordanceObservation(page);
        options.onDiagnostics({
            diag: null,
            no_export_observation: noExportObservation,
            phase: "no_export_affordance",
        });
    }
    return { kind: "failed" };
}
export async function driveExport(page, accountUrl, options) {
    const { sinceDate, untilDate, onDiagnostics } = options;
    const located = await locateExportPage(page, accountUrl, options.settleDelayMs ?? ACCOUNT_SETTLE_DELAY_MS);
    if (!located) {
        return noExportAffordanceFailure(page, options);
    }
    const dialogOpen = await openExportDialog(page, located, options);
    if (!dialogOpen) {
        return { kind: "failed" };
    }
    const dialog = page.locator('[role="dialog"]').first();
    if (!(await tryFillExportDateRange(page, dialog, sinceDate, untilDate, onDiagnostics))) {
        return { kind: "failed" };
    }
    await captureExportCheckpoint(page, options, "before-submit");
    const tempDir = mkdtempSync(join(tmpdir(), "usaa-export-"));
    const outcome = await submitExportAndAwait(page);
    if (outcome.kind === "empty" || outcome.kind === "dialog_error") {
        rmSync(tempDir, { recursive: true, force: true });
        await captureExportCheckpoint(page, options, outcome.kind === "empty" ? "source-empty" : "dialog-error");
        let dialogDiag = null;
        if (outcome.kind === "dialog_error" && onDiagnostics) {
            dialogDiag = await capturePageDiagnostics(page);
        }
        await page
            .locator('[role="dialog"] #export-cancel-button')
            .click()
            .catch(() => undefined);
        if (outcome.kind === "dialog_error" && onDiagnostics) {
            onDiagnostics({
                diag: dialogDiag,
                error: outcome.message,
                phase: "export_dialog_error",
            });
        }
        return outcome.kind === "empty" ? { kind: "empty" } : { kind: "failed" };
    }
    if (outcome.kind === "artifact_failed") {
        rmSync(tempDir, { recursive: true, force: true });
        await captureExportCheckpoint(page, options, "artifact-failed");
        if (onDiagnostics) {
            const diag = await capturePageDiagnostics(page);
            onDiagnostics({
                artifact: outcome.artifact,
                diag,
                download: outcome.download,
                error: outcome.error,
                phase: "export_artifact_wait_failed",
            });
        }
        return { kind: "failed" };
    }
    const suggested = (outcome.suggestedFilename || "usaa-export.csv").replace(UNSAFE_FILENAME_RE, "_");
    const targetPath = join(tempDir, suggested);
    await writeFile(targetPath, outcome.buffer);
    return { kind: "artifact", path: targetPath };
}
/** Latch `streamState.sessionDeadMidRun` from a stream's session-alive
 *  result. Extracted so `collect()`'s per-stream gating reads as one call
 *  per stream instead of a repeated inline `if (!x) { ...= true }`. */
function latchSessionDead(streamState, sessionAlive) {
    if (!sessionAlive) {
        streamState.sessionDeadMidRun = true;
    }
}
/**
 * `streamState.sessionRepairAttempted` is the same RUN-scoped budget
 * `gotoOrRepairSession` spends — shared here so the transactions export
 * ladder cannot drive its own automated bank login independently of every
 * other stream. Without this check, this path's "≤1 login per run" property
 * held only because the ladder's own latch (`onSessionDead`) happens to stop
 * the loop before a second call could occur — an emergent property of call
 * ordering, not a local one. Checking the shared budget here makes the
 * guarantee true by construction, the same way it already is in
 * `gotoOrRepairSession`.
 */
async function reauthAfterSessionLapse(deps, context, page, sendInteraction, _accountName, streamState, observation) {
    if (streamState.sessionRepairAttempted) {
        return false;
    }
    streamState.sessionRepairAttempted = true;
    await deps.emit({
        type: "PROGRESS",
        stream: "transactions",
        message: "Session lapsed during transactions; re-authenticating before retry",
    });
    try {
        if (deps.reauthenticate) {
            await deps.reauthenticate({ context, page, sendInteraction });
        }
        else {
            await ensureUsaaSession({
                capture: deps.capture ?? null,
                context,
                ...(deps.credentials === undefined
                    ? {}
                    : { credentials: deps.credentials }),
                page,
                sendInteraction,
            });
        }
        return true;
    }
    catch {
        const diagnostic = observation
            ? noExportAffordanceDiagnostic({
                diag: null,
                no_export_observation: observation,
                phase: "no_export_affordance",
            }, deps.browserSurface ?? "unknown")
            : null;
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "transactions",
            reason: "session_dead_reauth_failed",
            message: "USAA session expired mid-run and re-auth failed. Remaining accounts and statements skipped.",
            ...(diagnostic ? { diagnostics: { browser_surface: diagnostic } } : {}),
        });
        return false;
    }
}
/**
 * Navigate to `url`; if the final URL bounces to USAA's logon/OAuth-authorize
 * flow (`LOGON_REDIRECT_RE`) — the same mid-run session-death signal the
 * transactions export ladder already detects (`SessionDeadRedirectError`,
 * above) — re-run the connector's existing session-establishment flow
 * exactly once (`ensureUsaaSession`, idempotent: no-ops when the cookie is
 * still live) and retry the SAME navigation exactly once. A second redirect,
 * or a failed repair, reports session death to the caller instead of looping
 * or silently scraping the logon page as if it were data.
 *
 * `streamState.sessionRepairAttempted` is a RUN-scoped budget, not a
 * per-call one: this is the sole spender, and it is shared across every one
 * of this run's five stream entry points (accounts, transactions, statements,
 * inbox, and — critically — once per CARD in the credit-card billing loop,
 * which calls this function once per card). Without a run-scoped budget here,
 * a session that dies once before the credit-card loop would otherwise drive
 * one full automated bank login per remaining card. If the budget is already
 * spent (a prior call this run already attempted repair, whether it
 * succeeded or failed), a subsequent logon bounce returns `{ ok: false }`
 * immediately after detecting the bounce — it neither calls
 * `ensureUsaaSession`/`reauthenticate` again nor spends the post-repair retry
 * navigation. The caller must treat that identically to "repair attempted
 * and failed."
 *
 * Distinct from `SessionDeadRedirectError`/`reauthAfterSessionLapse` above
 * (which is transactions-specific and threads a `NoExportAffordanceObservation`
 * for its own diagnostic) — this is the shared, stream-agnostic version used
 * by accounts/statements/inbox/credit-card navigation, which have no
 * equivalent export-dialog diagnostic to capture.
 */
export async function gotoOrRepairSession(deps, context, page, sendInteraction, url, navOptions, streamForProgress, streamState, 
/** Set when the caller already navigated to `url` and confirmed the
 *  logon bounce itself (e.g. `navigateToCardOrGap`, which needs the
 *  distinct "goto rejected" vs "goto landed on logon" cases either way) —
 *  skips this function's own redundant first navigation. */
alreadyLandedOnLogon = false) {
    if (!alreadyLandedOnLogon) {
        await page.goto(url, {
            waitUntil: "domcontentloaded",
            timeout: navOptions.timeout,
        });
        if (!LOGON_REDIRECT_RE.test(page.url())) {
            return { ok: true };
        }
    }
    if (streamState.sessionRepairAttempted) {
        return { ok: false };
    }
    streamState.sessionRepairAttempted = true;
    await deps.emit({
        type: "PROGRESS",
        stream: streamForProgress,
        message: "Session lapsed mid-run; re-authenticating before retry",
    });
    try {
        if (deps.reauthenticate) {
            await deps.reauthenticate({ context, page, sendInteraction });
        }
        else {
            await ensureUsaaSession({
                capture: deps.capture ?? null,
                context,
                ...(deps.credentials === undefined
                    ? {}
                    : { credentials: deps.credentials }),
                page,
                sendInteraction,
            });
        }
    }
    catch {
        return { ok: false };
    }
    await page.goto(url, {
        waitUntil: "domcontentloaded",
        timeout: navOptions.timeout,
    });
    return LOGON_REDIRECT_RE.test(page.url()) ? { ok: false } : { ok: true };
}
function exportCaptureLabel(a, sinceDate, untilDate) {
    const account = `${a.name ?? a.account_type}-${a.last_four ?? "unknown"}`;
    return `transaction-export-${account}-${sinceDate}-to-${untilDate}`;
}
/** Run one iteration of the backfill ladder: drive export + translate errors. */
export async function runSingleLadderAttempt({ deps, context, page, sendInteraction, a, accountOrdinal, accountTotal, attemptOrdinal, attemptTotal, sinceDate, streamState, todayIso, onDiagnostics, onSessionDead, settleDelayMs, }) {
    await deps.emit({
        type: "PROGRESS",
        stream: "transactions",
        message: `Export wait: account ${accountOrdinal}/${accountTotal}, window ${attemptOrdinal}/${attemptTotal}`,
    });
    let attemptDiagnostic = null;
    const recordDiagnostic = (info) => {
        attemptDiagnostic = info;
        onDiagnostics(info);
    };
    try {
        const exportResult = await driveExport(page, `https://www.usaa.com${a.account_url}`, {
            sinceDate,
            untilDate: todayIso,
            accountType: a.account_type,
            capture: deps.capture ?? null,
            captureLabel: exportCaptureLabel(a, sinceDate, todayIso),
            onDiagnostics: recordDiagnostic,
            ...(settleDelayMs === undefined ? {} : { settleDelayMs }),
        });
        if (exportResult.kind === "artifact") {
            return { kind: "success", csvPath: exportResult.path };
        }
        if (exportResult.kind === "empty") {
            return { kind: "empty" };
        }
        return isFatalDiagPhase(attemptDiagnostic)
            ? { kind: "structure_changed" }
            : { kind: "retry" };
    }
    catch (err) {
        if (err instanceof SessionDeadRedirectError) {
            const ok = await reauthAfterSessionLapse(deps, context, page, sendInteraction, a.name, streamState, err.observation);
            if (ok) {
                return { kind: "retry" };
            }
            onSessionDead();
            return { kind: "session_dead" };
        }
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "transactions",
            reason: "export_error",
            message: `Export error: account ${accountOrdinal}/${accountTotal}, window ${attemptOrdinal}/${attemptTotal}; retry by runtime`,
        });
        return { kind: "retry" };
    }
}
function isFatalDiagPhase(diag) {
    return Boolean(diag &&
        (diag.phase === "no_export_affordance" ||
            diag.phase === "export_dialog_unexpected_shape" ||
            diag.phase === "export_dialog_fill_failed"));
}
/** Run the finite export-window ladder; exported for production-path regression coverage. */
export async function tryExportLadder(deps, context, page, sendInteraction, a, accountOrdinal, accountTotal, candidateStarts, todayIso, streamState, onSessionDead) {
    // Wrap in an object so TS tracks the mutation performed by the onDiagnostics
    // closure; a bare `let lastDiag` would narrow to `null` at read sites.
    const diagBox = { current: null };
    const onDiagnostics = (info) => {
        diagBox.current = info;
    };
    for (let i = 0; i < candidateStarts.length; i += 1) {
        const sinceDate = candidateStarts[i];
        if (!sinceDate) {
            continue;
        }
        const outcome = await runSingleLadderAttempt({
            deps,
            context,
            page,
            sendInteraction,
            a,
            accountOrdinal,
            accountTotal,
            attemptOrdinal: i + 1,
            attemptTotal: candidateStarts.length,
            sinceDate,
            streamState,
            todayIso,
            onDiagnostics,
            onSessionDead,
        });
        if (outcome.kind === "session_dead") {
            return {
                csvPath: null,
                exportEmpty: false,
                usedSince: null,
                lastDiag: diagBox.current,
            };
        }
        if (outcome.kind === "success") {
            return {
                csvPath: outcome.csvPath,
                exportEmpty: false,
                usedSince: sinceDate,
                lastDiag: diagBox.current,
            };
        }
        if (outcome.kind === "empty") {
            await deps.emit({
                type: "PROGRESS",
                stream: "transactions",
                message: `Export complete: no transactions for account ${accountOrdinal}/${accountTotal}, window ${i + 1}/${candidateStarts.length}`,
            });
            return {
                csvPath: null,
                exportEmpty: true,
                usedSince: sinceDate,
                lastDiag: diagBox.current,
            };
        }
        if (outcome.kind === "structure_changed") {
            const diagNow = diagBox.current;
            if (diagNow) {
                await deps.emit({
                    type: "PROGRESS",
                    stream: "transactions",
                    message: `Export diagnostic: account ${accountOrdinal}/${accountTotal}, window ${i + 1}/${candidateStarts.length}, ${formatDiagnosticInfo(diagNow)}`,
                });
            }
            await deps.emit({
                type: "PROGRESS",
                stream: "transactions",
                message: `Export diagnostic: ${diagNow?.phase ?? "source_structure_changed"}; skipping retries for account ${accountOrdinal}/${accountTotal}`,
            });
            break;
        }
        const diagNow = diagBox.current;
        if (diagNow) {
            await deps.emit({
                type: "PROGRESS",
                stream: "transactions",
                message: `Export diagnostic: account ${accountOrdinal}/${accountTotal}, window ${i + 1}/${candidateStarts.length}, ${formatDiagnosticInfo(diagNow)}`,
            });
        }
        await deps.emit({
            type: "PROGRESS",
            stream: "transactions",
            message: `Retrying export with shorter range for account ${accountOrdinal}/${accountTotal}`,
        });
    }
    return {
        csvPath: null,
        exportEmpty: false,
        usedSince: null,
        lastDiag: diagBox.current,
    };
}
/** Parse the downloaded CSV, emit each transaction, and return parse outcome metadata. */
export async function emitCsvTransactions(deps, csvPath, a, priorLastDate, accountOrdinal, accountTotal, fingerprintCursor) {
    const text = await readFile(csvPath, "utf8");
    const rows = parseCsv(text);
    const txnAccountId = a.account_id_raw || a.last_four || "unknown";
    const txns = rowsToTransactions(rows, {
        accountId: txnAccountId,
        accountName: a.name,
        fetchedAt: nowIso(),
    });
    // A CSV that was downloaded (so not the known-empty export path) but whose
    // data rows produced zero usable transactions is a silent coverage loss:
    // parseCsv returned only a header/garbage, or every data row failed the
    // header/shape checks in rowsToTransactions. Surface a bounded SKIP_RESULT
    // by account ordinal (never the account number / last-four) so the run does
    // not look complete. The caller also refuses to advance this account's
    // transaction cursor on this outcome, so a parser fix can recover the gap.
    // `rows.length` is the raw parsed line count; we report data-row count
    // (rows beyond the header) to keep the number meaningful.
    const dataRows = Math.max(0, rows.length - 1);
    if (txns.length === 0) {
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "transactions",
            reason: dataRows > 0 ? "csv_no_usable_transactions" : "csv_no_data_rows",
            message: dataRows > 0
                ? `CSV parsed no usable transactions from ${dataRows} data row(s) for account ${accountOrdinal}/${accountTotal} (header mismatch or unparseable rows)`
                : `CSV had no data rows for account ${accountOrdinal}/${accountTotal}`,
            diagnostics: {
                account_ordinal: accountOrdinal,
                account_total: accountTotal,
                data_rows: dataRows,
            },
        });
    }
    let latest = priorLastDate;
    for (const t of txns) {
        // Gate on a per-transaction fingerprint that excludes the run-clock
        // `fetched_at`. A posted transaction's identity
        // (id = hashId(accountId|date|amount|original|#ord)) and its fields are
        // immutable, but the incremental export re-downloads an overlapping
        // date window (INCREMENTAL_OVERLAP_MS) every run and re-emits each
        // transaction with a fresh `fetched_at`. With this gate an already-seen
        // transaction whose body is byte-identical modulo `fetched_at` is
        // suppressed; a genuinely-new transaction (new id) or a real field move
        // is a fingerprint boundary and still emits.
        //
        // NOTE: transactions is a PARTIAL scan (per-account overlapping
        // windows + statement-PDF subsets), so this cursor is never
        // `dropUnseenIds()`d — pruning ids the run did not look at would drop
        // their fingerprints and re-churn them on the next overlapping window.
        if (!fingerprintCursor || fingerprintCursor.shouldEmit(t)) {
            await deps.emitRecord("transactions", t);
        }
        if (!latest || t.date > latest) {
            latest = t.date;
        }
    }
    await unlink(csvPath).catch(() => undefined);
    const dir = csvPath.replace(TEMP_DIR_PREFIX_RE, "");
    await readdir(dir)
        .then((f) => {
        if (!f.length) {
            rmSync(dir, { recursive: true, force: true });
        }
    })
        .catch(() => undefined);
    return { dataRows, latest, usableCount: txns.length };
}
/** Build the retryable DETAIL_GAP for a USAA transaction account whose CSV
 *  export failed this run — the ladder produced no download, or the CSV had
 *  data rows but none parsed usable (a headers-only CSV is NOT a gap; see
 *  `classifyCsvTransactionResult`). `record_key` is the account id — the
 *  next run's detail pass retries exactly this account. Mirrors chase's
 *  `buildAccountDetailGap` (reference_only, retryable, pending) so the
 *  runtime persists one resumable gap per failed key and the per-account
 *  coverage stays honest. */
export function buildAccountTransactionDetailGap(outcome) {
    return {
        type: "DETAIL_GAP",
        stream: "transactions",
        parent_stream: "accounts",
        record_key: outcome.accountId,
        status: "pending",
        reason: outcome.reason,
        detail_locator: {
            kind: "usaa.account",
            account_id: outcome.accountId,
        },
        retryable: true,
        reference_only: true,
        detail: { class: outcome.errorClass },
        last_error: { class: outcome.errorClass },
    };
}
/**
 * Keep only the pending USAA detail gaps on `stream` whose `detail_locator`
 * has the expected `kind` and whose `locatorField` matches `record_key` — the
 * same closed-world shape check every served-gap lookup in this connector
 * needs. The connector may recover only gaps the runtime actually served this
 * run: synthesizing an id, or accepting a foreign/malformed locator, could
 * close unrelated work. Shared by `buildServedAccountTransactionGapLookup`
 * (transactions, locator field `account_id`) and the credit-card billing
 * streams (locator field `card_id`) so the same closed-world proof isn't
 * hand-rolled per stream.
 */
function buildServedGapLookup(detailGaps, stream, locatorKind, locatorField) {
    const lookup = new Map();
    for (const gap of detailGaps) {
        if (gap.stream !== stream || gap.status !== "pending") {
            continue;
        }
        const locator = gap.detail_locator;
        if (locator?.kind !== locatorKind) {
            continue;
        }
        const key = locator[locatorField];
        const recordKey = gap.record_key;
        if (typeof key !== "string" ||
            key.length === 0 ||
            typeof recordKey !== "string" ||
            recordKey.length === 0 ||
            recordKey !== key ||
            typeof gap.gap_id !== "string" ||
            !gap.gap_id) {
            continue;
        }
        if (!lookup.has(key)) {
            lookup.set(key, gap.gap_id);
        }
    }
    return lookup;
}
/**
 * Keep only USAA account-level transaction gaps the runtime actually served
 * this run. The connector may recover only these supplied ids: synthesizing
 * one, or accepting a foreign/malformed locator, could close unrelated work.
 */
export function buildServedAccountTransactionGapLookup(detailGaps) {
    return buildServedGapLookup(detailGaps, "transactions", "usaa.account", "account_id");
}
/**
 * Keep only `statements` PDF gaps the runtime actually served this run. Locator
 * shape is `buildStatementDetailGap`'s (`usaa.statement` / `statement_id`).
 */
export function buildServedStatementGapLookup(detailGaps) {
    return buildServedGapLookup(detailGaps, "statements", "usaa.statement", "statement_id");
}
/**
 * Keep only USAA credit-card billing/stats gaps the runtime actually served
 * this run, one lookup per stream (a card's `credit_card_billing` gap and its
 * `credit_card_billing_stats` gap are independent DETAIL_GAP rows, served and
 * recovered independently — see `emitCreditCardNavFailureGaps`).
 */
export function buildServedCreditCardGapLookups(detailGaps) {
    return {
        billing: buildServedGapLookup(detailGaps, "credit_card_billing", "usaa.credit_card_billing", "card_id"),
        billingStats: buildServedGapLookup(detailGaps, "credit_card_billing_stats", "usaa.credit_card_billing_stats", "card_id"),
    };
}
/**
 * A served account gap is recovered only after this run reaches that same
 * account. `hydrated` and source-limited `no_activity` are both complete
 * account coverage; a fresh `gap` is deliberately re-deferred instead.
 */
export async function recoverServedAccountTransactionGaps(deps, outcomes) {
    const served = deps.servedAccountTransactionGaps;
    if (!served || served.size === 0) {
        return;
    }
    for (const outcome of outcomes) {
        if (outcome.kind !== "hydrated" && outcome.kind !== "no_activity") {
            continue;
        }
        const gapId = served.get(outcome.accountId);
        if (!gapId) {
            continue;
        }
        await deps.emit({
            type: "DETAIL_GAP_RECOVERED",
            reference_only: true,
            gap_id: gapId,
            stream: "transactions",
            record_key: outcome.accountId,
        });
    }
}
/**
 * Emit the per-run DETAIL_COVERAGE for the account -> transactions detail
 * fan-out, mirroring chase's `emitTransactionsDetailCoverage`. `outcomes` is
 * built from the accounts this run actually attempted (session-dead
 * cutoffs are excluded), so it is a real, honest denominator:
 *   - `required_keys`: every transaction-eligible account attempted.
 *   - `hydrated_keys`: accounts reached, including source-limited
 *     no-activity ones (won't-backfill is coverage, never a broken signal).
 *   - `gap_keys`: accounts whose export failed transiently; each also
 *     carries a pending DETAIL_GAP so the runtime's coverage invariant is
 *     satisfied and the next run retries them.
 *
 * `enumerationComplete` disambiguates the two ways `outcomes` can be empty:
 *   - `true`: the account loop ran to completion (never cut short by a
 *     session death) — zero outcomes here means the run genuinely enumerated
 *     zero transaction-eligible accounts, a real measured denominator. Emits
 *     considered: 0 / covered: 0 with empty key sets rather than staying
 *     silent, so an account with no checking/savings/credit-card accounts
 *     stays measured instead of permanently unreported.
 *   - `false`: the session died before any account was attempted (or mid-run,
 *     before this stream's denominator was fully walked) — the denominator is
 *     genuinely unknown this run, so nothing is emitted rather than inventing
 *     a zero.
 * Only emitted when transactions was requested. `state_stream: "accounts"`
 * mirrors chase: the accounts cursor commit is gated on this stream's detail
 * coverage being honestly accounted for (hydrated or a same-run DETAIL_GAP),
 * never silently advanced past an unreached account.
 */
export async function emitTransactionsDetailCoverage(deps, outcomes, enumerationComplete) {
    // A partial sweep's `outcomes` (whatever accounts were reached before a
    // session death) is never the true denominator, even when non-empty — so
    // suppress unconditionally on `!enumerationComplete`, not only when
    // `outcomes` happens to also be empty.
    if (!enumerationComplete) {
        return;
    }
    const requiredKeys = outcomes.map((o) => o.accountId);
    const hydratedKeys = outcomes
        .filter((o) => o.kind === "hydrated" || o.kind === "no_activity")
        .map((o) => o.accountId);
    const gapKeys = outcomes
        .filter((o) => o.kind === "gap")
        .map((o) => o.accountId);
    await emitDetailCoverage(deps, {
        stream: "transactions",
        stateStream: "accounts",
        requiredKeys,
        hydratedKeys,
        gapKeys,
        considered: outcomes.length,
        covered: hydratedKeys.length,
    });
}
/**
 * Classify a downloaded-and-parsed CSV into the account's per-run detail
 * outcome + cursor decision. Pure — exported so the coverage classification
 * is testable without driving the Playwright export flow. The distinction
 * that matters (`csvResult` comes straight from `emitCsvTransactions`):
 *   - `usableCount > 0`: real transactions parsed → `hydrated`; the cursor
 *     advances to the latest parsed date (or the window start).
 *   - `usableCount === 0 && dataRows === 0`: the export produced a
 *     headers-only CSV — the source genuinely had no transactions for the
 *     window. A dormant account exports exactly this every run, so it is
 *     the same source-limited answer as the explicit "nothing to export"
 *     dialog → `no_activity` (covered), NEVER a gap. Classifying it as a
 *     gap would pin a pending retryable DETAIL_GAP on a healthy dormant
 *     account forever (permanent Degraded).
 *   - `usableCount === 0 && dataRows > 0`: data rows were present but none
 *     parsed to a usable transaction (header mismatch / unparseable rows)
 *     → genuine parse trouble, a retryable `gap` so a parser fix can
 *     recover it next run. (`emitCsvTransactions` already emitted the
 *     matching `csv_no_usable_transactions` SKIP_RESULT.)
 * In both zero-usable cases `last_date` stays at the prior watermark
 * (possibly null → the caller writes no cursor entry), preserving the
 * pre-coverage behavior of never advancing the cursor on a run that parsed
 * nothing.
 */
export function classifyCsvTransactionResult(accountId, priorLastDate, usedSince, csvResult) {
    if (csvResult.usableCount > 0) {
        return {
            last_date: csvResult.latest || usedSince || null,
            outcome: { accountId, kind: "hydrated" },
        };
    }
    if (csvResult.dataRows === 0) {
        return {
            last_date: priorLastDate,
            outcome: { accountId, kind: "no_activity" },
        };
    }
    return {
        last_date: priorLastDate,
        outcome: {
            accountId,
            kind: "gap",
            reason: "temporary_unavailable",
            errorClass: "csv_no_usable_transactions",
        },
    };
}
async function processAccountTransactions(deps, context, page, sendInteraction, a, priorLastDate, sinceDateCfg, seventeenMonthsAgo, streamState, accountOrdinal, accountTotal, fingerprintCursor) {
    const accountId = a.account_id_raw || a.last_four || "unknown";
    const desiredSince = priorLastDate
        ? new Date(Date.parse(priorLastDate) - INCREMENTAL_OVERLAP_MS)
            .toISOString()
            .slice(0, 10)
        : (sinceDateCfg ?? seventeenMonthsAgo);
    const todayIso = new Date().toISOString().slice(0, 10);
    const candidateStarts = buildCandidateStarts(desiredSince);
    const { csvPath, exportEmpty, usedSince, lastDiag } = await tryExportLadder(deps, context, page, sendInteraction, a, accountOrdinal, accountTotal, candidateStarts, todayIso, streamState, () => {
        streamState.sessionDeadMidRun = true;
    });
    if (streamState.sessionDeadMidRun) {
        return null;
    }
    if (!csvPath) {
        if (exportEmpty) {
            return {
                last_date: priorLastDate || usedSince || null,
                outcome: { accountId, kind: "no_activity" },
            };
        }
        await emitExportFailure(deps, a, lastDiag);
        const errorClass = lastDiag && isFatalDiagPhase(lastDiag)
            ? "source_structure_changed"
            : "export_no_download";
        return {
            last_date: priorLastDate,
            outcome: {
                accountId,
                kind: "gap",
                reason: "temporary_unavailable",
                errorClass,
            },
        };
    }
    const csvResult = await emitCsvTransactions(deps, csvPath, a, priorLastDate, accountOrdinal, accountTotal, fingerprintCursor);
    return classifyCsvTransactionResult(accountId, priorLastDate, usedSince, csvResult);
}
async function runTransactionsStream(deps, context, page, sendInteraction, accounts, state, requested, streamState, fingerprintCursor) {
    const stream = requested.get("transactions");
    const sinceDateCfg = stream?.time_range?.since?.slice(0, 10);
    const seventeenMonthsAgo = new Date(Date.now() - BACKFILL_17MO)
        .toISOString()
        .slice(0, 10);
    const priorStateForTxns = state.transactions ?? {};
    const transactionsCursor = { ...priorStateForTxns };
    const transactionAccounts = accounts.filter((a) => TRANSACTION_ACCOUNT_TYPE_RE.test(a.account_type));
    const outcomes = [];
    for (let i = 0; i < transactionAccounts.length; i += 1) {
        const a = transactionAccounts[i];
        if (!a) {
            continue;
        }
        if (streamState.sessionDeadMidRun) {
            await deps.emit({
                type: "PROGRESS",
                stream: "transactions",
                message: `Session died mid-run; skipping remaining ${transactionAccounts.length - i} account(s)`,
            });
            break;
        }
        const accountKey = a.account_id_raw || "";
        const perAccState = priorStateForTxns[accountKey];
        const priorLastDate = perAccState?.last_date ?? null;
        const result = await processAccountTransactions(deps, context, page, sendInteraction, a, priorLastDate, sinceDateCfg, seventeenMonthsAgo, streamState, i + 1, transactionAccounts.length, fingerprintCursor);
        if (!result) {
            // Session died mid-attempt: the account was never reached, so it is
            // excluded from `outcomes` entirely (see AccountTransactionOutcome
            // doc) rather than recorded as a gap.
            continue;
        }
        outcomes.push(result.outcome);
        if (result.outcome.kind === "gap") {
            await deps.emit(buildAccountTransactionDetailGap(result.outcome));
        }
        if (result.last_date === null) {
            // No cursor advance to record this account (e.g. a gap with no
            // prior watermark) — preserve prior behavior of leaving the cursor
            // untouched rather than writing a null watermark.
            continue;
        }
        transactionsCursor[accountKey || a.last_four || "unknown"] = {
            last_date: result.last_date,
        };
        await deps.emit({
            type: "STATE",
            stream: "transactions",
            cursor: withTransactionFingerprints(transactionsCursor, fingerprintCursor),
        });
    }
    // The loop above only `break`s on a session death; reaching here without
    // one means every transaction-eligible account was attempted (including
    // the zero-eligible-accounts case, where the loop body never ran at all),
    // so the denominator this run enumerated is genuinely complete.
    await recoverServedAccountTransactionGaps(deps, outcomes);
    await emitTransactionsDetailCoverage(deps, outcomes, !streamState.sessionDeadMidRun);
    return transactionsCursor;
}
/** Attach the carried-forward per-transaction fingerprint map to the
 *  transactions STATE cursor without mutating the per-account watermark
 *  entries. `fingerprints` is a reserved sibling key (account keys are
 *  USAA account ids / last-four), read back by
 *  `readPriorTransactionFingerprints`. NOT pruned: transactions is a
 *  partial scan (see emitCsvTransactions). */
function withTransactionFingerprints(cursor, fingerprintCursor) {
    const out = { ...cursor };
    if (fingerprintCursor && fingerprintCursor.size() > 0) {
        out.fingerprints = fingerprintCursor.toState();
    }
    return out;
}
// ─── Statements stream helpers ──────────────────────────────────────────
function scrapeStatementsIndex(page) {
    return page.evaluate(() => {
        // biome-ignore-start lint/performance/useTopLevelRegex: runs in browser context (page.evaluate); module-scoped regexes in Node cannot cross the bridge.
        const WS_RE = /\s+/g;
        const t = document.querySelector("table");
        if (!t) {
            return [];
        }
        return [...t.querySelectorAll("tbody tr")].map((tr, rowIndex) => {
            const cells = [...tr.querySelectorAll("td")];
            const [c0, c1, c2] = cells;
            return {
                rowIndex,
                title: (c0?.innerText || "").replace(WS_RE, " ").trim(),
                date_delivered: (c1?.innerText || "").trim(),
                account_reference: (c2?.innerText || "").trim(),
            };
        });
    });
}
async function hydratePdfsForIndex(deps, indexRows, context) {
    const results = new Map();
    let attempts = 0;
    let successes = 0;
    try {
        const hydrated = await hydrateStatementPdfs({
            page: deps.page,
            statements: indexRows,
            capture: deps.capture ?? null,
            context,
            onProgress: ({ index, total }) => {
                attempts = index + 1;
                // Fire-and-forget: hydrateStatementPdfs signature is sync callback.
                // Swallowing the promise keeps the emit ordering best-effort; a
                // failed write would be caught by the outer try/catch on next await.
                deps
                    .emit({
                    type: "PROGRESS",
                    stream: "statements",
                    message: `Downloading statement PDF ${index + 1}/${total}`,
                })
                    .catch(() => undefined);
            },
            onSkip: ({ statement, reason, diag }) => {
                results.set(statement.rowIndex, { err: reason, diag });
                deps
                    .emit({
                    type: "SKIP_RESULT",
                    stream: "statements",
                    reason: PDF_DOWNLOAD_SKIP_REASON[reason],
                    message: `Statement PDF download skipped at row ${statement.rowIndex + 1}: ${reason}`,
                    diagnostics: diag,
                })
                    .catch(() => undefined);
            },
        });
        for (const h of hydrated) {
            successes += 1;
            results.set(h.statement.rowIndex, {
                pdfPath: h.pdfPath,
                pdfSha256: h.pdfSha256,
                content: h.content,
                buffer: h.buffer,
            });
        }
    }
    catch (err) {
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "statements",
            reason: "hydrate_crashed",
            message: "Statement PDF hydration failed; retry by runtime",
            diagnostics: failureDiagnostic("hydrate_crashed", err),
        });
    }
    return { attempts, successes, results };
}
async function processPdfStatementRow(deps, row, ok, accountById, counters, fingerprintCursor) {
    const title = row.title || "";
    if (!shouldParseStatementTitle(title)) {
        return;
    }
    const period = (row.date_delivered || "").slice(0, 7) || null;
    const acct = row.account_id ? accountById.get(row.account_id) : null;
    const accountName = acct?.name ?? row.account_reference ?? null;
    try {
        const { txns, parseMeta, reconciliation } = await parsePdfStatement({
            buffer: ok.buffer,
            accountId: row.account_id || row.account_reference || "unknown",
            accountName,
            period,
        });
        // The completeness anchor: USAA's own printed period totals say what
        // this period's transactions must sum to. Report a failed reconciliation
        // BEFORE the empty-parse early return below, because "the balance moved
        // but we parsed nothing" is exactly the case that must not slip out as a
        // bare template-unknown notice. `unavailable` is silent by design — a
        // credit-card statement prints no such summary and has no anchor to
        // fail.
        if (reconciliation.status === "mismatched") {
            counters.unreconciledStatements += 1;
            await deps.emit({
                type: "SKIP_RESULT",
                stream: "transactions",
                reason: "statement_unreconciled",
                message: `Statement period at row ${row.rowIndex + 1} does not reconcile against its own printed balances`,
                diagnostics: buildReconciliationDiagnostics(row.id, reconciliation),
            });
        }
        if (!txns.length) {
            counters.unknownTemplates += 1;
            await deps.emit({
                type: "SKIP_RESULT",
                stream: "transactions",
                reason: "pdf_template_unknown",
                message: `PDF statement parse skipped at row ${row.rowIndex + 1}: no parser matched (era=${parseMeta.era})`,
                diagnostics: buildPdfTemplateUnknownDiagnostics(row.id, parseMeta),
            });
            return;
        }
        for (const t of txns) {
            // Same per-transaction fingerprint gate as the CSV path (excludes
            // run-clock `fetched_at`). PDF and CSV hash the same logical
            // transaction to the same id, so a transaction already emitted from
            // either source is suppressed on a re-parse whose body is identical
            // modulo `fetched_at`. Re-parsing the same statement PDFs every run
            // was appending a fresh version per transaction.
            if (!fingerprintCursor || fingerprintCursor.shouldEmit({ ...t })) {
                await deps.emitRecord("transactions", { ...t });
            }
            counters.pdfTxnCount += 1;
        }
        counters.parsedStatements += 1;
    }
    catch (err) {
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "transactions",
            reason: "pdf_parse_failed",
            message: `PDF statement parse failed at row ${row.rowIndex + 1}; retry by runtime`,
            diagnostics: failureDiagnostic("pdf_parse_failed", err),
        });
    }
}
async function emitPdfStatementTransactions(deps, indexRows, hydrationResults, accounts, fingerprintCursor) {
    const accountById = new Map(accounts
        .filter((a) => Boolean(a.account_id_raw))
        .map((a) => [a.account_id_raw, a]));
    const counters = {
        pdfTxnCount: 0,
        parsedStatements: 0,
        unknownTemplates: 0,
        unreconciledStatements: 0,
    };
    for (const row of indexRows) {
        const ok = hydrationSuccess(hydrationResults.get(row.rowIndex));
        if (!ok) {
            continue;
        }
        await processPdfStatementRow(deps, row, ok, accountById, counters, fingerprintCursor);
    }
    await deps.emit({
        type: "PROGRESS",
        stream: "transactions",
        message: `PDF parse complete: ${counters.pdfTxnCount} transaction(s) across ${counters.parsedStatements} statement(s) (${counters.unknownTemplates} unknown templates, ${counters.unreconciledStatements} unreconciled)`,
    });
}
/**
 * Exported purely so its mid-run session-repair wiring is directly
 * testable with a mocked Page/BrowserContext. See
 * singleton-checkpoint-coverage-wiring.test.ts.
 *
 * Return value means "no USAA logon bounce was observed navigating this
 * stream" — NOT "the session is definitively alive." The catch block below
 * returns `true` for any non-navigation scrape error (DOM parse failure,
 * network blip mid-scrape, etc.) without re-checking `page.url()`, since
 * those are unrelated to session death. A caller relying on this value to
 * mean "confirmed alive" would be wrong in that catch path; it correctly
 * means only "not confirmed dead."
 */
export async function runStatementsStream(deps, context, sendInteraction, accounts, requested, streamState, statementsFingerprintCursor, transactionsFingerprintCursor, statementsHydrationCursor) {
    try {
        await deps.emit({
            type: "PROGRESS",
            stream: "statements",
            message: "Fetching statements index",
        });
        const nav = await gotoOrRepairSession(deps, context, deps.page, sendInteraction, "https://www.usaa.com/my/documents", { timeout: DOCUMENTS_NAV_TIMEOUT_MS }, "statements", streamState);
        if (!nav.ok) {
            await deps.emit({
                type: "SKIP_RESULT",
                stream: "statements",
                reason: "session_dead_reauth_failed",
                message: "USAA session expired mid-run and re-auth failed. Statements skipped.",
            });
            return false;
        }
        await politeDelay(DOCUMENTS_SETTLE_DELAY_MS);
        const docs = await scrapeStatementsIndex(deps.page);
        const indexRows = buildIndexRows(docs, accounts);
        await deps.emit({
            type: "PROGRESS",
            stream: "statements",
            message: `Found ${indexRows.length} statement index row(s)`,
        });
        const summary = await hydratePdfsForIndex(deps, indexRows, context);
        if (requested.has("statements")) {
            await emitStatementRecords(deps, indexRows, summary.results, summary, statementsFingerprintCursor, statementsHydrationCursor);
        }
        if (requested.has("transactions")) {
            await emitPdfStatementTransactions(deps, indexRows, summary.results, accounts, transactionsFingerprintCursor);
        }
        return true;
    }
    catch (err) {
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "statements",
            reason: "scrape_failed",
            message: "Statements scrape failed; retry by runtime",
            diagnostics: failureDiagnostic("statements_scrape_failed", err),
        });
        return true;
    }
}
// ─── Inbox stream ───────────────────────────────────────────────────────
function scrapeInboxRows(page) {
    return page.evaluate(() => {
        // biome-ignore-start lint/performance/useTopLevelRegex: runs in browser context (page.evaluate); module-scoped regexes in Node cannot cross the bridge.
        const WS_RE = /\s+/g;
        const t = document.querySelector("table");
        if (!t) {
            return [];
        }
        return [...t.querySelectorAll("tbody tr")].map((tr) => {
            const cells = [...tr.querySelectorAll("td")];
            const [c0, c1, c2] = cells;
            return {
                status: (c0?.innerText || "").replace(WS_RE, " ").trim(),
                date_short: (c1?.innerText || "").replace(WS_RE, " ").trim(),
                preview: (c2?.innerText || "").replace(WS_RE, " ").trim(),
            };
        });
    });
}
/**
 * Exported (in addition to being called from `collect()`) purely so its
 * DETAIL_COVERAGE emit-path wiring is directly testable with a mocked Page —
 * never emit coverage after a caught scrape failure, only after a
 * successful enumeration. See singleton-checkpoint-coverage.test.ts.
 *
 * Return value semantics match `runStatementsStream`: "no logon bounce was
 * observed," not "confirmed alive" — a caught non-navigation scrape error
 * also returns `true`.
 */
export async function runInboxStream(deps, context, page, sendInteraction, state, streamState) {
    try {
        await deps.emit({
            type: "PROGRESS",
            stream: "inbox_messages",
            message: "Fetching inbox",
        });
        const nav = await gotoOrRepairSession(deps, context, page, sendInteraction, "https://www.usaa.com/my/inbox", { timeout: INBOX_NAV_TIMEOUT_MS }, "inbox_messages", streamState);
        if (!nav.ok) {
            await deps.emit({
                type: "SKIP_RESULT",
                stream: "inbox_messages",
                reason: "session_dead_reauth_failed",
                message: "USAA session expired mid-run and re-auth failed. Inbox skipped.",
            });
            return false;
        }
        await politeDelay(DOCUMENTS_SETTLE_DELAY_MS);
        // Diagnostic-only DOM/ARIA/screenshot snapshot of the inbox table before
        // the fixed-position [c0,c1,c2] scrape below. Every buildInboxMessageRecord
        // failure (empty date_short) traces back to this scrape's column mapping,
        // and there was previously no captured artifact showing the real table
        // shape to confirm or correct it against. No-op unless PDPP_CAPTURE_*.
        await deps.capture
            ?.captureDom(page, "inbox-listing")
            .catch(() => undefined);
        const msgs = await scrapeInboxRows(page);
        await deps.emit({
            type: "PROGRESS",
            stream: "inbox_messages",
            message: `Found ${msgs.length} inbox row(s)`,
        });
        // Per-message fingerprint cursor (excludes the run-clock `fetched_at`).
        // The inbox page is re-scraped in full every run, so without this gate
        // each still-listed message appended a fresh version differing only in
        // `fetched_at`. A genuine read → unread / unread → read status flip is
        // a fingerprint boundary and re-emits; only a byte-identical re-scrape
        // modulo `fetched_at` is suppressed.
        const fingerprintCursor = openFingerprintCursor(state.inbox_messages, {
            excludeFromFingerprint: ["fetched_at"],
            priorFingerprints: readPriorInboxMessageFingerprints(state),
        });
        const year = new Date().getFullYear();
        const resolvedRows = [];
        for (const m of msgs) {
            const record = buildInboxMessageRecord(m, year, nowIso());
            resolvedRows.push({ resolved: record !== null });
            if (!record) {
                continue;
            }
            if (fingerprintCursor.shouldEmit(record)) {
                await deps.emitRecord("inbox_messages", record);
            }
        }
        // The inbox listing is a full scan of the inbox page: prune fingerprints
        // for messages no longer listed so a re-appearance re-emits.
        fingerprintCursor.dropUnseenIds();
        const cursor = { fetched_at: nowIso() };
        if (fingerprintCursor.size() > 0) {
            cursor.fingerprints = fingerprintCursor.toState();
        }
        await deps.emit({
            type: "STATE",
            stream: "inbox_messages",
            cursor,
        });
        // `inbox_messages` is `checkpoint_window`: a full re-scan of the inbox
        // page every run. See inbox-coverage.ts for why `covered` is an objective
        // per-row accounting rather than `msgs.length` — a row dropped for an
        // unparseable date must lower `covered` below `considered`, reading an
        // honest `partial`, not a false `complete`. `considered: 0` when the
        // inbox genuinely holds nothing is verified-empty, not unmeasured.
        const inboxCoverage = computeInboxCoverage(resolvedRows);
        await emitDetailCoverage(deps, {
            stream: "inbox_messages",
            stateStream: "inbox_messages",
            requiredKeys: [],
            hydratedKeys: [],
            considered: inboxCoverage.considered,
            covered: inboxCoverage.covered,
        });
        // Every listed row failing to resolve (covered === 0 with a nonzero
        // considered) is a structural-drift signal, not ordinary per-row noise:
        // `buildInboxMessageRecord` only drops a row for a missing/unparseable
        // `date_short`, and it is very unlikely every row on a real inbox page
        // shares that defect at once — far more likely the table's column
        // layout shifted (an inserted leading cell, or status/date/preview
        // reordered) and `date_short` is silently reading the wrong cell for
        // every row. Statements (pdf_download_timeout) and transactions
        // (export_affordance_missing) already surface this class of failure as
        // a diagnostic SKIP_RESULT; inbox previously reported only a bare
        // partial DETAIL_COVERAGE with no signal telling anyone why. This is
        // purely diagnostic — retryable, reference-only, no PII (row count only,
        // no dates/preview text) — never a hard error, and a partial (some but
        // not all rows unresolved) intentionally stays silent to avoid noise on
        // the ordinary case.
        if (inboxCoverage.considered > 0 && inboxCoverage.covered === 0) {
            await deps.emit({
                type: "SKIP_RESULT",
                stream: "inbox_messages",
                reason: "inbox_rows_unresolved",
                message: `Inbox scrape found ${inboxCoverage.considered} row(s) but none resolved into a record (likely a table structure change); retry by runtime`,
                diagnostics: { considered: inboxCoverage.considered },
            });
        }
        return true;
    }
    catch (err) {
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "inbox_messages",
            reason: "scrape_failed",
            message: "Inbox scrape failed; retry by runtime",
            diagnostics: failureDiagnostic("inbox_scrape_failed", err),
        });
        return true;
    }
}
// ─── Credit-card billing stream ─────────────────────────────────────────
function scrapeCreditCardBilling(page) {
    return page.evaluate(() => {
        const kv = {};
        const labels = [
            ...document.querySelectorAll("dt, .label, .field-label"),
        ];
        for (const el of labels) {
            const label = (el.innerText || "").trim();
            const value = (el.nextElementSibling?.innerText || "").trim();
            if (label && value && !kv[label]) {
                kv[label] = value;
            }
        }
        return kv;
    });
}
/**
 * Parse the prior `credit_card_billing` STATE cursor's `fingerprints`
 * map. Keyed by the billing record `id` (the account id, last-four, or a
 * hash of the raw text). Legacy cursors (only `{ fetched_at }`) decode to
 * an empty map, so the first post-deploy run rebuilds the map and re-emits
 * every card exactly once.
 */
export function readPriorCreditCardBillingFingerprints(state) {
    const streamState = (state.credit_card_billing ?? {});
    const raw = streamState.fingerprints;
    const out = new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
/** The credit-card boundary both streams enumerate: dashboard accounts whose
 *  type matches USAA's credit-card route. Exported so the coverage
 *  `considered`/`covered` arithmetic (`considered === covered ===
 *  creditCardAccounts(accounts).length`, including 0 when the owner holds no
 *  credit cards) is independently unit-testable without driving a live page
 *  through `runCreditCardBillingStream`'s multi-second per-card settle delay. */
export function creditCardAccounts(accounts) {
    return accounts.filter((a) => CREDIT_CARD_TYPE_RE.test(a.account_type));
}
/** Emit a retryable DETAIL_GAP for one card whose page navigation failed,
 *  on whichever of the two credit-card streams are requested this run.
 *  Mirrors the statement PDF gap pattern (statement-coverage.ts's
 *  `temporary_unavailable`) — a navigation failure is always retried on the
 *  next run, so it is recoverable, not terminal. */
async function emitCreditCardNavFailureGaps(deps, cardId, { emitEntity, emitStats, }) {
    if (emitEntity) {
        await emitDetailGap(deps, {
            stream: "credit_card_billing",
            recordKey: cardId,
            reason: "temporary_unavailable",
            locator: { kind: "usaa.credit_card_billing", card_id: cardId },
        });
    }
    if (emitStats) {
        await emitDetailGap(deps, {
            stream: "credit_card_billing_stats",
            recordKey: cardId,
            reason: "temporary_unavailable",
            locator: { kind: "usaa.credit_card_billing_stats", card_id: cardId },
        });
    }
}
/**
 * Emit `DETAIL_GAP_RECOVERED` for a successfully-navigated-and-scraped card
 * on whichever of the two credit-card streams the runtime is holding a
 * served, pending gap for. Mirrors `recoverServedAccountTransactionGaps`:
 * before this, a card gapped by a crashed/interrupted run (e.g. the
 * mid-run `runtime_error` that produced this connection's stuck
 * `credit_card_billing`/`credit_card_billing_stats` gaps) stayed `pending`
 * forever on every later successful run, because `emitCreditCardNavFailureGaps`
 * had a DETAIL_GAP emit path but no matching recovery path — the connector
 * never told the runtime "this card is fine now." Only called for cards that
 * actually reached `emitCreditCardBillingForCard` (outcome `"ok"`); a
 * navigation failure keeps the gap pending via `emitCreditCardNavFailureGaps`
 * instead.
 */
async function recoverServedCreditCardGaps(deps, cardId, served, { emitEntity, emitStats, }) {
    if (!served) {
        return;
    }
    const billingGapId = emitEntity ? served.billing.get(cardId) : undefined;
    if (billingGapId) {
        await deps.emit({
            type: "DETAIL_GAP_RECOVERED",
            reference_only: true,
            gap_id: billingGapId,
            stream: "credit_card_billing",
            record_key: cardId,
        });
    }
    const statsGapId = emitStats ? served.billingStats.get(cardId) : undefined;
    if (statsGapId) {
        await deps.emit({
            type: "DETAIL_GAP_RECOVERED",
            reference_only: true,
            gap_id: statsGapId,
            stream: "credit_card_billing_stats",
            record_key: cardId,
        });
    }
}
/** Navigate to one card's page. On any non-`ok` outcome, reports the failure
 *  as a retryable DETAIL_GAP for this card. The caller must NOT proceed to
 *  scrape on a failed navigation, since that would attribute whatever page
 *  happens to be loaded (the prior card, the dashboard, the USAA logon page,
 *  an error page) to this card's id. A logon-page bounce triggers the same
 *  one-shot-per-RUN repair-and-retry as the other USAA streams
 *  (`gotoOrRepairSession`, budgeted via `streamState`) before falling back to
 *  the gap — see `CardNavOutcome` for how the caller must react to each
 *  outcome. */
async function navigateToCardOrGap(deps, context, page, sendInteraction, a, cardId, streamState, options) {
    const url = `https://www.usaa.com${a.account_url}`;
    const navigated = await page
        .goto(url, {
        waitUntil: "domcontentloaded",
        timeout: ACCOUNT_NAV_TIMEOUT_MS,
    })
        .then(() => true)
        .catch(() => false);
    const landedOnLogon = navigated && LOGON_REDIRECT_RE.test(page.url());
    if (navigated && !landedOnLogon) {
        return "ok";
    }
    if (landedOnLogon) {
        const nav = await gotoOrRepairSession(deps, context, page, sendInteraction, url, { timeout: ACCOUNT_NAV_TIMEOUT_MS }, "credit_card_billing", streamState, 
        /* alreadyLandedOnLogon */ true);
        if (nav.ok) {
            return "ok";
        }
        await emitCreditCardNavFailureGaps(deps, cardId, options);
        return "session_dead";
    }
    await emitCreditCardNavFailureGaps(deps, cardId, options);
    return "nav_failed";
}
/** Scrape and emit one successfully-navigated card's billing detail onto
 *  whichever of the two credit-card streams are requested. Entity gate: a
 *  per-card fingerprint that excludes the run-clock `fetched_at`. After the
 *  Family-2 split the entity body carries only card identity/settings
 *  (account_id, nickname, credit_limit_cents, APRs, card_holders), so it
 *  re-emits only on a real settings change — a balance/rewards/cycle-status
 *  tick no longer versions it. The volatile per-cycle fields go to
 *  `credit_card_billing_stats`, keyed `{card_id}:{observed_on}` so same-day
 *  re-pulls are idempotent and a later day appends a new point in the
 *  series. */
async function emitCreditCardBillingForCard(deps, page, a, options) {
    const { emitEntity, emitStats, fingerprintCursor, observedOn } = options;
    await politeDelay(CC_SETTLE_DELAY_MS);
    const billing = await scrapeCreditCardBilling(page);
    if (emitEntity) {
        const rec = buildCreditCardBillingRecord(a, billing, nowIso());
        if (!fingerprintCursor || fingerprintCursor.shouldEmit(rec)) {
            await deps.emitRecord("credit_card_billing", rec);
        }
    }
    if (emitStats) {
        await deps.emitRecord("credit_card_billing_stats", buildCreditCardBillingStatsRecord(a, billing, observedOn));
    }
}
/** Exported (in addition to being called from `collect()`) purely so its
 *  DETAIL_COVERAGE emit-path wiring is directly testable with a mocked Page —
 *  never emit coverage after a caught scrape failure, only after a
 *  successful enumeration. See singleton-checkpoint-coverage.test.ts. */
export async function runCreditCardBillingStream(deps, context, page, sendInteraction, accounts, streamState, options) {
    const { emitEntity, emitStats, fingerprintCursor, observedOn } = options;
    try {
        await deps.emit({
            type: "PROGRESS",
            stream: "credit_card_billing",
            message: "Fetching credit card billing details",
        });
        const cards = creditCardAccounts(accounts);
        // Cards whose per-card page navigation failed (plain nav failure OR the
        // session died): excluded from `covered` on both streams (see
        // navigateToCardOrGap / emitCreditCardNavFailureGaps). `considered`
        // below is always the full `cards.length`, so cards never reached
        // because the loop broke early on a session death are still accounted
        // for — added to this set below, not silently dropped from the
        // denominator.
        const navFailedIds = new Set();
        for (const a of cards) {
            const cardId = creditCardId(a);
            const outcome = await navigateToCardOrGap(deps, context, page, sendInteraction, a, cardId, streamState, {
                emitEntity,
                emitStats,
            });
            if (outcome === "ok") {
                await emitCreditCardBillingForCard(deps, page, a, options);
                await recoverServedCreditCardGaps(deps, cardId, deps.servedCreditCardGaps, { emitEntity, emitStats });
                continue;
            }
            navFailedIds.add(cardId);
            if (outcome === "session_dead") {
                // The run-scoped repair budget (gotoOrRepairSession/streamState) is
                // now spent and failed: every remaining card would land on the same
                // dead logon page, not its own real card page. Gap every remaining
                // card up front (a plain `continue` would silently re-attempt a nav
                // per remaining card against a session already known dead) and stop
                // — this is the fix for the N-cards-N-logins defect: at most one
                // automated bank login attempt across the whole credit-card loop
                // (indeed across the whole run), never one per card.
                streamState.sessionDeadMidRun = true;
                for (const remaining of cards.slice(cards.indexOf(a) + 1)) {
                    navFailedIds.add(creditCardId(remaining));
                    await emitCreditCardNavFailureGaps(deps, creditCardId(remaining), {
                        emitEntity,
                        emitStats,
                    });
                }
                break;
            }
        }
        if (emitStats) {
            await deps.emit({
                type: "STATE",
                stream: "credit_card_billing_stats",
                cursor: { observed_on: observedOn, fetched_at: nowIso() },
            });
            // `credit_card_billing_stats` is `singleton_presence`, re-derived from the
            // same full credit-card-account boundary (`cards`) every run.
            // buildCreditCardBillingStatsRecord never drops a row, so every card in
            // the boundary is accounted for except one whose navigation failed this
            // run (excluded above, reported as a DETAIL_GAP instead) —
            // `considered === cards.length`, `covered === considered -
            // navFailedIds.size`, including 0/0 when the account genuinely holds no
            // credit cards (verified-empty). See the matching account_stats comment
            // in emitAccountsStream for why a bare STATE commit is not proof alone.
            await emitDetailCoverage(deps, {
                stream: "credit_card_billing_stats",
                stateStream: "credit_card_billing_stats",
                requiredKeys: [],
                hydratedKeys: [],
                considered: cards.length,
                covered: cards.length - navFailedIds.size,
            });
        }
        if (!emitEntity) {
            return;
        }
        if (!fingerprintCursor) {
            await deps.emit({
                type: "STATE",
                stream: "credit_card_billing",
                cursor: { fetched_at: nowIso() },
            });
            return;
        }
        // Credit-card billing is a full scan of the credit-card accounts: prune
        // fingerprints for cards no longer present so a re-added card re-emits.
        fingerprintCursor.dropUnseenIds();
        const cursor = { fetched_at: nowIso() };
        if (fingerprintCursor.size() > 0) {
            cursor.fingerprints = fingerprintCursor.toState();
        }
        await deps.emit({
            type: "STATE",
            stream: "credit_card_billing",
            cursor,
        });
        // `credit_card_billing` is `checkpoint_window`: a full re-scan of the
        // credit-card accounts every run. buildCreditCardBillingRecord never
        // drops a row (unlike inbox_messages' date-parse guard), so every card
        // enumerated this run is accounted for except one whose navigation
        // failed (excluded above) — `considered === cards.length`, `covered ===
        // considered - navFailedIds.size`, including 0/0 when there are no
        // credit cards (verified-empty, not unmeasured).
        await emitDetailCoverage(deps, {
            stream: "credit_card_billing",
            stateStream: "credit_card_billing",
            requiredKeys: [],
            hydratedKeys: [],
            considered: cards.length,
            covered: cards.length - navFailedIds.size,
        });
    }
    catch (err) {
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "credit_card_billing",
            reason: "scrape_failed",
            message: "Credit-card billing scrape failed; retry by runtime",
            diagnostics: failureDiagnostic("credit_card_billing_scrape_failed", err),
        });
    }
}
/** Run the `credit_card_billing` entity and/or `credit_card_billing_stats`
 *  observation streams based on the requested scope. The entity fingerprint
 *  cursor is only opened when the entity stream is requested. Extracted from
 *  `collect()` to keep that orchestrator under the cognitive-complexity
 *  budget. */
async function maybeRunCreditCardBillingStreams(deps, context, page, sendInteraction, accounts, state, requested, emittedAt, streamState) {
    const wantsCardBilling = requested.has("credit_card_billing");
    const wantsCardBillingStats = requested.has("credit_card_billing_stats");
    if (!(wantsCardBilling || wantsCardBillingStats)) {
        return;
    }
    const billingFingerprintCursor = wantsCardBilling
        ? openFingerprintCursor(state.credit_card_billing, {
            excludeFromFingerprint: ["fetched_at"],
            priorFingerprints: readPriorCreditCardBillingFingerprints(state),
        })
        : undefined;
    await runCreditCardBillingStream(deps, context, page, sendInteraction, accounts, streamState, {
        emitEntity: wantsCardBilling,
        emitStats: wantsCardBillingStats,
        fingerprintCursor: billingFingerprintCursor,
        observedOn: emittedAt.slice(0, 10),
    });
}
// ─── Connector entry point ────────────────────────────────────────────────
export const USAA_RETRYABLE_PATTERN = /ECONN|ETIMEDOUT|timeout|source_unavailable/i;
// Guarded so `import "./index.ts"` in tests doesn't spin up the runtime
// and block the Node event loop on stdin. Only fires when this module
// IS the process entry point (i.e. `tsx connectors/usaa/index.ts`).
if (isMainModule(import.meta.url)) {
    runConnector({
        name: "usaa",
        retryablePattern: USAA_RETRYABLE_PATTERN,
        validateRecord,
        auth: { kind: "env", required: ["USAA_USERNAME", "USAA_PASSWORD"] },
        browser: { profileName: "usaa" },
        async ensureSession({ assist, capture, completeAssistance, context, credentials, onCredentialSubmit, page, sendInteraction, }) {
            // Forwarding `assist`/`completeAssistance` lets the manual-login handoffs
            // self-resolve (see `ensureUsaaSession`'s `requestManualLoginRecovery`
            // calls) instead of always requiring the owner's manual "Continue
            // collection" click.
            await ensureUsaaSession({
                ...(assist ? { assist } : {}),
                capture: capture ?? null,
                ...(completeAssistance ? { completeAssistance } : {}),
                context,
                credentials,
                onCredentialSubmit,
                page,
                sendInteraction,
            });
        },
        collect: collectUsaa,
    });
}
/**
 * Orchestrate every USAA stream for one run. Exported (in addition to being
 * wired as `runConnector`'s `collect`) purely so the cross-stream
 * session-death latch/budget behavior is directly testable end-to-end with a
 * mocked Page/BrowserContext, without needing to drive `runConnector`'s CLI
 * entry point. See `singleton-checkpoint-coverage-wiring.test.ts`'s
 * `collectUsaa` block for the collect()-level proof that a statements/inbox
 * session death actually suppresses later streams (not just the per-stream
 * unit behavior already covered in `late-auth-self-heal.test.ts`).
 */
export async function collectUsaa(ctx) {
    const { state, requested, context, page, emit, emitRecord, progress, capture, sendInteraction, emittedAt, browserSurface, } = ctx;
    const deps = {
        browserSurface: browserSurfaceManagedState(browserSurface),
        capture,
        credentials: ctx.credentials,
        emit,
        emitRecord,
        servedAccountTransactionGaps: buildServedAccountTransactionGapLookup(ctx.detailGaps),
        servedCreditCardGaps: buildServedCreditCardGapLookups(ctx.detailGaps),
        servedStatementGaps: buildServedStatementGapLookup(ctx.detailGaps),
    };
    // Run-scoped state shared across every stream below, constructed
    // BEFORE the first stream (accounts) runs — see `UsaaRunState`. This
    // is both the cross-stream "session died, skip the rest" latch AND the
    // sole run-scoped budget for automated session repair, so a session
    // death detected at ANY stage (including the very first dashboard
    // load) is visible to every later stage and spends the same one-shot
    // repair budget instead of each stage/card independently attempting
    // (and, pre-fix, re-attempting) a bank login.
    const streamState = {
        sessionDeadMidRun: false,
        sessionRepairAttempted: false,
    };
    // ACCOUNTS — extract from dashboard; emit optionally based on requested.
    await progress("Extracting accounts from dashboard");
    if (capture) {
        await capture.captureDom(page, "dashboard-accounts");
    }
    const accounts = await extractAccounts(deps, context, page, sendInteraction, streamState);
    await progress(`Found ${accounts.length} account(s)`);
    await maybeRunAccountsStreams(deps, accounts, state, requested, emittedAt);
    // Per-transaction fingerprint cursor (excludes the run-clock
    // `fetched_at`). One cursor shared across BOTH transaction emit paths
    // (CSV export + PDF-statement parse) for the whole stream — record
    // ids (`hashId(accountId|date|amount|original|#ord)`) are globally
    // unique and the two paths hash the same logical transaction to the
    // same id. Only opened when transactions are requested. NOT pruned:
    // transactions is a partial scan (see emitCsvTransactions).
    const transactionsFingerprintCursor = requested.has("transactions")
        ? openFingerprintCursor(state.transactions, {
            excludeFromFingerprint: ["fetched_at"],
            priorFingerprints: readPriorTransactionFingerprints(state),
        })
        : undefined;
    // TRANSACTIONS — drive Export per account where applicable. Capture
    // the advanced per-account watermark cursor so the final transactions
    // STATE write below preserves the incremental `last_date` progress
    // (not just the fingerprint map).
    let transactionsCursorAfterCsv = state.transactions ?? {};
    if (requested.has("transactions")) {
        transactionsCursorAfterCsv = await runTransactionsStream(deps, context, page, sendInteraction, accounts, state, requested, streamState, transactionsFingerprintCursor);
    }
    // STATEMENTS — scrape /my/documents + hydrate PDFs + (optionally) parse txns.
    // Per-statement fingerprint cursor (excludes the run-clock `fetched_at`)
    // so unchanged statements stop appending a new version every run. Only
    // opened when `statements` is requested; a transactions-only run does
    // not touch the statements STATE. The PDF-statement transaction parse
    // shares the transactions fingerprint cursor.
    if ((requested.has("statements") || requested.has("transactions")) &&
        !streamState.sessionDeadMidRun) {
        const statementsFingerprintCursor = requested.has("statements")
            ? openFingerprintCursor(state.statements, {
                // Content-gated: when the record carries a positive content
                // fingerprint (pdf_text_sha256 + pdf_page_count), the blob/
                // acquisition-identity fields are excluded too, so an RC4-style
                // re-encryption re-download with unchanged content is a no-op;
                // when the content fields are absent (legacy/index-only), only
                // `fetched_at` is excluded (conservative fallback).
                resolveExcludeFromFingerprint: statementFingerprintExcludeKeys,
                priorFingerprints: readPriorStatementFingerprints(state),
            })
            : undefined;
        // Carry-forward of prior hydrated PDF pointers: seeded from the prior
        // statements STATE so a transient re-download failure re-emits the
        // prior content-addressed pointers instead of null.
        const statementsHydrationCursor = requested.has("statements")
            ? openStatementHydrationCursor(readPriorStatementHydration(state.statements))
            : undefined;
        latchSessionDead(streamState, await runStatementsStream({ ...deps, page }, context, sendInteraction, accounts, requested, streamState, statementsFingerprintCursor, transactionsFingerprintCursor, statementsHydrationCursor));
    }
    // Persist the merged per-transaction fingerprint map (CSV + PDF paths)
    // once both have run, on top of the advanced per-account watermarks.
    // The per-account STATE writes inside runTransactionsStream only saw
    // the CSV-so-far map; this final write is authoritative and carries
    // the PDF-path fingerprints forward too. NOT pruned (partial scan).
    // Skipped if the session died mid-run so we never narrow a map a
    // partial run could not fully rebuild.
    if (requested.has("transactions") &&
        !streamState.sessionDeadMidRun &&
        transactionsFingerprintCursor) {
        await emit({
            type: "STATE",
            stream: "transactions",
            cursor: withTransactionFingerprints(transactionsCursorAfterCsv, transactionsFingerprintCursor),
        });
    }
    // INBOX_MESSAGES — scrape /my/inbox.
    if (requested.has("inbox_messages") && !streamState.sessionDeadMidRun) {
        latchSessionDead(streamState, await runInboxStream(deps, context, page, sendInteraction, state, streamState));
    }
    // CREDIT_CARD_BILLING — entity (identity/settings) + optional
    // `credit_card_billing_stats` observation. See
    // `maybeRunCreditCardBillingStreams`.
    if (!streamState.sessionDeadMidRun) {
        await maybeRunCreditCardBillingStreams(deps, context, page, sendInteraction, accounts, state, requested, emittedAt, streamState);
    }
    await emitDeferredStreams(emit, requested);
    if (streamState.sessionDeadMidRun) {
        throw new Error("usaa session expired mid-run; re-run with fresh auth to complete");
    }
}
