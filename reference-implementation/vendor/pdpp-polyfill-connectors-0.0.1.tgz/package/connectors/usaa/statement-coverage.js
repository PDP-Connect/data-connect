// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { isHydrated, } from "../../src/statement-hydration-carry-forward.js";
/** The `statements` list stream is both the list and the detail-anchor: the
 *  index row IS the parent, and the PDF is its detail enrichment. */
export const STATEMENTS_STREAM = "statements";
/** Build a redacted, pending, retryable DETAIL_GAP for a statement-document row
 *  whose PDF is not present this run. Reference-only (never promoted to portable
 *  protocol). The locator carries the opaque statement id hash and a static
 *  `kind` — no title, account reference, or path. `temporary_unavailable` is
 *  the honest reason: a statement PDF download is always retried on the next
 *  run, so the gap is recoverable, not terminal. */
export function buildStatementDetailGap(id) {
    return {
        type: "DETAIL_GAP",
        stream: STATEMENTS_STREAM,
        record_key: id,
        status: "pending",
        reason: "temporary_unavailable",
        detail_locator: {
            kind: "usaa.statement",
            statement_id: id,
        },
        retryable: true,
        reference_only: true,
    };
}
/** Compute per-run statement detail coverage from the resolved rows.
 *
 *  - required_keys: statement-document candidates (`shouldParseStatementTitle`).
 *  - hydrated_keys: candidates with a present PDF artifact (`isHydrated`).
 *  - gap_keys: candidates with no artifact this run; one DETAIL_GAP each.
 *
 *  Non-statement rows (disclosures/agreements) are not candidates and never
 *  appear in any key set. The result is self-consistent for the runtime's
 *  coverage-completeness check: required === hydrated ∪ gap.
 *
 *  Duplicate ids (the same statement listed twice) are de-duplicated so the
 *  coverage key sets stay set-like; the first occurrence's hydration state wins
 *  for that id, and a later hydrated occurrence upgrades a pending gap to
 *  hydrated (a present artifact is the more honest, less-alarming outcome). */
export function computeStatementCoverage(rows) {
    const hydratedIds = new Set();
    const gapIds = new Set();
    const requiredOrder = [];
    const seen = new Set();
    for (const row of rows) {
        if (!row.isCandidate) {
            continue;
        }
        if (!seen.has(row.id)) {
            seen.add(row.id);
            requiredOrder.push(row.id);
        }
        if (isHydrated(row.pointers)) {
            hydratedIds.add(row.id);
            // A present artifact for this id supersedes a gap recorded for an
            // earlier duplicate occurrence: do not report a gap for something we
            // actually have.
            gapIds.delete(row.id);
        }
        else if (!hydratedIds.has(row.id)) {
            gapIds.add(row.id);
        }
    }
    const requiredKeys = requiredOrder;
    const hydratedKeys = requiredOrder.filter((id) => hydratedIds.has(id));
    const gapKeys = requiredOrder.filter((id) => gapIds.has(id));
    return {
        candidateCount: requiredKeys.length,
        coverage: {
            stream: STATEMENTS_STREAM,
            stateStream: STATEMENTS_STREAM,
            requiredKeys,
            hydratedKeys,
            considered: requiredKeys.length,
            covered: hydratedKeys.length,
            ...(gapKeys.length ? { gapKeys } : {}),
        },
        gaps: gapKeys.map((id) => buildStatementDetailGap(id)),
    };
}
