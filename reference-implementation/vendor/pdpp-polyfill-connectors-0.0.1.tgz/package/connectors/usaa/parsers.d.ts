import type { AccountRecord, AccountStatsRecord, BillingKv, ClosingContext, CreditCardBillingRecord, CreditCardBillingStatsRecord, DashboardAccount, InboxMessageRecord, InboxRow, ParsedStatementTxn, StatementClosing, TransactionRecord } from "./types.ts";
export declare const BACKFILL_17MO: number;
export declare const INCREMENTAL_OVERLAP_MS: number;
export declare function hashId(s: string): string;
export declare function sha256Hex(buf: Buffer | Uint8Array): string;
export declare function fileUrlForPath(p: string): string;
export declare function safeAccountSlug(rawAccountId: string | null | undefined, fallback: string | null | undefined): string;
export declare function yearMonthFromDate(isoDateStr: string | null | undefined): string;
/** CSV-path currency: "$-123.45" / "(123.45)" / "-123.45" → cents. */
export declare function currencyToCents(s: string | null | undefined): number | null;
/**
 * Statement-PDF currency: handles trailing-minus ("$10.00-" = credit) and
 * accountants' parens in addition to leading-minus.
 */
export declare function currencyToCentsFromStatement(s: string | null | undefined): number | null;
export declare function isoDate(raw: string | null | undefined): string | null;
export declare function mmddyyyy(iso: string): string;
/**
 * Extract the statement's closing month + year from PDF text.
 * Credit-card: "Statement Closing Date MM/DD/YY".
 * Modern checking: "Statement Period MM/DD/YYYY - MM/DD/YYYY" (closing side).
 */
export declare function detectStatementClosing(text: string): StatementClosing | null;
/** Back-compat: some callers still want just the year. */
export declare function detectStatementYear(text: string): number | null;
/**
 * Assign a YYYY to an MM/DD transaction date extracted from a statement,
 * using the statement's closing month to decide whether the transaction
 * falls in the closing year or the prior year.
 */
export declare function toIso(mm: string | number, dd: string | number, ctx: ClosingContext): string | null;
export declare function parseCsv(text: string): string[][];
export declare function rowsToTransactions(rows: string[][], { accountId: rowsAccountId, accountName, fetchedAt, }: {
    accountId: string;
    accountName: string | null;
    fetchedAt: string;
}): TransactionRecord[];
interface EraParseArgs {
    closing: StatementClosing;
}
/**
 * Era A/B parser: scans for table rows that start with a date, joining a
 * row's wrapped continuation lines (see `groupModernRows`) before matching.
 * Handles "MM/DD" (inherits statement year) and "MM/DD/YY" formats.
 */
export declare function parseModernCheckingEra(text: string, { closing }: EraParseArgs): ParsedStatementTxn[];
/**
 * Era C parser for credit-card statements. Credit-card tables surface
 * "Trans Date | Post Date | Description | Amount" with "MM/DD" dates and
 * amounts (trailing minus = credit) in the rightmost column.
 */
export declare function parseCreditCardEra(text: string, { closing }: EraParseArgs): ParsedStatementTxn[];
export declare function checkNumberFromDescription(description: string): string | null;
/** Stable account id shared by the entity record and the observation
 *  record so `account_stats.account_id` joins back to `accounts.id`. USAA
 *  exposes no account id on some dashboard tiles, so we fall back to a hash
 *  of the raw tile text — identical input across the two builders. */
export declare function accountId(a: DashboardAccount): string;
export declare function buildAccountRecord(a: DashboardAccount, fetchedAt: string): AccountRecord;
/**
 * Family-2 observation record for one account's balances on one UTC day.
 * Keyed `{account_id}:{observed_on}` so a same-day re-pull is idempotent
 * and a later-day pull appends a new point in the balance time series. The
 * point-in-time balance fields moved here out of `buildAccountRecord` so a
 * balance tick no longer versions the entity record.
 */
export declare function buildAccountStatsRecord(a: DashboardAccount, observedOn: string): AccountStatsRecord;
export declare function buildInboxMessageRecord(m: InboxRow, year: number, fetchedAt: string): InboxMessageRecord | null;
/** Stable credit-card id shared by the entity record and the observation
 *  record so `credit_card_billing_stats.card_id` joins back to
 *  `credit_card_billing.id`. Identical fallback chain across both builders. */
export declare function creditCardId(a: DashboardAccount): string;
export declare function buildCreditCardBillingRecord(a: DashboardAccount, billing: BillingKv, fetchedAt: string): CreditCardBillingRecord;
/**
 * Family-2 observation record for one credit card's per-cycle volatile
 * state on one UTC day. Keyed `{card_id}:{observed_on}`. Current balance,
 * available credit, accrued rewards, and the cycle billing-status flip moved
 * here out of `buildCreditCardBillingRecord` so they no longer version the
 * entity record. Stable settings (credit limit, APRs, nickname, card
 * holders) stay on the entity.
 */
export declare function buildCreditCardBillingStatsRecord(a: DashboardAccount, billing: BillingKv, observedOn: string): CreditCardBillingStatsRecord;
/** Resolve a statement-row's account reference against the dashboard accounts. */
export declare function resolveAccountIdForRef(ref: string, accounts: readonly DashboardAccount[]): string | null;
/**
 * Incremental-backfill ladder: start with the desired since-date, then fall
 * back to progressively narrower windows (5y → 2y → 1y → 3mo) if the export
 * dialog keeps failing.
 */
export declare function buildCandidateStarts(desiredSince: string, now?: number): string[];
export {};
//# sourceMappingURL=parsers.d.ts.map