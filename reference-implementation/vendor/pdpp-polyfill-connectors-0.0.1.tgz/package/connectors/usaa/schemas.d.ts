/**
 * Zod schemas for USAA stream records. Used for shape-check-before-emit
 * per docs/reference/connector-authoring-guide.md §3: records that fail the schema
 * become SKIP_RESULT events instead of RECORD events, so the RS never
 * receives data that looks right but isn't.
 *
 * Each schema asserts:
 *   - primitive types correct
 *   - lengths bounded (strings can't be the whole DOM)
 *   - currency cents are integer-in-range (positive or negative for txns;
 *     positive for balance fields)
 *   - dates are YYYY-MM-DD
 *   - no known cruft patterns ("Loading…", innerText-of-container leaks)
 *
 * Schemas intentionally accept `null` for fields that can legitimately be
 * absent (e.g. a savings account has no APR). Required fields per the
 * manifest are strictly present.
 */
import { z } from "zod";
export declare const accountSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodNullable<z.ZodString>;
    type: z.ZodNullable<z.ZodString>;
    last_four: z.ZodNullable<z.ZodString>;
    status: z.ZodNullable<z.ZodString>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const accountStatsSchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodString;
    observed_on: z.ZodString;
    balance_cents: z.ZodNullable<z.ZodNumber>;
    available_balance_cents: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const transactionSchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodString;
    account_name: z.ZodNullable<z.ZodString>;
    date: z.ZodString;
    amount: z.ZodNumber;
    currency: z.ZodString;
    description: z.ZodNullable<z.ZodString>;
    original_description: z.ZodNullable<z.ZodString>;
    category: z.ZodNullable<z.ZodString>;
    check_number: z.ZodNullable<z.ZodString>;
    balance_after_cents: z.ZodNullable<z.ZodNumber>;
    source: z.ZodString;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const statementSchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodNullable<z.ZodString>;
    title: z.ZodString;
    date_delivered: z.ZodNullable<z.ZodString>;
    account_reference: z.ZodNullable<z.ZodString>;
    document_url: z.ZodNullable<z.ZodURL>;
    pdf_path: z.ZodNullable<z.ZodString>;
    pdf_sha256: z.ZodNullable<z.ZodString>;
    pdf_text_sha256: z.ZodNullable<z.ZodString>;
    pdf_page_count: z.ZodNullable<z.ZodNumber>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const inboxMessageSchema: z.ZodObject<{
    id: z.ZodString;
    date_received: z.ZodNullable<z.ZodString>;
    status: z.ZodNullable<z.ZodString>;
    subject: z.ZodNullable<z.ZodString>;
    preview: z.ZodNullable<z.ZodString>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const creditCardBillingSchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodNullable<z.ZodString>;
    account_nickname: z.ZodNullable<z.ZodString>;
    credit_limit_cents: z.ZodNullable<z.ZodNumber>;
    annual_percent_rate: z.ZodNullable<z.ZodString>;
    cash_advance_apr: z.ZodNullable<z.ZodString>;
    card_holders: z.ZodNullable<z.ZodString>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const creditCardBillingStatsSchema: z.ZodObject<{
    id: z.ZodString;
    card_id: z.ZodString;
    account_id: z.ZodNullable<z.ZodString>;
    observed_on: z.ZodString;
    current_balance_cents: z.ZodNullable<z.ZodNumber>;
    available_credit_cents: z.ZodNullable<z.ZodNumber>;
    cash_rewards_cents: z.ZodNullable<z.ZodNumber>;
    billing_status: z.ZodNullable<z.ZodString>;
    minimum_payment_met: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map