// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * USAA statement-PDF archive + parser.
 *
 * Phase A: for each row in /my/documents, drive the "Options" kebab -> "Download"
 * menu to trigger the PDF download. Save each PDF to
 *   <connector-artifact-root>/usaa/statements/<account_id>/<YYYY-MM>-<hash>.pdf
 * and return an array of hydrated-statement records (pdf_path, pdf_sha256,
 * document_url as file://) alongside pdf bytes.
 *
 * Phase B: run each PDF through pdf-parse, split the transaction table by
 * known USAA statement templates, and emit transactions with
 *   source: "pdf_statement_<YYYY-MM>"
 * and an id hash compatible with the CSV path so rows de-dupe cleanly.
 *
 * Selector strategy (live capture deferred — see design-notes/usaa-historical-
 * coverage-gap.md). The /my/documents UI on 2026-04-19 showed a table of rows
 * with the final cell containing an "Options" control; clicking it opens a
 * small menu with a "Download" item that fires a PDF download. The selectors
 * below try several shapes in order so the first-run failure emits diagnostics
 * rather than silently broken. If all fail we fall back to opening the row
 * link (`<a>`) which USAA sometimes surfaces as a direct-PDF link.
 */
import { mkdir, stat, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { attachBodyResponseQueue, isLikelyPdfResponseBody, waitForOptionalBodyResponse, } from "../../src/browser-artifact-response.js";
import { resolveConnectorArtifactDir } from "../../src/connector-artifact-root.js";
import { attachDownloadQueue, } from "../../src/download-queue.js";
import { readPlaywrightDownloadBuffer } from "../../src/playwright-download.js";
import { extractStatementContentFingerprint, extractStatementPdfTextAndPages, } from "../../src/statement-content-fingerprint.js";
import { currencyToCentsFromStatement as _currencyFromStatement, detectStatementClosing, detectStatementYear, hashId, parseCreditCardEra, parseModernCheckingEra, fileUrlForPath as parsersFileUrlForPath, safeAccountSlug, sha256Hex, yearMonthFromDate, } from "./parsers.js";
import { reconcileStatementPeriod, } from "./statement-reconciliation.js";
// Downloaded statement PDFs are durable: emitted records carry `pdf_path` /
// `document_url` pointing at these files. They live on the deployment-owned
// artifact root, not under homedir(), which the documented single-volume
// deployment discards on container replacement. See
// src/connector-artifact-root.ts.
const STATEMENT_ROOT = resolveConnectorArtifactDir("usaa", ["statements"]).root;
// ─── Selector regexes (kept here; Node-side, not pure data) ──────────────
const OPTIONS_BUTTON_TEXT_RE = /^\s*(Options|More|\.{3})\s*$/i;
const DOWNLOAD_MENU_ITEM_RE = /download/i;
const DOWNLOAD_BUTTON_TEXT_RE = /^\s*Download( PDF)?\s*$/i;
const DOCUMENTS_PATH_RE = /\/my\/documents/;
const CHECK_NUMBER_RE = /CHECK\s*#?\s*0*(\d+)/i;
// ─── Timing constants ────────────────────────────────────────────────────
const DOWNLOAD_TIMEOUT_MS = 45_000;
const RESPONSE_FALLBACK_GRACE_MS = 3000;
const DOCUMENTS_NAV_TIMEOUT_MS = 30_000;
const DOCUMENTS_RELOAD_SETTLE_MS = 5000;
const CLICK_TIMEOUT_MS = 5000;
const OPTIONS_MENU_SETTLE_MS = 500;
const ROW_JITTER_MS = 400;
// ─── Tiny helpers ────────────────────────────────────────────────────────
function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
}
function structuralErrorClass(error) {
    return error instanceof Error ? "Error" : "unknown";
}
function structuralErrorDiagnostic(error) {
    return { error_class: structuralErrorClass(error) };
}
export function buildUsaaStatementMenuDiagnostic({ downloadCandidateCount, menuActionCount, menuItemCount, menuPresent, }) {
    return {
        menu: {
            action_count: menuActionCount,
            download_candidate_count: downloadCandidateCount,
            item_count: menuItemCount,
            present: menuPresent,
        },
    };
}
export function summarizeUsaaStatementResponseDiagnostics(diagnostics) {
    const sourceCounts = { cdp: 0, playwright: 0 };
    for (const candidate of diagnostics.candidates) {
        sourceCounts[candidate.source] += 1;
    }
    return {
        response: {
            body_error_count: diagnostics.candidates.filter((candidate) => candidate.reason === "body_error").length,
            candidate_count: diagnostics.candidates.length,
            cdp_error: diagnostics.cdpError !== null,
            cdp_ready: diagnostics.cdpReady,
            matched_count: diagnostics.candidates.filter((candidate) => candidate.reason === "matched").length,
            source_counts: sourceCounts,
            status_codes: [
                ...new Set(diagnostics.candidates.map((candidate) => candidate.status)),
            ]
                .filter((status) => Number.isInteger(status))
                .slice(0, 8),
        },
    };
}
function attachPdfResponseQueue(page) {
    return attachBodyResponseQueue(page, {
        isExpectedBody: isLikelyPdfResponseBody,
        shouldInspect(headers) {
            const contentDisposition = headers["content-disposition"]?.toLowerCase() ?? "";
            const contentType = headers["content-type"]?.toLowerCase() ?? "";
            return (contentType.includes("pdf") ||
                contentDisposition.includes(".pdf") ||
                contentDisposition.includes("attachment"));
        },
    });
}
// ─── Download orchestration ──────────────────────────────────────────────
/**
 * Diagnostic-only instrumentation for the `pdf_download_timeout` hypothesis:
 * the Download menuitem may open a NEW page/tab that `attachDownloadQueue`
 * (page-scoped, see download-queue.ts:14-24) and `attachPdfResponseQueue`
 * cannot see. `context.on('page', ...)` fires for every new page/popup
 * created anywhere in the context, regardless of which page's click
 * triggered it — this is the direct, minimal way to confirm or rule out the
 * hypothesis from a single captured run, without guessing from a trace's
 * screenshot timeline. Best-effort and capture-gated: throws never reach the
 * caller, and with no CaptureSession this records nothing and costs nothing.
 */
function attachNewPageWatcher(context, capture, labelPrefix) {
    if (!(context && capture)) {
        return { detach: () => undefined };
    }
    let seq = 0;
    const onPage = (newPage) => {
        seq += 1;
        const label = `${labelPrefix}-new-page-${seq}`;
        // Fire-and-forget: a popup page can be short-lived (e.g. a PDF viewer
        // tab that immediately triggers its own download and closes), so this
        // must not block the click/consume race in the caller.
        capture.captureDom(newPage, label).catch(() => undefined);
        process.stderr.write(`[usaa-statements] new page/popup observed during ${labelPrefix}: url=${newPage.url()} label=${label}\n`);
    };
    context.on("page", onPage);
    return {
        detach() {
            context.off("page", onPage);
        },
    };
}
/**
 * Locate the per-row "Options" trigger. USAA's documents table renders as a
 * standard <table> with the trailing cell containing either a button labeled
 * "Options" / "..." or an icon-only button with aria-label containing
 * "Options" or "More". Try each in order; the first match wins.
 */
async function locateRowOptionsButton(row) {
    const candidates = [
        row
            .locator('button[aria-label*="Options" i], button[aria-label*="More" i]')
            .first(),
        row
            .locator('[role="button"][aria-label*="Options" i], [role="button"][aria-label*="More" i]')
            .first(),
        row.locator("button", { hasText: OPTIONS_BUTTON_TEXT_RE }).first(),
        // Icon-only kebab: last button in the last cell.
        row.locator("td").last().locator('button, [role="button"]').last(),
    ];
    for (const c of candidates) {
        if (await c.count().catch(() => 0)) {
            return c;
        }
    }
    return null;
}
/**
 * Locate the "Download" / "Download PDF" menu item in an open menu. Menus
 * on USAA's SPA are usually `[role="menu"]` with `[role="menuitem"]`
 * children, but some legacy components use plain buttons/links. Try each.
 */
async function locateDownloadMenuItem(page) {
    const candidates = [
        page
            .locator('[role="menuitem"]', { hasText: DOWNLOAD_MENU_ITEM_RE })
            .first(),
        page
            .locator('[role="menu"] a, [role="menu"] button', {
            hasText: DOWNLOAD_MENU_ITEM_RE,
        })
            .first(),
        page
            .locator("a, button")
            .filter({ hasText: DOWNLOAD_BUTTON_TEXT_RE })
            .first(),
    ];
    for (const c of candidates) {
        if (await c.count().catch(() => 0)) {
            return c;
        }
    }
    return null;
}
async function consumeDownloadOrResponse({ downloadQueue, responseQueue, }) {
    const responsePromise = responseQueue.waitForNextResponse({
        timeoutMs: DOWNLOAD_TIMEOUT_MS,
    });
    const downloadPromise = downloadQueue.waitForNextDownload({
        timeoutMs: DOWNLOAD_TIMEOUT_MS,
    });
    try {
        const result = await Promise.any([
            responsePromise.then((raceResponse) => ({
                kind: "response",
                response: raceResponse,
            })),
            downloadPromise.then((raceDownload) => ({
                download: raceDownload,
                kind: "download",
            })),
        ]);
        if (result.kind === "response") {
            return {
                buffer: result.response.body,
                suggestedFilename: result.response.suggestedFilename || "statement.pdf",
            };
        }
        try {
            const buffer = await readPlaywrightDownloadBuffer(result.download);
            if (buffer.length > 0) {
                return {
                    buffer,
                    suggestedFilename: result.download.suggestedFilename(),
                };
            }
        }
        catch (err) {
            const response = await waitForOptionalBodyResponse(responsePromise, RESPONSE_FALLBACK_GRACE_MS);
            if (response) {
                return {
                    buffer: response.body,
                    diag: {
                        bytes: response.body.length,
                        error_class: structuralErrorClass(err),
                        response_source: response.source,
                    },
                    suggestedFilename: response.suggestedFilename || result.download.suggestedFilename(),
                };
            }
            throw err;
        }
        const response = await waitForOptionalBodyResponse(responsePromise, RESPONSE_FALLBACK_GRACE_MS);
        if (response) {
            return {
                buffer: response.body,
                diag: {
                    bytes: response.body.length,
                    download_empty: true,
                    response_source: response.source,
                },
                suggestedFilename: response.suggestedFilename || result.download.suggestedFilename(),
            };
        }
        return null;
    }
    catch (err) {
        return {
            buffer: Buffer.alloc(0),
            diag: {
                error_class: structuralErrorClass(err),
                response: summarizeUsaaStatementResponseDiagnostics(responseQueue.diagnostics()).response,
            },
            suggestedFilename: "statement.pdf",
        };
    }
}
/** Fallback path: the row has a direct <a href="*.pdf"> link. */
async function downloadViaDirectLink(page, row) {
    const link = row.locator('a[href$=".pdf"], a[href*=".pdf?"]').first();
    if (!(await link.count().catch(() => 0))) {
        return null;
    }
    const downloadQueue = attachDownloadQueue(page);
    const responseQueue = attachPdfResponseQueue(page);
    await responseQueue.ready;
    try {
        await link.click({ timeout: CLICK_TIMEOUT_MS }).catch(() => {
            /* ignore */
        });
        const result = await consumeDownloadOrResponse({
            downloadQueue,
            responseQueue,
        });
        if (!result) {
            return { ok: false, reason: "download_empty" };
        }
        if (result.buffer.length === 0) {
            return {
                ok: false,
                reason: "download_timeout",
                diag: result.diag ?? null,
            };
        }
        return {
            ok: true,
            buffer: result.buffer,
            suggestedFilename: result.suggestedFilename,
        };
    }
    catch (err) {
        return {
            ok: false,
            reason: "direct_link_failed",
            diag: structuralErrorDiagnostic(err),
        };
    }
    finally {
        downloadQueue.detach();
        responseQueue.detach();
    }
}
/** Open the per-row Options menu. Returns the DownloadResult on failure, null on success. */
async function openOptionsMenu(optBtn) {
    try {
        await optBtn.click({ timeout: CLICK_TIMEOUT_MS });
        return null;
    }
    catch (err) {
        return {
            ok: false,
            reason: "options_click_failed",
            diag: structuralErrorDiagnostic(err),
        };
    }
}
/** Capture structural menu facts + dismiss the menu when no Download menuitem was found. */
async function noDownloadMenuitemFailure(page) {
    const menuCount = await page
        .locator('[role="menu"]')
        .count()
        .catch(() => 0);
    const menuItemCount = await page
        .locator('[role="menu"] [role="menuitem"]')
        .count()
        .catch(() => 0);
    const menuActionCount = await page
        .locator('[role="menu"] a, [role="menu"] button')
        .count()
        .catch(() => 0);
    const downloadCandidateCount = await page
        .locator('[role="menu"] [role="menuitem"], [role="menu"] a, [role="menu"] button')
        .filter({ hasText: DOWNLOAD_MENU_ITEM_RE })
        .count()
        .catch(() => 0);
    await page.keyboard.press("Escape").catch(() => {
        /* ignore */
    });
    return {
        ok: false,
        reason: "no_download_menuitem",
        diag: buildUsaaStatementMenuDiagnostic({
            downloadCandidateCount,
            menuActionCount,
            menuItemCount,
            menuPresent: menuCount > 0,
        }),
    };
}
/** Click the Download menuitem and consume the resulting download. */
async function clickDownloadAndConsume(page, dlItem, diagCapture) {
    const downloadQueue = attachDownloadQueue(page);
    const responseQueue = attachPdfResponseQueue(page);
    await responseQueue.ready;
    // Diagnostic-only: DOM snapshot immediately before the click that is
    // hypothesized to open a page the page-scoped download/response queues
    // above cannot observe. Paired with attachNewPageWatcher (armed by the
    // caller for the whole batch) this is the direct evidence for whether
    // the Download menuitem opens a new page/tab. No-op without capture.
    if (diagCapture?.capture) {
        await diagCapture.capture
            .captureDom(page, `${diagCapture.label}-pre-click`)
            .catch(() => undefined);
    }
    try {
        await dlItem.click({ timeout: CLICK_TIMEOUT_MS });
    }
    catch (err) {
        downloadQueue.detach();
        responseQueue.detach();
        await page.keyboard.press("Escape").catch(() => {
            /* ignore */
        });
        return {
            ok: false,
            reason: "download_click_failed",
            diag: structuralErrorDiagnostic(err),
        };
    }
    try {
        const result = await consumeDownloadOrResponse({
            downloadQueue,
            responseQueue,
        });
        await page.keyboard.press("Escape").catch(() => {
            /* ignore */
        });
        if (!result) {
            return { ok: false, reason: "download_empty" };
        }
        if (result.buffer.length === 0) {
            return {
                ok: false,
                reason: "download_timeout",
                diag: result.diag ?? null,
            };
        }
        return {
            ok: true,
            buffer: result.buffer,
            suggestedFilename: result.suggestedFilename,
        };
    }
    catch (err) {
        await page.keyboard.press("Escape").catch(() => {
            /* ignore */
        });
        return {
            ok: false,
            reason: "download_timeout",
            diag: structuralErrorDiagnostic(err),
        };
    }
    finally {
        downloadQueue.detach();
        responseQueue.detach();
    }
}
/**
 * Drive a single statement row to capture its PDF. Returns
 *   { ok: true, buffer, suggestedFilename } on success
 *   { ok: false, reason, diag }            on failure
 */
async function downloadStatementFromRow({ page, rowIndex, capture, captureLabel, }) {
    const row = page.locator("tbody tr").nth(rowIndex);
    if (!(await row.count().catch(() => 0))) {
        return { ok: false, reason: "row_missing" };
    }
    const optBtn = await locateRowOptionsButton(row);
    if (!optBtn) {
        const direct = await downloadViaDirectLink(page, row);
        return direct ?? { ok: false, reason: "no_options_affordance" };
    }
    const openErr = await openOptionsMenu(optBtn);
    if (openErr) {
        return openErr;
    }
    await sleep(OPTIONS_MENU_SETTLE_MS);
    const dlItem = await locateDownloadMenuItem(page);
    if (!dlItem) {
        return await noDownloadMenuitemFailure(page);
    }
    return await clickDownloadAndConsume(page, dlItem, captureLabel ? { capture, label: captureLabel } : undefined);
}
/**
 * Persist a PDF to disk at ~/.pdpp/usaa-statements/<account_slug>/<YYYY-MM>-<sha8>.pdf.
 * Skips rewriting if the file already exists with the same content hash.
 * Returns { pdfPath, pdfSha256 }.
 */
async function persistPdf({ buffer, accountId, dateDelivered, }) {
    const pdfSha256 = sha256Hex(buffer);
    const slug = safeAccountSlug(accountId, "unknown");
    const dir = join(STATEMENT_ROOT, slug);
    await mkdir(dir, { recursive: true });
    const ym = yearMonthFromDate(dateDelivered);
    const pdfPath = join(dir, `${ym}-${pdfSha256.slice(0, 16)}.pdf`);
    // Re-write is a cheap idempotency guarantee; skip if already at same size.
    const existing = await stat(pdfPath).catch(() => null);
    if (!existing || existing.size !== buffer.length) {
        await writeFile(pdfPath, buffer);
    }
    return { pdfPath, pdfSha256 };
}
/** Defensively (re-)navigate to /my/documents if we're not already there. */
async function ensureOnDocumentsPage(page) {
    if (DOCUMENTS_PATH_RE.test(page.url())) {
        return;
    }
    await page
        .goto("https://www.usaa.com/my/documents", {
        waitUntil: "domcontentloaded",
        timeout: DOCUMENTS_NAV_TIMEOUT_MS,
    })
        .catch(() => {
        /* ignore */
    });
    await sleep(DOCUMENTS_RELOAD_SETTLE_MS);
}
/** Persist a single downloaded PDF and append to the hydrated list. */
async function persistHydratedStatement(statement, download, hydrated, onSkip) {
    try {
        const { pdfPath, pdfSha256 } = await persistPdf({
            buffer: download.buffer,
            accountId: statement.account_id,
            dateDelivered: statement.date_delivered,
        });
        hydrated.push({
            statement,
            pdfPath,
            pdfSha256,
            content: await extractStatementContentFingerprint(download.buffer),
            buffer: download.buffer,
            suggestedFilename: download.suggestedFilename,
        });
    }
    catch (err) {
        if (onSkip) {
            onSkip({
                statement,
                reason: "persist_failed",
                diag: structuralErrorDiagnostic(err),
            });
        }
    }
}
/** Handle one statement row: download, persist, emit callbacks. */
async function hydrateOneStatement(page, statement, total, hydrated, { onProgress, onSkip }, capture) {
    if (onProgress) {
        onProgress({
            index: statement.rowIndex,
            total,
            title: statement.title,
        });
    }
    const result = await downloadStatementFromRow({
        page,
        rowIndex: statement.rowIndex,
        capture,
        captureLabel: capture
            ? `statement-download-row-${statement.rowIndex}`
            : undefined,
    });
    if (!result.ok) {
        if (onSkip) {
            onSkip({
                statement,
                reason: result.reason,
                diag: result.diag ?? null,
            });
        }
        return;
    }
    await persistHydratedStatement(statement, result, hydrated, onSkip);
}
/**
 * Hydrate every row in the currently-loaded /my/documents table. Callers
 * pass `onRecord({ index, statement, result })` to react per-row as we go
 * (so the main connector can emit hydrated statement records incrementally
 * and still make progress if the page/session dies partway through).
 *
 * Returns an array of { statement, pdfPath, pdfSha256, buffer } for every
 * successful download, and emits SKIP-equivalent diagnostics via onSkip
 * for rows that failed.
 */
export async function hydrateStatementPdfs({ page, statements, onProgress, onSkip, context, capture, }) {
    const hydrated = [];
    if (!statements.length) {
        return hydrated;
    }
    await ensureOnDocumentsPage(page);
    const newPageWatcher = attachNewPageWatcher(context, capture, "statement-hydration");
    try {
        for (const s of statements) {
            await hydrateOneStatement(page, s, statements.length, hydrated, {
                onProgress,
                onSkip,
            }, capture);
            // Small jitter between rows so we don't visibly hammer USAA's SPA.
            await sleep(ROW_JITTER_MS);
        }
    }
    finally {
        newPageWatcher.detach();
    }
    return hydrated;
}
export function fileUrlForPath(p) {
    return parsersFileUrlForPath(p);
}
// ─── Phase B: PDF -> transactions ─────────────────────────────────────────
/**
 * USAA statement PDFs have shifted formats over time. Known eras:
 *
 * Era A ("modern", ~2022-present):
 *   - Columns: Date | Description | Amount | Balance
 *   - Dates formatted "MM/DD" or "MM/DD/YY"
 *   - Transactions section titled "TRANSACTIONS" or "Account Activity"
 *
 * Era B ("legacy", ~2015-2022):
 *   - Similar column layout but with "Posting Date / Description / Amount"
 *   - May wrap long descriptions across two lines
 *
 * Era C ("credit card"):
 *   - Columns: Trans Date | Post Date | Description | Amount
 *   - Section "Transactions" per card-holder
 *
 * We try each parser in order. If none match we emit a structural SKIP_RESULT
 * with the parser era and statement year; raw statement text never enters the
 * durable diagnostic payload.
 */
// Statement text extraction reuses the shared `pdf-parse` path so the USAA
// transaction-splitting parse and the content fingerprint hash identically and
// no second PDF library is introduced.
async function extractPdfText(buffer) {
    return (await extractStatementPdfTextAndPages(buffer)).text;
}
/**
 * Determine the statement's closing context: prefer the in-PDF closing date,
 * then the period supplied by the statement index (YYYY-MM), then current
 * year as last resort.
 */
function resolveClosing(text, period) {
    const fromText = detectStatementClosing(text);
    if (fromText) {
        return fromText;
    }
    if (period) {
        const [y, m] = period.split("-").map(Number);
        if (y && m) {
            return { closingYear: y, closingMonth: m };
        }
    }
    return { closingYear: new Date().getFullYear(), closingMonth: 12 };
}
/** Try each era parser; keep the one that produced the most transactions. */
function runEraParsers(text, closing) {
    const attempts = [
        { era: "modern_checking", fn: parseModernCheckingEra },
        { era: "credit_card", fn: parseCreditCardEra },
    ];
    let chosen = null;
    let best = [];
    for (const a of attempts) {
        const txns = a.fn(text, { closing });
        if (txns.length > best.length) {
            best = txns;
            chosen = a.era;
        }
    }
    return { chosen, best };
}
/** Shape parsed transactions into emitted records, hashing ids compatibly with CSV path. */
function buildStatementRecords(best, { accountId, accountName, period, }) {
    const nowIso = new Date().toISOString();
    const provenance = `pdf_statement_${period || "unknown"}`;
    return best.map((t) => ({
        // Hash input is intentionally identical in shape to the CSV path so
        // the same logical transaction from both sources collapses to the same
        // id on ingest. See rowsToTransactions in parsers.ts.
        id: hashId(`${accountId}|${t.tupleKey}|#${t.ord}`),
        account_id: accountId,
        account_name: accountName,
        date: t.iso,
        description: t.description,
        original_description: t.description,
        category: null,
        amount: t.amount,
        currency: "USD",
        balance_after_cents: t.balance,
        check_number: (t.description.match(CHECK_NUMBER_RE) || [])[1] || null,
        source: provenance,
        fetched_at: nowIso,
    }));
}
/**
 * Parse one statement PDF's bytes into transaction records. Caller supplies
 *   accountId, accountName, period (YYYY-MM for provenance), originalDescription
 *   fallback.
 *
 * Returns { txns: Array<TxnRecord>, parseMeta: { era, year } }.
 * When no parser matches, txns is [] and parseMeta.era === "unknown"; the
 * connector surfaces a bounded structural SKIP_RESULT without statement text.
 */
export async function parsePdfStatement({ buffer, accountId, accountName, period, }) {
    const text = await extractPdfText(buffer);
    const closing = resolveClosing(text, period);
    const { chosen, best } = runEraParsers(text, closing);
    // The completeness anchor. Computed here because this is the only place
    // that holds BOTH the statement text (USAA's printed period totals) and
    // the transactions parsed from it. It is deliberately computed even when
    // no parser matched: a period whose balance moved but which yielded zero
    // transactions is precisely the failure worth catching, and returning
    // early without checking would hide it.
    const reconciliation = reconcileStatementPeriod(text, best);
    if (!best.length) {
        return {
            txns: [],
            parseMeta: {
                era: "unknown",
                year: closing.closingYear,
            },
            reconciliation,
        };
    }
    const records = buildStatementRecords(best, {
        accountId,
        accountName,
        period,
    });
    return {
        txns: records,
        parseMeta: {
            era: chosen ?? "unknown",
            year: closing.closingYear,
            closingMonth: closing.closingMonth,
        },
        reconciliation,
    };
}
// Exposed for introspection / tests.
export const _internals = {
    parseModernCheckingEra,
    parseCreditCardEra,
    detectStatementYear,
    currencyToCentsFromStatement: _currencyFromStatement,
    STATEMENT_ROOT,
};
