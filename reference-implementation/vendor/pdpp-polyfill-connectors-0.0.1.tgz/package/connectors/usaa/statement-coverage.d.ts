import type { DetailCoverageParams, DetailGapMessage } from "../../src/connector-runtime.ts";
import { type StatementHydration } from "../../src/statement-hydration-carry-forward.ts";
/** The `statements` list stream is both the list and the detail-anchor: the
 *  index row IS the parent, and the PDF is its detail enrichment. */
export declare const STATEMENTS_STREAM = "statements";
/** One row's resolved hydration outcome, as `emitStatementRecords` already
 *  computes it. `pointers` is the body the record carries (fresh, carried, or
 *  all-null); `isHydrated(pointers)` decides artifact-present. `isCandidate` is
 *  the caller's statement-document decision (`shouldParseStatementTitle`) —
 *  passed in so this module stays a pure, dependency-free leaf and never forms
 *  an import cycle with the connector's `index.ts`. */
export interface StatementCoverageRow {
    id: string;
    isCandidate: boolean;
    pointers: StatementHydration;
}
/** The coverage decision for a run: the params for one DETAIL_COVERAGE plus the
 *  redacted DETAIL_GAP messages to emit (one per gap candidate) before it.
 *  `candidateCount === 0` means the run saw no statement-document rows — the
 *  caller still emits the resulting `considered: 0` / `covered: 0` coverage
 *  (as long as enumeration itself completed) so a steady-state zero-candidate
 *  run stays measured rather than silently unreported. */
export interface StatementCoverageResult {
    candidateCount: number;
    coverage: DetailCoverageParams;
    gaps: DetailGapMessage[];
}
/** Build a redacted, pending, retryable DETAIL_GAP for a statement-document row
 *  whose PDF is not present this run. Reference-only (never promoted to portable
 *  protocol). The locator carries the opaque statement id hash and a static
 *  `kind` — no title, account reference, or path. `temporary_unavailable` is
 *  the honest reason: a statement PDF download is always retried on the next
 *  run, so the gap is recoverable, not terminal. */
export declare function buildStatementDetailGap(id: string): DetailGapMessage;
/** Compute per-run statement detail coverage from the resolved rows.
 *
 *  - required_keys: statement-document candidates (`shouldParseStatementTitle`).
 *  - hydrated_keys: candidates with a present PDF artifact (`isHydrated`).
 *  - gap_keys: candidates with no artifact this run; one DETAIL_GAP each.
 *
 *  Non-statement rows (disclosures/agreements) are not candidates and never
 *  appear in any key set. The result is self-consistent for the runtime's
 *  coverage-completeness check: required === hydrated ∪ gap.
 *
 *  Duplicate ids (the same statement listed twice) are de-duplicated so the
 *  coverage key sets stay set-like; the first occurrence's hydration state wins
 *  for that id, and a later hydrated occurrence upgrades a pending gap to
 *  hydrated (a present artifact is the more honest, less-alarming outcome). */
export declare function computeStatementCoverage(rows: readonly StatementCoverageRow[]): StatementCoverageResult;
//# sourceMappingURL=statement-coverage.d.ts.map