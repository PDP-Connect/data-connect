import type { ParsedStatementTxn } from "./types.ts";
/**
 * True when a parsed statement line is one of USAA's own summary rows rather
 * than a transaction.
 *
 * This exists because USAA's checking-era table prints the period summary as
 * a row that is shaped exactly like a transaction:
 *
 *     02/04 Ending Balance -- -- $33,821.48
 *
 * A line-oriented transaction regex matches it and stores the closing
 * BALANCE as if it were a transaction AMOUNT. Live evidence: 14 such rows
 * were emitted into this owner's `transactions` stream, the most recent of
 * them three days before this guard was written, with amounts up to
 * $52,334.41 that never happened.
 *
 * Matching is on the description only and is anchored at the start, so a
 * genuine merchant transaction that happens to contain these words later in
 * its description is unaffected.
 */
export declare function isStatementSummaryDescription(description: string): boolean;
/** Parse "$33,821.48" / "-$8.65" into signed integer cents. Returns null for
 *  anything that is not a well-formed currency token, so a malformed summary
 *  line yields "no anchor" rather than a wrong one. */
export declare function currencyToCents(raw: string): number | null;
/** USAA's own period totals for one statement, in signed cents. */
export interface PeriodBalances {
    beginningCents: number;
    endingCents: number;
}
/**
 * Read the statement's Beginning/Ending Balance summary from PDF text.
 *
 * Fails closed by returning `null`: a statement era that prints no such
 * summary (the credit-card era) or a statement whose summary is malformed
 * has NO anchor, and this module says so rather than substituting a number
 * it derived from the transactions — which would make the reconciliation
 * check compare the transactions against themselves and pass vacuously.
 *
 * Both values must be present and well-formed; one without the other proves
 * nothing about a period.
 */
export declare function extractPeriodBalances(text: string): PeriodBalances | null;
/**
 * The outcome of reconciling one statement period.
 *
 * `unavailable` is a first-class, non-alarming outcome: it means the period
 * offers no sound anchor (no summary balances printed). It is deliberately
 * NOT `reconciled: false`, because "cannot check" and "checked and wrong"
 * are different facts and collapsing them would either hide a real defect or
 * cry wolf on every credit-card statement.
 */
export type StatementReconciliation = {
    status: "unavailable";
    reason: "no_period_balances";
} | {
    status: "reconciled";
    beginningCents: number;
    endingCents: number;
    expectedDeltaCents: number;
    observedDeltaCents: number;
} | {
    status: "mismatched";
    beginningCents: number;
    endingCents: number;
    expectedDeltaCents: number;
    observedDeltaCents: number;
    differenceCents: number;
};
/**
 * Reconcile one statement period's parsed transactions against USAA's own
 * printed period totals.
 *
 * The identity checked is:
 *
 *     ending − beginning == Σ(amounts)
 *
 * Summary rows are excluded from the sum via
 * `isStatementSummaryDescription`; including them would add the closing
 * balance to the transaction sum and break the identity on every statement.
 *
 * A zero-transaction period is NOT auto-passed: a statement whose balance
 * moved but whose table yielded no transactions is exactly the multi-line
 * parse failure this owner's data exhibits, and it must surface as
 * `mismatched`. The identity handles that correctly with no special case —
 * an empty sum reconciles only when the balance genuinely did not move.
 */
export declare function reconcileStatementPeriod(text: string, txns: readonly ParsedStatementTxn[]): StatementReconciliation;
/**
 * Build the redacted diagnostic payload for a failed reconciliation.
 *
 * Only integers and the opaque statement id hash leave this function — never
 * a merchant description, account number, or account name. The balances
 * themselves ARE dollar figures for this owner's account, and they are the
 * whole point of the finding, so they are reported; the PII rule this
 * project enforces is about names and free text, and the `message` carries
 * no account identity at all.
 */
export declare function buildReconciliationDiagnostics(statementId: string, result: Extract<StatementReconciliation, {
    status: "mismatched";
}>): Record<string, unknown>;
//# sourceMappingURL=statement-reconciliation.d.ts.map