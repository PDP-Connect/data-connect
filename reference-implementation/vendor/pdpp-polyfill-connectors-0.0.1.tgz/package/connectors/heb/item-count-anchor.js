// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Validate a provider-declared item count.
 *
 * Fails closed to `null` — a malformed count is NOT zero and NOT complete.
 * Mirrors jellyfin's `validateTotalRecordCount` discipline, minus its
 * monotonicity rule: H-E-B legitimately restates an order's count downward
 * after a refund, so a decrease is ordinary source behaviour here rather
 * than the anomaly it is for a Jellyfin library.
 */
export function validateDeclaredItemCount(value) {
    if (typeof value !== "number") {
        return null;
    }
    if (!Number.isFinite(value)) {
        return null;
    }
    if (!Number.isInteger(value)) {
        return null;
    }
    if (value < 0) {
        return null;
    }
    return value;
}
/**
 * Compare one order's declared count against what was collected.
 *
 * A declared zero is a real fact (an order genuinely holding no line items),
 * so it is honoured rather than treated as "unknown" — this is the same
 * distinction the fleet draws elsewhere between the provider SAYING zero and
 * the provider saying nothing.
 */
export function tallyOrderItems(tally) {
    const declared = validateDeclaredItemCount(tally.declaredItemCount);
    if (declared === null) {
        return {
            status: "unavailable",
            orderId: tally.orderId,
            reason: "no_declared_count",
        };
    }
    const covered = Math.min(tally.collectedItemCount, declared);
    if (covered < declared) {
        return {
            status: "short",
            orderId: tally.orderId,
            considered: declared,
            covered,
            missing: declared - covered,
        };
    }
    return {
        status: "complete",
        orderId: tally.orderId,
        considered: declared,
        covered,
    };
}
/** Cap on ids listed in the diagnostic. The COUNT is always exact; only the
 *  id sample is bounded, so a large shortfall stays legible without an
 *  unbounded diagnostic. Mirrors signal's and slack's id-sample caps. */
export const MAX_SHORT_ORDER_IDS_IN_DIAGNOSTIC = 50;
/**
 * Roll per-order verdicts into one run-level summary.
 *
 * `unavailable` orders contribute to neither total: including an order with
 * no declared count would silently treat its collected items as if they had
 * been verified against something.
 */
export function summarizeItemCounts(tallies) {
    const summary = {
        complete: 0,
        short: 0,
        unavailable: 0,
        declaredItems: 0,
        collectedItems: 0,
        shortOrderIds: [],
    };
    for (const tally of tallies) {
        const verdict = tallyOrderItems(tally);
        if (verdict.status === "unavailable") {
            summary.unavailable += 1;
            continue;
        }
        summary.declaredItems += verdict.considered;
        summary.collectedItems += verdict.covered;
        if (verdict.status === "short") {
            summary.short += 1;
            if (summary.shortOrderIds.length < MAX_SHORT_ORDER_IDS_IN_DIAGNOSTIC) {
                summary.shortOrderIds.push(verdict.orderId);
            }
        }
        else {
            summary.complete += 1;
        }
    }
    return summary;
}
