#!/usr/bin/env node
import type { Page } from "playwright";
import { type BrowserCollectContext } from "../../src/connector-runtime.ts";
import { type FingerprintCursor } from "../../src/fingerprint-cursor.ts";
import { type OrderItemTally } from "./item-count-anchor.ts";
import type { ListPageDiagnostics, ListPageOrder, MaxPageResolution, OrderDetail } from "./types.ts";
export declare const HEB_HYDRATION_WAIT_MIN_MS = 1500;
export declare const HEB_HYDRATION_WAIT_MAX_MS = 2500;
export declare const MAX_LIST_PAGES = 50;
export declare const HEB_REPAIR_RETRY_DELAY_MIN_MS = 1500;
export declare const HEB_REPAIR_RETRY_DELAY_MAX_MS = 2500;
/**
 * Read the run's trigger-kind/automation-mode metadata (the same
 * `PDPP_RUN_TRIGGER_KIND` primitive the ChatGPT connector reads via
 * `chatGptAllowsInteractiveAuthRepair`, src/auto-login/chatgpt.ts:221) to
 * decide whether this run may spend the one shared owner-started manual
 * repair attempt (design.md Decision 4 / spec.md "manual-run-only for
 * owner-started assistance and latch-only for unattended runs"). Absent
 * trigger-kind metadata defaults to allowing repair — mirrors ChatGPT's same
 * default, treating "no metadata" as a manually-invoked/local/test run
 * rather than silently assuming the more restrictive unattended posture,
 * which would make local development impossible to test against.
 */
export declare function hebAllowsInteractiveAuthRepair(env?: NodeJS.ProcessEnv): boolean;
type DetailFailureKind = "deferred_budget" | "navigation_failed_non_retryable" | "navigation_retry_exhausted" | "parse_missing" | "session_repair_required";
export type HebDetailGapReason = "retry_exhausted" | "temporary_unavailable";
/**
 * Connector-neutral recovery class for one H-E-B detail-attempt outcome.
 * Mirrors connectors/amazon/index.ts's AmazonRecoveryClass shape (design doc:
 * "Copy Amazon's exhaustive DetailFailureKind -> RecoveryClass switch shape").
 */
export type HebRecoveryClass = "run_cap_deferred" | "transient_no_progress" | "owner_repair_required" | "connector_defect";
export declare function reasonForDetailFailure(kind: DetailFailureKind): HebDetailGapReason;
export declare function classifyHebDetailFailure(kind: DetailFailureKind): HebRecoveryClass;
export type DetailFetchResult = {
    detail: OrderDetail;
    status: "hydrated";
} | {
    failureKind: DetailFailureKind;
    reason: HebDetailGapReason;
    status: "deferred";
} | {
    failureKind: DetailFailureKind;
    reason: HebDetailGapReason;
    status: "failed";
};
export interface HydrationDeps {
    /** Optional deterministic seam for unit tests; production omits it and
     *  therefore keeps the 1500–2500ms polite hydration wait. */
    waitForHydration?: (() => Promise<void>) | undefined;
}
export declare function fetchOrderDetail(page: Page, orderId: string, deps?: HydrationDeps): Promise<DetailFetchResult>;
type EmptyListPageAction = "abort" | "terminal";
interface EmptyListPageClassification {
    action: EmptyListPageAction;
    reason: string;
}
/**
 * What this connection already knows about its own order history, threaded
 * explicitly into the otherwise-pure empty-page classifier.
 *
 * `hasPriorOrders` is true when a prior run committed an `orders` checkpoint —
 * the in-connector proof that H-E-B once listed orders for this account. It is
 * durable evidence about the CONNECTION, which no single page render can
 * retract.
 */
export interface PriorOrdersEvidence {
    hasPriorOrders: boolean;
}
/** Owner-facing message for the one classification whose whole point is to be
 *  read by a person. Says exactly what was observed and what was NOT concluded:
 *  neither selector drift nor a bot block is established, so neither is named.
 *  Stored records are untouched — this connector never deletes, tombstones, or
 *  overwrites on an empty page; it only declines to advance. */
export declare const HEB_EMPTY_AFTER_PRIOR_ORDERS_MESSAGE: string;
/**
 * Classify a zero-order list page: distinguish a genuine end-of-list from
 * selector drift, an auth/challenge block, or missing/contradictory
 * pagination metadata. Pure so the branch is unit-testable without driving
 * the browser.
 *
 * design.md Decision 3 / Stop Condition #3: `pageNum > 1` alone is no longer
 * terminal proof. Normal completion is proven by successfully parsing every
 * list page from page 1 through the source-advertised `maxPage`
 * (`resolveMaxPage`). Source-reported empty state is positive terminal
 * evidence. Otherwise, an empty page is terminal only after the resolved
 * pagination boundary; an empty page at or before that boundary is an error.
 * A resolved maxPage with a value strictly less than the page actually being
 * loaded is therefore treated as a terminal pagination boundary, while an
 * absent or contradictory resolution remains non-terminal.
 */
export declare function classifyEmptyListPage(diag: ListPageDiagnostics, pageNum: number, maxPageResolution: MaxPageResolution, priorOrdersEvidence?: PriorOrdersEvidence): EmptyListPageClassification;
export interface OrderItemsCoverage {
    gap: string[];
    hydrated: string[];
    required: string[];
}
export declare function newOrderItemsCoverage(): OrderItemsCoverage;
/**
 * Per-run, `orders` list-stream coverage accumulator — a distinct denominator
 * from `OrderItemsCoverage` (that one tracks the `order_items` detail-page
 * enrichment; this one tracks the `orders` list stream itself, so
 * `orders`/`checkpoint_window` can report honest evidence even on a run that
 * skips order_items entirely — H-E-B usage is genuinely light and orders-only
 * scans are a real steady-state).
 *
 * Every list-page order `runForwardScan` reaches `emitOrderAndItems` for is
 * "considered" (the denominator). An order is "covered" once the connector
 * made a real accounting decision for its `orders` record: either it
 * emitted, or the per-order fingerprint cursor deliberately suppressed a
 * byte-identical re-scrape. An order whose date never parses never reaches
 * `emitOrderAndItems`, so it is recorded separately as `dateDropped` —
 * considered, but not covered.
 */
export interface OrdersCoverage {
    considered: string[];
    covered: string[];
    dateDropped: string[];
}
export declare function newOrdersCoverage(): OrdersCoverage;
/**
 * The detail-hydration outcome for one considered order.
 *  - `hydrated` — the detail page fetched and parsed.
 *  - `gap`      — the detail fetch was attempted but degraded, or the order
 *                 never reached the detail lane (e.g., unparseable order date).
 * Both outcomes remain in the required denominator — the order was enumerated
 * by the parent list scan and must not silently vanish from coverage.
 */
export type DetailOutcome = "hydrated" | "gap";
export declare function recordDetailOutcome(coverage: OrderItemsCoverage, orderId: string, outcome: DetailOutcome): void;
/**
 * design.md Decision 4 / spec.md "manual-run-only for owner-started
 * assistance and latch-only for unattended runs": `manualRepairAttempted`
 * tracks whether this run has already spent its ONE shared run-scoped
 * repair attempt — shared across pending-gap recovery and forward scanning
 * so the two paths cannot each spend an independent attempt. `isManualRun`
 * is resolved once at run start from the trigger-kind/automation-mode
 * metadata (`hebAllowsInteractiveAuthRepair`) so every later failure site
 * branches on the same decision.
 */
export interface RunFlags {
    detailAttempts: number;
    isManualRun: boolean;
    manualRepairAttempted: boolean;
    sessionRepairRequired: boolean;
}
export interface EmitDeps extends HydrationDeps {
    capture?: BrowserCollectContext["capture"];
    emit: BrowserCollectContext["emit"];
    emitRecord: BrowserCollectContext["emitRecord"];
    emittedAt: string;
    /** Per-order declared-vs-collected item counts, accumulated across the run
     *  and rolled up into the `order_items` completeness anchor. Optional so
     *  existing callers and tests that do not exercise the anchor need no
     *  change. */
    itemCountTallies?: OrderItemTally[] | undefined;
    orderItemsCoverage: OrderItemsCoverage | undefined;
    ordersCoverage: OrdersCoverage | undefined;
    ordersFingerprintCursor: FingerprintCursor | undefined;
    progress: BrowserCollectContext["progress"];
    sendInteraction: BrowserCollectContext["sendInteraction"];
    wantsItems: boolean;
    wantsOrders: boolean;
}
/** Dependencies for the owner-started manual repair attempt — kept separate
 *  from EmitDeps because repair is browser/session-scoped, not
 *  emit/record-scoped, and tests exercising `resolveOrderDetail` without a
 *  repair scenario should not need to stub these. */
export interface RepairDeps extends HydrationDeps {
    capture?: BrowserCollectContext["capture"];
    sendInteraction: BrowserCollectContext["sendInteraction"];
    /** Optional deterministic seam for tests; production retains the polite
     *  1500–2500ms post-repair delay by omitting this dependency. */
    waitForRepairRetry?: () => Promise<void>;
}
/**
 * design.md Decision 4 / spec.md "manual-run-only for owner-started
 * assistance and latch-only for unattended runs":
 *   - Unattended run: on the first failure classified as session loss,
 *     Incapsula block, or challenge, latch `sessionRepairRequired`
 *     immediately and defer — no browser assistance is ever opened. This is
 *     the ONLY behavior on an unattended run; it never spends the manual
 *     repair budget, because it never has one.
 *   - Owner-started manual run: on that same first failure, if the one
 *     shared repair attempt has not yet been spent, spend it
 *     (`attemptManualSessionRepair`) and retry only the affected detail once
 *     if it recovers. If the attempt is already spent, or this repair
 *     attempt itself fails, latch and defer exactly like the unattended
 *     path — every subsequent failure this run behaves identically to an
 *     unattended run.
 *
 * `resolveOrderDetail` remains the single choke point every detail fetch
 * (forward-scan and old-gap recovery alike) passes through, so the shared
 * budget in `flags` cannot be spent twice by the two call sites.
 */
export declare function resolveOrderDetail(page: Page, flags: RunFlags, orderId: string, repairDeps?: RepairDeps): Promise<DetailFetchResult>;
export interface HebDetailRecoveryDeps extends HydrationDeps {
    capture?: BrowserCollectContext["capture"];
    detailGaps: readonly BrowserCollectContext["detailGaps"][number][];
    emit: BrowserCollectContext["emit"];
    emitRecord: BrowserCollectContext["emitRecord"];
    emittedAt: string;
    requestDetailGapPage?: BrowserCollectContext["requestDetailGapPage"] | undefined;
    sendInteraction: BrowserCollectContext["sendInteraction"];
}
export declare function recoverPendingOrderItemDetailGaps(page: Page, deps: HebDetailRecoveryDeps, flags: RunFlags): Promise<{
    recovered: number;
    stoppedWithPending: boolean;
}>;
export declare function recoverPendingOrderItemDetailGapsBeforeForwardRun(page: Page, deps: HebDetailRecoveryDeps, flags: RunFlags, options: {
    recoveryOnly?: boolean;
    wantsItems: boolean;
}): Promise<{
    recovered: number;
    stoppedWithPending: boolean;
    suppressForward: boolean;
}>;
export declare function processListOrder(page: Page, deps: EmitDeps, flags: RunFlags, listOrder: ListPageOrder): Promise<void>;
/**
 * The outcome of one forward scan. `truncated` distinguishes the loop's two
 * exits: `false` means the walk ended because it reached the end of the list
 * (terminal page, resume boundary, or the source's advertised `maxPage`);
 * `true` means it stopped at the `MAX_LIST_PAGES` blast-radius ceiling with
 * more pages still available. Callers MUST NOT advance the `orders` checkpoint
 * on a truncated scan — see `buildOrdersStateCursor`.
 */
export interface ForwardScanResult {
    newestOrderDate: string | null;
    truncated: boolean;
}
/**
 * Walk the order-history list pages newest-first, processing every order and
 * tracking the newest order_date seen. Stops on a legitimate terminal page,
 * once a full page is entirely older than the resume boundary, once the
 * source's own pagination max is exhausted, or at the `MAX_LIST_PAGES`
 * ceiling. The returned `truncated` flag says which of those it was, so a
 * bounded prefix is never mistaken for a finished walk.
 */
export declare function runForwardScan(page: Page, deps: EmitDeps, flags: RunFlags, boundary: string | null, priorOrdersEvidence?: PriorOrdersEvidence): Promise<ForwardScanResult>;
/** Build the next `orders` STATE cursor from this run's newest order_date
 *  (falling back to the prior checkpoint when no order was seen) and the
 *  fingerprint cursor, if any.
 *
 *  `truncated` is the page-ceiling exit. It must hold the checkpoint back,
 *  and this is the permanent-loss guard, not a nicety. The list is
 *  reverse-chronological, so `newestOrderDate` comes from page 1 — the very
 *  first page read. Committing it after a truncated walk would claim
 *  "everything at or before this date is covered" while pages 51..N were never
 *  read at all. The next run derives `resumeBoundary` from that checkpoint and
 *  `shouldStopPaginating` halts as soon as one full page falls older than it,
 *  so the untraversed tail would never be revisited by any future run: the
 *  data becomes unreachable forever, silently. Keeping the PRIOR checkpoint
 *  makes the next run re-walk from where coverage was genuinely proven.
 */
export declare function buildOrdersStateCursor(newestOrderDate: string | null, ordersState: OrdersStateShape, ordersFingerprintCursor: FingerprintCursor | undefined, truncated?: boolean): OrdersStateShape;
export declare function emitOrderItemsCoverage(deps: EmitDeps, coverage: OrderItemsCoverage): Promise<void>;
/**
 * Emit the run-level `orders` DETAIL_COVERAGE once after the forward scan,
 * using the shared `emitDetailCoverage` helper self-referentially (`stream`
 * and `stateStream` both `"orders"` — there is no separate detail-hydration
 * phase for the list stream itself, mirroring the pattern used for USAA's
 * `inbox_messages` and GitHub's `declareListConsidered` streams). Always
 * emits when the caller invokes it (orders in scope), including a
 * zero-considered steady-state run, so an account with no orders this run
 * (H-E-B usage is often genuinely light) still reads as measured, not
 * unknown.
 */
export declare function emitOrdersCoverage(deps: EmitDeps, coverage: OrdersCoverage): Promise<void>;
export interface OrdersStateShape {
    checkpoint?: string;
    fingerprints?: Record<string, string>;
}
/**
 * Derive the prior-orders evidence from this connection's stored `orders`
 * state. Exported and pure because `collect()` lives inside the
 * `isMainModule` block and cannot be driven from a test — without this seam
 * the checkpoint-to-evidence link would be the one untested link in the
 * chain, and a mutation that hardcodes `false` here (silently disarming the
 * guard for every connection) would go unnoticed.
 *
 * Any committed checkpoint counts, including one recorded by a run that
 * emitted no new records: the checkpoint's existence is the claim that H-E-B
 * once listed orders for this account.
 */
export declare function priorOrdersEvidenceFromState(ordersState: {
    checkpoint?: string;
}): PriorOrdersEvidence;
/**
 * H-E-B's order list is globally reverse-chronological (not year-partitioned
 * like Amazon). Given the prior run's checkpoint date, compute the resume
 * boundary: `checkpoint - overlap` so a re-scan crossing the boundary still
 * catches status transitions on recently-seen orders (design doc "Collector
 * plan" §4). Returns null (scan everything) when there is no prior checkpoint.
 */
export declare function resumeBoundary(priorCheckpoint: string | undefined): string | null;
/**
 * Given the newest order_date seen so far and a run's per-page order dates,
 * decide whether the forward walk should keep paginating. Stops once every
 * order on a page is older than the resume boundary (a full page past the
 * boundary means the rest of history is already covered).
 */
export declare function shouldStopPaginating(pageOrderDates: readonly (string | null)[], boundary: string | null): boolean;
export {};
//# sourceMappingURL=index.d.ts.map