/** One order's declared count against what was actually collected. */
export interface OrderItemTally {
    /** `order_items` records collected for this order this run. */
    collectedItemCount: number;
    /** The count H-E-B printed on the list card, or null when it did not. */
    declaredItemCount: number | null;
    orderId: string;
}
export type OrderItemVerdict = 
/** No sound anchor: the provider stated no usable count. */
{
    status: "unavailable";
    orderId: string;
    reason: "no_declared_count";
}
/** Everything the provider declared is accounted for. */
 | {
    status: "complete";
    orderId: string;
    considered: number;
    covered: number;
}
/** The provider declared more items than were collected. */
 | {
    status: "short";
    orderId: string;
    considered: number;
    covered: number;
    missing: number;
};
/**
 * Validate a provider-declared item count.
 *
 * Fails closed to `null` — a malformed count is NOT zero and NOT complete.
 * Mirrors jellyfin's `validateTotalRecordCount` discipline, minus its
 * monotonicity rule: H-E-B legitimately restates an order's count downward
 * after a refund, so a decrease is ordinary source behaviour here rather
 * than the anomaly it is for a Jellyfin library.
 */
export declare function validateDeclaredItemCount(value: unknown): number | null;
/**
 * Compare one order's declared count against what was collected.
 *
 * A declared zero is a real fact (an order genuinely holding no line items),
 * so it is honoured rather than treated as "unknown" — this is the same
 * distinction the fleet draws elsewhere between the provider SAYING zero and
 * the provider saying nothing.
 */
export declare function tallyOrderItems(tally: OrderItemTally): OrderItemVerdict;
/** The run-level roll-up of every per-order verdict. */
export interface ItemCountAnchorSummary {
    /** Total items collected across those same orders. */
    collectedItems: number;
    /** Orders whose declared count was fully accounted for. */
    complete: number;
    /** Total items the provider declared across anchorable orders. */
    declaredItems: number;
    /** Orders holding fewer items than the provider declared. */
    short: number;
    /** Order ids that came up short, for a bounded diagnostic. */
    shortOrderIds: string[];
    /** Orders offering no sound anchor. */
    unavailable: number;
}
/** Cap on ids listed in the diagnostic. The COUNT is always exact; only the
 *  id sample is bounded, so a large shortfall stays legible without an
 *  unbounded diagnostic. Mirrors signal's and slack's id-sample caps. */
export declare const MAX_SHORT_ORDER_IDS_IN_DIAGNOSTIC = 50;
/**
 * Roll per-order verdicts into one run-level summary.
 *
 * `unavailable` orders contribute to neither total: including an order with
 * no declared count would silently treat its collected items as if they had
 * been verified against something.
 */
export declare function summarizeItemCounts(tallies: readonly OrderItemTally[]): ItemCountAnchorSummary;
//# sourceMappingURL=item-count-anchor.d.ts.map