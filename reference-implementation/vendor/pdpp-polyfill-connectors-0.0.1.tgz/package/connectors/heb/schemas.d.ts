import { z } from "zod";
/**
 * orders stream (manifest required: id, order_date). One record per H-E-B
 * curbside/delivery order.
 *
 * status_code, timeslot_start, timeslot_end, store_name, unfulfilled_count
 * are nullable additive fields populated only from the structured
 * `__NEXT_DATA__` source when it is trustworthy for a given row (design.md
 * Decision 1); a DOM-sourced row emits them as null. status_code is an
 * honest open string reflecting the values actually observed in structured
 * source evidence (design.md Stop Condition #5) — not a closed enum asserted
 * from one account's history.
 */
export declare const ordersSchema: z.ZodObject<{
    id: z.ZodString;
    order_date: z.ZodString;
    fulfillment_method: z.ZodEnum<{
        curbside: "curbside";
        delivery: "delivery";
        unknown: "unknown";
    }>;
    fulfillment_location: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodNullable<z.ZodString>;
    status_code: z.ZodNullable<z.ZodString>;
    store_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    timeslot_start: z.ZodNullable<z.ZodString>;
    timeslot_end: z.ZodNullable<z.ZodString>;
    total: z.ZodNullable<z.ZodString>;
    total_cents: z.ZodNullable<z.ZodNumber>;
    item_count: z.ZodNullable<z.ZodNumber>;
    unfulfilled_count: z.ZodNullable<z.ZodNumber>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
/**
 * order_items stream (manifest required: id, order_id, name, order_date).
 * One record per line item on an order-detail page.
 */
export declare const orderItemsSchema: z.ZodObject<{
    id: z.ZodString;
    order_id: z.ZodString;
    name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    department: z.ZodNullable<z.ZodString>;
    product_id: z.ZodNullable<z.ZodString>;
    product_url: z.ZodNullable<z.ZodString>;
    image_url: z.ZodNullable<z.ZodString>;
    quantity: z.ZodNullable<z.ZodNumber>;
    line_total: z.ZodNullable<z.ZodString>;
    line_total_cents: z.ZodNullable<z.ZodNumber>;
    order_date: z.ZodString;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const listPageOrderShape: z.ZodObject<{
    orderId: z.ZodString;
    orderDateRaw: z.ZodNullable<z.ZodString>;
    fulfillmentMethod: z.ZodEnum<{
        curbside: "curbside";
        delivery: "delivery";
        unknown: "unknown";
    }>;
    fulfillmentLocation: z.ZodNullable<z.ZodString>;
    status: z.ZodNullable<z.ZodString>;
    statusCode: z.ZodNullable<z.ZodString>;
    storeName: z.ZodNullable<z.ZodString>;
    timeslotStart: z.ZodNullable<z.ZodString>;
    timeslotEnd: z.ZodNullable<z.ZodString>;
    total: z.ZodNullable<z.ZodString>;
    itemCount: z.ZodNullable<z.ZodNumber>;
    unfulfilledCount: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/** Sanity-check that fetched_at is a well-formed ISO-8601 datetime, used only
 *  by tests that want to assert on the emitted shape directly. */
export declare const fetchedAtSchema: z.ZodString;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map