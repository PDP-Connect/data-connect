import type { DetailItem, ListPageDiagnostics, ListPageOrder, MaxPageResolution, OrderDetail, OrderItemRecord, OrdersRecord } from "./types.ts";
export declare function parseOrdersListDom(html: string): ListPageOrder[];
/**
 * Parse every trustworthy row out of the structured `__NEXT_DATA__.props.
 * pageProps.orders[]` array. Returns null if the payload is absent, malformed,
 * or does not contain a usable order array — Decision 1's page-level fallback
 * trigger. Returns an array (possibly with fewer entries than the source
 * array, when individual rows fail the per-row trustworthy-shape check) when
 * the array itself is usable — those untrustworthy rows are the caller's
 * per-row DOM-fallback responsibility, not a page-level failure.
 */
export declare function parseOrdersListStructured(html: string): ListPageOrder[] | null;
/**
 * Merge a page's structured and DOM extractions: prefer the structured row
 * for an order id when present and trustworthy, fall back to the DOM row
 * otherwise. Preserves DOM extraction's `total`/`itemCount`/
 * `fulfillmentMethod`/`fulfillmentLocation` for a structured-preferred row
 * (those fields are not evidenced in the structured source — see the module
 * doc comment above) by carrying them over from the DOM row of the same
 * order id, when a DOM row for that id exists on this page. Order follows
 * the DOM extraction's order (list-page visual order); a structured-only row
 * with no DOM counterpart (should not normally occur — the DOM link list and
 * structured array describe the same page) is appended after.
 */
export declare function mergeOrdersListPage(structured: ListPageOrder[] | null, dom: ListPageOrder[]): ListPageOrder[];
/** Parse "July 14, 2026" or an ISO-8601 timestamp → "2026-07-14". Returns
 *  null on unparseable input. Used for both the DOM free-text date and the
 *  structured `orderTimeslot.startDateTime` fallback-fill of `orderDateRaw`
 *  (see mergeOrdersListPage doc: order_date itself stays DOM-authoritative
 *  when a DOM row exists; this only feeds a structured-only row's date). */
export declare function parseOrderDate(raw: string | null | undefined): string | null;
export declare function parseCurrencyCents(raw: string | null | undefined): number | null;
/** Resolve `maxPage` from structured `pages[]`/`page`. `pages[]` entries are
 *  `{to: "?page=N"}` links; the resolved value is the max parsed N. A
 *  `pages[]` entry present but not matching the expected `?page=N` shape is
 *  ignored for the max computation but marks the array as seen (so an empty
 *  usable result is still "resolved" only if at least one entry parsed). */
export declare function resolveStructuredMaxPage(pageProps: {
    page?: unknown;
    pages?: unknown;
} | null): MaxPageResolution;
/**
 * Resolve `maxPage` from the DOM pagination nav. Distinguishes "no
 * pagination nav present at all" (absent) from "a nav is present and
 * affirmatively asserts exactly one page" (resolved, value 1) from "a nav is
 * present but its links do not yield a coherent max" (contradictory) — the
 * prior `parseMaxPage` conflated the first two cases by always returning 1.
 */
export declare function resolveDomMaxPage(html: string): MaxPageResolution;
/**
 * The overall maxPage resolution contract: structured `pages[]`/`page` is
 * primary; the DOM nav scrape is used only when structured pagination is
 * absent. A structured "contradictory" result is NOT masked by falling back
 * to DOM — internally-inconsistent structured metadata is itself the
 * contradictory signal (falling back would silently hide the source
 * asserting two different things about its own pagination state).
 */
export declare function resolveMaxPage(html: string): MaxPageResolution;
/**
 * Derive the H-E-B product image CDN URL from a product id. Reverse-engineered
 * convention (docs/research/heb-site-knowledge-2026-07-14.md "Order detail"),
 * not a documented H-E-B API — this may drift and needs live re-verification.
 * Returns null for a productId that isn't a digits-only string (the
 * documented CDN convention is a zero-padded product-id digit string; a
 * decimal-like id such as "123.45" is not a valid H-E-B product id).
 */
export declare function productImageUrl(productId: string | null): string | null;
/**
 * Parse a detail row's quantity, preferring the structured "Qty: N" / "Qty: N
 * of M unit" span (the actual fulfilled/charged amount — LIVE-VERIFIED to
 * match what the line-total price corresponds to for substituted/weighted
 * items), falling back to the free-text "Quantity: ..." line (the ORDERED
 * amount) when the structured span is absent. Returns null — never a
 * fabricated/truncated integer — for anything that isn't a clean leading
 * number (e.g. a unit-only value with no numeric prefix). Exported for direct
 * unit tests of the quantity-value contract independent of DOM row
 * extraction.
 */
export declare function parseDetailQuantity(rowText: string): number | null;
export declare function parseOrderDetailDom(html: string): OrderDetail | null;
export declare function isIncapsulaBlocked(html: string): boolean;
export declare function looksLoggedOut(landedUrl: string, html: string): boolean;
export declare function hasOrdersEmptyState(html: string): boolean;
export declare function diagnoseEmptyListPage(html: string, url: string): ListPageDiagnostics;
/** Keep browser text local to classification. Durable SKIP_RESULT diagnostics
 * retain structural facts but never page content, title, or URL. */
export declare function redactHebListPageDiagnostics(diag: ListPageDiagnostics): ListPageDiagnostics;
export declare function buildOrderRecord(listOrder: ListPageOrder, orderDate: string, emittedAt: string): OrdersRecord;
/** Composite item id, Amazon's `${orderId}|${key}` pattern (design doc: "H-E-B
 *  is *better* off than Amazon here because `product_id` comes free from the
 *  detail-page href"). Falls back to a normalized name when product_id is
 *  absent so every item still gets a stable, order-scoped id. The fallback
 *  incorporates `itemIndex` (the item's position within this order's parsed
 *  item list) so two same-name, product-id-null items in one order — e.g. two
 *  malformed/variant hrefs that both fail to yield a product id — get
 *  distinct ids instead of colliding on the same normalized name. */
export declare function orderItemId(orderId: string, item: Pick<DetailItem, "productId" | "name">, itemIndex: number): string;
export declare function buildOrderItemRecord(orderId: string, orderDate: string, item: DetailItem, itemIndex: number, emittedAt: string): OrderItemRecord;
//# sourceMappingURL=parsers.d.ts.map