import { z } from "zod";
/**
 * events stream: one record per parsed VEVENT with a UID and a start.
 * Cursor: start (latest_start).
 */
export declare const eventsSchema: z.ZodObject<{
    id: z.ZodString;
    calendar_name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    summary: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    location: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    start: z.ZodString;
    end: z.ZodNullable<z.ZodString>;
    all_day: z.ZodBoolean;
    organizer_email: z.ZodNullable<z.ZodString>;
    attendees: z.ZodArray<z.ZodObject<{
        email: z.ZodString;
        name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        role: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    status: z.ZodNullable<z.ZodString>;
    rrule: z.ZodNullable<z.ZodString>;
    uid: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map