import type { IcsEvent, IcsEventOut, IcsLine } from "./types.ts";
export declare const ICAL_LINE_FOLD_RE: RegExp;
export declare const ICAL_DATETIME_UTC_RE: RegExp;
export declare const ICAL_DATETIME_LOCAL_RE: RegExp;
export declare const ICAL_MAILTO_RE: RegExp;
export declare const ICAL_ESC_NEWLINE_RE: RegExp;
export declare const ICAL_ESC_COMMA_RE: RegExp;
export declare const ICS_EXT_RE: RegExp;
export declare const RETRYABLE_FETCH_RE: RegExp;
export declare const ICAL_LINE_SPLIT_RE: RegExp;
export declare function hashId(s: string): string;
/** RFC 5545 line folding: continuation lines start with space/tab. */
export declare function unfoldIcal(text: string): string;
export declare function unescapeIcsText(value: string): string;
export declare function parseIcsDate(raw: string | undefined, isDateOnly: boolean): string | null;
/**
 * Parse one unfolded VEVENT property line into name, value, and params.
 * Returns null for lines without a `name:value` shape (blank / comment /
 * malformed). Parameters (e.g. `DTSTART;VALUE=DATE:20240605`) land in the
 * `params` bag with upper-cased keys.
 */
export declare function parseIcsLine(raw: string): IcsLine | null;
/**
 * Apply a single property line to the in-flight event. Keeping this as a
 * plain switch (one branch per property) keeps each branch cheap and
 * keeps the dispatch table readable vs. a Record<string, fn>.
 */
export declare function applyIcsProperty(event: IcsEvent, line: IcsLine): void;
/**
 * Parse a full `.ics` source string into zero-or-more IcsEvent records.
 * Line folding per RFC 5545 is unwrapped first, then VEVENT blocks are
 * framed by BEGIN/END markers and each property line delegates to
 * `applyIcsProperty`.
 */
export declare function parseIcs(source: string, calendarName: string): IcsEvent[];
/**
 * Build an emittable `events`-stream record from a parsed IcsEvent.
 * Returns null when UID or start is missing — index.ts skips those
 * silently since iCal sources sometimes emit half-formed stubs.
 */
export declare function buildEventRecord(event: IcsEvent, calendarName: string): IcsEventOut | null;
export declare function isBeforeCursor(start: string, since: string | undefined): boolean;
export declare function advanceCursor(prev: string | undefined, next: string): string;
//# sourceMappingURL=parsers.d.ts.map