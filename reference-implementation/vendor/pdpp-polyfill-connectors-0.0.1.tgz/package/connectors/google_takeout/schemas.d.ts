import { z } from "zod";
/**
 * location_history: one point per Google Maps Timeline record.
 * Cursor: timestamp (ISO).
 */
export declare const locationHistorySchema: z.ZodObject<{
    id: z.ZodString;
    timestamp: z.ZodString;
    latitude: z.ZodNullable<z.ZodNumber>;
    longitude: z.ZodNullable<z.ZodNumber>;
    accuracy_meters: z.ZodNullable<z.ZodNumber>;
    activity_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    velocity_mps: z.ZodNullable<z.ZodNumber>;
    altitude_m: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * youtube_watch_history: one entry per watched video.
 * Cursor: watched_at (ISO).
 */
export declare const youtubeWatchHistorySchema: z.ZodObject<{
    id: z.ZodString;
    watched_at: z.ZodString;
    video_url: z.ZodNullable<z.ZodURL>;
    video_title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    channel_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    channel_url: z.ZodNullable<z.ZodURL>;
}, z.core.$strip>;
/**
 * search_history: one entry per My Activity search row. `query` is the
 * title with the "Searched for " prefix stripped, so it may be empty
 * string (the parser does not null it) — allow min(0).
 * Cursor: timestamp (ISO).
 */
export declare const searchHistorySchema: z.ZodObject<{
    id: z.ZodString;
    timestamp: z.ZodString;
    query: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    product: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
export declare const photosSchema: z.ZodObject<{
    id: z.ZodString;
    filename: z.ZodString;
    event_time: z.ZodString;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    latitude: z.ZodNullable<z.ZodNumber>;
    longitude: z.ZodNullable<z.ZodNumber>;
    altitude: z.ZodNullable<z.ZodNumber>;
    blob_ref: z.ZodNullable<z.ZodObject<{
        blob_id: z.ZodString;
        mime_type: z.ZodString;
        sha256: z.ZodString;
        size_bytes: z.ZodNumber;
    }, z.core.$strip>>;
    content_sha256: z.ZodNullable<z.ZodString>;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    hydration_status: z.ZodString;
    hydration_error: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
export declare const coverageDiagnosticsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    store: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    stream: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodEnum<{
        collected: "collected";
        deferred: "deferred";
        excluded: "excluded";
        inventory_only: "inventory_only";
        missing: "missing";
        unsupported: "unsupported";
    }>;
    reason: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the streams this
 * connector emits.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map