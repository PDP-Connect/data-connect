import type { LocationPoint, LocationRecord, PhotoMetadataFile, PhotoRecord, SearchHistoryEntry, SearchRecord, WatchHistoryEntry, WatchHistoryRecord } from "./types.ts";
export declare const SEARCHED_FOR_PREFIX_RE: RegExp;
export declare function hashId(s: string): string;
export declare function readJsonIf(path: string): Promise<unknown>;
/**
 * Resolve a Google location point's absolute timestamp (Unix ms). Google
 * exports use either `timestampMs` (older) or ISO `timestamp` (newer).
 * Returns null when neither is usable.
 */
export declare function locationTimestampMs(loc: LocationPoint): number | null;
export declare function scaleE7(v: number | undefined): number | null;
/**
 * Build a location_history record from a raw LocationPoint at a given ISO
 * timestamp. Caller is responsible for the since-cursor filter.
 */
export declare function buildLocationRecord(loc: LocationPoint, iso: string): LocationRecord;
/**
 * Build a youtube_watch_history record from a raw WatchHistoryEntry. Returns
 * null if the entry is missing a timestamp.
 */
export declare function buildWatchHistoryRecord(e: WatchHistoryEntry): WatchHistoryRecord | null;
/**
 * Build a search_history record from a raw SearchHistoryEntry. Returns null
 * if the entry is missing a timestamp.
 */
export declare function buildSearchRecord(e: SearchHistoryEntry): SearchRecord | null;
/**
 * Extract event timestamp from Google Takeout photo metadata.
 * Prefers photoTakenTime (EXIF) over creationTime (upload).
 * Returns null if neither is present or valid.
 */
export declare function photoEventTimeMs(meta: PhotoMetadataFile): number | null;
/**
 * Google Takeout duplicates a photo's file + sidecar into every album folder
 * it belongs to (per-copy fields like creationTime/imageViews can differ
 * between copies of the same underlying photo — see connector-primary-
 * reconcile-0807.md §2). Filename + folder is therefore not a safe identity
 * key. Content sha256 is: identical bytes always mean the same underlying
 * asset, and it naturally collapses duplicate album copies to one record.
 */
export declare function buildPhotoRecord(filename: string, iso: string, contentSha256: string | null, metadata?: PhotoMetadataFile | null): Omit<PhotoRecord, "blob_ref" | "hydration_error" | "hydration_status" | "size_bytes">;
/**
 * Pick the best-matching sidecar JSON filename for a media file from the
 * list of JSON filenames present in the same directory. Returns null when
 * no plausible candidate exists (a missing sidecar is expected, not an
 * error — see connector-primary-reconcile-0807.md §2).
 */
export declare function matchSidecarFilename(mediaFilename: string, jsonFilenamesInDir: readonly string[]): string | null;
//# sourceMappingURL=parsers.d.ts.map