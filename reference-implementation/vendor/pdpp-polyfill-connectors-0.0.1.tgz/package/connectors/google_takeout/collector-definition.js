// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Default stream set for an unscoped `google_takeout` local-collector run.
 *
 * Mirrors the connector's full manifest-declared stream set. Google Takeout
 * reads an already-extracted GOOGLE_TAKEOUT_DIR from the local filesystem —
 * exactly the local-collector shape (runs on the machine that has the
 * extracted archive), not a browser-upload or provider-API connector.
 */
export const GOOGLE_TAKEOUT_DEFAULT_STREAMS = [
    "location_history",
    "youtube_watch_history",
    "search_history",
    "photos",
    "coverage_diagnostics",
];
/**
 * Streams an owner-declared `since` can be proven against — those the manifest
 * gives a `consent_time_field`. `coverage_diagnostics` carries none (it is the
 * run's own accounting, not owner data), so it is always collected whole.
 */
export const GOOGLE_TAKEOUT_TIME_SCOPABLE_STREAMS = [
    "location_history",
    "youtube_watch_history",
    "search_history",
    "photos",
];
export const googleTakeoutCollectorDefinition = {
    connector_id: "google_takeout",
    entry: "google_takeout",
    bindings: { filesystem: { required: true } },
    // Declared explicitly (not omitted): this definition targets the
    // connector-protocol 0.0.2 capability-declaration contract, which
    // requires an explicit array even when empty. This connector emits no
    // STREAM_EVIDENCE and needs no protocol capability today.
    protocol_capabilities: [],
    streams: GOOGLE_TAKEOUT_DEFAULT_STREAMS,
    time_scopable_streams: GOOGLE_TAKEOUT_TIME_SCOPABLE_STREAMS,
};
