import { z } from "zod";
/**
 * videos stream: one record per recorded Loom video.
 * Cursor: created_at. `id` is the Loom video id (opaque string in the
 * manifest); tighten to its real shape when extraction lands.
 */
export declare const videosSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    duration_seconds: z.ZodNullable<z.ZodNumber>;
    view_count: z.ZodNullable<z.ZodNumber>;
    created_at: z.ZodNullable<z.ZodString>;
    share_url: z.ZodNullable<z.ZodURL>;
    has_transcript: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
/**
 * transcripts stream: one record per video transcript.
 * `text` is the full transcript body → pdppSafeText (large allowed).
 */
export declare const transcriptsSchema: z.ZodObject<{
    id: z.ZodString;
    video_id: z.ZodString;
    text: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the streams this
 * connector declares (and will emit once extraction is wired).
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map