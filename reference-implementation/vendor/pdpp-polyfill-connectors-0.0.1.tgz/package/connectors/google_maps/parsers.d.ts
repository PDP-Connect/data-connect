import type { GoogleMapsSourceFormat, ParseResult } from "./types.ts";
export declare function hashId(s: string): string;
export declare function parseGoogleMapsExport(json: unknown): ParseResult;
/** Parse one element from a streamed Timeline container through the same
 * pure dispatch used by the buffer-backed parser. */
export declare function parseGoogleMapsExportElement(format: GoogleMapsSourceFormat, value: unknown): ParseResult;
//# sourceMappingURL=parsers.d.ts.map