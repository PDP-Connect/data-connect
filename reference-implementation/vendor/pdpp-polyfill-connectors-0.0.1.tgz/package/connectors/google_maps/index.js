#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * PDPP Google Maps Timeline Connector (v0.1.0) — file-based.
 *
 * Auth: none. The owner exports Google Maps Timeline data from Google Maps /
 * Android settings or extracts a legacy Takeout archive into
 * GOOGLE_MAPS_TIMELINE_DIR (defaults to ~/.pdpp/imports/google_maps/).
 */
import { existsSync } from "node:fs";
import { readdir } from "node:fs/promises";
import { homedir } from "node:os";
import { basename, join } from "node:path";
import { buildDetailCoverageMessage, buildFullScanCoverageMessage, runConnector, } from "../../src/connector-runtime.js";
import { GoogleMapsElementTooLargeError, GoogleMapsUnsupportedShapeError, streamGoogleMapsExport, } from "./archive-stream.js";
import { parseGoogleMapsExportElement } from "./parsers.js";
import { validateRecord } from "./schemas.js";
const MAX_DISCOVERY_DEPTH = 5;
const MAX_DISCOVERY_ENTRIES = 2000;
const POINT_PROGRESS_INTERVAL = 10_000;
const SEGMENT_PROGRESS_INTERVAL = 1000;
const SUPPORTED_FILE_NAMES = new Set([
    "location-history.json",
    "timeline.json",
    "records.json",
]);
function isLikelyTimelineJson(path) {
    const fileName = basename(path).toLowerCase();
    if (!SUPPORTED_FILE_NAMES.has(fileName)) {
        return false;
    }
    if (fileName !== "records.json") {
        return true;
    }
    const lowerPath = path.toLowerCase();
    return (lowerPath.includes("location history") ||
        lowerPath.includes("timeline") ||
        lowerPath.endsWith("/records.json"));
}
function markDiscoveryIncomplete(state, reason) {
    state.incompleteReason ??= reason;
}
async function readDiscoveryDirectory(dir, state) {
    try {
        return await readdir(dir, { withFileTypes: true });
    }
    catch {
        markDiscoveryIncomplete(state, "read_error");
        return null;
    }
}
async function inspectDiscoveryEntry(entry, path, depth, state) {
    if (entry.isDirectory()) {
        if (depth >= MAX_DISCOVERY_DEPTH) {
            markDiscoveryIncomplete(state, "depth_limit");
            return;
        }
        await walkDiscoveryDirectory(path, depth + 1, state);
        return;
    }
    if (entry.isFile() && isLikelyTimelineJson(path)) {
        state.found.push(path);
    }
}
async function walkDiscoveryDirectory(dir, depth, state) {
    if (depth > MAX_DISCOVERY_DEPTH) {
        markDiscoveryIncomplete(state, "depth_limit");
        return;
    }
    if (state.visited >= MAX_DISCOVERY_ENTRIES) {
        markDiscoveryIncomplete(state, "entry_limit");
        return;
    }
    const entries = await readDiscoveryDirectory(dir, state);
    if (!entries) {
        return;
    }
    for (const entry of entries) {
        if (state.visited >= MAX_DISCOVERY_ENTRIES) {
            markDiscoveryIncomplete(state, "entry_limit");
            return;
        }
        state.visited += 1;
        await inspectDiscoveryEntry(entry, join(dir, entry.name), depth, state);
        if (state.incompleteReason === "entry_limit") {
            return;
        }
    }
}
async function discoverTimelineFiles(importDir) {
    if (!existsSync(importDir)) {
        return { complete: false, files: [], incompleteReason: "missing" };
    }
    const state = {
        found: [],
        incompleteReason: undefined,
        visited: 0,
    };
    await walkDiscoveryDirectory(importDir, 0, state);
    return {
        complete: state.incompleteReason === undefined,
        files: [...new Set(state.found)].sort(),
        incompleteReason: state.incompleteReason,
    };
}
async function emitRequestedSkip(ctx, reason, message) {
    for (const stream of ["timeline_points", "timeline_segments"]) {
        if (ctx.requested.has(stream)) {
            await ctx.emit({ type: "SKIP_RESULT", stream, reason, message });
        }
    }
}
const GOOGLE_MAPS_EMISSION_ERROR = Symbol("google_maps_emission_error");
function makeGoogleMapsEmissionError(cause) {
    const error = new Error("Google Maps protocol emission failed", { cause });
    Object.defineProperty(error, GOOGLE_MAPS_EMISSION_ERROR, { value: true });
    return error;
}
function isGoogleMapsEmissionError(error) {
    return (error instanceof Error &&
        error[GOOGLE_MAPS_EMISSION_ERROR] === true);
}
function maxTimestamp(current, candidate) {
    return !current || candidate > current ? candidate : current;
}
async function emitRecordSafely(ctx, stream, record) {
    try {
        await ctx.emitRecord(stream, record);
    }
    catch (error) {
        throw makeGoogleMapsEmissionError(error);
    }
}
async function admitRecord(load, stream, record) {
    const validation = validateRecord(stream, record);
    if (validation.ok) {
        return true;
    }
    load.summary.complete = false;
    const requested = stream === "timeline_points"
        ? load.requestedPoints
        : load.requestedSegments;
    if (requested) {
        // Keep the runtime's SKIP_RESULT visible, but do not let this rejected
        // record enter the dedupe set or advance any coverage frontier.
        await emitRecordSafely(load.ctx, stream, record);
    }
    return false;
}
async function emitProgressSafely(ctx, message, options) {
    try {
        await ctx.progress(message, options);
    }
    catch (error) {
        throw makeGoogleMapsEmissionError(error);
    }
}
// The parser retains only the current source element, but exact cross-file
// dedupe intentionally retains one ID per accepted record for this run. The
// collector is therefore streaming with O(unique accepted IDs) dedupe state,
// not a constant-memory whole-run collector.
async function processPointRecords(load, points) {
    for (const point of points) {
        const pointId = typeof point.id === "string" ? point.id : null;
        const timestamp = typeof point.timestamp === "string" ? point.timestamp : null;
        if (!(pointId && timestamp)) {
            // The artifact held this element and the parser produced it, but without a
            // stable id + timestamp it cannot be emitted or deduped. Count it as
            // considered-but-not-covered rather than dropping it silently: an element
            // the run could not account for must not be erased from the denominator.
            load.summary.pointsUnaccounted += 1;
            continue;
        }
        if (load.seenPointIds.has(pointId)) {
            continue;
        }
        const record = { ...point };
        if (!(await admitRecord(load, "timeline_points", record))) {
            continue;
        }
        load.seenPointIds.add(pointId);
        load.summary.pointCount += 1;
        load.summary.latestPoint = maxTimestamp(load.summary.latestPoint, timestamp);
        if (!load.requestedPoints ||
            (load.pointSince && timestamp <= load.pointSince)) {
            continue;
        }
        await emitRecordSafely(load.ctx, "timeline_points", record);
        load.summary.pointsEmitted += 1;
        if (load.summary.pointsEmitted % POINT_PROGRESS_INTERVAL === 0) {
            await emitProgressSafely(load.ctx, `Google Maps phase=emit pass=emit stream=timeline_points emitted=${load.summary.pointsEmitted}/streaming`, { stream: "timeline_points" });
        }
    }
}
function recordUnrecognizedSegment(summary, segment) {
    if (segment.segment_kind !== "unrecognized") {
        return;
    }
    summary.unrecognizedCount += 1;
    summary.unrecognizedKinds.add(segment.unrecognized_kind ?? "(no payload key)");
}
async function processSegmentRecords(load, segments) {
    for (const segment of segments) {
        const segmentId = typeof segment.id === "string" ? segment.id : null;
        const startTime = typeof segment.start_time === "string" ? segment.start_time : null;
        if (!(segmentId && startTime)) {
            // See `processPointRecords`: an unaccountable element stays in the
            // denominator so the artifact reconciliation reads `partial`, not a
            // silent `complete`.
            load.summary.segmentsUnaccounted += 1;
            continue;
        }
        if (load.seenSegmentIds.has(segmentId)) {
            continue;
        }
        const record = { ...segment };
        if (!(await admitRecord(load, "timeline_segments", record))) {
            continue;
        }
        load.seenSegmentIds.add(segmentId);
        load.summary.segmentCount += 1;
        load.summary.latestSegment = maxTimestamp(load.summary.latestSegment, startTime);
        recordUnrecognizedSegment(load.summary, segment);
        if (!load.requestedSegments ||
            (load.segmentSince && startTime <= load.segmentSince)) {
            continue;
        }
        await emitRecordSafely(load.ctx, "timeline_segments", record);
        load.summary.segmentsEmitted += 1;
        if (load.summary.segmentsEmitted % SEGMENT_PROGRESS_INTERVAL === 0) {
            await emitProgressSafely(load.ctx, `Google Maps phase=emit pass=emit stream=timeline_segments emitted=${load.summary.segmentsEmitted}/streaming`, { stream: "timeline_segments" });
        }
    }
}
async function processStreamEvent(load, event) {
    if (event.kind === "shape") {
        return;
    }
    const parsed = parseGoogleMapsExportElement(event.format, event.value);
    // THE ARTIFACT BOUNDARY. One `element` event is exactly one element the
    // uploaded file contained, counted here — before the parser's verdict — so
    // the denominator is measured at the source, not recomputed from survivors.
    //
    // An element the parser yields nothing for (no point AND no segment) is the
    // silent drop this guards: an unkeyable `locations` entry with no
    // `timestampMs`, or a `semanticSegments` entry with no start time, both parse
    // to `{points:[],segments:[]}`. Attributing it to a stream requires the
    // element's own format, since a legacy `locations` element can only ever have
    // been a point and a `semanticSegments` element can only ever have been a
    // segment.
    if (parsed.points.length === 0 && parsed.segments.length === 0) {
        if (event.format === "legacy_records") {
            load.summary.pointsUnaccounted += 1;
        }
        else {
            load.summary.segmentsUnaccounted += 1;
        }
        return;
    }
    await processPointRecords(load, parsed.points);
    await processSegmentRecords(load, parsed.segments);
}
async function streamTimelineFile(load, file) {
    await streamGoogleMapsExport(file, (event) => processStreamEvent(load, event));
}
async function reportSourceFailure(ctx, error) {
    const oversized = error instanceof GoogleMapsElementTooLargeError;
    const unsupportedShape = error instanceof GoogleMapsUnsupportedShapeError;
    let reason = "invalid_json";
    let message = "A Google Maps Timeline export file could not be parsed as JSON";
    if (oversized) {
        reason = "record_too_large";
        message =
            "A Google Maps Timeline export contains a record that is too large to process safely";
    }
    else if (unsupportedShape) {
        reason = "unsupported_shape";
        message =
            "A Google Maps Timeline export contains a recognized key whose value is not an array";
    }
    await emitRequestedSkip(ctx, reason, message);
}
function discoveryFailureMessage(reason) {
    switch (reason) {
        case "missing":
            return "The configured Google Maps Timeline import directory is missing, so the source boundary was not observed";
        case "read_error":
            return "The Google Maps Timeline import directory could not be fully read, so the source boundary was not observed";
        case "depth_limit":
            return "The Google Maps Timeline import tree is deeper than the safe discovery limit, so coverage is incomplete";
        case "entry_limit":
            return "The Google Maps Timeline import tree exceeds the safe discovery limit, so coverage is incomplete";
        default:
            return "The Google Maps Timeline import tree could not be fully observed, so coverage is incomplete";
    }
}
async function loadExports(ctx, importDir, state) {
    const discovery = await discoverTimelineFiles(importDir);
    const { files } = discovery;
    const requestedPoints = ctx.requested.has("timeline_points");
    const requestedSegments = ctx.requested.has("timeline_segments");
    const pointSince = state.timeline_points?.last_timestamp;
    const segmentSince = state.timeline_segments?.last_start_time;
    const summary = {
        complete: discovery.complete,
        latestPoint: pointSince,
        latestSegment: segmentSince,
        pointCount: 0,
        pointsEmitted: 0,
        pointsUnaccounted: 0,
        segmentCount: 0,
        segmentsEmitted: 0,
        segmentsUnaccounted: 0,
        unrecognizedCount: 0,
        unrecognizedKinds: new Set(),
    };
    const load = {
        ctx,
        pointSince,
        requestedPoints,
        requestedSegments,
        segmentSince,
        seenPointIds: new Set(),
        seenSegmentIds: new Set(),
        summary,
    };
    await ctx.progress(`Google Maps phase=index pass=index source_files=${files.length}`);
    if (requestedPoints) {
        await ctx.progress("Google Maps phase=emit pass=emit stream=timeline_points total_items=streaming", {
            stream: "timeline_points",
        });
    }
    if (requestedSegments) {
        await ctx.progress("Google Maps phase=emit pass=emit stream=timeline_segments total_items=streaming", {
            stream: "timeline_segments",
        });
    }
    if (!discovery.complete && discovery.incompleteReason) {
        await emitRequestedSkip(ctx, "source_incomplete", discoveryFailureMessage(discovery.incompleteReason));
    }
    let fileOrdinal = 0;
    for (const file of files) {
        fileOrdinal += 1;
        await ctx.progress(`Google Maps phase=parse pass=parse source_file=${fileOrdinal}/${files.length}`);
        try {
            await streamTimelineFile(load, file);
        }
        catch (error) {
            if (isGoogleMapsEmissionError(error)) {
                throw error.cause;
            }
            summary.complete = false;
            await reportSourceFailure(ctx, error);
        }
    }
    return summary;
}
async function finishPoints(ctx, summary) {
    if (!summary.complete) {
        return;
    }
    await ctx.emit({
        type: "STATE",
        stream: "timeline_points",
        cursor: { last_timestamp: summary.latestPoint },
    });
    // Artifact reconciliation, NOT an account-completeness claim. The denominator
    // is every point element the parser produced from the uploaded file —
    // accounted-for plus unaccountable — measured at the parse site. The numerator
    // is only what this run could actually key and dedupe. When the artifact holds
    // an element with no id/timestamp, `covered < considered` and the stream reads
    // `partial`, which is the honest verdict.
    //
    // What this CANNOT say: whether the artifact itself is a complete export of
    // the owner's Google Maps history. Google decides what goes into the file; a
    // fully-reconciled artifact only proves this run ingested everything the file
    // contained, never that the file contained everything the provider holds.
    const pointsConsidered = summary.pointCount + summary.pointsUnaccounted;
    if (summary.pointsUnaccounted > 0) {
        await ctx.emit({
            type: "SKIP_RESULT",
            stream: "timeline_points",
            reason: "element_unaccounted",
            message: `${String(summary.pointsUnaccounted)} of ${String(pointsConsidered)} Google Maps Timeline point element(s) lacked a usable id or timestamp and could not be ingested`,
            diagnostics: {
                considered: pointsConsidered,
                unaccounted: summary.pointsUnaccounted,
            },
        });
    }
    await ctx.emit(buildDetailCoverageMessage({
        stream: "timeline_points",
        stateStream: "timeline_points",
        requiredKeys: [],
        hydratedKeys: [],
        considered: pointsConsidered,
        covered: summary.pointCount,
    }));
}
async function finishSegments(ctx, summary) {
    if (!summary.complete) {
        return;
    }
    if (summary.unrecognizedKinds.size > 0) {
        await ctx.progress(`Google Maps phase=emit pass=emit stream=timeline_segments unrecognized_segments=${summary.unrecognizedCount} unrecognized_kinds=${[
            ...summary.unrecognizedKinds,
        ]
            .sort()
            .join(",")}`, { stream: "timeline_segments" });
    }
    await ctx.emit({
        type: "STATE",
        stream: "timeline_segments",
        cursor: { last_start_time: summary.latestSegment },
    });
    // Same artifact reconciliation as `finishPoints`. `buildFullScanCoverageMessage`
    // is deliberately NOT used when an element went unaccounted: it forces
    // `covered === considered`, which would re-hide the very drop this counts.
    const segmentsConsidered = summary.segmentCount + summary.segmentsUnaccounted;
    if (summary.segmentsUnaccounted > 0) {
        await ctx.emit({
            type: "SKIP_RESULT",
            stream: "timeline_segments",
            reason: "element_unaccounted",
            message: `${String(summary.segmentsUnaccounted)} of ${String(segmentsConsidered)} Google Maps Timeline segment element(s) lacked a usable id or start time and could not be ingested`,
            diagnostics: {
                considered: segmentsConsidered,
                unaccounted: summary.segmentsUnaccounted,
            },
        });
        await ctx.emit(buildDetailCoverageMessage({
            stream: "timeline_segments",
            stateStream: "timeline_segments",
            requiredKeys: [],
            hydratedKeys: [],
            considered: segmentsConsidered,
            covered: summary.segmentCount,
        }));
        return;
    }
    await ctx.emit(buildFullScanCoverageMessage("timeline_segments", summary.segmentCount));
}
runConnector({
    name: "google_maps",
    validateRecord,
    async collect(ctx) {
        const importDir = process.env.GOOGLE_MAPS_TIMELINE_DIR ||
            join(homedir(), ".pdpp/imports/google_maps");
        const typedState = ctx.state;
        const requestedPoints = ctx.requested.has("timeline_points");
        const requestedSegments = ctx.requested.has("timeline_segments");
        const summary = await loadExports(ctx, importDir, typedState);
        if (requestedPoints && summary.complete && summary.pointCount === 0) {
            await ctx.emit({
                type: "SKIP_RESULT",
                stream: "timeline_points",
                reason: "timeline_points_not_found",
                message: "Google Maps Timeline point records were not found in the configured import directory",
            });
        }
        if (requestedSegments && summary.complete && summary.segmentCount === 0) {
            await ctx.emit({
                type: "SKIP_RESULT",
                stream: "timeline_segments",
                reason: "timeline_segments_not_found",
                message: "Google Maps Timeline segment records were not found in the configured import directory",
            });
        }
        if (requestedPoints) {
            await finishPoints(ctx, summary);
        }
        if (requestedSegments) {
            await finishSegments(ctx, summary);
        }
    },
});
