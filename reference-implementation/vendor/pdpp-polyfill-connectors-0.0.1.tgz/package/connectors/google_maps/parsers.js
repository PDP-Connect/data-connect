// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
// Pure parsers for owner-provided Google Maps Timeline export files. Runtime
// file discovery and emit orchestration live in index.ts.
import { createHash } from "node:crypto";
const GOOGLE_E7_DIVISOR = 1e7;
const RECORD_ID_HASH_LENGTH = 24;
const GEO_PREFIX_RE = /^geo:/i;
const GEO_PAIR_RE = /(-?\d+(?:\.\d+)?)[^\d-]+(-?\d+(?:\.\d+)?)/;
export function hashId(s) {
    return createHash("sha256")
        .update(s)
        .digest("hex")
        .slice(0, RECORD_ID_HASH_LENGTH);
}
function asObject(value) {
    return value && typeof value === "object" && !Array.isArray(value)
        ? value
        : null;
}
function asString(value) {
    return typeof value === "string" && value.trim() ? value : null;
}
function asNumber(value) {
    return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function isValidLatLon(latitude, longitude) {
    return (latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180);
}
function scaleE7(value) {
    const n = asNumber(value);
    return n === null ? null : n / GOOGLE_E7_DIVISOR;
}
function parseIso(value) {
    const raw = asString(value);
    if (!raw) {
        return null;
    }
    const ms = Date.parse(raw);
    return Number.isNaN(ms) ? null : new Date(ms).toISOString();
}
function parseTimestampMs(value) {
    const raw = typeof value === "number" ? String(value) : asString(value);
    if (!raw) {
        return null;
    }
    // `> 0` not just isFinite: a "0" timestampMs is Google's "unset", and
    // converting it would put the point at 1970-01-01 — the head of the
    // owner's timeline — instead of leaving it absent.
    const ms = Number.parseInt(raw, 10);
    return Number.isFinite(ms) && ms > 0 ? new Date(ms).toISOString() : null;
}
function parseTimestamp(value) {
    return parseIso(value) ?? parseTimestampMs(value);
}
function parseLatLonString(value) {
    const match = GEO_PAIR_RE.exec(value.replace(GEO_PREFIX_RE, ""));
    if (!match) {
        return null;
    }
    const latitude = Number.parseFloat(match[1] ?? "");
    const longitude = Number.parseFloat(match[2] ?? "");
    if (!(Number.isFinite(latitude) &&
        Number.isFinite(longitude) &&
        isValidLatLon(latitude, longitude))) {
        return null;
    }
    return { latitude, longitude };
}
function parseLatLon(value) {
    if (typeof value === "string") {
        return parseLatLonString(value);
    }
    const obj = asObject(value);
    if (!obj) {
        return null;
    }
    const latLng = asString(obj.latLng) ?? asString(obj.point);
    if (latLng) {
        return parseLatLonString(latLng);
    }
    const latitude = asNumber(obj.latitude) ??
        asNumber(obj.lat) ??
        scaleE7(obj.latitudeE7) ??
        scaleE7(obj.latE7) ??
        scaleE7(obj.sourceE7Lat);
    const longitude = asNumber(obj.longitude) ??
        asNumber(obj.lng) ??
        asNumber(obj.lon) ??
        scaleE7(obj.longitudeE7) ??
        scaleE7(obj.lngE7) ??
        scaleE7(obj.sourceE7Lng);
    if (latitude === null ||
        longitude === null ||
        !isValidLatLon(latitude, longitude)) {
        return null;
    }
    return { latitude, longitude };
}
function safeProbability(value) {
    const n = asNumber(value);
    return n === null || n < 0 || n > 1 ? null : n;
}
function firstActivityType(value) {
    if (!Array.isArray(value)) {
        return null;
    }
    const top = asObject(value[0]);
    const nested = Array.isArray(top?.activity)
        ? asObject(top.activity[0])
        : null;
    return asString(nested?.type);
}
function buildPoint(input) {
    return {
        id: hashId([
            "google_maps_point",
            input.sourceFormat,
            input.sourceKind,
            input.segmentId ?? "",
            input.timestamp,
            input.latitude.toFixed(7),
            input.longitude.toFixed(7),
        ].join("|")),
        timestamp: input.timestamp,
        latitude: input.latitude,
        longitude: input.longitude,
        accuracy_meters: input.accuracyMeters ?? null,
        altitude_m: input.altitudeM ?? null,
        velocity_mps: input.velocityMps ?? null,
        activity_type: input.activityType ?? null,
        segment_id: input.segmentId ?? null,
        source_format: input.sourceFormat,
        source_kind: input.sourceKind,
    };
}
function buildSegment(input) {
    return {
        id: hashId([
            "google_maps_segment",
            input.sourceFormat,
            input.segmentKind,
            input.startTime,
            input.endTime ?? "",
            input.placeId ?? "",
            input.activityType ?? "",
            input.latitude?.toFixed(7) ?? "",
            input.longitude?.toFixed(7) ?? "",
            // Only extend the hash input when this is actually an unrecognized
            // segment, so ids for the three understood kinds stay byte-identical
            // to those already collected (re-import must dedupe, not duplicate).
            ...(input.unrecognizedKind ? [input.unrecognizedKind] : []),
        ].join("|")),
        start_time: input.startTime,
        end_time: input.endTime ?? null,
        segment_kind: input.segmentKind,
        source_format: input.sourceFormat,
        latitude: input.latitude ?? null,
        longitude: input.longitude ?? null,
        place_id: input.placeId ?? null,
        semantic_type: input.semanticType ?? null,
        activity_type: input.activityType ?? null,
        probability: input.probability ?? null,
        unrecognized_kind: input.unrecognizedKind ?? null,
    };
}
function parseLegacyRecords(json) {
    const locations = Array.isArray(json.locations)
        ? json.locations
        : [];
    const points = [];
    for (const loc of locations) {
        const timestamp = parseTimestamp(loc.timestamp) ?? parseTimestampMs(loc.timestampMs);
        const latitude = scaleE7(loc.latitudeE7);
        const longitude = scaleE7(loc.longitudeE7);
        if (!timestamp ||
            latitude === null ||
            longitude === null ||
            !isValidLatLon(latitude, longitude)) {
            continue;
        }
        points.push(buildPoint({
            timestamp,
            latitude,
            longitude,
            accuracyMeters: loc.accuracy ?? null,
            altitudeM: loc.altitude ?? null,
            velocityMps: loc.velocity ?? null,
            activityType: firstActivityType(loc.activity),
            sourceFormat: "legacy_records",
            sourceKind: "raw_location",
        }));
    }
    return { points, segments: [] };
}
/** Keys `segmentTimes` reads — timing metadata, not a segment payload. */
const TIMING_SEGMENT_KEYS = new Set([
    "startTime",
    "startTimestamp",
    "endTime",
    "endTimestamp",
    "duration",
    "startTimeTimezoneUtcOffsetMinutes",
    "endTimeTimezoneUtcOffsetMinutes",
]);
function segmentTimes(segment) {
    const duration = asObject(segment.duration);
    return {
        startTime: parseTimestamp(segment.startTime) ??
            parseTimestamp(segment.startTimestamp) ??
            parseTimestamp(duration?.startTimestamp) ??
            parseTimestamp(duration?.startTime),
        endTime: parseTimestamp(segment.endTime) ??
            parseTimestamp(segment.endTimestamp) ??
            parseTimestamp(duration?.endTimestamp) ??
            parseTimestamp(duration?.endTime),
    };
}
function parseTimelinePathPoint(value, segmentId, fallbackTime, sourceFormat) {
    const obj = asObject(value);
    const timestamp = parseTimestamp(obj?.time) ?? parseTimestamp(obj?.timestamp) ?? fallbackTime;
    const latLon = parseLatLon(obj?.point ?? obj?.location ?? value);
    if (!(timestamp && latLon)) {
        return null;
    }
    return buildPoint({
        timestamp,
        latitude: latLon.latitude,
        longitude: latLon.longitude,
        segmentId,
        sourceFormat,
        sourceKind: "timeline_path",
    });
}
/** Payload keys a semanticSegments entry can carry that we know how to read. */
const MODELLED_SEGMENT_KEYS = ["visit", "activity", "timelinePath"];
/**
 * Classify a semanticSegments entry by which payload sub-object it carries.
 *
 * `path` is claimed only when a timelinePath is actually present. Anything
 * else — Google's `timelineMemory`, or whatever it ships next in this
 * undocumented format — classifies as `unrecognized` rather than falling
 * through to `path`. A mislabeled `path` segment with every location field
 * nulled is a confident lie about the owner's data; `unrecognized` keeps the
 * record without pretending to understand it.
 */
function semanticSegmentKind(visit, activity, hasTimelinePath) {
    if (visit) {
        return "visit";
    }
    if (activity) {
        return "activity";
    }
    return hasTimelinePath ? "path" : "unrecognized";
}
/**
 * The provider's own payload key(s) on an unrecognized segment, preserved
 * verbatim so the anomaly is inspectable instead of silent. Falls back to a
 * marker when the entry carries no key beyond the timestamps.
 */
function unrecognizedSegmentKey(segment) {
    const keys = Object.keys(segment).filter((k) => !(MODELLED_SEGMENT_KEYS.includes(k) || TIMING_SEGMENT_KEYS.has(k)));
    return keys.length > 0 ? keys.sort().join(",") : "(no payload key)";
}
function parseSemanticSegment(segment) {
    const { startTime, endTime } = segmentTimes(segment);
    const visit = asObject(segment.visit);
    const activity = asObject(segment.activity);
    const timelinePath = Array.isArray(segment.timelinePath)
        ? segment.timelinePath
        : [];
    const topVisit = asObject(visit?.topCandidate) ?? asObject(visit?.topPlace);
    const topActivity = asObject(activity?.topCandidate) ?? asObject(activity?.topActivity);
    const visitLocation = parseLatLon(topVisit?.placeLocation ??
        topVisit?.location ??
        visit?.placeLocation ??
        visit?.location);
    const segmentKind = semanticSegmentKind(visit, activity, timelinePath.length > 0);
    const activityType = asString(topActivity?.type) ?? asString(activity?.activityType);
    const placeId = asString(topVisit?.placeID) ??
        asString(topVisit?.placeId) ??
        asString(visit?.placeId);
    const semanticType = asString(topVisit?.semanticType) ?? asString(visit?.semanticType);
    const probability = safeProbability(topVisit?.probability ??
        topActivity?.probability ??
        visit?.probability ??
        activity?.probability);
    const segments = [];
    const points = [];
    let segmentId = null;
    if (startTime) {
        const seg = buildSegment({
            startTime,
            endTime,
            segmentKind,
            sourceFormat: "semantic_segments",
            latitude: visitLocation?.latitude ?? null,
            longitude: visitLocation?.longitude ?? null,
            placeId,
            semanticType,
            activityType,
            probability,
            unrecognizedKind: segmentKind === "unrecognized" ? unrecognizedSegmentKey(segment) : null,
        });
        segmentId = seg.id;
        segments.push(seg);
    }
    if (visitLocation && startTime) {
        points.push(buildPoint({
            timestamp: startTime,
            latitude: visitLocation.latitude,
            longitude: visitLocation.longitude,
            segmentId,
            sourceFormat: "semantic_segments",
            sourceKind: "visit_location",
        }));
    }
    for (const point of timelinePath) {
        const parsed = parseTimelinePathPoint(point, segmentId ?? "", startTime, "semantic_segments");
        if (parsed) {
            points.push(parsed);
        }
    }
    return { points, segments };
}
function parsePlaceVisitObject(placeVisit) {
    const { startTime, endTime } = segmentTimes(placeVisit);
    const location = asObject(placeVisit.location);
    const latLon = parseLatLon(location);
    if (!startTime) {
        return { points: [], segments: [] };
    }
    const seg = buildSegment({
        startTime,
        endTime,
        segmentKind: "visit",
        sourceFormat: "timeline_objects",
        latitude: latLon?.latitude ?? null,
        longitude: latLon?.longitude ?? null,
        placeId: asString(location?.placeId) ?? asString(location?.placeID),
        semanticType: asString(location?.semanticType),
    });
    const points = [];
    if (latLon) {
        points.push(buildPoint({
            timestamp: startTime,
            latitude: latLon.latitude,
            longitude: latLon.longitude,
            segmentId: seg.id,
            sourceFormat: "timeline_objects",
            sourceKind: "visit_location",
        }));
    }
    return { points, segments: [seg] };
}
function parseActivitySegmentObject(activitySegment) {
    const { startTime, endTime } = segmentTimes(activitySegment);
    const startLocation = parseLatLon(activitySegment.startLocation);
    const endLocation = parseLatLon(activitySegment.endLocation);
    if (!startTime) {
        return { points: [], segments: [] };
    }
    const seg = buildSegment({
        startTime,
        endTime,
        segmentKind: "activity",
        sourceFormat: "timeline_objects",
        latitude: startLocation?.latitude ?? null,
        longitude: startLocation?.longitude ?? null,
        activityType: asString(activitySegment.activityType),
    });
    const points = [];
    if (startLocation) {
        points.push(buildPoint({
            timestamp: startTime,
            latitude: startLocation.latitude,
            longitude: startLocation.longitude,
            segmentId: seg.id,
            sourceFormat: "timeline_objects",
            sourceKind: "activity_start",
            activityType: seg.activity_type,
        }));
    }
    if (endLocation && endTime) {
        points.push(buildPoint({
            timestamp: endTime,
            latitude: endLocation.latitude,
            longitude: endLocation.longitude,
            segmentId: seg.id,
            sourceFormat: "timeline_objects",
            sourceKind: "activity_end",
            activityType: seg.activity_type,
        }));
    }
    return { points, segments: [seg] };
}
function parseTimelineObject(value) {
    const obj = asObject(value);
    if (!obj) {
        return { points: [], segments: [] };
    }
    const results = [];
    const placeVisit = asObject(obj.placeVisit);
    const activitySegment = asObject(obj.activitySegment);
    if (placeVisit) {
        results.push(parsePlaceVisitObject(placeVisit));
    }
    if (activitySegment) {
        results.push(parseActivitySegmentObject(activitySegment));
    }
    return mergeResults(results);
}
function mergeResults(results) {
    const pointMap = new Map();
    const segmentMap = new Map();
    for (const result of results) {
        for (const point of result.points) {
            pointMap.set(point.id, point);
        }
        for (const segment of result.segments) {
            segmentMap.set(segment.id, segment);
        }
    }
    return {
        points: [...pointMap.values()].sort((a, b) => a.timestamp.localeCompare(b.timestamp)),
        segments: [...segmentMap.values()].sort((a, b) => a.start_time.localeCompare(b.start_time)),
    };
}
export function parseGoogleMapsExport(json) {
    const obj = asObject(json);
    const results = [];
    if (Array.isArray(obj?.locations)) {
        results.push(parseLegacyRecords(obj));
    }
    const semanticSegments = Array.isArray(obj?.semanticSegments)
        ? obj.semanticSegments
        : [];
    for (const segment of semanticSegments) {
        const parsed = asObject(segment);
        if (parsed) {
            results.push(parseSemanticSegment(parsed));
        }
    }
    const timelineObjects = [];
    if (Array.isArray(obj?.timelineObjects)) {
        timelineObjects.push(...obj.timelineObjects);
    }
    else if (Array.isArray(json)) {
        timelineObjects.push(...json);
    }
    for (const item of timelineObjects) {
        results.push(parseTimelineObject(item));
    }
    return mergeResults(results);
}
/** Parse one element from a streamed Timeline container through the same
 * pure dispatch used by the buffer-backed parser. */
export function parseGoogleMapsExportElement(format, value) {
    if (format === "legacy_records") {
        return parseGoogleMapsExport({ locations: [value] });
    }
    if (format === "semantic_segments") {
        return parseGoogleMapsExport({ semanticSegments: [value] });
    }
    return parseGoogleMapsExport([value]);
}
