import type { GoogleMapsSourceFormat } from "./types.ts";
export declare const GOOGLE_MAPS_SHAPE_KEYS: readonly ["locations", "semanticSegments", "timelineObjects"];
export declare const GOOGLE_MAPS_SHAPE_KEY_TO_FORMAT: Readonly<Record<(typeof GOOGLE_MAPS_SHAPE_KEYS)[number], GoogleMapsSourceFormat>>;
export type GoogleMapsStreamEvent = {
    readonly format: GoogleMapsSourceFormat;
    readonly kind: "element";
    readonly value: unknown;
} | {
    readonly format: GoogleMapsSourceFormat;
    readonly kind: "shape";
};
export interface GoogleMapsStreamOptions {
    readonly maxSingleElementBytes?: number;
}
export declare class GoogleMapsElementTooLargeError extends Error {
    constructor(message: string);
}
export declare class GoogleMapsUnsupportedShapeError extends Error {
    constructor(message: string);
}
type GoogleMapsStreamEventHandler = (event: GoogleMapsStreamEvent) => void | Promise<void>;
/**
 * Stream Timeline array elements without materializing the source file.
 * `shape` events preserve the empty-container evidence needed by the upload
 * validator; collector callers only consume `element` events.
 */
export declare function streamGoogleMapsExport(path: string, onEvent: GoogleMapsStreamEventHandler, options?: GoogleMapsStreamOptions): Promise<void>;
export {};
//# sourceMappingURL=archive-stream.d.ts.map