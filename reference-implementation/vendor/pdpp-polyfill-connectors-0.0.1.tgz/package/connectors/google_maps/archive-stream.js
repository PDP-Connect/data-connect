// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
// Bounded streaming reader for owner-provided Google Maps Timeline JSON.
// The upload validator uses the same parser shape, but the local collector
// also needs each normalized source element. Keeping that element stream here
// prevents the collector from holding both the raw artifact and a parsed
// object graph in memory at once.
import { createReadStream } from "node:fs";
import { JSONParser, TokenType } from "@streamparser/json";
const READ_BUFFER_SIZE = 65_536;
const DEFAULT_MAX_SINGLE_ELEMENT_BYTES = 4 * 1024 * 1024;
const FIRST_JSON_VALUE_RE = /[^\u0020\t\r\n\uFEFF]/u;
const ROOT_ARRAY_PATHS = ["$.*"];
const SEMANTIC_SEGMENT_PROJECTION_PATHS = [
    "$.semanticSegments.*.startTime",
    "$.semanticSegments.*.startTimestamp",
    "$.semanticSegments.*.endTime",
    "$.semanticSegments.*.endTimestamp",
    "$.semanticSegments.*.duration.startTimestamp",
    "$.semanticSegments.*.duration.startTime",
    "$.semanticSegments.*.duration.endTimestamp",
    "$.semanticSegments.*.duration.endTime",
    "$.semanticSegments.*.visit.topCandidate.placeLocation",
    "$.semanticSegments.*.visit.topCandidate.location",
    "$.semanticSegments.*.visit.topCandidate.placeId",
    "$.semanticSegments.*.visit.topCandidate.placeID",
    "$.semanticSegments.*.visit.topCandidate.semanticType",
    "$.semanticSegments.*.visit.topCandidate.probability",
    "$.semanticSegments.*.visit.topPlace.placeLocation",
    "$.semanticSegments.*.visit.topPlace.location",
    "$.semanticSegments.*.visit.topPlace.placeId",
    "$.semanticSegments.*.visit.topPlace.placeID",
    "$.semanticSegments.*.visit.topPlace.semanticType",
    "$.semanticSegments.*.visit.topPlace.probability",
    "$.semanticSegments.*.placeLocation",
    "$.semanticSegments.*.location",
    "$.semanticSegments.*.placeId",
    "$.semanticSegments.*.placeID",
    "$.semanticSegments.*.semanticType",
    "$.semanticSegments.*.probability",
    "$.semanticSegments.*.activity.topCandidate.type",
    "$.semanticSegments.*.activity.topCandidate.probability",
    "$.semanticSegments.*.activity.topActivity.type",
    "$.semanticSegments.*.activity.activityType",
    "$.semanticSegments.*.activity.probability",
    "$.semanticSegments.*.timelinePath.*",
];
const WRAPPED_ARRAY_ELEMENT_PATHS = [
    "$.locations.*",
    ...SEMANTIC_SEGMENT_PROJECTION_PATHS,
    "$.timelineObjects.*",
];
export const GOOGLE_MAPS_SHAPE_KEYS = [
    "locations",
    "semanticSegments",
    "timelineObjects",
];
export const GOOGLE_MAPS_SHAPE_KEY_TO_FORMAT = {
    locations: "legacy_records",
    semanticSegments: "semantic_segments",
    timelineObjects: "timeline_objects",
};
function semanticProjectionPath(stack, key) {
    if (stack.length < 3 ||
        stack[1]?.key !== "semanticSegments" ||
        typeof stack[2]?.key !== "number") {
        return null;
    }
    return [...stack.slice(3).map((entry) => String(entry.key)), String(key)];
}
function setProjectionValue(target, path, value) {
    let cursor = target;
    for (const part of path.slice(0, -1)) {
        const existing = cursor[part];
        if (!existing || typeof existing !== "object" || Array.isArray(existing)) {
            cursor[part] = {};
        }
        cursor = cursor[part];
    }
    const leaf = path.at(-1);
    if (leaf) {
        cursor[leaf] = value;
    }
}
function cloneProjection(projection) {
    return structuredClone(projection);
}
const SEMANTIC_SEGMENT_KNOWN_KEYS = new Set([
    "startTime",
    "startTimestamp",
    "endTime",
    "endTimestamp",
    "duration",
    "visit",
    "activity",
    "timelinePath",
]);
class SemanticSegmentKeyTracker {
    stack = [];
    onUnknownKey;
    nextSegmentIndex = 0;
    constructor(onUnknownKey) {
        this.onUnknownKey = onUnknownKey;
    }
    onToken(token, value) {
        if (token === TokenType.STRING) {
            this.handleString(value);
            return;
        }
        if (token === TokenType.LEFT_BRACE || token === TokenType.LEFT_BRACKET) {
            this.handleOpen(token);
            return;
        }
        if (token === TokenType.COMMA) {
            this.handleComma();
            return;
        }
        if (token === TokenType.RIGHT_BRACE || token === TokenType.RIGHT_BRACKET) {
            this.stack.pop();
        }
    }
    handleString(value) {
        const frame = this.stack.at(-1);
        if (frame?.kind !== "object" || frame.pendingKey !== undefined) {
            return;
        }
        const key = typeof value === "string" ? value : undefined;
        frame.pendingKey = key;
        if (key &&
            this.stack.length === 3 &&
            this.stack[1]?.format === "semantic_segments" &&
            !SEMANTIC_SEGMENT_KNOWN_KEYS.has(key) &&
            frame.segmentIndex !== undefined) {
            this.onUnknownKey(frame.segmentIndex, key);
        }
    }
    handleOpen(token) {
        const parent = this.stack.at(-1);
        const isSegment = token === TokenType.LEFT_BRACE &&
            parent?.kind === "array" &&
            parent.format === "semantic_segments" &&
            parent.segmentIndex === undefined;
        let segmentIndex = parent?.segmentIndex;
        if (isSegment) {
            segmentIndex = this.nextSegmentIndex;
            this.nextSegmentIndex += 1;
        }
        this.stack.push({
            kind: token === TokenType.LEFT_BRACE ? "object" : "array",
            pendingKey: undefined,
            segmentIndex,
            format: token === TokenType.LEFT_BRACKET &&
                (parent?.format === "semantic_segments" ||
                    parent?.pendingKey === "semanticSegments")
                ? "semantic_segments"
                : undefined,
        });
    }
    handleComma() {
        const frame = this.stack.at(-1);
        if (frame?.kind === "object") {
            frame.pendingKey = undefined;
        }
        else if (frame?.kind === "array") {
            frame.segmentIndex = undefined;
        }
    }
}
export class GoogleMapsElementTooLargeError extends Error {
    constructor(message) {
        super(message);
        this.name = "GoogleMapsElementTooLargeError";
    }
}
export class GoogleMapsUnsupportedShapeError extends Error {
    constructor(message) {
        super(message);
        this.name = "GoogleMapsUnsupportedShapeError";
    }
}
function formatForShapeKey(key) {
    return (GOOGLE_MAPS_SHAPE_KEY_TO_FORMAT[key] ?? null);
}
/**
 * Tracks only the root object's property/value boundary. The JSON parser's
 * `paths` option cannot both select wrapped array elements and observe a
 * non-array value at the same property without retaining that whole value.
 * Token observation supplies the missing shape proof while retaining no
 * source data of its own.
 */
class RootShapeTracker {
    stack = [];
    onArrayConfirmed;
    rootStarted = false;
    invalidRecognizedKey = null;
    constructor(onArrayConfirmed) {
        this.onArrayConfirmed = onArrayConfirmed;
    }
    get invalidKey() {
        return this.invalidRecognizedKey;
    }
    onToken(token, value) {
        if (token === TokenType.SEPARATOR) {
            return;
        }
        const frame = this.stack.at(-1);
        if (!frame) {
            this.startRoot(token);
            return;
        }
        if (frame.kind === "object") {
            this.onObjectToken(frame, token, value);
            return;
        }
        this.onArrayToken(frame, token);
    }
    startRoot(token) {
        if (this.rootStarted) {
            return;
        }
        this.rootStarted = true;
        if (token === TokenType.LEFT_BRACE) {
            this.stack.push({
                kind: "object",
                pendingKey: undefined,
                state: "key_or_end",
            });
            return;
        }
        if (token === TokenType.LEFT_BRACKET) {
            this.stack.push({
                kind: "array",
                state: "value_or_end",
                confirmedFormat: "timeline_objects",
            });
        }
    }
    onObjectToken(frame, token, value) {
        if (frame.state === "key_or_end") {
            if (token === TokenType.STRING && typeof value === "string") {
                frame.pendingKey = value;
                frame.state = "colon";
            }
            else if (token === TokenType.RIGHT_BRACE) {
                this.finishContainer();
            }
            return;
        }
        if (frame.state === "colon") {
            if (token === TokenType.COLON) {
                frame.state = "value";
            }
            return;
        }
        if (frame.state === "value") {
            this.startObjectValue(frame, token);
            return;
        }
        if (token === TokenType.COMMA) {
            frame.state = "key_or_end";
        }
        else if (token === TokenType.RIGHT_BRACE) {
            this.finishContainer();
        }
    }
    startObjectValue(frame, token) {
        const key = frame.pendingKey;
        const format = this.stack.length === 1 && key ? formatForShapeKey(key) : null;
        frame.pendingKey = undefined;
        frame.state = "comma_or_end";
        if (format && token !== TokenType.LEFT_BRACKET) {
            this.invalidRecognizedKey ??= key ?? "(unknown)";
        }
        if (token === TokenType.LEFT_BRACE) {
            this.stack.push({
                kind: "object",
                pendingKey: undefined,
                state: "key_or_end",
            });
            return;
        }
        if (token === TokenType.LEFT_BRACKET) {
            this.stack.push({
                kind: "array",
                state: "value_or_end",
                confirmedFormat: format ?? undefined,
            });
        }
    }
    onArrayToken(frame, token) {
        if (frame.state === "value_or_end") {
            if (token === TokenType.RIGHT_BRACKET) {
                this.finishContainer();
                return;
            }
            frame.state = "comma_or_end";
            if (token === TokenType.LEFT_BRACE) {
                this.stack.push({
                    kind: "object",
                    pendingKey: undefined,
                    state: "key_or_end",
                });
            }
            else if (token === TokenType.LEFT_BRACKET) {
                this.stack.push({
                    kind: "array",
                    state: "value_or_end",
                    confirmedFormat: undefined,
                });
            }
            return;
        }
        if (token === TokenType.COMMA) {
            frame.state = "value_or_end";
        }
        else if (token === TokenType.RIGHT_BRACKET) {
            this.finishContainer();
        }
    }
    finishContainer() {
        const frame = this.stack.pop();
        if (frame?.kind === "array" && frame.confirmedFormat) {
            this.onArrayConfirmed(frame.confirmedFormat);
        }
    }
}
/**
 * Counts selected array-element bytes before the JSON tokenizer sees them.
 * Token callbacks cannot do this for primitive values because the tokenizer
 * buffers a primitive until its closing token. This scanner keeps only JSON
 * structure and the current root key; it never retains an element value.
 */
class ElementByteTracker {
    stack = [];
    mode = "normal";
    primitiveIsDirectArrayElement = false;
    stringIsKey = false;
    stringRaw = "";
    maxElementBytes;
    constructor(maxElementBytes) {
        this.maxElementBytes = maxElementBytes;
    }
    consume(text) {
        for (const char of text) {
            this.consumeChar(char, char.charCodeAt(0) < 0x80 ? 1 : Buffer.byteLength(char, "utf8"));
        }
    }
    consumeChar(char, bytes) {
        if (this.mode === "string" || this.mode === "string_escape") {
            this.consumeStringChar(char, bytes);
            return;
        }
        if (this.mode === "primitive") {
            this.consumePrimitiveChar(char, bytes);
            return;
        }
        this.consumeNormalChar(char, bytes);
    }
    consumeStringChar(char, bytes) {
        this.count(bytes);
        if (this.mode === "string_escape") {
            if (this.stringIsKey) {
                this.stringRaw += char;
            }
            this.mode = "string";
        }
        else if (char === "\\") {
            if (this.stringIsKey) {
                this.stringRaw += char;
            }
            this.mode = "string_escape";
        }
        else if (char === '"') {
            this.finishString();
        }
        else if (this.stringIsKey) {
            this.stringRaw += char;
        }
    }
    consumePrimitiveChar(char, bytes) {
        if (isJsonDelimiter(char)) {
            this.finishPrimitive();
            this.consumeChar(char, bytes);
            return;
        }
        this.count(bytes);
    }
    consumeNormalChar(char, bytes) {
        if (char === '"') {
            const frame = this.stack.at(-1);
            this.stringIsKey =
                frame?.kind === "object" && frame.root && frame.state === "key_or_end";
            if (!this.stringIsKey) {
                this.beginScalar();
            }
            this.count(bytes);
            this.stringRaw = "";
            this.mode = "string";
            return;
        }
        if (char === "{" || char === "[") {
            this.beginContainer(char === "{" ? "object" : "array");
            this.count(bytes);
            return;
        }
        if (char === "}" || char === "]") {
            this.count(bytes);
            this.finishContainer(char);
            return;
        }
        if (char === ":" || char === ",") {
            this.count(bytes);
            this.transition(char);
            return;
        }
        if (isJsonWhitespace(char)) {
            this.count(bytes);
            return;
        }
        this.beginScalar();
        this.count(bytes);
        this.mode = "primitive";
    }
    beginContainer(kind) {
        const parent = this.stack.at(-1);
        if (!parent) {
            this.stack.push(kind === "object"
                ? { kind, pendingKey: undefined, root: true, state: "key_or_end" }
                : {
                    activeElement: false,
                    elementBytes: 0,
                    excludeFromParentElementBytes: false,
                    format: "timeline_objects",
                    kind,
                    state: "value_or_end",
                });
            return;
        }
        if (parent.kind === "object") {
            if (parent.state !== "value") {
                return;
            }
            const format = parent.root
                ? (formatForShapeKey(parent.pendingKey ?? "") ?? undefined)
                : undefined;
            const isTimelinePath = parent.pendingKey === "timelinePath";
            parent.pendingKey = undefined;
            parent.state = "comma_or_end";
            this.stack.push(kind === "object"
                ? { kind, pendingKey: undefined, root: false, state: "key_or_end" }
                : {
                    activeElement: false,
                    elementBytes: 0,
                    excludeFromParentElementBytes: isTimelinePath,
                    format,
                    kind,
                    state: "value_or_end",
                });
            return;
        }
        if (parent.state !== "value_or_end") {
            return;
        }
        parent.activeElement = true;
        parent.state = "comma_or_end";
        this.stack.push(kind === "object"
            ? { kind, pendingKey: undefined, root: false, state: "key_or_end" }
            : {
                activeElement: false,
                elementBytes: 0,
                excludeFromParentElementBytes: false,
                format: undefined,
                kind,
                state: "value_or_end",
            });
    }
    beginScalar() {
        const frame = this.stack.at(-1);
        if (!frame) {
            return;
        }
        if (frame.kind === "object") {
            if (frame.state === "value") {
                frame.pendingKey = undefined;
                frame.state = "comma_or_end";
            }
            return;
        }
        if (frame.state === "value_or_end") {
            frame.activeElement = true;
            frame.elementBytes = 0;
            frame.state = "primitive";
            this.primitiveIsDirectArrayElement = true;
        }
    }
    finishString() {
        if (this.stringIsKey) {
            const frame = this.stack.at(-1);
            if (frame?.kind === "object" && frame.state === "key_or_end") {
                frame.pendingKey = decodeJsonString(this.stringRaw);
                frame.state = "colon";
            }
        }
        else {
            this.finishPrimitive();
        }
        this.mode = "normal";
        this.stringIsKey = false;
        this.stringRaw = "";
    }
    finishPrimitive() {
        if (this.primitiveIsDirectArrayElement) {
            const frame = this.stack.at(-1);
            if (frame?.kind === "array" && frame.state === "primitive") {
                frame.activeElement = false;
                frame.state = "comma_or_end";
                frame.elementBytes = 0;
            }
        }
        this.primitiveIsDirectArrayElement = false;
        this.mode = "normal";
    }
    finishContainer(char) {
        const frame = this.stack.at(-1);
        if (!frame ||
            (char === "}" && frame.kind !== "object") ||
            (char === "]" && frame.kind !== "array")) {
            return;
        }
        this.stack.pop();
        const parent = this.stack.at(-1);
        if (parent?.kind === "array" &&
            parent.activeElement &&
            parent.state === "comma_or_end") {
            parent.activeElement = false;
            parent.elementBytes = 0;
        }
    }
    transition(char) {
        const frame = this.stack.at(-1);
        if (!frame) {
            return;
        }
        if (frame.kind === "object") {
            if (char === ":" && frame.state === "colon") {
                frame.state = "value";
            }
            else if (char === "," && frame.state === "comma_or_end") {
                frame.state = "key_or_end";
            }
            return;
        }
        if (char === "," && frame.state === "comma_or_end") {
            frame.state = "value_or_end";
            frame.activeElement = false;
        }
    }
    count(bytes) {
        const pathFrame = this.stack.find((candidate) => candidate.kind === "array" &&
            candidate.excludeFromParentElementBytes &&
            candidate.activeElement);
        if (pathFrame) {
            pathFrame.elementBytes += bytes;
            if (pathFrame.elementBytes > this.maxElementBytes) {
                throw new GoogleMapsElementTooLargeError(`a single Timeline path point exceeded ${String(this.maxElementBytes)} bytes`);
            }
            return;
        }
        const frame = this.stack.find((candidate) => candidate.kind === "array" &&
            candidate.format !== undefined &&
            candidate.activeElement);
        if (!frame) {
            return;
        }
        // `semanticSegments` entries are provider aggregates. In particular, a
        // single segment can contain an arbitrarily long timelinePath, while the
        // collector turns that path into one bounded point record per location.
        // Applying the per-element guard here rejects the aggregate before that
        // semantic normalization can happen and reports record_too_large on both
        // output streams. The guard remains active for the already-bounded
        // location/timeline-object element shapes.
        if (frame.format === "semantic_segments" &&
            this.stack.some((candidate) => candidate.kind === "array" && candidate.excludeFromParentElementBytes)) {
            return;
        }
        frame.elementBytes += bytes;
        if (frame.elementBytes > this.maxElementBytes) {
            throw new GoogleMapsElementTooLargeError(`a single Timeline array element exceeded ${String(this.maxElementBytes)} bytes`);
        }
    }
}
function isJsonWhitespace(char) {
    return char === " " || char === "\t" || char === "\r" || char === "\n";
}
function isJsonDelimiter(char) {
    return isJsonWhitespace(char) || char === "," || char === "]" || char === "}";
}
function decodeJsonString(raw) {
    try {
        return JSON.parse(`"${raw}"`);
    }
    catch {
        return raw;
    }
}
function formatForElementEvent(key, stack, parent) {
    if (!Array.isArray(parent)) {
        return null;
    }
    if (stack.length === 1) {
        return typeof key === "number" ? "timeline_objects" : null;
    }
    if (stack.length === 2) {
        const parentKey = stack[1]?.key;
        return typeof parentKey === "string" ? formatForShapeKey(parentKey) : null;
    }
    return null;
}
async function drain(pending, onEvent) {
    const batch = pending.splice(0);
    for (const event of batch) {
        const result = onEvent(event);
        if (result !== undefined) {
            await result;
        }
    }
}
function createParser(paths, shapeTracker, onElement, onEnd, semanticRun) {
    const parser = new JSONParser({
        emitPartialValues: true,
        keepStack: false,
        paths: [...paths],
    });
    const unknownKeys = new Map();
    const keyTracker = new SemanticSegmentKeyTracker((index, key) => {
        const keys = unknownKeys.get(index) ?? new Set();
        keys.add(key);
        unknownKeys.set(index, keys);
    });
    parser.onToken = ({ token, value }) => {
        shapeTracker.onToken(token, value);
        keyTracker.onToken(token, value);
    };
    let semanticIndex = null;
    let semanticProjection = null;
    let semanticHasPath = false;
    const flushSemanticProjection = () => {
        if (semanticProjection) {
            const index = semanticIndex;
            if (index !== null) {
                for (const key of unknownKeys.get(index) ?? []) {
                    semanticProjection[key] ??= {};
                }
                if (semanticRun) {
                    semanticRun.onComplete(index, cloneProjection(semanticProjection), semanticHasPath);
                }
                else if (!semanticHasPath) {
                    onElement("semantic_segments", cloneProjection(semanticProjection));
                }
            }
        }
        if (semanticIndex !== null) {
            unknownKeys.delete(semanticIndex);
        }
        semanticProjection = null;
        semanticIndex = null;
        semanticHasPath = false;
    };
    const handleSemanticValue = (info) => {
        const semanticPath = semanticProjectionPath(info.stack, info.key);
        if (!semanticPath) {
            return false;
        }
        const nextIndex = info.stack[2]?.key;
        if (typeof nextIndex !== "number") {
            return true;
        }
        if (semanticIndex !== null && semanticIndex !== nextIndex) {
            flushSemanticProjection();
        }
        semanticIndex = nextIndex;
        semanticProjection ??= { timelinePath: undefined };
        if (semanticPath.at(-2) === "timelinePath") {
            semanticHasPath = true;
            semanticProjection.timelinePath = [info.value];
            for (const key of unknownKeys.get(nextIndex) ?? []) {
                semanticProjection[key] ??= {};
            }
            semanticRun?.onPoint?.(nextIndex, info.value);
            if (!semanticRun) {
                onElement("semantic_segments", cloneProjection(semanticProjection));
            }
            semanticProjection.timelinePath = undefined;
        }
        else {
            setProjectionValue(semanticProjection, semanticPath, info.value);
        }
        return true;
    };
    parser.onValue = (info) => {
        if (info.partial) {
            return;
        }
        if (handleSemanticValue(info)) {
            return;
        }
        const format = formatForElementEvent(info.key, info.stack, info.parent);
        if (!format || info.value === undefined) {
            return;
        }
        onElement(format, info.value);
    };
    parser.onEnd = () => {
        flushSemanticProjection();
        onEnd();
    };
    return parser;
}
function initializeParser(text, shapeTracker, onElement, onEnd, semanticRun, pathsOverride) {
    const firstIndex = text.search(FIRST_JSON_VALUE_RE);
    if (firstIndex === -1) {
        return null;
    }
    const paths = pathsOverride ??
        (text[firstIndex] === "[" ? ROOT_ARRAY_PATHS : WRAPPED_ARRAY_ELEMENT_PATHS);
    return {
        parser: createParser(paths, shapeTracker, onElement, onEnd, semanticRun),
        text: text.slice(firstIndex),
    };
}
async function feedParserChunk(parser, text, elementByteTracker, pending, onEvent) {
    if (parser.isEnded) {
        // Keep feeding later chunks so the tokenizer can reject trailing
        // non-whitespace instead of silently stopping at the first root.
        parser.write(text);
        return;
    }
    elementByteTracker.consume(text);
    parser.write(text);
    await drain(pending, onEvent);
}
async function replaySemanticPath(path, maxSingleElementBytes, semanticProjections, onEvent) {
    const pending = [];
    const onElement = (format, value) => {
        pending.push({ format, kind: "element", value });
    };
    const semanticRun = {
        onComplete(index) {
            semanticProjections.delete(index);
        },
        onPoint(index, point) {
            const projection = semanticProjections.get(index);
            if (!projection) {
                return;
            }
            onElement("semantic_segments", {
                ...cloneProjection(projection),
                timelinePath: [point],
            });
        },
    };
    const shapeTracker = new RootShapeTracker(() => undefined);
    const elementByteTracker = new ElementByteTracker(maxSingleElementBytes);
    let parser = null;
    const stream = createReadStream(path, {
        encoding: "utf8",
        highWaterMark: READ_BUFFER_SIZE,
    });
    try {
        for await (const chunk of stream) {
            const text = typeof chunk === "string" ? chunk : chunk.toString("utf8");
            let toFeed = text;
            if (!parser) {
                const initialized = initializeParser(text, shapeTracker, onElement, () => undefined, semanticRun, SEMANTIC_SEGMENT_PROJECTION_PATHS);
                if (!initialized) {
                    continue;
                }
                ({ parser, text: toFeed } = initialized);
            }
            await feedParserChunk(parser, toFeed, elementByteTracker, pending, onEvent);
        }
    }
    finally {
        stream.destroy();
    }
    if (parser && !parser.isEnded) {
        parser.end();
    }
    await drain(pending, onEvent);
}
/**
 * Stream Timeline array elements without materializing the source file.
 * `shape` events preserve the empty-container evidence needed by the upload
 * validator; collector callers only consume `element` events.
 */
export async function streamGoogleMapsExport(path, onEvent, options = {}) {
    const maxSingleElementBytes = options.maxSingleElementBytes ?? DEFAULT_MAX_SINGLE_ELEMENT_BYTES;
    const pending = [];
    const seenShapes = new Set();
    const semanticProjections = new Map();
    const markShape = (format) => {
        if (seenShapes.has(format)) {
            return;
        }
        seenShapes.add(format);
        pending.push({ format, kind: "shape" });
    };
    const shapeTracker = new RootShapeTracker(markShape);
    const elementByteTracker = new ElementByteTracker(maxSingleElementBytes);
    const onElement = (format, value) => {
        pending.push({ format, kind: "element", value });
    };
    const firstSemanticRun = {
        onComplete(index, projection, hasPath) {
            if (hasPath) {
                semanticProjections.set(index, projection);
            }
            else {
                onElement("semantic_segments", projection);
            }
        },
    };
    let parser = null;
    const stream = createReadStream(path, {
        encoding: "utf8",
        highWaterMark: READ_BUFFER_SIZE,
    });
    try {
        for await (const chunk of stream) {
            const text = typeof chunk === "string" ? chunk : chunk.toString("utf8");
            let toFeed = text;
            if (!parser) {
                const initialized = initializeParser(text, shapeTracker, onElement, () => undefined, firstSemanticRun);
                if (!initialized) {
                    continue;
                }
                ({ parser, text: toFeed } = initialized);
            }
            await feedParserChunk(parser, toFeed, elementByteTracker, pending, onEvent);
        }
    }
    finally {
        stream.destroy();
    }
    if (!parser) {
        throw new Error("google_maps: Timeline document is empty or whitespace-only");
    }
    if (!parser.isEnded) {
        parser.end();
        if (!parser.isEnded) {
            throw new Error("google_maps: Timeline document did not close (truncated or malformed)");
        }
    }
    if (seenShapes.has("semantic_segments")) {
        await replaySemanticPath(path, maxSingleElementBytes, semanticProjections, onEvent);
    }
    if (shapeTracker.invalidKey) {
        throw new GoogleMapsUnsupportedShapeError(`google_maps: recognized Timeline key ${shapeTracker.invalidKey} did not contain an array`);
    }
    if (seenShapes.size === 0) {
        throw new GoogleMapsUnsupportedShapeError("google_maps: Timeline document did not contain a recognized Timeline array");
    }
    await drain(pending, onEvent);
}
