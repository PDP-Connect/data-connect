import { z } from "zod";
export declare const timelinePointSchema: z.ZodObject<{
    id: z.ZodString;
    timestamp: z.ZodString;
    latitude: z.ZodNumber;
    longitude: z.ZodNumber;
    accuracy_meters: z.ZodNullable<z.ZodNumber>;
    altitude_m: z.ZodNullable<z.ZodNumber>;
    velocity_mps: z.ZodNullable<z.ZodNumber>;
    activity_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    segment_id: z.ZodNullable<z.ZodString>;
    source_format: z.ZodEnum<{
        legacy_records: "legacy_records";
        semantic_segments: "semantic_segments";
        timeline_objects: "timeline_objects";
    }>;
    source_kind: z.ZodEnum<{
        activity_end: "activity_end";
        activity_start: "activity_start";
        raw_location: "raw_location";
        timeline_path: "timeline_path";
        visit_location: "visit_location";
    }>;
}, z.core.$strip>;
export declare const timelineSegmentSchema: z.ZodObject<{
    id: z.ZodString;
    start_time: z.ZodString;
    end_time: z.ZodNullable<z.ZodString>;
    segment_kind: z.ZodEnum<{
        activity: "activity";
        path: "path";
        unrecognized: "unrecognized";
        visit: "visit";
    }>;
    source_format: z.ZodEnum<{
        legacy_records: "legacy_records";
        semantic_segments: "semantic_segments";
        timeline_objects: "timeline_objects";
    }>;
    latitude: z.ZodNullable<z.ZodNumber>;
    longitude: z.ZodNullable<z.ZodNumber>;
    place_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    semantic_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    activity_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    probability: z.ZodNullable<z.ZodNumber>;
    unrecognized_kind: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map