// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
export class CodexArtifactLedger {
    #enabled;
    #outstanding = new Set();
    #captured = new Map();
    #backfilled = new Set();
    #pendingUpload = 0;
    constructor(options) {
        this.#enabled = options.enabled;
    }
    /** True when this run was asked to capture bodies at all. */
    get enabled() {
        return this.#enabled;
    }
    /**
     * Bodies spooled this run whose upload is still owed.
     *
     * Counted at capture time only — see `hasUploadTransport` in
     * `src/artifact-capture.ts` for why the obligation is reported rather than
     * enqueued as a `blob_upload` outbox row. Reporting keeps a
     * spooled-but-undelivered body VISIBLE instead of implying completion.
     */
    get pendingUpload() {
        return this.#pendingUpload;
    }
    /** Note the outcome for one rollout file, keyed by its cursor key (UUID). */
    record(cursorKey, status, sha256) {
        if (!this.#enabled) {
            return;
        }
        if (status === "captured" && sha256) {
            this.#outstanding.delete(cursorKey);
            this.#captured.set(cursorKey, sha256);
            this.#pendingUpload += 1;
            return;
        }
        this.#outstanding.add(cursorKey);
    }
    /** True when this file's body is still owed. */
    isOutstanding(cursorKey) {
        return this.#outstanding.has(cursorKey);
    }
    /**
     * Note that a body was captured WITHOUT reparsing its file — the skip path's
     * backfill.
     *
     * Such a run builds no aggregate, so nothing in the ordinary emission path
     * knows the session's stored row just became stale. Recording it here is what
     * lets the run decide it owes a targeted session update, rather than leaving
     * the digest visible only to the cursor.
     */
    noteBackfilled(cursorKey) {
        this.#backfilled.add(cursorKey);
    }
    /** Cursor keys whose bodies were backfilled by a skip-path capture this run. */
    get backfilled() {
        return this.#backfilled;
    }
    /**
     * The `captured_sha256` to persist for this file, or undefined to withhold
     * it.
     *
     * Withholding for an outstanding artifact is what makes the next run retry
     * this file. A run that cannot capture at all persists nothing, so it
     * neither claims a capture it did not make nor erases one an earlier run
     * legitimately recorded (`priorCaptured` carries that forward).
     */
    capturedMarker(cursorKey, priorCaptured) {
        if (!this.#enabled) {
            return priorCaptured;
        }
        if (this.isOutstanding(cursorKey)) {
            return undefined;
        }
        return this.#captured.get(cursorKey) ?? priorCaptured;
    }
    /**
     * Whether an unchanged file's body is already held, given what the last run
     * persisted.
     *
     * When capture is enabled, only a recorded `captured_sha256` settles a file.
     * Its absence means the body state is unknown — a pre-capture cursor, or a
     * run that had no stores — so the file is revisited once to backfill. When
     * capture is not enabled this is vacuously true, so a run that cannot
     * capture does not re-read files it cannot help.
     */
    isSettled(cursorKey, priorCaptured) {
        if (this.isOutstanding(cursorKey)) {
            return false;
        }
        if (!this.#enabled) {
            return true;
        }
        return priorCaptured !== undefined;
    }
    get size() {
        return this.#outstanding.size;
    }
}
