#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * PDPP Codex CLI Connector (v0.2.0)
 *
 * Reads OpenAI Codex CLI's on-disk state. No auth required; runs against
 * local files under ~/.codex (overridable).
 *
 * Streams:
 *   sessions        — one record per thread. Source of truth is
 *                     `state_5.sqlite#threads` (title, archived, tokens_used,
 *                     first_user_message, sandbox_policy, approval_mode, …),
 *                     enriched with rollout-derived message/tool-call counts.
 *                     Falls back to rollout-only records for sessions that
 *                     are on disk but not in state_5.sqlite.
 *   messages        — user/assistant text messages (from rollout-*.jsonl).
 *   function_calls  — shell/tool invocations + outputs (from rollout-*.jsonl).
 *   rules           — personal trust-registry entries (~/.codex/rules/*.rules),
 *                     one record per rule line. The stream is intentionally
 *                     named after the real local directory rather than the
 *                     backlog shorthand "approval_rules".
 *   prompts         — user-authored prompts (~/.codex/prompts/*.md).
 *   skills          — user-authored skills (~/.codex/skills/<name>/SKILL.md).
 *
 * Incremental: rollout parsing uses an append-safe per-file cursor
 * (`file_cursors`: identity + committed byte offset + prefix integrity guard),
 * so a long-lived append-only rollout file is tailed from its last committed
 * boundary instead of fully reparsed on every append. Unchanged files are
 * skipped; new files parse in full; truncated/replaced files fall back to a
 * full reparse. The legacy whole-file `file_mtimes` cursor is still read for
 * backward compatibility (one-time reparse on upgrade). `state_5.sqlite` is
 * opened READ-ONLY so we never risk corrupting live Codex state.
 *
 * Env overrides:
 *   CODEX_HOME               default ~/.codex (parent of all paths below)
 *   CODEX_SESSIONS_DIR       default $CODEX_HOME/sessions
 *   CODEX_SESSIONS_ARCHIVE_DIR default $CODEX_HOME/sessions-archive
 *   CODEX_STATE_DB           default $CODEX_HOME/state_5.sqlite
 *   CODEX_RULES_DIR          default $CODEX_HOME/rules
 *   CODEX_PROMPTS_DIR        default $CODEX_HOME/prompts
 *   CODEX_SKILLS_DIR         default $CODEX_HOME/skills
 *
 * Two rollout roots: `CODEX_SESSIONS_DIR` is where Codex itself writes and
 * appends rollout files. A separate, external archival policy (outside this
 * repo — see connectors/codex/ARCHIVAL-CONTRACT.md) one-way-moves rollout
 * files older than some threshold into `CODEX_SESSIONS_ARCHIVE_DIR`, using
 * the same yyyy/mm/dd layout. Codex itself never writes to the archive root.
 * This connector scans BOTH roots and merges them; rollout files are
 * identified by the session UUID embedded in their filename (see
 * `extractRolloutUuidFromFilename` in parsers.ts), never by path, so a file
 * relocated from one root to the other is recognized as the same file and is
 * neither reparsed from scratch nor double-emitted.
 */
import { createHash } from "node:crypto";
import { createReadStream, statSync } from "node:fs";
import { readdir, stat } from "node:fs/promises";
import { homedir } from "node:os";
import { basename, isAbsolute, join, sep } from "node:path";
import { createInterface } from "node:readline";
import { DatabaseSync } from "node:sqlite";
import { isMainModule, resourceSet, stringifyForJsonl, } from "@pdpp/connector-protocol";
import { readBoundedFilePreview } from "../../src/bounded-file-preview.js";
import { dateDirectoryInRange, enumerationScopeFingerprint, isPathWithinSourceRoots, readEnumerationScope, scopeBoundsEnumeration, } from "../../src/collection-scope-enumeration.js";
import { flushAndExitAfterRuntimeAck } from "../../src/connector-exit.js";
import { openCarryForwardCursor, } from "../../src/fingerprint-cursor.js";
import { LocalJsonlMalformedLineError } from "../../src/local-jsonl-cursor.js";
import { buildCoverageDiagnosticsStateSnapshot, buildDerivedCoverageRecord, buildLocalSourceInventory, listDirectoryInventory, openInventoryFingerprintCursor, } from "../../src/local-source-inventory.js";
import { buildPromptRecord, buildRolloutOnlySessionRecord, buildRuleRecord, buildSkillRecord, buildThreadSessionRecord, extendTimestampRange, extractMessageText, extractRolloutUuidFromFilename, isRolloutFile, isSkippableRulesLine, parseFrontmatter, payloadOutputPreview, RULES_SUFFIX_RE, splitRulesLines, TWO_DIGIT_DIR_RE, textPreview, YEAR_DIR_RE, } from "./parsers.js";
import { validateRecord } from "./schemas.js";
// Literal values keep every emitted reason visible to the completeness scan.
const JSONL_GAP_SKIP_REASON = {
    malformed_jsonl_line: "malformed_jsonl_line",
    non_object_jsonl_record: "non_object_jsonl_record",
    truncated_jsonl_tail: "truncated_jsonl_tail",
};
const DEFAULT_ACTIVE_ROLLOUT_QUIET_MS = 120_000;
const ACTIVE_ROLLOUT_QUIET_MS_ENV = "PDPP_CODEX_ACTIVE_ROLLOUT_QUIET_MS";
// Bytes of file prefix covered by the rollout cursor integrity guard. Rollout
// files are append-only, so a changed first 64 KiB means the file was
// truncated/rotated/replaced and the stored byte offset is no longer valid.
// Bounded so the guard is O(1) regardless of how large the rollout file grows.
const GUARD_PREFIX_BYTES = 64 * 1024;
// Enrollment / connector-version upgrades can arrive with only legacy file_mtimes
// state, and rotated/truncated/replaced rollout files fail the prefix-integrity
// guard. Both paths force a parse from byte offset 0, so keep unmatched
// function-call state bounded across full replay.
const MAX_PENDING_FUNCTION_CALLS = 1024;
let stdoutDrainPromise = null;
const emit = (m) => {
    const ok = process.stdout.write(stringifyForJsonl(m));
    if (!ok && stdoutDrainPromise === null) {
        stdoutDrainPromise = new Promise((resolve) => {
            process.stdout.once("drain", () => {
                stdoutDrainPromise = null;
                resolve();
            });
        });
    }
};
async function waitForEmitDrain() {
    if (stdoutDrainPromise !== null) {
        await stdoutDrainPromise;
    }
}
const flushAndExit = (code) => {
    flushAndExitAfterRuntimeAck(code);
};
const fail = (m, r = false) => {
    emit({
        type: "DONE",
        status: "failed",
        records_emitted: 0,
        error: { message: m, retryable: r },
    });
    flushAndExit(1);
};
export const CODEX_KNOWN_LOCAL_STORES = [
    {
        store: "sessions",
        relativePath: "sessions",
        stream: "sessions",
        classification: "collect",
        reason: "declared rollout source",
    },
    {
        store: "sessions_archive",
        relativePath: "sessions-archive",
        stream: "sessions",
        classification: "collect",
        reason: "declared rollout source: the external archival policy's one-way relocation target for rollout files older than its threshold (see ARCHIVAL-CONTRACT.md); absence is normal on a host with nothing archived yet",
    },
    {
        store: "state_db",
        relativePath: "state_5.sqlite",
        stream: "sessions",
        classification: "collect",
        reason: "declared thread metadata source opened read-only",
    },
    {
        store: "rules",
        relativePath: "rules",
        stream: "rules",
        classification: "collect",
        reason: "declared user-authored rules source",
    },
    {
        store: "prompts",
        relativePath: "prompts",
        stream: "prompts",
        classification: "collect",
        reason: "declared user-authored prompts source",
    },
    {
        store: "skills",
        relativePath: "skills",
        stream: "skills",
        classification: "collect",
        reason: "declared user-authored skills source",
    },
    {
        store: "history",
        relativePath: "history.jsonl",
        stream: "history",
        classification: "inventory_only",
        reason: "metadata-only until prompt-history payload contract is approved",
    },
    {
        store: "session_index",
        relativePath: "session_index.jsonl",
        stream: "session_index",
        classification: "inventory_only",
        reason: "metadata-only until session-index payload contract is approved",
    },
    {
        store: "shell_snapshots",
        relativePath: "shell-snapshots",
        stream: "shell_snapshots",
        classification: "inventory_only",
        reason: "shell content requires redaction review before payload collection",
    },
    {
        store: "memories",
        relativePath: "memories",
        stream: null,
        classification: "inventory_only",
        reason: "deferred private local store; diagnostics only until a general Codex memory surface is approved",
    },
    {
        store: "context_mode",
        relativePath: "context-mode",
        stream: null,
        classification: "inventory_only",
        reason: "user-specific local convention; diagnostics only, not a general Codex stream",
    },
    {
        store: "config",
        relativePath: "config.toml",
        stream: "config_inventory",
        classification: "inventory_only",
        reason: "configuration is inventoried without payload content",
    },
    {
        store: "cache",
        relativePath: "cache",
        stream: "cache_inventory",
        classification: "inventory_only",
        reason: "raw cache payloads may contain sensitive tool output",
    },
    {
        store: "auth",
        relativePath: "auth.json",
        stream: null,
        classification: "exclude",
        reason: "auth-adjacent credential material is never emitted",
    },
];
class RolloutSourceError extends Error {
    path;
    constructor(path, cause) {
        super("Codex rollout source could not be read", { cause });
        this.path = path;
    }
}
/** Only filesystem failures are wrapped; consumer/transport errors stay fatal. */
async function* readRolloutChunks(path, start, end) {
    try {
        for await (const chunk of createReadStream(path, {
            start,
            ...(end === undefined ? {} : { end }),
        })) {
            yield chunk;
        }
    }
    catch (error) {
        throw new RolloutSourceError(path, error);
    }
}
/**
 * Stream a rollout JSONL file from `startOffset` (bytes), yielding each
 * newline-terminated JSON object together with the byte offset just past its
 * terminator. A trailing chunk with no final `\n` (an in-flight append) is
 * NOT yielded and its bytes are NOT counted toward the committed offset — it
 * is re-read on a later run once the writer finishes the line. Memory stays
 * bounded: at most one line plus the current read chunk is held.
 *
 * Byte offsets are tracked over the raw bytes (Buffer length), not decoded
 * characters, so a multi-byte UTF-8 sequence advances the offset by its true
 * byte length and the resume offset always lands on a real byte boundary.
 * A malformed complete line throws unless the caller supplies an awaited gap
 * reporter. The collector discloses and persists each gap before checkpointing.
 */
export async function* iterJsonlLinesFromOffset(path, startOffset, options) {
    const stream = readRolloutChunks(path, startOffset);
    let pending = Buffer.alloc(0);
    // Byte offset (from file start) just past the last `\n` we have emitted.
    let committed = startOffset;
    for await (const chunk of stream) {
        const buf = chunk;
        pending = pending.length === 0 ? buf : Buffer.concat([pending, buf]);
        let nl = pending.indexOf(0x0a);
        while (nl !== -1) {
            const lineBuf = pending.subarray(0, nl);
            const lineStart = committed;
            committed += nl + 1; // bytes consumed up to and including the `\n`
            if (options) {
                options.progress.lineNumber += 1;
                options.progress.committedOffset = committed;
            }
            const line = lineBuf.toString("utf8");
            const trimmed = line.trim();
            if (trimmed) {
                let parsed;
                let reason = null;
                try {
                    parsed = JSON.parse(line);
                }
                catch (error) {
                    if (!options) {
                        throw new LocalJsonlMalformedLineError(committed, { cause: error });
                    }
                    reason = "malformed_jsonl_line";
                }
                if (reason === null &&
                    (!parsed || typeof parsed !== "object" || Array.isArray(parsed))) {
                    reason = "non_object_jsonl_record";
                }
                if (reason) {
                    if (!options)
                        throw new LocalJsonlMalformedLineError(committed);
                    await options.onGap({
                        path,
                        line_number: options.progress.lineNumber,
                        byte_offset: lineStart,
                        reason,
                    });
                }
                else {
                    yield { obj: parsed, committedOffset: committed };
                }
            }
            pending = pending.subarray(nl + 1);
            nl = pending.indexOf(0x0a);
        }
    }
    // Retain the entire unterminated tail for the next append, with explicit
    // coverage evidence. Even valid JSON is not committed until its newline.
    if (pending.toString("utf8").trim() && options) {
        await options.onGap({
            path,
            line_number: options.progress.lineNumber + 1,
            byte_offset: committed,
            reason: "truncated_jsonl_tail",
        });
    }
}
// ─── Rollout file integrity guard ───────────────────────────────────────
/**
 * SHA-256 over the first `guardBytes` bytes of `path`. Bounded read — never
 * loads more than the guard prefix into memory. Returns null if the file is
 * shorter than `guardBytes` (caller treats a short read as an integrity
 * mismatch and full-reparses). Read failures remain explicit source gaps.
 */
async function hashFilePrefix(path, guardBytes) {
    if (guardBytes <= 0) {
        return createHash("sha256").update(Buffer.alloc(0)).digest("hex");
    }
    const hash = createHash("sha256");
    let read = 0;
    for await (const chunk of readRolloutChunks(path, 0, guardBytes - 1)) {
        read += chunk.length;
        hash.update(chunk);
    }
    return read >= guardBytes ? hash.digest("hex") : null;
}
// ─── Rollout directory walking ──────────────────────────────────────────
// Distinguish ENOENT (legitimate absence) from other errors (unreadable/permission failure)
async function listIfExists(dir, onError) {
    try {
        return await readdir(dir);
    }
    catch (e) {
        const err = e;
        if (err?.code === "ENOENT") {
            return null;
        }
        const error = new RolloutSourceError(dir, e);
        if (!onError)
            throw error;
        await onError(error);
        return null;
    }
}
async function* walkDayFiles(dayPath, year, month, day, onDirectoryError) {
    const files = await listIfExists(dayPath, onDirectoryError);
    if (files === null) {
        return;
    }
    for (const f of files) {
        if (isRolloutFile(f)) {
            yield { path: join(dayPath, f), year, month, day, file: f };
        }
    }
}
async function* walkMonthDays(monthPath, year, month, scope, onDirectoryError) {
    const days = await listIfExists(monthPath, onDirectoryError);
    if (days === null) {
        return;
    }
    for (const d of days) {
        if (!TWO_DIGIT_DIR_RE.test(d)) {
            continue;
        }
        // A civil day strictly before the boundary day cannot hold an in-range
        // record, so the whole day is skipped without listing or opening any file.
        if (!dateDirectoryInRange({ day: d, month, year }, scope)) {
            continue;
        }
        yield* walkDayFiles(join(monthPath, d), year, month, d, onDirectoryError);
    }
}
async function* walkYearMonths(yearPath, year, scope, onDirectoryError) {
    const months = await listIfExists(yearPath, onDirectoryError);
    if (months === null) {
        return;
    }
    for (const m of months) {
        if (!TWO_DIGIT_DIR_RE.test(m)) {
            continue;
        }
        if (!dateDirectoryInRange({ month: m, year }, scope)) {
            continue;
        }
        yield* walkMonthDays(join(yearPath, m), year, m, scope, onDirectoryError);
    }
}
// Recursively walk the yyyy/mm/dd hierarchy and yield rollout-*.jsonl paths.
export async function* walkRollouts(baseDir, scope, onDirectoryError) {
    const years = await listIfExists(baseDir, onDirectoryError);
    if (years === null) {
        return;
    }
    for (const y of years) {
        if (!YEAR_DIR_RE.test(y)) {
            continue;
        }
        if (!dateDirectoryInRange({ year: y }, scope)) {
            continue;
        }
        yield* walkYearMonths(join(baseDir, y), y, scope, onDirectoryError);
    }
}
/**
 * The rich per-file parse cursor's map key. Prefers the session UUID parsed
 * out of the filename (stable across a relocation between the sessions/ and
 * sessions-archive/ roots — see ARCHIVAL-CONTRACT.md) and falls back to the
 * full path only for a filename that doesn't carry the expected UUID suffix
 * (never observed on a real Codex install, but a malformed/legacy name
 * degrades to the pre-fix path-keyed behavior rather than dropping the
 * cursor silently).
 */
export function cursorKeyForEntry(entry) {
    return extractRolloutUuidFromFilename(entry.file) ?? entry.path;
}
// ─── state_5.sqlite reader ─────────────────────────────────────────────
const THREADS_QUERY = `
  SELECT id, rollout_path, created_at, updated_at, source, model_provider,
         cwd, title, sandbox_policy, approval_mode, tokens_used,
         has_user_event, archived, archived_at, git_sha, git_branch,
         git_origin_url, cli_version, first_user_message, agent_nickname,
         agent_role, memory_mode, model, reasoning_effort
  FROM threads
`;
function openThreadsDb(dbPath) {
    try {
        return new DatabaseSync(dbPath, { readOnly: true });
    }
    catch {
        emit({
            type: "PROGRESS",
            message: "Codex phase=index pass=index state_db_readable=false fallback=rollouts_only",
        });
        return null;
    }
}
function isThreadRow(row) {
    return (typeof row === "object" &&
        row !== null &&
        typeof row.id === "string");
}
function* queryThreadsRows(db) {
    try {
        for (const row of db.prepare(THREADS_QUERY).iterate()) {
            if (isThreadRow(row)) {
                yield row;
            }
        }
    }
    catch {
        emit({
            type: "PROGRESS",
            message: "Codex phase=index pass=index state_db_query_failed=true fallback=rollouts_only",
        });
    }
}
async function statAndRead(path) {
    try {
        const st = await stat(path);
        const preview = await readBoundedFilePreview(path);
        if (preview === null) {
            return null;
        }
        const text = preview.buffer.toString("utf8");
        return { mtimeMs: Number(st.mtimeMs), size: Number(st.size), text };
    }
    catch {
        return null;
    }
}
async function emitRulesStream(rulesDir, emitRecord) {
    const entries = await listIfExists(rulesDir);
    if (entries === null) {
        return;
    }
    for (const f of entries) {
        if (!f.endsWith(".rules")) {
            continue;
        }
        const p = join(rulesDir, f);
        const loaded = await statAndRead(p);
        if (!loaded) {
            continue;
        }
        const mtime = Math.floor(loaded.mtimeMs / 1000);
        const ruleset = f.replace(RULES_SUFFIX_RE, "");
        let idx = 0;
        for (const raw of splitRulesLines(loaded.text)) {
            const line = raw.trim();
            if (isSkippableRulesLine(line)) {
                continue;
            }
            emitRecord("rules", buildRuleRecord({ ruleset, line, index: idx, path: p, mtime }));
            await waitForEmitDrain();
            idx += 1;
        }
    }
}
async function emitPromptsStream(promptsDir, emitRecord) {
    const entries = await listIfExists(promptsDir);
    if (entries === null) {
        return;
    }
    for (const f of entries) {
        if (!f.endsWith(".md")) {
            continue;
        }
        const p = join(promptsDir, f);
        const loaded = await statAndRead(p);
        if (!loaded) {
            continue;
        }
        const { meta, body } = parseFrontmatter(loaded.text);
        emitRecord("prompts", buildPromptRecord({
            fileName: f,
            meta,
            body,
            path: p,
            mtimeMs: loaded.mtimeMs,
        }));
        await waitForEmitDrain();
    }
}
function shouldSkipSkillEntry(ent) {
    return ent.name.startsWith(".") || ent.name === "skills.backup";
}
async function isDirectoryPath(p) {
    try {
        const s = await stat(p);
        return s.isDirectory();
    }
    catch {
        return false;
    }
}
async function emitSkillsStream(skillsDir, emitRecord) {
    // Each skill is a subdirectory with SKILL.md at its root. Follows symlinks
    // (skills are often symlinked from dotfiles). Skips hidden dirs (.system).
    //
    // Fail closed on an unreadable directory, matching `emitRulesStream` and
    // `emitPromptsStream`, which already route through `listIfExists`. This
    // function previously swallowed EVERY error, so a permission failure on the
    // skills directory was indistinguishable from "this owner has no skills" —
    // the filesystem is the whole source of truth here, so an unreadable
    // directory is a source-boundary failure, not evidence of emptiness. ENOENT
    // (genuinely absent) remains a legitimate empty enumeration.
    let entries;
    try {
        entries = await readdir(skillsDir, { withFileTypes: true });
    }
    catch (error) {
        if (error?.code === "ENOENT") {
            return;
        }
        throw error;
    }
    for (const ent of entries) {
        if (shouldSkipSkillEntry(ent)) {
            continue;
        }
        const dirPath = join(skillsDir, ent.name);
        if (!(await isDirectoryPath(dirPath))) {
            continue;
        }
        const skillMdPath = join(dirPath, "SKILL.md");
        const loaded = await statAndRead(skillMdPath);
        if (!loaded) {
            continue;
        }
        const { meta, body } = parseFrontmatter(loaded.text);
        emitRecord("skills", buildSkillRecord({
            dirName: ent.name,
            meta,
            body,
            path: skillMdPath,
            mtimeMs: loaded.mtimeMs,
        }));
        await waitForEmitDrain();
    }
}
export function makeRolloutParseState(seed) {
    return {
        sessionId: seed?.sessionId ?? null,
        sessionMeta: null,
        firstTimestamp: seed?.firstTimestamp ?? null,
        lastTimestamp: seed?.lastTimestamp ?? null,
        messageCount: seed?.messageCount ?? 0,
        functionCallCount: seed?.functionCallCount ?? 0,
        pendingCalls: new Map(),
        lineCount: seed?.lineCount ?? 0,
    };
}
// ─── Per-payload record builders (stateful over RolloutParseState) ──────
function emitMessageRecord(state, payload, ts, emitRecord) {
    const { sessionId } = state;
    if (!sessionId) {
        return;
    }
    const id = `${sessionId}:${state.lineCount}`;
    emitRecord("messages", {
        id,
        session_id: sessionId,
        role: payload.role || null,
        type: "message",
        content: textPreview(extractMessageText(payload), 5000),
        timestamp: ts,
    });
}
function registerFunctionCall(state, payload, ts, emitRecord) {
    const { sessionId } = state;
    if (!sessionId) {
        return;
    }
    const callId = payload.call_id || `${sessionId}:${state.lineCount}`;
    while (state.pendingCalls.size >= MAX_PENDING_FUNCTION_CALLS) {
        const oldestEntry = state.pendingCalls.entries().next();
        if (oldestEntry.done) {
            break;
        }
        const [oldestCallId, oldest] = oldestEntry.value;
        emitRecord("function_calls", oldest);
        state.pendingCalls.delete(oldestCallId);
    }
    state.pendingCalls.set(callId, {
        id: callId,
        session_id: sessionId,
        call_id: callId,
        name: payload.name || null,
        arguments: textPreview(payload.arguments || null, 2000),
        output_preview: null,
        timestamp: ts,
    });
}
function applyFunctionCallOutput(state, payload, ts, emitRecord) {
    const { sessionId } = state;
    if (!sessionId) {
        return;
    }
    const callId = payload.call_id;
    const existing = callId ? state.pendingCalls.get(callId) : null;
    const previewResult = payloadOutputPreview(payload.output);
    if (existing) {
        // Emit the merged call+output record NOW and drop the pending entry, rather
        // than mutating it in place and waiting for the EOF flush. Holding every
        // paired call in `pendingCalls` until end-of-file made the map grow to one
        // entry per call across the whole parse — O(file) memory, multi-GB on a
        // very large active Codex session. The "pendingCalls stays bounded across a
        // large parse" test in integration.test.ts pins this. The record shape is
        // identical to what flushPendingCalls produced; only the emit moment moves
        // earlier, so the stream still lands each call exactly once.
        existing.output_preview = previewResult.preview;
        if (previewResult.binaryReason) {
            existing.output_binary_reason = previewResult.binaryReason;
        }
        if (callId) {
            state.pendingCalls.delete(callId);
        }
        emitRecord("function_calls", { ...existing });
        return;
    }
    emitRecord("function_calls", {
        id: `${sessionId}:${state.lineCount}:output`,
        session_id: sessionId,
        call_id: callId || null,
        name: null,
        arguments: null,
        output_preview: previewResult.preview,
        output_binary_reason: previewResult.binaryReason,
        timestamp: ts,
    });
}
/**
 * Dispatch one response_item payload. Each branch is gated by the matching
 * stream in `requested.has(...)`: a message payload only emits when
 * `messages` is requested; a function_call / function_call_output payload
 * only emits when `function_calls` is requested. `reasoning` payloads are
 * silently dropped — encrypted_content is opaque.
 *
 * Side effect on state: the messageCount / functionCallCount counters
 * advance unconditionally (so the session aggregate stays accurate even
 * when the corresponding record stream is gated off).
 */
export function processResponseItem({ deps, payload, state, ts, }) {
    if (payload.type === "message") {
        state.messageCount += 1;
        if (deps.requested.has("messages")) {
            emitMessageRecord(state, payload, ts, deps.emitRecord);
        }
        return;
    }
    if (payload.type === "function_call") {
        state.functionCallCount += 1;
        if (deps.requested.has("function_calls")) {
            registerFunctionCall(state, payload, ts, deps.emitRecord);
        }
        return;
    }
    if (payload.type === "function_call_output" &&
        deps.requested.has("function_calls")) {
        applyFunctionCallOutput(state, payload, ts, deps.emitRecord);
    }
    // reasoning is skipped — encrypted_content is opaque.
}
const PROGRESS_EVERY = 2000;
export function shouldDeferActiveRolloutFile(input) {
    return input.quietMs > 0 && input.mtimeMs > input.nowMs - input.quietMs;
}
/**
 * Dispatch one JSONL line:
 *   - session_meta → install session id + metadata on state, but only
 *     from the FIRST session_meta line in the file. Forked rollouts
 *     emit additional session_meta lines describing the fork parent
 *     chain; those must NOT overwrite the canonical (child) session id,
 *     otherwise every response_item that follows would be attributed to
 *     the parent and the child session's message/function counts would
 *     stay null.
 *   - response_item → delegate to processResponseItem (iff sessionId seen).
 *   - anything else → silent no-op, line counter still advances.
 *
 * Fires a progress signal every PROGRESS_EVERY lines for large rollout
 * files. Timestamps extend the first/last range on every line regardless
 * of dispatch, so the session aggregate covers the full file span.
 */
export function processRolloutLine({ deps, obj, state, }) {
    state.lineCount += 1;
    if (state.lineCount % PROGRESS_EVERY === 0) {
        deps.progress(`Codex phase=emit pass=emit lines_parsed=${state.lineCount}`);
    }
    const ts = obj.timestamp || null;
    const range = {
        firstTs: state.firstTimestamp,
        lastTs: state.lastTimestamp,
    };
    extendTimestampRange(range, ts);
    state.firstTimestamp = range.firstTs;
    state.lastTimestamp = range.lastTs;
    if (obj.type === "session_meta") {
        if (state.sessionId === null) {
            state.sessionMeta = obj.payload || {};
            state.sessionId = state.sessionMeta.id || null;
        }
        return;
    }
    if (!state.sessionId) {
        return;
    }
    if (obj.type !== "response_item") {
        return;
    }
    processResponseItem({
        payload: obj.payload || {},
        ts,
        state,
        deps,
    });
}
// ─── End-of-file flush ──────────────────────────────────────────────────
/**
 * Emit any function_call that never saw a matching function_call_output.
 * A function_call payload registers a PendingCall in state.pendingCalls; a
 * matching function_call_output now emits the merged record and removes the
 * entry immediately (see applyFunctionCallOutput), so `pendingCalls` only ever
 * holds calls still awaiting their output. At EOF we drain whatever's left —
 * calls whose output never arrived in this parse window — with a null
 * output_preview, so the function_calls stream lands every call exactly once.
 *
 * Because paired calls drain on their output line, this map is bounded by the
 * number of concurrently-open (unanswered) calls, NOT by the file size — which
 * is what keeps a multi-GB session parse memory-bounded.
 */
export function flushPendingCalls(state, deps) {
    for (const call of state.pendingCalls.values()) {
        deps.emitRecord("function_calls", { ...call });
    }
    state.pendingCalls.clear();
}
/**
 * Decide whether a thread session needs to be re-emitted this run.
 * Returns true if any of:
 *   - The session id is new (no prior fingerprint).
 *   - This run parsed the session's rollout file (counts may have moved).
 *   - The thread's `updated_at` is strictly greater than the prior
 *     fingerprint's `updated_at` (state_5 actually changed for this row).
 *
 * Returns false when the row is byte-for-byte the same shape we'd build —
 * skipping the emit avoids a new history version downstream.
 */
export function shouldReemitThreadSession(thread, agg, priorFingerprint) {
    if (!priorFingerprint) {
        return true;
    }
    if (agg) {
        return true;
    }
    const priorUpdatedAt = priorFingerprint.updated_at ?? null;
    const currentUpdatedAt = thread.updated_at ?? null;
    if (currentUpdatedAt === null) {
        return priorUpdatedAt !== null;
    }
    if (priorUpdatedAt === null) {
        return true;
    }
    return currentUpdatedAt > priorUpdatedAt;
}
function makeThreadFingerprint(thread, agg, priorFingerprint) {
    // Counts must follow the same fallback chain as buildThreadSessionRecord
    // — otherwise the fingerprint we persist would disagree with the record
    // we just emitted, and the next run would think state_5 hasn't moved
    // while the count field oscillates.
    return {
        updated_at: thread.updated_at ?? null,
        message_count: agg?.messageCount ?? priorFingerprint?.message_count ?? null,
        function_call_count: agg?.functionCallCount ?? priorFingerprint?.function_call_count ?? null,
    };
}
/**
 * I/O-free sessions emitter: given a pre-loaded threads map (from
 * state_5.sqlite) and a map of rollout aggregates (from parseRolloutFile),
 * emit one `sessions` record per unique session id.
 *
 * Invariants:
 *   - Thread rows emit first, in threadsMap iteration order. Each thread
 *     is merged with its aggregate (so message_count / function_call_count
 *     reflect the on-disk rollout even when state_5 is canonical for the
 *     rest of the fields).
 *   - When prior fingerprints are supplied, threads whose `updated_at`
 *     hasn't advanced AND whose rollout wasn't parsed this run are
 *     skipped — this stops the state_5-mtime-only churn that was
 *     creating an excess record version per scan.
 *   - When a thread is emitted without a fresh aggregate, the prior
 *     fingerprint's counts fill in for `message_count` /
 *     `function_call_count`. Without this, a state_5-only update would
 *     overwrite a real count with `null` and grow history with a
 *     lossy version.
 *   - Rollout-only sessions (on disk but not in state_5) emit with nulls
 *     for state_5-only fields so the schema stays consistent.
 *   - Dedup is on session id: a session present in both maps emits ONCE
 *     (thread-preferred). Tests pin this — a regression would double-emit.
 */
export function emitSessionsFromMaps({ threadsMap, rolloutAggregates, emitRecord, cursor, }) {
    const emittedSessionIds = new Set();
    for (const [id, t] of threadsMap) {
        emittedSessionIds.add(id);
        const agg = rolloutAggregates.get(id);
        const prior = cursor?.prior(id);
        if (shouldReemitThreadSession(t, agg, prior)) {
            emitRecord("sessions", buildThreadSessionRecord(id, t, agg, prior));
        }
        cursor?.note(id, makeThreadFingerprint(t, agg, prior));
    }
    for (const [id, agg] of rolloutAggregates) {
        if (emittedSessionIds.has(id)) {
            continue;
        }
        emitRecord("sessions", buildRolloutOnlySessionRecord(id, agg));
        // Rollout-only sessions don't have a state_5 row to fingerprint
        // against (updated_at lives in threads). They re-emit whenever
        // their rollout file mtime changes — the rollout-file mtime gate
        // in scanRollouts is the right deduper for that path.
    }
}
function emitSessionsFromRows({ threadsRows, rolloutAggregates, emitRecord, cursor, }) {
    for (const t of threadsRows) {
        const agg = rolloutAggregates.get(t.id);
        rolloutAggregates.delete(t.id);
        const prior = cursor.prior(t.id);
        if (shouldReemitThreadSession(t, agg, prior)) {
            emitRecord("sessions", buildThreadSessionRecord(t.id, t, agg, prior));
        }
        cursor.note(t.id, makeThreadFingerprint(t, agg, prior));
    }
    for (const [id, agg] of rolloutAggregates) {
        emitRecord("sessions", buildRolloutOnlySessionRecord(id, agg));
    }
}
async function parseRolloutFile(args) {
    const state = makeRolloutParseState(args.seed);
    const jsonlGaps = (args.priorCursor?.jsonl_gaps ?? []).filter((gap) => gap.byte_offset < args.startOffset);
    for (const gap of jsonlGaps) {
        await reportMalformedRolloutGap(args.requested, gap);
    }
    const progress = {
        committedOffset: args.startOffset,
        lineNumber: args.priorCursor?.source_line_count ?? 0,
    };
    // Legacy cursors count parsed objects, not physical lines. Count the bounded
    // prefix once on migration so blank lines cannot make gap locations lie.
    if (args.startOffset > 0 &&
        args.priorCursor?.source_line_count === undefined) {
        for await (const chunk of readRolloutChunks(args.path, 0, args.startOffset - 1)) {
            let newline = chunk.indexOf(0x0a);
            while (newline !== -1) {
                progress.lineNumber += 1;
                newline = chunk.indexOf(0x0a, newline + 1);
            }
        }
    }
    const deps = {
        emitRecord: args.emitRecord,
        progress: (message) => {
            emit({ type: "PROGRESS", message });
        },
        requested: args.requested,
    };
    for await (const { obj } of iterJsonlLinesFromOffset(args.path, args.startOffset, {
        progress,
        onGap: async (gap) => {
            jsonlGaps.push(gap);
            if (gap.reason !== "truncated_jsonl_tail")
                state.lineCount += 1;
            await reportMalformedRolloutGap(args.requested, gap);
        },
    })) {
        // A damaged initial session_meta must not starve its remaining messages.
        // A valid metadata line still wins; only a preceding parse gap permits the
        // canonical rollout filename UUID to supply otherwise missing identity.
        if (state.sessionId === null &&
            obj.type !== "session_meta" &&
            jsonlGaps.some((gap) => gap.reason !== "truncated_jsonl_tail")) {
            state.sessionId = extractRolloutUuidFromFilename(args.file);
        }
        processRolloutLine({ obj, state, deps, file: args.file });
        await waitForEmitDrain();
    }
    flushPendingCalls(state, deps);
    await waitForEmitDrain();
    if (state.sessionId) {
        args.rolloutAggregates.set(state.sessionId, {
            meta: state.sessionMeta || {},
            firstTs: state.firstTimestamp,
            lastTs: state.lastTimestamp,
            // Counts are cumulative: makeRolloutParseState seeded them from the
            // prior cursor on an append, so this is prior + delta, not suffix-only.
            messageCount: state.messageCount,
            functionCallCount: state.functionCallCount,
            rolloutPath: args.path,
        });
    }
    return {
        committedOffset: progress.committedOffset,
        sourceLineCount: progress.lineNumber,
        jsonlGaps,
        sessionId: state.sessionId,
        lineCount: state.lineCount,
        messageCount: state.messageCount,
        functionCallCount: state.functionCallCount,
        firstTimestamp: state.firstTimestamp,
        lastTimestamp: state.lastTimestamp,
    };
}
/**
 * Decide how to process one rollout file given its current stat and the prior
 * per-file cursor (if any). Pure + I/O-free over its inputs: the caller
 * supplies the recomputed prefix-guard hash (or null when the file is too
 * short / unreadable) so this stays unit-testable. `guardMatches` is only
 * consulted on the grow path — a verified prefix is required before tailing.
 */
export function decideRolloutAction(input) {
    const { cursor, sizeBytes, mtimeMs } = input;
    if (!cursor) {
        return { kind: "full" };
    }
    if (sizeBytes === cursor.size_bytes && mtimeMs === cursor.mtime_ms) {
        return { kind: "skip" };
    }
    // Anything that is not a clean forward-append over a verified prefix is
    // treated as truncation/replacement and reparsed in full — never tailed
    // from a stale offset, never silently skipped.
    if (sizeBytes < cursor.size_bytes ||
        cursor.offset_bytes > sizeBytes ||
        !input.guardMatches) {
        return { kind: "unsafe_full" };
    }
    if (sizeBytes > cursor.size_bytes) {
        return {
            kind: "append",
            startOffset: cursor.offset_bytes,
            seed: {
                sessionId: cursor.session_id,
                lineCount: cursor.line_count,
                messageCount: cursor.message_count,
                functionCallCount: cursor.function_call_count,
                firstTimestamp: cursor.first_ts,
                lastTimestamp: cursor.last_ts,
            },
        };
    }
    // Same size, different mtime, prefix intact: content is byte-identical up to
    // the boundary and the file did not grow. A touch with no new data — skip.
    return { kind: "skip" };
}
/** Carry a file's prior cursor forward verbatim into the next STATE, and keep
 *  the legacy mtime map populated so a downgrade still has a usable cursor.
 *  The rich cursor is carried under its UUID key (stable across a relocation
 *  between roots); the legacy mtime map stays path-keyed, matching its
 *  pre-existing path+mtime fast-path semantics. */
function carryFileCursorForward(args, entry, mtime) {
    const cursorKey = cursorKeyForEntry(entry);
    const prior = args.fileCursors[cursorKey];
    if (prior) {
        args.newFileCursors[cursorKey] = prior;
    }
    args.newMtimes[entry.path] = mtime;
}
/** Report `Codex phase=index sessions_dir_readable=false` and return the empty scan result. */
async function reportMissingSessionsBase(scanOutcomeOnBaseError) {
    emit({
        type: "PROGRESS",
        message: "Codex phase=index pass=index sessions_dir_readable=false",
    });
    await waitForEmitDrain();
    // If we caught an error, it's unreadable; if not, ENOENT = complete
    return {
        parsedFiles: 0,
        messagesEmitted: 0,
        messagesExamined: 0,
        functionCallsEmitted: 0,
        functionCallsExamined: 0,
        scanOutcome: scanOutcomeOnBaseError || "complete",
    };
}
/** The examined-record counts a rollout file's carried-forward cursor vouches for. */
function examinedCountsFromCursor(cursor) {
    return {
        functionCalls: cursor?.function_call_count ?? 0,
        messages: cursor?.message_count ?? 0,
    };
}
/**
 * Build (or rebuild) a rich cursor after a parse, hashing the committed prefix.
 *
 * Active-append safety: the file may grow while we parse it (Codex is actively
 * appending to the same long-lived rollout). The cursor MUST record a
 * `size_bytes` consistent with the bytes it actually vouches for, so we set
 * `size_bytes = offset_bytes = committedOffset` — the byte boundary the parse
 * actually reached — NOT the (possibly larger) on-disk size. Recording the live
 * size would let the next run see `size === cursor.size_bytes` for a file that
 * still has an uncommitted tail and SKIP it, losing the tail. With
 * `size_bytes == committedOffset`, any real growth makes the next run observe
 * `sizeBytes > cursor.size_bytes` and tail exactly the uncommitted+new suffix.
 *
 * `mtime_ms` is taken from a POST-parse re-stat (the pre-parse mtime is stale if
 * the file was appended to during the parse). A stale mtime would only cost a
 * spurious guard recomputation next run (which resolves to skip), never data
 * loss — but re-stat keeps the cursor honest. The guard hashes the committed
 * prefix, which is immutable on an append-only file, so it is stable across the
 * mid-parse growth.
 */
async function buildFileCursorAfterParse(path, result) {
    const guardBytes = Math.min(result.committedOffset, GUARD_PREFIX_BYTES);
    const head = await hashFilePrefix(path, guardBytes);
    if (head === null)
        throw new RolloutSourceError(path, new Error("Rollout prefix shortened during parsing"));
    // Re-stat AFTER parsing; a source race must keep the old retry boundary.
    let mtimeMs = 0;
    try {
        ({ mtimeMs } = statSync(path));
    }
    catch (error) {
        throw new RolloutSourceError(path, error);
    }
    return {
        mtime_ms: mtimeMs,
        source_line_count: result.sourceLineCount,
        jsonl_gaps: result.jsonlGaps,
        // Invariant: size_bytes == offset_bytes. The cursor vouches for exactly the
        // committed prefix; everything past it is re-read on a later run.
        size_bytes: result.committedOffset,
        offset_bytes: result.committedOffset,
        line_count: result.lineCount,
        head_sha256: head,
        guard_bytes: guardBytes,
        session_id: result.sessionId,
        message_count: result.messageCount,
        function_call_count: result.functionCallCount,
        first_ts: result.firstTimestamp,
        last_ts: result.lastTimestamp,
    };
}
/** Resolve the append-safe action for one file: recompute the prefix guard
 *  only when there is a cursor and the file grew (the only path that tails). */
async function resolveRolloutAction(path, st, cursor) {
    const sizeBytes = Number(st.size);
    let guardMatches = false;
    if (cursor &&
        sizeBytes > cursor.size_bytes &&
        cursor.offset_bytes <= sizeBytes) {
        const head = await hashFilePrefix(path, cursor.guard_bytes);
        guardMatches = head !== null && head === cursor.head_sha256;
    }
    return decideRolloutAction({
        cursor,
        sizeBytes,
        mtimeMs: st.mtimeMs,
        guardMatches,
    });
}
async function processRolloutEntry(entry, args, rolloutOrdinal) {
    let st;
    try {
        st = statSync(entry.path);
    }
    catch (error) {
        throw new RolloutSourceError(entry.path, error);
    }
    const mtime = st.mtimeMs;
    const cursorKey = cursorKeyForEntry(entry);
    // Mid-move race guard: the archival policy one-way-moves a file from
    // sessions/ to sessions-archive/ (see ARCHIVAL-CONTRACT.md). A scan that
    // lands mid-`mv` (rare, but the walk over two roots is not atomic) can see
    // the SAME session UUID under both roots in one pass — e.g. a `cp`-then-
    // `rm` style move briefly leaves both copies on disk, or a directory
    // listing race yields stale entries. Once this scan has already processed
    // a UUID (from whichever root it was walked first), a second sighting in
    // the same pass is the identical file re-appearing under its other root:
    // skip it outright rather than re-parsing or re-emitting. This is
    // never a "the file disappeared, therefore deleted" inference — it is the
    // same content encountered twice in one walk, using the same identity the
    // per-run cursor already trusts.
    //
    // This is distinct from a plain "skipped" (the legacy mtime fast path, or
    // an unchanged-file skip below): those carry a cursor whose examined counts
    // have NOT yet been added to this scan's totals, so the caller adds them.
    // A "duplicate" sighting's cursor was already counted at first sighting —
    // counting it again would double `messagesExamined`/`functionCallsExamined`
    // for a file that was only actually examined once.
    if (args.seenCursorKeysThisScan.has(cursorKey)) {
        return "duplicate";
    }
    args.seenCursorKeysThisScan.add(cursorKey);
    const cursor = args.fileCursors[cursorKey];
    // Legacy fast path: no rich cursor yet, but the legacy mtime matches — the
    // previously-emitted records stay valid. Carry the (absent) cursor forward.
    // This map stays PATH-keyed (its pre-existing semantics): a relocated file
    // has a new path, so it never spuriously hits this fast path — it falls
    // through to resolveRolloutAction, which is keyed by the stable UUID.
    if (!cursor &&
        !args.sourceGaps[entry.path] &&
        args.fileMtimes[entry.path] === mtime) {
        args.newMtimes[entry.path] = mtime;
        return "skipped";
    }
    let action = await resolveRolloutAction(entry.path, st, cursor);
    if (args.sourceGaps[entry.path] && action.kind === "skip")
        action = { kind: "full" };
    if (action.kind === "skip") {
        carryFileCursorForward(args, entry, mtime);
        return "skipped";
    }
    if (shouldDeferActiveRolloutFile({
        mtimeMs: mtime,
        nowMs: args.scanStartedAtMs,
        quietMs: args.activeQuietMs,
    })) {
        emit({
            type: "PROGRESS",
            message: `Codex phase=index pass=index item=${rolloutOrdinal} backpressure=active_rollout_deferred`,
        });
        await waitForEmitDrain();
        // Defer: the file is being actively written, so it must be reconsidered
        // next run once it goes quiet. Carry a prior RICH cursor forward (preserves
        // its committed offset) but do NOT write a fresh `newMtimes` entry: the
        // legacy fast path skips a file when `!cursor && fileMtimes[path] === mtime`,
        // so stamping the mtime of a deferred-but-unparsed new file would skip it
        // forever (silent data loss). For a file with a prior rich cursor the
        // newMtimes stamp is harmless (the fast path is gated on `!cursor`), but we
        // still avoid stamping it so the deferral is a pure no-op on this run's
        // record emission.
        if (cursor) {
            args.newFileCursors[cursorKey] = cursor;
        }
        return "skipped";
    }
    const isAppend = action.kind === "append";
    emit({
        type: "PROGRESS",
        message: `Codex phase=emit pass=emit item=${rolloutOrdinal} mode=${isAppend ? "append" : "full"} file_size_mb=${(st.size / 1024 / 1024).toFixed(1)}`,
    });
    await waitForEmitDrain();
    const result = await parseRolloutFile({
        priorCursor: isAppend ? cursor : undefined,
        path: entry.path,
        file: entry.file,
        requested: args.requested,
        emitRecord: args.emitRecord,
        rolloutAggregates: args.rolloutAggregates,
        startOffset: action.kind === "append" ? action.startOffset : 0,
        seed: action.kind === "append" ? action.seed : undefined,
    });
    args.newFileCursors[cursorKey] = await buildFileCursorAfterParse(entry.path, result);
    args.newMtimes[entry.path] = mtime;
    delete args.sourceGaps[entry.path];
    return "parsed";
}
/** Whether a root directory exists, distinguishing ENOENT from a real I/O
 *  error the same way `listIfExists` does. */
async function rootExists(baseDir, onDirectoryError) {
    try {
        return {
            exists: (await listIfExists(baseDir)) !== null,
            unreadable: false,
        };
    }
    catch (error) {
        if (!(error instanceof RolloutSourceError))
            throw error;
        await onDirectoryError(error);
        return { exists: false, unreadable: true };
    }
}
/**
 * Scan every rollout root (today: `sessions/` and `sessions-archive/`, see
 * ARCHIVAL-CONTRACT.md) and merge their results into one logical scan.
 *
 * Root existence is evaluated independently: a host that has never had
 * anything archived yet (sessions-archive/ absent) is normal, not an error —
 * only when EVERY root is absent does this report the legacy
 * `sessions_dir_readable=false` outcome. A single unreadable (not merely
 * absent) root still marks the overall scan `unreadable`, since that root's
 * content genuinely could not be examined.
 *
 * Cross-root de-duplication is `processRolloutEntry`'s job (via
 * `seenCursorKeysThisScan`, keyed by the UUID `cursorKeyForEntry` derives from
 * each entry's filename) — this function just walks every existing root in
 * turn and folds the counts together.
 */
export async function scanRollouts(args) {
    const reportedCursorKeys = new Set();
    const priorPaths = new Set([
        ...Object.keys(args.fileMtimes),
        ...Object.keys(args.sourceGaps),
        ...Object.entries(args.fileCursors).flatMap(([key, cursor]) => [
            ...(isAbsolute(key) ? [key] : []),
            ...(cursor.jsonl_gaps ?? []).map((gap) => gap.path),
        ]),
    ]);
    const keyForPath = (path) => cursorKeyForEntry({ path, file: basename(path) });
    const locatedKeys = new Set([...priorPaths].map(keyForPath));
    // Disappearance does not repair a declared line gap. Keep its evidence until
    // a successful scan of that file replaces it, including when all roots vanish.
    for (const [key, cursor] of Object.entries(args.fileCursors)) {
        if ((cursor.jsonl_gaps?.length ?? 0) > 0)
            args.newFileCursors[key] = cursor;
    }
    let directoryFailed = false;
    const onDirectoryError = async (error) => {
        directoryFailed = true;
        for (const path of priorPaths) {
            if (!path.startsWith(error.path + sep))
                continue;
            const key = keyForPath(path);
            const prior = args.fileCursors[key];
            if (prior && !args.newFileCursors[key])
                args.newFileCursors[key] = prior;
        }
        // Older UUID-only cursors can lack every path hint. An unreadable subtree
        // cannot establish their absence, so preserve those boundaries conservatively.
        for (const [key, cursor] of Object.entries(args.fileCursors)) {
            if (!locatedKeys.has(key) && !args.newFileCursors[key])
                args.newFileCursors[key] = cursor;
        }
        await reportRolloutSourceGap(args.requested, buildRolloutSourceGap(error));
    };
    const reportRetainedGaps = async () => {
        for (const [key, cursor] of Object.entries(args.newFileCursors)) {
            if (reportedCursorKeys.has(key))
                continue;
            for (const gap of cursor.jsonl_gaps ?? [])
                await reportMalformedRolloutGap(args.requested, gap);
        }
    };
    // Sequential, not Promise.all: `args.roots` is a short, fixed list (today:
    // two — the primary and archive roots), and each check is a single cheap
    // listIfExists(). No ordering or parallelism benefit is worth the added
    // concurrency surface.
    const rootChecks = [];
    for (const root of args.roots) {
        rootChecks.push({
            root,
            ...(await rootExists(root.baseDir, onDirectoryError)),
        });
    }
    const existingRoots = rootChecks.filter((r) => r.exists).map((r) => r.root);
    const anyUnreadable = rootChecks.some((r) => r.unreadable);
    if (existingRoots.length === 0) {
        await reportRetainedGaps();
        for (const gap of Object.values(args.sourceGaps)) {
            await reportRolloutSourceGap(args.requested, gap);
        }
        return await reportMissingSessionsBase(anyUnreadable ||
            Object.keys(args.sourceGaps).length > 0 ||
            Object.values(args.newFileCursors).some((cursor) => (cursor.jsonl_gaps?.length ?? 0) > 0)
            ? "unreadable"
            : null);
    }
    // Local wrapper to track emissions without mutating args
    const originalEmit = args.emitRecord;
    let messagesEmitted = 0;
    let functionCallsEmitted = 0;
    const countingEmit = (stream, data) => {
        if (stream === "messages") {
            messagesEmitted += 1;
        }
        if (stream === "function_calls") {
            functionCallsEmitted += 1;
        }
        originalEmit(stream, data);
    };
    let totalRollouts = 0;
    let parsedRollouts = 0;
    let scanOutcome = anyUnreadable
        ? "unreadable"
        : "complete";
    let messagesExamined = 0;
    let functionCallsExamined = 0;
    for (const root of existingRoots) {
        try {
            for await (const entry of walkRollouts(root.baseDir, args.scope, onDirectoryError)) {
                if (!isPathWithinSourceRoots(entry.path, args.scope)) {
                    continue;
                }
                totalRollouts += 1;
                try {
                    const result = await processRolloutEntry(entry, { ...args, emitRecord: countingEmit }, totalRollouts);
                    if (result === "parsed") {
                        parsedRollouts += 1;
                    }
                    // A "parsed" file was just examined; a "skipped" file may still carry
                    // examined counts forward from a prior run's cursor — either way, the
                    // cursor at this key (fresh or carried-forward) is the source of truth.
                    // A "duplicate" (mid-move-race second sighting of the same UUID this
                    // scan) contributes nothing: its cursor was already counted at first
                    // sighting, so adding it again would double-count the file.
                    if (result === "parsed" || result === "skipped") {
                        const gaps = args.newFileCursors[cursorKeyForEntry(entry)]?.jsonl_gaps ?? [];
                        if (gaps.length > 0) {
                            scanOutcome = "parse_error";
                            if (result === "skipped") {
                                for (const gap of gaps)
                                    await reportMalformedRolloutGap(args.requested, gap);
                            }
                        }
                        const counts = examinedCountsFromCursor(args.newFileCursors[cursorKeyForEntry(entry)]);
                        messagesExamined += counts.messages;
                        functionCallsExamined += counts.functionCalls;
                        reportedCursorKeys.add(cursorKeyForEntry(entry));
                    }
                }
                catch (error) {
                    if (!(error instanceof RolloutSourceError))
                        throw error;
                    scanOutcome = "unreadable";
                    // Preserve the retry boundary, including a partially emitted file.
                    const key = cursorKeyForEntry(entry);
                    const prior = args.fileCursors[key];
                    if (prior)
                        args.newFileCursors[key] = prior;
                    else
                        delete args.newFileCursors[key];
                    delete args.newMtimes[entry.path];
                    args.sourceGaps[error.path] = buildRolloutSourceGap(error);
                }
            }
        }
        catch (error) {
            if (!(error instanceof RolloutSourceError))
                throw error;
            // Enumeration error (e.g., directory traversal failure) makes scan incomplete
            scanOutcome = "unreadable";
            // Directory failures are reprobed each run; only file retry gaps belong
            // in the cursor ledger, since files have individual success boundaries.
            await onDirectoryError(error);
        }
    }
    await reportRetainedGaps();
    if (directoryFailed)
        scanOutcome = "unreadable";
    else if (Object.values(args.newFileCursors).some((cursor) => (cursor.jsonl_gaps?.length ?? 0) > 0))
        scanOutcome = "parse_error";
    for (const gap of Object.values(args.sourceGaps)) {
        scanOutcome = "unreadable";
        await reportRolloutSourceGap(args.requested, gap);
    }
    emit({
        type: "PROGRESS",
        message: `Codex phase=index pass=index total_items=${totalRollouts} parsed_items=${parsedRollouts}`,
    });
    await waitForEmitDrain();
    return {
        parsedFiles: parsedRollouts,
        messagesEmitted,
        messagesExamined,
        functionCallsEmitted,
        functionCallsExamined,
        scanOutcome,
    };
}
function buildRolloutSourceGap(error) {
    const cause = error.cause;
    return {
        path: error.path,
        reason: "rollout_source_read_error",
        error_code: typeof cause?.code === "string" ? cause.code : null,
    };
}
async function reportRolloutSourceGap(requested, gap) {
    for (const stream of ["sessions", "messages", "function_calls"]) {
        if (requested.has(stream))
            emit({
                type: "SKIP_RESULT",
                stream,
                reason: "rollout_source_read_error",
                message: "Codex could not read a rollout source; it will retry while other files continue",
                diagnostics: { ...gap },
            });
    }
    await waitForEmitDrain();
}
async function reportMalformedRolloutGap(requested, gap) {
    for (const stream of ["sessions", "messages", "function_calls"]) {
        if (requested.has(stream)) {
            emit({
                type: "SKIP_RESULT",
                stream,
                reason: JSONL_GAP_SKIP_REASON[gap.reason],
                message: gap.reason !== "truncated_jsonl_tail"
                    ? "Codex skipped an invalid JSONL record and continued scanning"
                    : "Codex retained an unterminated JSONL tail for the next append and continued scanning",
                diagnostics: { ...gap },
            });
        }
    }
    await waitForEmitDrain();
}
function emitSessions({ stateDbPath, rolloutAggregates, emitRecord, cursor, }) {
    // Sessions: prefer state_5.sqlite#threads; fall back to rollout-derived
    // fields only when state_5 doesn't have the session. Session PK stays the
    // thread/session id — the same UUID is used by both sources.
    const db = openThreadsDb(stateDbPath);
    if (!db) {
        for (const [id, agg] of rolloutAggregates) {
            emitRecord("sessions", buildRolloutOnlySessionRecord(id, agg));
        }
        return;
    }
    try {
        emitSessionsFromRows({
            threadsRows: queryThreadsRows(db),
            rolloutAggregates,
            emitRecord,
            cursor,
        });
    }
    finally {
        db.close();
    }
}
// ─── Start-message + state-cursor helpers ───────────────────────────────
async function readStartMessage() {
    const rl = createInterface({ input: process.stdin, terminal: false });
    return await new Promise((resolve, reject) => rl.once("line", (l) => {
        try {
            resolve(JSON.parse(l));
        }
        catch (e) {
            reject(e);
        }
    }));
}
function resolveCodexDirs() {
    const codexHome = process.env.CODEX_HOME || join(homedir(), ".codex");
    return {
        codexHome,
        baseDir: process.env.CODEX_SESSIONS_DIR || join(codexHome, "sessions"),
        // The external archival policy's destination root (see
        // ARCHIVAL-CONTRACT.md). Absence is normal — many hosts have nothing
        // old enough to have been archived yet — and is reported honestly via
        // the `sessions_archive` coverage store rather than failing readiness.
        archiveBaseDir: process.env.CODEX_SESSIONS_ARCHIVE_DIR ||
            join(codexHome, "sessions-archive"),
        stateDbPath: process.env.CODEX_STATE_DB || join(codexHome, "state_5.sqlite"),
        rulesDir: process.env.CODEX_RULES_DIR || join(codexHome, "rules"),
        promptsDir: process.env.CODEX_PROMPTS_DIR || join(codexHome, "prompts"),
        skillsDir: process.env.CODEX_SKILLS_DIR || join(codexHome, "skills"),
    };
}
function readFileMtimes(startMsg) {
    const state = startMsg.state || {};
    // STATE is stream-keyed per Collection Profile: `state` is
    // { <stream>: <cursor>, ... }. This connector emits STATE with a
    // stream name (see cursorStream below), cursor={file_mtimes:{...}}.
    // Check all streams that might carry file_mtimes plus legacy top-level.
    return (state.messages?.file_mtimes ||
        state.function_calls?.file_mtimes ||
        state.sessions?.file_mtimes ||
        state.file_mtimes ||
        {});
}
function readPriorSourceGaps(start) {
    const raw = start.state?.messages?.source_gaps ??
        start.state?.function_calls?.source_gaps ??
        start.state?.sessions?.source_gaps;
    const gaps = {};
    if (!raw || typeof raw !== "object")
        return gaps;
    for (const value of Object.values(raw)) {
        if (value &&
            typeof value.path === "string" &&
            value.reason === "rollout_source_read_error") {
            gaps[value.path] = {
                path: value.path,
                reason: value.reason,
                error_code: typeof value.error_code === "string" ? value.error_code : null,
            };
        }
    }
    return gaps;
}
function coerceRolloutFileCursor(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return null;
    }
    const v = value;
    const num = (x) => typeof x === "number" && Number.isFinite(x) ? x : null;
    const offset = num(v.offset_bytes);
    const size = num(v.size_bytes);
    const mtime = num(v.mtime_ms);
    const line = num(v.line_count);
    const guardBytes = num(v.guard_bytes);
    const head = typeof v.head_sha256 === "string" ? v.head_sha256 : null;
    // These six are load-bearing for the tail/skip/unsafe decision. A cursor
    // missing any of them is unusable — drop it so the file full-reparses once
    // (the same one-time cost as the legacy-mtime upgrade) rather than risk a
    // bad offset.
    if (offset === null ||
        size === null ||
        mtime === null ||
        line === null ||
        guardBytes === null ||
        head === null) {
        return null;
    }
    const gaps = [];
    if (v.jsonl_gaps !== undefined) {
        if (!Array.isArray(v.jsonl_gaps))
            return null;
        for (const gap of v.jsonl_gaps) {
            if (!gap ||
                typeof gap !== "object" ||
                typeof gap.path !== "string" ||
                !Number.isSafeInteger(gap.line_number) ||
                gap.line_number < 1 ||
                !Number.isSafeInteger(gap.byte_offset) ||
                gap.byte_offset < 0 ||
                (gap.reason !== "malformed_jsonl_line" &&
                    gap.reason !== "non_object_jsonl_record" &&
                    gap.reason !== "truncated_jsonl_tail"))
                return null;
            gaps.push({
                path: gap.path,
                line_number: gap.line_number,
                byte_offset: gap.byte_offset,
                reason: gap.reason,
            });
        }
    }
    const sourceLines = num(v.source_line_count);
    return {
        ...(sourceLines !== null &&
            Number.isSafeInteger(sourceLines) &&
            sourceLines >= 0
            ? { source_line_count: sourceLines }
            : {}),
        ...(v.jsonl_gaps !== undefined ? { jsonl_gaps: gaps } : {}),
        mtime_ms: mtime,
        size_bytes: size,
        offset_bytes: offset,
        line_count: line,
        head_sha256: head,
        guard_bytes: guardBytes,
        session_id: typeof v.session_id === "string" ? v.session_id : null,
        message_count: num(v.message_count) ?? 0,
        function_call_count: num(v.function_call_count) ?? 0,
        first_ts: typeof v.first_ts === "string" ? v.first_ts : null,
        last_ts: typeof v.last_ts === "string" ? v.last_ts : null,
    };
}
/**
 * Decode the prior per-file rollout cursors from STATE. Tolerant of legacy
 * cursors (no `file_cursors` field), wrong types, and partially-corrupt
 * entries — a malformed entry is dropped (its file then full-reparses once)
 * rather than failing the run. Checks the rollout streams plus the sessions
 * stream so the lookup survives whichever stream carried the cursor.
 */
export function readPriorFileCursors(startMsg) {
    const state = startMsg.state || {};
    const raw = state.messages?.file_cursors ||
        state.function_calls?.file_cursors ||
        state.sessions?.file_cursors ||
        null;
    const out = {};
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [path, value] of Object.entries(raw)) {
        const cursor = coerceRolloutFileCursor(value);
        if (cursor) {
            // Earlier collectors used absolute paths. Normalize those aliases to
            // the current UUID key so a successful reread replaces their old gaps.
            const key = isAbsolute(path)
                ? cursorKeyForEntry({ path, file: basename(path) })
                : path;
            if (path === key || !out[key])
                out[key] = cursor;
        }
    }
    return out;
}
function resolveActiveRolloutQuietMs(env = process.env) {
    const raw = env[ACTIVE_ROLLOUT_QUIET_MS_ENV];
    if (!raw) {
        return DEFAULT_ACTIVE_ROLLOUT_QUIET_MS;
    }
    const parsed = Number(raw);
    return Number.isFinite(parsed) && parsed >= 0
        ? parsed
        : DEFAULT_ACTIVE_ROLLOUT_QUIET_MS;
}
function buildRequestedMap(startMsg) {
    return new Map((startMsg.scope?.streams || []).map((s) => [s.name, s]));
}
function buildResourceFilters(requested) {
    const resFilters = new Map();
    for (const [n, r] of requested) {
        resFilters.set(n, resourceSet(r));
    }
    return resFilters;
}
// Check if path is a readable directory; returns true/false/error code for distinction
async function isReadableDirectory(path) {
    try {
        const st = await stat(path);
        return st.isDirectory();
    }
    catch {
        return false;
    }
}
// Check if path exists as a directory and is readable; return error code if not
async function checkDirectoryReadable(path) {
    try {
        const st = await stat(path);
        if (st.isDirectory()) {
            return "ok";
        }
        return "unreadable"; // exists but is not a directory
    }
    catch (e) {
        const err = e;
        if (err?.code === "ENOENT") {
            return "not_found";
        }
        return "unreadable"; // EACCES, EIO, etc.
    }
}
async function isReadableFile(path) {
    try {
        const st = await stat(path);
        return st.isFile();
    }
    catch {
        return false;
    }
}
async function assertRequestedCodexSources(dirs, requested) {
    // Distinguish ENOENT (legitimately absent) from EACCES/EIO (actual I/O failures).
    // ENOENT allows coverage_diagnostics to emit verified_empty evidence.
    // EACCES/EIO is an actual error that should be reported.
    const unreadable = [];
    const needsRollouts = requested.has("messages") || requested.has("function_calls");
    if (needsRollouts) {
        const status = await checkDirectoryReadable(dirs.baseDir);
        if (status === "unreadable") {
            unreadable.push(`CODEX_SESSIONS_DIR=${dirs.baseDir}`);
        }
    }
    if (requested.has("sessions")) {
        const hasRollouts = await isReadableDirectory(dirs.baseDir);
        const hasThreadsDb = await isReadableFile(dirs.stateDbPath);
        if (!(hasRollouts || hasThreadsDb)) {
            // Both missing — check if unreadable (not just absent)
            const rolloutStatus = await checkDirectoryReadable(dirs.baseDir);
            if (rolloutStatus === "unreadable") {
                unreadable.push(`CODEX_SESSIONS_DIR=${dirs.baseDir}`);
            }
        }
    }
    // rules/prompts/skills are optional, user-authored directories that Codex
    // itself never creates until the user writes one — coverage_diagnostics
    // already reports each as "missing" (not an error) when absent, and
    // emitRulesStream/emitPromptsStream/emitSkillsStream already no-op safely
    // on a missing directory. Requiring them here was fatal-on-every-fresh-
    // install: any host without a manually-created empty rules/prompts dir
    // failed its very first run. Only actual I/O failures (not ENOENT) are errors.
    if (unreadable.length > 0) {
        throw new Error(`requested Codex local source path(s) are unreadable: ${unreadable.join(", ")}`);
    }
}
function emitStateCursors({ sourceGaps, requested, newFileCursors, newMtimes, nowIso, sessionsSourceMtimeMs, threadFingerprints, }) {
    if (requested.has("sessions")) {
        emit({
            type: "STATE",
            stream: "sessions",
            cursor: {
                fetched_at: nowIso(),
                source_mtime_ms: sessionsSourceMtimeMs,
                thread_fingerprints: threadFingerprints.toState(),
                source_gaps: sourceGaps,
            },
        });
    }
    if (requested.has("messages") || requested.has("function_calls")) {
        const cursorStream = requested.has("messages")
            ? "messages"
            : "function_calls";
        emit({
            type: "STATE",
            stream: cursorStream,
            // file_cursors is the append-safe per-file cursor; file_mtimes is kept
            // alongside it for backward compatibility with a downgraded collector
            // (and the legacy fast-path skip on files this connector hasn't yet
            // upgraded to a rich cursor).
            cursor: {
                file_mtimes: newMtimes,
                file_cursors: newFileCursors,
                source_gaps: sourceGaps,
                fetched_at: nowIso(),
            },
        });
    }
    for (const s of ["rules", "prompts", "skills"]) {
        if (requested.has(s)) {
            emit({ type: "STATE", stream: s, cursor: { fetched_at: nowIso() } });
        }
    }
    // Inventory streams (history, session_index, shell_snapshots,
    // config_inventory, cache_inventory) own their STATE inside the fingerprint
    // gate (emitLocalInventoryStreams) and must NOT get a bare clobbering STATE
    // here. coverage_diagnostics is emitted after all collection output drains,
    // immediately before terminal success, so it cannot certify a partial scan.
}
function readPriorSessionsSourceMtimeMs(startMsg) {
    const state = startMsg.state || {};
    const { sessions } = state;
    const value = sessions && typeof sessions === "object" && !Array.isArray(sessions)
        ? sessions.source_mtime_ms
        : null;
    return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function nullableFiniteNumber(value) {
    return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function coerceFingerprintEntry(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return null;
    }
    const v = value;
    return {
        updated_at: nullableFiniteNumber(v.updated_at),
        message_count: nullableFiniteNumber(v.message_count),
        function_call_count: nullableFiniteNumber(v.function_call_count),
    };
}
function rawFingerprintMap(startMsg) {
    if (!startMsg || typeof startMsg !== "object") {
        return null;
    }
    const { state } = startMsg;
    if (!state || typeof state !== "object") {
        return null;
    }
    const { sessions } = state;
    if (!sessions || typeof sessions !== "object" || Array.isArray(sessions)) {
        return null;
    }
    const { thread_fingerprints: raw } = sessions;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return null;
    }
    return raw;
}
/**
 * Parse the prior `sessions` STATE cursor's `thread_fingerprints` map.
 * Tolerant of legacy cursors (no fingerprints), missing field, wrong
 * types, or values from a partially-different schema — bad entries are
 * silently dropped rather than failing the whole run.
 */
export function readPriorThreadFingerprints(startMsg) {
    const out = new Map();
    const raw = rawFingerprintMap(startMsg);
    if (!raw) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        const entry = coerceFingerprintEntry(value);
        if (entry) {
            out.set(id, entry);
        }
    }
    return out;
}
function fileMtimeMs(path) {
    try {
        return statSync(path).mtimeMs;
    }
    catch {
        return 0;
    }
}
/**
 * Emit the per-store `coverage_diagnostics` rows from a pre-built
 * inventory. Kept separate from inventory-record emission so the durable
 * coverage signal can be flushed BEFORE {@link assertRequestedCodexSources}
 * runs: a missing requested content source must still surface honest
 * `missing` coverage rows rather than abort the run with zero coverage
 * evidence. The connection-health rollup derives a local collector's
 * coverage axis from these records, and an omitted coverage stream
 * collapses to `coverage_unknown` forever (the local run path writes no
 * spine run). The inventory walk reads only path metadata, never payload,
 * so it is safe on a partial/empty home. No-op when `coverage_diagnostics`
 * was not requested.
 */
async function emitCoverageDiagnostics(input) {
    if (!input.requested.has("coverage_diagnostics")) {
        return;
    }
    for (const record of input.inventory.coverage) {
        input.emitRecord("coverage_diagnostics", record);
        await waitForEmitDrain();
    }
}
/**
 * Commit the STATE snapshot for the STATIC (inventory-classified) coverage
 * rows only, right after the inventory pass — before rollout scanning ever
 * starts. `bufferedState.coverage_diagnostics` is last-wins per stream, so a
 * later {@link emitDerivedCoverage} call in a run that goes on to finish
 * simply supersedes this snapshot with the richer static+derived one.
 *
 * Exists because a run that ends early — a sample-limit abort, a mid-scan
 * failure — never reaches {@link emitDerivedCoverage}, which used to be the
 * ONLY place `coverage_diagnostics` STATE was written. The inventory pass
 * that classifies `shell_snapshots`/`history`/etc. has nothing to do with
 * rollout scanning and already succeeded by this point, so its proof must
 * not be held hostage by a scan that hasn't even started yet: without this,
 * a store whose classification correctly changed (e.g. `missing` →
 * `inventory_only`) never gets a chance to refresh in the durable checkpoint
 * on any run that doesn't run to full completion, even though a fresh
 * `coverage_diagnostics` RECORD for it was already emitted and durably
 * ingested — a permanent split between the live per-store diagnostic and
 * the committed coverage-axis proof.
 */
async function emitStaticCoverageState(input) {
    if (!input.requested.has("coverage_diagnostics")) {
        return;
    }
    emit({
        type: "STATE",
        stream: "coverage_diagnostics",
        cursor: {
            fetched_at: input.nowIso(),
            stores: buildCoverageDiagnosticsStateSnapshot(input.inventory.coverage),
        },
    });
    await waitForEmitDrain();
}
/** Emit one inventory stream's records under a fingerprint gate that excludes
 *  incidental `mtime_epoch`/`size_bytes`, then write a per-stream STATE cursor
 *  carrying the fingerprints forward. Inventory enumeration is a full scan, so
 *  stale ids are pruned: a store that disappears drops out and re-appears as a
 *  fresh emit. */
async function emitGatedInventoryStream(input) {
    const cursor = openInventoryFingerprintCursor(input.priorState);
    for (const record of input.records) {
        if (cursor.shouldEmit(record)) {
            input.emitRecord(input.stream, record);
            await waitForEmitDrain();
        }
    }
    cursor.dropUnseenIds();
    const inventoryCursor = {
        fetched_at: input.nowIso(),
    };
    if (cursor.size() > 0) {
        inventoryCursor.fingerprints = cursor.toState();
    }
    emit({ type: "STATE", stream: input.stream, cursor: inventoryCursor });
    await waitForEmitDrain();
}
/** Inventory streams whose STATE cursor is owned by the fingerprint gate.
 *  These are the Codex `inventory_only`/`defer` stores plus the directory-
 *  listed `shell_snapshots`. `emitStateCursors` must NOT also write a bare
 *  `{ fetched_at }` STATE for these — that trailing write would clobber the
 *  fingerprint map and re-open the per-run churn the gate exists to close. */
export const CODEX_GATED_INVENTORY_STREAMS = [
    "history",
    "session_index",
    "shell_snapshots",
    "config_inventory",
    "cache_inventory",
];
/** Resolve one gated inventory stream's records: `shell_snapshots` is a live
 *  directory listing; every other gated stream reads from the pre-built
 *  store inventory's `recordsByStream` map (empty for an absent store). */
async function resolveGatedInventoryRecords(stream, codexHome, inventory) {
    if (stream !== "shell_snapshots") {
        return inventory.recordsByStream.get(stream) ?? [];
    }
    return await listDirectoryInventory({
        tool: "codex",
        sourceHome: codexHome,
        relativeRoot: "shell-snapshots",
        store: "shell_snapshots",
        stream: "shell_snapshots",
        reason: "shell content requires redaction review before payload collection",
    });
}
async function emitLocalInventoryStreams(input) {
    // `shell_snapshots` is enumerated via a directory listing rather than the
    // pre-built store inventory; everything else comes from `recordsByStream`
    // (empty for an absent store, which still produces a carry-forward STATE).
    for (const stream of CODEX_GATED_INVENTORY_STREAMS) {
        if (!input.requested.has(stream)) {
            continue;
        }
        const records = await resolveGatedInventoryRecords(stream, input.codexHome, input.inventory);
        await emitGatedInventoryStream({
            emitRecord: input.emitRecord,
            nowIso: input.nowIso,
            priorState: input.state[stream],
            records,
            stream,
        });
    }
}
/** Factory: returns the emitRecord closure + a live-updating emitted-count ref. */
function makeCodexEmitRecord(deps) {
    const { emittedAt, resFilters } = deps;
    const counters = { total: 0 };
    const emitRecord = (s, d) => {
        if (d.id == null) {
            return;
        }
        const resSet = resFilters.get(s);
        if (resSet && !resSet.has(String(d.id))) {
            return;
        }
        const validation = validateRecord(s, d);
        if (!validation.ok) {
            const message = `${String(d.id)}: ${validation.issues.map((i) => `${i.path}: ${i.message}`).join("; ")}`;
            emit({
                type: "SKIP_RESULT",
                stream: s,
                reason: "shape_check_failed",
                message,
            });
            return;
        }
        emit({
            type: "RECORD",
            stream: s,
            key: String(d.id),
            data: d,
            emitted_at: emittedAt,
        });
        counters.total += 1;
    };
    return { counters, emitRecord };
}
/**
 * Builds derived (rollout-scanned) coverage_diagnostics records for the
 * requested streams, emits them alongside the static inventory coverage,
 * then flushes the combined snapshot as the stream's STATE cursor.
 */
async function emitDerivedCoverage(input) {
    const { emitRecord, enumerationScope, inventory, nowIso, requested, rolloutScan, } = input;
    const derivedRecords = [];
    const scopeFingerprint = enumerationScopeFingerprint(enumerationScope);
    const scanComplete = rolloutScan.scanOutcome === "complete";
    const incompleteReason = scanComplete
        ? undefined
        : `rollout enumeration failed: ${rolloutScan.scanOutcome}`;
    if (requested.has("messages")) {
        derivedRecords.push(buildDerivedCoverageRecord({
            connectorId: "codex",
            emitted: rolloutScan.messagesEmitted,
            examined: rolloutScan.messagesExamined,
            incompleteReason,
            label: "message",
            scanComplete,
            scopeFingerprint,
            stream: "messages",
        }));
    }
    if (requested.has("function_calls")) {
        derivedRecords.push(buildDerivedCoverageRecord({
            connectorId: "codex",
            emitted: rolloutScan.functionCallsEmitted,
            examined: rolloutScan.functionCallsExamined,
            incompleteReason,
            label: "function_call",
            scanComplete,
            scopeFingerprint,
            stream: "function_calls",
        }));
    }
    // Emit derived records
    for (const record of derivedRecords) {
        emitRecord("coverage_diagnostics", record);
        await waitForEmitDrain();
    }
    // Emit STATE with snapshot including both static and derived records.
    const allCoverageRecords = [
        ...inventory.coverage,
        ...derivedRecords,
    ];
    emit({
        type: "STATE",
        stream: "coverage_diagnostics",
        cursor: {
            fetched_at: nowIso(),
            stores: buildCoverageDiagnosticsStateSnapshot(allCoverageRecords),
        },
    });
    await waitForEmitDrain();
}
// ─── main ───────────────────────────────────────────────────────────────
async function main() {
    const startMsg = await readStartMessage();
    if (startMsg.type !== "START") {
        return fail("Expected START");
    }
    const requested = buildRequestedMap(startMsg);
    if (!requested.size) {
        return fail("START.scope.streams is required");
    }
    const resFilters = buildResourceFilters(requested);
    const dirs = resolveCodexDirs();
    const fileMtimes = readFileMtimes(startMsg);
    const fileCursors = readPriorFileCursors(startMsg);
    const nowIso = () => new Date().toISOString();
    const emittedAt = nowIso();
    const { counters, emitRecord } = makeCodexEmitRecord({
        emittedAt,
        resFilters,
    });
    const needRollouts = requested.has("sessions") ||
        requested.has("messages") ||
        requested.has("function_calls");
    // Rollout aggregates per session (so `sessions` can carry message_count /
    // function_call_count even when state_5 provides the canonical metadata).
    const rolloutAggregates = new Map();
    const newMtimes = { ...fileMtimes };
    // The scan retains declared gaps and boundaries hidden by unreadable
    // directories, then replaces successfully read entries. Ungapped deleted
    // files drop out; disappearance alone cannot resolve a saved line gap.
    const newFileCursors = {};
    const sourceGaps = readPriorSourceGaps(startMsg);
    const scanStartedAtMs = Date.now();
    const sessionsSourceMtimeMs = fileMtimeMs(dirs.stateDbPath);
    let parsedRolloutFiles = 0;
    // Prior per-thread fingerprints (from last STATE cursor) gate which
    // thread sessions actually need to re-emit, and provide the count
    // fallback that prevents `message_count: null` overwrites when this
    // run didn't parse the matching rollout file. The shared carry-forward
    // cursor seeds its next map from the prior map (via openCarryForwardCursor),
    // so threads we deliberately don't re-emit carry their fingerprints
    // forward unchanged. The connector-specific decode + tolerant coercion of
    // the structured `ThreadFingerprint` shape stays in readPriorThreadFingerprints.
    const threadFingerprints = openCarryForwardCursor(readPriorThreadFingerprints(startMsg));
    // Build the source inventory and flush durable coverage diagnostics BEFORE
    // asserting requested content sources exist. A missing content store should
    // surface an honest `missing` coverage row, not abort the run with zero
    // coverage evidence — see emitCoverageDiagnostics. The inventory walk reads
    // only path metadata, never payload, so it is safe on a partial/empty home.
    const enumerationScope = readEnumerationScope(requested, [
        "sessions",
        "messages",
        "function_calls",
    ]);
    // The measured boundary is stamped onto the coverage records themselves,
    // so it commits atomically with the evidence it qualifies.
    const inventory = await buildLocalSourceInventory("codex", dirs.codexHome, CODEX_KNOWN_LOCAL_STORES, enumerationScopeFingerprint(enumerationScope));
    await emitCoverageDiagnostics({ emitRecord, inventory, requested });
    // Commit the static coverage proof now, independent of everything that
    // follows — see emitStaticCoverageState. assertRequestedCodexSources can
    // still throw right after this, and a sample-limit abort can still kill
    // the process during rollout scanning; either way this snapshot already
    // reached bufferedState and survives as the checkpoint if nothing later
    // supersedes it.
    await emitStaticCoverageState({ inventory, nowIso, requested });
    await assertRequestedCodexSources(dirs, requested);
    // The owner-declared boundary rides on the stream scopes the runtime already
    // threads through. Applied at ENUMERATION: the rollout tree is laid out as
    // yyyy/mm/dd, so a `since` prunes whole years, months, and days before they
    // are listed, and `source_roots` skips out-of-root files before they open.
    if (scopeBoundsEnumeration(enumerationScope)) {
        emit({
            type: "PROGRESS",
            message: `Codex phase=index pass=index enumeration_bounded=true since=${enumerationScope?.since ? "set" : "unset"} roots=${enumerationScope?.source_roots?.length ?? 0}`,
        });
    }
    await emitLocalInventoryStreams({
        codexHome: dirs.codexHome,
        emitRecord,
        inventory,
        nowIso,
        requested,
        state: startMsg.state || {},
    });
    let rolloutScan = {
        parsedFiles: 0,
        messagesEmitted: 0,
        messagesExamined: 0,
        functionCallsEmitted: 0,
        functionCallsExamined: 0,
        scanOutcome: "complete",
    };
    if (needRollouts) {
        rolloutScan = await scanRollouts({
            sourceGaps,
            activeQuietMs: resolveActiveRolloutQuietMs(),
            roots: [
                { baseDir: dirs.baseDir, label: "sessions" },
                { baseDir: dirs.archiveBaseDir, label: "sessions_archive" },
            ],
            fileCursors,
            fileMtimes,
            newFileCursors,
            newMtimes,
            requested,
            emitRecord,
            rolloutAggregates,
            scanStartedAtMs,
            seenCursorKeysThisScan: new Set(),
            scope: enumerationScope,
        });
        parsedRolloutFiles = rolloutScan.parsedFiles;
    }
    if (requested.has("sessions") &&
        (parsedRolloutFiles > 0 ||
            readPriorSessionsSourceMtimeMs(startMsg) !== sessionsSourceMtimeMs)) {
        emitSessions({
            stateDbPath: dirs.stateDbPath,
            rolloutAggregates,
            emitRecord,
            cursor: threadFingerprints,
        });
        await waitForEmitDrain();
    }
    if (requested.has("rules")) {
        await emitRulesStream(dirs.rulesDir, emitRecord);
    }
    if (requested.has("prompts")) {
        await emitPromptsStream(dirs.promptsDir, emitRecord);
    }
    if (requested.has("skills")) {
        await emitSkillsStream(dirs.skillsDir, emitRecord);
    }
    emitStateCursors({
        sourceGaps,
        requested,
        newFileCursors,
        newMtimes,
        nowIso,
        sessionsSourceMtimeMs,
        threadFingerprints,
    });
    await waitForEmitDrain();
    if (requested.has("coverage_diagnostics")) {
        await emitDerivedCoverage({
            emitRecord,
            enumerationScope,
            inventory,
            nowIso,
            requested,
            rolloutScan,
        });
    }
    emit({ type: "DONE", status: "succeeded", records_emitted: counters.total });
    flushAndExit(0);
}
// Guarded so `import "./index.ts"` in tests doesn't spin up the runtime
// and block the Node event loop on stdin. Only fires when this module
// IS the process entry point (i.e. `tsx connectors/codex/index.ts`).
if (isMainModule(import.meta.url)) {
    main().catch((e) => {
        const msg = e instanceof Error ? e.message : String(e);
        emit({
            type: "DONE",
            status: "failed",
            records_emitted: 0,
            error: { message: msg, retryable: false },
        });
        flushAndExit(1);
    });
}
