import { z } from "zod";
export declare const sessionsSchema: z.ZodObject<{
    id: z.ZodString;
    cwd: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    originator: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    cli_version: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    model_provider: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    git_commit: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    git_branch: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    repository_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    started_at: z.ZodNullable<z.ZodString>;
    last_event_at: z.ZodNullable<z.ZodString>;
    message_count: z.ZodNullable<z.ZodNumber>;
    function_call_count: z.ZodNullable<z.ZodNumber>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    archived: z.ZodNullable<z.ZodBoolean>;
    tokens_used: z.ZodNullable<z.ZodNumber>;
    first_user_message: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    sandbox_policy: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    approval_mode: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    rollout_path: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    blob_ref: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        blob_id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        mime_type: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        sha256: z.ZodString;
        size_bytes: z.ZodNumber;
    }, z.core.$strip>>>;
    artifact_capture: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        captured: "captured";
        failed: "failed";
        unavailable: "unavailable";
    }>>>;
    artifact_sha256: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
export declare const messagesSchema: z.ZodObject<{
    id: z.ZodString;
    session_id: z.ZodString;
    role: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    timestamp: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const functionCallsSchema: z.ZodObject<{
    id: z.ZodString;
    session_id: z.ZodString;
    call_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    arguments: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    output_preview: z.ZodNullable<z.ZodString>;
    output_binary_reason: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    timestamp: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const rulesSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    ruleset: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    rule_text: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    rule_index: z.ZodNumber;
    path: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    mtime_epoch: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const promptsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    path: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    mtime_epoch: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const skillsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    path: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    mtime_epoch: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const inventorySchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    store: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    relative_path: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    path_hash: z.ZodString;
    type: z.ZodEnum<{
        directory: "directory";
        file: "file";
        missing: "missing";
        other: "other";
    }>;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    mtime_epoch: z.ZodNullable<z.ZodNumber>;
    classification: z.ZodEnum<{
        defer: "defer";
        inventory_only: "inventory_only";
    }>;
    reason: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
export declare const coverageDiagnosticsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    store: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    stream: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodEnum<{
        collected: "collected";
        deferred: "deferred";
        excluded: "excluded";
        inventory_only: "inventory_only";
        missing: "missing";
        unsupported: "unsupported";
    }>;
    reason: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
/** Map stream name → schema. Single source of truth for what streams this
 *  connector produces at shape-check time. */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map