// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Default stream set for an unscoped `codex` local-collector run.
 *
 * Mirrors the full manifest-declared safe surface: `coverage_diagnostics` is
 * what promotes a drained local collector off `coverage_unknown` (the local
 * run path writes no spine run, so the connection-health rollup derives the
 * coverage axis from durable `coverage_diagnostics` records alone), and the
 * inventory streams emit metadata only (path hash, size, mtime).
 */
export const CODEX_DEFAULT_STREAMS = [
    "sessions",
    "messages",
    "function_calls",
    "rules",
    "prompts",
    "skills",
    "history",
    "session_index",
    "shell_snapshots",
    "config_inventory",
    "cache_inventory",
    "coverage_diagnostics",
];
/**
 * Streams an owner-declared `since` can be proven against — exactly those the
 * `codex` manifest gives a `consent_time_field` (`sessions.started_at`,
 * `messages.timestamp`, `function_calls.timestamp`).
 *
 * Streams without a consent time field remain whole-store under a time bound;
 * the runner keeps them in the requested inventory and marks them unscoped.
 */
export const CODEX_TIME_SCOPABLE_STREAMS = [
    "sessions",
    "messages",
    "function_calls",
];
export const CODEX_SOURCE_ROOT_SCOPABLE_STREAMS = CODEX_TIME_SCOPABLE_STREAMS;
export const codexCollectorDefinition = {
    connector_id: "codex",
    entry: "codex",
    bindings: { filesystem: { required: true } },
    // Declared explicitly (not omitted): this definition targets the
    // connector-protocol 0.0.2 capability-declaration contract, which
    // requires an explicit array even when empty. This connector emits no
    // STREAM_EVIDENCE and needs no protocol capability today.
    protocol_capabilities: [],
    streams: CODEX_DEFAULT_STREAMS,
    enforces_source_roots: true,
    source_root_scopable_streams: CODEX_SOURCE_ROOT_SCOPABLE_STREAMS,
    time_scopable_streams: CODEX_TIME_SCOPABLE_STREAMS,
};
