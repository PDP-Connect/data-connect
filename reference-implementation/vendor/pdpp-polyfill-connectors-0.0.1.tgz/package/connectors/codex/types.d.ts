import type { ArtifactCaptureStatus } from "../../src/artifact-capture.ts";
import type { RecordData, StreamScope } from "../../src/connector-runtime.ts";
/**
 * Per-thread fingerprint carried across runs. `updated_at` is the
 * state_5.sqlite#threads.updated_at epoch the connector last emitted
 * for this session. `message_count` and `function_call_count` are the
 * rollout-derived counts at that emit, used as the fallback when a
 * subsequent run's rollout file is unchanged (so the connector doesn't
 * overwrite a real count with null).
 *
 * `retained_sha256` is the session's body reference: the digest of bytes the
 * device holds for this session, recorded here rather than only on the rollout
 * file cursor. A file cursor is scan state whose ordinary lifecycle includes
 * dropping out when the source file is deleted, so it cannot be the sole
 * authority for a reference that is supposed to outlive the source. This map
 * is per-session, is seeded from the prior run and is never pruned, so the
 * reference survives the source's retirement. Absent on legacy cursors and on
 * sessions whose body was never captured.
 */
export interface ThreadFingerprint {
    function_call_count: number | null;
    message_count: number | null;
    retained_sha256?: string | null;
    updated_at: number | null;
}
/**
 * Per-rollout-file append-safe source cursor. Replaces the whole-file mtime
 * gate for rollout JSONL files so a long-lived append-only file is tailed from
 * its last committed byte boundary instead of fully reparsed on every append.
 *
 * `offset_bytes` always ends on a line terminator — the byte position after the
 * last parsed or explicitly gapped complete line. `line_count`, `session_id`, the two counts, and the
 * ts-range are the parser state at that boundary, carried forward so a suffix
 * parse continues the same record-key sequence and produces prior+delta
 * cumulative counts. `head_sha256` over the first `guard_bytes` of the file is
 * the integrity guard: a rollout file is append-only, so a changed prefix means
 * the file was truncated/replaced and the offset is no longer trustworthy.
 */
export interface RolloutFileCursor {
    /** Physical newline count, separate from the historical record-key counter. */
    source_line_count?: number;
    /**
     * sha256 of the rollout file's complete bytes as of `size_bytes`, present
     * only once those bytes are durably held in the artifact spool.
     *
     * This is the persisted half of the capture obligation, and it is a separate
     * fact from the byte offset beside it: `offset_bytes` says "these lines were
     * parsed into records", while this says "these bytes are recoverable". A
     * cursor written before capture existed, or by a run with no spool, has no
     * value here — which is exactly what a later capture-enabled run reads as
     * "body state unknown" and backfills once.
     */
    captured_sha256?: string;
    jsonl_gaps?: RolloutJsonlGap[];
    first_ts: string | null;
    function_call_count: number;
    guard_bytes: number;
    head_sha256: string;
    last_ts: string | null;
    line_count: number;
    message_count: number;
    mtime_ms: number;
    offset_bytes: number;
    session_id: string | null;
    size_bytes: number;
}
export interface RolloutJsonlGap {
    path: string;
    line_number: number;
    byte_offset: number;
    reason: "malformed_jsonl_line" | "non_object_jsonl_record" | "truncated_jsonl_tail";
}
export interface RolloutSourceGap {
    path: string;
    reason: "rollout_source_read_error";
    error_code: string | null;
}
interface RolloutStreamState {
    source_gaps?: Record<string, RolloutSourceGap>;
    file_cursors?: Record<string, RolloutFileCursor>;
    file_mtimes?: Record<string, number>;
}
export interface StartMessage {
    scope?: {
        streams?: readonly StreamScope[];
    };
    state?: {
        messages?: RolloutStreamState;
        function_calls?: RolloutStreamState;
        sessions?: RolloutStreamState & {
            source_mtime_ms?: number;
            thread_fingerprints?: Record<string, ThreadFingerprint>;
        };
        file_mtimes?: Record<string, number>;
    };
    type: string;
}
export interface RolloutObject {
    payload?: RolloutPayload;
    timestamp?: string;
    type?: string;
}
export interface RolloutPayload {
    arguments?: string | null;
    call_id?: string;
    cli_version?: string;
    content?: Array<{
        type?: string;
        text?: string;
    }>;
    cwd?: string;
    git?: {
        commit_hash?: string;
        branch?: string;
        repository_url?: string;
    };
    id?: string;
    model_provider?: string;
    name?: string;
    originator?: string;
    output?: string | object;
    role?: string;
    timestamp?: string;
    type?: string;
}
export interface ThreadRow {
    agent_nickname: string | null;
    agent_role: string | null;
    approval_mode: string | null;
    archived: number | boolean | null;
    archived_at: number | null;
    cli_version: string | null;
    created_at: number | null;
    cwd: string | null;
    first_user_message: string | null;
    git_branch: string | null;
    git_origin_url: string | null;
    git_sha: string | null;
    has_user_event: number | null;
    id: string;
    memory_mode: string | null;
    model: string | null;
    model_provider: string | null;
    reasoning_effort: string | null;
    rollout_path: string | null;
    sandbox_policy: string | null;
    source: string | null;
    title: string | null;
    tokens_used: number | null;
    updated_at: number | null;
}
export interface RolloutAggregate {
    /**
     * Outcome of capturing this session's rollout file, so an uncaptured body is
     * VISIBLE on the session record rather than indistinguishable from a session
     * that never had one. Absent when this run did not reach the capture path.
     */
    artifactCapture?: ArtifactCaptureStatus;
    /** sha256 of the complete rollout bytes, set only once they are held. */
    artifactSha256?: string | null;
    firstTs: string | null;
    functionCallCount: number;
    lastTs: string | null;
    messageCount: number;
    meta: RolloutPayload;
    rolloutPath: string;
}
export interface PendingCall extends RecordData {
    arguments: string | null;
    call_id: string;
    id: string;
    name: string | null;
    output_binary_reason?: string | null;
    output_preview: string | null;
    session_id: string;
    timestamp: string | null;
}
export interface ParsedFrontmatter {
    body: string;
    meta: Record<string, string>;
}
export {};
//# sourceMappingURL=types.d.ts.map