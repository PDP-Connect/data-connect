import type { ParsedFrontmatter, RolloutAggregate, RolloutPayload, ThreadFingerprint, ThreadRow } from "./types.ts";
export declare const YEAR_DIR_RE: RegExp;
export declare const TWO_DIGIT_DIR_RE: RegExp;
export declare const RULES_SUFFIX_RE: RegExp;
export declare const MD_SUFFIX_RE: RegExp;
export declare function textPreview(s: unknown, max?: number): string | null;
export declare function extractMessageText(payload: RolloutPayload): string | null;
export declare function payloadOutputPreview(output: unknown, max?: number): {
    preview: string | null;
    binaryReason: string | null;
};
export declare function epochToIso(sec: number | null | undefined): string | null;
export declare function parseFrontmatter(text: string): ParsedFrontmatter;
export declare function isRolloutFile(name: string): boolean;
/**
 * Extract the trailing session UUID from a rollout filename, or `null` when
 * the name doesn't carry the expected suffix (e.g. a legacy/malformed file
 * name). This is a pure, I/O-free identity hint used to key the per-file
 * parse cursor by session UUID instead of by path, so a rollout file that is
 * later relocated (e.g. archived to a second root; see
 * ARCHIVAL-CONTRACT.md) is still recognized as the SAME file and is not
 * fully reparsed — the file's content-derived identity never changes even
 * when its location does.
 */
export declare function extractRolloutUuidFromFilename(name: string): string | null;
/**
 * What durable state knows about a session's captured body, for a run that
 * built no fresh aggregate for it.
 *
 * Supplied by the caller from the cursor this run is about to persist, which
 * only ever carries a `captured_sha256` describing the CURRENT file generation
 * (every path that writes one has just proved size and mtime match, or has just
 * captured the bytes itself). This type is the reconciliation input, not a
 * second place to re-derive that rule.
 */
export interface SessionCaptureState {
    sha256: string;
}
export declare function buildThreadSessionRecord(id: string, t: ThreadRow, agg: RolloutAggregate | undefined, priorFingerprint?: ThreadFingerprint | null, durableCapture?: SessionCaptureState | undefined): Record<string, unknown>;
export declare function buildRolloutOnlySessionRecord(id: string, agg: RolloutAggregate, durableCapture?: SessionCaptureState | undefined): Record<string, unknown>;
export declare function splitRulesLines(text: string): string[];
export declare function isSkippableRulesLine(line: string): boolean;
export declare function buildRuleRecord(args: {
    ruleset: string;
    line: string;
    index: number;
    path: string;
    mtime: number;
}): Record<string, unknown>;
export declare function buildPromptRecord(args: {
    fileName: string;
    meta: Record<string, string>;
    body: string;
    path: string;
    mtimeMs: number;
}): Record<string, unknown>;
export declare function buildSkillRecord(args: {
    dirName: string;
    meta: Record<string, string>;
    body: string;
    path: string;
    mtimeMs: number;
}): Record<string, unknown>;
export interface TimestampRange {
    firstTs: string | null;
    lastTs: string | null;
}
export declare function extendTimestampRange(range: TimestampRange, ts: string | null): void;
//# sourceMappingURL=parsers.d.ts.map