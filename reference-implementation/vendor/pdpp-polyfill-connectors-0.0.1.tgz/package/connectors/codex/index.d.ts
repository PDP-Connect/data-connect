#!/usr/bin/env node
import { type RecordData, type StreamScope } from "@pdpp/connector-protocol";
import { type EnumerationScope } from "../../src/collection-scope-enumeration.ts";
import { type CarryForwardCursor } from "../../src/fingerprint-cursor.ts";
import { type KnownLocalStore } from "../../src/local-source-inventory.ts";
import type { PendingCall, RolloutAggregate, RolloutFileCursor, RolloutObject, RolloutPayload, StartMessage, ThreadFingerprint, ThreadRow } from "./types.ts";
export declare const CODEX_KNOWN_LOCAL_STORES: KnownLocalStore[];
export interface RolloutLineYield {
    /** Byte offset just past this line's terminating `\n`. This is the safe
     *  append boundary: a parse that stops here has consumed only fully
     *  newline-terminated lines, so a later run can resume from here without
     *  re-reading or splitting a partial line. */
    committedOffset: number;
    obj: RolloutObject;
}
/**
 * Stream a rollout JSONL file from `startOffset` (bytes), yielding each
 * newline-terminated JSON object together with the byte offset just past its
 * terminator. A trailing chunk with no final `\n` (an in-flight append) is
 * NOT yielded and its bytes are NOT counted toward the committed offset — it
 * is re-read on a later run once the writer finishes the line. Memory stays
 * bounded: at most one line plus the current read chunk is held.
 *
 * Byte offsets are tracked over the raw bytes (Buffer length), not decoded
 * characters, so a multi-byte UTF-8 sequence advances the offset by its true
 * byte length and the resume offset always lands on a real byte boundary.
 * A malformed complete line throws instead of being consumed, so callers
 * cannot checkpoint past an unresolved source gap.
 */
export declare function iterJsonlLinesFromOffset(path: string, startOffset: number): AsyncGenerator<RolloutLineYield>;
export declare function walkRollouts(baseDir: string, scope?: EnumerationScope | null): AsyncGenerator<{
    path: string;
    year: string;
    month: string;
    day: string;
    file: string;
}>;
/**
 * The rich per-file parse cursor's map key. Prefers the session UUID parsed
 * out of the filename (stable across a relocation between the sessions/ and
 * sessions-archive/ roots — see ARCHIVAL-CONTRACT.md) and falls back to the
 * full path only for a filename that doesn't carry the expected UUID suffix
 * (never observed on a real Codex install, but a malformed/legacy name
 * degrades to the pre-fix path-keyed behavior rather than dropping the
 * cursor silently).
 */
export declare function cursorKeyForEntry(entry: {
    file: string;
    path: string;
}): string;
/** Injected deps threaded through every per-line emit helper. Mirrors the
 *  amazon/chase/slack pattern: one stable bag so parseRolloutFile becomes
 *  pure orchestration and each helper is individually testable. */
export interface LineEmitDeps {
    emitRecord: (stream: string, data: RecordData) => void;
    /** Coarse progress hook fired every 2000 lines. Tests wire this to a
     *  recorder; production wires it to the runtime `emit(PROGRESS)`. */
    progress: (message: string) => void;
    requested: Map<string, StreamScope>;
}
export interface RolloutParseState {
    firstTimestamp: string | null;
    functionCallCount: number;
    lastTimestamp: string | null;
    lineCount: number;
    messageCount: number;
    pendingCalls: Map<string, PendingCall>;
    sessionId: string | null;
    sessionMeta: RolloutPayload | null;
}
/** Optional seed for an append-only resume. Carries forward the parser
 *  counters and identity that an appended suffix continues, so suffix record
 *  keys (`${sessionId}:${lineCount}`) never collide with already-emitted keys
 *  and the resulting aggregate counts are cumulative (prior + delta). The
 *  appended suffix has no `session_meta` line, so seeding `sessionId` is what
 *  attributes the suffix response_items to the right session. */
export interface RolloutParseSeed {
    firstTimestamp: string | null;
    functionCallCount: number;
    lastTimestamp: string | null;
    lineCount: number;
    messageCount: number;
    sessionId: string | null;
}
export declare function makeRolloutParseState(seed?: RolloutParseSeed): RolloutParseState;
export interface ProcessResponseItemArgs {
    deps: LineEmitDeps;
    payload: RolloutPayload;
    state: RolloutParseState;
    ts: string | null;
}
/**
 * Dispatch one response_item payload. Each branch is gated by the matching
 * stream in `requested.has(...)`: a message payload only emits when
 * `messages` is requested; a function_call / function_call_output payload
 * only emits when `function_calls` is requested. `reasoning` payloads are
 * silently dropped — encrypted_content is opaque.
 *
 * Side effect on state: the messageCount / functionCallCount counters
 * advance unconditionally (so the session aggregate stays accurate even
 * when the corresponding record stream is gated off).
 */
export declare function processResponseItem({ deps, payload, state, ts, }: ProcessResponseItemArgs): void;
export interface ProcessRolloutLineArgs {
    deps: LineEmitDeps;
    file: string;
    obj: RolloutObject;
    state: RolloutParseState;
}
export declare function shouldDeferActiveRolloutFile(input: {
    mtimeMs: number;
    nowMs: number;
    quietMs: number;
}): boolean;
/**
 * Dispatch one JSONL line:
 *   - session_meta → install session id + metadata on state, but only
 *     from the FIRST session_meta line in the file. Forked rollouts
 *     emit additional session_meta lines describing the fork parent
 *     chain; those must NOT overwrite the canonical (child) session id,
 *     otherwise every response_item that follows would be attributed to
 *     the parent and the child session's message/function counts would
 *     stay null.
 *   - response_item → delegate to processResponseItem (iff sessionId seen).
 *   - anything else → silent no-op, line counter still advances.
 *
 * Fires a progress signal every PROGRESS_EVERY lines for large rollout
 * files. Timestamps extend the first/last range on every line regardless
 * of dispatch, so the session aggregate covers the full file span.
 */
export declare function processRolloutLine({ deps, obj, state, }: ProcessRolloutLineArgs): void;
/**
 * Emit any function_call that never saw a matching function_call_output.
 * A function_call payload registers a PendingCall in state.pendingCalls; a
 * matching function_call_output now emits the merged record and removes the
 * entry immediately (see applyFunctionCallOutput), so `pendingCalls` only ever
 * holds calls still awaiting their output. At EOF we drain whatever's left —
 * calls whose output never arrived in this parse window — with a null
 * output_preview, so the function_calls stream lands every call exactly once.
 *
 * Because paired calls drain on their output line, this map is bounded by the
 * number of concurrently-open (unanswered) calls, NOT by the file size — which
 * is what keeps a multi-GB session parse memory-bounded.
 */
export declare function flushPendingCalls(state: RolloutParseState, deps: LineEmitDeps): void;
export interface EmitSessionsFromMapsArgs {
    /**
     * Shared carry-forward cursor over the per-thread `ThreadFingerprint`.
     * This run's emitted sessions `note` a fresh fingerprint, and skipped
     * sessions carry their prior fingerprint forward unchanged (the cursor
     * seeds its next map from the prior). The caller serializes
     * `cursor.toState()` into the next `sessions` STATE cursor so the chain
     * stays intact across runs.
     *
     * The cursor owns two behaviors the connector relies on:
     *   1. Lossy-overwrite repair: `cursor.prior(id)` supplies the prior
     *      counts when this run did NOT parse the session's rollout file, so
     *      a state_5-only update doesn't clobber a real `message_count` with
     *      `null` (see `buildThreadSessionRecord` / `makeThreadFingerprint`).
     *   2. Churn reduction: `shouldReemitThreadSession` skips emitting a
     *      thread entirely when none of (a) rollout parsed this run,
     *      (b) thread.updated_at moved, (c) the session id is new. No emit =
     *      no new history version. The cursor still carries the fingerprint
     *      forward so the next run can gate against it.
     *
     * Omitted by callers that don't need the cursor (e.g. unit tests pinning
     * the legacy emit-everything contract); in that case every thread emits
     * and no fingerprints are tracked.
     */
    cursor?: CarryForwardCursor<ThreadFingerprint>;
    emitRecord: (stream: string, data: RecordData) => void;
    rolloutAggregates: Map<string, RolloutAggregate>;
    threadsMap: Map<string, ThreadRow>;
}
/**
 * Decide whether a thread session needs to be re-emitted this run.
 * Returns true if any of:
 *   - The session id is new (no prior fingerprint).
 *   - This run parsed the session's rollout file (counts may have moved).
 *   - The thread's `updated_at` is strictly greater than the prior
 *     fingerprint's `updated_at` (state_5 actually changed for this row).
 *
 * Returns false when the row is byte-for-byte the same shape we'd build —
 * skipping the emit avoids a new history version downstream.
 */
export declare function shouldReemitThreadSession(thread: ThreadRow, agg: RolloutAggregate | undefined, priorFingerprint: ThreadFingerprint | undefined): boolean;
/**
 * I/O-free sessions emitter: given a pre-loaded threads map (from
 * state_5.sqlite) and a map of rollout aggregates (from parseRolloutFile),
 * emit one `sessions` record per unique session id.
 *
 * Invariants:
 *   - Thread rows emit first, in threadsMap iteration order. Each thread
 *     is merged with its aggregate (so message_count / function_call_count
 *     reflect the on-disk rollout even when state_5 is canonical for the
 *     rest of the fields).
 *   - When prior fingerprints are supplied, threads whose `updated_at`
 *     hasn't advanced AND whose rollout wasn't parsed this run are
 *     skipped — this stops the state_5-mtime-only churn that was
 *     creating an excess record version per scan.
 *   - When a thread is emitted without a fresh aggregate, the prior
 *     fingerprint's counts fill in for `message_count` /
 *     `function_call_count`. Without this, a state_5-only update would
 *     overwrite a real count with `null` and grow history with a
 *     lossy version.
 *   - Rollout-only sessions (on disk but not in state_5) emit with nulls
 *     for state_5-only fields so the schema stays consistent.
 *   - Dedup is on session id: a session present in both maps emits ONCE
 *     (thread-preferred). Tests pin this — a regression would double-emit.
 */
export declare function emitSessionsFromMaps({ threadsMap, rolloutAggregates, emitRecord, cursor, }: EmitSessionsFromMapsArgs): void;
export type RolloutAction = 
/** size+mtime match the cursor — nothing changed, skip the file. */
{
    kind: "skip";
}
/** No tracked cursor or legacy-mtime-only entry that changed — parse the
 *  whole file from offset 0 and write a fresh cursor. */
 | {
    kind: "full";
}
/** Cursor present, file grew, prefix guard verified — tail the suffix from
 *  the committed offset, seeding the parser to continue the sequence. */
 | {
    kind: "append";
    startOffset: number;
    seed: RolloutParseSeed;
}
/** Cursor present but file shrank / offset past EOF / prefix guard changed —
 *  truncated or replaced, full reparse from offset 0 to avoid data loss. */
 | {
    kind: "unsafe_full";
};
/**
 * Decide how to process one rollout file given its current stat and the prior
 * per-file cursor (if any). Pure + I/O-free over its inputs: the caller
 * supplies the recomputed prefix-guard hash (or null when the file is too
 * short / unreadable) so this stays unit-testable. `guardMatches` is only
 * consulted on the grow path — a verified prefix is required before tailing.
 */
export declare function decideRolloutAction(input: {
    cursor: RolloutFileCursor | undefined;
    guardMatches: boolean;
    mtimeMs: number;
    sizeBytes: number;
}): RolloutAction;
/**
 * Decode the prior per-file rollout cursors from STATE. Tolerant of legacy
 * cursors (no `file_cursors` field), wrong types, and partially-corrupt
 * entries — a malformed entry is dropped (its file then full-reparses once)
 * rather than failing the run. Checks the rollout streams plus the sessions
 * stream so the lookup survives whichever stream carried the cursor.
 */
export declare function readPriorFileCursors(startMsg: StartMessage): Record<string, RolloutFileCursor>;
/**
 * Parse the prior `sessions` STATE cursor's `thread_fingerprints` map.
 * Tolerant of legacy cursors (no fingerprints), missing field, wrong
 * types, or values from a partially-different schema — bad entries are
 * silently dropped rather than failing the whole run.
 */
export declare function readPriorThreadFingerprints(startMsg: unknown): Map<string, ThreadFingerprint>;
/** Inventory streams whose STATE cursor is owned by the fingerprint gate.
 *  These are the Codex `inventory_only`/`defer` stores plus the directory-
 *  listed `shell_snapshots`. `emitStateCursors` must NOT also write a bare
 *  `{ fetched_at }` STATE for these — that trailing write would clobber the
 *  fingerprint map and re-open the per-run churn the gate exists to close. */
export declare const CODEX_GATED_INVENTORY_STREAMS: readonly ["history", "session_index", "shell_snapshots", "config_inventory", "cache_inventory"];
//# sourceMappingURL=index.d.ts.map