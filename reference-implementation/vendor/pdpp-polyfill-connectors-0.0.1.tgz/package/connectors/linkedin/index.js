#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { politeDelay, runConnector, } from "../../src/connector-runtime.js";
import { validateRecord } from "./schemas.js";
const SESSION_COOKIE = /li_at|JSESSIONID/;
runConnector({
    name: "linkedin",
    browser: {},
    validateRecord,
    async probeSession({ context }) {
        const cookies = await context.cookies("https://www.linkedin.com/");
        return cookies.some((c) => SESSION_COOKIE.test(c.name) && Boolean(c.value));
    },
    async collect({ page, emit }) {
        await page
            .goto("https://www.linkedin.com/in/me/", {
            waitUntil: "domcontentloaded",
            timeout: 30_000,
        })
            .catch(() => undefined);
        await politeDelay(3000);
        await emit({
            type: "SKIP_RESULT",
            stream: "profile",
            reason: "linkedin_voyager_wiring_pending",
            message: "LinkedIn session reachable. Voyager API endpoint wiring deferred to live session (hostile anti-bot; conservative approach).",
        });
    },
});
