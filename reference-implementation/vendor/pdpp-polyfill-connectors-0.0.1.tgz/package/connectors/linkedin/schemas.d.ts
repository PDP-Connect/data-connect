import { z } from "zod";
/**
 * profile stream (manifest required: id). One record: the owner's profile.
 * Every text field is free-form human content → pdppSafeText; public_url is a
 * URL.
 */
export declare const profileSchema: z.ZodObject<{
    id: z.ZodString;
    full_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    headline: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    summary: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    location: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    industry: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    public_url: z.ZodNullable<z.ZodURL>;
    current_position_title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    current_company: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
/**
 * experience stream (manifest required: id). One record per role.
 */
export declare const experienceSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    company: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    employment_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    start_date: z.ZodNullable<z.ZodString>;
    end_date: z.ZodNullable<z.ZodString>;
    location: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
/**
 * education stream (manifest required: id). One record per school.
 */
export declare const educationSchema: z.ZodObject<{
    id: z.ZodString;
    school: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    degree: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    field_of_study: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    start_date: z.ZodNullable<z.ZodString>;
    end_date: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * skills stream (manifest required: id, name). One record per skill.
 */
export declare const skillsSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    endorsement_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the streams this
 * connector declares (and will emit once Voyager extraction is wired).
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map