/**
 * Zod schemas for Jellyfin stream records. Used for shape-check-before-emit
 * per docs/reference/connector-authoring-guide.md §3: records that don't match the
 * schema become SKIP_RESULT events instead of RECORD events.
 *
 * Jellyfin REST API shapes: User can query libraries (Views) and items
 * within libraries, with playback metadata (LastPlayedDate, PlayCount, Played;
 * playback fields are nullable when Jellyfin omits UserData).
 * No session-level history in core API; PlaybackReporting plugin optional for history.
 */
import { z } from "zod";
/**
 * Jellyfin libraries (Views) — root containers (Movies, TV Shows, Music, etc.).
 * Note: fetched_at is a collection-time field added by the connector, not from Jellyfin API.
 */
export declare const librariesSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    collection_type: z.ZodNullable<z.ZodString>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
/**
 * Jellyfin items — media files (movies, TV episodes, songs, etc.) with playback metadata.
 *
 * last_played_date can be null (never played).
 * play_count and played are nullable when Jellyfin omits UserData; absence is
 * not evidence of zero playback.
 * image_url is optional for cover art; constructed from Jellyfin image endpoints.
 * provider_ids are external identifiers (IMDb, TVDB, TMDB) from Jellyfin's ProviderIds.
 */
export declare const itemsSchema: z.ZodObject<{
    id: z.ZodString;
    library_id: z.ZodString;
    name: z.ZodString;
    type: z.ZodNullable<z.ZodString>;
    played: z.ZodNullable<z.ZodBoolean>;
    play_count: z.ZodNullable<z.ZodNumber>;
    last_played_date: z.ZodNullable<z.ZodString>;
    image_url: z.ZodNullable<z.ZodString>;
    genres: z.ZodArray<z.ZodString>;
    release_date: z.ZodNullable<z.ZodString>;
    provider_ids: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodString>>;
    production_year: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
export declare const JellyfinSystemInfoSchema: z.ZodObject<{
    Id: z.ZodString;
    ServerName: z.ZodString;
    Version: z.ZodString;
}, z.core.$strip>;
export type JellyfinSystemInfo = z.infer<typeof JellyfinSystemInfoSchema>;
export declare const JellyfinViewSchema: z.ZodObject<{
    Id: z.ZodString;
    Name: z.ZodString;
    CollectionType: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    PrimaryImageTag: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
export declare const JellyfinItemSchema: z.ZodObject<{
    Id: z.ZodString;
    Name: z.ZodString;
    Type: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    UserData: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        PlayCount: z.ZodOptional<z.ZodNumber>;
        Played: z.ZodOptional<z.ZodBoolean>;
        LastPlayedDate: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>>;
    Genres: z.ZodOptional<z.ZodArray<z.ZodString>>;
    PremiereDate: z.ZodOptional<z.ZodString>;
    PrimaryImageTag: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    ProviderIds: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    ProductionYear: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>;
export declare const JellyfinViewsResponseSchema: z.ZodObject<{
    Items: z.ZodArray<z.ZodObject<{
        Id: z.ZodString;
        Name: z.ZodString;
        CollectionType: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        PrimaryImageTag: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const JellyfinItemsResponseSchema: z.ZodObject<{
    Items: z.ZodArray<z.ZodObject<{
        Id: z.ZodString;
        Name: z.ZodString;
        Type: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        UserData: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            PlayCount: z.ZodOptional<z.ZodNumber>;
            Played: z.ZodOptional<z.ZodBoolean>;
            LastPlayedDate: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>>>;
        Genres: z.ZodOptional<z.ZodArray<z.ZodString>>;
        PremiereDate: z.ZodOptional<z.ZodString>;
        PrimaryImageTag: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        ProviderIds: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        ProductionYear: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>;
    TotalRecordCount: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export declare function validateSystemInfo(data: unknown): JellyfinSystemInfo;
export declare function validateViewsResponse(data: unknown): {
    Items: {
        Id: string;
        Name: string;
        CollectionType?: string | null | undefined;
        PrimaryImageTag?: string | null | undefined;
    }[];
};
export declare function validateItemsResponse(data: unknown): {
    Items: {
        Id: string;
        Name: string;
        Type?: string | null | undefined;
        UserData?: {
            PlayCount?: number | undefined;
            Played?: boolean | undefined;
            LastPlayedDate?: string | null | undefined;
        } | null | undefined;
        Genres?: string[] | undefined;
        PremiereDate?: string | undefined;
        PrimaryImageTag?: string | null | undefined;
        ProviderIds?: Record<string, any> | undefined;
        ProductionYear?: number | null | undefined;
    }[];
    TotalRecordCount?: number | undefined;
};
//# sourceMappingURL=schemas.d.ts.map