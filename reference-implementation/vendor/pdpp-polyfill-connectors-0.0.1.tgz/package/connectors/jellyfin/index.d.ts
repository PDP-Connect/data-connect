#!/usr/bin/env node
import { type CollectContext, type RecordData } from "../../src/connector-runtime.ts";
export declare const JELLYFIN_RETRYABLE_PATTERN: RegExp;
/**
 * Build the well-formed `MediaBrowser Client=..., Device=..., DeviceId=...,
 * Version=...` Authorization header AuthenticateByName requires.
 *
 * NON-NEGOTIABLE SAFETY CONSTRAINT: a malformed header on this exact
 * endpoint is a known Jellyfin defect (jellyfin/jellyfin#11484) that wipes
 * the server's ENTIRE Devices table, and does not require admin rights to
 * trigger. Every field must be present and non-empty — pinned by
 * authenticate-by-name.test.ts so a future edit cannot silently drop one.
 */
declare function buildMediaBrowserAuthHeader(deviceId: string): string;
/**
 * Derive a stable per-connection DeviceId rather than a fresh random one per
 * run. AuthenticateByName registers a Devices-table row per distinct
 * DeviceId; a fresh UUID every run would grow that table unboundedly for a
 * connector that authenticates on a recurring schedule. The caller seeds
 * this with the connection's base URL + username, so repeated runs of the
 * same connection consistently reuse one device entry.
 */
declare function deriveStableDeviceId(seed: string): string;
/**
 * Normalize Jellyfin's `PremiereDate` to the `items.release_date` schema's
 * bare `YYYY-MM-DD` shape. Jellyfin serializes PremiereDate as a full
 * .NET DateTime round-trip string (e.g. "1994-09-23T00:00:00.0000000Z"),
 * never a bare date — the schema's own regex source (schemas.ts) expects
 * only the date portion, so the leading `YYYY-MM-DD` is extracted here
 * rather than relaxing the schema to accept a shape release_date was never
 * meant to carry.
 *
 * Only two input shapes are accepted: an exact bare date, or a bare date
 * followed by a structurally valid ISO-8601 time-of-day suffix. An
 * arbitrary trailing suffix (e.g. "2021-01-01garbage") is NOT a datetime
 * and is rejected, not silently truncated to its leading digits. The
 * extracted date is also checked against the real UTC calendar (rejects
 * e.g. "2021-99-99" and "2021-02-30") so a structurally-shaped but
 * impossible date cannot pass through.
 *
 * Absence is preserved honestly: missing/null/non-string/unparseable/
 * impossible-calendar-date input becomes null rather than a fabricated
 * date, and a value that merely doesn't parse does not discard the rest of
 * the record — only this field degrades to null.
 */
declare function normalizeReleaseDate(premiereDate: unknown): string | null;
/**
 * Build an items record from a Jellyfin Item with UserData and library_id.
 */
export declare function itemRecord(item: Record<string, unknown>, libraryId: string): RecordData;
declare function collect(ctx: CollectContext): Promise<void>;
export { collect };
export declare const __setMaxPagesPerStream: (n: number) => void;
export declare const __setMaxJsonBytes: (n: number) => void;
export { buildMediaBrowserAuthHeader, deriveStableDeviceId, normalizeReleaseDate, };
//# sourceMappingURL=index.d.ts.map