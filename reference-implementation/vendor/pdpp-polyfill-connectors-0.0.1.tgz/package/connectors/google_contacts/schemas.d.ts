import { z } from "zod";
export declare const peopleSchema: z.ZodObject<{
    id: z.ZodString;
    resource_name: z.ZodString;
    deleted: z.ZodBoolean;
    display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    names: z.ZodArray<z.ZodObject<{
        display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        family_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        given_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>;
    email_addresses: z.ZodArray<z.ZodObject<{
        type: z.ZodNullable<z.ZodString>;
        value: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    phone_numbers: z.ZodArray<z.ZodObject<{
        type: z.ZodNullable<z.ZodString>;
        value: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    addresses: z.ZodArray<z.ZodObject<{
        city: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        formatted_value: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        type: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    organizations: z.ZodArray<z.ZodObject<{
        name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>;
    biography: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    nickname: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    photo_url: z.ZodNullable<z.ZodString>;
    contact_group_resource_names: z.ZodArray<z.ZodString>;
    updated: z.ZodNullable<z.ZodString>;
    source: z.ZodLiteral<"google_people_api">;
}, z.core.$strip>;
export declare const contactGroupsSchema: z.ZodObject<{
    id: z.ZodString;
    resource_name: z.ZodString;
    name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    member_count: z.ZodNumber;
    source: z.ZodLiteral<"google_people_api">;
}, z.core.$strip>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map