export type PeopleFetch = (url: string, init: RequestInit) => Promise<Response>;
export interface PeopleClientOptions {
    readonly accessToken: string;
    readonly baseUrl?: string;
    readonly fetch?: PeopleFetch;
}
export declare class PeopleApiError extends Error {
    readonly bodySnippet: string;
    readonly status: number;
    constructor(status: number, bodySnippet: string);
}
/** Thrown when Google reports the syncToken is no longer valid (HTTP 410
 *  GONE) — the documented behavior once a token ages past its 7-day
 *  validity window. */
export declare class PeopleSyncTokenExpiredError extends Error {
    constructor();
}
export interface PersonName {
    readonly displayName: string | null;
    readonly familyName: string | null;
    readonly givenName: string | null;
}
export interface PersonEmail {
    readonly type: string | null;
    readonly value: string | null;
}
export interface PersonPhone {
    readonly type: string | null;
    readonly value: string | null;
}
export interface PersonAddress {
    readonly city: string | null;
    readonly formattedValue: string | null;
    readonly type: string | null;
}
export interface PersonOrganization {
    readonly name: string | null;
    readonly title: string | null;
}
export interface Person {
    readonly addresses: readonly PersonAddress[];
    readonly biography: string | null;
    readonly deleted: boolean;
    readonly emailAddresses: readonly PersonEmail[];
    readonly memberships: readonly string[];
    readonly names: readonly PersonName[];
    readonly nickname: string | null;
    readonly organizations: readonly PersonOrganization[];
    readonly phoneNumbers: readonly PersonPhone[];
    readonly photoUrl: string | null;
    readonly resourceName: string;
    readonly updated: string | null;
}
export interface ConnectionsPage {
    readonly nextPageToken: string | null;
    readonly nextSyncToken: string | null;
    readonly people: readonly Person[];
}
export interface ContactGroup {
    readonly memberCount: number;
    readonly name: string | null;
    readonly resourceName: string;
}
export declare class GooglePeopleClient {
    private readonly accessToken;
    private readonly baseUrl;
    private readonly fetchImpl;
    constructor(options: PeopleClientOptions);
    /**
     * GET /people/me/connections, one page. `syncToken` requests an
     * incremental delta (deleted contacts surface with `PersonMetadata.deleted:
     * true`); its absence requests a full listing. Throws
     * `PeopleSyncTokenExpiredError` on HTTP 410 — Google's documented signal
     * that the (up-to-7-day-old) syncToken is no longer valid.
     */
    listConnectionsPage(options?: {
        pageToken?: string;
        syncToken?: string;
    }): Promise<ConnectionsPage>;
    /** GET /contactGroups — the owner's contact groups (labels). Not
     *  incremental; small collection, re-enumerated each run. */
    listContactGroups(): Promise<ContactGroup[]>;
    private request;
}
//# sourceMappingURL=api.d.ts.map