#!/usr/bin/env node
import { type CollectContext } from "../../src/connector-runtime.ts";
import { type GoogleAccessToken } from "../../src/google-oauth.ts";
import type { ConnectionsPage, ContactGroup } from "./api.ts";
/**
 * The persisted per-stream cursor this connector writes at the end of a run
 * and reads at the start of the next one.
 *
 * EXPORTED SO TESTS CANNOT DRIFT FROM IT. A hand-built state fixture that is
 * not checked against this type is a second, unversioned copy of the cursor
 * contract: nothing type-checks a JSON blob, so a new gating field would be
 * silently absent from the fixture and the test would quietly start
 * exercising — and asserting against — the wrong branch. That is exactly how
 * apple_contacts' `initial_sync_completed` gate slipped past its own tests.
 * `syncTokenIsStale` below already gates on the PAIR
 * `sync_token`+`synced_at`; keep fixtures typed as `GoogleContactsState` so
 * any future gate lands as a compile error in the tests, not as silence.
 */
export interface PeopleState {
    readonly fingerprints?: Record<string, string>;
    readonly sync_token?: string;
    readonly synced_at?: string;
}
export interface GoogleContactsState {
    readonly contact_groups?: {
        fingerprints?: Record<string, string>;
    };
    readonly people?: PeopleState;
}
interface PeopleClientLike {
    listConnectionsPage: (options: {
        pageToken?: string;
        syncToken?: string;
    }) => Promise<ConnectionsPage>;
    listContactGroups: () => Promise<ContactGroup[]>;
}
interface ContactsCollectOptions {
    readonly clientFactory?: (accessToken: string) => PeopleClientLike;
    readonly env?: NodeJS.ProcessEnv | Record<string, string | undefined>;
    readonly getAccessToken?: () => Promise<GoogleAccessToken>;
    /** Test seam: lowers the page ceiling so truncation is reachable without
     *  standing up {@link MAX_PAGES} pages of fixtures. */
    readonly maxPages?: number;
    readonly now?: () => number;
}
export declare function collectGoogleContacts(ctx: CollectContext, options?: ContactsCollectOptions): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map