#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * PDPP Google Contacts Connector (v0.1.0)
 *
 * Official People API v1 (OAuth2, `contacts.readonly` scope). Reuses the
 * shared Google OAuth refresh primitive (src/google-oauth.ts) — its second
 * concrete consumer alongside Google Calendar, per the reconciliation
 * report's §14 rule that the primitive extracts only once two consumers
 * exist.
 *
 * Streams: people, contact_groups.
 *
 * Incremental mechanism: `syncToken` (the real, LIVE People API mechanism —
 * NOT the dead Contacts API v3's `updated-min`). Deletion is in-band via
 * `PersonMetadata.deleted: true`. Google documents sync tokens as expiring 7
 * days after the full sync that produced them, so this connector tracks the
 * token's age explicitly and forces a full resync BEFORE that boundary,
 * defense-in-depth alongside the reactive HTTP 410 handler (Calendar's
 * syncToken expiry is unconfirmed to have the same fixed window, so it relies
 * on 410 alone; Contacts' 7-day window is confirmed, so a proactive check is
 * warranted here) — mirroring YNAB's existing incremental-fallback shape.
 *
 * State shape:
 *   {
 *     people: { sync_token?: string, synced_at?: string, fingerprints: { [resourceName]: sha1 } },
 *     contact_groups: { fingerprints: { [resourceName]: sha1 } }
 *   }
 *
 * Auth: GOOGLE_OAUTH_CLIENT_ID / GOOGLE_OAUTH_CLIENT_SECRET (shared Google app
 * registration) + GOOGLE_CONTACTS_REFRESH_TOKEN (this connector's own consent
 * grant, distinct from Calendar's).
 */
import { isMainModule } from "@pdpp/connector-protocol";
import { createConnectorHttpGovernor } from "../../src/connector-http-governor.js";
import { emitDetailCoverage, runConnector, } from "../../src/connector-runtime.js";
import { openFingerprintCursor, } from "../../src/fingerprint-cursor.js";
import { isGoogleOAuthGrantInvalid, refreshGoogleAccessToken, resolveGoogleOAuthCredentials, } from "../../src/google-oauth.js";
import { walkPagesWithCeiling } from "../../src/page-ceiling.js";
import { google_contactsPacingProfile } from "../../src/provider-profile.js";
import { GooglePeopleClient, PeopleSyncTokenExpiredError } from "./api.js";
import { validateRecord } from "./schemas.js";
const REFRESH_TOKEN_ENV_VAR = "GOOGLE_CONTACTS_REFRESH_TOKEN";
const MAX_PAGES = 500;
/** Google documents syncToken validity as 7 days from the full sync that
 *  produced it (reconciliation report §5). Force a resync one day early so a
 *  run landing exactly on day 7 does not race the boundary. */
const SYNC_TOKEN_MAX_AGE_MS = 6 * 24 * 60 * 60 * 1000;
const httpGovernor = createConnectorHttpGovernor({
    name: "google_contacts",
    maxAttempts: 1,
    profile: google_contactsPacingProfile(),
});
/** See the matching comment in connectors/google_calendar/index.ts: the HTTP
 *  governor wraps a first-attempt throw in RetryExhaustedError. */
function isSyncTokenExpired(error) {
    if (error instanceof PeopleSyncTokenExpiredError) {
        return true;
    }
    return (error instanceof Error &&
        "originalCause" in error &&
        error.originalCause instanceof
            PeopleSyncTokenExpiredError);
}
function displayName(person) {
    return person.names[0]?.displayName ?? null;
}
function personRecord(person) {
    return {
        id: person.resourceName,
        resource_name: person.resourceName,
        deleted: person.deleted,
        display_name: displayName(person),
        names: person.names.map((n) => ({
            display_name: n.displayName,
            family_name: n.familyName,
            given_name: n.givenName,
        })),
        email_addresses: person.emailAddresses.map((e) => ({
            type: e.type,
            value: e.value,
        })),
        phone_numbers: person.phoneNumbers.map((p) => ({
            type: p.type,
            value: p.value,
        })),
        addresses: person.addresses.map((a) => ({
            city: a.city,
            formatted_value: a.formattedValue,
            type: a.type,
        })),
        organizations: person.organizations.map((o) => ({
            name: o.name,
            title: o.title,
        })),
        biography: person.biography,
        nickname: person.nickname,
        photo_url: person.photoUrl,
        contact_group_resource_names: person.memberships,
        updated: person.updated,
        source: "google_people_api",
    };
}
function contactGroupRecord(group) {
    return {
        id: group.resourceName,
        resource_name: group.resourceName,
        name: group.name,
        member_count: group.memberCount,
        source: "google_people_api",
    };
}
/** `updated` is Google's server-side write timestamp on the person's most
 *  recent source; like Calendar's event `updated`, it can move without a
 *  human-visible content change, so it is excluded from the change signal. */
const PERSON_FINGERPRINT_EXCLUDE = ["updated"];
function syncTokenIsStale(state, now) {
    if (!(state?.sync_token && state.synced_at)) {
        return false;
    }
    const syncedAtMs = Date.parse(state.synced_at);
    if (Number.isNaN(syncedAtMs)) {
        return false;
    }
    return now() - syncedAtMs >= SYNC_TOKEN_MAX_AGE_MS;
}
async function syncPeoplePages(args) {
    const { client, ctx, cursor, maxPages, syncToken } = args;
    let pageToken;
    let nextSyncToken = null;
    let considered = 0;
    let covered = 0;
    const walk = await walkPagesWithCeiling({
        maxPages,
        fetchPage: async (pageNumber) => {
            const page = await httpGovernor.request(() => client.listConnectionsPage({
                ...(syncToken ? { syncToken } : {}),
                ...(pageToken ? { pageToken } : {}),
            }), (value) => ({ status: 200, value }));
            await ctx.progress(`Fetched Google Contacts connections page ${String(pageNumber)}`, {
                stream: "people",
                count: page.value.people.length,
            });
            for (const person of page.value.people) {
                const record = personRecord(person);
                considered += 1;
                // The runtime drops a record that fails its shape check (it emits a
                // SKIP_RESULT instead of a RECORD), so asking the same validator here
                // is what separates "accounted for" from "weighed and dropped".
                // Without this the two counts could never diverge and the stream would
                // report 100% coverage even while every contact was being rejected.
                if (validateRecord("people", record).ok) {
                    covered += 1;
                }
                if (cursor.shouldEmit(record)) {
                    await ctx.emitRecord("people", record);
                }
            }
            pageToken = page.value.nextPageToken ?? undefined;
            nextSyncToken = page.value.nextSyncToken ?? nextSyncToken;
            return Boolean(pageToken);
        },
    });
    return {
        fullResync: !(syncToken || walk.truncated),
        nextSyncToken: walk.truncated ? (syncToken ?? null) : nextSyncToken,
        considered: considered + (walk.truncated ? 1 : 0),
        covered,
        truncated: walk.truncated,
    };
}
async function syncPeopleWithFallback(args) {
    const { client, ctx, cursor, maxPages, priorState, now } = args;
    const tokenIsStale = syncTokenIsStale(priorState, now);
    const syncToken = tokenIsStale ? undefined : priorState?.sync_token;
    if (tokenIsStale) {
        await ctx.progress("Google Contacts syncToken is past its 7-day validity window — forcing full resync", {
            stream: "people",
        });
    }
    try {
        return await syncPeoplePages({ client, ctx, cursor, maxPages, syncToken });
    }
    catch (error) {
        if (!isSyncTokenExpired(error)) {
            throw error;
        }
        await ctx.progress("Google Contacts syncToken rejected by the API (410) — falling back to full resync", {
            stream: "people",
        });
        return await syncPeoplePages({
            client,
            ctx,
            cursor,
            maxPages,
            syncToken: undefined,
        });
    }
}
export async function collectGoogleContacts(ctx, options = {}) {
    const env = options.env ?? process.env;
    const maxPages = options.maxPages ?? MAX_PAGES;
    const now = options.now ?? Date.now;
    const getAccessToken = options.getAccessToken ??
        (async () => {
            const credentials = resolveGoogleOAuthCredentials(env, REFRESH_TOKEN_ENV_VAR);
            try {
                return await refreshGoogleAccessToken(credentials);
            }
            catch (error) {
                if (isGoogleOAuthGrantInvalid(error)) {
                    throw new Error("google_contacts_auth_failed", { cause: error });
                }
                throw error;
            }
        });
    const wantsPeople = ctx.requested.has("people");
    const wantsGroups = ctx.requested.has("contact_groups");
    if (!(wantsPeople || wantsGroups)) {
        await ctx.progress("No Google Contacts streams requested", {
            stream: "people",
        });
        return;
    }
    const { accessToken } = await getAccessToken();
    const client = options.clientFactory
        ? options.clientFactory(accessToken)
        : new GooglePeopleClient({ accessToken });
    const state = ctx.state ?? {};
    if (wantsGroups) {
        const groups = await httpGovernor.request(() => client.listContactGroups(), (value) => ({ status: 200, value }));
        const groupsCursor = openFingerprintCursor(state.contact_groups);
        for (const group of groups.value) {
            const record = contactGroupRecord(group);
            if (groupsCursor.shouldEmit(record)) {
                await ctx.emitRecord("contact_groups", record);
            }
        }
        groupsCursor.dropUnseenIds();
        await ctx.emit({
            type: "STATE",
            stream: "contact_groups",
            cursor: { fingerprints: groupsCursor.toState() },
        });
    }
    if (!wantsPeople) {
        return;
    }
    const peopleCursor = openFingerprintCursor(state.people, {
        excludeFromFingerprint: [...PERSON_FINGERPRINT_EXCLUDE],
    });
    const result = await syncPeopleWithFallback({
        client,
        ctx,
        cursor: peopleCursor,
        maxPages,
        priorState: state.people,
        now,
    });
    // A syncToken response is a PARTIAL delta; only a full resync (no
    // syncToken, or the fallback path) may prune stale fingerprints — matching
    // the Calendar connector's identical rule.
    if (result.fullResync) {
        peopleCursor.dropUnseenIds();
    }
    if (result.truncated) {
        await ctx.emit({
            type: "SKIP_RESULT",
            stream: "people",
            reason: "older_pages_deferred_page_budget",
            // The ceiling reported here is the one actually enforced, not the module
            // default — otherwise a lowered cap would disclose a limit the walk
            // never applied.
            message: `Google Contacts stopped at the ${String(maxPages)}-page limit with more people listed`,
            diagnostics: { page_limit: maxPages, unread_pages: 1 },
        });
    }
    const nextPeopleState = {
        ...(result.nextSyncToken
            ? {
                sync_token: result.nextSyncToken,
                synced_at: new Date(now()).toISOString(),
            }
            : {}),
        fingerprints: peopleCursor.toState(),
    };
    await ctx.emit({ type: "STATE", stream: "people", cursor: nextPeopleState });
    // Counted at the page loop, not from the cursor. `peopleCursor.size()` is
    // the carry-forward map — it is seeded from prior state, so on a syncToken
    // delta run it includes every contact this run never even looked at, and
    // using it for both counts made coverage report 100% by construction.
    // `covered` omits any person the shape check would reject, so a drop shows
    // up as a shortfall rather than a silent green.
    await emitDetailCoverage(ctx, {
        stream: "people",
        stateStream: "people",
        requiredKeys: [],
        hydratedKeys: [],
        considered: result.considered,
        covered: result.covered,
    });
}
if (isMainModule(import.meta.url)) {
    runConnector({
        name: "google_contacts",
        validateRecord,
        retryablePattern: /429|5\d\d|timeout|temporar|rate|unavailable|google_people_api_error/i,
        isTombstone: (stream, data) => stream === "people" && data.deleted === true,
        auth: {
            kind: "env",
            required: [
                "GOOGLE_OAUTH_CLIENT_ID",
                "GOOGLE_OAUTH_CLIENT_SECRET",
                REFRESH_TOKEN_ENV_VAR,
            ],
        },
        collect: (ctx) => collectGoogleContacts(ctx),
    });
}
