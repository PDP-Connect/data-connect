// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import test from "node:test";
import type {
	CollectContext,
	EmittedMessage,
	RecordData,
	StartMessage,
	StreamScope,
} from "../../src/connector-runtime.ts";
import type { ConnectionsPage, ContactGroup, Person } from "./api.ts";
import { PeopleSyncTokenExpiredError } from "./api.ts";
import type { GoogleContactsState } from "./index.ts";
import { collectGoogleContacts } from "./index.ts";

class FakePeopleClient {
	readonly calls: Array<{ args?: unknown; method: string }> = [];
	private readonly groups: ContactGroup[];
	private readonly connectionPages: ConnectionsPage[];
	private readonly onListConnections?: (options: {
		pageToken?: string;
		syncToken?: string;
	}) => ConnectionsPage;

	constructor(args: {
		connectionPages?: ConnectionsPage[];
		groups?: ContactGroup[];
		onListConnections?: (options: {
			pageToken?: string;
			syncToken?: string;
		}) => ConnectionsPage;
	}) {
		this.groups = args.groups ?? [];
		this.connectionPages = args.connectionPages ?? [];
		if (args.onListConnections) {
			this.onListConnections = args.onListConnections;
		}
	}

	listConnectionsPage(options: {
		pageToken?: string;
		syncToken?: string;
	}): Promise<ConnectionsPage> {
		this.calls.push({ args: options, method: "listConnectionsPage" });
		if (this.onListConnections) {
			return Promise.resolve(this.onListConnections(options));
		}
		const page = this.connectionPages.shift();
		assert.ok(
			page,
			"unexpected listConnectionsPage call — no fake page queued",
		);
		return Promise.resolve(page);
	}

	listContactGroups(): Promise<ContactGroup[]> {
		this.calls.push({ method: "listContactGroups" });
		return Promise.resolve(this.groups);
	}
}

function makePerson(
	overrides: Partial<Person> & { resourceName: string },
): Person {
	return {
		addresses: [],
		biography: null,
		deleted: false,
		emailAddresses: [],
		memberships: [],
		names: [
			{ displayName: "Ada Lovelace", familyName: "Lovelace", givenName: "Ada" },
		],
		nickname: null,
		organizations: [],
		phoneNumbers: [],
		photoUrl: null,
		updated: "2026-08-01T00:00:00Z",
		...overrides,
	};
}

function makeContext({
	state = {},
	streams = [{ name: "people" }, { name: "contact_groups" }],
}: {
	readonly state?: GoogleContactsState;
	readonly streams?: readonly StreamScope[];
} = {}): {
	readonly ctx: CollectContext;
	readonly messages: EmittedMessage[];
	readonly records: Array<{ data: RecordData; stream: string }>;
} {
	const messages: EmittedMessage[] = [];
	const records: Array<{ data: RecordData; stream: string }> = [];
	// `StartMessage.state` is the runtime's connector-agnostic open bag; the
	// fixture stays typed as `GoogleContactsState` and widens only here.
	const startState: Record<string, unknown> = { ...state };
	const start: StartMessage = {
		type: "START",
		scope: { streams },
		state: startState,
	};
	return {
		messages,
		records,
		ctx: {
			assist: () => Promise.resolve("asst_test"),
			capture: null,
			completeAssistance: () => Promise.resolve(),
			credentials: {},
			detailGaps: [],
			emit: (msg) => {
				messages.push(msg);
				return Promise.resolve();
			},
			emitRecord: (stream, data) => {
				records.push({ data, stream });
				return Promise.resolve();
			},
			emittedAt: "2026-08-07T00:00:00.000Z",
			progress: () => Promise.resolve(),
			requested: new Map(streams.map((stream) => [stream.name, stream])),
			requestDetailGapPage: () => Promise.resolve([]),
			scope: start.scope,
			sendInteraction: () =>
				Promise.resolve({
					request_id: "int_test",
					status: "cancelled" as const,
					type: "INTERACTION_RESPONSE" as const,
				}),
			state: startState,
		},
	};
}

const ENV = {
	GOOGLE_OAUTH_CLIENT_ID: "client-id",
	GOOGLE_OAUTH_CLIENT_SECRET: "client-secret",
	GOOGLE_CONTACTS_REFRESH_TOKEN: "refresh-token",
};

const FAKE_TOKEN = {
	getAccessToken: () =>
		Promise.resolve({
			accessToken: "ya29.fake",
			expiresAt: Date.now() + 3_600_000,
		}),
};
const FIXED_NOW = Date.parse("2026-08-07T00:00:00Z");

function lastStateCursor(
	messages: readonly EmittedMessage[],
	stream: string,
): unknown {
	const found = [...messages]
		.reverse()
		.find((msg) => msg.type === "STATE" && msg.stream === stream);
	return found && found.type === "STATE" ? found.cursor : undefined;
}

test("emits people and contact_groups, advancing the syncToken cursor", async () => {
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [makePerson({ resourceName: "people/c1" })],
				nextPageToken: null,
				nextSyncToken: "sync-1",
			},
		],
		groups: [
			{
				resourceName: "contactGroups/myContacts",
				name: "My Contacts",
				memberCount: 1,
			},
		],
	});
	const { ctx, records } = makeContext();

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	assert.equal(records.filter((r) => r.stream === "people").length, 1);
	assert.equal(records.filter((r) => r.stream === "contact_groups").length, 1);
});

test("pages through multiple connection pages before advancing the cursor", async () => {
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [makePerson({ resourceName: "people/c1" })],
				nextPageToken: "page2",
				nextSyncToken: null,
			},
			{
				people: [makePerson({ resourceName: "people/c2" })],
				nextPageToken: null,
				nextSyncToken: "sync-final",
			},
		],
	});
	const { ctx, records } = makeContext({ streams: [{ name: "people" }] });

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	const calls = fakeClient.calls.filter(
		(c) => c.method === "listConnectionsPage",
	);
	assert.equal(calls.length, 2);
	assert.equal(records.filter((r) => r.stream === "people").length, 2);
});

test("a page cap with a continuation token discloses truncation instead of claiming coverage", async () => {
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [makePerson({ resourceName: "people/c1" })],
				nextPageToken: "page2",
				nextSyncToken: null,
			},
			{
				people: [makePerson({ resourceName: "people/c2" })],
				nextPageToken: null,
				nextSyncToken: "sync-final",
			},
		],
	});
	const { ctx, messages, records } = makeContext({
		streams: [{ name: "people" }],
	});

	// The ceiling is hit while the provider still advertises another page. The
	// run keeps the prefix it enumerated but must disclose the shortfall rather
	// than let a truncated walk read as a complete one.
	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		maxPages: 1,
		...FAKE_TOKEN,
	});

	assert.equal(
		records.filter((r) => r.stream === "people").length,
		1,
		"the enumerated prefix may be emitted",
	);
	const skip = messages.find(
		(message): message is Extract<typeof message, { type: "SKIP_RESULT" }> =>
			message.type === "SKIP_RESULT" && message.stream === "people",
	);
	assert.ok(skip, "a truncated walk must disclose itself to the owner");
	assert.equal(skip.reason, "older_pages_deferred_page_budget");
	assert.match(
		skip.message,
		/1-page limit/,
		"the disclosed ceiling must be the one actually enforced",
	);
	// Coverage IS emitted on a truncated walk — suppressing it would leave the
	// stream with no denominator at all. What must never happen is a COMPLETE
	// claim: the unread page inflates `considered`, so the shortfall is visible.
	const coverage = messages.find(
		(
			message,
		): message is Extract<typeof message, { type: "DETAIL_COVERAGE" }> =>
			message.type === "DETAIL_COVERAGE" && message.stream === "people",
	);
	assert.ok(coverage, "a truncated walk still needs a denominator");
	const { considered, covered } = coverage;
	assert.equal(
		typeof considered,
		"number",
		"a coverage claim without a denominator is not a claim",
	);
	assert.equal(
		typeof covered,
		"number",
		"a coverage claim without a numerator is not a claim",
	);
	assert.ok(
		(considered as number) > (covered as number),
		`truncation must read as a shortfall, got ${String(covered)}/${String(considered)}`,
	);
});

test("carries forward the prior syncToken cursor on an incremental run", async () => {
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [makePerson({ resourceName: "people/c2" })],
				nextPageToken: null,
				nextSyncToken: "sync-2",
			},
		],
	});
	const priorState = {
		people: {
			sync_token: "sync-1",
			synced_at: "2026-08-06T00:00:00Z",
			fingerprints: {},
		},
	};
	const { ctx } = makeContext({
		state: priorState,
		streams: [{ name: "people" }],
	});

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	const call = fakeClient.calls.find((c) => c.method === "listConnectionsPage");
	assert.ok(call);
	assert.equal((call.args as { syncToken?: string }).syncToken, "sync-1");
});

test("deleted person (PersonMetadata.deleted) emits a tombstone record", async () => {
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [
					makePerson({
						resourceName: "people/c-gone",
						deleted: true,
						names: [],
					}),
				],
				nextPageToken: null,
				nextSyncToken: "sync-1",
			},
		],
	});
	const { ctx, records } = makeContext({ streams: [{ name: "people" }] });

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	const personRecord = records.find((r) => r.stream === "people");
	assert.ok(personRecord);
	assert.equal(personRecord.data.deleted, true);
});

test("falls back to a full resync when the syncToken has expired (HTTP 410)", async () => {
	let call = 0;
	const fakeClient = new FakePeopleClient({
		onListConnections: (options) => {
			call += 1;
			if (call === 1) {
				assert.equal(options.syncToken, "sync-expired");
				throw new PeopleSyncTokenExpiredError();
			}
			assert.equal(options.syncToken, undefined);
			return {
				people: [makePerson({ resourceName: "people/c-full" })],
				nextPageToken: null,
				nextSyncToken: "sync-fresh",
			};
		},
	});
	const priorState = {
		people: {
			sync_token: "sync-expired",
			synced_at: "2026-08-06T00:00:00Z",
			fingerprints: { stale: "abc" },
		},
	};
	const { ctx, messages, records } = makeContext({
		state: priorState,
		streams: [{ name: "people" }],
	});

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	assert.equal(records.filter((r) => r.stream === "people").length, 1);
	const cursor = lastStateCursor(messages, "people") as {
		sync_token?: string;
		fingerprints?: Record<string, string>;
	};
	assert.equal(cursor.sync_token, "sync-fresh");
	assert.equal(cursor.fingerprints?.stale, undefined);
});

test("proactively forces a full resync when the syncToken is past its 7-day window, without waiting for a 410", async () => {
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [makePerson({ resourceName: "people/c1" })],
				nextPageToken: null,
				nextSyncToken: "sync-new",
			},
		],
	});
	// synced_at is 8 days before FIXED_NOW — past the 6-day proactive threshold.
	const eightDaysAgo = new Date(
		FIXED_NOW - 8 * 24 * 60 * 60 * 1000,
	).toISOString();
	const priorState = {
		people: {
			sync_token: "sync-old",
			synced_at: eightDaysAgo,
			fingerprints: {},
		},
	};
	const { ctx } = makeContext({
		state: priorState,
		streams: [{ name: "people" }],
	});

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	const call = fakeClient.calls.find((c) => c.method === "listConnectionsPage");
	assert.ok(call);
	// No syncToken sent — full resync requested proactively, before any 410.
	assert.equal((call.args as { syncToken?: string }).syncToken, undefined);
});

test("does not force a full resync when the syncToken is still within its validity window", async () => {
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [makePerson({ resourceName: "people/c1" })],
				nextPageToken: null,
				nextSyncToken: "sync-new",
			},
		],
	});
	const oneDayAgo = new Date(FIXED_NOW - 1 * 24 * 60 * 60 * 1000).toISOString();
	const priorState = {
		people: {
			sync_token: "sync-recent",
			synced_at: oneDayAgo,
			fingerprints: {},
		},
	};
	const { ctx } = makeContext({
		state: priorState,
		streams: [{ name: "people" }],
	});

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	const call = fakeClient.calls.find((c) => c.method === "listConnectionsPage");
	assert.ok(call);
	assert.equal((call.args as { syncToken?: string }).syncToken, "sync-recent");
});

test("unchanged person does not re-emit but the cursor still advances", async () => {
	const person = makePerson({ resourceName: "people/c1" });
	const seedCtx = makeContext({ streams: [{ name: "people" }] });
	await collectGoogleContacts(seedCtx.ctx, {
		clientFactory: () =>
			new FakePeopleClient({
				connectionPages: [
					{ people: [person], nextPageToken: null, nextSyncToken: "sync-1" },
				],
			}),
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});
	const seededState = lastStateCursor(seedCtx.messages, "people");

	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{ people: [person], nextPageToken: null, nextSyncToken: "sync-2" },
		],
	});
	const { ctx, records } = makeContext({
		state: { people: seededState as Record<string, unknown> },
		streams: [{ name: "people" }],
	});
	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	assert.equal(records.filter((r) => r.stream === "people").length, 0);
});

test("no-op when neither people nor contact_groups streams are requested", async () => {
	const fakeClient = new FakePeopleClient({});
	const { ctx, records } = makeContext({ streams: [] });

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	assert.equal(fakeClient.calls.length, 0);
	assert.equal(records.length, 0);
});

// ─── Default credential-resolution path (no getAccessToken override) ────
//
// Every test above passes FAKE_TOKEN, which bypasses collectGoogleContacts's
// own default `getAccessToken` closure entirely — a dead or silently-broken
// refreshGoogleAccessToken()/resolveGoogleOAuthCredentials() call would not
// fail any of them. This test omits the override so the connector's real
// default path (src/google-oauth.ts, reached via the global `fetch`) runs
// end to end: it stubs `globalThis.fetch` for the token endpoint only, and
// asserts the access token handed to the client factory is the one that
// ONLY a real refresh exchange could have produced.

test("default getAccessToken path calls the real Google OAuth token endpoint and forwards its access_token to the client", async () => {
	const originalFetch = globalThis.fetch;
	const tokenCalls: Array<{ body: string; url: string }> = [];
	globalThis.fetch = ((url: string, init: RequestInit) => {
		tokenCalls.push({ body: String(init.body ?? ""), url: String(url) });
		return Promise.resolve(
			new Response(
				JSON.stringify({
					access_token: "ya29.from-real-refresh-flow",
					expires_in: 3600,
				}),
				{
					headers: { "Content-Type": "application/json" },
					status: 200,
				},
			),
		);
	}) as typeof fetch;

	try {
		const fakeClient = new FakePeopleClient({
			connectionPages: [
				{ people: [], nextPageToken: null, nextSyncToken: "sync-1" },
			],
		});
		let capturedAccessToken: string | null = null;
		const { ctx } = makeContext({ streams: [{ name: "people" }] });

		// No getAccessToken override — exercises collectGoogleContacts's own
		// default closure, which must call resolveGoogleOAuthCredentials +
		// refreshGoogleAccessToken exactly as production does.
		await collectGoogleContacts(ctx, {
			clientFactory: (accessToken) => {
				capturedAccessToken = accessToken;
				return fakeClient;
			},
			env: ENV,
			now: () => FIXED_NOW,
		});

		assert.equal(
			tokenCalls.length,
			1,
			"the real token endpoint must be called exactly once",
		);
		assert.equal(tokenCalls[0]?.url, "https://oauth2.googleapis.com/token");
		const params = new URLSearchParams(tokenCalls[0]?.body ?? "");
		assert.equal(params.get("client_id"), ENV.GOOGLE_OAUTH_CLIENT_ID);
		assert.equal(params.get("client_secret"), ENV.GOOGLE_OAUTH_CLIENT_SECRET);
		assert.equal(
			params.get("refresh_token"),
			ENV.GOOGLE_CONTACTS_REFRESH_TOKEN,
		);
		assert.equal(params.get("grant_type"), "refresh_token");
		assert.equal(capturedAccessToken, "ya29.from-real-refresh-flow");
	} finally {
		globalThis.fetch = originalFetch;
	}
});

test("default getAccessToken path surfaces google_contacts_auth_failed on invalid_grant (400) without calling the client", async () => {
	const originalFetch = globalThis.fetch;
	globalThis.fetch = (() =>
		Promise.resolve(
			new Response(JSON.stringify({ error: "invalid_grant" }), {
				headers: { "Content-Type": "application/json" },
				status: 400,
			}),
		)) as typeof fetch;

	try {
		let clientFactoryCalled = false;
		const { ctx } = makeContext({ streams: [{ name: "people" }] });

		await assert.rejects(
			() =>
				collectGoogleContacts(ctx, {
					clientFactory: () => {
						clientFactoryCalled = true;
						return new FakePeopleClient({});
					},
					env: ENV,
					now: () => FIXED_NOW,
				}),
			/google_contacts_auth_failed/,
		);
		assert.equal(
			clientFactoryCalled,
			false,
			"a revoked grant must fail before any client is constructed",
		);
	} finally {
		globalThis.fetch = originalFetch;
	}
});

// ─── Coverage accounting ─────────────────────────────────────────────────
//
// `considered`/`covered` used to both be `peopleCursor.size()`, which made a
// shortfall unreportable: the two counts were the same expression, so the
// stream read 100% covered no matter what the run actually did. These pin the
// two ways that lie showed up.

function peopleCoverage(
	messages: readonly EmittedMessage[],
): Extract<EmittedMessage, { type: "DETAIL_COVERAGE" }> | undefined {
	return messages.find(
		(msg): msg is Extract<EmittedMessage, { type: "DETAIL_COVERAGE" }> =>
			msg.type === "DETAIL_COVERAGE" && msg.stream === "people",
	);
}

test("a person the shape check rejects is considered but NOT covered", async () => {
	// `biography` is `pdppSafeText` — a NUL byte makes the record fail the
	// runtime's shape check, so it is dropped rather than stored. The run
	// therefore accounted for only one of the two contacts it enumerated.
	const poisoned = makePerson({
		resourceName: "people/c2",
		biography: `bio${String.fromCharCode(0)}drift`,
	});
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [makePerson({ resourceName: "people/c1" }), poisoned],
				nextPageToken: null,
				nextSyncToken: "sync-1",
			},
		],
	});
	const { ctx, messages } = makeContext({ streams: [{ name: "people" }] });

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	const coverage = peopleCoverage(messages);
	assert.ok(coverage, "people must emit DETAIL_COVERAGE");
	assert.equal(
		coverage?.considered,
		2,
		"both enumerated contacts were weighed",
	);
	assert.equal(
		coverage?.covered,
		1,
		"the rejected contact must NOT count as covered — this is the shortfall",
	);
});

test("an incremental syncToken run counts only what it enumerated, not the carry-forward cursor", async () => {
	// The delta returns one changed contact; prior STATE holds three. Counting
	// the cursor made `considered` 3 — contacts this run never looked at — which
	// is exactly the fabricated denominator the contract forbids.
	const priorState = {
		people: {
			sync_token: "sync-prior",
			synced_at: new Date(FIXED_NOW).toISOString(),
			fingerprints: {
				"people/c1": "aaa",
				"people/c2": "bbb",
				"people/c3": "ccc",
			},
		},
	};
	const fakeClient = new FakePeopleClient({
		connectionPages: [
			{
				people: [makePerson({ resourceName: "people/c2" })],
				nextPageToken: null,
				nextSyncToken: "sync-next",
			},
		],
	});
	const { ctx, messages } = makeContext({
		state: priorState,
		streams: [{ name: "people" }],
	});

	await collectGoogleContacts(ctx, {
		clientFactory: () => fakeClient,
		env: ENV,
		now: () => FIXED_NOW,
		...FAKE_TOKEN,
	});

	const coverage = peopleCoverage(messages);
	assert.equal(
		coverage?.considered,
		1,
		"a delta run enumerated exactly one contact",
	);
	assert.equal(coverage?.covered, 1, "and accounted for it");
});
