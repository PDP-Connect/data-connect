#!/usr/bin/env node
import { type ConnectorHttpGovernor } from "../../src/connector-http-governor.ts";
import { type CollectContext, type RecordData } from "../../src/connector-runtime.ts";
import { type FingerprintCursor } from "../../src/fingerprint-cursor.ts";
interface YnabFetchOptions {
    knowledge?: number;
    sinceDate?: string;
}
interface YnabBudget {
    currency_format?: {
        iso_code?: string | null;
        currency_symbol?: string | null;
        symbol_first?: boolean | null;
        decimal_digits?: number | null;
        decimal_separator?: string | null;
        group_separator?: string | null;
    } | null;
    date_format?: {
        format?: string | null;
    } | null;
    first_month?: string | null;
    id: string;
    last_modified_on?: string | null;
    last_month?: string | null;
    name: string;
}
interface YnabAccount {
    balance: number;
    cleared_balance: number;
    closed: boolean;
    debt_escrow_amounts?: Record<string, unknown> | null;
    debt_interest_rates?: Record<string, unknown> | null;
    debt_minimum_payments?: Record<string, unknown> | null;
    deleted: boolean;
    direct_import_in_error?: boolean | null;
    direct_import_linked?: boolean | null;
    id: string;
    last_reconciled_at?: string | null;
    name: string;
    note?: string | null;
    on_budget: boolean;
    transfer_payee_id?: string | null;
    type: string;
    uncleared_balance: number;
}
interface YnabCategory {
    activity: number;
    balance: number;
    budgeted: number;
    category_group_id?: string | null;
    category_group_name?: string | null;
    deleted: boolean;
    goal_cadence?: number | null;
    goal_cadence_frequency?: number | null;
    goal_creation_month?: string | null;
    goal_day?: number | null;
    goal_months_to_budget?: number | null;
    goal_needs_whole_amount?: boolean | null;
    goal_overall_funded?: number | null;
    goal_overall_left?: number | null;
    goal_percentage_complete?: number | null;
    goal_snoozed_at?: string | null;
    goal_target?: number | null;
    goal_target_date?: string | null;
    goal_type?: string | null;
    goal_under_funded?: number | null;
    hidden: boolean;
    id: string;
    name: string;
    note?: string | null;
}
interface YnabPayeeLocation {
    deleted: boolean;
    id: string;
    latitude: string;
    longitude: string;
    payee_id: string;
}
interface YnabMonth {
    activity: number;
    age_of_money?: number | null;
    budgeted: number;
    categories?: YnabCategory[];
    deleted: boolean;
    income: number;
    month: string;
    note?: string | null;
    to_be_budgeted: number;
}
/**
 * Reduce a non-2xx response body to a diagnostic safe for a terminal message.
 *
 * The body is attacker- and proxy-influenced text: YNAB's own errors are a small
 * closed envelope, but an intercepting proxy, a gateway error page, or a WAF can
 * return anything, and an echoed request URL or account content in that text
 * would land verbatim in a terminal DB row. Slicing to 200 chars bounded the size
 * and enforced nothing.
 *
 * Two layers, allowlist first:
 *
 *  1. YNAB documents `{ error: { id, name, detail } }`. When the body parses to
 *     that shape we emit only those fields — `id`/`name` are closed machine codes
 *     (`401`/`unauthorized`, `403.1`/`subscription_lapsed`) and are exactly what
 *     an operator needs. `detail` is free prose, so it still goes through the
 *     shared redactor rather than being trusted for being inside a known shape.
 *  2. Anything else — HTML, a proxy dump, malformed JSON — is not a shape we can
 *     reason about, so it is redacted wholesale and bounded.
 *
 * `redactTransportDetail` is reused deliberately: one deterministic sanitizer for
 * every third-party string that can reach terminal text, rather than a second
 * policy that drifts from the first.
 */
export declare function errorDetail(body: string): string;
export type YnabRequest = <T>(path: string, token: string, options?: YnabFetchOptions, progress?: ProgressFn, extra?: Parameters<ProgressFn>[1]) => Promise<T>;
export declare function createYnabRequest(governor: Pick<ConnectorHttpGovernor, "request">): YnabRequest;
export declare const ynab: YnabRequest;
/**
 * Keep retryable failures from the optional account-type enrichment request
 * visible to the outer run. A transient failure there still consumed a YNAB
 * request and must not be relabeled as a successful transaction collection.
 * Permanent endpoint errors remain non-fatal because the transaction payload
 * itself is still useful without account-type enrichment.
 */
export declare function isYnabRetryableError(error: unknown): boolean;
interface TimeRange {
    since?: string;
    until?: string;
}
export declare function rewindOneMonth(monthIso: string): string;
/**
 * Fields excluded from the `budgets` fingerprint.
 *
 * `last_month` and `last_modified_on` move without a corresponding change to
 * the budget-summary content this stream actually projects:
 *
 *   - `last_month` is the most-recent budget month YNAB has materialized.
 *     YNAB rolls active budgets forward automatically, so this advances on
 *     the 1st of every calendar month even when the owner has touched
 *     nothing. It is a clock, not a user edit to a budget-summary field.
 *   - `last_modified_on` is the budget's last-modified timestamp. It ticks
 *     on *any* edit anywhere in the budget — a single transaction, a
 *     category assignment, a memo — none of which change the fields this
 *     stream emits (name, currency locale, date format, first month).
 *     Those edits surface in their own streams (`transactions`,
 *     `categories`, …); re-emitting the budget summary for them is the
 *     unbounded forward churn this gate removes (~273 versions/budget in the
 *     2026-05-26 churn report).
 *
 * Every remaining field — name, currency locale, date format, and
 * `first_month` — is a real budget-summary source fact, so a genuine edit to
 * any of them still re-emits the budget. This matches the design-note rule
 * "exclude volatile collection-time fields from durable record identity
 * unless those fields are source facts"
 * (design-notes/record-version-churn-and-noop-semantics-2026-05-26.md).
 */
export declare const BUDGET_FINGERPRINT_EXCLUDE: readonly ["last_month", "last_modified_on"];
export declare function budgetRecord(b: YnabBudget): RecordData;
/**
 * Open the per-record fingerprint cursor for the `budgets` stream.
 *
 * Unlike the per-budget streams, `/budgets` is a single full-collection
 * fetch keyed by budget id, so there is one cursor for the whole stream
 * rather than one per budget. The prior fingerprints live alongside the
 * existing `fetched_at` marker under `state.budgets.fingerprints`; the
 * cursor's tolerant decoder ignores `fetched_at` and any legacy shape.
 *
 * `BUDGET_FINGERPRINT_EXCLUDE` drops the two calendar/clock fields so an
 * unchanged budget no-ops across runs (see the constant's doc comment).
 */
export declare function openBudgetCursor(state: Record<string, unknown>): FingerprintCursor;
export declare function accountRecord(a: YnabAccount, budgetId: string): RecordData;
export declare function accountStatsRecord(a: YnabAccount, budgetId: string, observedOn: string): RecordData;
export declare function payeeLocationRecord(loc: YnabPayeeLocation, budgetId: string): RecordData;
export declare function monthCategoryRecord(c: YnabCategory, month: string, budgetId: string): RecordData;
type EmitFn = CollectContext["emit"];
type TrackedEmitRecord = (stream: string, data: RecordData) => Promise<void>;
interface CoverageFact {
    considered: number;
    covered: number;
    enumeratedFresh: boolean;
}
type ProgressFn = (message: string, extra?: {
    count?: number;
    cursor_present?: boolean;
    item_count?: number;
    offset_ordinal?: number;
    phase?: string;
    rate_limit_pressure?: number;
    stream?: string;
    total?: number;
    total_seen?: number;
}) => Promise<void>;
export interface BudgetCtx {
    budgetId: string;
    budgetOrdinal?: number;
    emit: EmitFn;
    newState: Record<string, unknown>;
    progress: ProgressFn;
    request: YnabRequest;
    requested: Map<string, {
        time_range?: TimeRange;
    }>;
    state: Record<string, unknown>;
    token: string;
    trackAndEmit: TrackedEmitRecord;
}
/**
 * Per-budget fingerprint cursor for the `accounts` entity stream. After the
 * balance fields move to `account_stats`, the entity record carries only
 * identity and settings fields, so a full fingerprint (no exclusions) is
 * correct: the record re-emits only when one of those fields actually changes.
 *
 * State shape: `state.accounts[budgetId].fingerprints`, opened per budget so a
 * multi-budget owner cannot cross-contaminate fingerprint maps. The per-budget
 * entry also carries the existing `server_knowledge` cursor; this wrapper reads
 * only the `fingerprints` field.
 */
export declare function openAccountCursor(state: Record<string, unknown>, budgetId: string): FingerprintCursor;
/**
 * One budget's contribution to the whole-stream self-coverage proof for
 * `accounts` and/or `account_stats` (both fetched from the same
 * `/budgets/{id}/accounts` call).
 *
 * Unlike `categories`/`payees`/`transactions`/`months`, `collectAccounts`
 * never passes a `server_knowledge` cursor — it always walks the full
 * account list, same as `payee_locations`/`scheduled_transactions` (and
 * matching `collectTransactions`'s own unconditional `/accounts` refetch for
 * its type map). `/accounts` returns no separate total-boundary count
 * alongside a delta payload, so a `knowledge`-scoped call could never measure
 * `considered` at all — only a full walk can. This costs nothing extra:
 * `/accounts` is one request per budget either way (see
 * `collectScheduledTransactions`'s "One request per budget" comment for the
 * same reasoning applied to that endpoint), so always requesting the full
 * list keeps `accounts`/`account_stats` provable on every run, not just a
 * connection's first ever run.
 *
 * `accountsCovered`/`accountStatsCovered` follow the `budgets`/usaa/
 * `scheduled_transactions` precedent: emitted-and-valid plus
 * suppressed-because-unchanged, tallied at the per-record loop from
 * `validateRecord` (the same shape-check the runtime's real emitRecord
 * applies) — never aliased to the emitted count, so a steady-state
 * (all-suppressed) run still reads `covered === considered`, while a row
 * this run attempted and the runtime silently SKIPped for a bad shape is
 * never claimed as covered. A suppressed-unchanged row is counted without
 * re-validating: its fingerprint can only exist because an earlier run's
 * identical content already passed the real emitRecord shape-check.
 *
 * `undefined` on `accountsCovered`/`accountStatsCovered` means that stream
 * was not requested this run — the aggregate must not fabricate a zero for
 * an unrequested stream.
 */
export interface AccountsBudgetFact {
    accountStatsCovered?: number;
    accountsCovered?: number;
    budgetId: string;
    considered: number;
}
/**
 * Aggregate per-budget `AccountsBudgetFact`s into the whole-stream
 * self-coverage proof for `accounts` and, separately, `account_stats`. Every
 * fact already reflects a full-boundary walk (see `AccountsBudgetFact` doc
 * comment — `collectAccounts` never sends a delta cursor), so no freshness
 * gate is needed; this mirrors `aggregatePayeeLocationsCoverage`. Returns
 * `null` for a stream that had no facts (wasn't requested by any budget, or
 * zero budgets ran).
 */
export declare function aggregateAccountsCoverage(facts: readonly AccountsBudgetFact[]): {
    accountStats: {
        considered: number;
        covered: number;
    } | null;
    accounts: {
        considered: number;
        covered: number;
    } | null;
};
export declare function collectCategoriesAndGroups(ctx: BudgetCtx): Promise<{
    categoryGroups: CoverageFact;
    categories: CoverageFact;
}>;
/**
 * Open a per-record fingerprint cursor for one budget's payee_locations.
 *
 * YNAB exposes `server_knowledge` deltas on payees/transactions/etc., but
 * NOT on `/payee_locations` — the full collection re-returns every run.
 * Without a connector-side gate, every run appends a new version per
 * location (77 keys × 270 versions in the live churn report). The cursor
 * fingerprints the full emitted record; nothing is excluded — lat/long
 * are user-provided in the YNAB UI and never re-geocoded silently, so
 * they are valid change signals, and YNAB does not stamp a run-clock
 * field into the payload.
 *
 * State shape: `state.payee_locations[budgetId].fingerprints` — opened
 * per budget so a multi-budget owner cannot cross-contaminate fingerprint
 * maps.
 */
export declare function openPayeeLocationCursor(state: Record<string, unknown>, budgetId: string): FingerprintCursor;
/**
 * One budget's contribution to the whole-stream `payee_locations`
 * self-coverage proof. Unlike `accounts`/`scheduled_transactions`,
 * `/payee_locations` carries no `server_knowledge` delta — it is a true
 * full-collection endpoint on every call — so no freshness gating is needed;
 * every call measures the full boundary.
 *
 * `covered` is emitted-and-valid plus suppressed-because-unchanged, tallied
 * at the per-record loop via `validateRecord` (mirroring
 * `scheduled_transactions`) — never aliased to the emitted count, so a
 * steady-state run still reads `covered === considered`, while a
 * newly-attempted row the runtime silently SKIPs for a bad shape is never
 * claimed as covered.
 */
export interface PayeeLocationsBudgetFact {
    budgetId: string;
    considered: number;
    covered: number;
}
/**
 * Aggregate per-budget `PayeeLocationsBudgetFact`s into the whole-stream
 * `payee_locations` self-coverage proof. No freshness gate is needed (see
 * `PayeeLocationsBudgetFact` doc comment); every budget that ran contributes
 * a measured boundary.
 */
export declare function aggregatePayeeLocationsCoverage(facts: readonly PayeeLocationsBudgetFact[]): {
    considered: number;
    covered: number;
} | null;
/**
 * One budget's contribution to the `scheduled_transactions` whole-stream
 * coverage proof. A delta response can prove nonzero coverage, but an empty
 * delta response is reconciled with one uncursored walk before it can prove a
 * source boundary.
 */
export interface ScheduledTransactionsBudgetFact {
    budgetId: string;
    /** Rows this call's response held — the enumerated boundary size. */
    considered: number;
    /**
     * Rows this run objectively accounted for (validated + emitted) — NEVER
     * aliased to `considered`. A row present in the response is "considered"
     * but not automatically "covered": `validateRecord` (the same shape-check
     * the runtime's emitRecord applies) can reject a malformed row, in which
     * case it never emits and must not be claimed as covered — else the proof
     * would overclaim coverage of a row that was in fact dropped.
     */
    covered: number;
    enumeratedFresh: boolean;
}
export declare function collectScheduledTransactions(ctx: BudgetCtx): Promise<ScheduledTransactionsBudgetFact>;
/**
 * Aggregate per-budget `scheduled_transactions` facts into the whole-stream
 * self-coverage proof. Nonzero delta facts remain usable, while a zero fact is
 * emitted only when every budget performed the uncursored reconciliation.
 *
 * `considered` and `covered` are summed independently, never aliased to one
 * another: a per-budget row that failed `validateRecord` raises that
 * budget's `considered` (the API said it existed) without raising `covered`
 * (it was never emitted), so a run with any rejected row honestly reads
 * `partial` rather than a false `complete`.
 */
export declare function aggregateScheduledTransactionsCoverage(facts: readonly ScheduledTransactionsBudgetFact[]): {
    considered: number;
    covered: number;
} | null;
type MonthDetailFetcher = (budgetId: string, month: string, token: string, request: YnabRequest) => Promise<YnabMonth>;
export declare function collectMonthCategories(ctx: BudgetCtx, monthList: YnabMonth[], monthCategoriesStream: {
    time_range?: TimeRange;
}, fetchMonth?: MonthDetailFetcher, enumeratedFresh?: boolean, fullScanForDetails?: boolean): Promise<CoverageFact>;
/** Inputs for the `budgets` full-sync stream, extracted from `collect()` so the
 *  considered/covered declaration is unit-testable without the live API. */
export interface BudgetsStreamDeps {
    budgets: readonly YnabBudget[];
    emit: CollectContext["emit"];
    newState: Record<string, unknown>;
    state: Record<string, unknown>;
    trackAndEmit: TrackedEmitRecord;
}
/**
 * Emit the `budgets` entity stream. `/budgets` is a full-collection endpoint
 * with no `server_knowledge` delta, so the run re-enumerates the whole budget
 * inventory every time and gates each row through a per-record fingerprint
 * (excluding the two calendar/clock fields, see `BUDGET_FINGERPRINT_EXCLUDE`) so
 * an unchanged budget is not re-emitted — without this gate each run appended a
 * new version per budget (~273/budget in the 2026-05-26 churn report).
 *
 * Because the run suppresses unchanged rows, on a steady-state run `collected`
 * is a churn-reduced subset (often 0), not a coverage count. The stream declares
 * `considered = budgets.length` (the enumerated boundary) alongside an objective
 * `covered` count — emitted plus suppressed-because-unchanged, tallied at the
 * loop site from per-record outcomes — so the Collection Report reads `complete`
 * instead of a false `partial` (define-connector-progress-evidence-contract
 * task 4.4). `covered` is counted independently from `budgets.length`: a future
 * malformed-row drop before the gate would raise `considered` without raising
 * `covered`, leaving an honest `partial`. Empty required/hydrated key sets — a
 * list stream with no detail-hydration phase, so considered-vs-covered is the
 * only coverage axis.
 */
export declare function emitBudgetsStream(deps: BudgetsStreamDeps): Promise<void>;
/**
 * The production `collect()` callback `runConnector` invokes. Extracted to a
 * named export so integration tests can drive the exact same top-level
 * orchestration (budgets fetch → per-budget loop → whole-stream coverage
 * aggregation) that a real run executes, rather than re-implementing a
 * parallel path that could silently diverge from production.
 *
 * `request` is the sole seam for a deterministic test double: it defaults to
 * the real governed `ynab()` (pacing + retry via the module-level
 * `httpGovernor`), and every downstream fetch — including the ones inside
 * `collectForBudget`/`fetchMonthDetail` — flows through this single injected
 * function via `BudgetCtx.request`. A test override never touches the
 * governor or `fetch`, so a fixture-driven run incurs none of
 * `ynabPacingProfile()`'s real per-request pacing floor. This is a plain
 * function-injection seam — no test-only env flag, no mutable global, no
 * parallel orchestration.
 */
export declare function ynabCollect({ state, requested, credentials, emit, emitRecord: runtimeEmitRecord, progress, }: CollectContext, request?: YnabRequest): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map