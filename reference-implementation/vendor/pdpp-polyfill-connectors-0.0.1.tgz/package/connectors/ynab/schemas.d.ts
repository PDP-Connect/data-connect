/**
 * Zod schemas for YNAB stream records. Used for shape-check-before-emit
 * per docs/reference/connector-authoring-guide.md §3: records that don't match the
 * schema become SKIP_RESULT events instead of RECORD events.
 *
 * YNAB uses milliunits for amounts (1000 = 1 currency unit). All amounts
 * are integers with no magnitude constraints; debits are negative.
 */
import { z } from "zod";
export declare const budgetsSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    last_modified_on: z.ZodNullable<z.ZodString>;
    first_month: z.ZodNullable<z.ZodString>;
    last_month: z.ZodNullable<z.ZodString>;
    currency_iso_code: z.ZodNullable<z.ZodString>;
    currency_symbol: z.ZodNullable<z.ZodString>;
    currency_symbol_first: z.ZodNullable<z.ZodBoolean>;
    currency_decimal_digits: z.ZodNullable<z.ZodNumber>;
    currency_decimal_separator: z.ZodNullable<z.ZodString>;
    currency_group_separator: z.ZodNullable<z.ZodString>;
    date_format_string: z.ZodNullable<z.ZodString>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const accountsSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    name: z.ZodString;
    type: z.ZodString;
    on_budget: z.ZodBoolean;
    closed: z.ZodBoolean;
    transfer_payee_id: z.ZodNullable<z.ZodString>;
    direct_import_linked: z.ZodNullable<z.ZodBoolean>;
    direct_import_in_error: z.ZodNullable<z.ZodBoolean>;
    last_reconciled_at: z.ZodNullable<z.ZodString>;
    note: z.ZodNullable<z.ZodString>;
    debt_interest_rates: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    debt_minimum_payments: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    debt_escrow_amounts: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const accountStatsSchema: z.ZodObject<{
    id: z.ZodString;
    account_id: z.ZodString;
    budget_id: z.ZodString;
    observed_on: z.ZodString;
    balance: z.ZodNumber;
    cleared_balance: z.ZodNumber;
    uncleared_balance: z.ZodNumber;
}, z.core.$strip>;
export declare const categoryGroupsSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    name: z.ZodString;
    hidden: z.ZodBoolean;
    note: z.ZodNullable<z.ZodString>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const categoriesSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    category_group_id: z.ZodString;
    category_group_name: z.ZodNullable<z.ZodString>;
    name: z.ZodString;
    hidden: z.ZodBoolean;
    budgeted: z.ZodNumber;
    activity: z.ZodNumber;
    balance: z.ZodNumber;
    note: z.ZodNullable<z.ZodString>;
    goal_type: z.ZodNullable<z.ZodString>;
    goal_needs_whole_amount: z.ZodNullable<z.ZodBoolean>;
    goal_day: z.ZodNullable<z.ZodNumber>;
    goal_cadence: z.ZodNullable<z.ZodNumber>;
    goal_cadence_frequency: z.ZodNullable<z.ZodNumber>;
    goal_creation_month: z.ZodNullable<z.ZodString>;
    goal_target: z.ZodNullable<z.ZodNumber>;
    goal_target_date: z.ZodNullable<z.ZodString>;
    goal_percentage_complete: z.ZodNullable<z.ZodNumber>;
    goal_months_to_budget: z.ZodNullable<z.ZodNumber>;
    goal_under_funded: z.ZodNullable<z.ZodNumber>;
    goal_overall_funded: z.ZodNullable<z.ZodNumber>;
    goal_overall_left: z.ZodNullable<z.ZodNumber>;
    goal_snoozed_at: z.ZodNullable<z.ZodString>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const payeesSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    name: z.ZodString;
    transfer_account_id: z.ZodNullable<z.ZodString>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const payeeLocationsSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    payee_id: z.ZodString;
    latitude: z.ZodString;
    longitude: z.ZodString;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const transactionsSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    account_id: z.ZodString;
    account_name: z.ZodNullable<z.ZodString>;
    account_type: z.ZodNullable<z.ZodString>;
    date: z.ZodString;
    amount: z.ZodNumber;
    payee_id: z.ZodNullable<z.ZodString>;
    payee_name: z.ZodNullable<z.ZodString>;
    category_id: z.ZodNullable<z.ZodString>;
    category_name: z.ZodNullable<z.ZodString>;
    memo: z.ZodNullable<z.ZodString>;
    cleared: z.ZodString;
    approved: z.ZodBoolean;
    flag_color: z.ZodNullable<z.ZodString>;
    flag_name: z.ZodNullable<z.ZodString>;
    transfer_account_id: z.ZodNullable<z.ZodString>;
    transfer_transaction_id: z.ZodNullable<z.ZodString>;
    matched_transaction_id: z.ZodNullable<z.ZodString>;
    import_id: z.ZodNullable<z.ZodString>;
    import_payee_name: z.ZodNullable<z.ZodString>;
    import_payee_name_original: z.ZodNullable<z.ZodString>;
    debt_transaction_type: z.ZodNullable<z.ZodString>;
    is_split: z.ZodBoolean;
    subtransactions: z.ZodArray<z.ZodUnknown>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const scheduledTransactionsSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    date_first: z.ZodString;
    date_next: z.ZodString;
    frequency: z.ZodString;
    amount: z.ZodNumber;
    account_id: z.ZodString;
    account_name: z.ZodNullable<z.ZodString>;
    payee_id: z.ZodNullable<z.ZodString>;
    payee_name: z.ZodNullable<z.ZodString>;
    category_id: z.ZodNullable<z.ZodString>;
    category_name: z.ZodNullable<z.ZodString>;
    memo: z.ZodNullable<z.ZodString>;
    transfer_account_id: z.ZodNullable<z.ZodString>;
    flag_color: z.ZodNullable<z.ZodString>;
    flag_name: z.ZodNullable<z.ZodString>;
    subtransactions: z.ZodArray<z.ZodUnknown>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const monthsSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    month: z.ZodString;
    income: z.ZodNumber;
    budgeted: z.ZodNumber;
    activity: z.ZodNumber;
    to_be_budgeted: z.ZodNumber;
    age_of_money: z.ZodNullable<z.ZodNumber>;
    note: z.ZodNullable<z.ZodString>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const monthCategoriesSchema: z.ZodObject<{
    id: z.ZodString;
    budget_id: z.ZodString;
    month: z.ZodString;
    category_id: z.ZodString;
    category_name: z.ZodString;
    category_group_id: z.ZodNullable<z.ZodString>;
    category_group_name: z.ZodNullable<z.ZodString>;
    budgeted: z.ZodNumber;
    activity: z.ZodNumber;
    balance: z.ZodNumber;
    goal_type: z.ZodNullable<z.ZodString>;
    goal_target: z.ZodNullable<z.ZodNumber>;
    goal_percentage_complete: z.ZodNullable<z.ZodNumber>;
    goal_months_to_budget: z.ZodNullable<z.ZodNumber>;
    goal_creation_month: z.ZodNullable<z.ZodString>;
    goal_under_funded: z.ZodNullable<z.ZodNumber>;
    goal_overall_funded: z.ZodNullable<z.ZodNumber>;
    goal_overall_left: z.ZodNullable<z.ZodNumber>;
    hidden: z.ZodBoolean;
    note: z.ZodNullable<z.ZodString>;
    deleted: z.ZodBoolean;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map