#!/usr/bin/env node
import { type CollectContext } from "../../src/connector-runtime.ts";
import { type GoogleAccessToken } from "../../src/google-oauth.ts";
import { type CalendarListEntry } from "./api.ts";
/** Structural shape the connector needs from a Calendar client — lets tests
 *  substitute a fake without extending the concrete `GoogleCalendarClient`. */
export interface CalendarClientLike {
    listCalendars: () => Promise<CalendarListEntry[]>;
    listEventsPage: (calendarId: string, options: {
        pageToken?: string;
        syncToken?: string;
        timeMin?: string;
    }) => Promise<import("./api.ts").EventsPage>;
}
interface CalendarCollectOptions {
    readonly clientFactory?: (accessToken: string) => CalendarClientLike;
    readonly env?: NodeJS.ProcessEnv | Record<string, string | undefined>;
    readonly getAccessToken?: () => Promise<GoogleAccessToken>;
    /** Test seam: lowers the page ceiling so truncation is reachable without
     *  standing up {@link MAX_PAGES_PER_CALENDAR} pages of fixtures. */
    readonly maxPagesPerCalendar?: number;
}
export declare function collectGoogleCalendar(ctx: CollectContext, options?: CalendarCollectOptions): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map