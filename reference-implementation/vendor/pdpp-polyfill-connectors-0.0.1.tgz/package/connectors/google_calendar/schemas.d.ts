import { z } from "zod";
export declare const calendarsSchema: z.ZodObject<{
    id: z.ZodString;
    summary: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    time_zone: z.ZodNullable<z.ZodString>;
    access_role: z.ZodNullable<z.ZodString>;
    primary: z.ZodBoolean;
    source: z.ZodLiteral<"google_calendar_api">;
}, z.core.$strip>;
export declare const eventsSchema: z.ZodObject<{
    id: z.ZodString;
    calendar_id: z.ZodString;
    summary: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    location: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodString;
    deleted: z.ZodBoolean;
    start: z.ZodNullable<z.ZodString>;
    start_date: z.ZodNullable<z.ZodString>;
    end: z.ZodNullable<z.ZodString>;
    end_date: z.ZodNullable<z.ZodString>;
    all_day: z.ZodBoolean;
    organizer_email: z.ZodNullable<z.ZodString>;
    organizer_display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    attendees: z.ZodArray<z.ZodObject<{
        email: z.ZodNullable<z.ZodString>;
        display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        organizer: z.ZodBoolean;
        optional: z.ZodBoolean;
        response_status: z.ZodNullable<z.ZodString>;
        self: z.ZodBoolean;
    }, z.core.$strip>>;
    recurrence: z.ZodNullable<z.ZodArray<z.ZodString>>;
    recurring_event_id: z.ZodNullable<z.ZodString>;
    html_link: z.ZodNullable<z.ZodString>;
    updated: z.ZodNullable<z.ZodString>;
    source: z.ZodLiteral<"google_calendar_api">;
}, z.core.$strip>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map