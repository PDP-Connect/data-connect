export type CalendarFetch = (url: string, init: RequestInit) => Promise<Response>;
export interface CalendarClientOptions {
    readonly accessToken: string;
    readonly baseUrl?: string;
    readonly fetch?: CalendarFetch;
}
export declare class CalendarApiError extends Error {
    readonly bodySnippet: string;
    readonly status: number;
    constructor(status: number, bodySnippet: string);
}
/** Thrown when Google reports the syncToken is no longer valid (HTTP 410 GONE).
 *  Per the sync guide this requires the caller to discard the token and do a
 *  full resync. */
export declare class CalendarSyncTokenExpiredError extends Error {
    constructor();
}
export interface CalendarListEntry {
    readonly accessRole: string | null;
    readonly id: string;
    readonly primary: boolean;
    readonly summary: string | null;
    readonly timeZone: string | null;
}
export interface CalendarEventAttendee {
    readonly displayName: string | null;
    readonly email: string | null;
    readonly optional: boolean;
    readonly organizer: boolean;
    readonly responseStatus: string | null;
    readonly self: boolean;
}
export interface CalendarEventDateTime {
    readonly date: string | null;
    readonly dateTime: string | null;
    readonly timeZone: string | null;
}
export interface CalendarEvent {
    readonly attendees: readonly CalendarEventAttendee[];
    readonly description: string | null;
    readonly end: CalendarEventDateTime | null;
    readonly htmlLink: string | null;
    readonly id: string;
    readonly location: string | null;
    readonly organizer: {
        email: string | null;
        displayName: string | null;
    } | null;
    readonly recurrence: readonly string[] | null;
    readonly recurringEventId: string | null;
    readonly start: CalendarEventDateTime | null;
    readonly status: string;
    readonly summary: string | null;
    readonly updated: string | null;
}
export interface EventsPage {
    readonly events: readonly CalendarEvent[];
    readonly nextPageToken: string | null;
    readonly nextSyncToken: string | null;
}
export declare class GoogleCalendarClient {
    private readonly accessToken;
    private readonly baseUrl;
    private readonly fetchImpl;
    constructor(options: CalendarClientOptions);
    /** GET /users/me/calendarList — every calendar the owner can see. Not
     *  incremental; the list is small and re-enumerated each run (the
     *  connector fingerprint-gates emit, not this client). */
    listCalendars(): Promise<CalendarListEntry[]>;
    /**
     * GET /calendars/{calendarId}/events, one page. `syncToken` requests an
     * incremental delta (deleted events surface with status: "cancelled" per
     * the sync guide); its absence requests a full listing. `pageToken`
     * continues a paginated response within either mode — Google's sync guide
     * documents that `nextSyncToken` only appears on the LAST page, so callers
     * must page fully via `pageToken` before treating a page's absent
     * `nextSyncToken` as "not done yet".
     *
     * Throws `CalendarSyncTokenExpiredError` on HTTP 410 (Gone) — the
     * documented expired/invalid-syncToken signal — so the caller can fall
     * back to a full resync.
     */
    listEventsPage(calendarId: string, options?: {
        pageToken?: string;
        syncToken?: string;
        timeMin?: string;
    }): Promise<EventsPage>;
    private request;
}
//# sourceMappingURL=api.d.ts.map