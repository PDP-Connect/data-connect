import { z } from "zod";
/**
 * orders stream (manifest required: id). One record per Whole Foods (Amazon)
 * order. `total_cents` / `item_count` are non-negative ints; `store` / `method`
 * are short labels; `order_date` is an ISO datetime.
 */
export declare const ordersSchema: z.ZodObject<{
    id: z.ZodString;
    order_date: z.ZodNullable<z.ZodString>;
    store: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    method: z.ZodNullable<z.ZodString>;
    total_cents: z.ZodNullable<z.ZodNumber>;
    item_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * order_items stream (manifest required: id, order_id, name). One record per
 * line item. `name` is the free-form product name; `quantity` is a count/weight
 * (float-capable — grocery items sell by weight); `nutrition` is the opaque
 * USDA-sourced nutrition object preserved verbatim (manifest declares
 * `object|null` with no interior contract), or null when no USDA match.
 */
export declare const orderItemsSchema: z.ZodObject<{
    id: z.ZodString;
    order_id: z.ZodString;
    name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    quantity: z.ZodNullable<z.ZodNumber>;
    unit_price_cents: z.ZodNullable<z.ZodNumber>;
    nutrition: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the streams this
 * connector declares (and will emit once extraction is wired).
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map