import { z } from "zod";
/**
 * chats stream: one record per imported .txt export.
 * Semantics: mutable_state (re-import replaces).
 */
export declare const chatsSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    participants: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    message_count: z.ZodNumber;
    first_message_date: z.ZodNullable<z.ZodString>;
    last_message_date: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * messages stream: one record per parsed message line.
 * Cursor: sent_at.
 */
export declare const messagesSchema: z.ZodObject<{
    id: z.ZodString;
    chat_id: z.ZodString;
    author: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    content: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    has_attachment: z.ZodBoolean;
    sent_at: z.ZodString;
}, z.core.$strip>;
export declare const attachmentsSchema: z.ZodObject<{
    id: z.ZodString;
    blob_ref: z.ZodNullable<z.ZodObject<{
        blob_id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        mime_type: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        sha256: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        size_bytes: z.ZodNumber;
    }, z.core.$strip>>;
    chat_id: z.ZodString;
    content_sha256: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    content_type: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    filename: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    hydration_error: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    hydration_status: z.ZodEnum<{
        deferred: "deferred";
        failed: "failed";
        hydrated: "hydrated";
    }>;
    message_id: z.ZodNullable<z.ZodString>;
    size_bytes: z.ZodNumber;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map