import { ZipPolicyViolationError } from "../../src/bounded-zip-archive.ts";
/**
 * Thrown by WhatsAppChatLineAccumulator.pushLine once the message-count
 * policy is exceeded -- a real, catchable JS exception, not a crash. Mirrors
 * WhatsAppZipPolicyRejection's role: distinguishes "this is a real (or
 * plausibly real) export that tripped a resource policy" from "this isn't a
 * recognizable export at all," so callers report it as too_large, not
 * unsupported.
 */
export declare class WhatsAppMessageLimitExceededError extends Error {
    constructor(messageCount: number, maxMessageCount: number);
}
export interface ParsedWhatsAppMessage {
    author: string;
    content: string;
    has_attachment?: boolean;
    id: string;
    sent_at: string;
}
/**
 * A media attachment's bytes are read LAZILY via `data()`, never eagerly
 * materialized into this object. A "with media" export can legitimately
 * contain many GiB of attachments; holding every attachment's inflated bytes
 * in one array simultaneously (the previous shape: `{ bytes: Buffer }`)
 * meant total attachment memory scaled with archive size even though only
 * one attachment is ever being uploaded at a time. Callers must call
 * `data()` at most once and let the bytes go out of scope (e.g. immediately
 * after handing them to the blob uploader) before moving to the next
 * attachment.
 */
export interface ParsedWhatsAppAttachment {
    data: () => Buffer;
    filename: string;
}
/**
 * Aggregate-only summary of a chat export: everything validation.ts and
 * index.ts's chat-identity resolution need to know WITHOUT holding every
 * message in memory at once. Produced by a single streaming pass
 * (scanWhatsAppChatIdentity) that maintains only bounded running state
 * (a Set of participant names, min/max timestamps, a few counters, and a
 * fixed-size reservoir sample of message fingerprints for
 * openChatIdentityCursor's overlap check) — never an array sized by
 * message count. Emitting actual message RECORDS is a SEPARATE streaming
 * pass (streamWhatsAppChatMessages) driven only after this summary's
 * chatId has been resolved through the persisted reconciliation cursor.
 */
export interface WhatsAppChatSummary {
    attachmentMessageCount: number;
    /** Provisional chatId, derived directly from identityKey with no salt —
     *  the caller (index.ts) MUST resolve this through its persisted
     *  reconciliation-alias cursor (index.ts's openChatIdentityCursor) before
     *  treating it as final and driving streamWhatsAppChatMessages with it. */
    chatId: string;
    firstSentAt: string | null;
    /** Best-effort reconciliation lookup key — see deriveChatIdentityKey. */
    identityKey: string;
    lastSentAt: string | null;
    messageCount: number;
    /** Fixed-size UNIFORM RANDOM sample of message content fingerprints
     *  (reservoir sampling, not fixed-stride) — see scanWhatsAppChatIdentity's
     *  doc comment for why stride sampling was replaced. */
    messageFingerprintSample: string[];
    participants: string[];
    title: string;
}
export declare const WHATSAPP_ATTACHMENT_RE: RegExp;
export declare const ZIP_EXT_RE: RegExp;
/**
 * Best-effort identity LOOKUP key — NOT a claimed unique id (see the
 * module-level comment above). Two distinct chats with identical
 * participant sets produce the SAME identityKey; that is expected and
 * handled by index.ts's alias-based reconciliation cursor, which uses
 * message CONTENT overlap (not this key alone) to decide whether two
 * exports sharing a key are the same chat (reuse) or genuinely distinct
 * chats (kept separate, surfaced as ambiguous) — see
 * openChatIdentityCursor's doc comment for the full design. This function
 * only guarantees the key itself is deterministic for a given participant
 * set; it makes no uniqueness claim and must not be used as if it did.
 */
export declare function deriveChatIdentityKey(participants: readonly string[]): string;
/** Mint a fresh chatId for an identity key seen for the first time. Never
 *  called directly by parseWhatsAppChatFile — see index.ts's reconciliation
 *  cursor, which looks up an existing mapping before minting a new one. */
export declare function mintChatId(identityKey: string, salt: string): string;
/**
 * Content-addressed message identity: hash of author+sent_at+content, NOT
 * array position. Index-based ids shift on any reordering or prepended
 * history in a re-export (common — WhatsApp exports aren't guaranteed
 * stable-ordered across exports), which makes the fingerprint cursor treat
 * unchanged messages as new. A duplicate consecutive message (same author,
 * same minute, same text) collides by design — see occurrenceIndex below,
 * which disambiguates true duplicates without reintroducing position-based
 * fragility for the common (non-duplicate) case.
 */
/**
 * The chat-independent content fingerprint used as BOTH the message id's
 * suffix (see deriveMessageId) AND, separately, the overlap-detection
 * signal the reconciliation-alias system (index.ts) uses to decide whether
 * two exports sharing an identityKey are the SAME chat (their message
 * fingerprints overlap) or two DISTINCT chats that merely share a
 * participant list (zero overlap). Exported so index.ts never needs to
 * recompute it or reach into message.id's string shape.
 */
export declare function messageContentFingerprint(message: Pick<ParsedWhatsAppMessage, "author" | "content" | "sent_at">, occurrenceIndex: number): string;
export declare function nowIso(): string;
export declare function parseWhatsAppDateTime(dateStr: string, timeStr: string): string | null;
/** Splits an already-in-memory chat-text string (e.g. a zip's bounded
 *  chat.txt entry, already read once) into lines for the sync scan/stream
 *  APIs below. Only ever used against text already known to be bounded
 *  (MAX_CHAT_TEXT_BYTES or smaller) -- never against a raw .txt upload,
 *  which uses the async file-streamed APIs instead. */
export declare function splitWhatsAppChatLines(content: string): string[];
export declare function whatsappChatTitleFromFilename(filename: string): string;
export declare function looksLikeWhatsAppChatExport(text: string): boolean;
export type WhatsAppChatArtifactFormat = "whatsapp_chat_export" | "whatsapp_chat_export_zip";
export interface ExtractedWhatsAppChatArtifact {
    chatFileName: string;
    format: WhatsAppChatArtifactFormat;
    mediaFileCount: number;
    mediaFiles: ParsedWhatsAppAttachment[];
    /**
     * Media entries present in the zip's central directory but withheld from
     * mediaFiles because extracting them would violate WHATSAPP_ZIP_POLICY
     * (oversized, or the shared decompression budget was exhausted). Nonzero
     * means real attachment coverage is missing from this parse — the caller
     * MUST surface this (see index.ts), not treat mediaFiles.length as the
     * true attachment count.
     */
    skippedMediaCount: number;
    text: string;
}
/**
 * Thrown instead of returning null when the zip archive itself (not a media
 * entry inside it) violates WHATSAPP_ZIP_POLICY — e.g. too many entries, or
 * the shared decompression budget is exhausted before any chat text can even
 * be located. Distinguishes "this is a real export that's too large to
 * safely process" from extractWhatsAppChatArtifact returning null, which
 * means "this isn't a recognizable WhatsApp export at all." Callers
 * (validation.ts) MUST preserve this distinction — collapsing both into
 * "unsupported" hides an actionable signal from the owner.
 */
export declare class WhatsAppZipPolicyRejection extends Error {
    readonly code: InstanceType<typeof ZipPolicyViolationError>["code"];
    constructor(cause: InstanceType<typeof ZipPolicyViolationError>);
}
/**
 * File-backed variant of {@link extractWhatsAppChatArtifact}'s zip path: the
 * archive is never buffered whole in memory. `fd` is caller-owned (this
 * function neither opens nor closes it). Use this for staged manual-upload
 * artifacts, where the archive already exists as a file on disk and there is
 * no reason to also hold it as a Buffer.
 */
export declare function extractWhatsAppChatArtifactFromFile(fd: number, fileSize: number): ExtractedWhatsAppChatArtifact | null;
export declare function extractWhatsAppChatArtifact(filename: string, input: Buffer | Uint8Array | string): ExtractedWhatsAppChatArtifact | null;
/**
 * One-shot uniform-random sample of an already-in-memory (small) array down
 * to `capacity` items, via the same reservoir-sampling algorithm as the
 * streaming scanner above. Exported for index.ts's chat-identity
 * reconciliation cursor, which needs to re-sample a GROWN fingerprint set
 * (this run's sample plus a previously-persisted alias's sample, both
 * already <= MESSAGE_FINGERPRINT_SAMPLE_SIZE) back down to the cap -- using
 * the same unbiased algorithm here, not a fixed-stride shortcut, avoids
 * reintroducing the exact narrow-overlap-window blind spot the streaming
 * scanner's reservoir sampling was built to close.
 */
export declare function sampleUniform<T>(items: readonly T[], capacity: number): T[];
/**
 * Pass 1 of 2: a single streaming read that determines chat identity and
 * summary aggregates WITHOUT holding every message in memory. Bounded
 * state only (see ChatIdentityAccumulator): a Set of participant names
 * (realistically a few hundred entries at most, even for a large group), a
 * running min/max timestamp, a few counters, and a fixed-size reservoir
 * sample of message fingerprints. The message-count policy cap
 * (WhatsAppMessageLimitExceededError) is enforced here too, since this
 * pass already visits every message.
 *
 * Message ids assigned during this pass use the PROVISIONAL chatId (see
 * WhatsAppChatSummary.chatId) -- fine for fingerprinting (the fingerprint
 * itself does not depend on chatId), but the real per-message ids used for
 * actual record emission are assigned fresh in pass 2
 * (streamWhatsAppChatMessages), which is only ever driven with the FINAL,
 * reconciled chatId.
 */
export declare function scanWhatsAppChatIdentity(filename: string, lines: Iterable<string>): WhatsAppChatSummary;
/**
 * Async-iterable variant of scanWhatsAppChatIdentity, for a file-backed
 * line source (e.g. node:readline over fs.createReadStream) instead of a
 * pre-materialized string's lines. Shares ChatIdentityAccumulator with the
 * sync variant above -- only the loop's iteration protocol differs.
 */
export declare function scanWhatsAppChatIdentityStream(filename: string, lines: AsyncIterable<string>): Promise<WhatsAppChatSummary>;
/**
 * Pass 2 of 2: re-streams the SAME chat text, now with the FINAL, already-
 * reconciled chatId (see WhatsAppChatSummary.chatId's doc comment), and
 * calls `onMessage` once per message with its real content-addressed id
 * assigned -- never materializing a message array. `onMessage` is called
 * synchronously in file order; a caller needing async work per message
 * (e.g. emitRecord) should await inside its own loop after collecting
 * each callback's message via a one-slot handoff, or use
 * streamWhatsAppChatMessagesAsync below.
 *
 * Re-enforces WHATSAPP_MAX_MESSAGE_COUNT independently of pass 1, mirroring
 * streamWhatsAppChatMessagesAsync's identical guard (see that function's
 * doc comment for why). Not on any production call path today (index.ts
 * only drives the async variant below) but kept in lockstep so a future
 * caller of this sync variant does not silently inherit an unbounded pass.
 */
export declare function streamWhatsAppChatMessages(lines: Iterable<string>, chatId: string, onMessage: (message: ParsedWhatsAppMessage) => void): void;
/**
 * Async variant of streamWhatsAppChatMessages: `onMessage` may return a
 * Promise (e.g. to await emitRecord before the next message is parsed),
 * and is awaited in strict file order -- at most one message's emission is
 * ever in flight, which is what keeps this bounded rather than racing
 * ahead and buffering results.
 *
 * Re-enforces WHATSAPP_MAX_MESSAGE_COUNT independently of pass 1
 * (ChatIdentityAccumulator.onMessage). Pass 1 and pass 2 read the file
 * separately; normally that's harmless because pass 2 re-reads the exact
 * same already-validated bytes pass 1 scanned, but a caller whose two
 * passes are NOT provably reading the same content (e.g. a source that
 * changed between passes) would otherwise let pass 2's message count grow
 * unbounded with no policy backstop of its own -- a silent bypass of a cap
 * that is supposed to be memory-bounding, not merely a pass-1 formality.
 */
export declare function streamWhatsAppChatMessagesAsync(lines: AsyncIterable<string> | Iterable<string>, chatId: string, onMessage: (message: ParsedWhatsAppMessage) => Promise<void> | void): Promise<void>;
//# sourceMappingURL=parsers.d.ts.map