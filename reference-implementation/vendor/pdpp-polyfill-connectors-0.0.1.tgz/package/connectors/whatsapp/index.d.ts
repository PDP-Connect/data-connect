#!/usr/bin/env node
export interface ChatIdentityResolution {
    readonly ambiguous: boolean;
    readonly chatId: string;
}
export interface ChatIdentityCursor {
    resolve: (identityKey: string, provisionalChatId: string, messageFingerprints: readonly string[]) => ChatIdentityResolution;
    toState: () => {
        aliases: Record<string, unknown>;
        synced_at: string;
    };
}
export declare function openChatIdentityCursor(state: Record<string, unknown>): ChatIdentityCursor;
//# sourceMappingURL=index.d.ts.map