// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { createServer, type IncomingMessage } from "node:http";
import type { AddressInfo } from "node:net";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";
import type { EmittedMessage } from "../../src/connector-runtime.ts";
import { runConnectorProtocolSubprocess } from "../../src/test-harness.ts";

const __dirname = dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = resolve(__dirname, "../..");
const WHATSAPP_ENTRYPOINT = join(
	PACKAGE_ROOT,
	"connectors",
	"whatsapp",
	"index.ts",
);

const VALID_EXPORT = `[6/5/24, 9:15:22 AM] Alice: Hello
[6/5/24, 9:16:00 AM] Bob: <attached: IMG-20240605-WA0001.jpg>`;

function zipHeader(signature: number, size: number): Buffer {
	const header = Buffer.alloc(size);
	header.writeUInt32LE(signature, 0);
	return header;
}

function makeStoredZip(
	entries: readonly { name: string; data: string | Buffer }[],
): Buffer {
	const chunks: Buffer[] = [];
	const central: Buffer[] = [];
	let offset = 0;
	for (const entry of entries) {
		const name = Buffer.from(entry.name, "utf8");
		const data = Buffer.isBuffer(entry.data)
			? entry.data
			: Buffer.from(entry.data, "utf8");
		const local = zipHeader(0x04_03_4b_50, 30);
		local.writeUInt16LE(0x08_00, 6);
		local.writeUInt16LE(0, 8);
		local.writeUInt32LE(0, 14);
		local.writeUInt32LE(data.length, 18);
		local.writeUInt32LE(data.length, 22);
		local.writeUInt16LE(name.length, 26);
		chunks.push(local, name, data);

		const directory = zipHeader(0x02_01_4b_50, 46);
		directory.writeUInt16LE(20, 4);
		directory.writeUInt16LE(20, 6);
		directory.writeUInt16LE(0x08_00, 8);
		directory.writeUInt16LE(0, 10);
		directory.writeUInt32LE(0, 16);
		directory.writeUInt32LE(data.length, 20);
		directory.writeUInt32LE(data.length, 24);
		directory.writeUInt16LE(name.length, 28);
		directory.writeUInt32LE(offset, 42);
		central.push(directory, name);
		offset += local.length + name.length + data.length;
	}
	const centralStart = offset;
	const centralBytes = Buffer.concat(central);
	const end = zipHeader(0x06_05_4b_50, 22);
	end.writeUInt16LE(entries.length, 8);
	end.writeUInt16LE(entries.length, 10);
	end.writeUInt32LE(centralBytes.length, 12);
	end.writeUInt32LE(centralStart, 16);
	return Buffer.concat([...chunks, centralBytes, end]);
}

function records(
	messages: readonly EmittedMessage[],
	stream: string,
): Record<string, unknown>[] {
	return messages
		.filter(
			(message): message is Extract<EmittedMessage, { type: "RECORD" }> =>
				message.type === "RECORD",
		)
		.filter((message) => message.stream === stream)
		.map((message) => message.data);
}

function progressMessages(
	messages: readonly EmittedMessage[],
): Extract<EmittedMessage, { type: "PROGRESS" }>[] {
	return messages.filter(
		(message): message is Extract<EmittedMessage, { type: "PROGRESS" }> =>
			message.type === "PROGRESS",
	);
}

function detailCoverage(
	messages: readonly EmittedMessage[],
): Extract<EmittedMessage, { type: "DETAIL_COVERAGE" }>[] {
	return messages.filter(
		(
			message,
		): message is Extract<EmittedMessage, { type: "DETAIL_COVERAGE" }> =>
			message.type === "DETAIL_COVERAGE",
	);
}

async function writeMediaZip(importRoot: string): Promise<void> {
	const stagedDir = join(importRoot, "artifact_123");
	await mkdir(stagedDir, { recursive: true });
	const zip = makeStoredZip([
		{ name: "WhatsApp Chat - Alice.txt", data: VALID_EXPORT },
		{ name: "IMG-20240605-WA0001.jpg", data: Buffer.from([1, 2, 3, 4]) },
	]);
	await writeFile(join(stagedDir, "Alice export.zip"), zip);
}

async function runWhatsAppImport(
	importRoot: string,
	env: Record<string, string> = {},
): Promise<{
	attachment: Record<string, unknown>;
	messages: EmittedMessage[];
}> {
	const result = await runConnectorProtocolSubprocess({
		cwd: PACKAGE_ROOT,
		entrypoint: WHATSAPP_ENTRYPOINT,
		env: {
			PDPP_OWNER_TOKEN: "",
			PDPP_RS_URL: "",
			RS_URL: "",
			TZ: "America/Chicago",
			WHATSAPP_EXPORT_DIR: importRoot,
			...env,
		},
		start: {
			scope: {
				streams: [
					{ name: "chats" },
					{ name: "messages" },
					{ name: "attachments" },
				],
			},
			type: "START",
		},
	});
	const attachmentRecords = records(result.messages, "attachments");
	assert.equal(attachmentRecords.length, 1);
	return { attachment: attachmentRecords[0] ?? {}, messages: result.messages };
}

function readRequestBody(req: IncomingMessage): Promise<Buffer> {
	const chunks: Buffer[] = [];
	return new Promise((done, reject) => {
		req.on("data", (chunk: Buffer) => chunks.push(chunk));
		req.on("end", () => done(Buffer.concat(chunks)));
		req.on("error", reject);
	});
}

async function withBlobServer<T>(
	handler: (req: IncomingMessage) => Promise<{ body: unknown; status: number }>,
	fn: (baseUrl: string) => Promise<T>,
): Promise<T> {
	const server = createServer((req, res) => {
		handler(req)
			.then(({ body, status }) => {
				res.writeHead(status, { "Content-Type": "application/json" });
				res.end(JSON.stringify(body));
			})
			.catch((err: unknown) => {
				res.writeHead(500, { "Content-Type": "application/json" });
				res.end(
					JSON.stringify({
						error: err instanceof Error ? err.message : "test server error",
					}),
				);
			});
	});
	try {
		await new Promise<void>((done, reject) => {
			server.once("error", reject);
			server.listen(0, "127.0.0.1", () => done());
		});
		const address = server.address() as AddressInfo;
		return await fn(`http://127.0.0.1:${address.port}`);
	} finally {
		await new Promise<void>((done, reject) => {
			server.close((err) => (err ? reject(err) : done()));
		});
	}
}

test("WhatsApp connector imports zip media as deferred attachment records when blob upload is unavailable", async () => {
	const importRoot = await mkdtemp(join(tmpdir(), "pdpp-whatsapp-media-"));
	try {
		await writeMediaZip(importRoot);
		const { attachment, messages } = await runWhatsAppImport(importRoot);

		assert.deepEqual(attachment.blob_ref, null);
		assert.equal(attachment.filename, "IMG-20240605-WA0001.jpg");
		assert.equal(attachment.content_type, "image/jpeg");
		assert.equal(attachment.size_bytes, 4);
		assert.equal(attachment.hydration_status, "deferred");
		assert.match(String(attachment.content_sha256), /^[0-9a-f]{64}$/);
		assert.match(String(attachment.message_id), /^[0-9a-f]{16}:[0-9a-f]{16}$/);

		assert.equal(records(messages, "chats").length, 1);
		assert.equal(records(messages, "messages").length, 2);
		const done = messages.at(-1);
		assert.equal(done?.type, "DONE");
		if (done?.type === "DONE") {
			assert.equal(done.status, "succeeded");
			assert.equal(done.records_emitted, 4);
		}
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});

test("WhatsApp connector emits privacy-safe structured progress for manual imports", async () => {
	const importRoot = await mkdtemp(join(tmpdir(), "pdpp-whatsapp-progress-"));
	try {
		await writeMediaZip(importRoot);
		const { messages } = await runWhatsAppImport(importRoot);
		const progress = progressMessages(messages);

		assert.ok(progress.length >= 5);
		assert.ok(
			progress.some(
				(message) =>
					message.message === "Found 1 WhatsApp export file(s) to inspect.",
			),
		);
		assert.ok(
			progress.some(
				(message) =>
					message.stream === "messages" &&
					message.count === 2 &&
					message.total === 2 &&
					message.message.includes("Processed 2 of 2 WhatsApp messages"),
			),
		);
		assert.ok(
			progress.some(
				(message) =>
					message.stream === "attachments" &&
					message.count === 1 &&
					message.total === 1 &&
					message.message.includes("Processed 1 of 1 WhatsApp media file"),
			),
		);

		const progressText = progress.map((message) => message.message).join("\n");
		assert.doesNotMatch(
			progressText,
			/Alice export|WhatsApp Chat - Alice|IMG-20240605-WA0001\.jpg/,
		);
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});

test("WhatsApp connector declares chat and message coverage from the parsed export inventory", async () => {
	const importRoot = await mkdtemp(
		join(tmpdir(), "pdpp-whatsapp-chat-coverage-"),
	);
	try {
		await writeMediaZip(importRoot);
		const { messages } = await runWhatsAppImport(importRoot);
		const coverage = detailCoverage(messages);

		// One export file parsed into one chat, so the discovery walk considered
		// one chat and accounted for it.
		const chats = coverage.find((message) => message.stream === "chats");
		assert.ok(chats, "expected chats DETAIL_COVERAGE");
		assert.equal(chats.state_stream, "chats");
		assert.equal(chats.considered, 1);
		assert.equal(chats.covered, 1);
		assert.deepEqual(chats.required_keys, []);
		assert.deepEqual(chats.hydrated_keys, []);

		// VALID_EXPORT carries two parsed lines; the denominator is the parsed
		// count, not the emitted count.
		const parsed = coverage.find((message) => message.stream === "messages");
		assert.ok(parsed, "expected messages DETAIL_COVERAGE");
		assert.equal(parsed.state_stream, "messages");
		assert.equal(parsed.considered, 2);
		assert.equal(parsed.covered, 2);
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});

test("WhatsApp rejected exports stay in the chat denominator but out of coverage", async () => {
	const importRoot = await mkdtemp(
		join(tmpdir(), "pdpp-whatsapp-rejected-chat-coverage-"),
	);
	try {
		await writeFile(join(importRoot, "a-valid.txt"), VALID_EXPORT);
		await writeFile(
			join(importRoot, "b-rejected.txt"),
			"not a WhatsApp export",
		);
		const result = await runConnectorProtocolSubprocess({
			cwd: PACKAGE_ROOT,
			entrypoint: WHATSAPP_ENTRYPOINT,
			env: {
				PDPP_OWNER_TOKEN: "",
				PDPP_RS_URL: "",
				RS_URL: "",
				TZ: "America/Chicago",
				WHATSAPP_EXPORT_DIR: importRoot,
			},
			start: {
				scope: { streams: [{ name: "chats" }] },
				type: "START",
			},
		});

		const coverage = detailCoverage(result.messages).find(
			(message) => message.stream === "chats",
		);
		assert.ok(coverage, "expected chats DETAIL_COVERAGE");
		assert.equal(
			coverage.considered,
			2,
			"both enumerated exports belong in the denominator",
		);
		assert.equal(
			coverage.covered,
			1,
			"the rejected export must not count as covered",
		);
		assert.ok(
			result.messages.some((message) => message.type === "SKIP_RESULT"),
			"the rejected export must remain visible as a gap",
		);
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});

test("WhatsApp connector declares attachment coverage from parsed media inventory", async () => {
	const importRoot = await mkdtemp(join(tmpdir(), "pdpp-whatsapp-coverage-"));
	try {
		await writeMediaZip(importRoot);
		const { messages } = await runWhatsAppImport(importRoot);
		const coverage = detailCoverage(messages).find(
			(message) => message.stream === "attachments",
		);

		assert.ok(coverage, "expected attachments DETAIL_COVERAGE");
		assert.equal(coverage.state_stream, "attachments");
		assert.equal(coverage.considered, 1);
		assert.equal(coverage.covered, 1);
		assert.deepEqual(coverage.required_keys, []);
		assert.deepEqual(coverage.hydrated_keys, []);

		const coverageIdx = messages.findIndex(
			(message) =>
				message.type === "DETAIL_COVERAGE" && message.stream === "attachments",
		);
		const firstStateIdx = messages.findIndex(
			(message) => message.type === "STATE",
		);
		assert.ok(
			firstStateIdx > coverageIdx,
			"DETAIL_COVERAGE must emit before attachment STATE",
		);
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});

test("WhatsApp connector reports unsupported scoped imports on a declared stream", async () => {
	const importRoot = await mkdtemp(join(tmpdir(), "pdpp-whatsapp-skip-"));
	try {
		await writeFile(
			join(importRoot, "not-a-chat.txt"),
			"not a WhatsApp export",
		);
		const result = await runConnectorProtocolSubprocess({
			cwd: PACKAGE_ROOT,
			entrypoint: WHATSAPP_ENTRYPOINT,
			env: {
				PDPP_OWNER_TOKEN: "",
				PDPP_RS_URL: "",
				RS_URL: "",
				WHATSAPP_EXPORT_DIR: importRoot,
			},
			start: {
				scope: { streams: [{ name: "messages" }] },
				type: "START",
			},
		});
		const skips = result.messages.filter(
			(message): message is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
				message.type === "SKIP_RESULT",
		);
		assert.equal(skips.length, 1);
		assert.equal(skips[0]?.stream, "messages");
		assert.equal(skips[0]?.reason, "unsupported_export");
		assert.doesNotMatch(skips[0]?.message ?? "", /not-a-chat/);
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});

test("WhatsApp connector's collect() rejects an export past the message-count cap as a SKIP_RESULT, not a crash (H1)", async () => {
	// Real subprocess run (not a direct import) proves the collection path,
	// not just validation: an export that would OOM the whole process during
	// accumulation instead produces a normal SKIP_RESULT and a succeeded DONE
	// -- the subprocess exits cleanly, it never aborts.
	const importRoot = await mkdtemp(join(tmpdir(), "pdpp-whatsapp-msg-cap-"));
	try {
		const lines = [
			"[6/5/24, 9:15:22 AM] Alice: one",
			"[6/5/24, 9:16:00 AM] Alice: two",
			"[6/5/24, 9:17:00 AM] Alice: three",
			"[6/5/24, 9:18:00 AM] Alice: four",
		].join("\n");
		await writeFile(join(importRoot, "WhatsApp Chat - Alice.txt"), lines);
		const result = await runConnectorProtocolSubprocess({
			cwd: PACKAGE_ROOT,
			entrypoint: WHATSAPP_ENTRYPOINT,
			env: {
				PDPP_OWNER_TOKEN: "",
				PDPP_RS_URL: "",
				RS_URL: "",
				WHATSAPP_EXPORT_DIR: importRoot,
				WHATSAPP_MAX_MESSAGE_COUNT: "3",
			},
			start: {
				scope: { streams: [{ name: "chats" }, { name: "messages" }] },
				type: "START",
			},
		});
		const skips = result.messages.filter(
			(message): message is Extract<EmittedMessage, { type: "SKIP_RESULT" }> =>
				message.type === "SKIP_RESULT",
		);
		assert.equal(skips.length, 1);
		assert.equal(skips[0]?.reason, "import_exceeds_bounded_read_policy");
		const done = result.messages.at(-1);
		assert.equal(done?.type, "DONE");
		if (done?.type === "DONE") {
			assert.equal(done.status, "succeeded");
		}
		const chatRecords = result.messages.filter(
			(message): message is Extract<EmittedMessage, { type: "RECORD" }> =>
				message.type === "RECORD" && message.stream === "chats",
		);
		assert.equal(
			chatRecords.length,
			0,
			"the over-cap export must not produce a chat record",
		);
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});

test("WhatsApp connector hydrates zip media through the reference blob endpoint", async () => {
	const importRoot = await mkdtemp(join(tmpdir(), "pdpp-whatsapp-media-"));
	try {
		await writeMediaZip(importRoot);
		await withBlobServer(
			async (req) => {
				assert.equal(req.headers.authorization, "Bearer owner-token");
				assert.equal(req.headers["content-type"], "application/octet-stream");
				assert.equal(req.url?.startsWith("/v1/blobs?"), true);
				const url = new URL(req.url ?? "", "http://127.0.0.1");
				assert.equal(
					url.searchParams.get("connector_id"),
					"https://registry.pdpp.dev/connectors/whatsapp",
				);
				assert.equal(url.searchParams.get("mime_type"), "image/jpeg");
				assert.equal(
					url.searchParams.get("connector_instance_id"),
					"cin_whatsapp_media",
				);
				assert.equal(url.searchParams.get("stream"), "attachments");
				assert.match(
					url.searchParams.get("record_key") ?? "",
					/^[0-9a-f]{16}:attachment:[0-9a-f]{16}$/,
				);
				const body = await readRequestBody(req);
				const sha256 = createHash("sha256").update(body).digest("hex");
				return {
					body: {
						blob_id: `blob_sha256_${sha256}`,
						mime_type: url.searchParams.get("mime_type"),
						object: "blob",
						sha256,
						size_bytes: body.byteLength,
					},
					status: 200,
				};
			},
			async (baseUrl) => {
				const { attachment } = await runWhatsAppImport(importRoot, {
					PDPP_CONNECTOR_INSTANCE_ID: "cin_whatsapp_media",
					PDPP_OWNER_TOKEN: "owner-token",
					PDPP_RS_URL: baseUrl,
				});
				assert.equal(attachment.hydration_status, "hydrated");
				assert.equal(attachment.hydration_error, null);
				assert.deepEqual(attachment.blob_ref, {
					blob_id: `blob_sha256_${attachment.content_sha256}`,
					mime_type: "image/jpeg",
					sha256: attachment.content_sha256,
					size_bytes: 4,
				});
			},
		);
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});

test("WhatsApp connector marks media hydration failed when blob upload fails", async () => {
	const importRoot = await mkdtemp(join(tmpdir(), "pdpp-whatsapp-media-"));
	try {
		await writeMediaZip(importRoot);
		await withBlobServer(
			async () => ({
				body: { error: "synthetic upload failure" },
				status: 500,
			}),
			async (baseUrl) => {
				const { attachment } = await runWhatsAppImport(importRoot, {
					PDPP_OWNER_TOKEN: "owner-token",
					PDPP_RS_URL: baseUrl,
				});
				assert.equal(attachment.hydration_status, "failed");
				assert.deepEqual(attachment.blob_ref, null);
				assert.match(
					String(attachment.hydration_error),
					/500.*synthetic upload failure/,
				);
			},
		);
	} finally {
		await rm(importRoot, { force: true, recursive: true });
	}
});
