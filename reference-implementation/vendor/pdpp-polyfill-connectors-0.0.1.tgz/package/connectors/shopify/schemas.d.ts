import { z } from "zod";
/**
 * orders stream (manifest required: id). One record per Shop-app order.
 * `total_cents` / `item_count` are non-negative ints; `currency` is an ISO 4217
 * code; `merchant_name` and `status` are free-form/short strings;
 * `tracking_url` is a URL; `tracking_number` is an opaque carrier string.
 */
export declare const ordersSchema: z.ZodObject<{
    id: z.ZodString;
    order_date: z.ZodNullable<z.ZodString>;
    merchant_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodNullable<z.ZodString>;
    total_cents: z.ZodNullable<z.ZodNumber>;
    currency: z.ZodNullable<z.ZodString>;
    tracking_number: z.ZodNullable<z.ZodString>;
    tracking_url: z.ZodNullable<z.ZodURL>;
    item_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the stream this
 * connector declares (and will emit once Apollo extraction is wired).
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map