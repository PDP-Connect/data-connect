import { z } from "zod";
/**
 * tweets stream: one record per authored tweet.
 * Cursor: created_at.
 */
export declare const tweetsSchema: z.ZodObject<{
    id: z.ZodNullable<z.ZodString>;
    text: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    created_at: z.ZodString;
    favorite_count: z.ZodNullable<z.ZodNumber>;
    retweet_count: z.ZodNullable<z.ZodNumber>;
    in_reply_to_status_id: z.ZodNullable<z.ZodString>;
    in_reply_to_screen_name: z.ZodNullable<z.ZodString>;
    lang: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    media_count: z.ZodNumber;
    url_count: z.ZodNumber;
}, z.core.$strip>;
/**
 * direct_messages stream: one record per DM message.
 *
 * DM ids and participant ids are a DIFFERENT id space from tweet snowflakes
 * and are NOT validated with SNOWFLAKE_ID_RE. Real Twitter archives carry
 * numeric DM/user ids, but the only fixtures available (synthetic
 * `__fixtures__/archive-samples.ts`) use short opaque ids ("m1", "111"), so
 * these stay permissive bounded strings to avoid rejecting real records we
 * cannot yet fixture-prove. Tighten to numeric once a real archive is captured.
 * Cursor: created_at.
 */
export declare const directMessagesSchema: z.ZodObject<{
    id: z.ZodNullable<z.ZodString>;
    conversation_id: z.ZodNullable<z.ZodString>;
    sender_id: z.ZodNullable<z.ZodString>;
    recipient_id: z.ZodNullable<z.ZodString>;
    created_at: z.ZodString;
    text: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map