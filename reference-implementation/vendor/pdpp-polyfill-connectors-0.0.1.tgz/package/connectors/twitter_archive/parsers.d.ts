import type { DMConversation, DMMessage, DMOut, DMShape, TweetOut, TweetShape } from "./types.ts";
export declare function toIsoOrNull(raw: string | undefined): string | null;
export declare function toIntOrNull(raw: string | number | undefined): number | null;
/**
 * Archive tweet entries come in two shapes: either `{ tweet: {...} }`
 * (the modern layout) or the flat tweet itself (older exports). Unwrap
 * to a single TweetShape so downstream code stays one-branch.
 */
export declare function unwrapTweetEntry(raw: unknown): TweetShape;
/**
 * Build a single `tweets`-stream record from an unwrapped TweetShape.
 * Returns null when created_at is missing or unparseable; index.ts treats
 * that as "skip silently" for malformed rows.
 */
export declare function buildTweetRecord(t: TweetShape): TweetOut | null;
/** Unwrap a DM conversation entry from the `{ dmConversation: {...} }` wrapper. */
export declare function unwrapDmConversation(raw: unknown): DMConversation;
/** Unwrap a single DM message from the `{ messageCreate: {...} }` wrapper. */
export declare function unwrapDmMessage(raw: DMMessage): DMShape;
/**
 * Build a single `direct_messages`-stream record. Returns null when
 * createdAt is missing or unparseable.
 */
export declare function buildDmRecord(dm: DMShape, conversationId: string | null): DMOut | null;
export declare function isBeforeCursor(createdAt: string, since: string | undefined): boolean;
export declare function advanceCursor(prev: string | undefined, next: string): string;
//# sourceMappingURL=parsers.d.ts.map