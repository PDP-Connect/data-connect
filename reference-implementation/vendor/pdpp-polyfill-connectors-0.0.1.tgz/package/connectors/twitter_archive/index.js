#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * PDPP Twitter/X Archive Connector (v0.1.0)
 *
 * Auth: none. User requests their Twitter archive at
 *   https://twitter.com/settings/download_your_data
 * extracts the .zip into TWITTER_ARCHIVE_DIR (defaults
 * ~/.pdpp/imports/twitter_archive/), and runs this connector.
 *
 * The archive contains JS files that assign to a global — we strip the
 * prefix to get JSON. Expected files:
 *   data/tweets.js  (or data/tweet.js in older archives)
 *   data/direct-messages.js
 */
import { homedir } from "node:os";
import { join } from "node:path";
import { runConnector, } from "../../src/connector-runtime.js";
import { archiveExists, streamJsArchive } from "./archive-stream.js";
import { advanceCursor, buildDmRecord, buildTweetRecord, isBeforeCursor, unwrapDmConversation, unwrapDmMessage, unwrapTweetEntry, } from "./parsers.js";
import { validateRecord } from "./schemas.js";
/**
 * Locate `tweets.js`, falling back to the older `tweet.js` filename some
 * archives use. Returns the streaming source path, or null when neither file
 * is present.
 */
function resolveTweetArchivePath(importDir) {
    const modern = join(importDir, "data", "tweets.js");
    if (archiveExists(modern)) {
        return modern;
    }
    const legacy = join(importDir, "data", "tweet.js");
    return archiveExists(legacy) ? legacy : null;
}
async function runTweetsStream(ctx) {
    const { emit, emitRecord, importDir, state } = ctx;
    const path = resolveTweetArchivePath(importDir);
    if (!path) {
        await emit({
            type: "SKIP_RESULT",
            stream: "tweets",
            reason: "archive_not_found",
            message: "Twitter archive tweets data was not found in the configured import directory",
        });
        return;
    }
    const since = state?.last_created_at;
    let latest = since;
    await emit({
        type: "PROGRESS",
        stream: "tweets",
        message: "Twitter archive phase=emit pass=emit stream=tweets streaming",
    });
    let itemOrdinal = 0;
    try {
        for await (const raw of streamJsArchive(path)) {
            itemOrdinal += 1;
            const tweet = unwrapTweetEntry(raw);
            const rec = buildTweetRecord(tweet);
            if (!rec) {
                continue;
            }
            if (isBeforeCursor(rec.created_at, since)) {
                continue;
            }
            latest = advanceCursor(latest, rec.created_at);
            await emitRecord("tweets", { ...rec });
            if (itemOrdinal % 10_000 === 0) {
                await emit({
                    type: "PROGRESS",
                    stream: "tweets",
                    message: `Twitter archive phase=emit pass=emit stream=tweets item=${itemOrdinal}`,
                });
            }
        }
    }
    catch (err) {
        // A present-but-malformed archive (not a window.YTD assignment, truncated,
        // or non-array body) is reported as a missing archive, matching the prior
        // whole-file parser that returned null for any non-array body.
        await emit({
            type: "SKIP_RESULT",
            stream: "tweets",
            reason: "archive_not_found",
            message: `Twitter archive tweets data could not be parsed: ${err.message}`,
        });
        return;
    }
    await emit({
        type: "STATE",
        stream: "tweets",
        cursor: { last_created_at: latest },
    });
}
async function emitDmConversation(rawConvo, cursor, emitRecord) {
    const conversation = unwrapDmConversation(rawConvo);
    const convId = conversation.conversationId || null;
    for (const msg of conversation.messages || []) {
        const mm = unwrapDmMessage(msg);
        const rec = buildDmRecord(mm, convId);
        if (!rec) {
            continue;
        }
        if (isBeforeCursor(rec.created_at, cursor.since)) {
            continue;
        }
        cursor.latest = advanceCursor(cursor.latest, rec.created_at);
        await emitRecord("direct_messages", { ...rec });
    }
}
async function runDirectMessagesStream(ctx) {
    const { emit, emitRecord, importDir, state } = ctx;
    const path = join(importDir, "data", "direct-messages.js");
    if (!archiveExists(path)) {
        await emit({
            type: "SKIP_RESULT",
            stream: "direct_messages",
            reason: "archive_not_found",
            message: "Twitter archive direct-message data was not found in the configured import directory",
        });
        return;
    }
    const cursor = {
        since: state?.last_created_at,
        latest: state?.last_created_at,
    };
    await emit({
        type: "PROGRESS",
        stream: "direct_messages",
        message: "Twitter archive phase=emit pass=emit stream=direct_messages streaming",
    });
    let conversationOrdinal = 0;
    try {
        for await (const rawConvo of streamJsArchive(path)) {
            conversationOrdinal += 1;
            await emitDmConversation(rawConvo, cursor, emitRecord);
            if (conversationOrdinal % 1000 === 0) {
                await emit({
                    type: "PROGRESS",
                    stream: "direct_messages",
                    message: `Twitter archive phase=emit pass=emit stream=direct_messages conversation=${conversationOrdinal}`,
                });
            }
        }
    }
    catch (err) {
        await emit({
            type: "SKIP_RESULT",
            stream: "direct_messages",
            reason: "archive_not_found",
            message: `Twitter archive direct-message data could not be parsed: ${err.message}`,
        });
        return;
    }
    await emit({
        type: "STATE",
        stream: "direct_messages",
        cursor: { last_created_at: cursor.latest },
    });
}
runConnector({
    name: "twitter_archive",
    validateRecord,
    async collect({ state, requested, emit, emitRecord }) {
        const importDir = process.env.TWITTER_ARCHIVE_DIR ||
            join(homedir(), ".pdpp/imports/twitter_archive");
        const typedState = state;
        if (requested.has("tweets")) {
            await runTweetsStream({
                importDir,
                state: typedState.tweets,
                emit,
                emitRecord,
            });
        }
        if (requested.has("direct_messages")) {
            await runDirectMessagesStream({
                importDir,
                state: typedState.direct_messages,
                emit,
                emitRecord,
            });
        }
    },
});
