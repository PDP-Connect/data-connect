/**
 * Strip the leading `window.YTD... = ` assignment prefix from a buffered head,
 * returning the text from the array opener onward, or null when no array
 * opener has been seen yet (caller should keep buffering).
 */
export declare function stripAssignmentPrefix(head: string): string | null;
/**
 * Stream the top-level array elements of a Twitter archive `.js` file without
 * materializing the whole archive. Yields each entry (still wrapped, e.g.
 * `{ tweet: {...} }`) for the caller's pure record builders to unwrap.
 *
 * Returns immediately (yielding nothing) when the file is absent — callers
 * distinguish "absent" from "present but empty" via {@link archiveExists}.
 *
 * Throws when the file is present but is not a well-formed
 * `window.YTD... = [ ... ]` archive, preserving the previous parser's
 * "malformed archive → treated as no records" behavior at the call site.
 */
export declare function streamJsArchive(path: string): AsyncGenerator<unknown>;
/** Whether the archive file exists on disk (present-but-empty vs. absent). */
export declare function archiveExists(path: string): boolean;
//# sourceMappingURL=archive-stream.d.ts.map