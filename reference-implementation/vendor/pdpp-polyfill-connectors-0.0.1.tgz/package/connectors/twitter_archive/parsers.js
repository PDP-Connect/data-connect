// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
// ─── Low-level helpers ─────────────────────────────────────────────────
//
// Archive `.js` files assign an array literal to a `window.YTD.*` global. The
// assignment prefix is stripped and the array streamed element-by-element by
// the bounded reader in archive-stream.ts; these helpers stay pure (no I/O)
// so they can be unit-tested in isolation.
export function toIsoOrNull(raw) {
    if (!raw) {
        return null;
    }
    const d = new Date(raw);
    if (Number.isNaN(d.getTime())) {
        return null;
    }
    return d.toISOString();
}
export function toIntOrNull(raw) {
    if (raw === null || raw === undefined || raw === "") {
        return null;
    }
    const n = Number.parseInt(String(raw), 10);
    return Number.isFinite(n) ? n : null;
}
// ─── Tweet unwrapping + record building ────────────────────────────────
/**
 * Archive tweet entries come in two shapes: either `{ tweet: {...} }`
 * (the modern layout) or the flat tweet itself (older exports). Unwrap
 * to a single TweetShape so downstream code stays one-branch.
 */
export function unwrapTweetEntry(raw) {
    const entry = raw;
    if (entry.tweet) {
        return entry.tweet;
    }
    return entry;
}
/**
 * Build a single `tweets`-stream record from an unwrapped TweetShape.
 * Returns null when created_at is missing or unparseable; index.ts treats
 * that as "skip silently" for malformed rows.
 */
export function buildTweetRecord(t) {
    const createdAt = toIsoOrNull(t.created_at);
    if (!createdAt) {
        return null;
    }
    return {
        id: t.id_str || t.id || null,
        text: t.full_text ?? t.text ?? null,
        created_at: createdAt,
        favorite_count: toIntOrNull(t.favorite_count),
        retweet_count: toIntOrNull(t.retweet_count),
        in_reply_to_status_id: t.in_reply_to_status_id_str ?? null,
        in_reply_to_screen_name: t.in_reply_to_screen_name ?? null,
        lang: t.lang ?? null,
        media_count: (t.entities?.media || []).length,
        url_count: (t.entities?.urls || []).length,
    };
}
// ─── DM unwrapping + record building ───────────────────────────────────
/** Unwrap a DM conversation entry from the `{ dmConversation: {...} }` wrapper. */
export function unwrapDmConversation(raw) {
    const entry = raw;
    if (entry.dmConversation) {
        return entry.dmConversation;
    }
    return entry;
}
/** Unwrap a single DM message from the `{ messageCreate: {...} }` wrapper. */
export function unwrapDmMessage(raw) {
    if (raw.messageCreate) {
        return raw.messageCreate;
    }
    return raw;
}
/**
 * Build a single `direct_messages`-stream record. Returns null when
 * createdAt is missing or unparseable.
 */
export function buildDmRecord(dm, conversationId) {
    const createdAt = toIsoOrNull(dm.createdAt);
    if (!createdAt) {
        return null;
    }
    return {
        id: dm.id ?? null,
        conversation_id: conversationId,
        sender_id: dm.senderId ?? null,
        recipient_id: dm.recipientId ?? null,
        created_at: createdAt,
        text: dm.text ?? null,
    };
}
// ─── Cursor helpers ────────────────────────────────────────────────────
export function isBeforeCursor(createdAt, since) {
    return Boolean(since && createdAt <= since);
}
export function advanceCursor(prev, next) {
    if (!prev || next > prev) {
        return next;
    }
    return prev;
}
