import { z } from "zod";
/**
 * trips stream (manifest required: id). One record per Uber trip.
 *
 * Mirrors the amazon-style dual money representation: `fare_total` is the
 * display string ("$12.34") and `fare_total_cents` is the integer amount.
 * Addresses, driver name, and vehicle description are free-form human text →
 * pdppSafeText. `status` / `product_type` / `currency` are short structural
 * strings. `receipt_url` is a URL.
 */
export declare const tripsSchema: z.ZodObject<{
    id: z.ZodString;
    status: z.ZodNullable<z.ZodString>;
    product_type: z.ZodNullable<z.ZodString>;
    requested_at: z.ZodNullable<z.ZodString>;
    started_at: z.ZodNullable<z.ZodString>;
    completed_at: z.ZodNullable<z.ZodString>;
    pickup_address: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    pickup_lat: z.ZodNullable<z.ZodNumber>;
    pickup_lng: z.ZodNullable<z.ZodNumber>;
    dropoff_address: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    dropoff_lat: z.ZodNullable<z.ZodNumber>;
    dropoff_lng: z.ZodNullable<z.ZodNumber>;
    distance_meters: z.ZodNullable<z.ZodNumber>;
    duration_seconds: z.ZodNullable<z.ZodNumber>;
    fare_total: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    fare_total_cents: z.ZodNullable<z.ZodNumber>;
    currency: z.ZodNullable<z.ZodString>;
    tip_cents: z.ZodNullable<z.ZodNumber>;
    surge_multiplier: z.ZodNullable<z.ZodNumber>;
    driver_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    vehicle_description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    receipt_url: z.ZodNullable<z.ZodURL>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the stream this
 * connector declares (and will emit once GraphQL extraction is wired).
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map