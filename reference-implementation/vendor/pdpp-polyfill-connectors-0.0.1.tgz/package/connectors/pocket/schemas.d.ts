import { z } from "zod";
/**
 * items stream: one record per saved Pocket item.
 * Cursor: last_time_updated_unix (derived from time_updated/time_added).
 * Tombstone: status === "2".
 */
export declare const itemsSchema: z.ZodObject<{
    id: z.ZodString;
    status: z.ZodOptional<z.ZodString>;
    url: z.ZodOptional<z.ZodURL>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    author: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    time_added: z.ZodNullable<z.ZodString>;
    time_updated: z.ZodNullable<z.ZodString>;
    time_read: z.ZodNullable<z.ZodString>;
    time_favorited: z.ZodNullable<z.ZodString>;
    tags: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    archived: z.ZodBoolean;
    favorite: z.ZodBoolean;
    word_count: z.ZodNullable<z.ZodNumber>;
    reading_time_minutes: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map