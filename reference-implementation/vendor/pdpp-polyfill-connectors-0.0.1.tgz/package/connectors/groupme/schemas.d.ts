import { z } from "zod";
export declare const GroupSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodNullable<z.ZodString>;
    description: z.ZodNullable<z.ZodString>;
    avatar_url: z.ZodNullable<z.ZodString>;
    created_at: z.ZodString;
    updated_at: z.ZodString;
    member_count: z.ZodNullable<z.ZodNumber>;
    messages_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const GroupMessageSchema: z.ZodObject<{
    id: z.ZodString;
    group_id: z.ZodString;
    user_id: z.ZodNullable<z.ZodString>;
    name: z.ZodNullable<z.ZodString>;
    text: z.ZodNullable<z.ZodString>;
    avatar_url: z.ZodNullable<z.ZodString>;
    created_at: z.ZodString;
    attachments: z.ZodArray<z.ZodObject<{
        type: z.ZodEnum<{
            autokicked_member: "autokicked_member";
            emoji: "emoji";
            event: "event";
            file: "file";
            image: "image";
            linked_image: "linked_image";
            location: "location";
            mentions: "mentions";
            poll: "poll";
            postprocessing: "postprocessing";
            reply: "reply";
            video: "video";
        }>;
        url: z.ZodNullable<z.ZodString>;
        blob_id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        name: z.ZodNullable<z.ZodString>;
        lat: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        lng: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>;
    like_count: z.ZodNullable<z.ZodNumber>;
    system: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
export declare const DirectChatSchema: z.ZodObject<{
    id: z.ZodString;
    other_user_id: z.ZodNullable<z.ZodString>;
    other_user_name: z.ZodNullable<z.ZodString>;
    avatar_url: z.ZodNullable<z.ZodString>;
    last_message: z.ZodNullable<z.ZodString>;
    last_message_at: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const DirectChatMessageSchema: z.ZodObject<{
    id: z.ZodString;
    chat_id: z.ZodString;
    user_id: z.ZodNullable<z.ZodString>;
    name: z.ZodNullable<z.ZodString>;
    text: z.ZodNullable<z.ZodString>;
    avatar_url: z.ZodNullable<z.ZodString>;
    created_at: z.ZodString;
    attachments: z.ZodArray<z.ZodObject<{
        type: z.ZodEnum<{
            autokicked_member: "autokicked_member";
            emoji: "emoji";
            event: "event";
            file: "file";
            image: "image";
            linked_image: "linked_image";
            location: "location";
            mentions: "mentions";
            poll: "poll";
            postprocessing: "postprocessing";
            reply: "reply";
            video: "video";
        }>;
        url: z.ZodNullable<z.ZodString>;
        blob_id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        name: z.ZodNullable<z.ZodString>;
        lat: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        lng: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const AttachmentRecordSchema: z.ZodObject<{
    id: z.ZodString;
    message_id: z.ZodString;
    message_stream: z.ZodEnum<{
        direct_chat_messages: "direct_chat_messages";
        group_messages: "group_messages";
    }>;
    type: z.ZodEnum<{
        file: "file";
        image: "image";
    }>;
    content_type: z.ZodString;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    content_sha256: z.ZodNullable<z.ZodString>;
    hydration_status: z.ZodEnum<{
        deferred: "deferred";
        failed: "failed";
        hydrated: "hydrated";
        unavailable: "unavailable";
    }>;
    hydration_error: z.ZodNullable<z.ZodString>;
    blob_ref: z.ZodNullable<z.ZodObject<{
        blob_id: z.ZodString;
        mime_type: z.ZodString;
        sha256: z.ZodString;
        size_bytes: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map