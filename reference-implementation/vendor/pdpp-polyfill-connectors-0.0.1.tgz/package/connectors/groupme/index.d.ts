#!/usr/bin/env node
import { type CollectContext, type DetailCoverageMessage, type RecordData } from "../../src/connector-runtime.ts";
import { openFingerprintCursor } from "../../src/fingerprint-cursor.ts";
import { type ReferenceBlobRef } from "../../src/reference-blob-uploader.ts";
/**
 * Test-only escape hatch: swap the module-level governor for one with pacing
 * disabled (`pacingInitialIntervalMs: 0`, zero-delay `sleep`), so unit tests
 * that exercise real multi-page/multi-group walks (the incremental-anchor
 * tests walk many pages by construction) don't pay GroupMe's production
 * pacing interval per request. Production `collect()` never calls
 * this — only test files import it. Restores the real, paced governor via
 * `resetHttpGovernorForTests()` so tests remain isolated from each other.
 */
export declare function __setZeroDelayHttpGovernorForTests(): void;
/** Restore the real, production-paced governor after a test that called
 *  `__setZeroDelayHttpGovernorForTests()`. */
export declare function __resetHttpGovernorForTests(): void;
interface GroupMeGroup {
    archived?: boolean | null;
    avatar_url?: string | null;
    created_at?: number | null;
    description?: string | null;
    id: string;
    image_url?: string | null;
    members_count?: number | null;
    /**
     * GroupMe's own documented per-group message envelope on `GET /groups`:
     * `{ count, last_message_id, last_message_created_at, preview }`.
     *
     * The connector previously read only a FLAT `messages_count`, which is
     * absent from that documented shape — and live evidence agrees: all 156
     * of this owner's groups carry `messages_count: null` across every
     * version ever collected, while the sibling `members_count` populates
     * normally. So the flat field was never the real one.
     */
    messages?: {
        count?: number | null;
    } | null;
    messages_count?: number | null;
    muted?: boolean | null;
    name?: string | null;
    office_mode?: boolean | null;
    phone_number?: string | null;
    share_url?: string | null;
    show_full_last_message?: boolean | null;
    updated_at?: number | null;
}
/**
 * The provider-reported message count for one group, read from whichever
 * shape the API actually returned: the documented nested
 * `messages.count`, or the flat `messages_count` this connector has always
 * modelled.
 *
 * Returns `null` when NEITHER is present or usable. That distinction is
 * load-bearing: `null` means "the provider did not tell us", which is
 * different from `0` ("the provider says this group is empty"). A missing
 * count must never collapse into a zero denominator — that would assert an
 * empty group that was simply never reported on.
 *
 * Rejects non-integer, negative, and non-finite values rather than
 * coercing them, so a malformed provider value degrades to "unknown"
 * instead of silently becoming a fabricated anchor.
 */
export declare function providerMessageCount(group: GroupMeGroup): number | null;
interface GroupMeAttachment {
    charmap?: [number, number][] | null;
    file_id?: string | null;
    lat?: string | null;
    lng?: string | null;
    name?: string | null;
    picture_url?: string | null;
    type: "image" | "file" | "location" | "emoji";
    url?: string | null;
}
interface GroupMeMessage {
    attachments?: GroupMeAttachment[] | null;
    avatar_url?: string | null;
    created_at: number;
    favorited_by?: string[] | null;
    id: string;
    name?: string | null;
    system?: boolean | null;
    text?: string | null;
    user_id?: string | null;
}
interface ProgressExtra {
    after_id?: string;
    before_id?: string;
    cursor_present?: boolean;
    item_count?: number;
    page?: number;
    phase?: string;
    rate_limit_pressure?: number;
    stream?: string;
    total_seen?: number;
}
/**
 * Validates attachment URL origin, protocol, port, and auth.
 * Fails closed: only https://i.groupme.com (no port, no userinfo, no redirect).
 */
export declare function validateAttachmentUrl(urlString: string): {
    valid: boolean;
    reason?: string;
};
/**
 * Normalizes a raw Content-Type response header into a safe, known MIME
 * type, or null if the header is missing/malformed/not in the allowed set.
 * Strips parameters (e.g. `; charset=utf-8`) before matching.
 */
export declare function normalizeAttachmentContentType(rawHeader: string | null | undefined): string | null;
/**
 * Fetch and validate blob attachment with streaming byte cap.
 * Returns blob buffer on success, null on any validation/network/size failure.
 * Records the failure (caller must emit record even if blob fetch fails).
 */
export declare function fetchAttachmentBlob(urlString: string, recordKey: string): Promise<{
    buffer: Buffer;
    contentType: string | null;
    size: number;
} | null>;
export type AttachmentFetchOutcome = {
    kind: "available";
    blob: {
        buffer: Buffer;
        contentType: string | null;
        size: number;
    };
} | {
    kind: "failed";
    reason: string;
} | {
    kind: "unavailable";
    reason: "provider_object_unavailable";
};
/**
 * Preserve the distinction between a provider object that no longer exists
 * and a fetch that may succeed later. GroupMe's public CDN returns 403/404 for
 * unavailable objects; every other failure remains retryable/unproven.
 */
export declare function fetchAttachmentBlobOutcome(urlString: string, recordKey: string): Promise<AttachmentFetchOutcome>;
interface NormalizedAttachment {
    blob_id?: string | null;
    lat?: number | null;
    lng?: number | null;
    name: string | null;
    type: "image" | "file" | "location" | "emoji";
    url: string | null;
}
type AttachmentRecordEmitter = (data: RecordData) => Promise<void>;
export declare function attachmentContentType(att: GroupMeAttachment): string;
/**
 * Attachment record ids must be unique per attachment, not per type — the
 * prior `attachment:${type}` record key collapsed every image (or every
 * file) in a run onto one blob-upload record_key, which also meant every
 * hydration after the first for a given type silently overwrote the same
 * upstream record. Keyed on the owning message + the attachment's position
 * within that message's attachment array, which is stable across reruns of
 * the same message.
 */
export declare function attachmentRecordId(messageId: string, index: number, url: string | null): string;
export declare function normalizeOneAttachment(att: GroupMeAttachment, index: number, messageId: string, messageStream: "group_messages" | "direct_chat_messages", uploader: BlobUploader | undefined, emitAttachmentRecord: AttachmentRecordEmitter | undefined): Promise<NormalizedAttachment>;
export declare function normalizeAttachments(attachments: GroupMeAttachment[] | undefined | null, messageId: string, messageStream: "group_messages" | "direct_chat_messages", uploader: BlobUploader | undefined, emitAttachmentRecord: AttachmentRecordEmitter | undefined): Promise<NormalizedAttachment[]>;
type BlobHydrationOutcome = {
    kind: "failed";
    reason: string;
} | {
    kind: "hydrated";
    blobRef: ReferenceBlobRef;
} | {
    kind: "unavailable";
    reason: "provider_object_unavailable";
};
type BlobUploader = (url: string, mimeType: string, recordKey: string) => Promise<BlobHydrationOutcome | ReferenceBlobRef | null>;
type ProgressFn = (message: string, extra?: ProgressExtra) => Promise<void>;
/**
 * Prefers the Content-Type actually observed on the attachment fetch over
 * the pre-fetch type-based guess. `observedContentType` is already
 * normalized/allowlisted by `normalizeAttachmentContentType` upstream.
 */
export declare function resolveUploadMimeType(observedContentType: string | null, fallbackGuess: string): string;
interface GroupMessagesResponse {
    count: number;
    messages: GroupMeMessage[];
}
/**
 * Whether a message page ended the walk WITHOUT reaching a message the
 * provider still counts: the response served `messages: []` while its own
 * `count` field was greater than zero.
 *
 * WHAT `count` ACTUALLY MEANS — and what this predicate must NOT claim.
 * `count` is UNDOCUMENTED. GroupMe's API reference
 * (dev.groupme.com/docs/v3) shows it only inside a sample body for
 * `GET /groups/:id/messages` and never defines it in prose. All available
 * evidence says it is the conversation's LIFETIME TOTAL, not the size of
 * the page just served:
 *
 *   - `GET /groups` returns the same key as `messages.count`, sitting beside
 *     `last_message_id` — self-evidently a group total.
 *   - A per-page reading would make `count` exactly `messages.length`, i.e.
 *     carry no information at all.
 *   - Mature clients treat it as a total (Groupy binds it to
 *     `message_count` and returns it from `__len__`), and terminate
 *     pagination on 304 / empty / short pages — never on a `count`
 *     comparison.
 *
 * So an empty page against a non-zero total is NOT the provider
 * contradicting itself: the two fields answer different questions ("how
 * many has this group ever held" vs "what can I serve you from here"). A
 * total that exceeds what `before_id` pagination can reach is a documented
 * real-world state — GroupMe's own API support forum has a user walking
 * `before_id` to a 304 and reaching only 62k of a reported 70k messages,
 * with history stopping in Aug 2013, attributed to server-side retention.
 * This owner's data shows the SAME Aug-2013 floor (see
 * connectors/groupme/docs/groupme-message-count-shortfall.md).
 *
 * What the predicate therefore means, and all it means: this walk ran out
 * of servable history while the provider's total still implied more, so
 * the walk's boundary is UNPROVEN. It could be retention (old messages
 * counted but no longer stored), messages deleted without decrementing the
 * total, or a transient refusal — the response carries nothing that tells
 * them apart, so the connector names none of them.
 *
 * NOTE the two `count` values in play are from DIFFERENT endpoints and must
 * not be conflated: this predicate reads the per-response `count` from
 * `GET /groups/:id/messages`, while the shortfall arithmetic downstream
 * uses `providerMessageCount()` from the `/groups` listing.
 *
 * `count === 0` with an empty array is coherent and stays an ordinary
 * natural end. GroupMe's documented end-of-history signal — HTTP 304, "If
 * no messages are found (e.g. when filtering with `before_id`) we return
 * code 304" — is normalized to a synthetic `{count: 0, messages: []}` by
 * `fetchMessagesPage`, so the documented terminal page can never reach this
 * predicate as a false positive.
 */
export declare function pageEndedShortOfProviderCount(resp: GroupMessagesResponse): boolean;
/**
 * Per-group durable resumable cursor for `group_messages`' incremental walk.
 * Keyed by GroupMe group id, value is the `id` of the newest message
 * observed in that group's last clean run — an opaque, provider-issued
 * boundary marker, never a locally-computed time window. Lives alongside
 * `fingerprints` in `state.group_messages`, written only when
 * `collectGroupMessages`' overall pass is clean (see `CollectionOutcome`) —
 * the same all-or-nothing gate that already protects the fingerprint map.
 *
 * Resumed with GroupMe's documented FORWARD pagination primitive,
 * `after_id`: "messages that immediately follow a given message... in
 * ascending order (which makes it easy to pick off the last result for
 * continued pagination)" (dev.groupme.com/docs/v3). This is the API's own
 * intended continuation cursor for exactly this use case — advance the
 * cursor to each page's last message id and keep paging forward until a
 * page shorter than the page size proves the natural end. This replaces two
 * earlier, rejected designs: a locally-computed timestamp-plus-overlap
 * window (an ungrounded heuristic — no overlap size is provably sufficient,
 * and a time window cannot force re-observation of a row whose mutable
 * field changed without moving `created_at`), and a backward `before_id`
 * re-scan searching for this same id as an "anchor" (wastes work
 * proportional to everything posted since last run, and — the reason it was
 * rejected outright — a page-count ceiling on that backward search is
 * itself a correctness bug: a sufficiently large, still-growing group could
 * never converge within a fixed page cap).
 *
 * A cursor is a PURE RESUME POINT, not a search target: this walk never
 * re-derives "was this row already covered" by comparing ids against a
 * target — it trusts `after_id` to already start exactly one message past
 * where the prior run stopped, and it just keeps going until the API says
 * there's nothing left.
 */
export interface GroupMessageCursors {
    [groupId: string]: string;
}
/** Decode `state.group_messages.cursors` tolerantly: any missing/malformed
 *  shape yields an empty map (cold start — walk backward to the natural
 *  end instead), matching `decodePriorFingerprints`'s tolerance policy in
 *  fingerprint-cursor.ts. */
export declare function decodeGroupMessageCursors(priorState: unknown): GroupMessageCursors;
/**
 * Whether a stream's collection pass reached its own clean end (`failed:
 * false`) or was cut short by a fetch/parse failure it never recovered from.
 * `considered` is the raw enumerated-boundary count, measured at each
 * fetch's response — independent of how many records `emitRecord` actually
 * received, so a run that filtered/suppressed everything still proves the
 * boundary it walked. The caller (`collect()`) uses `failed` to gate both
 * the STATE checkpoint and the DETAIL_COVERAGE proof: a failed pass must
 * commit neither, since it never fully walked the boundary it would be
 * claiming.
 */
export interface CollectionOutcome {
    considered: number;
    failed: boolean;
}
/**
 * Per-run honest coverage accounting for the `attachments` detail stream
 * (manifest `coverage_strategy: "parent_detail_accounting"` — see
 * evidence/coherence.ts's `strategyBoundsWindowRatherThanCounting`, which
 * deliberately excludes this strategy: it owes a per-item accounting, not a
 * bounded window, so `covered` must actually satisfy `considered`).
 *
 * Every attachment `normalizeOneAttachment` attempts to hydrate (an
 * image/file attachment with a URL) lands in `requiredKeys` — the
 * denominator — the moment its record reaches `emitAttachmentRecord`.
 * `hydrationStatus` then places it in exactly one outcome bucket:
 *   - `hydrated` -> `hydratedKeys` (the numerator: blob bytes actually
 *     committed to storage).
 *   - `unavailable` -> `unavailableKeys`: the public provider CDN returned a
 *     bounded, recognized terminal-object error. Metadata stays retained and
 *     the key is reported as an explicit optional skip.
 *   - `deferred` or `failed` -> neither bucket. Missing runtime support,
 *     validation failures, transient HTTP failures, and upload failures stay
 *     uncovered because another run may still acquire the bytes.
 *
 * A `failed` hydration remains uncovered. Its parent-bound DETAIL_COVERAGE
 * report then withholds that parent's cursor, so the next run re-enumerates the
 * owning message and retries the provider URL without persisting that URL in
 * durable control-plane metadata. A missing uploader is handled the same way.
 */
export interface AttachmentDetailCoverage {
    hydratedKeys: string[];
    requiredKeys: string[];
    unavailableKeys: string[];
}
type AttachmentParentStream = "direct_chat_messages" | "group_messages";
/** Fresh, empty accumulator for one run's attachments detail pass. */
export declare function makeAttachmentDetailCoverage(): AttachmentDetailCoverage;
/**
 * Record one attachment record reaching the `attachments` stream into the
 * coverage accumulator, keyed by its own `hydration_status`. Pure: mutates
 * the passed accumulator. `data.id`/`data.hydration_status` are read
 * defensively (RecordData is an index-signature type) since this runs on
 * the same record shape `emitRecord` will independently (re-)validate —
 * this accumulator must never assume the runtime accepted the record.
 */
export declare function recordAttachmentCoverage(coverage: AttachmentDetailCoverage, data: RecordData): void;
/**
 * Build one parent-bound attachment coverage report. Group and direct-message
 * cursors advance independently, so a shortfall must withhold only the parent
 * whose message walk produced the missing attachment.
 */
export declare function buildAttachmentDetailCoverageMessage(coverage: AttachmentDetailCoverage, stateStream: AttachmentParentStream): DetailCoverageMessage;
export declare function collectGroups(token: string, cursor: ReturnType<typeof openFingerprintCursor>, progressWithSignals: ProgressFn, emitRecord: (stream: string, data: RecordData) => Promise<void>, reportStreamFailure?: CollectContext["reportStreamFailure"]): Promise<CollectionOutcome>;
export declare function collectDirectChats(token: string, cursor: ReturnType<typeof openFingerprintCursor>, progressWithSignals: ProgressFn, emitRecord: (stream: string, data: RecordData) => Promise<void>, reportStreamFailure?: CollectContext["reportStreamFailure"]): Promise<CollectionOutcome>;
export declare function collectDirectChatMessages(token: string, cursor: ReturnType<typeof openFingerprintCursor>, uploader: BlobUploader | undefined, emitAttachmentRecord: AttachmentRecordEmitter | undefined, progressWithSignals: ProgressFn, emitRecord: (stream: string, data: RecordData) => Promise<void>, sinceEpochSeconds?: number | null, reportStreamFailure?: CollectContext["reportStreamFailure"]): Promise<CollectionOutcome>;
/**
 * Result of `collectGroupMessages`: the ordinary `CollectionOutcome` plus the
 * next-run per-group cursor map. `nextCursors` is only meaningful when
 * `failed` is false — `collect()` must not persist it otherwise, same rule as
 * the fingerprint cursor's STATE emit (see `CollectionOutcome`'s doc comment).
 */
export interface GroupMessagesCollectionOutcome extends CollectionOutcome {
    nextCursors: GroupMessageCursors;
    /** Per-group provider-count reconciliation for this run. */
    shortfalls: GroupMessageShortfall[];
    /** Groups whose walk could not be anchored because the provider reported no count. */
    unanchoredGroupIds: string[];
}
/** One group where the provider reported MORE messages than the walk saw. */
export interface GroupMessageShortfall {
    groupId: string;
    providerCount: number;
    /**
     * True when the walk that produced this shortfall ran out of servable
     * history before reaching the provider's total (see
     * `pageEndedShortOfProviderCount`) — so the shortfall is UNEXPLAINED: the
     * connector cannot tell retention (the oldest messages are gone from the
     * provider) from a transient refusal to serve them.
     *
     * Optional so existing constructions (and fixtures) stay valid; absent is
     * read as `false`.
     */
    unprovenBoundary?: boolean;
    walked: number;
}
/**
 * Split a run's shortfalls into the situations they conflate, so each can be
 * reported with its own reason and recovery hint.
 *
 * `unexplained` — the walk RAN OUT OF SERVABLE HISTORY before reaching the
 * provider's total: GroupMe served `messages: []` while stating `count > 0`
 * in the same body. Because `count` is a lifetime total (see
 * `pageEndedShortOfProviderCount`), this is not self-contradiction — but it
 * is still ambiguous as to CAUSE. Measured live, the response is
 * byte-identical (headers included, `content-length` aside) whether the
 * oldest messages are gone for good or the provider is declining to serve
 * them right now, and GroupMe emits no status code, `Retry-After`, or
 * rate-limit header to separate them. The connector therefore does NOT
 * claim to know which it is, and does not claim the group was proven walked.
 *
 * On this owner's real data the evidence points overwhelmingly at
 * retention: all 42 affected groups went dormant before Aug 2013, and no
 * stored message anywhere predates 2013-08-15 (see
 * connectors/groupme/docs/groupme-message-count-shortfall.md). But "overwhelmingly" is not
 * "provably", and one run's response cannot establish it per-group.
 *
 * A PRIOR REVISION of this function classified exactly this shape as
 * definitively `not_retriable`, keyed on `walked === 0`. That was
 * unsound: `walked === 0` IS the ambiguous signal, so keying the
 * "unrecoverable" verdict on it means the connector asserts unrecoverability
 * on the strength of a response that cannot support the claim. Whatever the
 * true cause on any given group, a connector must not convert an ambiguous
 * observation into a certain verdict.
 *
 * `partial` — the walk returned SOME messages but fewer than claimed, and
 * ended on a page the provider actually served. The shortfall is real and the
 * boundary evidence is coherent, so retrying is a meaningful suggestion.
 *
 * This is a classification split ONLY. NEITHER bucket is subtracted from the
 * missing total, and neither is counted as covered: an unserved message is
 * still an absent message, and saying so honestly is the whole point of the
 * anchor.
 */
export declare function partitionGroupMessageShortfalls(shortfalls: readonly GroupMessageShortfall[]): {
    partial: GroupMessageShortfall[];
    unexplained: GroupMessageShortfall[];
};
/**
 * Compare one group's provider-reported message count against what this
 * run's walk actually enumerated.
 *
 * ONE-DIRECTIONAL ON PURPOSE. Only `providerCount > walked` is reported.
 * The reverse — we walked more than the provider now claims — is NOT a
 * defect: PDPP is a preservation product, so messages deleted from GroupMe
 * after we collected them legitimately make our holdings larger than the
 * provider's current count. Reporting that as a gap would flag successful
 * preservation as loss.
 *
 * Returns `null` when the provider reported no usable count: unknown is
 * not zero, and an absent count must never become a denominator.
 *
 * CEILING: this is a scalar, so it cannot distinguish "we are missing N
 * distinct messages" from "we collected N duplicates". GroupMe exposes no
 * cheap per-group message-id listing to make this a set comparison, so the
 * anchor detects magnitude only — see the connector README note.
 */
export declare function groupMessageShortfall(group: GroupMeGroup, walked: number, unprovenBoundary?: boolean): {
    kind: "ok";
} | {
    kind: "short";
    shortfall: GroupMessageShortfall;
} | {
    kind: "unanchored";
};
export declare function collectGroupMessages(token: string, cursor: ReturnType<typeof openFingerprintCursor>, uploader: BlobUploader | undefined, emitAttachmentRecord: AttachmentRecordEmitter | undefined, progressWithSignals: ProgressFn, emitRecord: (stream: string, data: RecordData) => Promise<void>, sinceEpochSeconds?: number | null, priorCursors?: GroupMessageCursors, collectionMode?: "full_refresh" | "incremental", reportStreamFailure?: CollectContext["reportStreamFailure"]): Promise<GroupMessagesCollectionOutcome>;
/**
 * `collect()` writes each stream's fingerprint cursor under that stream's OWN
 * top-level `state.<stream>` key — `state.groups`, `state.group_messages`,
 * `state.direct_messages`, `state.direct_chat_messages`, `state.attachments`
 * — mirroring exactly what it reads back on the next run. This is the only
 * shape that survives the runtime's per-stream last-wins STATE projection
 * (`bufferedState[message.stream] = message.cursor` in collector-runner.ts):
 * a single unified emit under `stream: "groups"` would collide with
 * `groups`'s own per-stream STATE emit and get overwritten by it on every
 * run where `groups` succeeds, silently discarding the other four streams'
 * cursors. There is no prior persisted state to migrate — GroupMe has never
 * shipped a build that read these keys.
 */
export declare function collect({ state, requested, credentials, emit, emitRecord, progress, reportStreamFailure, collectionMode, }: CollectContext, testDependencies?: {
    uploader?: BlobUploader;
}): Promise<void>;
export {};
/**
 * DESIGN NOTE (scope closed vs. not): this fix closes exact FORWARD
 * incrementality for group_messages (no more repeated full-history
 * rescans). It does NOT close automatic repair of an old message's mutable
 * field (favorited_by/like_count) once that message has fallen behind the
 * resume cursor — hence `mutable_state` in the manifest, not
 * `immutable_log`. That repair currently requires an explicit
 * `collection_mode: "full_refresh"`; no periodic/automatic trigger for it
 * exists anywhere in this system today (verified against RI's START-build
 * path, not assumed). The generic, connector-agnostic primitive this
 * system would need to close that gap — a manifest-declared per-stream
 * repair cadence the SCHEDULER (not this connector) interprets — is
 * specified in docs/reference/periodic-full-refresh-repair.md, not
 * implemented here.
 */
//# sourceMappingURL=index.d.ts.map