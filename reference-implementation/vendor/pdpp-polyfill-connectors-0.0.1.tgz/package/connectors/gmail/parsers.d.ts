import type { MessageAddressObject, MessageEnvelopeObject, MessageStructureObject } from "imapflow";
import type { AttachmentRecord, ClassifiedBody, ThreadAggregate } from "./types.ts";
export declare const SNIPPET_MAX_CHARS = 200;
export declare const MAX_BODY_FIELD_CHARS: number;
/**
 * Narrow an imapflow UIDVALIDITY/modseq value to a Number for STATE cursor
 * use. imapflow types these as `bigint`, but the wire value is a single
 * 32-bit unsigned int (UIDVALIDITY) or a mod-sequence value typically well
 * within safe-integer range. We only coerce if we can check the type at
 * runtime — casting `as bigint` would hide a future shape change.
 */
export declare function bigintToNumber(value: unknown): number | null;
/**
 * Preserve precision for values that might exceed safe-integer range by
 * returning a string when outside it, a number otherwise.
 */
export declare function bigintToCursor(value: unknown): number | string | null;
export declare function canonicalLabelName(raw: string): string;
export declare function isGmailSystemLabel(name: string): boolean;
export declare function labelParentName(name: string): string | null;
export declare function addressListToArray(list: readonly MessageAddressObject[] | undefined): Array<{
    name: string | null;
    email: string | null;
}>;
export declare function toFlagsArray(flags: Set<string> | undefined): string[];
export declare function toLabelsArray(labels: Set<string> | string[] | undefined): string[];
/**
 * Strip characters that break JSONL reassembly on the runtime side.
 * - Lone surrogates → U+FFFD (JSON.stringify can otherwise produce
 *   malformed \uDXXX escapes that JSON.parse rejects).
 * - Raw control chars (0x00-0x08, 0x0B-0x1F, 0x7F) → replaced with a
 *   single space. JSON.stringify escapes \r\n to "\\r\\n" reliably, so
 *   keeping them in the string is safe — but empirically some body_text
 *   values yield raw \n in the output stream. Defensively normalize all
 *   disallowed control chars to a space before stringify to guarantee a
 *   clean JSONL line.
 */
export declare function sanitizeForJsonl(v: unknown): unknown;
/**
 * Walk a BODYSTRUCTURE tree and emit an AttachmentRecord for every leaf
 * whose disposition is attachment/inline or which carries a filename
 * parameter. Part index follows IMAP's dotted-path convention (1, 1.2,
 * 2.1.1...) so callers can fetch the part later by its exact path.
 */
export declare function decodeBodystructureForAttachments(structure: MessageStructureObject | undefined, msgId: string, receivedAt: string, path?: string): AttachmentRecord[];
/**
 * Find the first leaf of a given MIME type in a BODYSTRUCTURE tree and
 * return its IMAP part number (e.g. "1" or "1.2"), or null if none.
 */
export declare function findFirstPartByType(structure: MessageStructureObject | undefined, mimeType: string, path?: string): string | null;
export declare function findTextPlainPart(structure: MessageStructureObject | undefined, path?: string): string | null;
export declare function findTextHtmlPart(structure: MessageStructureObject | undefined, path?: string): string | null;
/** Locate a leaf in a BODYSTRUCTURE tree by its IMAP part number. */
export declare function findLeafByPath(structure: MessageStructureObject | undefined, targetPath: string): MessageStructureObject | null;
/**
 * Decode a body part buffer according to its MIME transfer encoding and
 * charset into a JavaScript string. Best-effort; never throws.
 */
export declare function decodeBodyPart(buffer: Buffer | null | undefined, encoding: string | null, charset: string | null): string;
/**
 * Strip HTML tags into plain text. Handles <script>/<style> blocks,
 * common block-level tags (inserted newlines), <br>, and basic entity
 * decoding. Not a full HTML parser — intentionally minimal for bodies
 * that arrive as HTML-only (e.g. newsletters) where we still want a
 * readable text fallback.
 */
export declare function stripHtmlToText(html: string | null | undefined): string;
/**
 * Parse a "References:" header value into an array of Message-IDs.
 * IMAP may return headers as a Buffer; References is a whitespace-separated
 * list of <id@host> tokens, possibly wrapped across lines.
 */
export declare function parseReferencesHeader(rawHeaders: Buffer | string | null | undefined): string[];
/**
 * Decode a body part buffer according to its MIME transfer encoding, then
 * extract a plain-text snippet: strip quoted reply blocks and collapse
 * whitespace. Returns a trimmed string up to `maxChars`.
 */
export declare function makeSnippet(buffer: Buffer | null | undefined, encoding: string | null, charset: string | null, maxChars?: number): string | null;
/**
 * Create or update a ThreadAggregate in place from one message's fields.
 * If `existing` is undefined, builds a fresh aggregate initialized from
 * the incoming message; otherwise mutates `existing` and returns the same
 * reference. Callers drive the Map keyed by threadId.
 */
export declare function updateThreadAggregate(existing: ThreadAggregate | undefined, params: {
    flagsArr: readonly string[];
    hasAttachments: boolean;
    labels: readonly string[];
    participants: readonly string[];
    receivedAt: string;
    subject: string | null;
    threadId: string;
}): ThreadAggregate;
export declare function buildThreadRecord(agg: ThreadAggregate): Record<string, unknown>;
/**
 * Stable per-thread fingerprint: a hash of every field of the emitted
 * thread record. The connector's `1:*` aggregation re-derives the
 * record on every run; without this gate, even a thread whose
 * semantic shape hasn't moved emits a fresh RECORD and grows
 * version history. The fingerprint includes every field on the
 * record — none excluded — because every field is source-derived
 * (subject, participants, counts, dates, labels). No run-clock
 * fields participate.
 *
 * Thin wrapper over the shared `recordFingerprint` helper so the gmail
 * connector and the shared `openFingerprintCursor` agree byte-for-byte
 * on what an unchanged thread hashes to. Without that agreement the
 * STATE cursor written by an old build and read by a new one would
 * force a one-time re-emit of every thread.
 */
export declare function buildThreadFingerprint(agg: ThreadAggregate): string;
/**
 * Resolved body-part metadata pulled from a BODYSTRUCTURE tree. Used by the
 * connector's body-fetch branch to decide which IMAP parts to request and
 * how to decode the returned buffers. Pure: no IMAP IO.
 */
export interface BodyPartSelection {
    htmlCharset: string | null;
    htmlEncoding: string | null;
    htmlLeaf: MessageStructureObject | null;
    htmlPart: string | null;
    plainCharset: string | null;
    plainEncoding: string | null;
    plainLeaf: MessageStructureObject | null;
    plainPart: string | null;
}
/**
 * Given a BODYSTRUCTURE and the caller's intent (wantBodies/wantMessages),
 * locate the text/plain and text/html leaves and return their encodings +
 * charsets. htmlPart is only resolved when wantBodies is true because we
 * otherwise skip the HTML fetch entirely (the snippet comes from text/plain).
 */
export declare function selectBodyParts(structure: MessageStructureObject | undefined, wantBodies: boolean): BodyPartSelection;
/**
 * Classify the final body_text + body_source we'll emit on message_bodies,
 * falling back to html_stripped when text/plain is absent. Mirrors the
 * original in-loop branching exactly so the record shape is unchanged.
 */
export declare function classifyBodySource(bodyTextFull: string | null, bodyHtmlFull: string | null): ClassifiedBody;
export interface CanonicalBodyBlobCandidate {
    content: Buffer;
    jsonPath: "/body_html" | "/body_text";
    mimeType: "text/html" | "text/plain";
}
/** Return exact UTF-8 bytes for body fields that cannot remain in record_json. */
export declare function canonicalBodyBlobCandidates(params: {
    bodyHtmlFull: string | null;
    bodyTextFull: string | null;
}): CanonicalBodyBlobCandidate[];
/**
 * Build the `message_bodies` RECORD payload for one message. Mirrors the
 * original in-loop semantics:
 *   - Truncate body_text / body_html to MAX_BODY_FIELD_CHARS + "…[truncated]"
 *   - Emit body_*_bytes from the FULL (pre-truncation) decoded body
 *   - Fall back to html_stripped when text/plain is absent/empty
 *   - charset = textCharset || htmlCharset || null
 *
 * `message_received_at` denormalizes the parent message's received time onto
 * the body so the row can carry a semantic time of its own. A body has no
 * timestamp in its IMAP payload, and semantic-time resolution reads only the
 * record's own fields — no join — so without this the stream would fall back
 * to ingest time. Mirrors the same denormalization on `attachments`.
 */
export declare function buildMessageBodyRecord(params: {
    bodyHtmlFull: string | null;
    bodyTextFull: string | null;
    gmMsgid: string;
    htmlCharset: string | null;
    receivedAt: string;
    textCharset: string | null;
}): Record<string, unknown>;
/**
 * Build the `messages` RECORD payload for one full metadata row. Pure over
 * an envelope + already-parsed flags/labels/attachments — no IMAP IO.
 */
export declare function buildMessageRecord(params: {
    attachmentsCount: number;
    dateHeader: string | null;
    envelope: MessageEnvelopeObject;
    flagsArr: readonly string[];
    gmMsgid: string;
    gmThrid: string;
    labels: readonly string[];
    rawHeaders: Buffer | string | null | undefined;
    receivedAt: string;
    sizeBytes: number | null;
    snippet: string | null;
}): Record<string, unknown>;
/** Determine whether a received_at timestamp falls inside a since/until window. */
export declare function isInTimeRange(receivedAt: string, range: {
    since?: string;
    until?: string;
} | null | undefined): boolean;
/** Extract the envelope participants (from/to/cc) as a de-duped email list. */
export declare function envelopeParticipants(env: MessageEnvelopeObject | undefined): string[];
//# sourceMappingURL=parsers.d.ts.map