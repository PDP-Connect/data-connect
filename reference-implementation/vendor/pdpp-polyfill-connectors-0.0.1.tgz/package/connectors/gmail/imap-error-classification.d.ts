/**
 * Classify an IMAP transport error as transient (retryable) or terminal.
 * Checks both error code (structured, from imapflow) and message (fallback).
 *
 * Transient (retryable):
 *   - ImapFlow codes: CONNECT_TIMEOUT, GREETING_TIMEOUT, UPGRADE_TIMEOUT
 *   - OS codes: ECONNRESET, ECONNREFUSED, ECONNABORTED
 *   - Message patterns: ETIMEDOUT, fetch failed, EPIPE, timeout
 *
 * Terminal (non-retryable):
 *   - Auth codes: BAD_AUTH, AUTH_FAILED, etc.
 *   - Auth messages: "invalid credentials", "[Gmail] IMAP is disabled", etc.
 */
export declare function isImapTransientError(err: unknown): boolean;
//# sourceMappingURL=imap-error-classification.d.ts.map