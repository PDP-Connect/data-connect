#!/usr/bin/env node
import { type FetchMessageObject, ImapFlow, type ListResponse } from "imapflow";
import { type DetailCoverageMessage, type DetailGapMessage, type DetailGapStartEntry } from "../../src/connector-runtime.ts";
import { type FingerprintCursor } from "../../src/fingerprint-cursor.ts";
import type { ReferenceBlobUploadFn } from "../../src/reference-blob-uploader.ts";
import { type BodyPartSelection } from "./parsers.ts";
import type { AttachmentAllMailCursor, AttachmentRecord, BlobRef, EmittedMessage, MessagesBackfillCursor, ProgressMessage, StreamRequest, ThreadAggregate } from "./types.ts";
export declare const DEFAULT_MAX_ATTACHMENT_BYTES: number;
export declare const DEFAULT_ATTACHMENT_BACKFILL_WINDOW_UIDS = 500;
export declare const DEFAULT_ATTACHMENT_STALL_TIMEOUT_MS = 90000;
/** Test-only reset of the terminal latch; the real process never reuses it. */
export declare function __resetDoneLatchForTests(): void;
/** Test-only handle on the real stdout emitter, so the latch is exercised
 *  through the same function every production path writes through. */
export declare function gmailEmitForTests(msg: EmittedMessage): Promise<void>;
/** Progress cadence for the body pass — emit a PROGRESS message every N
 *  processed rows. Exported so the extraction preserves observable
 *  behavior; tests rely on the boundary. */
export declare const FETCH_MSG_PROGRESS = 500;
export type EmitRecordFn = (stream: string, data: Record<string, unknown>, keyField?: "id" | "name") => Promise<boolean> | Promise<void>;
export type ProgressEmitter = (msg: ProgressMessage) => Promise<void>;
/**
 * Bodies resolved for one message.
 *
 * `fetchFailed` is the load-bearing field. All three body fields are null in
 * TWO very different situations, and before this discriminator existed the
 * caller could not tell them apart:
 *
 *   1. The message genuinely has no body part in scope (or scope did not ask).
 *      Nothing was lost; `body_source: "empty"` is the honest record.
 *   2. The IMAP body fetch THREW. The body exists on the server, we just did
 *      not get it. Emitting `body_source: "empty"` here is a lie, and because
 *      the walk advances the UID cursor past the message either way, the real
 *      body lands behind the cursor and is never refetched.
 *
 * `fetchFailed: true` marks case 2 so `processMessage` can emit a durable,
 * retryable DETAIL_GAP for that message. `failureClass` carries the bounded,
 * non-secret reason (never raw error text — see `bodyFetchFailureClass`) so a
 * gap that keeps failing records WHY instead of accruing attempts against a
 * permanently-null `last_error_json`.
 */
export interface FetchedBodies {
    bodyHtmlFull: string | null;
    bodyTextFull: string | null;
    /** Bounded failure category; present only when `fetchFailed` is true. */
    failureClass?: string;
    /** True only when the body fetch threw — NOT when the message is simply empty. */
    fetchFailed?: boolean;
    snippet: string | null;
}
/**
 * Injected body fetcher. Production wires this to an IMAP round-trip;
 * tests wire it to a pure function that returns canned bodies (or a
 * rejected promise to simulate fetch failure — the helper turns that
 * into all-nulls plus `fetchFailed: true` internally).
 */
export type FetchBodiesFn = (msg: FetchMessageObject, selection: BodyPartSelection, wantBodies: boolean, wantMessages: boolean) => Promise<FetchedBodies>;
export interface AttachmentDownload {
    content: AsyncIterable<Buffer | Uint8Array | string>;
    expectedSize: number | null;
    mimeType: string;
}
export type FetchAttachmentFn = (msg: FetchMessageObject, attachment: AttachmentRecord) => Promise<AttachmentDownload>;
export type UploadAttachmentBlobFn = (args: {
    content: AsyncIterable<Buffer | Uint8Array | string>;
    connectorId: string;
    jsonPath?: string;
    mimeType: string;
    recordKey: string;
    stream: "attachments" | "message_bodies";
}) => Promise<BlobRef>;
export type UploadBodyBlobFn = ReferenceBlobUploadFn;
type AttachmentHydrationFailureStage = "blob_upload_http_4xx" | "blob_upload_http_5xx" | "blob_upload_integrity_failed" | "blob_upload_invalid_response" | "blob_upload_transport_failed" | "imap_download_failed";
/** Aggregate-safe taxonomy retained only until recovery telemetry settles. */
interface AttachmentHydrationFailure {
    readonly stage: AttachmentHydrationFailureStage;
}
export interface AttachmentHydrationResult {
    readonly failure: AttachmentHydrationFailure | null;
    readonly record: AttachmentRecord;
}
/**
 * Resolves to an honest per-attachment outcome for every ordinary failure
 * mode (download error, too-large, upload error) — callers do not need a
 * try/catch for those. The one exception: a stall-timeout (see
 * `AttachmentStallTimeoutError`) REJECTS instead, because by the time it
 * fires the shared IMAP connection has already been closed and every later
 * command in the run would fail too; that must end the run, not be
 * swallowed into one attachment's coverage row.
 */
export type HydrateAttachmentFn = (msg: FetchMessageObject, attachment: AttachmentRecord) => Promise<AttachmentHydrationResult>;
export interface AttachmentBackfillSummary {
    failed: number;
    hydrated: number;
    remaining_historical_gaps: number;
    too_large: number;
    unavailable_skipped: number;
}
export declare function createAttachmentBackfillSummary(): AttachmentBackfillSummary;
export declare function addAttachmentBackfillRecordToSummary(summary: AttachmentBackfillSummary, data: Record<string, unknown>): void;
export declare function formatAttachmentBackfillSummary(summary: AttachmentBackfillSummary): string;
/**
 * Per-run honest coverage accounting for the `attachments` detail stream.
 *
 * Every attachment decoded from a message's BODYSTRUCTURE during the run is
 * a key we attempted to hydrate, so it lands in `requiredKeys` (the
 * denominator). Each attempt lands in exactly one outcome by `hydration_status`:
 *   - `hydrated` → `hydratedKeys` (the numerator: blob bytes committed).
 *   - `failed`   → `gapKeys` (a retryable detail gap to re-attempt next run).
 *   - `too_large` or `deferred` → unaccounted (required denominator only).
 */
/** A failed attachment hydration, paired with why it failed (bounded, non-secret). */
export interface FailedAttachmentRecord {
    readonly failureClass: string;
    readonly record: AttachmentRecord;
}
export interface AttachmentDetailCoverage {
    /**
     * Failed attachment records, retained so the run can emit one matching
     * DETAIL_GAP per `gapKeys` entry. The host commit-gate credits a missing
     * required key only when it is hydrated, optional-skipped, or backed by a
     * durable pending DETAIL_GAP — `gap_keys` alone do not satisfy it. Each
     * record's `id` is exactly the value that landed in `gapKeys`, keeping the
     * gap's `record_key` and the coverage key a single source of truth.
     *
     * `failureClass` is the bounded, non-secret classification (see
     * `attachmentHydrationFailureClass`) — the only hydration-failure detail
     * that reaches the emitted DETAIL_GAP. Without it, a gap that keeps
     * failing on every retry never records why: `attempt_count` climbs but
     * `last_error_json` stays null forever (the 2026-08 Gmail 5-row defect).
     */
    failedRecords: FailedAttachmentRecord[];
    gapKeys: string[];
    hydratedKeys: string[];
    requiredKeys: string[];
}
/** Fresh, empty accumulator for one attachments detail pass. */
export declare function makeAttachmentDetailCoverage(): AttachmentDetailCoverage;
/**
 * Record one attempted attachment hydration into the coverage accumulator by
 * its terminal `hydration_status`. A `deferred` status (never hydrated this
 * run) is still a considered key but has no terminal outcome bucket, so it
 * counts only toward the denominator. Pure: mutates the passed accumulator.
 *
 * `failure` is the same `AttachmentHydrationFailure | null` the hydrator
 * already computes for aggregate telemetry — passed through here so a
 * `failed` outcome's DETAIL_GAP can carry a bounded, non-secret `error.class`
 * instead of recording an attempt with no evidence of why it failed.
 */
export declare function recordAttachmentCoverage(coverage: AttachmentDetailCoverage, record: AttachmentRecord, failure?: AttachmentHydrationFailure | null): void;
/**
 * Build the per-run attachments DETAIL_COVERAGE after the detail lane settles.
 * The list cursor that anchors this detail pass lives on `messages`, so that is
 * the `state_stream`.
 * Reference-only: this reuses DETAIL_COVERAGE without promoting it to portable
 * protocol.
 *
 * Extracted from `emitAttachmentDetailCoverage` so the zero-attachment case is
 * testable without capturing process stdout.
 */
export declare function buildAttachmentDetailCoverageMessage(coverage: AttachmentDetailCoverage): DetailCoverageMessage;
/**
 * Whether this run walked a boundary that can support an attachments coverage
 * claim at all.
 *
 * `attachments` has no enumeration of its own: an attachment is only ever
 * discovered by decoding the BODYSTRUCTURE of a message the run already
 * fetched. Its denominator is therefore inherited from whatever slice of the
 * mailbox the run walked — and on an ordinary scheduled run that slice is the
 * incremental forward window plus the MODSEQ delta, i.e. a CHANGE FEED, not an
 * inventory.
 *
 * That is exactly the apple_contacts `contactsBoundaryEstablished` situation
 * (`connectors/apple_contacts/index.ts`), and it needs the same answer. A quiet
 * 16-minute run that observes no new mail decodes no attachment parts and would
 * otherwise emit `considered: 0, covered: 0` — numbers that are trivially
 * self-consistent and read downstream as "this stream is proven complete",
 * when the honest statement is "this run proved nothing about the mailbox".
 * Worse, the two are indistinguishable to the gate: a stream that has walked
 * almost nothing and a stream that is genuinely fully collected emit the
 * identical fact. Withholding is what keeps those two apart.
 *
 * The one boundary that does justify a whole-stream claim is a COMPLETED
 * historical `messages` walk: the historical pass fetches every UID below the
 * forward floor and `processMessage` decodes attachments for each one, so once
 * `messages.backfill.completed_at` is set, every message in All Mail has had
 * its attachment parts enumerated. Until then the mailbox below the resume
 * point is simply unwalked, and no count taken above it describes it.
 *
 * Emitting nothing leaves the stream honestly unproven (the coherence
 * contract's `checkpoint_only`/`no_proof_strategy` -> axis `unknown`) rather
 * than falsely complete. `unknown` is a worse-looking verdict than a green
 * `0/0` and that is the point: it is the true one, and it is the verdict an
 * owner can act on.
 */
export declare function attachmentsCoverageBoundaryEstablished(session: {
    messagesBackfill: MessagesBackfillCursor;
}): boolean;
/**
 * Build the recoverable DETAIL_GAP for one failed attachment hydration.
 *
 * Every attachment that lands in `DETAIL_COVERAGE.gap_keys` (hydration_status
 * `failed`) needs a matching durable DETAIL_GAP: the host commit-gate credits a
 * missing required key only when it is hydrated, optional-skipped, or backed by
 * a pending DETAIL_GAP — `gap_keys` on their own are not enough, so without this
 * a successful run that failed even one attachment aborts at commit and the
 * messages cursor never advances, re-fetching the same window every run.
 *
 * `record_key` is the attachment `id` (`<X-GM-MSGID>:<part_index>`), the exact
 * value already in `gap_keys`, so the gate matches one-to-one. `reason` is
 * `temporary_unavailable` (retryable): the `failed` bucket mixes transient
 * download/network/parse errors with no exhaustion signal, mirroring Amazon's
 * order-detail gap; retrying next run is the honest, non-destructive default.
 *
 * Reference-only and bounded: only opaque message and part identifiers cross
 * (X-GM-MSGID, the BODYSTRUCTURE part index, and the attachment id), plus —
 * when `failureClass` is supplied — a bounded, non-secret failure category
 * (e.g. `imap_download_failed`, `blob_upload_http_5xx`, `unclassified_failed`;
 * see `attachmentHydrationFailureClass`). No filename, content, blob bytes,
 * raw error text, tokens, cookies, URLs, request bodies, or payload snippets
 * are ever carried — `AttachmentRecord.hydration_error` (which CAN embed
 * that raw text) never crosses this boundary, by construction: only the
 * caller-supplied category string can reach `error.class`.
 *
 * Without a failure class, a repeatedly-retried gap accrues `attempt_count`
 * on every run but never records why it keeps failing — `last_error_json`
 * stays null forever, which is indistinguishable from "never attempted" and
 * blocks the stream from ever proving its remaining gaps are impossible
 * (2026-08 Gmail: 5 `attachments` gaps reached terminal status with 37-117
 * attempts and a permanently-null `last_error_json`).
 */
export declare function buildAttachmentDetailGap(attachment: AttachmentRecord, failureClass?: string): DetailGapMessage;
/**
 * Build the recoverable DETAIL_GAP for one message whose body fetch THREW.
 *
 * Why this exists: `message_bodies` has a `body_source: "empty"` enum value,
 * and before this gap a failed fetch and a genuinely bodyless message produced
 * the identical record. The messages walk then advanced the UID cursor to live
 * `uidnext` either way, so the real body sat behind the cursor and was never
 * refetched — while the stream read complete to the owner. A schema-valid
 * record is not the same as an honest one.
 *
 * `record_key` is the X-GM-MSGID, the `message_bodies` primary key, so a later
 * run can refetch exactly this body. The locator carries the IMAP `uid` too,
 * but only as a hint: a UID is meaningful only inside one UIDVALIDITY epoch,
 * whereas X-GM-MSGID is stable across epochs. The message id is therefore the
 * authoritative half, and the UID merely saves a lookup when the epoch has not
 * rolled — which is why the gap stays valid even if it does.
 *
 * `reason` is `temporary_unavailable` (retryable): a thrown BODY[...] fetch
 * mixes transient network/IMAP faults with no exhaustion signal, exactly like
 * the attachments gap above, so retrying next run is the honest default.
 *
 * Bounded and reference-only: only opaque identifiers plus the connector-chosen
 * failure class cross. No body bytes, subject, sender, filename, raw error
 * text, tokens, or URLs.
 */
export declare function buildMessageBodyDetailGap(params: {
    failureClass?: string | undefined;
    gmMsgid: string;
    uid: number | undefined;
}): DetailGapMessage;
export interface PerMessageDeps {
    /**
     * Optional accumulator for the `attachments` detail-coverage report. When
     * present, `processMessage` records every attachment it attempts to hydrate
     * so the pass driver can emit one honest DETAIL_COVERAGE after the lane
     * settles. Absent for passes that have no attachments denominator.
     */
    attachmentCoverage?: AttachmentDetailCoverage;
    detailGaps?: readonly DetailGapStartEntry[] | undefined;
    emitProgress: ProgressEmitter;
    emitProtocol: (msg: EmittedMessage) => Promise<void>;
    emitRecord: EmitRecordFn;
    failOnError?: boolean;
    fetchBodies: FetchBodiesFn;
    hydrateAttachment: HydrateAttachmentFn;
    nowIso: () => string;
    recoveredAttachmentGapIds?: Set<string>;
    requested: Map<string, StreamRequest>;
    timeRange: {
        since?: string;
        until?: string;
    } | undefined;
    uploadBodyBlob?: UploadBodyBlobFn;
    wantBodies: boolean;
    wantMessages: boolean;
}
/**
 * Emit the per-stream records for one Gmail message.
 *
 * Invariants (tested in integration.test.ts):
 *   1. No X-GM-MSGID → skip silently (return false).
 *   2. time_range filter skips out-of-range messages.
 *   3. Emit order within a single message: message_bodies → messages →
 *      attachments. The per-message order matters because downstream
 *      consumers rely on bodies being present before the messages row
 *      that references them.
 *   4. wantBodies / wantMessages / requested.has("attachments") each
 *      gate their own stream; disabling one doesn't suppress siblings.
 *   5. Body-fetch failure still emits the messages record with a null
 *      snippet — never silently drops the envelope — but ALSO emits a
 *      durable retryable DETAIL_GAP on `message_bodies`, so the body stays
 *      refetchable after the UID cursor advances past it. A genuinely
 *      bodyless message emits `body_source: "empty"` with no gap.
 *
 * Returns true if the message produced any emits (or would have, modulo
 * scope). Returns false when skipped by an early filter so the caller
 * can skip progress accounting.
 */
export declare function processMessage(deps: PerMessageDeps, msg: FetchMessageObject): Promise<boolean>;
/**
 * Phase B driver: iterate metas, emit records, report progress every
 * FETCH_MSG_PROGRESS rows. Per-message errors are logged to stderr and
 * swallowed so a single bad message doesn't halt the whole pass.
 */
export declare function emitMessagesPass(deps: PerMessageDeps, metas: readonly FetchMessageObject[]): Promise<{
    considered: number;
    covered: number;
}>;
/** Resolve the Gmail app password from env or via INTERACTION kind=credentials. */
export declare function resolveGmailPasswordFromEnv(env?: NodeJS.ProcessEnv): string | null;
/**
 * Resolve the Gmail address from env (GMAIL_ADDRESS, GMAIL_USER, or
 * AMAZON_USERNAME if it looks like an email) or by asking the user via
 * INTERACTION.
 */
export declare function resolveGmailAddressFromEnv(env?: NodeJS.ProcessEnv): string | null;
/**
 * Mask an email address for an operator/model-visible PROGRESS message.
 *
 * The owner's full Gmail address is a raw PII identifier; emitting it verbatim
 * in a PROGRESS line leaks it to every consumer of the run stream (dashboard,
 * timeline, logs, model). We still want the progress line to confirm *which
 * account/domain* connected, so we keep the domain and the first character of
 * the local-part and mask the rest:
 *
 *   "taylor.rivera@example.com"  ->  "t***@example.com"
 *   "x@example.com"            ->  "***@example.com"
 *
 * If the value does not look like an `local@domain` address (no `@`, or an
 * empty domain), we return a constant placeholder rather than risk echoing an
 * unexpected raw value. The output never contains the full local-part.
 */
export declare function redactEmailForProgress(address: string): string;
/**
 * Parse the prior `labels` STATE cursor's `fingerprints` map. The cursor
 * shape is `state.labels.fingerprints` keyed by label `name`. Legacy
 * cursors (pre-fingerprint: only `{ fetched_at }`) decode to an empty
 * map, so the first post-deploy run rebuilds the map and re-emits every
 * label exactly once.
 */
export declare function readPriorLabelFingerprints(state: Record<string, unknown>): Map<string, string>;
interface AllMailSession {
    attachmentBackfill: AttachmentAllMailCursor;
    /**
     * IMAP `EXISTS` for All Mail: the server's own count of the messages in the
     * mailbox, taken from the SELECT this run already performed. This is the
     * only mailbox-wide inventory total Gmail hands us, and it is measured at
     * the provider boundary — before a single UID is walked and independently
     * of what any pass emits.
     */
    existsTotal: number;
    fullResync: boolean;
    highestModseqCursor: number | string | null;
    messagesBackfill: MessagesBackfillCursor;
    priorExistsTotal: number | undefined;
    priorModseq: number | string | null | undefined;
    priorUidnext: number;
    uidnext: number | undefined;
    uidvalidityNum: number;
}
/**
 * Parse an ISO 8601 timestamp into IMAP's date format (DD-MMM-YYYY).
 * Returns null if the input is not a valid ISO string.
 *
 * IMAP's SINCE criterion matches messages with an internal date >= the
 * specified date, and IMAP dates are day-granular (no time component).
 * Post-filtering by exact ISO boundary is required to honor the stream's
 * declared time_range.since, which may have time-of-day precision.
 */
export declare function isoToImapDate(iso: string | undefined): string | null;
export declare function collectMetadata(client: Pick<ImapFlow, "fetch" | "search">, fetchRange: string, sinceDate?: string | null, sinceIso?: string | null): Promise<FetchMessageObject[]>;
/**
 * Bounded, non-secret failure category for a thrown body fetch.
 *
 * Only this connector-chosen category ever reaches the emitted DETAIL_GAP's
 * `error.class`. Raw error text never crosses that boundary: an IMAP error
 * message can embed the failing command, which for a BODY[...] fetch quotes
 * the mailbox and part path. The split mirrors `isImapTransientError`, which
 * the run-level retry classifier already trusts.
 */
export declare function bodyFetchFailureClass(err: unknown): string;
export declare function selectAllMailFetchRange(session: {
    fullResync: boolean;
    priorUidnext: number;
}, _requested: Map<string, StreamRequest>): string | null;
export declare const DEFAULT_MESSAGES_BACKFILL_WINDOW_UIDS = 500;
export declare function resolveMessagesBackfillWindowUids(env?: NodeJS.ProcessEnv): number;
/**
 * Select one historical message work unit. The unit is a UID interval, not a
 * positional page: Gmail UIDs may contain holes, but a successful fetch of the
 * interval accounts for those holes and lets the cursor advance to the exact
 * admitted interval end.
 */
export declare function selectMessagesBackfillFetchRange(args: {
    messagesBackfill: MessagesBackfillCursor;
    maxWindowUids?: number;
    uidnext: number | undefined;
    uidvalidity?: number;
}): string | null;
/**
 * Decide the ceiling the historical walk must reach on THIS run.
 *
 * The band defect this closes
 * ---------------------------
 * The two pointers divide one UID space, so they must MEET: every UID below
 * `forward_uidnext` that the forward pass did not actually walk has to fall
 * inside the historical walk's remit, or it belongs to neither walk and is
 * never fetched.
 *
 * The old rule was `prior.target_uid ?? priorEnd` — once written, the ceiling
 * only ever copied itself forward. Meanwhile the forward watermark advanced on
 * every run with new mail. So the ceiling froze at the mailbox's size on the
 * day the backfill started while the resume point climbed away from it, and the
 * interval between them reopened continuously and grew without bound. Repairing
 * the stored value (as `scripts/repair/gmail-backfill-target-extend.ts` did)
 * fixed one instance of the gap and not the mechanism: the very next run with
 * new mail reopened it.
 *
 * The rule here instead ties the ceiling to the ONE fact that makes the band
 * provably empty: the historical walk must own everything up to where the
 * forward walk genuinely resumes from. `forwardFloorUid` is that point minus
 * one — the last UID the forward pass will NOT fetch on the next run.
 *
 * Why this cannot rewind or thrash
 * --------------------------------
 *   - It only ever RAISES: `Math.max` against the prior ceiling. A ceiling that
 *     could fall would re-open `completed_at` on a finished walk and, worse,
 *     let `backfilled_through_uid` sit above its own target.
 *   - It never touches `backfilled_through_uid`. Progress through the mailbox
 *     (~150k UIDs on the live instance) is preserved exactly; raising a ceiling
 *     adds `new - old` UIDs of work and re-walks nothing already done.
 *   - It is bounded per run. The ceiling rises to a watermark the mailbox
 *     already passed, never to a live `uidnext` that moves while we walk, so
 *     the walk converges on a fixed target instead of chasing the mailbox
 *     forever. Termination is preserved: each run consumes a bounded page and
 *     the ceiling only gains the UIDs that arrived since the last run.
 */
export declare function resolveMessagesBackfillTargetUid(args: {
    forwardFloorUid: number;
    prior: MessagesBackfillCursor;
}): number;
export declare function advanceMessagesBackfillCursor(args: {
    now: string;
    pageEndUid: number;
    /**
     * The cursor for this run, whose `target_uid` is the ceiling already raised
     * to meet the forward watermark by `resolveMessagesBackfillTargetUid`. The
     * ceiling is read from here rather than passed separately so there is exactly
     * one source of truth for it.
     */
    prior: MessagesBackfillCursor;
}): Required<MessagesBackfillCursor>;
export declare function isAttachmentBackfillRequested(streamsToBackfill: readonly string[] | undefined): boolean;
/**
 * Historical attachment backfill should run when the operator asked for it or
 * when the runtime hands the connector pending attachment detail gaps. The
 * latter is the recovery-first seam: durable attachment backlog should not
 * look healthy just because the ordinary messages cursor is current.
 */
export declare function shouldBackfillAttachments(args: {
    detailGaps?: readonly DetailGapStartEntry[] | undefined;
    streamsToBackfill?: readonly string[] | undefined;
}): boolean;
export declare function selectAttachmentBackfillFetchRange(session: {
    attachmentBackfill: AttachmentAllMailCursor;
    maxWindowUids?: number;
    priorUidnext: number;
}): string | null;
export declare function resolveAttachmentBackfillWindowUids(env?: NodeJS.ProcessEnv): number;
export declare const ATTACHMENT_BACKFILL_PAGE_MIN_BYTES: number;
export declare const ATTACHMENT_BACKFILL_PAGE_DEFAULT_BYTES: number;
export declare const ATTACHMENT_BACKFILL_PAGE_MAX_BYTES: number;
export declare const ATTACHMENT_RECOVERY_PAGE_DEFAULT_BYTES: number;
/**
 * Fixed conservative per-UID cost used only when BODYSTRUCTURE reported no
 * usable attachment size. Not learned or updated — a single documented
 * fallback, chosen above the ordinary attachment-metadata overhead so a run
 * of unknown-size UIDs still forms a small, bounded page rather than an
 * unbounded one.
 */
export declare const ATTACHMENT_BACKFILL_UNKNOWN_SIZE_FALLBACK_BYTES: number;
export declare function attachmentBackfillPageByteBudget(configuredTargetBytes?: number): number;
export declare function resolveAttachmentBackfillPageByteBudget(env?: NodeJS.ProcessEnv): number;
/**
 * Resolve the served-recovery byte budget without coupling it to ordinary
 * forward backfill. The legacy backfill variable continues to override both
 * lanes until an operator opts into the recovery-specific variable.
 */
export declare function resolveAttachmentRecoveryPageByteBudget(env?: NodeJS.ProcessEnv): number;
/**
 * One UID's attachment byte cost, for page-size planning. `attachmentBytes`
 * is precomputed by the caller as: 0 for a UID with no attachments (a
 * no-attachment message must not consume the unknown-size fallback, or an
 * ordinary window of plain messages would starve to a handful admitted per
 * page); otherwise the sum of each attachment's known `size_bytes`, with
 * `ATTACHMENT_BACKFILL_UNKNOWN_SIZE_FALLBACK_BYTES` substituted per
 * attachment whose size is unavailable (never dropped, so a mix of known
 * and unknown attachment sizes is not underestimated).
 */
export interface AttachmentBackfillCandidate {
    readonly attachmentBytes: number;
    readonly uid: number;
}
export interface ServedAttachmentRecoverySummary {
    admitted: number;
    admitted_bytes: number;
    attachment_hydration_failure_outcome: AttachmentHydrationFailureOutcome;
    attempted: number;
    hydration_failed: number;
    lookup_miss: number;
    metadata_lookups: number;
    recovered: number;
    run_cap_deferred: number;
    served: number;
}
interface AttachmentHydrationFailureOutcome {
    blob_upload_http_4xx: number;
    blob_upload_http_5xx: number;
    blob_upload_integrity_failed: number;
    blob_upload_invalid_response: number;
    blob_upload_transport_failed: number;
    imap_download_failed: number;
    unclassified_failed: number;
}
type GmailMessageLookupClient = Pick<ImapFlow, "search" | "fetchOne">;
type GmailAttachmentBackfillClient = GmailMessageLookupClient & Pick<ImapFlow, "fetch">;
/**
 * Trim a candidate list — MUST already be sorted ascending by UID by the
 * caller; this function trusts array order and does not re-sort, so an
 * out-of-order input silently produces a wrong prefix — to a byte-cost
 * page: keep admitting candidates in order while the running total of
 * attachment bytes stays within budget, but always admit at least one
 * candidate (mirrors `trimDetailGapPageToByteBudget`'s at-least-one-entry
 * rule) so a single oversized attachment cannot block all backfill
 * progress. Returns a PREFIX COUNT, not a UID value or set, so the caller
 * derives the admitted page positionally (`candidates.slice(0, admittedCount)`)
 * rather than by comparing UIDs — immune to UID gaps.
 */
export declare function trimAttachmentBackfillPageToByteBudget(candidates: readonly AttachmentBackfillCandidate[], byteBudget: number): {
    admittedCount: number;
    estimatedBytesTotal: number;
};
export declare function recoverServedAttachmentGaps(client: GmailMessageLookupClient, deps: {
    attachmentCoverage?: AttachmentDetailCoverage;
    detailGaps?: readonly DetailGapStartEntry[] | undefined;
    emitProtocol: (msg: EmittedMessage) => Promise<void>;
    emitRecord: EmitRecordFn;
    hydrateAttachment: HydrateAttachmentFn;
    recoveredAttachmentGapIds?: Set<string>;
}): Promise<ServedAttachmentRecoverySummary>;
export declare function runAttachmentBackfillAndRecoveryPass(args: {
    allMail: ListResponse;
    attachmentBackfillRequested: boolean;
    attachmentCoverage: AttachmentDetailCoverage | undefined;
    client: GmailAttachmentBackfillClient;
    deps: AllMailDeps;
    fetchBodiesBound: FetchBodiesFn;
    hydrateAttachment: HydrateAttachmentFn;
    emit: (msg: EmittedMessage) => Promise<void>;
    recoveredAttachmentGapIds: Set<string>;
    recoveryOnly?: boolean;
    session: AllMailSession;
}): Promise<void>;
/**
 * Resolve the per-attachment max byte cap from env, falling back to the
 * conservative default. Non-positive or non-numeric overrides are ignored
 * so a misconfigured env var can never silently disable the cap.
 */
export declare function resolveMaxAttachmentBytes(env?: NodeJS.ProcessEnv): number;
/**
 * Raised when an attachment transfer goes silent (no chunk received) for
 * longer than the stall budget. The message deliberately contains "timeout"
 * so `isImapTransientError` (and `handleMainRejection`'s classification) marks
 * the resulting run failure retryable without a second keyword list to keep
 * in sync.
 */
export declare class AttachmentStallTimeoutError extends Error {
    constructor(stallMs: number, observedBytes: number);
}
/**
 * Resolve the attachment stall budget from env, falling back to the
 * conservative default. Non-positive or non-numeric overrides are ignored so
 * a misconfigured env var can never silently disable the guard.
 */
export declare function resolveAttachmentStallTimeoutMs(env?: NodeJS.ProcessEnv): number;
/** One in-transfer progress observation, bounded and pre-redacted at the
 *  source: no attachment id, filename, subject, sender, or content ever
 *  reaches this shape. `totalBytes` is present only when the source already
 *  reported a trusted expected size (BODYSTRUCTURE / IMAP FETCH metadata) —
 *  never inferred or guessed. */
export interface AttachmentTransferProgress {
    bytesTransferred: number;
    elapsedMs: number;
    phase: "transferring" | "complete";
    totalBytes: number | null;
}
export declare const DEFAULT_ATTACHMENT_PROGRESS_MIN_INTERVAL_MS = 15000;
export declare const DEFAULT_ATTACHMENT_PROGRESS_MIN_BYTES: number;
export declare function resolveAttachmentProgressMinIntervalMs(env?: NodeJS.ProcessEnv): number;
export declare function resolveAttachmentProgressMinBytes(env?: NodeJS.ProcessEnv): number;
/** Bounded, non-secret PROGRESS text for one in-transfer observation: phase,
 *  byte counters, and elapsed time only — matches
 *  `buildServedAttachmentRecoveryProgressMessage`'s shape for the same
 *  reason (a free-text `message` that a dashboard/log can render safely). */
export declare function buildAttachmentTransferProgressMessage(progress: AttachmentTransferProgress): string;
interface AttachmentHydratorArgs {
    connectorId: string;
    fetchAttachment: FetchAttachmentFn;
    maxBytes?: number;
    onStall?: () => void;
    onTransferProgress?: (progress: AttachmentTransferProgress) => void;
    progressMinBytes?: number;
    progressMinIntervalMs?: number;
    progressNow?: () => number;
    stallTimeoutMs?: number;
    uploadBlob: UploadAttachmentBlobFn;
}
/**
 * `onStall`: called at most once if a transfer stalls past `stallTimeoutMs`.
 * MUST make the connection backing `fetchAttachment`'s returned content
 * unusable (imapflow has no per-command cancel — see `fetchAttachmentPart`),
 * so the caller is expected to treat the whole run as ending after this
 * fires. Omitted in tests that don't exercise a real IMAP connection.
 *
 * `onTransferProgress`: cadence-gated in-transfer progress (see
 * `enforceTransferProgress`). Composed OUTSIDE the stall guard: cannot
 * affect stall timing, backpressure, or error propagation. Omitted entirely
 * in tests that don't exercise it — `enforceTransferProgress` is only
 * applied when this is provided, so a caller with no progress sink pays
 * zero extra wrapping.
 */
export declare function makeAttachmentHydrator(args: AttachmentHydratorArgs): HydrateAttachmentFn;
/**
 * Download one attachment PART's bytes.
 *
 * `expectedSize` is deliberately taken from BODYSTRUCTURE (`attachment.size_bytes`)
 * and NOT from the download response's `meta.expectedSize`.
 *
 * imapflow populates `meta.expectedSize` from the FETCH `RFC822.SIZE` item
 * (`lib/imap-flow.js`: `meta = { expectedSize: response.size }`, where `size`
 * is requested as the `RFC822.SIZE` atom in `lib/commands/fetch.js`).
 * RFC822.SIZE is the size of the ENTIRE MESSAGE — every part, every MIME
 * header, every boundary — not of the part being downloaded. It is the same
 * number for every part of a multipart message.
 *
 * Feeding a message-scoped size into a per-attachment cap made a message
 * reject ALL of its attachments whenever their SUM crossed the cap, even
 * though no single one came close. Observed live on the owner's mailbox:
 * 68 attachments marked `too_large` across 18 messages, of which only 2 were
 * genuinely over the 25 MiB cap; one 3,080-byte attachment was rejected as
 * "29830196 > 26214400 bytes". Two parts of one message recorded the byte-for-byte
 * identical "observed" size — impossible for real per-part sizes, and the tell
 * that the number was never the part's.
 *
 * That number is not just a wrong skip: `isProvenUnfillableGap`
 * (`server/connector-gap-classification.ts`) parses this exact
 * "exceeds max size: <observed> > <limit>" text as DURABLE PROOF that an item
 * is permanently uncollectable. A message-scoped size therefore manufactured
 * per-item impossibility proofs for items that are collectible, which is the
 * fabricated-evidence failure that predicate exists to refuse.
 *
 * BODYSTRUCTURE's per-part `size` is the only per-part size IMAP gives us
 * before transfer, so it is the only honest pre-flight number. When it is
 * absent we report `null` (unknown) rather than substituting a
 * message-scoped stand-in: `enforceMaxBytes` still counts real bytes
 * mid-stream, so an under-reported or missing size is caught by observation
 * instead of by a guess.
 */
export declare function fetchAttachmentPart(client: Pick<ImapFlow, "download">, msg: FetchMessageObject, attachment: AttachmentRecord): Promise<AttachmentDownload>;
export declare function validateAttachmentHydrationPreflight(args: {
    env?: NodeJS.ProcessEnv;
    detailGaps?: readonly DetailGapStartEntry[] | undefined;
    requested: Map<string, StreamRequest>;
    streamsToBackfill?: readonly string[] | undefined;
}): string | null;
/**
 * Emit flag/label changes for messages modified since `priorModseq`.
 *
 * The envelope is fetched alongside the flags. That is not an optimization —
 * it is what makes the pass safe. PDPP records are whole-document upserts
 * (`records` is keyed `UNIQUE(connector_instance_id, stream, record_key)` and
 * ingest replaces `record_json`), so emitting a partial `messages` record
 * overwrites the stored row rather than merging into it. An envelope-free
 * delta record therefore nulls `subject`, `from_email`, `date`, `size_bytes`,
 * and `snippet` on a message that had them, and sets `received_at` to the run
 * clock — silently destroying already-collected history every time a label or
 * a `\Seen` flag changes.
 *
 * A message whose envelope the server does not return is skipped rather than
 * emitted partially: losing a flag update is recoverable on the next pass,
 * losing the envelope is not.
 *
 * `fetchBodiesFn` is the same seam `processMessage` uses. Called with
 * `wantBodies: false` it fetches at most `SNIPPET_FETCH_MAX_BYTES` of the
 * plain part — enough to rebuild `snippet`, without touching the
 * externally-throttled full-body/attachment path.
 */
export declare function runDeltaPass(client: Pick<ImapFlow, "fetch">, session: AllMailSession, requested: Map<string, StreamRequest>, emitRecord: EmitRecordFn, receivedAtFallback: string, fetchBodiesFn: FetchBodiesFn): Promise<void>;
/**
 * Gate every aggregated thread through the shared fingerprint cursor and
 * emit only the records whose semantic shape moved since the prior run.
 * Pruning stale ids is the caller's responsibility — `runThreadsPass`
 * receives one bounded UID range per scheduled run. Threads with empty ids are
 * silently dropped: the upstream IMAP loop already filters them. The caller
 * deliberately does not prune stale fingerprints on bounded pages; pruning is
 * only sound after the historical high-water boundary is complete.
 *
 * Exported so the two-pass churn invariant can be exercised without
 * standing up an IMAP fixture.
 */
export declare function emitChangedThreads(aggregates: Iterable<ThreadAggregate>, cursor: FingerprintCursor, emitRecord: EmitRecordFn): Promise<void>;
/**
 * Parse the prior `threads` STATE cursor's `thread_fingerprints` map.
 * Tolerant of:
 *   - missing/legacy cursors (no fingerprints field)
 *   - malformed entries (non-string values silently dropped)
 *   - state from a different schema (best-effort coercion)
 * The returned map is always safe to read; on legacy input it is empty
 * and the next run re-emits every thread once (the normal one-time
 * cost of the cursor's introduction).
 */
export declare function readPriorThreadFingerprints(state: Record<string, unknown>): Map<string, string>;
interface AllMailDeps {
    detailGaps?: readonly DetailGapStartEntry[] | undefined;
    emitRecord: EmitRecordFn;
    emittedAt: string;
    recoveryOnly?: boolean;
    requested: Map<string, StreamRequest>;
    streamsToBackfill?: readonly string[] | undefined;
}
type GmailAllMailClient = GmailAttachmentBackfillClient & Pick<ImapFlow, "close" | "download" | "mailbox">;
/**
 * Drive Pass 1 (new messages or full resync), Pass 2 (flag/label deltas),
 * threads aggregation, and the final STATE emit — all inside the mailbox
 * lock. The list-mailbox lookup happens in `main()` before entering here.
 */
export declare function runAllMailPasses(client: GmailAllMailClient, allMail: ListResponse, state: Record<string, unknown>, deps: AllMailDeps): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map