import { z } from "zod";
export declare const messagesSchema: z.ZodObject<{
    id: z.ZodString;
    thread_id: z.ZodString;
    subject: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    from_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    from_email: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    to: z.ZodArray<z.ZodObject<{
        name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        email: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>;
    cc: z.ZodArray<z.ZodObject<{
        name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        email: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>;
    bcc: z.ZodArray<z.ZodObject<{
        name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        email: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>;
    reply_to: z.ZodArray<z.ZodObject<{
        name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        email: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>;
    date: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    received_at: z.ZodString;
    message_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    in_reply_to: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    references: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    labels: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    is_draft: z.ZodBoolean;
    is_flagged: z.ZodBoolean;
    is_seen: z.ZodBoolean;
    is_answered: z.ZodBoolean;
    has_attachments: z.ZodBoolean;
    snippet: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
export declare const threadsSchema: z.ZodObject<{
    id: z.ZodString;
    subject: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    participant_emails: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    message_count: z.ZodNumber;
    first_message_date: z.ZodString;
    last_message_date: z.ZodString;
    labels: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    unread_count: z.ZodNumber;
    flagged_count: z.ZodNumber;
    has_attachments: z.ZodBoolean;
}, z.core.$strip>;
export declare const labelsSchema: z.ZodObject<{
    name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    canonical_name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    is_system: z.ZodBoolean;
    parent_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    message_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const messageBodiesSchema: z.ZodObject<{
    id: z.ZodString;
    message_id: z.ZodString;
    body_text: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body_html: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body_text_bytes: z.ZodNullable<z.ZodNumber>;
    body_html_bytes: z.ZodNullable<z.ZodNumber>;
    body_source: z.ZodEnum<{
        empty: "empty";
        html_stripped: "html_stripped";
        text_html: "text_html";
        text_plain: "text_plain";
    }>;
    content_languages: z.ZodNull;
    charset: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    message_received_at: z.ZodString;
}, z.core.$strip>;
export declare const attachmentsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    message_id: z.ZodString;
    filename: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    content_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    content_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    is_inline: z.ZodBoolean;
    encoding: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    part_index: z.ZodString;
    message_received_at: z.ZodString;
    blob_ref: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
    content_sha256: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    hydration_status: z.ZodOptional<z.ZodEnum<{
        deferred: "deferred";
        failed: "failed";
        hydrated: "hydrated";
        too_large: "too_large";
    }>>;
    hydration_error: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
}, z.core.$strip>;
/**
 * Map stream name → schema. Single source of truth for what streams this
 * connector produces at shape-check time.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map