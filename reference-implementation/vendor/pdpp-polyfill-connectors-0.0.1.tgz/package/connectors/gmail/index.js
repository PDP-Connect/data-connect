#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * PDPP Gmail Connector (v0.1.0)
 *
 * Uses IMAP + Google app-specific password. Iterates [Gmail]/All Mail so
 * messages with multiple labels aren't multi-counted. Derives label
 * membership from X-GM-LABELS per message.
 *
 * Auth:
 *   GOOGLE_APP_PASSWORD_PDPP or GMAIL_APP_PASSWORD — app password
 *   GMAIL_ADDRESS or GMAIL_USER                    — the account's email;
 *                                                    if missing, emits
 *                                                    INTERACTION kind=credentials.
 *
 * Streams: messages, threads, labels, attachments.
 *
 * State shape:
 *   {
 *     all_mail: { uidvalidity: N, uidnext: N, highest_modseq: N }
 *   }
 *
 * Rate budget: keep to one concurrent connection; fetch in windows of 200.
 */
import { createInterface, } from "node:readline";
import { isMainModule, requireCredentialsOrAsk, resourceSet, stringifyForJsonl, } from "@pdpp/connector-protocol";
import { ImapFlow, } from "imapflow";
import { flushAndExitAfterRuntimeAck } from "../../src/connector-exit.js";
import { buildDetailCoverageMessage, buildDetailGap, buildFullScanCoverageMessage, describeUnexpectedFailure, } from "../../src/connector-runtime.js";
import { openFingerprintCursor, } from "../../src/fingerprint-cursor.js";
import { makeReferenceBlobUploader as makeSharedReferenceBlobUploader, ReferenceBlobUploadFailure, runtimeBlobUploadAvailable as sharedRuntimeBlobUploadAvailable, } from "../../src/reference-blob-uploader.js";
import { isImapTransientError } from "./imap-error-classification.js";
import { bigintToCursor, bigintToNumber, buildMessageBodyRecord, buildMessageRecord, buildThreadRecord, canonicalBodyBlobCandidates, canonicalLabelName, decodeBodyPart, decodeBodystructureForAttachments, envelopeParticipants, isGmailSystemLabel, isInTimeRange, labelParentName, makeSnippet, SNIPPET_MAX_CHARS, sanitizeForJsonl, selectBodyParts, toFlagsArray, toLabelsArray, updateThreadAggregate, } from "./parsers.js";
import { validateRecord } from "./schemas.js";
// ─── Module-scoped regexes (Biome useTopLevelRegex) ─────────────────────
const EMAIL_AT_RE = /@/;
// Splits an address into [local-part, domain] for progress redaction. Only the
// last `@` is treated as the domain delimiter so quoted local-parts that embed
// an `@` still redact (the domain is whatever follows the final `@`).
const EMAIL_SPLIT_RE = /^(.*)@([^@]+)$/;
// ─── Constants ──────────────────────────────────────────────────────────
const FETCH_HEADER_BATCH_PROGRESS = 1000;
const SNIPPET_FETCH_MAX_BYTES = 4096;
const ERROR_MSG_TAIL = 400;
const DEFAULT_CRED_TIMEOUT_S = 1800;
const DEFAULT_GMAIL_CONNECTOR_ID = "https://registry.pdpp.dev/connectors/gmail";
const HYDRATION_ERROR_MAX_CHARS = 240;
const DEFAULT_ATTACHMENT_MIME_TYPE = "application/octet-stream";
// The blob endpoint's own media-type grammar (`rs-blobs-upload`'s
// `MEDIA_TYPE_PATTERN`): a bare `type/subtype`, no wildcard, no empty half.
// Mirrored here so a value that endpoint would reject with a 400 is replaced
// BEFORE the request rather than after — see `normalizeAttachmentMimeType`.
const VALID_MEDIA_TYPE_PATTERN = /^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/i;
const BLOB_UPLOAD_ENV_ERROR = "blob upload unavailable: PDPP_RS_URL and PDPP_OWNER_TOKEN must be provided by the runtime";
// Conservative default chosen to align with Gmail's per-message attachment
// cap (25 MiB). Operators can raise/lower with PDPP_GMAIL_MAX_ATTACHMENT_BYTES;
// the value is enforced both before download (when source size is known) and
// while streaming bytes (defense against under-reported sizes).
export const DEFAULT_MAX_ATTACHMENT_BYTES = 25 * 1024 * 1024;
const MAX_ATTACHMENT_BYTES_ENV = "PDPP_GMAIL_MAX_ATTACHMENT_BYTES";
const POSITIVE_INTEGER_PATTERN = /^\d+$/;
export const DEFAULT_ATTACHMENT_BACKFILL_WINDOW_UIDS = 500;
const ATTACHMENT_BACKFILL_WINDOW_UIDS_ENV = "PDPP_GMAIL_ATTACHMENT_BACKFILL_WINDOW_UIDS";
// Live-incident floor (gmail-attachment-convergence-0809): sustained Gmail
// IMAP attachment-transfer throughput measured at ~4.65 KB/s across four
// different attachment sizes over a 2-hour window (general HTTPS from the
// same host hit 22 MB/s; TLS handshake to imap.gmail.com was instant), so the
// bottleneck is IMAP-side, not this codebase's network path. 90s of true
// silence is generous headroom above the inter-chunk gaps a merely-slow (not
// wedged) transfer at that floor rate produces, while still bounding a truly
// stuck FETCH to a fraction of the run's cadence window.
export const DEFAULT_ATTACHMENT_STALL_TIMEOUT_MS = 90_000;
const ATTACHMENT_STALL_TIMEOUT_MS_ENV = "PDPP_GMAIL_ATTACHMENT_STALL_TIMEOUT_MS";
// ─── Stdin / stdout plumbing ────────────────────────────────────────────
// Readline interface for stdin. Initialized inside the isMainModule guard
// at the bottom of the file so importing index.ts from tests doesn't
// open stdin and keep the Node event loop alive.
let rl = null;
function getReadline() {
    if (!rl) {
        rl = createInterface({ input: process.stdin, terminal: false });
    }
    return rl;
}
// Track in-flight writes so back-pressured, partial stdout writes can't
// produce interleaved or truncated JSONL lines on the runtime side. Bodies
// on the `message_bodies` stream can exceed 200 KB each, which is well
// above the default pipe buffer (~64 KB on Linux). A blocking write alone
// isn't enough: Node returns `false` from write() without sending any
// bytes on a full pipe, and the caller must wait for 'drain' before the
// next write.
//
// Gmail uses `sanitizeForJsonl` (parsers.ts) to scrub lone surrogates and
// control chars out of body text before encoding. The JSONL encoding
// itself — BigInt coercion + U+2028/U+2029 escaping — lives in
// `stringifyForJsonl`.
// DONE is terminal on the wire, and nothing below this line may write after
// it. The runtime's `handleMsg` latches the first DONE of any status and
// throws `Connector emitted <TYPE> after DONE` on the next message, failing
// the whole run as a protocol violation.
//
// Enforcing that here rather than at each terminal path is deliberate: the
// terminal paths do not stop this process. `flushAndExit` only registers
// listeners and returns (see `connector-exit.ts` — it waits for the runtime
// to close stdin, up to 30 minutes), so after `fail()` or a rejection
// handler emits DONE, the interrupted work is still on the stack. An
// in-flight `for await` over an IMAP FETCH keeps iterating and keeps calling
// `emitRecord`, and each of those writes lands after the DONE.
//
// That is what production hit: gmail runs failed `connector_protocol_violation
// "Connector emitted RECORD after DONE"` while reporting more records emitted
// than the runtime ever flushed — the surplus was written into a channel that
// had already closed. Making every terminal path unwind perfectly would be a
// standing obligation on code that mostly cannot see it coming; making the
// write refuse is a property of the channel.
//
// Suppressed messages go to stderr, so a swallowed record is diagnosable
// rather than silent. Emitting them would fail the run outright, which is
// strictly worse: the records ingested before DONE are durable and the run's
// own terminal status is already decided.
let doneEmitted = false;
function emit(msg) {
    if (doneEmitted) {
        process.stderr.write(`[gmail] suppressed ${String(msg.type)} after DONE\n`);
        return Promise.resolve();
    }
    if (msg.type === "DONE") {
        doneEmitted = true;
    }
    const line = stringifyForJsonl(sanitizeForJsonl(msg));
    const ok = process.stdout.write(line);
    if (ok) {
        return Promise.resolve();
    }
    return new Promise((resolve) => {
        process.stdout.once("drain", () => {
            resolve();
        });
    });
}
/** Test-only reset of the terminal latch; the real process never reuses it. */
export function __resetDoneLatchForTests() {
    doneEmitted = false;
}
/** Test-only handle on the real stdout emitter, so the latch is exercised
 *  through the same function every production path writes through. */
export function gmailEmitForTests(msg) {
    return emit(msg);
}
function flushAndExit(code) {
    flushAndExitAfterRuntimeAck(code);
}
function fail(m, retryable = false) {
    emit({
        type: "DONE",
        status: "failed",
        records_emitted: 0,
        error: { message: m, retryable },
    }).catch(() => undefined);
    flushAndExit(1);
}
const nowIso = () => new Date().toISOString();
let interactionCounter = 0;
function nextInteractionId() {
    interactionCounter += 1;
    return `int_${Date.now()}_${interactionCounter}`;
}
// Block on stdin until we receive INTERACTION_RESPONSE matching request_id.
async function sendInteractionAndWait(msg) {
    await emit(msg);
    const reqId = msg.request_id;
    const reader = getReadline();
    return new Promise((resolve, reject) => {
        const onLine = (line) => {
            try {
                const parsed = JSON.parse(line);
                if (parsed.type === "INTERACTION_RESPONSE" &&
                    parsed.request_id === reqId) {
                    reader.off("line", onLine);
                    resolve(parsed);
                }
            }
            catch (err) {
                reject(err instanceof Error ? err : new Error(String(err)));
            }
        };
        reader.on("line", onLine);
    });
}
// Clock-dependent ISO conversion — lives here because the fallback reaches
// for wall-clock time. Pure-date conversion is inlined in parsers.ts tests.
function internalDateToIso(date) {
    if (!date) {
        return nowIso();
    }
    return new Date(date).toISOString();
}
// ─── Startup: credentials + scope ───────────────────────────────────────
/** Progress cadence for the body pass — emit a PROGRESS message every N
 *  processed rows. Exported so the extraction preserves observable
 *  behavior; tests rely on the boundary. */
export const FETCH_MSG_PROGRESS = 500;
/**
 * A `failed` hydration's stage, if known, else the same `unclassified_failed`
 * bucket already used by `attachment_hydration_failure_outcome` telemetry.
 * This is the ONLY hydration-failure detail that ever reaches a DETAIL_GAP:
 * a bounded category, never `AttachmentRecord.hydration_error` (raw IMAP/blob
 * text that can embed hostnames, tokens, or URLs — see
 * `buildAttachmentDetailGap`'s doc comment on why that string never crosses).
 */
function attachmentHydrationFailureClass(failure) {
    return failure?.stage ?? "unclassified_failed";
}
export function createAttachmentBackfillSummary() {
    return {
        failed: 0,
        hydrated: 0,
        remaining_historical_gaps: 0,
        too_large: 0,
        unavailable_skipped: 0,
    };
}
export function addAttachmentBackfillRecordToSummary(summary, data) {
    switch (data.hydration_status) {
        case "hydrated":
            summary.hydrated += 1;
            break;
        case "too_large":
            summary.too_large += 1;
            summary.remaining_historical_gaps += 1;
            break;
        case "failed":
            summary.failed += 1;
            summary.remaining_historical_gaps += 1;
            break;
        case "deferred":
            summary.unavailable_skipped += 1;
            summary.remaining_historical_gaps += 1;
            break;
        default:
            summary.unavailable_skipped += 1;
            summary.remaining_historical_gaps += 1;
            break;
    }
}
export function formatAttachmentBackfillSummary(summary) {
    return [
        `hydrated=${summary.hydrated}`,
        `too_large=${summary.too_large}`,
        `failed=${summary.failed}`,
        `unavailable_skipped=${summary.unavailable_skipped}`,
        `remaining_historical_gaps=${summary.remaining_historical_gaps}`,
    ].join(" ");
}
/** Fresh, empty accumulator for one attachments detail pass. */
export function makeAttachmentDetailCoverage() {
    return { failedRecords: [], gapKeys: [], hydratedKeys: [], requiredKeys: [] };
}
/**
 * Record one attempted attachment hydration into the coverage accumulator by
 * its terminal `hydration_status`. A `deferred` status (never hydrated this
 * run) is still a considered key but has no terminal outcome bucket, so it
 * counts only toward the denominator. Pure: mutates the passed accumulator.
 *
 * `failure` is the same `AttachmentHydrationFailure | null` the hydrator
 * already computes for aggregate telemetry — passed through here so a
 * `failed` outcome's DETAIL_GAP can carry a bounded, non-secret `error.class`
 * instead of recording an attempt with no evidence of why it failed.
 */
export function recordAttachmentCoverage(coverage, record, failure = null) {
    // The runtime rejects a DETAIL_COVERAGE whose required_keys repeats a key.
    // The same attachment id can legitimately reach this accumulator twice in a
    // run -- a message re-observed across pages, or a retry re-walking a
    // partially hydrated thread -- so pushing unconditionally turns an ordinary
    // duplicate observation into a hard run failure ("invalid
    // DETAIL_COVERAGE.required_keys: duplicate key"), which is what took Gmail
    // out on 2026-08-17. Record each key once; the terminal-outcome buckets
    // below are already keyed by the same id and stay consistent with it.
    if (coverage.requiredKeys.includes(record.id)) {
        return;
    }
    coverage.requiredKeys.push(record.id);
    switch (record.hydration_status) {
        case "hydrated":
            coverage.hydratedKeys.push(record.id);
            return;
        case "failed":
            coverage.gapKeys.push(record.id);
            // Retain the record so a matching DETAIL_GAP is emitted for this key.
            // `gap_keys` on DETAIL_COVERAGE are not enough on their own: the host
            // commit-gate requires a durable pending DETAIL_GAP to credit the key.
            coverage.failedRecords.push({
                failureClass: attachmentHydrationFailureClass(failure),
                record,
            });
            return;
        case "too_large":
        case "deferred":
            // Unaccounted: required-only outcomes that stay in denominator but no
            // outcome bucket. too_large is a deployment cap (may change); deferred is
            // not attempted this run. Neither justifies permanent skip or gap claim.
            return;
        default: {
            const unhandledStatus = record.hydration_status;
            throw new Error(`Unhandled attachment hydration status: ${unhandledStatus}`);
        }
    }
}
/**
 * Build the per-run attachments DETAIL_COVERAGE after the detail lane settles.
 * The list cursor that anchors this detail pass lives on `messages`, so that is
 * the `state_stream`.
 * Reference-only: this reuses DETAIL_COVERAGE without promoting it to portable
 * protocol.
 *
 * Extracted from `emitAttachmentDetailCoverage` so the zero-attachment case is
 * testable without capturing process stdout.
 */
export function buildAttachmentDetailCoverageMessage(coverage) {
    return buildDetailCoverageMessage({
        stream: "attachments",
        stateStream: "messages",
        requiredKeys: coverage.requiredKeys,
        hydratedKeys: coverage.hydratedKeys,
        gapKeys: coverage.gapKeys,
        considered: coverage.requiredKeys.length,
        covered: coverage.hydratedKeys.length,
    });
}
/**
 * Whether this run walked a boundary that can support an attachments coverage
 * claim at all.
 *
 * `attachments` has no enumeration of its own: an attachment is only ever
 * discovered by decoding the BODYSTRUCTURE of a message the run already
 * fetched. Its denominator is therefore inherited from whatever slice of the
 * mailbox the run walked — and on an ordinary scheduled run that slice is the
 * incremental forward window plus the MODSEQ delta, i.e. a CHANGE FEED, not an
 * inventory.
 *
 * That is exactly the apple_contacts `contactsBoundaryEstablished` situation
 * (`connectors/apple_contacts/index.ts`), and it needs the same answer. A quiet
 * 16-minute run that observes no new mail decodes no attachment parts and would
 * otherwise emit `considered: 0, covered: 0` — numbers that are trivially
 * self-consistent and read downstream as "this stream is proven complete",
 * when the honest statement is "this run proved nothing about the mailbox".
 * Worse, the two are indistinguishable to the gate: a stream that has walked
 * almost nothing and a stream that is genuinely fully collected emit the
 * identical fact. Withholding is what keeps those two apart.
 *
 * The one boundary that does justify a whole-stream claim is a COMPLETED
 * historical `messages` walk: the historical pass fetches every UID below the
 * forward floor and `processMessage` decodes attachments for each one, so once
 * `messages.backfill.completed_at` is set, every message in All Mail has had
 * its attachment parts enumerated. Until then the mailbox below the resume
 * point is simply unwalked, and no count taken above it describes it.
 *
 * Emitting nothing leaves the stream honestly unproven (the coherence
 * contract's `checkpoint_only`/`no_proof_strategy` -> axis `unknown`) rather
 * than falsely complete. `unknown` is a worse-looking verdict than a green
 * `0/0` and that is the point: it is the true one, and it is the verdict an
 * owner can act on.
 */
export function attachmentsCoverageBoundaryEstablished(session) {
    return (typeof session.messagesBackfill.completed_at === "string" &&
        session.messagesBackfill.completed_at !== "");
}
/**
 * Emit the per-run attachments DETAIL_COVERAGE after the detail lane settles —
 * but only when the run established a boundary that can support the claim
 * (see `attachmentsCoverageBoundaryEstablished`).
 *
 * Extracted from `runAllMailPasses` to keep that orchestrator under the
 * cognitive-complexity ceiling (authoring guide §"Rules the tooling enforces").
 */
async function emitAttachmentDetailCoverage(coverage, boundaryEstablished) {
    if (!coverage) {
        return;
    }
    if (!boundaryEstablished) {
        // Deliberately not a SKIP_RESULT: nothing was skipped by policy. The run
        // simply has no denominator worth reporting, and says so by staying quiet.
        await emit({
            type: "PROGRESS",
            stream: "attachments",
            message: "Withholding attachments coverage: the historical messages walk has not completed, so this run's attachment counts describe an incremental window, not the mailbox",
        });
        return;
    }
    await emit(buildAttachmentDetailCoverageMessage(coverage));
}
/**
 * Build the recoverable DETAIL_GAP for one failed attachment hydration.
 *
 * Every attachment that lands in `DETAIL_COVERAGE.gap_keys` (hydration_status
 * `failed`) needs a matching durable DETAIL_GAP: the host commit-gate credits a
 * missing required key only when it is hydrated, optional-skipped, or backed by
 * a pending DETAIL_GAP — `gap_keys` on their own are not enough, so without this
 * a successful run that failed even one attachment aborts at commit and the
 * messages cursor never advances, re-fetching the same window every run.
 *
 * `record_key` is the attachment `id` (`<X-GM-MSGID>:<part_index>`), the exact
 * value already in `gap_keys`, so the gate matches one-to-one. `reason` is
 * `temporary_unavailable` (retryable): the `failed` bucket mixes transient
 * download/network/parse errors with no exhaustion signal, mirroring Amazon's
 * order-detail gap; retrying next run is the honest, non-destructive default.
 *
 * Reference-only and bounded: only opaque message and part identifiers cross
 * (X-GM-MSGID, the BODYSTRUCTURE part index, and the attachment id), plus —
 * when `failureClass` is supplied — a bounded, non-secret failure category
 * (e.g. `imap_download_failed`, `blob_upload_http_5xx`, `unclassified_failed`;
 * see `attachmentHydrationFailureClass`). No filename, content, blob bytes,
 * raw error text, tokens, cookies, URLs, request bodies, or payload snippets
 * are ever carried — `AttachmentRecord.hydration_error` (which CAN embed
 * that raw text) never crosses this boundary, by construction: only the
 * caller-supplied category string can reach `error.class`.
 *
 * Without a failure class, a repeatedly-retried gap accrues `attempt_count`
 * on every run but never records why it keeps failing — `last_error_json`
 * stays null forever, which is indistinguishable from "never attempted" and
 * blocks the stream from ever proving its remaining gaps are impossible
 * (2026-08 Gmail: 5 `attachments` gaps reached terminal status with 37-117
 * attempts and a permanently-null `last_error_json`).
 */
export function buildAttachmentDetailGap(attachment, failureClass) {
    return buildDetailGap({
        stream: "attachments",
        parentStream: "messages",
        recordKey: attachment.id,
        reason: "temporary_unavailable",
        locator: {
            kind: "gmail.attachment_detail",
            message_id: attachment.message_id,
            part_index: attachment.part_index,
            attachment_id: attachment.id,
        },
        ...(failureClass ? { error: { class: failureClass } } : {}),
    });
}
/**
 * Build the recoverable DETAIL_GAP for one message whose body fetch THREW.
 *
 * Why this exists: `message_bodies` has a `body_source: "empty"` enum value,
 * and before this gap a failed fetch and a genuinely bodyless message produced
 * the identical record. The messages walk then advanced the UID cursor to live
 * `uidnext` either way, so the real body sat behind the cursor and was never
 * refetched — while the stream read complete to the owner. A schema-valid
 * record is not the same as an honest one.
 *
 * `record_key` is the X-GM-MSGID, the `message_bodies` primary key, so a later
 * run can refetch exactly this body. The locator carries the IMAP `uid` too,
 * but only as a hint: a UID is meaningful only inside one UIDVALIDITY epoch,
 * whereas X-GM-MSGID is stable across epochs. The message id is therefore the
 * authoritative half, and the UID merely saves a lookup when the epoch has not
 * rolled — which is why the gap stays valid even if it does.
 *
 * `reason` is `temporary_unavailable` (retryable): a thrown BODY[...] fetch
 * mixes transient network/IMAP faults with no exhaustion signal, exactly like
 * the attachments gap above, so retrying next run is the honest default.
 *
 * Bounded and reference-only: only opaque identifiers plus the connector-chosen
 * failure class cross. No body bytes, subject, sender, filename, raw error
 * text, tokens, or URLs.
 */
export function buildMessageBodyDetailGap(params) {
    const { gmMsgid, uid, failureClass } = params;
    return buildDetailGap({
        stream: "message_bodies",
        parentStream: "messages",
        recordKey: gmMsgid,
        reason: "temporary_unavailable",
        locator: {
            kind: "gmail.message_body_detail",
            message_id: gmMsgid,
            ...(typeof uid === "number" ? { uid } : {}),
        },
        ...(failureClass ? { error: { class: failureClass } } : {}),
    });
}
function normalizeAttachmentRecoveryKey(recordKey) {
    if (recordKey == null) {
        return null;
    }
    const key = String(recordKey).trim();
    return key.length > 0 ? key : null;
}
function attachmentDetailGapMatches(gap, attachment, normalizedAttachmentKey) {
    if (gap.stream !== "attachments" || gap.status !== "pending") {
        return false;
    }
    if (normalizeAttachmentRecoveryKey(gap.record_key) !== normalizedAttachmentKey) {
        return false;
    }
    const locator = gap.detail_locator;
    if (!locator || typeof locator !== "object" || Array.isArray(locator)) {
        return true;
    }
    const typedLocator = locator;
    if (typedLocator.kind !== "gmail.attachment_detail") {
        return false;
    }
    if (typedLocator.attachment_id != null &&
        typedLocator.attachment_id !== attachment.id) {
        return false;
    }
    if (typedLocator.message_id != null &&
        typedLocator.message_id !== attachment.message_id) {
        return false;
    }
    if (typedLocator.part_index != null &&
        typedLocator.part_index !== attachment.part_index) {
        return false;
    }
    return true;
}
function findRecoveredAttachmentDetailGaps(detailGaps, attachment, recoveredGapIds) {
    const normalizedAttachmentKey = normalizeAttachmentRecoveryKey(attachment.id);
    if (!(normalizedAttachmentKey && Array.isArray(detailGaps)) ||
        detailGaps.length === 0) {
        return [];
    }
    const matches = [];
    for (const gap of detailGaps) {
        if (!gap || recoveredGapIds.has(gap.gap_id)) {
            continue;
        }
        if (attachmentDetailGapMatches(gap, attachment, normalizedAttachmentKey)) {
            matches.push(gap);
        }
    }
    return matches;
}
async function emitAttachmentRecords(deps, msg, attachments) {
    if (!deps.requested.has("attachments") || attachments.length === 0) {
        return;
    }
    const recoveredAttachmentGapIds = deps.recoveredAttachmentGapIds ?? new Set();
    for (const a of attachments) {
        const hydration = await deps.hydrateAttachment(msg, a);
        const hydrated = hydration.record;
        // Record the outcome BEFORE emitting so the coverage denominator counts
        // every attempt even if the emit is scope-filtered downstream.
        if (deps.attachmentCoverage) {
            recordAttachmentCoverage(deps.attachmentCoverage, hydrated, hydration.failure);
        }
        const emitted = await deps.emitRecord("attachments", { ...hydrated });
        // Only `hydrated` may acknowledge a served gap as recovered. Unaccounted
        // statuses (too_large, deferred) have no durable DETAIL_GAP, so there is
        // nothing to recover.
        if (!emitted || hydrated.hydration_status !== "hydrated") {
            continue;
        }
        const recoveredGaps = findRecoveredAttachmentDetailGaps(deps.detailGaps, hydrated, recoveredAttachmentGapIds);
        for (const gap of recoveredGaps) {
            recoveredAttachmentGapIds.add(gap.gap_id);
            await deps.emitProtocol({
                type: "DETAIL_GAP_RECOVERED",
                reference_only: true,
                gap_id: gap.gap_id,
                record_key: hydrated.id,
                stream: "attachments",
            });
        }
    }
}
/**
 * Emit one DETAIL_GAP per failed attachment retained during the run, mirroring
 * `emitAttachmentDetailCoverage`. Emitted right after the coverage report and
 * before the messages STATE commits, so the gate sees every gap as durable when
 * it credits required keys. No-ops when nothing failed.
 */
async function emitAttachmentDetailGaps(coverage) {
    if (!coverage) {
        return;
    }
    for (const failed of coverage.failedRecords) {
        await emit(buildAttachmentDetailGap(failed.record, failed.failureClass));
    }
}
function perMessageInternalDateToIso(date, nowIsoFn) {
    if (!date) {
        return nowIsoFn();
    }
    return new Date(date).toISOString();
}
/**
 * Emit the `message_bodies` record for one message, and — when the body was NOT
 * actually captured — the durable gap that keeps it refetchable.
 *
 * Two distinct ways the body is not captured, both of which previously left an
 * advancing UID cursor and no trace at all:
 *
 *   - the fetch THREW (`bodies.fetchFailed`). The record emitted just above
 *     says `body_source: "empty"`, which is byte-identical to the record for a
 *     message that genuinely has no body. Schema-valid, and a lie.
 *   - `emitRecord` returned false — the record was schema-rejected (a
 *     SKIP_RESULT went out instead) or carried no key, so nothing landed.
 *
 * Either way the body stays retryable behind a pending DETAIL_GAP. A genuinely
 * empty body that emits cleanly gets NO gap: an empty message is not broken,
 * and marking every one of them would drown the real losses.
 *
 * Honoring `emitRecord === false` is possible here only because Gmail owns its
 * `makeEmitRecord`, which returns `Promise<boolean>`. The shared runtime's
 * `emitRecord` is `Promise<void>` and gives a caller nothing to branch on.
 */
async function emitMessageBody(deps, params) {
    const { bodies, gmMsgid, receivedAt, selection, uid } = params;
    const { bodyHtmlFull, bodyTextFull, fetchFailed, failureClass } = bodies;
    const bodyBlobCandidates = canonicalBodyBlobCandidates({
        bodyHtmlFull,
        bodyTextFull,
    });
    if (bodyBlobCandidates.length > 0 && !deps.uploadBodyBlob) {
        throw new Error("canonical Gmail body requires blob upload");
    }
    for (const candidate of bodyBlobCandidates) {
        await deps.uploadBodyBlob?.({
            content: [candidate.content],
            connectorId: process.env.PDPP_CONNECTOR_ID || DEFAULT_GMAIL_CONNECTOR_ID,
            jsonPath: candidate.jsonPath,
            mimeType: candidate.mimeType,
            recordKey: gmMsgid,
            stream: "message_bodies",
        });
    }
    const bodyEmitted = await deps.emitRecord("message_bodies", buildMessageBodyRecord({
        bodyHtmlFull,
        bodyTextFull,
        gmMsgid,
        htmlCharset: selection.htmlCharset,
        receivedAt,
        textCharset: selection.plainCharset,
    }));
    if (!(fetchFailed || bodyEmitted === false)) {
        return;
    }
    await deps.emitProtocol(buildMessageBodyDetailGap({
        gmMsgid,
        uid,
        failureClass: fetchFailed
            ? failureClass
            : "message_bodies_record_rejected",
    }));
}
/**
 * Emit the per-stream records for one Gmail message.
 *
 * Invariants (tested in integration.test.ts):
 *   1. No X-GM-MSGID → skip silently (return false).
 *   2. time_range filter skips out-of-range messages.
 *   3. Emit order within a single message: message_bodies → messages →
 *      attachments. The per-message order matters because downstream
 *      consumers rely on bodies being present before the messages row
 *      that references them.
 *   4. wantBodies / wantMessages / requested.has("attachments") each
 *      gate their own stream; disabling one doesn't suppress siblings.
 *   5. Body-fetch failure still emits the messages record with a null
 *      snippet — never silently drops the envelope — but ALSO emits a
 *      durable retryable DETAIL_GAP on `message_bodies`, so the body stays
 *      refetchable after the UID cursor advances past it. A genuinely
 *      bodyless message emits `body_source: "empty"` with no gap.
 *
 * Returns true if the message produced any emits (or would have, modulo
 * scope). Returns false when skipped by an early filter so the caller
 * can skip progress accounting.
 */
export async function processMessage(deps, msg) {
    // Gmail-specific IDs via imapflow: msg.emailId = X-GM-MSGID; msg.threadId = X-GM-THRID.
    const gmMsgid = String(msg.emailId ?? "");
    const gmThrid = String(msg.threadId ?? "");
    if (!gmMsgid) {
        if (deps.failOnError) {
            await emitHistoricalMessageSkip(deps, msg.uid);
        }
        return false;
    }
    const env = msg.envelope ?? {};
    const receivedAt = perMessageInternalDateToIso(msg.internalDate, deps.nowIso);
    if (!isInTimeRange(receivedAt, deps.timeRange)) {
        return false;
    }
    const dateHeader = env.date ? new Date(env.date).toISOString() : null;
    const flagsArr = toFlagsArray(msg.flags);
    const labels = toLabelsArray(msg.labels);
    const attachments = decodeBodystructureForAttachments(msg.bodyStructure, gmMsgid, receivedAt);
    const selection = selectBodyParts(msg.bodyStructure, deps.wantBodies);
    const { bodyHtmlFull, bodyTextFull, snippet, fetchFailed, failureClass } = await deps.fetchBodies(msg, selection, deps.wantBodies, deps.wantMessages);
    if (deps.wantBodies) {
        await emitMessageBody(deps, {
            bodies: {
                bodyHtmlFull,
                bodyTextFull,
                snippet,
                ...(fetchFailed ? { fetchFailed } : {}),
                ...(failureClass ? { failureClass } : {}),
            },
            gmMsgid,
            receivedAt,
            selection,
            uid: typeof msg.uid === "number" ? msg.uid : undefined,
        });
    }
    if (deps.wantMessages) {
        await deps.emitRecord("messages", buildMessageRecord({
            attachmentsCount: attachments.length,
            dateHeader,
            envelope: env,
            flagsArr,
            gmMsgid,
            gmThrid,
            labels,
            rawHeaders: msg.headers,
            receivedAt,
            sizeBytes: typeof msg.size === "number" ? msg.size : null,
            snippet,
        }));
    }
    await emitAttachmentRecords(deps, msg, attachments);
    return true;
}
/**
 * Phase B driver: iterate metas, emit records, report progress every
 * FETCH_MSG_PROGRESS rows. Per-message errors are logged to stderr and
 * swallowed so a single bad message doesn't halt the whole pass.
 */
export async function emitMessagesPass(deps, metas) {
    let count = 0;
    for (const msg of metas) {
        try {
            const processed = await processMessage(deps, msg);
            if (!processed) {
                continue;
            }
            count += 1;
            if (count % FETCH_MSG_PROGRESS === 0) {
                await deps.emitProgress({
                    type: "PROGRESS",
                    stream: "messages",
                    message: `Fetched ${count} messages`,
                    count,
                    total: metas.length,
                });
            }
        }
        catch (perMsgErr) {
            if (perMsgErr instanceof AttachmentStallTimeoutError) {
                // NOT an ordinary per-message failure: `onStall` has already closed
                // the shared IMAP connection (imapflow has no per-command cancel),
                // so every later command in this run — including the next message
                // in this very loop — would throw a confusing "connection closed"
                // error instead of the real cause. Propagate instead of swallowing
                // so the run ends cleanly through the normal uncaught-rejection path.
                throw perMsgErr;
            }
            if (deps.failOnError) {
                await emitHistoricalMessageSkip(deps, msg.uid);
                continue;
            }
            const emsg = perMsgErr instanceof Error
                ? (perMsgErr.stack ?? perMsgErr.message)
                : String(perMsgErr);
            process.stderr.write(`[gmail] per-message error at UID ${String(msg.uid)}: ${emsg}\n`);
            // Continue with next message; don't let one bad record halt the whole run.
        }
    }
    return { considered: metas.length, covered: count };
}
/**
 * Disclose the mailbox-wide inventory total against this run's walk boundary.
 *
 * Gmail's `messages` DETAIL_COVERAGE is deliberately PER-PAGE: the runtime's
 * `isHealthyBoundedContinuation` admits a bounded page only when
 * `considered === covered` on same-page facts, so the page denominator must
 * stay the page. Overwriting it with the mailbox-wide `EXISTS` would make every
 * run of a 140k-message mailbox read `partial` forever and would break the
 * continuation contract outright — a wrong denominator, not a better one.
 *
 * The honest place for the provider total is therefore a SEPARATE fact: the
 * server-declared inventory size, plus how much of the UID space this
 * connector's two cursors have actually claimed. `EXISTS` is validated
 * fail-closed in `validateExistsTotal` before this point, so a missing or
 * malformed total has already thrown and can never reach here as a silent
 * "complete". What this adds is visibility: the number the provider asserts,
 * next to the boundary we have walked to.
 */
async function emitAllMailInventoryDisclosure(emitFn, session, historicalCursor, forwardFloorUid) {
    const backfilledThroughUid = historicalCursor.backfilled_through_uid ?? 0;
    await emitFn({
        type: "PROGRESS",
        stream: "messages",
        message: `All Mail reports ${session.existsTotal} messages; historical walk is through UID ${backfilledThroughUid} of ${forwardFloorUid}`,
        all_mail_inventory: {
            all_mail_exists: session.existsTotal,
            backfilled_through_uid: backfilledThroughUid,
            forward_floor_uid: forwardFloorUid,
            historical_backfill_complete: historicalCursor.completed_at !== null,
            uidvalidity: session.uidvalidityNum,
        },
    });
}
/** Record a bounded terminal outcome so a poison UID cannot replay forever. */
async function emitHistoricalMessageSkip(deps, uid) {
    await deps.emitProtocol({
        type: "SKIP_RESULT",
        stream: "messages",
        reason: "historical_message_unaccounted",
        message: "A Gmail historical message could not be represented; the UID was recorded as a terminal gap.",
        diagnostics: { uid: typeof uid === "number" ? uid : null },
    });
}
async function emitHistoricalContinuationSkip(emitFn, stream, continuation) {
    await emitFn({
        type: "SKIP_RESULT",
        stream,
        reason: "historical_backfill_pending",
        message: "This bounded page completed; more historical work remains and will be retried by the next run.",
        continuation: { ...continuation, owner: "runtime", remaining: true },
        recovery_hint: { action: "retry_by_runtime", retryable: true },
    });
}
/** Read one START line from stdin, or reject if malformed. */
function readStartMessage(reader) {
    return new Promise((resolve, reject) => {
        reader.once("line", (line) => {
            try {
                resolve(JSON.parse(line));
            }
            catch (e) {
                reject(e instanceof Error ? e : new Error(String(e)));
            }
        });
    });
}
/** Resolve the Gmail app password from env or via INTERACTION kind=credentials. */
export function resolveGmailPasswordFromEnv(env = process.env) {
    return env.GOOGLE_APP_PASSWORD_PDPP || env.GMAIL_APP_PASSWORD || null;
}
async function resolvePassword() {
    const envPassword = resolveGmailPasswordFromEnv();
    if (envPassword) {
        return envPassword;
    }
    try {
        const creds = await requireCredentialsOrAsk({
            required: [["GOOGLE_APP_PASSWORD_PDPP", "GMAIL_APP_PASSWORD"]],
            connectorName: "Gmail",
            sendInteraction: (req) => {
                const wrapped = {
                    type: "INTERACTION",
                    request_id: req.request_id ?? nextInteractionId(),
                    kind: req.kind,
                    message: req.message,
                    ...(req.schema === undefined ? {} : { schema: req.schema }),
                    ...(req.timeout_seconds === undefined
                        ? {}
                        : { timeout_seconds: req.timeout_seconds }),
                };
                return sendInteractionAndWait(wrapped).then((resp) => ({
                    type: "INTERACTION_RESPONSE",
                    request_id: resp.request_id,
                    status: resp.status,
                    ...(resp.data === undefined
                        ? {}
                        : { data: resp.data }),
                }));
            },
        });
        return creds.GOOGLE_APP_PASSWORD_PDPP ?? null;
    }
    catch (e) {
        fail(e instanceof Error ? e.message : String(e), false);
        return null;
    }
}
/**
 * Resolve the Gmail address from env (GMAIL_ADDRESS, GMAIL_USER, or
 * AMAZON_USERNAME if it looks like an email) or by asking the user via
 * INTERACTION.
 */
export function resolveGmailAddressFromEnv(env = process.env) {
    if (env.GMAIL_ADDRESS) {
        return env.GMAIL_ADDRESS;
    }
    if (env.GMAIL_USER) {
        return env.GMAIL_USER;
    }
    if (env.AMAZON_USERNAME && EMAIL_AT_RE.test(env.AMAZON_USERNAME)) {
        return env.AMAZON_USERNAME;
    }
    return null;
}
/**
 * Mask an email address for an operator/model-visible PROGRESS message.
 *
 * The owner's full Gmail address is a raw PII identifier; emitting it verbatim
 * in a PROGRESS line leaks it to every consumer of the run stream (dashboard,
 * timeline, logs, model). We still want the progress line to confirm *which
 * account/domain* connected, so we keep the domain and the first character of
 * the local-part and mask the rest:
 *
 *   "taylor.rivera@example.com"  ->  "t***@example.com"
 *   "x@example.com"            ->  "***@example.com"
 *
 * If the value does not look like an `local@domain` address (no `@`, or an
 * empty domain), we return a constant placeholder rather than risk echoing an
 * unexpected raw value. The output never contains the full local-part.
 */
export function redactEmailForProgress(address) {
    const match = EMAIL_SPLIT_RE.exec(address);
    const local = match?.[1];
    const domain = match?.[2];
    if (!(local && domain)) {
        return "[redacted-account]";
    }
    const head = local.length > 1 ? local[0] : "";
    return `${head}***@${domain}`;
}
async function resolveAddress() {
    const fromEnv = resolveGmailAddressFromEnv();
    if (fromEnv) {
        return fromEnv;
    }
    const resp = await sendInteractionAndWait({
        type: "INTERACTION",
        request_id: nextInteractionId(),
        kind: "credentials",
        message: "Gmail address to sync (the account the app password was generated for)",
        schema: {
            type: "object",
            properties: { email: { type: "string", format: "email" } },
            required: ["email"],
        },
        timeout_seconds: DEFAULT_CRED_TIMEOUT_S,
    });
    if (resp.status === "success" &&
        resp.data &&
        typeof resp.data.email === "string") {
        return resp.data.email;
    }
    return null;
}
// ─── Labels stream ──────────────────────────────────────────────────────
/**
 * Parse the prior `labels` STATE cursor's `fingerprints` map. The cursor
 * shape is `state.labels.fingerprints` keyed by label `name`. Legacy
 * cursors (pre-fingerprint: only `{ fetched_at }`) decode to an empty
 * map, so the first post-deploy run rebuilds the map and re-emits every
 * label exactly once.
 */
export function readPriorLabelFingerprints(state) {
    const streamState = (state.labels ?? {});
    const raw = streamState.fingerprints;
    const out = new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
/**
 * Emit the IMAP mailbox list as `labels` records, gated through a
 * per-label fingerprint cursor so an unchanged mailbox set does not
 * append a new version of every label on every run.
 *
 * The labels record body is `{ name, canonical_name, is_system,
 * parent_name, message_count }`. `message_count` is hardcoded `null`,
 * and there is no run-clock field in the record (the `fetched_at`
 * lives only in the STATE cursor). So the record's stable-JSON IS the
 * change signal: a label only re-emits when its name/derived flags
 * actually change. No fields are excluded from the fingerprint.
 *
 * Before this gate, `labels` re-emitted every mailbox unconditionally
 * each run, accumulating ~269 versions per label of byte-identical
 * history.
 */
async function emitLabelsStream(client, emitRecord, state) {
    // `labels` is keyed by `name`, not `id`, and the stored record body has
    // no `id` field. The fingerprint cursor keys on `data.id`, so we pass a
    // keying `id` (the label name) but EXCLUDE it from the fingerprint —
    // leaving the hash computed over exactly the stored record body
    // (`{name, canonical_name, is_system, parent_name, message_count}`).
    // This keeps byte-parity with the compaction script, which fingerprints
    // the stored `record_json` (no `id`) with an empty exclude set.
    const cursor = openFingerprintCursor(state, {
        excludeFromFingerprint: ["id"],
        priorFingerprints: readPriorLabelFingerprints(state),
    });
    const mailboxes = await client.list();
    // The full mailbox list is the stream's boundary, measured here before the
    // fingerprint gate below decides what to emit. Every mailbox is either
    // emitted or suppressed as unchanged — none is dropped — so `considered` and
    // `covered` are equal and a steady-state run reads covered rather than a
    // false partial.
    const consideredLabels = mailboxes.length;
    for (const mb of mailboxes) {
        const name = mb.path;
        const record = {
            name,
            canonical_name: canonicalLabelName(name),
            is_system: isGmailSystemLabel(name),
            parent_name: labelParentName(name),
            message_count: null, // we could SELECT each to get EXISTS but not worth it
        };
        // Fingerprint by the label `name` (the record key for this stream).
        if (cursor.shouldEmit({ id: name, ...record })) {
            await emitRecord("labels", record, "name");
        }
    }
    // Drop fingerprints for mailboxes that disappeared so a future
    // re-creation re-emits. `labels` is always a full scan.
    cursor.dropUnseenIds();
    const labelsCursor = { fetched_at: nowIso() };
    if (cursor.size() > 0) {
        labelsCursor.fingerprints = cursor.toState();
    }
    await emit({
        type: "STATE",
        stream: "labels",
        cursor: labelsCursor,
    });
    await emit(buildFullScanCoverageMessage("labels", consideredLabels));
}
// ─── All Mail resolution + cursor ───────────────────────────────────────
/** Locate the [Gmail]/All Mail mailbox via \All special-use or fallback path. */
async function findAllMailbox(client) {
    const mailboxes = await client.list();
    return (mailboxes.find((m) => m.specialUse === "\\All" || m.path === "[Gmail]/All Mail") ?? null);
}
/**
 * Validate the IMAP `EXISTS` count for All Mail and bind it as the mailbox's
 * inventory total. Fail closed on missing/malformed, mirroring Jellyfin's
 * `validateTotalRecordCount`: a silently absent total that reads as success is
 * precisely the bug this contract exists to prevent.
 *
 * `priorTotal` is compared only WITHIN a UIDVALIDITY epoch (the caller passes
 * `undefined` across a re-key). A decrease inside one epoch is real deletion or
 * a server bug and must throw rather than pass quietly. Across a re-key the UID
 * space was rebuilt, so a different count is expected and is not loss.
 */
function validateExistsTotal(value, priorTotal) {
    if (value === undefined || value === null) {
        throw new Error("gmail_all_mail_exists_missing: SELECT reported no EXISTS for All Mail");
    }
    if (typeof value !== "number") {
        throw new Error("gmail_all_mail_exists_not_number");
    }
    if (!Number.isFinite(value)) {
        throw new Error("gmail_all_mail_exists_not_finite");
    }
    if (!Number.isInteger(value)) {
        throw new Error("gmail_all_mail_exists_not_integer");
    }
    if (value < 0) {
        throw new Error("gmail_all_mail_exists_negative");
    }
    if (priorTotal !== undefined && value < priorTotal) {
        throw new Error(`gmail_all_mail_exists_decreased: ${value} < ${priorTotal}`);
    }
    return value;
}
/**
 * Narrow the MailboxObject + prior state into the (UIDVALIDITY, cursor,
 * resync-flag) triple the fetch loop needs. Returns null when UIDVALIDITY
 * is missing (caller should fail).
 */
function deriveAllMailSession(mailbox, state) {
    const uidvalidityNum = bigintToNumber(mailbox.uidValidity);
    if (uidvalidityNum === null) {
        return null;
    }
    // The RS returns state as { <stream>: <cursor>, ... } where each <cursor>
    // is the object the connector put in the STATE message's .cursor field.
    // This connector emits STATE with stream='messages' and
    // cursor={all_mail:{uidvalidity,uidnext,highest_modseq}}, so the correct
    // read path is state.messages.all_mail — NOT state.all_mail. Prior code
    // read the top level, resolving to undefined on every run and silently
    // forcing full-refresh. Observed 2026-04-21: state persisted correctly
    // but every run did a full 1:* fetch. Also accept the legacy top-level
    // shape in case any historical state was written before this fix.
    const messagesState = (state.messages ?? {});
    const attachmentsState = (state.attachments ?? {});
    const legacyState = state;
    const priorAllMail = messagesState.all_mail ?? legacyState.all_mail ?? {};
    const priorAttachmentAllMail = attachmentsState.all_mail ?? {};
    const priorMessagesBackfill = messagesState.backfill ?? {};
    const priorUidvalidity = priorAllMail.uidvalidity;
    // Only compare EXISTS against a prior recorded in the SAME UID epoch. A
    // UIDVALIDITY change means the mailbox was re-keyed, so the old count
    // describes a different UID space and a lower new count is not loss —
    // exactly the re-key-vs-deletion distinction the messages cursor already
    // draws above. Comparing across the boundary would turn every legitimate
    // re-key into a spurious throw.
    const priorExistsTotal = priorUidvalidity === uidvalidityNum &&
        typeof priorAllMail.exists === "number"
        ? priorAllMail.exists
        : undefined;
    const existsTotal = validateExistsTotal(mailbox.exists, priorExistsTotal);
    const attachmentBackfill = priorAttachmentAllMail.uidvalidity === uidvalidityNum
        ? priorAttachmentAllMail
        : {
            completed_at: null,
            uidvalidity: uidvalidityNum,
        };
    return {
        attachmentBackfill,
        existsTotal,
        priorExistsTotal,
        messagesBackfill: priorMessagesBackfill.uidvalidity === uidvalidityNum
            ? priorMessagesBackfill
            : {
                uidvalidity: uidvalidityNum,
                backfilled_through_uid: 0,
                completed_at: null,
            },
        fullResync: !priorUidvalidity || priorUidvalidity !== uidvalidityNum,
        highestModseqCursor: bigintToCursor(mailbox.highestModseq),
        priorModseq: priorAllMail.highest_modseq,
        priorUidnext: priorAllMail.forward_uidnext ?? priorAllMail.uidnext ?? 1,
        uidnext: mailbox.uidNext,
        uidvalidityNum,
    };
}
// ─── Phase A: metadata collection ───────────────────────────────────────
/**
 * Parse an ISO 8601 timestamp into IMAP's date format (DD-MMM-YYYY).
 * Returns null if the input is not a valid ISO string.
 *
 * IMAP's SINCE criterion matches messages with an internal date >= the
 * specified date, and IMAP dates are day-granular (no time component).
 * Post-filtering by exact ISO boundary is required to honor the stream's
 * declared time_range.since, which may have time-of-day precision.
 */
export function isoToImapDate(iso) {
    if (!iso || typeof iso !== "string") {
        return null;
    }
    try {
        const d = new Date(iso);
        if (Number.isNaN(d.getTime())) {
            return null;
        }
        const day = String(d.getUTCDate()).padStart(2, "0");
        const monthNames = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
        ];
        const month = monthNames[d.getUTCMonth()];
        const year = d.getUTCFullYear();
        return `${day}-${month}-${year}`;
    }
    catch {
        return null;
    }
}
/**
 * Intersect two UID ranges (either "1:*" format or comma-separated list)
 * and return the overlap as a comma-separated list.
 *
 * - `rangeStr` is the original range (e.g., "200:*" from incremental cursor)
 * - `searchUids` are UIDs returned by IMAP search (sorted ascending)
 *
 * Returns only the UIDs that fall within both ranges.
 */
function intersectUidRanges(rangeStr, searchUids) {
    if (searchUids.length === 0) {
        return ""; // Empty result
    }
    // Parse the range string to determine included UIDs
    const parts = rangeStr.split(":");
    if (parts.length === 2 && parts[0] && parts[1]) {
        const start = Number(parts[0]);
        const end = parts[1] === "*" ? Number.POSITIVE_INFINITY : Number(parts[1]);
        if (!(Number.isNaN(start) || Number.isNaN(end))) {
            // Range format: keep only UIDs in [start, end]
            return searchUids.filter((uid) => uid >= start && uid <= end).join(",");
        }
    }
    // Fallback: assume a comma-separated list, intersect with search result
    const rangeUids = new Set(rangeStr
        .split(",")
        .map((s) => Number(s.trim()))
        .filter((n) => !Number.isNaN(n)));
    return searchUids.filter((uid) => rangeUids.has(uid)).join(",");
}
/**
 * Thrown when a message's internalDate is missing or unparseable during exact
 * boundary filtering. This prevents the run from emitting records and committing
 * STATE, ensuring no false complete claims are made.
 *
 * The message lacks proof of its position relative to the declared scope, so
 * the entire enumeration must fail rather than silently excluding it or
 * returning a false partial. The runtime's unhandledRejection handler will
 * classify this error and decide retry policy based on its deterministic nature.
 */
class MissingOrInvalidInternalDateError extends Error {
    constructor(uid, detail, options) {
        super(`UID ${uid}: cannot verify internalDate for exact boundary filtering: ${detail}`, options);
        this.name = "MissingOrInvalidInternalDateError";
    }
}
/**
 * Compare message timestamp against declared boundary using epoch milliseconds.
 * Returns true if message is at or after the boundary, false if before.
 * Throws MissingOrInvalidInternalDateError if internalDate is missing or
 * unparseable, preventing silent inclusion or false coverage claims.
 *
 * Lexical comparison of ISO strings fails when offsets differ; epoch comparison
 * is timezone-safe and handles arbitrary precision correctly.
 */
function isAtOrAfterBoundary(messageTimestamp, boundaryIso, uid) {
    // Reject missing internalDate when exact boundary is declared.
    // IMAP does not guarantee internalDate presence; without it, we cannot
    // prove the message is in scope. Throw to prevent silent exclusion and
    // false complete claims; retryability is preserved.
    if (!messageTimestamp) {
        throw new MissingOrInvalidInternalDateError(uid, "missing");
    }
    try {
        const msgTime = new Date(messageTimestamp).getTime();
        const boundaryTime = new Date(boundaryIso).getTime();
        // Reject unparseable timestamps; can't compare without valid epoch values.
        if (Number.isNaN(msgTime)) {
            throw new MissingOrInvalidInternalDateError(uid, `unparseable: "${messageTimestamp}"`);
        }
        if (Number.isNaN(boundaryTime)) {
            throw new Error(`boundary ISO is unparseable: "${boundaryIso}" (internal error)`);
        }
        return msgTime >= boundaryTime;
    }
    catch (e) {
        if (e instanceof MissingOrInvalidInternalDateError) {
            throw e;
        }
        throw new MissingOrInvalidInternalDateError(uid, `exception: ${e instanceof Error ? e.message : String(e)}`, {
            cause: e,
        });
    }
}
export async function collectMetadata(client, fetchRange, sinceDate = null, sinceIso = null) {
    let range = fetchRange;
    // If a since boundary is declared (IMAP date format), constrain via search.
    // Intersect the search result with the existing fetchRange to preserve
    // cursor/resume semantics and avoid re-fetching already-seen UIDs.
    if (sinceDate) {
        const uidsAfterSince = await client.search({ since: sinceDate }, { uid: true });
        if (!uidsAfterSince || uidsAfterSince.length === 0) {
            // No messages after the declared date.
            return [];
        }
        // Intersect search result with the existing range (e.g., "200:*" from
        // incremental cursor). This preserves the cursor and prevents duplicate work.
        range = intersectUidRanges(fetchRange, uidsAfterSince);
        if (!range) {
            // No overlap between incremental range and SINCE search.
            return [];
        }
    }
    const metas = [];
    for await (const m of client.fetch(range, GMAIL_METADATA_FETCH_QUERY, {
        uid: true,
    })) {
        // IMAP SINCE is day-granular; post-filter on exact ISO boundary to honor
        // the stream's declared time_range.since at the second precision. When an
        // exact boundary is declared, every message MUST have a valid internalDate
        // to prove it's in scope. Throws MissingOrInvalidInternalDateError if unable
        // to verify, preventing STATE commit and preserving retryability.
        if (sinceIso) {
            const isInBoundary = isAtOrAfterBoundary(m.internalDate, sinceIso, m.uid ?? "unknown");
            if (!isInBoundary) {
                // Message before the exact boundary. Skip it; IMAP SINCE (day-granular)
                // included it but exact scope (second-precise) excludes it.
                continue;
            }
        }
        metas.push(m);
        if (metas.length % FETCH_HEADER_BATCH_PROGRESS === 0) {
            await emit({
                type: "PROGRESS",
                stream: "messages",
                message: `Collected ${metas.length} message headers`,
                count: metas.length,
            });
        }
    }
    await emit({
        type: "PROGRESS",
        stream: "messages",
        message: `Collected ${metas.length} message headers`,
        count: metas.length,
        total: metas.length,
    });
    return metas;
}
/** Build the bodyParts request list given the selection + scope. */
function buildBodyPartsRequest(selection, wantBodies) {
    const parts = [];
    if (selection.plainPart) {
        // Full body if we need message_bodies; otherwise bounded for snippet.
        parts.push(wantBodies
            ? { key: selection.plainPart }
            : {
                key: selection.plainPart,
                start: 0,
                maxLength: SNIPPET_FETCH_MAX_BYTES,
            });
    }
    if (wantBodies && selection.htmlPart) {
        parts.push({ key: selection.htmlPart });
    }
    return parts;
}
/**
 * Decode fetched body buffers into strings + optional snippet per the
 * caller's scope. Never throws; missing buffers resolve to nulls.
 */
function decodeFetchedBodies(plainBuf, htmlBuf, selection, wantBodies, wantMessages) {
    let bodyTextFull = null;
    let bodyHtmlFull = null;
    let snippet = null;
    if (plainBuf) {
        if (wantBodies) {
            bodyTextFull = decodeBodyPart(plainBuf, selection.plainEncoding, selection.plainCharset);
        }
        if (wantMessages) {
            snippet = makeSnippet(plainBuf, selection.plainEncoding, selection.plainCharset, SNIPPET_MAX_CHARS);
        }
    }
    if (htmlBuf && wantBodies) {
        bodyHtmlFull = decodeBodyPart(htmlBuf, selection.htmlEncoding, selection.htmlCharset);
    }
    return { bodyHtmlFull, bodyTextFull, snippet };
}
/**
 * Bounded, non-secret failure category for a thrown body fetch.
 *
 * Only this connector-chosen category ever reaches the emitted DETAIL_GAP's
 * `error.class`. Raw error text never crosses that boundary: an IMAP error
 * message can embed the failing command, which for a BODY[...] fetch quotes
 * the mailbox and part path. The split mirrors `isImapTransientError`, which
 * the run-level retry classifier already trusts.
 */
export function bodyFetchFailureClass(err) {
    return isImapTransientError(err)
        ? "imap_body_fetch_transient"
        : "imap_body_fetch_failed";
}
/**
 * Fetch (and decode) the parts we need for one message in a single IMAP
 * round-trip.
 *
 * Still best-effort in the sense that a body failure never blocks the envelope
 * emit — but it no longer renders as an empty message. A thrown fetch resolves
 * to all-nulls PLUS `fetchFailed: true`, which is what lets `processMessage`
 * mark the body retryable instead of writing a schema-valid lie
 * (`body_source: "empty"`) that the advancing UID cursor then makes permanent.
 */
async function fetchBodies(client, msg, selection, wantBodies, wantMessages) {
    const empty = {
        bodyHtmlFull: null,
        bodyTextFull: null,
        snippet: null,
    };
    if (!(msg.uid && (wantBodies || (wantMessages && selection.plainPart)))) {
        return empty;
    }
    const parts = buildBodyPartsRequest(selection, wantBodies);
    if (parts.length === 0) {
        return empty;
    }
    try {
        const bodyResp = await client.fetchOne(String(msg.uid), { bodyParts: parts }, { uid: true });
        const plainBuf = selection.plainPart && bodyResp
            ? (bodyResp.bodyParts?.get(selection.plainPart) ?? null)
            : null;
        const htmlBuf = selection.htmlPart && bodyResp
            ? (bodyResp.bodyParts?.get(selection.htmlPart) ?? null)
            : null;
        return decodeFetchedBodies(plainBuf, htmlBuf, selection, wantBodies, wantMessages);
    }
    catch (err) {
        // The envelope still emits — but the caller MUST be able to tell this
        // apart from a genuinely bodyless message, or the body is lost behind the
        // cursor forever.
        return {
            ...empty,
            fetchFailed: true,
            failureClass: bodyFetchFailureClass(err),
        };
    }
}
export function selectAllMailFetchRange(session, _requested) {
    // Range is determined purely by the persisted forward cursor:
    //   - Full resync (no prior uidvalidity, or it changed): no forward range;
    //     historical work selects its own bounded UID page.
    //   - Incremental: priorUidnext:* — only UIDs we haven't seen yet.
    //
    // The earlier behavior forced 1:* whenever the run scope included
    // `attachments`. Rationale at the time was: enable attachment
    // backfill when a user first turns the stream on. The cost was real:
    // every Gmail sync re-scanned the entire mailbox forever, not just
    // the once-after-enabling pass.
    //
    // The correct shape is to treat backfill as an explicit, per-stream
    // operation rather than an implicit side effect of stream selection.
    // For new attachments on new messages — the common case — the
    // incremental range already covers them: new UIDs land in `metas`
    // and `processMessage` emits attachment records for them
    // (lines 357-361).
    //
    // Historical attachment recovery is still bounded by the dedicated
    // attachment backfill cursor, but a pending attachment detail backlog also
    // activates that path so a healthy-looking messages cursor does not hide
    // durable attachment work.
    if (session.fullResync) {
        return null;
    }
    return `${session.priorUidnext}:*`;
}
export const DEFAULT_MESSAGES_BACKFILL_WINDOW_UIDS = 500;
const MESSAGES_BACKFILL_WINDOW_UIDS_ENV = "PDPP_GMAIL_MESSAGES_BACKFILL_WINDOW_UIDS";
function normalizeMessagesBackfillWindowUids(value) {
    if (typeof value === "number" && Number.isSafeInteger(value) && value > 0) {
        return value;
    }
    return DEFAULT_MESSAGES_BACKFILL_WINDOW_UIDS;
}
export function resolveMessagesBackfillWindowUids(env = process.env) {
    const raw = env[MESSAGES_BACKFILL_WINDOW_UIDS_ENV];
    if (!(raw && POSITIVE_INTEGER_PATTERN.test(raw))) {
        return DEFAULT_MESSAGES_BACKFILL_WINDOW_UIDS;
    }
    return normalizeMessagesBackfillWindowUids(Number(raw));
}
/**
 * Select one historical message work unit. The unit is a UID interval, not a
 * positional page: Gmail UIDs may contain holes, but a successful fetch of the
 * interval accounts for those holes and lets the cursor advance to the exact
 * admitted interval end.
 */
export function selectMessagesBackfillFetchRange(args) {
    const cursor = args.messagesBackfill;
    const sameEpoch = args.uidvalidity === undefined || cursor.uidvalidity === args.uidvalidity;
    const backfilledThrough = sameEpoch
        ? (cursor.backfilled_through_uid ?? 0)
        : 0;
    const targetUid = sameEpoch
        ? (cursor.target_uid ?? Math.max(0, (args.uidnext ?? 1) - 1))
        : Math.max(0, (args.uidnext ?? 1) - 1);
    const startUid = Math.max(1, backfilledThrough + 1);
    if (startUid > targetUid) {
        return null;
    }
    const windowUids = normalizeMessagesBackfillWindowUids(args.maxWindowUids);
    return `${startUid}:${Math.min(targetUid, startUid + windowUids - 1)}`;
}
/**
 * Decide the ceiling the historical walk must reach on THIS run.
 *
 * The band defect this closes
 * ---------------------------
 * The two pointers divide one UID space, so they must MEET: every UID below
 * `forward_uidnext` that the forward pass did not actually walk has to fall
 * inside the historical walk's remit, or it belongs to neither walk and is
 * never fetched.
 *
 * The old rule was `prior.target_uid ?? priorEnd` — once written, the ceiling
 * only ever copied itself forward. Meanwhile the forward watermark advanced on
 * every run with new mail. So the ceiling froze at the mailbox's size on the
 * day the backfill started while the resume point climbed away from it, and the
 * interval between them reopened continuously and grew without bound. Repairing
 * the stored value (as `scripts/repair/gmail-backfill-target-extend.ts` did)
 * fixed one instance of the gap and not the mechanism: the very next run with
 * new mail reopened it.
 *
 * The rule here instead ties the ceiling to the ONE fact that makes the band
 * provably empty: the historical walk must own everything up to where the
 * forward walk genuinely resumes from. `forwardFloorUid` is that point minus
 * one — the last UID the forward pass will NOT fetch on the next run.
 *
 * Why this cannot rewind or thrash
 * --------------------------------
 *   - It only ever RAISES: `Math.max` against the prior ceiling. A ceiling that
 *     could fall would re-open `completed_at` on a finished walk and, worse,
 *     let `backfilled_through_uid` sit above its own target.
 *   - It never touches `backfilled_through_uid`. Progress through the mailbox
 *     (~150k UIDs on the live instance) is preserved exactly; raising a ceiling
 *     adds `new - old` UIDs of work and re-walks nothing already done.
 *   - It is bounded per run. The ceiling rises to a watermark the mailbox
 *     already passed, never to a live `uidnext` that moves while we walk, so
 *     the walk converges on a fixed target instead of chasing the mailbox
 *     forever. Termination is preserved: each run consumes a bounded page and
 *     the ceiling only gains the UIDs that arrived since the last run.
 */
export function resolveMessagesBackfillTargetUid(args) {
    const priorEnd = args.prior.backfilled_through_uid ?? 0;
    const priorTarget = args.prior.target_uid ?? priorEnd;
    // Monotonic by construction: the ceiling is a high-water mark, never a
    // setting. A ceiling that fell below `backfilled_through_uid` would make the
    // walk's own recorded progress illegal against its target.
    return Math.max(priorTarget, args.forwardFloorUid);
}
export function advanceMessagesBackfillCursor(args) {
    const priorEnd = args.prior.backfilled_through_uid ?? 0;
    const targetUid = args.prior.target_uid ?? priorEnd;
    if (args.pageEndUid < priorEnd) {
        throw new Error("messages backfill cursor must not regress");
    }
    if (args.pageEndUid > targetUid) {
        throw new Error("messages backfill page must not pass its target");
    }
    return {
        backfilled_through_uid: args.pageEndUid,
        completed_at: args.pageEndUid >= targetUid ? args.now : null,
        target_uid: targetUid,
        uidvalidity: args.prior.uidvalidity ?? 0,
    };
}
export function isAttachmentBackfillRequested(streamsToBackfill) {
    return (Array.isArray(streamsToBackfill) &&
        streamsToBackfill.includes("attachments"));
}
function hasPendingAttachmentBacklog(detailGaps) {
    return (Array.isArray(detailGaps) &&
        detailGaps.some((gap) => gap.stream === "attachments" && gap.status === "pending"));
}
/**
 * True when the attachments All Mail cursor made real prior progress
 * (`backfilled_through_uid > 0`, so a run genuinely opted in and scanned at
 * least one page) but stalled short of the mailbox's current UID range with
 * `completed_at` still unset. Deliberately excludes a fresh/never-started
 * cursor (`backfilled_through_uid` 0 or absent): a connector that has never
 * been asked to backfill attachments must not have this signal alone force
 * one on every future scheduled run — that stays opt-in via
 * `streamsToBackfill` or a pending detail gap. This only catches the case
 * where backfill started, then the trigger that was driving it (an explicit
 * `streamsToBackfill` request) stopped arriving before the cursor reached
 * `completed_at`, leaving the cursor permanently stuck with no pending gaps
 * to signal it. Mirrors the range math in `selectAttachmentBackfillFetchRange`
 * without requiring a full session object, so the trigger and the range
 * selector agree on what "done" means.
 */
function hasIncompleteAttachmentBackfill(args) {
    const cursor = args.attachmentBackfill;
    if (!cursor || cursor.completed_at) {
        return false;
    }
    const backfilledThrough = cursor.backfilled_through_uid ?? 0;
    if (backfilledThrough <= 0) {
        return false;
    }
    if (args.priorUidnext === undefined) {
        return false;
    }
    const endUid = Math.max(0, args.priorUidnext - 1);
    return backfilledThrough < endUid;
}
/**
 * Historical attachment backfill should run when the operator asked for it,
 * when the runtime hands the connector pending attachment detail gaps, or
 * when the attachments All Mail cursor already made progress and then
 * stalled. The gap check alone is not enough: a durable per-attachment gap
 * only exists once an attachment has been attempted and failed, so a cursor
 * that started backfilling (e.g. via a one-time `streamsToBackfill` request)
 * and then stopped receiving that request has zero pending gaps and would
 * otherwise look healthy forever, even though the overwhelming majority of
 * the mailbox was never scanned for attachments at all. The gap check is
 * still the recovery-first seam: durable attachment backlog should not look
 * healthy just because the ordinary messages cursor is current.
 */
export function shouldBackfillAttachments(args) {
    return (isAttachmentBackfillRequested(args.streamsToBackfill) ||
        hasPendingAttachmentBacklog(args.detailGaps) ||
        hasIncompleteAttachmentBackfill({
            attachmentBackfill: args.attachmentBackfill,
            priorUidnext: args.priorUidnext,
        }));
}
export function selectAttachmentBackfillFetchRange(session) {
    const backfilledThrough = session.attachmentBackfill.backfilled_through_uid ?? 0;
    const startUid = Math.max(1, backfilledThrough + 1);
    const endUid = Math.max(0, session.priorUidnext - 1);
    if (startUid > endUid) {
        return null;
    }
    const maxWindowUids = normalizeAttachmentBackfillWindowUids(session.maxWindowUids);
    const windowEndUid = Math.min(endUid, startUid + maxWindowUids - 1);
    return `${startUid}:${windowEndUid}`;
}
export function resolveAttachmentBackfillWindowUids(env = process.env) {
    const value = env[ATTACHMENT_BACKFILL_WINDOW_UIDS_ENV];
    if (!(value && POSITIVE_INTEGER_PATTERN.test(value))) {
        return DEFAULT_ATTACHMENT_BACKFILL_WINDOW_UIDS;
    }
    return normalizeAttachmentBackfillWindowUids(Number(value));
}
function normalizeAttachmentBackfillWindowUids(value) {
    if (typeof value === "number" && Number.isSafeInteger(value) && value > 0) {
        return value;
    }
    return DEFAULT_ATTACHMENT_BACKFILL_WINDOW_UIDS;
}
// ─── Historical attachment backfill: byte-cost-bounded page sizing ────────
//
// A fixed UID count is a poor unit of completed work for historical
// attachment backfill: two UIDs can differ by orders of magnitude in
// attachment bytes to transfer (see gmail-blob-throughput-rootcause-0715.md
// — a single 4.77 MB attachment observed at ~5.7 KB/s). Mirrors
// reference-implementation/runtime/detail-gap-paging.js's byte-budget-clamp
// and trim-to-budget-with-at-least-one-entry pattern as Gmail-local policy:
// the generic detail-gap-paging module is not modified and gains no Gmail
// knowledge.
//
// Unlike the generic detail-gap page (which has no per-row size hint and so
// needs a learned observed-average), Gmail already knows each UID's
// attachment byte cost up front from BODYSTRUCTURE (fetched pre-download by
// collectMetadata). There is no cross-page learning here: the historical
// backfill emits exactly one page per run (see runAllMailPasses), so an
// EWMA "observed average that adapts across pages" would have nothing to
// adapt across and was removed as dead complexity. A UID whose attachment
// size is unavailable (BODYSTRUCTURE parse gap) falls back to a single
// fixed conservative estimate, not a learned one.
//
// Default sizing: at the live-incident worst-case observed throughput of
// ~5.7 KB/s (gmail-blob-throughput-rootcause-0715.md), a 1 MiB page is
// ~3 minutes of transfer time in the worst case, leaving headroom inside
// the connector's ~15-minute run cadence for the rest of the run's work
// (normal message walk, other streams). The max (4 MiB, ~12 min worst-case)
// stays under one cadence window; the min (256 KiB, <1 min worst-case) is a
// usable floor for an operator who wants faster, smaller pages. No
// wall-clock timer is introduced — the budget bounds completed work, not
// elapsed time.
export const ATTACHMENT_BACKFILL_PAGE_MIN_BYTES = 256 * 1024;
export const ATTACHMENT_BACKFILL_PAGE_DEFAULT_BYTES = 1024 * 1024;
export const ATTACHMENT_BACKFILL_PAGE_MAX_BYTES = 4 * 1024 * 1024;
// Served recovery is the whole run's bounded work unit: it returns before the
// ordinary forward walk. It can therefore use the established 4 MiB safe
// ceiling without changing the 1 MiB historical-backfill default, which
// reserves time for ordinary sync work in mixed runs.
export const ATTACHMENT_RECOVERY_PAGE_DEFAULT_BYTES = ATTACHMENT_BACKFILL_PAGE_MAX_BYTES;
/**
 * Fixed conservative per-UID cost used only when BODYSTRUCTURE reported no
 * usable attachment size. Not learned or updated — a single documented
 * fallback, chosen above the ordinary attachment-metadata overhead so a run
 * of unknown-size UIDs still forms a small, bounded page rather than an
 * unbounded one.
 */
export const ATTACHMENT_BACKFILL_UNKNOWN_SIZE_FALLBACK_BYTES = 256 * 1024;
const ATTACHMENT_BACKFILL_PAGE_BYTES_ENV = "PDPP_GMAIL_ATTACHMENT_BACKFILL_PAGE_BYTES";
const ATTACHMENT_RECOVERY_PAGE_BYTES_ENV = "PDPP_GMAIL_ATTACHMENT_RECOVERY_PAGE_BYTES";
function boundedPositiveInteger(value, fallback, min, max) {
    if (typeof value !== "number" || !Number.isFinite(value) || value < min) {
        return fallback;
    }
    return Math.max(min, Math.min(max, Math.floor(value)));
}
export function attachmentBackfillPageByteBudget(configuredTargetBytes) {
    return boundedPositiveInteger(configuredTargetBytes, ATTACHMENT_BACKFILL_PAGE_DEFAULT_BYTES, ATTACHMENT_BACKFILL_PAGE_MIN_BYTES, ATTACHMENT_BACKFILL_PAGE_MAX_BYTES);
}
export function resolveAttachmentBackfillPageByteBudget(env = process.env) {
    const value = env[ATTACHMENT_BACKFILL_PAGE_BYTES_ENV];
    if (!(value && POSITIVE_INTEGER_PATTERN.test(value))) {
        return attachmentBackfillPageByteBudget();
    }
    return attachmentBackfillPageByteBudget(Number(value));
}
function resolveAttachmentPageByteBudgetOverride(value) {
    if (!(value && POSITIVE_INTEGER_PATTERN.test(value))) {
        return;
    }
    const parsed = Number(value);
    return parsed >= ATTACHMENT_BACKFILL_PAGE_MIN_BYTES &&
        parsed <= ATTACHMENT_BACKFILL_PAGE_MAX_BYTES
        ? parsed
        : undefined;
}
/**
 * Resolve the served-recovery byte budget without coupling it to ordinary
 * forward backfill. The legacy backfill variable continues to override both
 * lanes until an operator opts into the recovery-specific variable.
 */
export function resolveAttachmentRecoveryPageByteBudget(env = process.env) {
    return (resolveAttachmentPageByteBudgetOverride(env[ATTACHMENT_RECOVERY_PAGE_BYTES_ENV]) ??
        resolveAttachmentPageByteBudgetOverride(env[ATTACHMENT_BACKFILL_PAGE_BYTES_ENV]) ??
        ATTACHMENT_RECOVERY_PAGE_DEFAULT_BYTES);
}
const GMAIL_METADATA_FETCH_QUERY = {
    uid: true,
    envelope: true,
    internalDate: true,
    flags: true,
    size: true,
    bodyStructure: true,
    headers: ["list-unsubscribe", "auto-submitted", "references"],
    source: false,
    labels: true,
    threadId: true,
    emailId: true,
};
function createAttachmentHydrationFailureOutcome() {
    return {
        blob_upload_http_4xx: 0,
        blob_upload_http_5xx: 0,
        blob_upload_integrity_failed: 0,
        blob_upload_invalid_response: 0,
        blob_upload_transport_failed: 0,
        imap_download_failed: 0,
        unclassified_failed: 0,
    };
}
// Bound the served-gap probe lane so START.detail_gaps can never fan out into
// unbounded Gmail metadata work before byte admission has a chance to stop the
// prefix. Same-message gaps reuse a single lookup through the cache.
const SERVED_ATTACHMENT_RECOVERY_METADATA_LOOKUP_LIMIT = 32;
/**
 * Trim a candidate list — MUST already be sorted ascending by UID by the
 * caller; this function trusts array order and does not re-sort, so an
 * out-of-order input silently produces a wrong prefix — to a byte-cost
 * page: keep admitting candidates in order while the running total of
 * attachment bytes stays within budget, but always admit at least one
 * candidate (mirrors `trimDetailGapPageToByteBudget`'s at-least-one-entry
 * rule) so a single oversized attachment cannot block all backfill
 * progress. Returns a PREFIX COUNT, not a UID value or set, so the caller
 * derives the admitted page positionally (`candidates.slice(0, admittedCount)`)
 * rather than by comparing UIDs — immune to UID gaps.
 */
export function trimAttachmentBackfillPageToByteBudget(candidates, byteBudget) {
    let admittedCount = 0;
    let estimatedBytesTotal = 0;
    for (const candidate of candidates) {
        const cost = candidate.attachmentBytes;
        if (admittedCount > 0 && estimatedBytesTotal + cost > byteBudget) {
            break;
        }
        admittedCount += 1;
        estimatedBytesTotal += cost;
        if (estimatedBytesTotal >= byteBudget) {
            break;
        }
    }
    return { admittedCount, estimatedBytesTotal };
}
function servedAttachmentDetailGaps(detailGaps) {
    if (!Array.isArray(detailGaps) || detailGaps.length === 0) {
        return [];
    }
    return detailGaps.filter((gap) => {
        if (gap.stream !== "attachments" || gap.status !== "pending") {
            return false;
        }
        const locator = gap.detail_locator;
        if (!locator || typeof locator !== "object" || Array.isArray(locator)) {
            return false;
        }
        const typedLocator = locator;
        return (typedLocator.kind === "gmail.attachment_detail" &&
            typedLocator.message_id != null &&
            typedLocator.part_index != null);
    });
}
function normalizeGmailAttachmentRecoveryLocator(gap) {
    const locator = gap.detail_locator;
    if (!locator || typeof locator !== "object" || Array.isArray(locator)) {
        return null;
    }
    const typedLocator = locator;
    if (typedLocator.kind !== "gmail.attachment_detail") {
        return null;
    }
    const messageId = typedLocator.message_id == null
        ? ""
        : String(typedLocator.message_id).trim();
    const partIndex = typedLocator.part_index == null
        ? ""
        : String(typedLocator.part_index).trim();
    if (!(messageId && partIndex)) {
        return null;
    }
    const attachmentId = typedLocator.attachment_id == null
        ? null
        : String(typedLocator.attachment_id).trim() || null;
    return { attachmentId, messageId, partIndex };
}
async function fetchGmailMessageByMessageId(client, messageId) {
    const uids = await client.search({ emailId: messageId }, { uid: true });
    if (!uids || uids.length === 0) {
        return null;
    }
    const [uid] = uids;
    if (uid == null) {
        return null;
    }
    const message = await client.fetchOne(String(uid), GMAIL_METADATA_FETCH_QUERY, { uid: true });
    return message || null;
}
function buildServedAttachmentRecoveryProgressMessage(args) {
    return `Gmail served attachment-gap recovery phase=${args.phase} admitted=${args.admitted} recovered=${args.recovered} metadata_lookups=${args.metadataLookups}`;
}
async function emitServedAttachmentRecoveryProgress(emitProtocol, progress) {
    await emitProtocol({
        type: "PROGRESS",
        stream: "attachments",
        message: buildServedAttachmentRecoveryProgressMessage(progress),
        count: progress.phase === "hydrating" ? progress.admitted : progress.recovered,
        total: progress.phase === "hydrating"
            ? progress.metadataLookups
            : progress.admitted,
    });
}
async function loadServedAttachmentRecoveryMessage(client, messageId, state) {
    const cachedMessage = state.messageCache.get(messageId);
    if (cachedMessage !== undefined) {
        return cachedMessage;
    }
    if (state.metadataLookups >= SERVED_ATTACHMENT_RECOVERY_METADATA_LOOKUP_LIMIT) {
        return "metadata_lookup_limit_reached";
    }
    state.metadataLookups += 1;
    const message = await fetchGmailMessageByMessageId(client, messageId);
    state.messageCache.set(messageId, message);
    return message;
}
async function settleServedAttachmentRecoveryAttempt(deps, state, hydration) {
    const hydrated = hydration.record;
    if (deps.attachmentCoverage) {
        recordAttachmentCoverage(deps.attachmentCoverage, hydrated, hydration.failure);
    }
    const emitted = await deps.emitRecord("attachments", { ...hydrated });
    if (emitted && hydrated.hydration_status === "hydrated") {
        const recoveredGaps = findRecoveredAttachmentDetailGaps(deps.detailGaps, hydrated, state.recoveredAttachmentGapIds);
        for (const recoveredGap of recoveredGaps) {
            state.recoveredAttachmentGapIds.add(recoveredGap.gap_id);
            await deps.emitProtocol({
                type: "DETAIL_GAP_RECOVERED",
                reference_only: true,
                gap_id: recoveredGap.gap_id,
                ...(recoveredGap.lease_id ? { lease_id: recoveredGap.lease_id } : {}),
                record_key: hydrated.id,
                stream: "attachments",
            });
            state.recovered += 1;
        }
    }
    if (hydrated.hydration_status === "failed") {
        state.hydrationFailed += 1;
        if (hydration.failure) {
            state.attachmentHydrationFailureOutcome[hydration.failure.stage] += 1;
        }
        else {
            state.attachmentHydrationFailureOutcome.unclassified_failed += 1;
        }
    }
    // Emit bounded, non-secret progress as each admitted attempt settles so a
    // long single hydration is visible before the whole recovery lane ends.
    await emitServedAttachmentRecoveryProgress(deps.emitProtocol, {
        admitted: state.admitted,
        metadataLookups: state.metadataLookups,
        phase: "settled",
        recovered: state.recovered,
    });
}
function buildServedAttachmentRecoveryDeferredGap(gap, errorClass) {
    const locator = gap.detail_locator &&
        typeof gap.detail_locator === "object" &&
        !Array.isArray(gap.detail_locator)
        ? gap.detail_locator
        : { kind: "gmail.attachment_detail" };
    return {
        type: "DETAIL_GAP",
        reference_only: true,
        status: "pending",
        stream: "attachments",
        parent_stream: "messages",
        record_key: gap.record_key ?? gap.gap_id,
        detail_locator: locator,
        reason: "temporary_unavailable",
        retryable: true,
        last_error: { class: errorClass },
        gap_id: gap.gap_id,
        ...(gap.lease_id ? { lease_id: gap.lease_id } : {}),
    };
}
async function markServedAttachmentRecoveryAttempt(gap, emitProtocol) {
    if (!gap.lease_id) {
        return;
    }
    await emitProtocol({
        type: "DETAIL_GAP_ATTEMPTED",
        reference_only: true,
        gap_id: gap.gap_id,
        lease_id: gap.lease_id,
        stream: "attachments",
    });
}
async function processServedAttachmentRecoveryGap(client, gap, deps, state, byteBudget) {
    if (state.admitted > 0 && state.admittedBytesTotal >= byteBudget) {
        return "byte_budget";
    }
    const locator = normalizeGmailAttachmentRecoveryLocator(gap);
    if (!locator) {
        return false;
    }
    // A metadata lookup is a real provider attempt even when it finds no
    // matching message/attachment. The host records this explicit outcome; it
    // never infers attempt status from a successful DONE envelope.
    if (!state.messageCache.has(locator.messageId) &&
        state.metadataLookups >= SERVED_ATTACHMENT_RECOVERY_METADATA_LOOKUP_LIMIT) {
        return "metadata_lookup_cap";
    }
    state.attempted += 1;
    await markServedAttachmentRecoveryAttempt(gap, deps.emitProtocol);
    const loadedMessage = await loadServedAttachmentRecoveryMessage(client, locator.messageId, state);
    if (loadedMessage === "metadata_lookup_limit_reached") {
        return "metadata_lookup_cap";
    }
    if (!loadedMessage) {
        state.lookupMiss += 1;
        await deps.emitProtocol(buildServedAttachmentRecoveryDeferredGap(gap, "attachment_lookup_miss"));
        return false;
    }
    const normalizedAttachmentKey = normalizeAttachmentRecoveryKey(gap.record_key);
    if (!normalizedAttachmentKey) {
        return false;
    }
    const messageKey = String(loadedMessage.emailId ?? locator.messageId);
    const receivedAt = perMessageInternalDateToIso(loadedMessage.internalDate, nowIso);
    const attachments = decodeBodystructureForAttachments(loadedMessage.bodyStructure, messageKey, receivedAt);
    const attachment = attachments.find((candidate) => attachmentDetailGapMatches(gap, candidate, normalizedAttachmentKey));
    if (!attachment) {
        state.lookupMiss += 1;
        await deps.emitProtocol(buildServedAttachmentRecoveryDeferredGap(gap, "attachment_lookup_miss"));
        return false;
    }
    const attachmentBytes = typeof attachment.size_bytes === "number"
        ? attachment.size_bytes
        : ATTACHMENT_BACKFILL_UNKNOWN_SIZE_FALLBACK_BYTES;
    if (state.admitted > 0 &&
        state.admittedBytesTotal + attachmentBytes > byteBudget) {
        await deps.emitProtocol(buildServedAttachmentRecoveryDeferredGap(gap, "run_cap_deferred"));
        return "byte_budget";
    }
    state.admitted += 1;
    state.admittedBytesTotal += attachmentBytes;
    await emitServedAttachmentRecoveryProgress(deps.emitProtocol, {
        admitted: state.admitted,
        metadataLookups: state.metadataLookups,
        phase: "hydrating",
        recovered: state.recovered,
    });
    const hydration = await deps.hydrateAttachment(loadedMessage, attachment);
    await settleServedAttachmentRecoveryAttempt(deps, state, hydration);
    return false;
}
export async function recoverServedAttachmentGaps(client, deps) {
    const servedGaps = servedAttachmentDetailGaps(deps.detailGaps);
    if (servedGaps.length === 0) {
        return {
            admitted: 0,
            admitted_bytes: 0,
            attempted: 0,
            attachment_hydration_failure_outcome: createAttachmentHydrationFailureOutcome(),
            hydration_failed: 0,
            lookup_miss: 0,
            metadata_lookups: 0,
            recovered: 0,
            run_cap_deferred: 0,
            served: 0,
        };
    }
    const byteBudget = resolveAttachmentRecoveryPageByteBudget();
    const recoveryState = {
        admitted: 0,
        admittedBytesTotal: 0,
        attachmentHydrationFailureOutcome: createAttachmentHydrationFailureOutcome(),
        attempted: 0,
        hydrationFailed: 0,
        lookupMiss: 0,
        metadataLookups: 0,
        messageCache: new Map(),
        recovered: 0,
        recoveredAttachmentGapIds: deps.recoveredAttachmentGapIds ?? new Set(),
        runCapDeferred: 0,
    };
    const recoveryAttemptDeps = {
        ...(deps.attachmentCoverage
            ? { attachmentCoverage: deps.attachmentCoverage }
            : {}),
        detailGaps: deps.detailGaps,
        emitProtocol: deps.emitProtocol,
        emitRecord: deps.emitRecord,
        hydrateAttachment: deps.hydrateAttachment,
    };
    for (const [index, gap] of servedGaps.entries()) {
        const stop = await processServedAttachmentRecoveryGap(client, gap, recoveryAttemptDeps, recoveryState, byteBudget);
        if (stop) {
            if (stop === "byte_budget") {
                recoveryState.runCapDeferred = servedGaps.length - index;
            }
            break;
        }
    }
    return {
        admitted: recoveryState.admitted,
        admitted_bytes: recoveryState.admittedBytesTotal,
        attempted: recoveryState.attempted,
        attachment_hydration_failure_outcome: recoveryState.attachmentHydrationFailureOutcome,
        hydration_failed: recoveryState.hydrationFailed,
        lookup_miss: recoveryState.lookupMiss,
        metadata_lookups: recoveryState.metadataLookups,
        recovered: recoveryState.recovered,
        run_cap_deferred: recoveryState.runCapDeferred,
        served: servedGaps.length,
    };
}
async function recoverServedAttachmentGapsIfRequested(client, deps) {
    if (servedAttachmentDetailGaps(deps.detailGaps).length === 0) {
        return;
    }
    const recoverySummary = await recoverServedAttachmentGaps(client, {
        ...(deps.attachmentCoverage
            ? { attachmentCoverage: deps.attachmentCoverage }
            : {}),
        detailGaps: deps.detailGaps,
        emitProtocol: deps.emitProtocol,
        emitRecord: deps.emitRecord,
        hydrateAttachment: deps.hydrateAttachment,
        recoveredAttachmentGapIds: deps.recoveredAttachmentGapIds,
    });
    const { attachment_hydration_failure_outcome, ...attachmentRecoveryOutcome } = recoverySummary;
    await deps.emitProtocol({
        type: "PROGRESS",
        stream: "attachments",
        message: `Gmail served attachment-gap recovery summary: admitted=${recoverySummary.admitted} recovered=${recoverySummary.recovered}`,
        count: recoverySummary.recovered,
        total: recoverySummary.admitted,
        attachment_recovery_outcome: {
            object: "attachment_recovery_outcome",
            ...attachmentRecoveryOutcome,
        },
        attachment_hydration_failure_outcome: {
            object: "attachment_hydration_failure_outcome",
            ...attachment_hydration_failure_outcome,
        },
    });
}
export async function runAttachmentBackfillAndRecoveryPass(args) {
    if (args.recoveryOnly === true) {
        await recoverServedAttachmentGapsIfRequested(args.client, {
            attachmentCoverage: args.attachmentCoverage,
            detailGaps: args.deps.detailGaps,
            emitProtocol: args.emit,
            emitRecord: args.deps.emitRecord,
            hydrateAttachment: args.hydrateAttachment,
            recoveredAttachmentGapIds: args.recoveredAttachmentGapIds,
        });
        return;
    }
    if (!args.attachmentBackfillRequested) {
        return;
    }
    const servedAttachmentRecoveryRequested = servedAttachmentDetailGaps(args.deps.detailGaps).length > 0;
    if (servedAttachmentRecoveryRequested) {
        await recoverServedAttachmentGapsIfRequested(args.client, {
            attachmentCoverage: args.attachmentCoverage,
            detailGaps: args.deps.detailGaps,
            emitProtocol: args.emit,
            emitRecord: args.deps.emitRecord,
            hydrateAttachment: args.hydrateAttachment,
            recoveredAttachmentGapIds: args.recoveredAttachmentGapIds,
        });
        return;
    }
    const attachmentBackfillRange = selectAttachmentBackfillFetchRange({
        ...args.session,
        maxWindowUids: resolveAttachmentBackfillWindowUids(),
    });
    if (attachmentBackfillRange) {
        // Probe metadata (cheap: envelope + BODYSTRUCTURE, no body/attachment
        // bytes transferred) across the coarse range to learn each UID's known
        // attachment byte cost, then trim to a byte-cost-bounded page. The
        // durable cursor below only advances to the trimmed page's end UID,
        // not the coarse range's end — so a page that stops well short of the
        // coarse ceiling still commits correctly and the next run picks up
        // where this page left off.
        const probeMetas = await collectMetadata(args.client, attachmentBackfillRange);
        const byteBudget = resolveAttachmentBackfillPageByteBudget();
        const { backfillMetas, backfillWindowEndUid } = planAttachmentBackfillPage(probeMetas, byteBudget, Number(attachmentBackfillRange.split(":")[1]));
        await args.emit({
            type: "PROGRESS",
            stream: "attachments",
            message: `Backfilling historical attachment UIDs (${attachmentBackfillRange.split(":")[0]}:${backfillWindowEndUid}) from ${args.allMail.path}, byte budget ${byteBudget}`,
        });
        const backfillSummary = createAttachmentBackfillSummary();
        await emitMessagesPass({
            ...(args.attachmentCoverage
                ? { attachmentCoverage: args.attachmentCoverage }
                : {}),
            emitProtocol: emit,
            emitProgress: (m) => emit({ ...m, stream: "attachments" }),
            emitRecord: async (stream, data, keyField) => {
                const emitted = await args.deps.emitRecord(stream, data, keyField);
                if (stream === "attachments" && emitted === true) {
                    addAttachmentBackfillRecordToSummary(backfillSummary, data);
                }
                return emitted === true;
            },
            fetchBodies: args.fetchBodiesBound,
            hydrateAttachment: args.hydrateAttachment,
            recoveredAttachmentGapIds: args.recoveredAttachmentGapIds,
            nowIso,
            requested: new Map([["attachments", { name: "attachments" }]]),
            timeRange: args.deps.requested.get("attachments")?.time_range,
            wantBodies: false,
            wantMessages: false,
        }, backfillMetas);
        await args.emit({
            type: "PROGRESS",
            stream: "attachments",
            message: `Gmail attachment backfill summary: ${formatAttachmentBackfillSummary(backfillSummary)}`,
            count: backfillSummary.hydrated,
            total: backfillSummary.hydrated +
                backfillSummary.too_large +
                backfillSummary.failed +
                backfillSummary.unavailable_skipped,
        });
        await args.emit({
            type: "STATE",
            stream: "attachments",
            cursor: {
                all_mail: {
                    uidvalidity: args.session.uidvalidityNum,
                    backfilled_through_uid: backfillWindowEndUid,
                    completed_at: backfillWindowEndUid >= Math.max(0, args.session.priorUidnext - 1)
                        ? nowIso()
                        : null,
                },
            },
        });
    }
    else {
        await args.emit({
            type: "PROGRESS",
            stream: "attachments",
            message: `Gmail attachment backfill summary: ${formatAttachmentBackfillSummary(createAttachmentBackfillSummary())}`,
            count: 0,
            total: 0,
        });
        await args.emit({
            type: "STATE",
            stream: "attachments",
            cursor: {
                all_mail: {
                    uidvalidity: args.session.uidvalidityNum,
                    backfilled_through_uid: Math.max(0, args.session.priorUidnext - 1),
                    completed_at: nowIso(),
                },
            },
        });
    }
}
/**
 * Plan one historical attachment backfill page from probe metadata: sort
 * ascending by UID (IMAP fetch responses are not guaranteed to arrive in
 * UID order, and the trim/admission logic is a prefix walk that must
 * operate over a UID-ordered sequence — an out-of-order high UID admitted
 * first would let a `uid <= max` derivation cover the entire coarse window,
 * silently defeating the byte budget), compute each UID's cost, trim to the
 * byte budget, and derive the admitted metas + end UID positionally.
 */
function planAttachmentBackfillPage(probeMetas, byteBudget, fallbackEndUid) {
    const sortedMetas = probeMetas.slice().sort((a, b) => a.uid - b.uid);
    const candidates = sortedMetas.map((meta) => ({
        uid: meta.uid,
        attachmentBytes: attachmentBackfillCandidateCost(meta),
    }));
    const { admittedCount } = trimAttachmentBackfillPageToByteBudget(candidates, byteBudget);
    const backfillMetas = sortedMetas.slice(0, admittedCount);
    const lastAdmittedMeta = backfillMetas.at(-1);
    return {
        backfillMetas,
        backfillWindowEndUid: lastAdmittedMeta
            ? lastAdmittedMeta.uid
            : fallbackEndUid,
    };
}
/**
 * A UID with zero attachments costs nothing — it must not consume the
 * unknown-size fallback (that would starve ordinary no-attachment messages
 * down to a handful per page). A UID with one or more attachments sums each
 * attachment's known size, substituting the fixed fallback per attachment
 * whose size is unavailable, so a mix of known and unknown sizes is not
 * underestimated by silently dropping the unknown ones.
 */
function attachmentBackfillCandidateCost(meta) {
    const attachments = decodeBodystructureForAttachments(meta.bodyStructure, String(meta.emailId ?? meta.uid), perMessageInternalDateToIso(meta.internalDate, nowIso));
    return attachments.reduce((sum, a) => sum +
        (typeof a.size_bytes === "number"
            ? a.size_bytes
            : ATTACHMENT_BACKFILL_UNKNOWN_SIZE_FALLBACK_BYTES), 0);
}
function boundedHydrationError(err) {
    // Attachment downloads go over IMAP too, so the same generic
    // "Command failed" applies here — keep the server's reason, then bound it.
    const raw = describeUnexpectedFailure(err);
    return raw.slice(0, HYDRATION_ERROR_MAX_CHARS);
}
function hydrationFailureResult(attachment, status, err, failure = null) {
    return {
        failure,
        record: {
            ...attachment,
            blob_ref: null,
            content_sha256: null,
            hydration_status: status,
            hydration_error: boundedHydrationError(err),
        },
    };
}
function originalHydrationError(err) {
    return err instanceof ReferenceBlobUploadFailure && err.cause !== undefined
        ? err.cause
        : err;
}
/**
 * The MIME type to upload one attachment under, guaranteed to satisfy the blob
 * endpoint's media-type grammar.
 *
 * The candidates are tried in source-preference order (IMAP `BODYSTRUCTURE`
 * `contentType`, then the record's own `content_type`), and the FIRST VALID one
 * wins — not the first non-empty one. That distinction is the defect this
 * function fixes: the previous `a || b || DEFAULT` chain only fell through on
 * an empty value, so a non-empty but malformed type was passed straight to the
 * upload and rejected with a 400 (`mime_type must be a valid media type`).
 *
 * The real instance was `image/*`: IMAP servers may report a wildcard subtype
 * for a part whose concrete type the server declines to narrow. It is
 * non-empty, so it survived the `||` chain; `*` is outside the endpoint's
 * grammar, so every attempt failed identically. Because a 4xx is not
 * retry-convergent, the item burned its whole no-progress budget and was
 * quarantined `terminal` — which, on a REQUIRED stream with no durable
 * impossibility proof, renders the whole source as "Missing data" forever. The
 * bytes were always fetchable; only the label on them was malformed.
 *
 * Falling back to `application/octet-stream` is the honest answer for a type
 * the source would not state precisely: it claims nothing beyond "opaque
 * bytes", which is exactly what a wildcard conveyed. A parameterized type
 * (`text/plain; charset=utf-8`) stays valid — the endpoint strips parameters
 * itself, so it is passed through unchanged rather than downgraded.
 */
export function normalizeAttachmentMimeType(...candidates) {
    for (const candidate of candidates) {
        if (typeof candidate !== "string") {
            continue;
        }
        // Match the endpoint's own normalization before testing: it compares the
        // pre-`;` half, trimmed and lowercased. Testing the raw string instead
        // would reject a valid parameterized type this function must preserve.
        const mediaType = (candidate.split(";")[0] ?? "").trim().toLowerCase();
        if (mediaType && VALID_MEDIA_TYPE_PATTERN.test(mediaType)) {
            return candidate;
        }
    }
    return DEFAULT_ATTACHMENT_MIME_TYPE;
}
function hydrationFailureForBlobUpload(err) {
    if (!(err instanceof ReferenceBlobUploadFailure)) {
        return null;
    }
    switch (err.kind) {
        case "http_4xx":
            return { stage: "blob_upload_http_4xx" };
        case "http_5xx":
            return { stage: "blob_upload_http_5xx" };
        case "invalid_response":
            return { stage: "blob_upload_invalid_response" };
        case "integrity_mismatch":
            return { stage: "blob_upload_integrity_failed" };
        case "source_content_failed":
            return { stage: "imap_download_failed" };
        case "transport":
            return { stage: "blob_upload_transport_failed" };
        default:
            return null;
    }
}
/**
 * Resolve the per-attachment max byte cap from env, falling back to the
 * conservative default. Non-positive or non-numeric overrides are ignored
 * so a misconfigured env var can never silently disable the cap.
 */
export function resolveMaxAttachmentBytes(env = process.env) {
    const raw = env[MAX_ATTACHMENT_BYTES_ENV];
    if (!raw) {
        return DEFAULT_MAX_ATTACHMENT_BYTES;
    }
    if (!POSITIVE_INTEGER_PATTERN.test(raw)) {
        return DEFAULT_MAX_ATTACHMENT_BYTES;
    }
    const parsed = Number.parseInt(raw, 10);
    if (!Number.isFinite(parsed) || parsed <= 0) {
        return DEFAULT_MAX_ATTACHMENT_BYTES;
    }
    return parsed;
}
class AttachmentTooLargeError extends Error {
    constructor(observedBytes, maxBytes) {
        super(`attachment exceeds max size: ${observedBytes} > ${maxBytes} bytes`);
        this.name = "AttachmentTooLargeError";
    }
}
/**
 * Raised when an attachment transfer goes silent (no chunk received) for
 * longer than the stall budget. The message deliberately contains "timeout"
 * so `isImapTransientError` (and `handleMainRejection`'s classification) marks
 * the resulting run failure retryable without a second keyword list to keep
 * in sync.
 */
export class AttachmentStallTimeoutError extends Error {
    constructor(stallMs, observedBytes) {
        super(`attachment transfer stalled: no data for ${stallMs}ms after ${observedBytes} bytes (timeout)`);
        this.name = "AttachmentStallTimeoutError";
    }
}
/**
 * Wrap an AsyncIterable so that consumed bytes are tallied and the stream
 * aborts with `AttachmentTooLargeError` the moment it exceeds the cap.
 * Used as a defense-in-depth guard against attachments whose source size
 * is missing or under-reported.
 */
function enforceMaxBytes(content, maxBytes) {
    return {
        [Symbol.asyncIterator]() {
            const inner = content[Symbol.asyncIterator]();
            let observed = 0;
            return {
                async next() {
                    const step = await inner.next();
                    if (step.done) {
                        return step;
                    }
                    const chunk = step.value;
                    const chunkSize = typeof chunk === "string"
                        ? Buffer.byteLength(chunk)
                        : chunk.byteLength;
                    observed += chunkSize;
                    if (observed > maxBytes) {
                        if (typeof inner.return === "function") {
                            await inner.return();
                        }
                        throw new AttachmentTooLargeError(observed, maxBytes);
                    }
                    return step;
                },
                return(value) {
                    if (typeof inner.return === "function") {
                        return inner.return(value);
                    }
                    return Promise.resolve({ done: true, value });
                },
            };
        },
    };
}
/**
 * Wrap an AsyncIterable so that SILENCE (no chunk delivered) longer than
 * `stallMs` aborts the transfer, instead of a fixed total-duration cap.
 *
 * A total-duration timeout is wrong here: legitimate large attachments over
 * a slow-but-live IMAP transfer (observed live at ~4.65 KB/s — see
 * gmail-attachment-convergence-0809 root-cause notes) can honestly take many
 * minutes while still making steady progress. A stall budget only fires when
 * that progress actually STOPS, which is the real distinguishing signal
 * between "slow" and "wedged" (mirrors the test-accounting authority runner's
 * stall-vs-total-runtime distinction).
 *
 * `onStall` MUST leave the source iterable unusable afterward (e.g. by
 * force-closing the underlying IMAP connection) — imapflow has no per-command
 * cancel; the only way to unblock an abandoned in-flight FETCH is to close
 * the whole connection (see `fetchAttachmentPart`). This wrapper does not
 * call `inner.return()` on stall for that reason: the source is expected to
 * already be dead by the time `onStall` returns.
 */
function enforceStallTimeout(content, stallMs, onStall) {
    return {
        [Symbol.asyncIterator]() {
            const inner = content[Symbol.asyncIterator]();
            let observed = 0;
            return {
                async next() {
                    let timer;
                    const stalled = new Promise((_, reject) => {
                        timer = setTimeout(() => {
                            onStall();
                            reject(new AttachmentStallTimeoutError(stallMs, observed));
                        }, stallMs);
                    });
                    try {
                        const step = await Promise.race([inner.next(), stalled]);
                        if (!step.done) {
                            const chunk = step.value;
                            observed +=
                                typeof chunk === "string"
                                    ? Buffer.byteLength(chunk)
                                    : chunk.byteLength;
                        }
                        return step;
                    }
                    finally {
                        clearTimeout(timer);
                    }
                },
                return(value) {
                    if (typeof inner.return === "function") {
                        return inner.return(value);
                    }
                    return Promise.resolve({ done: true, value });
                },
            };
        },
    };
}
/**
 * Resolve the attachment stall budget from env, falling back to the
 * conservative default. Non-positive or non-numeric overrides are ignored so
 * a misconfigured env var can never silently disable the guard.
 */
export function resolveAttachmentStallTimeoutMs(env = process.env) {
    const raw = env[ATTACHMENT_STALL_TIMEOUT_MS_ENV];
    if (!(raw && POSITIVE_INTEGER_PATTERN.test(raw))) {
        return DEFAULT_ATTACHMENT_STALL_TIMEOUT_MS;
    }
    const parsed = Number.parseInt(raw, 10);
    return Number.isFinite(parsed) && parsed > 0
        ? parsed
        : DEFAULT_ATTACHMENT_STALL_TIMEOUT_MS;
}
/**
 * Resolve the in-transfer progress cadence from env. Both a minimum elapsed
 * time AND a minimum byte delta must be satisfied before a new progress
 * observation fires (see `enforceTransferProgress`) — either alone is
 * ignorable by a pathological source (a firehose of 1-byte chunks would
 * otherwise defeat a bytes-only gate; a single giant chunk every few ms
 * would defeat a time-only gate). Non-positive or non-numeric overrides fall
 * back to the default so a misconfigured env var can never turn the cadence
 * gate into a flood.
 */
const ATTACHMENT_PROGRESS_MIN_INTERVAL_MS_ENV = "PDPP_GMAIL_ATTACHMENT_PROGRESS_MIN_INTERVAL_MS";
const ATTACHMENT_PROGRESS_MIN_BYTES_ENV = "PDPP_GMAIL_ATTACHMENT_PROGRESS_MIN_BYTES";
export const DEFAULT_ATTACHMENT_PROGRESS_MIN_INTERVAL_MS = 15_000;
export const DEFAULT_ATTACHMENT_PROGRESS_MIN_BYTES = 256 * 1024;
function resolveBoundedEnvInt(raw, fallback) {
    if (!(raw && POSITIVE_INTEGER_PATTERN.test(raw))) {
        return fallback;
    }
    const parsed = Number.parseInt(raw, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
export function resolveAttachmentProgressMinIntervalMs(env = process.env) {
    return resolveBoundedEnvInt(env[ATTACHMENT_PROGRESS_MIN_INTERVAL_MS_ENV], DEFAULT_ATTACHMENT_PROGRESS_MIN_INTERVAL_MS);
}
export function resolveAttachmentProgressMinBytes(env = process.env) {
    return resolveBoundedEnvInt(env[ATTACHMENT_PROGRESS_MIN_BYTES_ENV], DEFAULT_ATTACHMENT_PROGRESS_MIN_BYTES);
}
/**
 * Wrap an AsyncIterable so that observed chunk bytes drive a cadence-gated
 * `onProgress` callback — bounded, redacted, and inert with respect to the
 * transfer itself.
 *
 * Composed OUTSIDE `enforceStallTimeout` (see `makeAttachmentHydrator`): this
 * wrapper never participates in stall detection, so nothing it does —
 * including a slow or throwing `onProgress` — can affect stall timing.
 * `onProgress` is fire-and-forget (never awaited inline in the chunk path)
 * and any error it throws is swallowed, so it cannot add latency or turn a
 * successful transfer into a failed one — the one exception is that a
 * REJECTED `onProgress` promise is still observed via `.catch()`, which is
 * enough to prevent an unhandled-rejection crash without blocking the loop.
 *
 * Cadence: an observation fires only once BOTH `minIntervalMs` elapsed AND
 * `minBytes` new bytes arrived since the last one (see
 * `resolveAttachmentProgressMinIntervalMs`/`resolveAttachmentProgressMinBytes`),
 * so a run with many small/fast attachments cannot flood the event stream —
 * most attachments will finish within one cadence window and emit only the
 * `complete` signal, never a mid-transfer one. The `complete` signal always
 * fires exactly once at end-of-stream, bypassing the cadence gate, so every
 * transfer has a coherent start-adjacent/end pair regardless of size.
 */
function enforceTransferProgress(content, args) {
    return {
        [Symbol.asyncIterator]() {
            const inner = content[Symbol.asyncIterator]();
            const startedAt = args.now();
            let observed = 0;
            let lastEmitAt = startedAt;
            let lastEmitBytes = 0;
            const safeEmit = (progress) => {
                try {
                    args.onProgress(progress);
                }
                catch {
                    // A progress observer must never be able to fail the transfer.
                }
            };
            return {
                async next() {
                    const step = await inner.next();
                    if (step.done) {
                        safeEmit({
                            bytesTransferred: observed,
                            elapsedMs: args.now() - startedAt,
                            phase: "complete",
                            totalBytes: args.totalBytes,
                        });
                        return step;
                    }
                    const chunk = step.value;
                    observed +=
                        typeof chunk === "string"
                            ? Buffer.byteLength(chunk)
                            : chunk.byteLength;
                    const nowMs = args.now();
                    if (nowMs - lastEmitAt >= args.minIntervalMs &&
                        observed - lastEmitBytes >= args.minBytes) {
                        lastEmitAt = nowMs;
                        lastEmitBytes = observed;
                        safeEmit({
                            bytesTransferred: observed,
                            elapsedMs: nowMs - startedAt,
                            phase: "transferring",
                            totalBytes: args.totalBytes,
                        });
                    }
                    return step;
                },
                return(value) {
                    if (typeof inner.return === "function") {
                        return inner.return(value);
                    }
                    return Promise.resolve({ done: true, value });
                },
            };
        },
    };
}
/** Bounded, non-secret PROGRESS text for one in-transfer observation: phase,
 *  byte counters, and elapsed time only — matches
 *  `buildServedAttachmentRecoveryProgressMessage`'s shape for the same
 *  reason (a free-text `message` that a dashboard/log can render safely). */
export function buildAttachmentTransferProgressMessage(progress) {
    const totalPart = progress.totalBytes === null ? "" : ` total_bytes=${progress.totalBytes}`;
    return `Gmail attachment transfer phase=${progress.phase} bytes_transferred=${progress.bytesTransferred}${totalPart} elapsed_ms=${progress.elapsedMs}`;
}
/** A trusted, already-known expected size only — never inferred or guessed
 *  from observed bytes. Prefers the IMAP download response's own reported
 *  size (freshest), falling back to the BODYSTRUCTURE-derived size already
 *  on the attachment record. */
function trustedAttachmentTotalBytes(downloaded, attachment) {
    if (typeof downloaded.expectedSize === "number") {
        return downloaded.expectedSize;
    }
    if (typeof attachment.size_bytes === "number") {
        return attachment.size_bytes;
    }
    return null;
}
/** Compose the size cap, stall guard, and (optional) progress observer
 *  around a downloaded attachment's content stream, in that fixed order —
 *  see `enforceTransferProgress`'s doc comment for why progress MUST wrap
 *  outside the stall guard, never inside it. Extracted from
 *  `makeAttachmentHydrator` purely to keep that closure's cognitive
 *  complexity under the repo's ceiling; behavior is unchanged. */
function composeAttachmentContentGuards(downloaded, attachment, args, resolved) {
    const sizeGuarded = enforceMaxBytes(downloaded.content, resolved.maxBytes);
    const stallGuarded = args.onStall
        ? enforceStallTimeout(sizeGuarded, resolved.stallTimeoutMs, args.onStall)
        : sizeGuarded;
    if (!args.onTransferProgress) {
        return stallGuarded;
    }
    return enforceTransferProgress(stallGuarded, {
        minBytes: resolved.progressMinBytes,
        minIntervalMs: resolved.progressMinIntervalMs,
        now: resolved.progressNow,
        onProgress: args.onTransferProgress,
        totalBytes: trustedAttachmentTotalBytes(downloaded, attachment),
    });
}
/**
 * `onStall`: called at most once if a transfer stalls past `stallTimeoutMs`.
 * MUST make the connection backing `fetchAttachment`'s returned content
 * unusable (imapflow has no per-command cancel — see `fetchAttachmentPart`),
 * so the caller is expected to treat the whole run as ending after this
 * fires. Omitted in tests that don't exercise a real IMAP connection.
 *
 * `onTransferProgress`: cadence-gated in-transfer progress (see
 * `enforceTransferProgress`). Composed OUTSIDE the stall guard: cannot
 * affect stall timing, backpressure, or error propagation. Omitted entirely
 * in tests that don't exercise it — `enforceTransferProgress` is only
 * applied when this is provided, so a caller with no progress sink pays
 * zero extra wrapping.
 */
export function makeAttachmentHydrator(args) {
    const resolved = {
        maxBytes: args.maxBytes ?? DEFAULT_MAX_ATTACHMENT_BYTES,
        progressMinBytes: args.progressMinBytes ?? DEFAULT_ATTACHMENT_PROGRESS_MIN_BYTES,
        progressMinIntervalMs: args.progressMinIntervalMs ?? DEFAULT_ATTACHMENT_PROGRESS_MIN_INTERVAL_MS,
        progressNow: args.progressNow ?? Date.now,
        stallTimeoutMs: args.stallTimeoutMs ?? DEFAULT_ATTACHMENT_STALL_TIMEOUT_MS,
    };
    return async (msg, attachment) => {
        if (typeof attachment.size_bytes === "number" &&
            attachment.size_bytes > resolved.maxBytes) {
            return hydrationFailureResult(attachment, "too_large", new AttachmentTooLargeError(attachment.size_bytes, resolved.maxBytes));
        }
        let downloaded;
        try {
            downloaded = await args.fetchAttachment(msg, attachment);
        }
        catch (err) {
            return hydrationFailureResult(attachment, "failed", err, {
                stage: "imap_download_failed",
            });
        }
        if (typeof downloaded.expectedSize === "number" &&
            downloaded.expectedSize > resolved.maxBytes) {
            return hydrationFailureResult(attachment, "too_large", new AttachmentTooLargeError(downloaded.expectedSize, resolved.maxBytes));
        }
        try {
            const guarded = composeAttachmentContentGuards(downloaded, attachment, args, resolved);
            const blobRef = await args.uploadBlob({
                content: guarded,
                connectorId: args.connectorId,
                mimeType: normalizeAttachmentMimeType(downloaded.mimeType, attachment.content_type),
                recordKey: attachment.id,
                stream: "attachments",
            });
            return {
                failure: null,
                record: {
                    ...attachment,
                    blob_ref: blobRef,
                    content_sha256: blobRef.sha256,
                    content_type: blobRef.mime_type,
                    size_bytes: blobRef.size_bytes,
                    hydration_status: "hydrated",
                    hydration_error: null,
                },
            };
        }
        catch (err) {
            const originalError = originalHydrationError(err);
            if (originalError instanceof AttachmentTooLargeError) {
                return hydrationFailureResult(attachment, "too_large", originalError);
            }
            if (originalError instanceof AttachmentStallTimeoutError) {
                // Re-thrown, not returned as an ordinary `failed` result: `onStall`
                // already closed the shared IMAP connection (imapflow has no
                // per-command cancel), so every later command in this run — the next
                // attachment, the delta pass, anything — would otherwise throw a
                // confusing "connection closed" error instead of the real cause.
                // Propagating here lets the run end cleanly through the normal
                // uncaught-rejection path (`handleMainRejection`), which classifies
                // it retryable and reports one honest reason instead of a cascade.
                throw originalError;
            }
            return hydrationFailureResult(attachment, "failed", err, hydrationFailureForBlobUpload(err));
        }
    };
}
/**
 * Download one attachment PART's bytes.
 *
 * `expectedSize` is deliberately taken from BODYSTRUCTURE (`attachment.size_bytes`)
 * and NOT from the download response's `meta.expectedSize`.
 *
 * imapflow populates `meta.expectedSize` from the FETCH `RFC822.SIZE` item
 * (`lib/imap-flow.js`: `meta = { expectedSize: response.size }`, where `size`
 * is requested as the `RFC822.SIZE` atom in `lib/commands/fetch.js`).
 * RFC822.SIZE is the size of the ENTIRE MESSAGE — every part, every MIME
 * header, every boundary — not of the part being downloaded. It is the same
 * number for every part of a multipart message.
 *
 * Feeding a message-scoped size into a per-attachment cap made a message
 * reject ALL of its attachments whenever their SUM crossed the cap, even
 * though no single one came close. Observed live on the owner's mailbox:
 * 68 attachments marked `too_large` across 18 messages, of which only 2 were
 * genuinely over the 25 MiB cap; one 3,080-byte attachment was rejected as
 * "29830196 > 26214400 bytes". Two parts of one message recorded the byte-for-byte
 * identical "observed" size — impossible for real per-part sizes, and the tell
 * that the number was never the part's.
 *
 * That number is not just a wrong skip: `isProvenUnfillableGap`
 * (`server/connector-gap-classification.ts`) parses this exact
 * "exceeds max size: <observed> > <limit>" text as DURABLE PROOF that an item
 * is permanently uncollectable. A message-scoped size therefore manufactured
 * per-item impossibility proofs for items that are collectible, which is the
 * fabricated-evidence failure that predicate exists to refuse.
 *
 * BODYSTRUCTURE's per-part `size` is the only per-part size IMAP gives us
 * before transfer, so it is the only honest pre-flight number. When it is
 * absent we report `null` (unknown) rather than substituting a
 * message-scoped stand-in: `enforceMaxBytes` still counts real bytes
 * mid-stream, so an under-reported or missing size is caught by observation
 * instead of by a guess.
 */
export async function fetchAttachmentPart(client, msg, attachment) {
    if (!msg.uid) {
        throw new Error("attachment download requires IMAP UID");
    }
    const response = (await client.download(String(msg.uid), attachment.part_index, {
        uid: true,
    }));
    return {
        content: response.content,
        expectedSize: attachment.size_bytes,
        mimeType: normalizeAttachmentMimeType(response.meta?.contentType, attachment.content_type),
    };
}
function buildRuntimeBlobUploader() {
    const rsUrl = process.env.PDPP_RS_URL || process.env.RS_URL;
    const ownerToken = process.env.PDPP_OWNER_TOKEN;
    if (!(rsUrl && ownerToken)) {
        return () => Promise.reject(new Error(BLOB_UPLOAD_ENV_ERROR));
    }
    return makeSharedReferenceBlobUploader({
        connectorInstanceId: process.env.PDPP_CONNECTOR_INSTANCE_ID || null,
        ownerToken,
        rsUrl,
    });
}
export function validateAttachmentHydrationPreflight(args) {
    const env = args.env ?? process.env;
    const hydrationRequested = args.requested.has("attachments") || shouldBackfillAttachments(args);
    if (!hydrationRequested) {
        return null;
    }
    if (!resolveGmailAddressFromEnv(env)) {
        return "Gmail attachment hydration requires GMAIL_ADDRESS or GMAIL_USER";
    }
    if (!resolveGmailPasswordFromEnv(env)) {
        return "Gmail attachment hydration requires GOOGLE_APP_PASSWORD_PDPP or GMAIL_APP_PASSWORD";
    }
    if (!sharedRuntimeBlobUploadAvailable(env)) {
        return BLOB_UPLOAD_ENV_ERROR;
    }
    return null;
}
// ─── Delta pass (flag/label changes since priorModseq) ──────────────────
/**
 * Emit flag/label changes for messages modified since `priorModseq`.
 *
 * The envelope is fetched alongside the flags. That is not an optimization —
 * it is what makes the pass safe. PDPP records are whole-document upserts
 * (`records` is keyed `UNIQUE(connector_instance_id, stream, record_key)` and
 * ingest replaces `record_json`), so emitting a partial `messages` record
 * overwrites the stored row rather than merging into it. An envelope-free
 * delta record therefore nulls `subject`, `from_email`, `date`, `size_bytes`,
 * and `snippet` on a message that had them, and sets `received_at` to the run
 * clock — silently destroying already-collected history every time a label or
 * a `\Seen` flag changes.
 *
 * A message whose envelope the server does not return is skipped rather than
 * emitted partially: losing a flag update is recoverable on the next pass,
 * losing the envelope is not.
 *
 * `fetchBodiesFn` is the same seam `processMessage` uses. Called with
 * `wantBodies: false` it fetches at most `SNIPPET_FETCH_MAX_BYTES` of the
 * plain part — enough to rebuild `snippet`, without touching the
 * externally-throttled full-body/attachment path.
 */
export async function runDeltaPass(client, session, requested, emitRecord, receivedAtFallback, fetchBodiesFn) {
    if (session.fullResync ||
        session.priorModseq === undefined ||
        session.priorModseq === null) {
        return;
    }
    const { priorModseq } = session;
    const priorModseqBig = typeof priorModseq === "bigint" ? priorModseq : BigInt(priorModseq);
    await emit({
        type: "PROGRESS",
        message: `Fetching flag/label deltas since modseq=${String(priorModseq)}`,
    });
    // `envelope`/`internalDate`/`size`/`bodyStructure` ride along with the flags
    // so the emitted record is whole. See this function's doc comment: a partial
    // record is a destructive upsert, not a cheap one. BODYSTRUCTURE is metadata
    // only — it is what `has_attachments` is derived from, and fetching it does
    // not pull attachment or body content.
    const deltaQuery = {
        uid: true,
        flags: true,
        labels: true,
        threadId: true,
        emailId: true,
        envelope: true,
        internalDate: true,
        size: true,
        bodyStructure: true,
    };
    // Phase A: drain the delta FETCH completely before issuing any other IMAP
    // command. Phase B: fetch snippets and emit.
    //
    // The split is required, not stylistic — it is the same rule the message
    // pass states at its own Phase A/B boundary: imapflow multiplexes one
    // command at a time over a single connection, so a nested command issued
    // while the outer iterator is still open hangs that iterator. Calling
    // `fetchBodiesFn` (a `fetchOne`) inside the `for await` did exactly that.
    //
    // `fetchBodies` swallows its own errors, so the nested call surfaced not as
    // a body-fetch failure but as a wedged connection: the run stopped making
    // progress after "Fetching flag/label deltas", sat until a timeout, and
    // then tripped the runtime's post-DONE guard while the abandoned iterator
    // drained. Draining first keeps the envelope guarantee below intact and
    // costs only the metadata already held in memory.
    const deltaMetas = [];
    for await (const msg of client.fetch("1:*", deltaQuery, {
        uid: true,
        changedSince: priorModseqBig,
    })) {
        if (!requested.has("messages")) {
            continue;
        }
        if (!String(msg.emailId ?? "")) {
            continue;
        }
        // No envelope means no safe record to write. Skipping preserves the
        // stored row; emitting would blank it.
        if (!msg.envelope) {
            continue;
        }
        deltaMetas.push(msg);
    }
    for (const msg of deltaMetas) {
        const gmMsgid = String(msg.emailId ?? "");
        const env = msg.envelope;
        if (!env) {
            continue;
        }
        const receivedAt = perMessageInternalDateToIso(msg.internalDate, () => receivedAtFallback);
        // Bounded snippet-only body read, exactly as the forward pass does for a
        // messages-without-bodies scope. Sequential by necessity: this is one IMAP
        // command at a time on a connection that is not concurrent.
        const { snippet } = await fetchBodiesFn(msg, selectBodyParts(msg.bodyStructure, false), false, true);
        await emitRecord("messages", buildMessageRecord({
            attachmentsCount: decodeBodystructureForAttachments(msg.bodyStructure, gmMsgid, receivedAt).length,
            dateHeader: env.date ? new Date(env.date).toISOString() : null,
            envelope: env,
            flagsArr: toFlagsArray(msg.flags),
            gmMsgid,
            gmThrid: String(msg.threadId ?? ""),
            labels: toLabelsArray(msg.labels),
            rawHeaders: msg.headers,
            receivedAt,
            sizeBytes: typeof msg.size === "number" ? msg.size : null,
            snippet,
        }));
    }
}
// ─── Threads pass ───────────────────────────────────────────────────────
async function runThreadsPass(client, fetchRange, emitRecord, cursor) {
    await emit({
        type: "PROGRESS",
        stream: "threads",
        message: "Deriving threads from All Mail",
    });
    const threadAgg = new Map();
    const threadQuery = {
        uid: true,
        threadId: true,
        emailId: true,
        envelope: true,
        flags: true,
        internalDate: true,
        // Needed for per-thread labels + has_attachments aggregation.
        labels: true,
        bodyStructure: true,
    };
    for await (const msg of client.fetch(fetchRange, threadQuery, {
        uid: true,
    })) {
        const tid = String(msg.threadId ?? "");
        if (!tid) {
            continue;
        }
        const env = msg.envelope ?? {};
        const rcv = internalDateToIso(msg.internalDate);
        const msgHasAttachments = decodeBodystructureForAttachments(msg.bodyStructure, String(msg.emailId ?? tid), rcv).length > 0;
        const next = updateThreadAggregate(threadAgg.get(tid), {
            flagsArr: toFlagsArray(msg.flags),
            hasAttachments: msgHasAttachments,
            labels: toLabelsArray(msg.labels),
            participants: envelopeParticipants(env),
            receivedAt: rcv,
            subject: env.subject || null,
            threadId: tid,
        });
        threadAgg.set(tid, next);
    }
    await emitChangedThreads(threadAgg.values(), cursor, emitRecord);
    return threadAgg.size;
}
/**
 * Gate every aggregated thread through the shared fingerprint cursor and
 * emit only the records whose semantic shape moved since the prior run.
 * Pruning stale ids is the caller's responsibility — `runThreadsPass`
 * receives one bounded UID range per scheduled run. Threads with empty ids are
 * silently dropped: the upstream IMAP loop already filters them. The caller
 * deliberately does not prune stale fingerprints on bounded pages; pruning is
 * only sound after the historical high-water boundary is complete.
 *
 * Exported so the two-pass churn invariant can be exercised without
 * standing up an IMAP fixture.
 */
export async function emitChangedThreads(aggregates, cursor, emitRecord) {
    for (const agg of aggregates) {
        const record = buildThreadRecord(agg);
        if (!cursor.shouldEmit(record)) {
            continue;
        }
        await emitRecord("threads", record);
    }
}
/**
 * Parse the prior `threads` STATE cursor's `thread_fingerprints` map.
 * Tolerant of:
 *   - missing/legacy cursors (no fingerprints field)
 *   - malformed entries (non-string values silently dropped)
 *   - state from a different schema (best-effort coercion)
 * The returned map is always safe to read; on legacy input it is empty
 * and the next run re-emits every thread once (the normal one-time
 * cost of the cursor's introduction).
 */
export function readPriorThreadFingerprints(state) {
    const out = new Map();
    const streamState = state.threads;
    if (!streamState ||
        typeof streamState !== "object" ||
        Array.isArray(streamState)) {
        return out;
    }
    const raw = streamState.thread_fingerprints;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
/**
 * Drive Pass 1 (new messages or full resync), Pass 2 (flag/label deltas),
 * threads aggregation, and the final STATE emit — all inside the mailbox
 * lock. The list-mailbox lookup happens in `main()` before entering here.
 */
export async function runAllMailPasses(client, allMail, state, deps) {
    const { mailbox } = client;
    if (!mailbox) {
        fail("mailbox not selected after lock");
        return;
    }
    const session = deriveAllMailSession(mailbox, state);
    if (!session) {
        fail("missing UIDVALIDITY on All Mail mailbox");
        return;
    }
    // Forward progress and historical progress are separate. A first run has no
    // forward range: it receives one bounded historical UID page below.
    const timeRange = deps.requested.get("messages")?.time_range ||
        deps.requested.get("attachments")?.time_range;
    const messageHistoryRequested = deps.requested.has("messages") ||
        deps.requested.has("message_bodies") ||
        deps.requested.has("attachments") ||
        deps.requested.has("threads");
    const forwardFetchRange = selectAllMailFetchRange(session, deps.requested);
    // Where the forward walk resumes on the NEXT run, and therefore the last UID
    // it will not fetch. The historical walk must own everything up to here or
    // the interval between the two belongs to neither (see
    // `resolveMessagesBackfillTargetUid`).
    //
    // On a full resync there is no forward range at all: the forward watermark
    // below is written from the live `uidnext` without a single UID having been
    // walked, so the ENTIRE mailbox below it is historical work and the ceiling
    // must say so. Reading the same `session.uidnext` the watermark is written
    // from is what keeps the two pointers describing one space.
    const forwardFloorUid = Math.max(0, (session.uidnext ?? session.priorUidnext) - 1);
    const historicalTargetUid = resolveMessagesBackfillTargetUid({
        forwardFloorUid,
        prior: session.messagesBackfill,
    });
    const historicalCursor = {
        ...session.messagesBackfill,
        backfilled_through_uid: session.messagesBackfill.backfilled_through_uid ?? 0,
        completed_at: session.messagesBackfill.completed_at ?? null,
        target_uid: historicalTargetUid,
        uidvalidity: session.uidvalidityNum,
    };
    const historicalFetchRange = messageHistoryRequested
        ? selectMessagesBackfillFetchRange({
            messagesBackfill: historicalCursor,
            uidnext: session.uidnext,
            uidvalidity: session.uidvalidityNum,
            maxWindowUids: resolveMessagesBackfillWindowUids(),
        })
        : null;
    // Parse declared collection_scope.since into IMAP date format (day-granular)
    // for the bounded SINCE search criterion, and keep the exact ISO for
    // post-filtering to honor time-of-day precision.
    const sinceDate = timeRange?.since ? isoToImapDate(timeRange.since) : null;
    const sinceIso = timeRange?.since ?? null;
    const attachmentBackfillRequested = shouldBackfillAttachments({
        attachmentBackfill: session.attachmentBackfill,
        detailGaps: deps.detailGaps,
        priorUidnext: session.priorUidnext,
        streamsToBackfill: deps.streamsToBackfill,
    });
    const servedAttachmentRecoveryRequested = servedAttachmentDetailGaps(deps.detailGaps).length > 0;
    const fetchBodiesBound = (msg, selection, wantBodies, wantMessages) => fetchBodies(client, msg, selection, wantBodies, wantMessages);
    const hydrateAttachment = makeAttachmentHydrator({
        connectorId: process.env.PDPP_CONNECTOR_ID || DEFAULT_GMAIL_CONNECTOR_ID,
        fetchAttachment: (msg, attachment) => fetchAttachmentPart(client, msg, attachment),
        maxBytes: resolveMaxAttachmentBytes(),
        // imapflow has no per-command cancel (see `AttachmentStallTimeoutError`
        // doc comment): the only way to unblock a stalled FETCH is to close the
        // whole connection. That's a whole-run failure, not a per-attachment one
        // — but it's a RETRYABLE one (message contains "timeout", matched by
        // `isImapTransientError` in `handleMainRejection`), and every record this
        // run already emitted (labels/threads/prior attachments) is durable, and
        // the messages STATE cursor only commits at the very end of
        // `runAllMailPasses` — so the next run resumes cleanly rather than
        // silently poisoning a completed stream.
        onStall: () => client.close(),
        stallTimeoutMs: resolveAttachmentStallTimeoutMs(),
        // Fire-and-forget by construction (`enforceTransferProgress` calls this
        // synchronously and never awaits it) — a slow or failed PROGRESS emit can
        // never add latency to the transfer or turn it into a failure. `.catch()`
        // only prevents an unhandled-rejection crash; it changes nothing about
        // whether the attachment itself succeeds.
        onTransferProgress: (progress) => {
            emit({
                type: "PROGRESS",
                stream: "attachments",
                message: buildAttachmentTransferProgressMessage(progress),
            }).catch(() => undefined);
        },
        progressMinBytes: resolveAttachmentProgressMinBytes(),
        progressMinIntervalMs: resolveAttachmentProgressMinIntervalMs(),
        uploadBlob: buildRuntimeBlobUploader(),
    });
    // Accumulate honest attachments detail-coverage across BOTH the primary pass
    // and the historical backfill pass below, so a single DETAIL_COVERAGE can
    // report considered-vs-hydrated for every attachment this run attempted.
    // Only when `attachments` is in scope — otherwise no hydration attempts run
    // and there is no denominator to report.
    const wantsAttachments = deps.requested.has("attachments") ||
        attachmentBackfillRequested ||
        servedAttachmentRecoveryRequested;
    const attachmentCoverage = wantsAttachments
        ? makeAttachmentDetailCoverage()
        : undefined;
    const recoveredAttachmentGapIds = new Set();
    if (deps.recoveryOnly === true) {
        if (servedAttachmentRecoveryRequested) {
            await runAttachmentBackfillAndRecoveryPass({
                allMail,
                attachmentBackfillRequested,
                attachmentCoverage,
                client,
                deps,
                emit,
                fetchBodiesBound,
                hydrateAttachment,
                recoveredAttachmentGapIds,
                recoveryOnly: true,
                session,
            });
            // Recovery-only mode touches exactly the served gaps it was handed and
            // returns before the ordinary Gmail walk, so it never establishes a
            // mailbox boundary — its counts describe a retry list, not an inventory.
            // It still emits its DETAIL_GAPs below; only the coverage CLAIM is
            // withheld (see `attachmentsCoverageBoundaryEstablished`).
            await emitAttachmentDetailCoverage(attachmentCoverage, false);
            await emitAttachmentDetailGaps(attachmentCoverage);
        }
        return;
    }
    let fetchProgressMessage = "No Gmail message UID work is pending";
    if (historicalFetchRange) {
        fetchProgressMessage = `Fetching bounded historical messages (${historicalFetchRange}) from ${allMail.path}`;
    }
    else if (forwardFetchRange) {
        fetchProgressMessage = `Fetching new messages (${forwardFetchRange}) from ${allMail.path}`;
    }
    await emit({ type: "PROGRESS", message: fetchProgressMessage });
    // Phase A: pull all metadata into an array up-front.
    // Phase B: for each metadata row, do any additional IMAP commands
    // (body fetches) we need — we cannot issue other IMAP commands WHILE the
    // outer fetch iterator is still open, because imapflow multiplexes one
    // command at a time over a single connection and a nested call hangs the
    // outer iterator.
    // THREADS stream first (parent-first convention, Tranche C 2026-04-23).
    // Threads is derived from its own `1:*` IMAP fetch that aggregates by
    // thread_id — it doesn't depend on the per-message body pass below, so
    // emitting it first gives downstream consumers the parent record before
    // any message records arrive. The cost is one extra IMAP round-trip
    // before the message pass can start; that's already how it ran anyway
    // (this fetch happened at the end before the reorder), so no throughput
    // change.
    if (deps.requested.has("threads")) {
        // Per-thread fingerprint cursor via the shared helper. The prior STATE
        // shape (`state.threads.thread_fingerprints`) predates the helper's
        // default `fingerprints` key, so the prior map is decoded by the
        // gmail-local reader and handed in via `priorFingerprints`. The
        // cursor still seeds its next map from the prior so threads we skip
        // emitting carry their fingerprint forward unchanged.
        const threadCursor = openFingerprintCursor(state, {
            priorFingerprints: readPriorThreadFingerprints(state),
        });
        const threadRanges = [historicalFetchRange, forwardFetchRange].filter((range) => range !== null);
        let historicalThreadItemsConsidered = 0;
        for (const threadRange of threadRanges) {
            const considered = await runThreadsPass(client, threadRange, deps.emitRecord, threadCursor);
            if (threadRange === historicalFetchRange) {
                historicalThreadItemsConsidered = considered;
            }
        }
        // The threads STATE cursor carries the next-run fingerprint map.
        // Emitted here (inside the mailbox lock) so it's persisted right
        // after the threads pass and before the messages pass; if the
        // messages pass crashes, the threads cursor still holds and we
        // don't re-emit every thread on retry.
        await emit({
            type: "STATE",
            stream: "threads",
            cursor: {
                fetched_at: nowIso(),
                thread_fingerprints: threadCursor.toState(),
            },
        });
        if (historicalFetchRange) {
            const historicalPageEndUid = Number(historicalFetchRange.split(":")[1]);
            await emit(buildDetailCoverageMessage({
                considered: historicalThreadItemsConsidered,
                covered: historicalThreadItemsConsidered,
                hydratedKeys: [],
                requiredKeys: [],
                stateStream: "threads",
                stream: "threads",
            }));
            if (historicalPageEndUid < historicalTargetUid) {
                await emitHistoricalContinuationSkip(emit, "threads", {
                    boundary: String(historicalCursor.uidvalidity),
                    considered: historicalThreadItemsConsidered,
                    covered: historicalThreadItemsConsidered,
                    slice_start: Number(historicalFetchRange.split(":")[0]),
                    slice_end: historicalPageEndUid,
                });
            }
        }
    }
    const historicalMetas = [];
    const forwardMetas = [];
    const metas = [];
    if (historicalFetchRange) {
        historicalMetas.push(...(await collectMetadata(client, historicalFetchRange, sinceDate, sinceIso)));
    }
    if (forwardFetchRange) {
        forwardMetas.push(...(await collectMetadata(client, forwardFetchRange, sinceDate, sinceIso)));
    }
    metas.push(...historicalMetas, ...forwardMetas);
    await emit({
        type: "PROGRESS",
        stream: "messages",
        message: `Collected ${metas.length} headers; beginning body pass`,
    });
    await emitAllMailInventoryDisclosure(emit, session, historicalCursor, forwardFloorUid);
    const perMessageDeps = {
        ...(attachmentCoverage ? { attachmentCoverage } : {}),
        emitProtocol: emit,
        emitProgress: (m) => emit(m),
        emitRecord: deps.emitRecord,
        failOnError: false,
        fetchBodies: fetchBodiesBound,
        hydrateAttachment,
        recoveredAttachmentGapIds,
        nowIso,
        uploadBodyBlob: buildRuntimeBlobUploader(),
        requested: deps.requested,
        timeRange,
        wantBodies: deps.requested.has("message_bodies"),
        wantMessages: deps.requested.has("messages"),
    };
    const historicalMessageCoverage = await emitMessagesPass({ ...perMessageDeps, failOnError: historicalFetchRange !== null }, historicalMetas);
    const forwardMessageCoverage = await emitMessagesPass(perMessageDeps, forwardMetas);
    // `message_bodies` deliberately emits NO DETAIL_COVERAGE. The manifest
    // declares it `state_stream: messages`, i.e. a static single-parent detail
    // stream, and such a stream's checkpoint status is projected from the
    // declared parent's own commit outcome — the runtime rejects the run
    // outright if it emits coverage of its own
    // (`validateDetailCoverageAgainstManifest`).
    //
    // It could not honestly emit one anyway. The numbers available here are the
    // *parent* pass's considered/covered — how many MESSAGES were walked, not
    // how many bodies were hydrated against a per-key denominator. Re-reporting
    // the parent's counts under the body stream's name is the `covered ==
    // considered` fabrication this codebase has worked to eliminate: it would
    // claim every walked message proved a body, including the ones whose body
    // fetch was skipped or failed. `attachments` is the contrast — it earns its
    // coverage from a real attempt-per-key tally (see
    // `emitAttachmentDetailCoverage`), which is why it may emit at all.
    await runAttachmentBackfillAndRecoveryPass({
        allMail,
        attachmentBackfillRequested,
        attachmentCoverage,
        client,
        deps,
        emit,
        fetchBodiesBound,
        hydrateAttachment,
        recoveredAttachmentGapIds,
        recoveryOnly: false,
        session,
    });
    // Emit the per-run attachments coverage report after every attachments
    // record (primary pass + historical backfill) has settled and before the
    // messages STATE cursor commits — the ordering the progress-evidence
    // contract expects (records, then DETAIL_COVERAGE, then STATE).
    await emitAttachmentDetailCoverage(attachmentCoverage, attachmentsCoverageBoundaryEstablished(session));
    // Then one matching DETAIL_GAP per failed attachment, so the commit-gate can
    // credit each gap_keys entry against a durable pending gap. Without this the
    // gate aborts an otherwise-successful run and the messages cursor never
    // advances, re-fetching the same window every run.
    await emitAttachmentDetailGaps(attachmentCoverage);
    // Pass 2: detect flag/label changes on already-seen messages (incremental only)
    await runDeltaPass(client, session, deps.requested, deps.emitRecord, deps.emittedAt, fetchBodiesBound);
    if (messageHistoryRequested && historicalFetchRange) {
        const historicalPageEndUid = Number(historicalFetchRange.split(":")[1]);
        // Sums BOTH passes, like the `message_bodies` DETAIL_COVERAGE above: the
        // forward pass runs in the same call to `runAllMailPasses` and emits its
        // own `messages` records via the same shared `emitRecord`, so the raw
        // collected-record count already includes them. Reporting only
        // `historicalMessageCoverage` undercounted the denominator against that
        // total every scheduled run with new mail waiting alongside a pending
        // historical backfill.
        //
        // Both emissions below MUST read these same two numbers. The runtime's
        // `isHealthyBoundedContinuation` accepts a bounded page only when the
        // continuation's considered/covered are identical to the DETAIL_COVERAGE
        // fact's — it binds a continuation to complete *same-page* facts, and the
        // summing above is what defines "the page" here. Feeding the continuation
        // historical-only counts desyncs the pair by exactly the forward-pass
        // count, the identity check fails, and the stream degrades to a
        // retryable_gap instead of deriving complete. The sibling `threads`
        // emission never desyncs precisely because it feeds one variable to both.
        const messagesCoverage = {
            considered: historicalMessageCoverage.considered +
                forwardMessageCoverage.considered,
            covered: historicalMessageCoverage.covered + forwardMessageCoverage.covered,
        };
        await emit(buildDetailCoverageMessage({
            considered: messagesCoverage.considered,
            covered: messagesCoverage.covered,
            hydratedKeys: [],
            requiredKeys: [],
            stateStream: "messages",
            stream: "messages",
        }));
        if (historicalPageEndUid < historicalTargetUid) {
            await emitHistoricalContinuationSkip(emit, "messages", {
                boundary: String(historicalCursor.uidvalidity),
                considered: messagesCoverage.considered,
                covered: messagesCoverage.covered,
                slice_start: Number(historicalFetchRange.split(":")[0]),
                slice_end: historicalPageEndUid,
            });
        }
    }
    // Keep the cursor value (possibly string if out of safe-integer range) on STATE.
    let nextMessagesBackfill = null;
    if (messageHistoryRequested) {
        if (historicalFetchRange) {
            nextMessagesBackfill = advanceMessagesBackfillCursor({
                now: nowIso(),
                pageEndUid: Number(historicalFetchRange.split(":")[1]),
                prior: historicalCursor,
            });
        }
        else if (historicalCursor.completed_at === null) {
            nextMessagesBackfill = advanceMessagesBackfillCursor({
                now: nowIso(),
                pageEndUid: historicalTargetUid,
                prior: historicalCursor,
            });
        }
        else {
            // A completed walk with no fetch range left. This is reachable only when
            // the ceiling did NOT move — `historicalTargetUid` is raised before the
            // range is selected, so any reopened band yields a non-null range and is
            // handled by the branch above. With an unchanged ceiling this cursor is
            // already at its target, so carrying it forward is exact.
            nextMessagesBackfill = historicalCursor;
        }
    }
    const nextForwardUidnext = session.uidnext;
    const nextUidnext = nextMessagesBackfill && nextMessagesBackfill.completed_at === null
        ? (nextMessagesBackfill.backfilled_through_uid ?? 0) + 1
        : nextForwardUidnext;
    await emit({
        type: "STATE",
        stream: "messages",
        cursor: {
            all_mail: {
                uidvalidity: session.uidvalidityNum,
                uidnext: nextUidnext,
                forward_uidnext: nextForwardUidnext,
                highest_modseq: session.highestModseqCursor ?? null,
                // Carry the mailbox's own EXISTS forward so the next run in this epoch
                // can prove the inventory did not shrink underneath us.
                exists: session.existsTotal,
            },
            ...(nextMessagesBackfill ? { backfill: nextMessagesBackfill } : {}),
        },
    });
}
// ─── emitRecord factory ─────────────────────────────────────────────────
function makeEmitRecord(resFilters, emittedAt, incTotal) {
    return async (stream, data, keyField = "id") => {
        const keyCandidate = data[keyField] ?? data.name;
        if (keyCandidate == null) {
            return false;
        }
        const canonical = String(keyCandidate);
        const resSet = resFilters.get(stream);
        if (resSet && !resSet.has(canonical)) {
            return false;
        }
        // Validate record against schema.
        const validation = validateRecord(stream, data);
        if (!validation.ok) {
            await emit({
                type: "SKIP_RESULT",
                stream,
                reason: "schema_validation_failed",
                message: `${stream} ${canonical}: ${validation.issues.map((i) => `${i.path}: ${i.message}`).join("; ")}`,
                diagnostics: { issues: validation.issues },
            });
            return false;
        }
        await emit({
            type: "RECORD",
            stream,
            key: canonical,
            data: validation.data,
            emitted_at: emittedAt,
        });
        incTotal();
        return true;
    };
}
// ─── Main ──────────────────────────────────────────────────────────────
async function main() {
    const startMsg = await readStartMessage(getReadline());
    if (startMsg.type !== "START") {
        fail("Expected START");
        return;
    }
    const password = await resolvePassword();
    if (!password) {
        // resolvePassword already calls fail() on error path; the early-fail
        // exits the process, so reaching here means the prompt returned null.
        fail("no Gmail app password provided");
        return;
    }
    const address = await resolveAddress();
    if (!address) {
        fail("no Gmail address provided");
        return;
    }
    const requested = new Map((startMsg.scope?.streams || []).map((s) => [s.name, s]));
    if (!requested.size) {
        fail("START.scope.streams is required");
        return;
    }
    const recoveryOnly = startMsg.recovery_only === true;
    const preflightError = validateAttachmentHydrationPreflight({
        detailGaps: startMsg.detail_gaps,
        requested,
        streamsToBackfill: startMsg.streamsToBackfill,
    });
    if (preflightError) {
        fail(preflightError);
        return;
    }
    const resFilters = new Map();
    for (const [n, r] of requested) {
        resFilters.set(n, resourceSet(r));
    }
    const state = startMsg.state ?? {};
    const emittedAt = nowIso();
    let totalEmitted = 0;
    const emitRecord = makeEmitRecord(resFilters, emittedAt, () => {
        totalEmitted += 1;
    });
    const client = new ImapFlow({
        host: "imap.gmail.com",
        port: 993,
        secure: true,
        auth: { user: address, pass: password },
        logger: false,
    });
    await client.connect();
    try {
        await emit({
            type: "PROGRESS",
            message: `Connected to ${redactEmailForProgress(address)}`,
        });
        if (requested.has("labels") && !recoveryOnly) {
            await emitLabelsStream(client, emitRecord, state);
        }
        const allMail = await findAllMailbox(client);
        if (!allMail) {
            fail("could not find [Gmail]/All Mail mailbox; is this a Gmail account?");
            return;
        }
        const lock = await client.getMailboxLock(allMail.path);
        try {
            await runAllMailPasses(client, allMail, state, {
                emitRecord,
                emittedAt,
                detailGaps: startMsg.detail_gaps,
                recoveryOnly,
                requested,
                streamsToBackfill: startMsg.streamsToBackfill,
            });
        }
        finally {
            lock.release();
        }
    }
    finally {
        await client.logout().catch(() => undefined);
    }
    await emit({
        type: "DONE",
        status: "succeeded",
        records_emitted: totalEmitted,
    });
    flushAndExit(0);
}
// Named (not inline) so its own internal `emit(...).catch(...)` isn't a
// promise chain nested inside another chain's callback.
function handleMainRejection(e) {
    // imapflow raises a bare `new Error("Command failed")` for EVERY IMAP NO/BAD
    // response and puts the server's actual explanation on side fields. Reading
    // `.message` alone made a revoked app password, a rate limit, and IMAP being
    // disabled all arrive as the same contentless string. This path emits DONE
    // directly, so it has to do that extraction itself rather than inheriting the
    // runtime's.
    const msg = describeUnexpectedFailure(e);
    const retryable = isImapTransientError(e);
    const trace = e instanceof Error ? (e.stack ?? msg) : msg;
    process.stderr.write(`[gmail] main rejected: ${trace}\n`);
    emit({
        type: "DONE",
        status: "failed",
        records_emitted: 0,
        error: { message: msg, retryable },
    }).catch(() => undefined);
    flushAndExit(1);
}
// Guarded so `import "./index.ts"` in tests doesn't spin up the runtime
// (process-level handlers, stdin reader, IMAP connect) and block the
// Node event loop. Only fires when this module IS the process entry
// point (i.e. `tsx connectors/gmail/index.ts`).
if (isMainModule(import.meta.url)) {
    process.on("unhandledRejection", (reason) => {
        const msg = reason instanceof Error
            ? (reason.stack ?? reason.message)
            : String(reason);
        process.stderr.write(`[gmail] unhandledRejection: ${msg}\n`);
        const summary = reason instanceof Error ? reason.message : String(reason);
        emit({
            type: "DONE",
            status: "failed",
            records_emitted: 0,
            error: {
                message: `unhandledRejection: ${summary.slice(0, ERROR_MSG_TAIL)}`,
                retryable: false,
            },
        }).catch(() => undefined);
        flushAndExit(1);
    });
    process.on("uncaughtException", (err) => {
        const msg = err.stack ?? err.message;
        process.stderr.write(`[gmail] uncaughtException: ${msg}\n`);
        emit({
            type: "DONE",
            status: "failed",
            records_emitted: 0,
            error: {
                message: `uncaughtException: ${err.message.slice(0, ERROR_MSG_TAIL)}`,
                retryable: false,
            },
        }).catch(() => undefined);
        flushAndExit(1);
    });
    main().catch(handleMainRejection);
}
