#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * PDPP Amazon Connector (v0.1.0) — scaffolded 2026-04-19, BLOCKED on 2FA.
 *
 * Uses the shared Playwright persistent profile. Two-level session probe:
 * (1) nav greeting check, (2) deep check by navigating to /your-orders.
 *
 * Port of selectors from ~/code/data-connectors/amazon/amazon-playwright.js
 * (492 lines), cleaned to PDPP semantics:
 *   - No global `page` coupling
 *   - Emits RECORDs per Collection Profile (orders + order_items streams)
 *   - State per year (year-freezing incremental strategy)
 *   - Sequential, humanlike pacing (2s between navigations)
 *
 * Auth: relies on the bootstrapped profile (the owner logs in once via bootstrap).
 * On session expiry, emits INTERACTION kind=manual_action with sign-in URL.
 */
import { isMainModule } from "@pdpp/connector-protocol";
import pRetry, { AbortError } from "p-retry";
import { AMAZON_LOGIN_FIELDS, ensureAmazonSession, } from "../../src/auto-login/amazon.js";
import { resolveLoginCredentials } from "../../src/auto-login/login-credentials.js";
import { emitDetailCoverage, nowIso, politeDelay, runConnector, } from "../../src/connector-runtime.js";
import { openFingerprintCursor, recordFingerprint, } from "../../src/fingerprint-cursor.js";
import { walkPagesWithCeiling } from "../../src/page-ceiling.js";
import { buildOrderItemRecord, buildOrderRecord, countOrderCardsWithoutOrderId, mergeOrderItems, parseOrderDate, parseOrderDetailDom, parseOrdersListDom, } from "./parsers.js";
import { listPageOrderShape, validateRecord } from "./schemas.js";
/**
 * Parse the prior `orders` STATE cursor's `fingerprints` map. Keyed by the
 * order record `id` (the Amazon order id). The cursor is `{ years,
 * fingerprints }`; `collect()` reads `state.orders.fingerprints`. Legacy
 * cursors (only `{ years }`) decode to an empty map, so the first
 * post-deploy run rebuilds the map and re-emits every re-scraped order
 * exactly once.
 */
function readPriorOrderFingerprints(state) {
    const streamState = (state.orders ?? {});
    const raw = streamState.fingerprints;
    const out = new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
/**
 * Parse the prior `orders` STATE cursor's `hydratedOrders` map into a
 * `Map<orderId, listSurfaceFingerprint>`. Tolerant of every prior shape:
 *
 *   - missing / non-object `hydratedOrders`  -> empty map
 *   - a legacy `hydratedOrderIds: string[]` (pre-fingerprint cursor shape,
 *     no per-order fingerprint recorded)     -> empty map
 *   - an entry whose value is not a non-empty string (missing fingerprint)
 *                                             -> that entry dropped
 *
 * In every tolerant case the order is simply absent from the returned map,
 * which `processListOrder` treats as "unknown list surface" — one honest
 * re-fetch, self-healing from that run onward. This mirrors the same
 * legacy-cursor tolerance `readPriorOrderFingerprints` already applies.
 */
function readPriorHydratedOrders(state) {
    const streamState = (state.orders ?? {});
    const raw = streamState.hydratedOrders;
    const out = new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
/** Owner-facing message for the one classification whose whole point is to be
 *  read by a person. Says exactly what was observed and what was NOT
 *  concluded: neither selector drift nor a bot block is established, so
 *  neither is named. Stored records are untouched — this connector never
 *  deletes, tombstones, or overwrites on an empty page; it only declines to
 *  advance the year cursor. */
export const AMAZON_EMPTY_AFTER_PRIOR_ORDERS_MESSAGE = "Amazon reported no order history for a year in which PDPP previously collected orders. " +
    "Your stored orders are retained and untouched. This run was stopped instead of recording " +
    "an empty history, because a page showing no orders cannot prove those orders are gone.";
// Navigation timeouts + pacing knobs
const NAV_TIMEOUT_MS = 30_000;
const DEEP_PROBE_WAIT_MS = 15_000;
const DETAIL_WAIT_MS = 15_000;
const PAGE_CONTENT_TIMEOUT_MS = 10_000;
const LIST_PAGE_WAIT_MS = 10_000;
const PAGE_LIMIT = 50;
const START_INDEX_STEP = 10;
const POLITE_DELAY_MS = 800;
const RETRY_MIN_TIMEOUT_MS = 1500;
const RETRY_FACTOR = 2;
const RETRY_COUNT = 2;
// Keep optional detail enrichment comfortably below the controller watchdog;
// recovery-only runs can drain the durable gaps without re-walking the list.
const MAX_DETAIL_ATTEMPTS_PER_RUN = 200;
const MAX_TEMPORARY_DETAIL_FAILURES_PER_RUN = 3;
// Module-scoped regexes (Biome useTopLevelRegex)
const RETRYABLE_ERROR_RE = /timeout|ECONN|ETIMEDOUT|net::|5\d\d/i;
const SIGNIN_URL_RE = /\/ap\/(signin|challenge|mfa)/;
const ORDERS_URL_RE = /\/your-orders|\/order-history/;
const YEAR_VALUE_RE = /year-(\d{4})/;
const DETAIL_URL_RE = /\/(?:gp\/your-account|fopo|uff\/your-account)\/order-details/;
export const AMAZON_NO_ORDERS_TEXT_PATTERN = String.raw `you have not placed any orders|no orders found|0\s+orders\s+placed\s+in|looks like you didn['’]t place an order in`;
export function reasonForDetailFailure(kind) {
    switch (kind) {
        case "navigation_retry_exhausted":
            return "retry_exhausted";
        case "deferred_budget":
            return "retry_exhausted";
        case "parse_missing":
        case "redirected_non_detail":
        case "session_repair_required":
            return "temporary_unavailable";
        default:
            return "temporary_unavailable";
    }
}
/**
 * Map an Amazon detail failure kind to its connector-neutral recovery class.
 * Pure and exhaustive so the classification can be unit-tested without driving
 * the browser and so a newly added failure kind is a compile error until it is
 * classified.
 *
 * NOTE ON `parse_missing`: a single parse-missing attempt is `transient_no_progress`,
 * not `connector_defect`. Whether *repeated* deterministic no-progress becomes a
 * durable connector defect is a runtime decision (per-item attempt budget +
 * terminal-gap classifier), not a per-attempt connector call. See the recovery
 * governor design D4/D10 and the runtime dependency noted in the change report.
 */
export function classifyAmazonDetailFailure(kind) {
    switch (kind) {
        case "deferred_budget":
            return "run_cap_deferred";
        case "session_repair_required":
            return "owner_repair_required";
        case "navigation_retry_exhausted":
        case "parse_missing":
        case "redirected_non_detail":
            return "transient_no_progress";
        default:
            return "transient_no_progress";
    }
}
function classForDetailFailure(kind) {
    return classifyAmazonDetailFailure(kind);
}
export async function readPageContentWithin(page, timeoutMs = PAGE_CONTENT_TIMEOUT_MS) {
    let timer = null;
    try {
        return await Promise.race([
            page.content(),
            new Promise((_resolve, reject) => {
                timer = setTimeout(() => {
                    reject(new Error(`page_content_timeout after ${timeoutMs}ms`));
                }, timeoutMs);
            }),
        ]);
    }
    finally {
        if (timer) {
            clearTimeout(timer);
        }
    }
}
// ─── Session probes ──────────────────────────────────────────────────────
async function deepSessionCheck(page) {
    await page.goto("https://www.amazon.com/your-orders/orders", {
        waitUntil: "domcontentloaded",
        timeout: NAV_TIMEOUT_MS,
    });
    // Wait for either the orders page to render or a sign-in form (both are
    // valid post-nav states; we branch on them).
    await page
        .locator('form[name="signIn"], #orderTypeMenuContainer, #yourOrdersHeader, [data-component="orderCardList"]')
        .first()
        .waitFor({ state: "attached", timeout: DEEP_PROBE_WAIT_MS })
        .catch(() => undefined);
    const url = page.url();
    if (SIGNIN_URL_RE.test(url)) {
        return false;
    }
    const loginForm = await page
        .locator('form[name="signIn"]')
        .first()
        .isVisible()
        .catch(() => false);
    if (loginForm) {
        return false;
    }
    return ORDERS_URL_RE.test(url);
}
// ─── Year discovery & pagination ─────────────────────────────────────────
async function discoverYears(page) {
    // Try select#time-filter first, then link patterns.
    const fromSelect = await page
        .evaluate(() => {
        const sel = document.querySelector("select#time-filter") ||
            document.querySelector('select[name="timeFilter"]');
        if (!sel) {
            return [];
        }
        return [...sel.options].map((o) => o.value).filter(Boolean);
    })
        .catch(() => []);
    const fromLinks = await page
        .evaluate(() => {
        const links = [
            ...document.querySelectorAll('a[href*="timeFilter=year-"]'),
        ];
        return links
            .map((a) => a.getAttribute("href"))
            .filter((v) => Boolean(v));
    })
        .catch(() => []);
    const years = new Set();
    for (const v of [...fromSelect, ...fromLinks]) {
        const m = YEAR_VALUE_RE.exec(v);
        if (m?.[1]) {
            years.add(Number(m[1]));
        }
    }
    const current = new Date().getFullYear();
    if (years.size === 0) {
        years.add(current);
    }
    return [...years].sort((a, b) => b - a); // newest first
}
// ─── Per-order detail fetch ──────────────────────────────────────────────
// Scrapes /gp/your-account/order-details?orderID=<ID> using Amazon's own
// `data-component` attributes (English-in-code on every locale) rather
// than regexing concatenated innerText. See docs/reference/connector-authoring-guide.md
// §2 for why structure > text.
//
// DOM contract used (stable on Amazon across layouts since ≥2023):
//   [data-component="shippingAddress"]          → recipient + address (clean <ul><li>)
//   [data-component="viewPaymentPlanSummaryWidget"] → payment method
//   [data-component="chargeSummary"]            → Order Summary incl. Grand Total
//   [data-component="purchasedItemsRightGrid"]  → one per item; wraps itemTitle/orderedMerchant/unitPrice
//   [data-component="itemTitle"]                → product name (no cruft)
//   [data-component="orderedMerchant"]          → "Sold by: <seller>"
//   [data-component="unitPrice"]                → "$15.54 $15.54" (accessibility double)
//   [data-component="cancelled"]                → present+non-empty only on cancelled orders
//   .od-item-view-qty span                      → quantity (present only when qty>1)
//   [data-component="itemConnections"]          → cross-sell buttons (EXCLUDED from names)
//
// Fallback path: if no [data-component] attributes exist (hypothetical
// older layouts or post-A/B rollback), return null — the list-page
// record stands alone rather than risking corrupt structural-less parse.
//
// Cancelled orders have [data-component="cancelled"] with "This order has
// been cancelled" text and NO other structural fields. We detect and
// emit status_detail only.
async function fetchOrderDetail(page, orderId) {
    const url = `https://www.amazon.com/gp/your-account/order-details?orderID=${orderId}`;
    // Retry transient navigation failures (network, timeout, 5xx) with
    // exponential backoff. AbortError bypasses retries — we use it for the
    // "Amazon redirected us to a non-detail URL" signal. Valid alternate
    // detail surfaces (for example /uff/... order cards) are handled below.
    try {
        await pRetry(async () => {
            await page.goto(url, {
                waitUntil: "domcontentloaded",
                timeout: NAV_TIMEOUT_MS,
            });
            // Wait for the known detail page signatures. waitForSelector replaces
            // `await sleep(800)` — real sync primitive instead of a pacing guess.
            await page.waitForSelector([
                "#orderDetails",
                '[data-component="cancelled"]',
                "#f3_food_ItemList",
                "#f3_food_WfmInStoreOrderSummary",
                ".ufpo-item-list-table",
                "#ufpo-order-status-container",
                ".js-order-card",
            ].join(", "), {
                timeout: DETAIL_WAIT_MS,
                state: "attached",
            });
        }, {
            retries: RETRY_COUNT,
            minTimeout: RETRY_MIN_TIMEOUT_MS,
            factor: RETRY_FACTOR,
            shouldRetry: ({ error }) => !(error instanceof AbortError) &&
                RETRYABLE_ERROR_RE.test(error.message),
        });
    }
    catch {
        return {
            failureKind: "navigation_retry_exhausted",
            reason: reasonForDetailFailure("navigation_retry_exhausted"),
            status: "failed",
        };
    }
    try {
        const landedUrl = page.url();
        if (!DETAIL_URL_RE.test(landedUrl)) {
            // A detail request that lands on Amazon's sign-in/challenge/MFA flow is a
            // dead authenticated session, not a transient page miss: retrying it every
            // run is owner busywork. Route it to owner-repair so the run stops churning
            // retryable gaps and the owner is asked to reconnect. A redirect to any
            // OTHER non-detail URL stays a transient no-progress gap.
            const failureKind = SIGNIN_URL_RE.test(landedUrl)
                ? "session_repair_required"
                : "redirected_non_detail";
            return {
                failureKind,
                reason: reasonForDetailFailure(failureKind),
                status: "failed",
            };
        }
        const html = await readPageContentWithin(page);
        const detail = parseOrderDetailDom(html);
        if (detail) {
            return { detail, status: "hydrated" };
        }
        return {
            failureKind: "parse_missing",
            reason: reasonForDetailFailure("parse_missing"),
            status: "failed",
        };
    }
    catch {
        return {
            failureKind: "parse_missing",
            reason: reasonForDetailFailure("parse_missing"),
            status: "failed",
        };
    }
}
async function extractOrdersOnPage(page) {
    try {
        const html = await readPageContentWithin(page);
        return {
            droppedCardCount: countOrderCardsWithoutOrderId(html),
            orders: parseOrdersListDom(html),
        };
    }
    catch {
        return { droppedCardCount: 0, orders: [] };
    }
}
export function newOrderItemsCoverage() {
    return { gap: [], hydrated: [], required: [] };
}
export function newOrdersCoverage() {
    return { considered: [], covered: [], dateDropped: [] };
}
/**
 * Classify one order's detail outcome. Policy-deferred orders
 * (PDPP_AMAZON_SKIP_DETAIL=1) are "unaccounted": required but not in any
 * outcome set. Per spec, required_keys absent from outcomes defer the
 * checkpoint. Attempted-but-failed is gap (backed by DETAIL_GAP).
 */
export function classifyDetailOutcome(skipDetail, detail) {
    if (skipDetail) {
        return "unaccounted";
    }
    return detail ? "hydrated" : "gap";
}
/**
 * Record one order's detail outcome into the run-level coverage accumulator.
 * Pure aside from mutating the passed accumulator; only the order id (an opaque
 * Amazon order number, already carried in SKIP_RESULT diagnostics) crosses in,
 * never recipient/address/payment fields. Every recorded order joins
 * `required` (the denominator); the outcome decides which numerator/skip set it
 * also joins.
 */
export function recordDetailOutcome(coverage, orderId, outcome) {
    coverage.required.push(orderId);
    if (outcome === "hydrated") {
        coverage.hydrated.push(orderId);
    }
    else if (outcome === "gap") {
        coverage.gap.push(orderId);
    }
    // "unaccounted" orders: required but not in hydrated or gap, per spec
}
/**
 * Build the per-order pending DETAIL_GAP for an order whose detail fetch was
 * attempted but came back null (a degraded gap, not a policy skip). The runtime
 * treats `DETAIL_COVERAGE.gap_keys` as a projection only — a `required` key is
 * satisfied at state-commit solely by a hydration, an optional skip, or a
 * durable pending DETAIL_GAP with a matching `record_key`
 * (`assertDetailCoverageSatisfiedBeforeCommit`). Emitting `gap_keys` without the
 * matching DETAIL_GAP would fail an otherwise-successful run at commit, so every
 * gap order MUST carry exactly one pending DETAIL_GAP on `order_items` (the same
 * stream the coverage report describes, so the runtime's
 * `gap.stream === coverage.stream` match holds).
 *
 * Reference-only and redacted: the opaque Amazon order id is the only datum that
 * crosses (it is already the `record_key`/`detail_locator.order_id`); no
 * recipient, address, payment, item title, or item text is carried. `reason`
 * stays redacted but precise enough to distinguish exhausted navigation retries
 * from parse-missing detail pages and connector-budget deferrals.
 */
export function buildOrderDetailGap(orderId, reason = "temporary_unavailable", failureKind, orderDate) {
    return {
        type: "DETAIL_GAP",
        stream: "order_items",
        parent_stream: "orders",
        record_key: orderId,
        status: "pending",
        reason,
        retryable: true,
        reference_only: true,
        detail_locator: {
            kind: "amazon.order_detail",
            order_id: orderId,
            ...(orderDate ? { order_date: orderDate } : {}),
        },
        ...(failureKind
            ? {
                detail: { class: classForDetailFailure(failureKind) },
                last_error: { class: classForDetailFailure(failureKind) },
            }
            : {}),
    };
}
function readRecoverableAmazonOrderDetailGap(gap) {
    if (gap.stream !== "order_items" || gap.status !== "pending") {
        return null;
    }
    const locator = gap.detail_locator;
    if (locator?.kind !== "amazon.order_detail") {
        return null;
    }
    const orderId = locator.order_id;
    const orderDate = locator.order_date;
    if (typeof orderId !== "string" ||
        typeof orderDate !== "string" ||
        orderId.length === 0 ||
        orderDate.length === 0) {
        return null;
    }
    return {
        gapId: gap.gap_id,
        orderDate,
        orderId,
        recordKey: gap.record_key ?? orderId,
    };
}
/**
 * Attempt exactly one mid-run session repair via `ensureAmazonSession` (or
 * `reauthenticate`, if injected), then retry the exact same order-detail
 * fetch once. Gated to the credentialed (this connection's resolved
 * `AMAZON_USERNAME`/`AMAZON_PASSWORD` pair) automated login path only — `ensureAmazonSession`
 * probes first and no-ops when the session is still live, but its
 * NO-credentials fallback opens an interactive owner hand-off that can
 * block up to 30 minutes and consume an OTP interaction slot; that path
 * stays reserved for `ensureSession` at run start, never triggered
 * speculatively mid-run from here. Returns null (no repair attempted, or
 * credentials absent) so the caller falls through to the existing terminal
 * `session_repair_required` behavior unchanged.
 */
async function attemptAutomatedSessionRepair(page, context, sendInteraction, flags, orderId, reauthenticate = ensureAmazonSession, credentials) {
    if (flags.repairAttempted) {
        return null;
    }
    flags.repairAttempted = true;
    // Connection-scoped, never ambient. This is a GATE, not a login site: it only
    // decides whether the credentialed repair path is eligible, so an absent pair
    // stays silent here and falls through to `session_repair_required` — the
    // owner-facing naming belongs to `ensureAmazonSession` at run start, which
    // must not be triggered speculatively mid-run (it can block 30 minutes).
    const resolved = resolveLoginCredentials(credentials, AMAZON_LOGIN_FIELDS, "amazon");
    if (resolved.kind === "absent") {
        return null;
    }
    const recovered = await reauthenticate({
        context,
        credentials,
        page,
        sendInteraction,
    }).catch(() => false);
    if (!recovered) {
        return null;
    }
    return fetchOrderDetail(page, orderId);
}
async function resolveOrderDetail(page, context, sendInteraction, flags, orderId, reauthenticate, credentials) {
    if (flags.sessionRepairRequired) {
        // The session died earlier this run and the one-shot automated repair
        // (if eligible) already failed or was never eligible. Do not touch the
        // browser again — the gap re-defers as owner-repair so the owner is
        // asked to reconnect instead of the run hammering sign-in once per
        // remaining order.
        return Promise.resolve({
            failureKind: "session_repair_required",
            reason: reasonForDetailFailure("session_repair_required"),
            status: "deferred",
        });
    }
    if (flags.detailAttempts >= MAX_DETAIL_ATTEMPTS_PER_RUN) {
        return Promise.resolve({
            failureKind: "deferred_budget",
            reason: reasonForDetailFailure("deferred_budget"),
            status: "deferred",
        });
    }
    if (flags.temporaryDetailFailures >= MAX_TEMPORARY_DETAIL_FAILURES_PER_RUN) {
        return Promise.resolve({
            failureKind: "deferred_budget",
            reason: reasonForDetailFailure("deferred_budget"),
            status: "deferred",
        });
    }
    flags.detailAttempts += 1;
    const result = await fetchOrderDetail(page, orderId);
    if (!(result.status === "failed" &&
        result.failureKind === "session_repair_required" &&
        context &&
        sendInteraction)) {
        return result;
    }
    const repaired = await attemptAutomatedSessionRepair(page, context, sendInteraction, flags, orderId, reauthenticate ?? ensureAmazonSession, credentials);
    return repaired ?? result;
}
/**
 * Fold one detail-attempt outcome into the per-run flags. Kept in one place so
 * the forward walk and the recovery loop escalate identically:
 *   - a navigation-retry-exhausted failure ratchets the transient no-progress
 *     count toward the per-run temporary-failure cap;
 *   - a session-repair-required failure latches the run into owner-repair so no
 *     further detail attempt touches the browser (blast-radius stop; the runtime
 *     still owns the cross-run retry decision).
 * `deferred` outcomes (already gated by flags) never re-ratchet.
 */
function recordDetailFailureFlags(flags, result) {
    if (result.status === "deferred") {
        return;
    }
    if (result.status === "failed" &&
        result.failureKind === "navigation_retry_exhausted") {
        flags.temporaryDetailFailures += 1;
    }
    if (result.status === "failed" &&
        result.failureKind === "session_repair_required") {
        flags.sessionRepairRequired = true;
    }
}
async function captureFailedDetailOnce(capture, page, flags, result) {
    if (!capture || flags.failedDetailCaptured) {
        return;
    }
    await capture.captureDom(page, `order-detail-failed-${result.failureKind}`);
    flags.failedDetailCaptured = true;
}
async function recoverPendingOrderItemDetailGapPage(page, deps, flags, gaps) {
    let recovered = 0;
    let reDeferred = 0;
    let skipped = 0;
    for (const gap of gaps) {
        const locator = readRecoverableAmazonOrderDetailGap(gap);
        if (!locator) {
            if (gap.stream === "order_items" && gap.status === "pending") {
                skipped += 1;
            }
            continue;
        }
        const result = await resolveOrderDetail(page, deps.context, deps.sendInteraction, flags, locator.orderId, deps.reauthenticate, deps.credentials);
        if (result.status === "hydrated") {
            for (const item of result.detail.items) {
                await deps.emitRecord("order_items", buildOrderItemRecord(locator.orderId, locator.orderDate, item));
            }
            await deps.emit({
                type: "DETAIL_GAP_RECOVERED",
                reference_only: true,
                gap_id: locator.gapId,
                stream: "order_items",
                record_key: locator.recordKey,
            });
            // The recovery path has no list-page row for this order (only the
            // gap locator's id/date), so it cannot compute a real list-surface
            // fingerprint (see `listSurfaceFingerprint`) and does not mark the
            // order known-hydrated here. The next forward walk that lists this
            // order establishes the proof normally, with a real fingerprint.
            recovered += 1;
            continue;
        }
        recordDetailFailureFlags(flags, result);
        if (result.status === "failed") {
            await captureFailedDetailOnce(deps.capture, page, flags, result);
        }
        await deps.emit(buildOrderDetailGap(locator.orderId, result.reason, result.failureKind, locator.orderDate));
        reDeferred += 1;
    }
    return { recovered, reDeferred, skipped };
}
export async function recoverPendingOrderItemDetailGaps(page, deps, flags) {
    let recovered = 0;
    let gaps = deps.detailGaps;
    while (gaps.length > 0) {
        const result = await recoverPendingOrderItemDetailGapPage(page, deps, flags, gaps);
        recovered += result.recovered;
        if (!deps.requestDetailGapPage) {
            return {
                recovered,
                stoppedWithPending: result.reDeferred + result.skipped > 0,
            };
        }
        if (result.recovered === 0 && result.reDeferred + result.skipped > 0) {
            return { recovered, stoppedWithPending: true };
        }
        gaps = await deps.requestDetailGapPage({ streams: ["order_items"] });
    }
    return { recovered, stoppedWithPending: false };
}
export async function recoverPendingOrderItemDetailGapsBeforeForwardRun(page, deps, flags, options) {
    if (!options.wantsItems) {
        return {
            recovered: 0,
            stoppedWithPending: false,
            suppressForward: options.recoveryOnly === true,
        };
    }
    const recovery = await recoverPendingOrderItemDetailGaps(page, deps, flags);
    const detailBudgetExhausted = flags.detailAttempts >= MAX_DETAIL_ATTEMPTS_PER_RUN ||
        flags.temporaryDetailFailures >= MAX_TEMPORARY_DETAIL_FAILURES_PER_RUN;
    return {
        ...recovery,
        suppressForward: options.recoveryOnly === true || detailBudgetExhausted,
    };
}
/**
 * Emit the run-level `order_items` DETAIL_COVERAGE once after the year loop,
 * using the shared `emitDetailCoverage` helper. The detail stream described is
 * `order_items` (enriched by the per-order detail page); its cursor is anchored
 * by the `orders` list stream (`state_stream`). The caller (`collect()`) only
 * reaches this call site once the `for (const year of years)` sweep has run to
 * completion without throwing — a thrown error aborts the whole collect() call
 * before this line — so `coverage.required.length === 0` here always means
 * "the year sweep completed and considered zero orders across every in-scope
 * year," never "the sweep never ran." Always emits when the caller invokes it
 * (order_items in scope) — including that zero-required steady-state case
 * (considered: 0, covered: 0, empty key sets) — so a run that legitimately
 * swept its denominator to zero stays measured instead of silently
 * unreported. Reuses DETAIL_COVERAGE as a reference-only projection; it is
 * not promoted to portable protocol.
 */
export async function emitOrderItemsCoverage(deps, coverage) {
    await emitDetailCoverage(deps, {
        stream: "order_items",
        stateStream: "orders",
        requiredKeys: coverage.required,
        hydratedKeys: coverage.hydrated,
        gapKeys: coverage.gap,
        considered: coverage.required.length,
        covered: coverage.hydrated.length,
    });
}
/**
 * Emit the run-level `orders` DETAIL_COVERAGE once after the year loop, using
 * the shared `emitDetailCoverage` helper self-referentially (`stream` and
 * `stateStream` both `"orders"` — there is no separate detail-hydration phase
 * for the list stream itself, so `requiredKeys`/`hydratedKeys` stay empty and
 * the denominator/numerator live entirely in `considered`/`covered`, mirroring
 * the pattern used for USAA's `inbox_messages` and GitHub's `declareListConsidered`
 * streams). Always emits when the caller invokes it (orders in scope) —
 * including a zero-considered steady-state run — for the same reason
 * `emitOrderItemsCoverage` always emits: a completed sweep that considered
 * zero orders is a real measured zero, not silence.
 */
export async function emitOrdersCoverage(deps, coverage) {
    await emitDetailCoverage(deps, {
        stream: "orders",
        stateStream: "orders",
        requiredKeys: [],
        hydratedKeys: [],
        considered: coverage.considered.length,
        covered: coverage.covered.length,
    });
}
/** Emit the order record + per-item records for a single list-page order.
 *
 * The invariants this enforces:
 *   1. The order record emits BEFORE its item records (so downstream
 *      readers see the parent-child relationship in order).
 *   2. Items emit in mergeOrderItems() order — list-page items first,
 *      detail-only items appended — which is the dedup + enrichment
 *      order consumers depend on.
 *   3. Streams disabled via scope (wantsOrders/wantsItems) emit nothing;
 *      the other stream still flows.
 * Regressing any of these is a real bug; integration.test.ts covers them.
 */
export async function emitOrderAndItems(deps, listOrder, detail, orderDate) {
    if (deps.wantsOrders) {
        // Gate on a per-order fingerprint that excludes the run-clock
        // `fetched_at`. An order's identity (id = order id) is immutable and its
        // total is fixed once placed, but the current (unfrozen) year is
        // re-scraped every run and re-emitted with a fresh `fetched_at`. With
        // this gate an already-seen order whose body is byte-identical modulo
        // `fetched_at` is suppressed; a real field move (delivery_status /
        // status_detail transitioning while the order ships) is a fingerprint
        // boundary and still emits. `order_items` carries no `fetched_at`, so it
        // does not churn on a no-op re-scrape and is left ungated.
        //
        // NOTE: orders is a PARTIAL scan (year-freezing skips historical years),
        // so this cursor is never `dropUnseenIds()`d — pruning ids in years the run
        // did not scrape would drop their fingerprints and re-churn them when the
        // year is next (re)visited.
        const orderRecord = buildOrderRecord(listOrder, detail, orderDate, deps.emittedAt);
        if (!deps.ordersFingerprintCursor ||
            deps.ordersFingerprintCursor.shouldEmit(orderRecord)) {
            await deps.emitRecord("orders", orderRecord);
        }
        // A fingerprint-suppressed re-scrape and a fresh emit are both a real
        // accounting decision for this order's `orders` record, so both count as
        // covered — only a date that never parses (handled below, before this
        // function is reached) is considered-but-not-covered.
        if (deps.ordersCoverage) {
            deps.ordersCoverage.considered.push(listOrder.orderId);
            deps.ordersCoverage.covered.push(listOrder.orderId);
        }
    }
    if (deps.wantsItems) {
        const merged = mergeOrderItems(listOrder, detail);
        for (const item of merged) {
            await deps.emitRecord("order_items", buildOrderItemRecord(listOrder.orderId, orderDate, item));
        }
        await emitItemCountReconciliation(deps, listOrder, detail, merged.length);
    }
}
/**
 * Reconcile the items we emitted against the count the order page asserted, and
 * report a shortfall rather than letting it pass.
 *
 * The denominator is measured at the parse boundary — `detail.items` is what
 * the order-detail page listed, counted before the merge and independently of
 * what `mergeOrderItems` decided to emit. Deduplication across the two surfaces
 * means the merged list should never be SHORTER than the detail page's own
 * list; if it is, an item the page showed us did not survive into a record.
 *
 * Only runs when a detail page was actually fetched. Without it there is no
 * assertion to reconcile against — `resolveItemCount` reports null for exactly
 * that case, and inventing a denominator from the list card would fabricate a
 * shortfall on every 3+ item order (the list card renders no item titles once
 * Amazon collapses them behind "+N more items").
 */
async function emitItemCountReconciliation(deps, listOrder, detail, emittedItemCount) {
    const declared = detail?.items?.length;
    if (declared === undefined || emittedItemCount >= declared) {
        return;
    }
    await deps.emit({
        type: "SKIP_RESULT",
        stream: "order_items",
        reason: "item_count_shortfall",
        message: `order ${listOrder.orderId} listed ${declared} items on its detail page but only ${emittedItemCount} became records`,
        diagnostics: {
            order_id: listOrder.orderId,
            declared_item_count: declared,
            emitted_item_count: emittedItemCount,
        },
    });
}
/**
 * Run list-page extraction through the zod shape-check. Orders that fail
 * the shape-check become SKIP_RESULT events; the successful subset is
 * returned in source order.
 */
async function extractAndShapeCheckOrders(page, emit) {
    const { droppedCardCount, orders: rawOrders } = await extractOrdersOnPage(page);
    // Only report when the page also proved at least one real order: `.order-card`/
    // `.js-order-card` is reused by Amazon's "Buy it again" recommendation carousel on
    // a genuinely empty year (see the `orders-list-empty-year-with-carousel` fixture),
    // so a page with ZERO real orders and only carousel cards is not evidence of loss —
    // `reportEmptyPageDiagnostics` already owns that case. Gating on `rawOrders.length
    // > 0` keeps this diagnostic scoped to "some cards parsed, but not all of them."
    if (droppedCardCount > 0 && rawOrders.length > 0) {
        // A card matched `.order-card`/`.js-order-card` but `parseOrderCard`
        // could not find a `.yohtmlc-order-id` on it, so it never became a raw
        // order and never reached the shape-check below — with no fix here that
        // card is lost with zero trace (no SKIP_RESULT, no coverage-considered
        // id, no rejection). This is the only signal that loss ever happened.
        await emit({
            type: "SKIP_RESULT",
            stream: "orders",
            reason: "list_page_order_id_not_found",
            message: `${droppedCardCount} order card(s) on this page had no parseable .yohtmlc-order-id and were dropped before the shape-check`,
            diagnostics: { dropped_card_count: droppedCardCount },
        });
    }
    const orders = [];
    for (const r of rawOrders) {
        const parsed = listPageOrderShape.safeParse(r);
        if (parsed.success) {
            orders.push(parsed.data);
        }
        else {
            await emit({
                type: "SKIP_RESULT",
                stream: "orders",
                reason: "list_page_shape_check_failed",
                message: `list card ${r.orderId}: ${parsed.error.issues
                    .map((i) => `${i.path.join(".")}: ${i.message}`)
                    .join("; ")}`,
                diagnostics: { card: r, issues: parsed.error.issues },
            });
        }
    }
    return orders;
}
/**
 * Empty-page diagnostic branch: distinguish "no more orders" from
 * "our selectors missed the DOM". Emits SKIP_RESULT with drift details
 * + screenshot when the page clearly has order-like elements but our
 * selectors matched nothing.
 */
async function reportEmptyPageDiagnostics(page, year, startIndex, emit, priorOrdersEvidence) {
    let diag;
    try {
        diag = await page.evaluate((noOrdersTextPattern) => {
            // biome-ignore-start lint/performance/useTopLevelRegex: runs in browser context (page.evaluate); module-scoped regexes in Node cannot cross the bridge.
            const CAPTCHA_RE = /captcha|robot|unusual traffic/i;
            const NO_ORDERS_RE = new RegExp(noOrdersTextPattern, "i");
            const WS = /\s+/g;
            // biome-ignore-end lint/performance/useTopLevelRegex: runs in browser context (page.evaluate); module-scoped regexes in Node cannot cross the bridge.
            return {
                url: location.href,
                title: document.title,
                order_cards: document.querySelectorAll("div.order-card, div.js-order-card").length,
                any_card: document.querySelectorAll('[class*="order" i][class*="card" i]').length,
                any_order_header: document.querySelectorAll('[class*="order" i][class*="header" i]').length,
                sign_in_form: Boolean(document.querySelector('form[name="signIn"]')),
                captcha: CAPTCHA_RE.test(document.body?.innerText || "").toString(),
                no_orders_text: NO_ORDERS_RE.test(document.body?.innerText || "").toString(),
                body_preview: (document.body?.innerText || "")
                    .replace(WS, " ")
                    .slice(0, 240),
            };
        }, AMAZON_NO_ORDERS_TEXT_PATTERN);
    }
    catch (error) {
        await emit({
            type: "SKIP_RESULT",
            stream: "orders",
            reason: "renderer_diagnostics_failed",
            message: `Amazon year ${year} startIndex=${startIndex}: renderer diagnostics failed; refusing to advance the cursor.`,
            diagnostics: {
                error_class: error instanceof Error ? "Error" : "unknown",
            },
        });
        throw new Error("amazon_empty_list_page_renderer_diagnostics_failed", {
            cause: error,
        });
    }
    const classification = classifyEmptyListPageDiagnostics(diag, startIndex, priorOrdersEvidence);
    if (classification.action === "terminal") {
        return;
    }
    if (classification.reason === "source_auth_or_challenge") {
        await emit({
            type: "PROGRESS",
            stream: "orders",
            message: `Amazon year ${year}: sign-in or CAPTCHA challenge detected; manual action required to continue`,
        });
    }
    if (diag && classification.reason === "selector_drift") {
        const shotPath = `/tmp/amazon-drift-${year}-${startIndex}.png`;
        await page
            .screenshot({ path: shotPath, fullPage: true })
            .catch(() => undefined);
        await emit({
            type: "SKIP_RESULT",
            stream: "orders",
            reason: "selector_drift",
            message: `Year ${year} startIndex=${startIndex}: order containers visible on page but .order-card/.js-order-card selector matched 0. Screenshot=${shotPath}`,
            diagnostics: redactAmazonListPageDiagnostics(diag),
        });
    }
    else {
        await emit({
            type: "SKIP_RESULT",
            stream: "orders",
            reason: classification.reason,
            message: classification.reason === "amazon_empty_history_after_prior_orders"
                ? AMAZON_EMPTY_AFTER_PRIOR_ORDERS_MESSAGE
                : `Year ${year} startIndex=${startIndex}: empty Amazon list page is not a proven terminal page; refusing to advance the cursor.`,
            diagnostics: diag
                ? {
                    ...redactAmazonListPageDiagnostics(diag),
                    has_prior_orders: priorOrdersEvidence.hasPriorOrders,
                    year,
                }
                : { missing_diagnostics: true },
        });
    }
    throw new Error(`amazon_empty_list_page_${classification.reason}`);
}
/** Browser text, titles, and URLs are useful for local classification but are
 * not durable connector evidence. Keep only structural facts in SKIP_RESULT. */
export function redactAmazonListPageDiagnostics(diag) {
    return { ...diag, body_preview: "", title: "", url: "" };
}
export function classifyEmptyListPageDiagnostics(diag, startIndex, priorOrdersEvidence = { hasPriorOrders: false }) {
    if (!diag) {
        return { action: "abort", reason: "renderer_diagnostics_failed" };
    }
    const captcha = diag.captcha === "true";
    if (diag.sign_in_form || captcha || SIGNIN_URL_RE.test(diag.url)) {
        return { action: "abort", reason: "source_auth_or_challenge" };
    }
    if ((diag.any_card > 0 || diag.any_order_header > 0) &&
        diag.order_cards === 0) {
        return { action: "abort", reason: "selector_drift" };
    }
    // A year that has already yielded orders can never prove itself empty.
    // `hasPriorOrders` is this connection's own prior `years[<year>].order_count`
    // for the SAME year being scraped — durable evidence that Amazon previously
    // listed orders there — threaded in explicitly by `scrapeListPage` rather
    // than read from ambient state, so this branch stays pure and unit-testable.
    //
    // Without this check, a year holding hundreds of stored orders could finish
    // as {action:"terminal", reason:"no_orders_text"}, letting the run advance
    // the year cursor and report covered:0/considered:0 — replacing a measured
    // coverage claim with a fabricated proven-zero. The two causes are
    // indistinguishable from the page alone: Amazon may have purged the history
    // upstream (making our stored copy the only copy), or the page may render
    // empty for a degraded session. So the run fails loudly and lets a human
    // decide, rather than guessing.
    //
    // Scoped to `startIndex === 0` because only the FIRST page of a year makes
    // the claim "this year is empty". A later page coming back empty is ordinary
    // pagination exhaustion on a year that plainly did yield orders — the rows
    // preceding it were just collected on this very run — and must keep falling
    // through to `pagination_exhausted` below.
    //
    // Ordering: BELOW the auth/challenge and selector-drift checks (an
    // established block or a real markup change is the more specific and more
    // actionable diagnosis, and must not be relabelled), and ABOVE the
    // `no_orders_text` branch, so Amazon's own empty-state copy cannot
    // short-circuit past it.
    if (startIndex === 0 &&
        diag.no_orders_text === "true" &&
        priorOrdersEvidence.hasPriorOrders) {
        return {
            action: "abort",
            reason: "amazon_empty_history_after_prior_orders",
        };
    }
    if (diag.no_orders_text === "true") {
        return { action: "terminal", reason: "no_orders_text" };
    }
    if (startIndex > 0) {
        return { action: "terminal", reason: "pagination_exhausted" };
    }
    return {
        action: "abort",
        reason: "empty_first_page_without_terminal_signal",
    };
}
/**
 * Navigate to one list-page URL for `year` at `startIndex`, wait for the
 * list signal, optionally capture a fixture, and return the shape-checked
 * orders. On zero orders, emits drift diagnostics before returning [].
 */
export async function scrapeListPage(page, capture, year, startIndex, emit, priorOrdersEvidence = { hasPriorOrders: false }) {
    const url = `https://www.amazon.com/your-orders/orders?timeFilter=year-${year}&startIndex=${startIndex}`;
    try {
        await page.goto(url, {
            waitUntil: "domcontentloaded",
            timeout: NAV_TIMEOUT_MS,
        });
    }
    catch (error) {
        await emit({
            type: "SKIP_RESULT",
            stream: "orders",
            reason: "list_page_navigation_failed",
            message: "Amazon list-page navigation failed; refusing to reuse the previous page as current data.",
            diagnostics: {
                error_class: error instanceof Error ? error.constructor.name : "unknown",
            },
        });
        throw new Error("amazon_list_page_navigation_failed", { cause: error });
    }
    // Wait for list-page signal. `.order-card` is the standard container
    // in modern layouts; `#ordersContainer` catches legacy. Either appears
    // when the orders list has rendered.
    await page
        .locator(".order-card, .js-order-card, #ordersContainer, #no-orders")
        .first()
        .waitFor({ state: "attached", timeout: LIST_PAGE_WAIT_MS })
        .catch(() => undefined);
    // Fixture capture: one list-page snapshot per year (page 1 only).
    if (capture && startIndex === 0) {
        await capture.captureDom(page, `orders-list-${year}`);
    }
    const orders = await extractAndShapeCheckOrders(page, emit);
    if (orders.length === 0) {
        await reportEmptyPageDiagnostics(page, year, startIndex, emit, priorOrdersEvidence);
    }
    return orders;
}
/**
 * The fingerprint of everything the LIST page alone can prove about an
 * order — computed the same way as an enriched `orders` record but with
 * `detail: null`, so detail-only fields (recipient, payment, status_detail,
 * gift/digital flags) are excluded and only list-observable fields
 * (delivery status, list total, list item count) participate. Comparing
 * this against the fingerprint recorded at hydration time is the change
 * trigger: if the list surface has not moved, the prior enriched detail is
 * still valid; if it has (delivery progressed, a return appeared), the
 * order must be re-hydrated.
 */
export function listSurfaceFingerprint(listOrder, orderDate, emittedAt) {
    return recordFingerprint(buildOrderRecord(listOrder, null, orderDate, emittedAt), ["fetched_at"]);
}
/**
 * Resolve one list-page order's detail (or record why it did not resolve),
 * honoring the explicit `skipDetail` policy. Extracted from `processListOrder`
 * to keep that function's branching within the cognitive-complexity budget.
 * Callers that already know the order is already-hydrated-and-unchanged
 * return early before reaching this function (see `processListOrder`).
 */
async function resolveDetailForListOrder(page, deps, flags, listOrder) {
    const resolution = {
        detail: null,
        detailFailureKind: null,
        detailGapReason: "temporary_unavailable",
    };
    if (deps.skipDetail) {
        return resolution;
    }
    const result = await resolveOrderDetail(page, deps.context, deps.sendInteraction, flags, listOrder.orderId, deps.reauthenticate, deps.credentials);
    if (result.status === "hydrated") {
        resolution.detail = result.detail;
        return resolution;
    }
    resolution.detailGapReason = result.reason;
    resolution.detailFailureKind = result.failureKind;
    recordDetailFailureFlags(flags, result);
    if (result.status === "failed") {
        await captureFailedDetailOnce(deps.capture, page, flags, result);
    }
    return resolution;
}
export async function processListOrder(page, deps, flags, listOrder) {
    const orderDate = parseOrderDate(listOrder.orderDateRaw);
    if (!orderDate) {
        // A list row whose date does not parse never reaches the detail lane, so it
        // is not counted toward order-item coverage; runYear already accounts for
        // it via the bounded per-year drop SKIP_RESULT. It was still enumerated by
        // the list scan, so the `orders` coverage denominator must not silently
        // drop it: considered, but not covered (no accounting decision was made
        // for its `orders` record).
        if (deps.ordersCoverage) {
            deps.ordersCoverage.considered.push(listOrder.orderId);
            deps.ordersCoverage.dateDropped.push(listOrder.orderId);
        }
        return false;
    }
    // The current (and previous) year is re-listed on every run — orders are
    // ongoing, so year-freezing never applies to it (see planIncrementalYears).
    // An order already known-hydrated AND whose list surface has not moved
    // since needs no repeat detail fetch or re-emit: its enriched records are
    // already durable and unchanged. A list-surface change (delivery status
    // moved, a return/refund became visible) invalidates the entry below and
    // forces a full re-hydration, so detail-driven fields never go stale.
    const currentListFingerprint = listSurfaceFingerprint(listOrder, orderDate, deps.emittedAt);
    const priorFingerprint = deps.hydratedOrders?.get(listOrder.orderId);
    const alreadyHydrated = !deps.skipDetail && priorFingerprint === currentListFingerprint;
    if (priorFingerprint !== undefined &&
        priorFingerprint !== currentListFingerprint) {
        // Stale proof: the list surface moved since hydration. Drop the entry
        // so this run's real hydration (below) re-establishes it fresh.
        deps.hydratedOrders?.delete(listOrder.orderId);
    }
    if (alreadyHydrated) {
        // Already-hydrated AND unchanged: nothing new to prove or emit on
        // either stream. Emitting a list-page-only `orders` record here would
        // silently downgrade the durable enriched record (recipient, payment,
        // status_detail nulled) even though nothing actually changed.
        if (deps.orderItemsCoverage) {
            recordDetailOutcome(deps.orderItemsCoverage, listOrder.orderId, "hydrated");
        }
        // The list scan still enumerated this order and the fingerprint match is
        // itself a real accounting decision (list surface unchanged since a prior
        // durable emit) — considered and covered, even though nothing re-emits.
        if (deps.ordersCoverage) {
            deps.ordersCoverage.considered.push(listOrder.orderId);
            deps.ordersCoverage.covered.push(listOrder.orderId);
        }
        return true;
    }
    const { detail, detailGapReason, detailFailureKind } = await resolveDetailForListOrder(page, deps, flags, listOrder);
    if (deps.capture && !(flags.detailCaptured || deps.skipDetail) && detail) {
        await deps.capture.captureDom(page, `order-detail-${listOrder.orderId}`);
        flags.detailCaptured = true;
    }
    // A real hydration this run joins the durable known-hydrated map, keyed to
    // the list surface observed THIS run, so a later run only skips re-fetch
    // while that surface stays unchanged. Gated on `wantsItems`: the map's
    // honest meaning is "order_items durably emitted", so a run scoped to
    // `orders` only (which may still fetch detail for order enrichment) must
    // not mark an order hydrated when no order_items record was emitted for
    // it — a later item-scoped run needs its own real attempt.
    if (detail && deps.wantsItems) {
        deps.hydratedOrders?.set(listOrder.orderId, currentListFingerprint);
    }
    if (deps.orderItemsCoverage) {
        const outcome = classifyDetailOutcome(deps.skipDetail, detail);
        recordDetailOutcome(deps.orderItemsCoverage, listOrder.orderId, outcome);
        // Attempted-but-failed detail emits a durable DETAIL_GAP so the gap_key is
        // backed and the checkpoint is satisfiable on recovery.
        if (outcome === "gap") {
            await deps.emit(buildOrderDetailGap(listOrder.orderId, detailGapReason, detailFailureKind ?? undefined, orderDate));
        }
    }
    await emitOrderAndItems(deps, listOrder, detail, orderDate);
    return true;
}
export async function applyYearCompletionState({ newYearsState, prior, progress, truncated, unparseableDateCount, year, yearOrderCount, }) {
    // A year whose walk hit PAGE_LIMIT is a PREFIX of that year, not the year.
    // Recording it would be the permanent-loss case this connector's freeze
    // policy makes irreversible: `order_count` would hold the capped prefix
    // count, and because a truncated year reproduces the SAME capped count on
    // every run, `stableCount` goes true on the very next run and freezes a past
    // year for good — and `collect()` skips frozen years outright
    // (`if (prior?.frozen) continue`), so the untraversed tail becomes
    // unreachable by ANY future run. Leaving the prior state untouched keeps the
    // year eligible for a later, fuller scan.
    if (truncated) {
        await progress(`Not advancing Amazon year ${year} cursor because its scan stopped at the ${PAGE_LIMIT}-page limit ` +
            `with more orders still listed (${yearOrderCount} seen so far)`, { stream: "orders" });
        return;
    }
    // Year completion state with freeze-once-stable policy. If required
    // list rows were dropped, do not advance `last_scraped`: the next run
    // must be allowed to retry the year after a parser fix instead of
    // treating the year as complete forever.
    if (unparseableDateCount === 0) {
        const stableCount = prior !== undefined && prior.order_count === yearOrderCount;
        newYearsState[String(year)] = {
            order_count: yearOrderCount,
            frozen: year < new Date().getFullYear() && stableCount,
            last_scraped: nowIso(),
        };
    }
    else {
        await progress(`Not advancing Amazon year ${year} cursor because ${unparseableDateCount} order row${unparseableDateCount === 1 ? "" : "s"} could not be emitted`, { stream: "orders" });
    }
}
/**
 * Build the `orders` STATE cursor: year cursors plus the optional per-order
 * fingerprint map and known-hydrated order map. Shared by every STATE emit
 * site in `collect()` so the carry-forward fields are assembled identically
 * regardless of which site triggers the emit.
 */
function buildAmazonOrdersStateCursor(yearsState, ordersFingerprintCursor, hydratedOrders) {
    const cursor = { years: yearsState };
    if (ordersFingerprintCursor && ordersFingerprintCursor.size() > 0) {
        cursor.fingerprints = ordersFingerprintCursor.toState();
    }
    if (hydratedOrders.size > 0) {
        cursor.hydratedOrders = Object.fromEntries(hydratedOrders);
    }
    return cursor;
}
/**
 * Decide whether `collect()` must emit a trailing `orders` STATE after the
 * year loop, to persist durable progress the loop itself never reached a
 * STATE emit for. `ordersStateEmitted` (NOT `years.length === 0`) is the
 * right signal: `planIncrementalYears` always plans the current and
 * previous year and the previous year CAN be frozen, so the loop runs with
 * `years.length > 0` while every iteration `continue`s before its STATE
 * emit. Exported for direct unit coverage of this decision, independent of
 * a full `collect()` drive (which needs a browser context this repo's other
 * connector test suites also don't build).
 */
export function shouldEmitTrailingOrdersState(ordersStateEmitted, hydratedOrders) {
    return !ordersStateEmitted && hydratedOrders.size > 0;
}
/**
 * Derive the prior-orders evidence for ONE year from this connection's stored
 * `years` cursor. Exported and pure because `collect()` lives inside the
 * `isMainModule` block and cannot be driven from a test — without this seam
 * the year-state-to-evidence link would be the one untested link in the
 * chain, and a mutation that hardcodes `false` here (silently disarming the
 * guard for every connection) would go unnoticed.
 *
 * The evidence is `order_count > 0`, not the mere existence of a year cursor.
 * A year that was scraped and legitimately held zero orders commits a cursor
 * with `order_count: 0`; that year must stay free to report empty again on
 * every later run. Only a year that actually yielded orders can contradict a
 * later "no orders" page.
 */
export function priorOrdersEvidenceForYear(yearsState, year) {
    return { hasPriorOrders: (yearsState[String(year)]?.order_count ?? 0) > 0 };
}
/**
 * Scrape every list page for one year and emit records. Returns both the total
 * order count seen for the year (used for freeze-once-stable policy) and the
 * count of rows we could not emit because their order date was unparseable.
 */
async function runYear(page, deps, flags, year, priorOrdersEvidence = { hasPriorOrders: false }) {
    let yearOrderCount = 0;
    let unparseableDateCount = 0;
    let pageCount = 0;
    const walk = await walkPagesWithCeiling({
        maxPages: PAGE_LIMIT,
        fetchPage: async () => {
            await deps.progress(`Amazon year ${year}: scanning page ${pageCount + 1}`, { stream: "orders" });
            const orders = await scrapeListPage(page, deps.capture, year, pageCount * START_INDEX_STEP, deps.emit, priorOrdersEvidence);
            if (orders.length === 0) {
                // EXIT A — honest completion: the year is exhausted.
                await deps.progress(`Amazon year ${year}: no more orders after ${yearOrderCount} seen`, { stream: "orders" });
                return false;
            }
            yearOrderCount += orders.length;
            await deps.progress(`Amazon year ${year}: page ${pageCount + 1} found ${orders.length} orders`, {
                stream: "orders",
            });
            for (const [index, o] of orders.entries()) {
                await deps.progress(`Amazon year ${year}: processing order ${index + 1}/${orders.length} on page ${pageCount + 1}`, { stream: "orders" });
                const processed = await processListOrder(page, deps, flags, o);
                if (!processed) {
                    // biome-ignore lint/style/noIncrementDecrement: integration.test.ts asserts this literal `unparseableDateCount++` source text (source-regex oracle); switching to += would fail that pre-existing test for a purely cosmetic change.
                    unparseableDateCount++;
                }
            }
            pageCount += 1;
            await politeDelay(POLITE_DELAY_MS);
            return true;
        },
    });
    // Bounded per-year coverage evidence: a year that silently drops order rows
    // with an unparseable order date must not look complete. One count-only
    // SKIP_RESULT per year (no raw order ids) instead of a per-item flood.
    if (unparseableDateCount > 0) {
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "orders",
            reason: "unparseable_order_date",
            message: `Amazon year ${year}: dropped ${unparseableDateCount} order row${unparseableDateCount === 1 ? "" : "s"} with unparseable dates (of ${yearOrderCount} seen)`,
            diagnostics: {
                dropped: unparseableDateCount,
                total_seen: yearOrderCount,
                year,
            },
        });
    }
    // A truncated year is reported to the owner as a deferred remainder, never
    // left to read as a finished year. `..._deferred` is load-bearing: the
    // reference implementation classifies a skip by its reason string, and only
    // a deferred-matching reason maps to the `deferred` axis instead of
    // `terminal_gap` — the remaining orders are postponed by a page budget, not
    // permanently unreachable.
    if (walk.truncated) {
        await deps.emit({
            type: "SKIP_RESULT",
            stream: "orders",
            reason: "older_pages_deferred_page_budget",
            message: `Amazon year ${year}: stopped at the ${PAGE_LIMIT}-page limit with more orders still listed`,
            diagnostics: { page_limit: PAGE_LIMIT, total_seen: yearOrderCount, year },
        });
    }
    return {
        orderCount: yearOrderCount,
        truncated: walk.truncated,
        unparseableDateCount,
    };
}
// ─── Incremental year planning ───────────────────────────────────────────
/**
 * Given the full set of discovered years and prior year state, return the
 * subset that should be scraped on this run.
 *
 * Invariants:
 *   - Current year is always included (orders are ongoing).
 *   - Previous year is always included (returns / late-arriving shipments
 *     can post after year-end).
 *   - Any year ≥2 years ago that already has a `last_scraped` timestamp in
 *     prior state is skipped — it was captured on a previous run and
 *     re-scraping it on every incremental run is unbounded behaviour.
 *   - Any year ≥2 years ago with NO prior `last_scraped` (newly discovered)
 *     is included so first-time discovery still works.
 *   - If there is no prior scraped state at all (first run), all years are
 *     returned so the initial backfill completes normally.
 *
 * This function is exported for unit testing. The `currentYear` parameter
 * is injected to keep the function pure (no `new Date()` at call time).
 */
export function planIncrementalYears(years, yearsState, currentYear) {
    // If there is no prior scraped state at all, treat this as a first run —
    // return all discovered years so the initial backfill completes normally.
    const hasAnyScrapeHistory = Object.values(yearsState).some((s) => s?.last_scraped);
    if (!hasAnyScrapeHistory) {
        return { planned: [...years], skipped: [] };
    }
    const planned = [];
    const skipped = [];
    const prevYear = currentYear - 1;
    for (const year of years) {
        if (year >= prevYear) {
            // Current and previous year are always eligible.
            planned.push(year);
            continue;
        }
        const prior = yearsState[String(year)];
        if (prior?.last_scraped) {
            // Historical year with prior state: skip to prevent unbounded re-scrape.
            skipped.push({
                year,
                reason: `prior state last_scraped=${prior.last_scraped}`,
            });
        }
        else {
            // Newly discovered historical year (no prior state): include once.
            planned.push(year);
        }
    }
    return { planned, skipped };
}
// ─── Main ────────────────────────────────────────────────────────────────
// Guarded so `import "./index.ts"` in tests doesn't spin up the runtime
// and block the Node event loop on stdin. Only fires when this module
// IS the process entry point (i.e. `tsx connectors/amazon/index.ts`).
if (isMainModule(import.meta.url)) {
    runConnector({
        name: "amazon",
        validateRecord,
        // See the chase declaration: without this the runtime resolves `{}`, never
        // raises the `credentials` INTERACTION, and Amazon's hand-off says "no
        // optional sign-in details were provided" without naming the fields the
        // owner must supply.
        auth: { kind: "env", required: ["AMAZON_USERNAME", "AMAZON_PASSWORD"] },
        // Persistent profile keeps cookies and session state across runs; browser
        // mode is selected by the deployment, not by this connector.
        browser: { profileName: "amazon" },
        async ensureSession({ capture, checkpoint, context, credentials, onCredentialSubmit, page, sendInteraction, }) {
            await ensureAmazonSession({
                ...(capture ? { capture } : {}),
                checkpoint,
                context,
                credentials,
                onCredentialSubmit,
                page,
                sendInteraction,
            });
            await checkpoint("amazon-deep-session-check");
            const deepOk = await deepSessionCheck(page);
            if (!deepOk) {
                throw new Error("amazon_session_required");
            }
        },
        async collect(ctx) {
            const { scope, state, emitRecord, emit, progress, capture, emittedAt, page, context, credentials, sendInteraction, } = ctx;
            const requested = new Map((scope?.streams || []).map((s) => [s.name, s]));
            const wantsItems = requested.has("order_items");
            const wantsOrders = requested.has("orders");
            const flags = {
                detailAttempts: 0,
                detailCaptured: false,
                failedDetailCaptured: false,
                repairAttempted: false,
                sessionRepairRequired: false,
                temporaryDetailFailures: 0,
            };
            // Seeded once for the whole run; mutated in place by the forward walk
            // only (the recovery pass has no list-page row to fingerprint against
            // — see AmazonDetailRecoveryDeps).
            const hydratedOrders = readPriorHydratedOrders(state);
            const gapRecovery = await recoverPendingOrderItemDetailGapsBeforeForwardRun(page, {
                capture,
                context,
                credentials,
                detailGaps: ctx.detailGaps,
                emit,
                emitRecord,
                requestDetailGapPage: ctx.requestDetailGapPage,
                sendInteraction,
            }, flags, { recoveryOnly: ctx.recoveryOnly === true, wantsItems });
            if (gapRecovery.stoppedWithPending) {
                await progress("Amazon order-item gap recovery stopped with pending gaps still queued; the next run will continue recovery");
            }
            if (gapRecovery.suppressForward) {
                return;
            }
            // STATE is stream-keyed per Collection Profile: `state` is
            // { <stream>: <cursor>, ... }. We write STATE stream='orders'
            // cursor={years:{...}}, so reads must go through state.orders.
            const ordersState = (state.orders ?? {});
            const legacyYears = state.years;
            const yearsState = ordersState.years ?? legacyYears ?? {};
            // Per-order fingerprint cursor (excludes the run-clock `fetched_at`).
            // One cursor for the whole orders stream — order ids are globally
            // unique across years. Only opened when orders are requested. NOT
            // pruned: orders is a partial scan (year-freezing skips historical
            // years — see emitOrderAndItems).
            const ordersFingerprintCursor = requested.has("orders")
                ? openFingerprintCursor(state.orders, {
                    excludeFromFingerprint: ["fetched_at"],
                    priorFingerprints: readPriorOrderFingerprints(state),
                })
                : undefined;
            await progress("Amazon session verified; discovering years");
            const discoveredYears = await discoverYears(page);
            let years;
            // Targeted-year override for spot checks and explicit backfills.
            // Bypasses incremental planning entirely.
            if (process.env.PDPP_AMAZON_YEARS) {
                const filter = new Set(process.env.PDPP_AMAZON_YEARS.split(",").map((y) => Number(y.trim())));
                years = discoveredYears.filter((y) => filter.has(y));
            }
            else {
                // Incremental planning: bound the year set so historical years with
                // prior scraped state are not re-scraped on every run.
                const currentYear = new Date().getFullYear();
                const { planned, skipped } = planIncrementalYears(discoveredYears, yearsState, currentYear);
                for (const { year, reason } of skipped) {
                    await progress(`Skipping year ${year} (incremental: ${reason})`);
                }
                years = planned;
            }
            await progress(`Years to scrape: ${years.join(", ")}`);
            // Capture fixtures (gated on PDPP_CAPTURE_FIXTURES=1). One orders-list
            // page per year and one order-detail page overall is enough to drive
            // offline parser tests — more just bloats the fixture tree.
            // Order-item detail coverage is only meaningful when the detail-enriched
            // `order_items` stream is in scope. When it is not requested, the
            // accumulator stays undefined and processListOrder records nothing.
            const orderItemsCoverage = wantsItems
                ? newOrderItemsCoverage()
                : undefined;
            // `orders` list-stream coverage is only meaningful when `orders` itself
            // is in scope — mirrors the `wantsItems`-gated accumulator above.
            const ordersCoverage = wantsOrders ? newOrdersCoverage() : undefined;
            const deps = {
                capture,
                context,
                credentials,
                emit,
                emitRecord,
                emittedAt,
                hydratedOrders,
                orderItemsCoverage,
                ordersCoverage,
                ordersFingerprintCursor,
                progress,
                sendInteraction,
                skipDetail: process.env.PDPP_AMAZON_SKIP_DETAIL === "1",
                wantsItems,
                wantsOrders,
            };
            const newYearsState = { ...yearsState };
            const buildOrdersStateCursor = () => buildAmazonOrdersStateCursor(newYearsState, ordersFingerprintCursor, hydratedOrders);
            // Tracks whether the loop below has emitted STATE at least once, so
            // the trailing fallback emit (below the loop) fires exactly when the
            // loop emitted nothing — including "every planned year is frozen",
            // which `years.length === 0` does not cover: `planIncrementalYears`
            // always plans the current and previous year, and the previous year
            // CAN be frozen, so `years.length > 0` while every iteration
            // `continue`s before reaching the STATE emit.
            let ordersStateEmitted = false;
            for (const year of years) {
                const prior = yearsState[String(year)];
                // Year-freezing: skip if already frozen
                if (prior?.frozen) {
                    await progress(`Skipping year ${year} (frozen)`);
                    continue;
                }
                // A prior `years[<year>].order_count > 0` is this connection's own
                // record that Amazon has listed orders for this account in THIS year
                // before. It is what makes a later "no orders in <year>" page a
                // contradiction to escalate rather than a result to trust. Read here,
                // next to the year cursor it derives from, and passed down explicitly.
                const { orderCount: yearOrderCount, truncated, unparseableDateCount, } = await runYear(page, deps, flags, year, priorOrdersEvidenceForYear(yearsState, year));
                await applyYearCompletionState({
                    newYearsState,
                    prior,
                    progress,
                    truncated,
                    unparseableDateCount,
                    year,
                    yearOrderCount,
                });
                // Carry the per-order fingerprint map and known-hydrated order map
                // forward alongside the year cursors so the next run can suppress
                // re-scraped orders whose body is unchanged modulo the run clock, and
                // skip re-fetching detail for orders whose list surface has not
                // moved. NOT pruned: orders is a partial scan (frozen years are
                // skipped, so their ids are never re-seen).
                await emit({
                    type: "STATE",
                    stream: "orders",
                    cursor: buildOrdersStateCursor(),
                });
                ordersStateEmitted = true;
            }
            // The loop may emit no STATE at all — every planned year frozen, or no
            // years discovered — even though the recovery pass above hydrated
            // gaps or a prior run's `hydratedOrders` map is non-empty. Without
            // this, that durable progress would never reach a STATE emit this run.
            if (shouldEmitTrailingOrdersState(ordersStateEmitted, hydratedOrders)) {
                await emit({
                    type: "STATE",
                    stream: "orders",
                    cursor: buildOrdersStateCursor(),
                });
            }
            // After every scraped year settles, emit one run-level `order_items`
            // DETAIL_COVERAGE: the order list is a real "considered" denominator, so
            // the console can tell a fully-hydrated run from one that degraded some
            // order-detail fetches without inferring it from gaps alone. No-ops when
            // order_items is out of scope or no order was considered.
            if (orderItemsCoverage) {
                await emitOrderItemsCoverage(deps, orderItemsCoverage);
            }
            // Same honesty posture as order_items: emit once the year sweep
            // completes, including the zero-considered steady-state case, so the
            // `orders` list stream is never left permanently unmeasured.
            if (ordersCoverage) {
                await emitOrdersCoverage(deps, ordersCoverage);
            }
        },
    });
}
