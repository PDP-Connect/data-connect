import type { DetailItem, ListPageOrder, MergedItem, OrderDetail, OrderItemRecord, OrdersRecord } from "./types.ts";
export declare function parseOrderDetailDom(html: string): OrderDetail | null;
export declare function parseOrdersListDom(html: string): ListPageOrder[];
/**
 * Count `.order-card`/`.js-order-card` elements that `parseOrdersListDom`
 * silently drops because `findOrderId` found no `.yohtmlc-order-id` span
 * matching the canonical order-id shape. `parseOrderCard`'s `if (!orderId)
 * return null` (and `parseOrdersListDom`'s discard of that `null`) leaves no
 * other trace: the card never reaches the shape-check, so it never produces
 * a SKIP_RESULT, a coverage-considered id, or a rejection — a page can lose
 * cards here with zero connector-visible evidence. Called alongside
 * `parseOrdersListDom` so a caller can detect and report the gap the parse
 * step itself cannot see (it only ever sees what survived).
 */
export declare function countOrderCardsWithoutOrderId(html: string): number;
export declare function parseOrderDate(raw: string | null | undefined): string | null;
export declare function parseCurrencyCents(raw: string | null | undefined): number | null;
export declare function itemId(orderId: string, it: {
    asin?: string | null;
    name?: string;
}): string;
export declare function mergeDetailByKey(detailItems: DetailItem[]): {
    byAsin: Map<string, DetailItem>;
    byName: Map<string, DetailItem>;
};
/**
 * Merge list-page items with detail-page items into the final emit-ordered
 * sequence. Preserves original collect() semantics exactly:
 *   1. For each list-page item, find its detail-page counterpart (ASIN first,
 *      then normalized name), spread list→detail, emit.
 *   2. After that, append any detail-page items not seen in the list
 *      (dedup by ASIN or normalized name against list items).
 *   3. Dedup emitted items by their final itemId() so repeats within a
 *      single order aren't duplicated.
 */
export declare function mergeOrderItems(listOrder: ListPageOrder, detail: OrderDetail | null): MergedItem[];
/** Build the emitted OrderItemRecord for a single merged item. */
export declare function buildOrderItemRecord(orderId: string, orderDate: string, merged: MergedItem): OrderItemRecord;
export declare function buildOrderRecord(listOrder: ListPageOrder, detail: OrderDetail | null, orderDate: string, emittedAt: string): OrdersRecord;
//# sourceMappingURL=parsers.d.ts.map