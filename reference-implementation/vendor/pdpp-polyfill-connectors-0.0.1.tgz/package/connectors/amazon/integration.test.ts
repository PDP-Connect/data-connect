// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

/**
 * Integration tests for the Amazon connector's `collect()` layer —
 * specifically the per-order emit orchestration.
 *
 * These tests DON'T spin up a browser. They construct a fake `EmitDeps`
 * backed by `makeRecordingEmit(validateRecord)` — so every emitted
 * record is run through the real zod schema the runtime applies in
 * production. A fixture that would SKIP_RESULT in prod fails the test
 * here rather than silently passing. Captures every (stream, data) pair
 * pushed through `emitRecord`, then asserts on the sequence: order
 * emitted before items, items in dedup+merge order, stream-scope
 * respected, cursor timing preserved.
 *
 * Imports directly from ./index.ts — `runConnector({...})` is guarded by
 * `isMainModule(import.meta.url)` so it only fires when index.ts is the
 * process entry point, not when a test imports it.
 *
 * Why bother: unit tests on pure parsers prove record *shapes* are
 * correct. Integration tests on emitOrderAndItems prove the invariants
 * that consumers actually observe: "emit parent record before children",
 * "scope.streams filters what flows without breaking sibling streams",
 * "the same order doesn't double-emit if the list and detail both
 * reference the same ASIN". Regressing any of these is a data-corruption
 * bug, and nothing else in the test suite catches it.
 */

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { fileURLToPath } from "node:url";
import type { EmittedMessage } from "@pdpp/connector-protocol";
import type { Page } from "playwright";
import type { BrowserCollectContext } from "../../src/connector-runtime.ts";
import {
	openFingerprintCursor,
	recordFingerprint,
} from "../../src/fingerprint-cursor.ts";
import {
	type EmittedRecord,
	makeRecordingEmit,
} from "../../src/test-harness.ts";
import {
	AMAZON_NO_ORDERS_TEXT_PATTERN,
	type AmazonRecoveryClass,
	applyYearCompletionState,
	buildOrderDetailGap,
	classifyAmazonDetailFailure,
	classifyDetailOutcome,
	classifyEmptyListPageDiagnostics,
	type EmitDeps,
	emitOrderAndItems,
	emitOrderItemsCoverage,
	emitOrdersCoverage,
	listSurfaceFingerprint,
	newOrderItemsCoverage,
	newOrdersCoverage,
	type OrderItemsCoverage,
	type OrdersCoverage,
	planIncrementalYears,
	priorOrdersEvidenceForYear,
	processListOrder,
	type RunFlags,
	readPageContentWithin,
	reasonForDetailFailure,
	recordDetailOutcome,
	recoverPendingOrderItemDetailGaps,
	recoverPendingOrderItemDetailGapsBeforeForwardRun,
	redactAmazonListPageDiagnostics,
	scrapeListPage,
	shouldEmitTrailingOrdersState,
	type YearsCursor,
} from "./index.ts";
import { buildOrderRecord, parseOrderDate } from "./parsers.ts";
import { validateRecord } from "./schemas.ts";
import type {
	DetailItem,
	ListPageDiagnostics,
	ListPageOrder,
	OrderDetail,
} from "./types.ts";

const AMAZON_MANIFEST_PATH = new URL(
	"../../manifests/amazon.json",
	import.meta.url,
);
const AMAZON_INDEX_PATH = fileURLToPath(new URL("./index.ts", import.meta.url));
const AMAZON_FOPO_DETAIL_FIXTURE = new URL(
	"./__fixtures__/order-detail-fopo-minimal.html",
	import.meta.url,
);
const AMAZON_UFPO_DETAIL_FIXTURE = new URL(
	"./__fixtures__/order-detail-ufpo-minimal.html",
	import.meta.url,
);
const AMAZON_UFF_DETAIL_FIXTURE = new URL(
	"./__fixtures__/order-detail-uff-card-minimal.html",
	import.meta.url,
);
const AMAZON_EMPTY_YEAR_FIXTURE = new URL(
	"./__fixtures__/orders-list-empty-year-with-carousel.html",
	import.meta.url,
);

interface RecordingDeps {
	deps: EmitDeps;
	emitted: EmittedRecord[];
	protocolMessages: EmittedMessage[];
}

/** Build an EmitDeps that records every emitRecord() call, validating
 *  each record against the connector's real zod schema (so a test that
 *  would silently emit drifted data in production now fails loudly).
 *  emit() is a no-op side-channel (emitOrderAndItems doesn't call emit()
 *  — only diagnostic paths do). capture is null since fixture capture is
 *  orthogonal to emit ordering. */
function makeRecordingDeps(overrides: Partial<EmitDeps> = {}): RecordingDeps {
	const harness = makeRecordingEmit(validateRecord);
	const deps: EmitDeps = {
		capture: null,
		emit: harness.emit,
		emitRecord: harness.emitRecord,
		emittedAt: "2026-04-22T12:00:00.000Z",
		progress: (): Promise<void> => Promise.resolve(),
		skipDetail: false,
		wantsItems: true,
		wantsOrders: true,
		...overrides,
	};
	return {
		deps,
		emitted: harness.emitted,
		protocolMessages: harness.protocolMessages,
	};
}

function makeListOrder(overrides: Partial<ListPageOrder> = {}): ListPageOrder {
	return {
		orderId: "111-1234567-8901234",
		orderDateRaw: "January 5, 2026",
		orderTotal: "$42.99",
		deliveryStatus: "Delivered",
		items: [
			{
				asin: "B01ABCDEFG",
				name: "Widget",
				url: "https://amazon.com/dp/B01ABCDEFG",
			},
		],
		...overrides,
	};
}

function makeDetailItem(overrides: Partial<DetailItem> = {}): DetailItem {
	return {
		asin: null,
		name: "Widget",
		url: null,
		unit_price: null,
		quantity: 1,
		seller: null,
		item_image_url: null,
		refund_status: null,
		...overrides,
	};
}

function makeDetail(overrides: Partial<OrderDetail> = {}): OrderDetail {
	return {
		grand_total: "$42.99",
		recipient_name: "Fake Name",
		shipping_address_summary: "123 Fake St",
		payment_method_summary: "Visa ending in 0000",
		status_detail: null,
		gift_order: false,
		digital_order: false,
		items: [
			makeDetailItem({
				asin: "B01ABCDEFG",
				name: "Widget",
				unit_price: "$39.99",
			}),
		],
		...overrides,
	};
}

/**
 * A minimal but real order-detail page that `parseOrderDetailDom` parses into a
 * non-null `OrderDetail`. The recipient/address/payment strings are synthetic
 * PII that the coverage projection must NOT carry — only the opaque order id
 * may cross into DETAIL_COVERAGE.
 */
function makeDetailHtml(): string {
	return `<!doctype html><html><body><div id="orderDetails">
    <div data-component="shippingAddress"><ul><li>Fake Name</li><li>123 Fake St</li></ul></div>
    <div data-component="viewPaymentPlanSummaryWidget">Visa ending in 0000</div>
    <div data-component="chargeSummary">Grand Total: $42.99</div>
    <div data-component="purchasedItemsRightGrid">
      <div data-component="itemTitle"><a href="/dp/B01ABCDEFG">Widget</a></div>
      <div data-component="unitPrice">$39.99 $39.99</div>
    </div>
  </div></body></html>`;
}

/** Detail page with no `#orderDetails` container → `parseOrderDetailDom`
 *  returns null: the same degraded-gap outcome a layout drift or non-detail
 *  redirect produces, but with no pRetry backoff so the test stays fast. */
const NO_DETAIL_HTML =
	"<!doctype html><html><body><div>no order details</div></body></html>";

/**
 * Drives `fetchOrderDetail` without a browser. `goto`/`waitForSelector` resolve,
 * and `content()` returns the supplied HTML. A hydrated stub passes
 * `makeDetailHtml()` (parses to a non-null OrderDetail); a degraded-gap stub
 * passes `NO_DETAIL_HTML`.
 */
function makeDetailPageStub(
	html: string,
	url = "https://www.amazon.com/gp/your-account/order-details?orderID=fixture",
): Page {
	// Single assertion through Proxy (matches NEVER_CALLED_PAGE), avoiding a
	// double-cast. Only the methods fetchOrderDetail touches are backed; any
	// other access throws so an unexpected page call is caught loudly.
	return new Proxy(
		{},
		{
			get(_target, prop): unknown {
				if (prop === "goto" || prop === "waitForSelector") {
					return (): Promise<null> => Promise.resolve(null);
				}
				if (prop === "content") {
					return (): Promise<string> => Promise.resolve(html);
				}
				if (prop === "url") {
					return (): string => url;
				}
				throw new Error(`unexpected page.${String(prop)} in detail stub`);
			},
		},
	) as Page;
}

// ─── Invariant 1: ordering (parent before children) ──────────────────────

test("emitOrderAndItems: emits 'orders' record BEFORE any 'order_items' records", async () => {
	const { deps, emitted } = makeRecordingDeps();
	const listOrder = makeListOrder();
	await emitOrderAndItems(deps, listOrder, makeDetail(), "2026-01-05");

	const orderIdx = emitted.findIndex((r) => r.stream === "orders");
	const firstItemIdx = emitted.findIndex((r) => r.stream === "order_items");
	assert.notEqual(orderIdx, -1, "expected an 'orders' record");
	assert.notEqual(
		firstItemIdx,
		-1,
		"expected at least one 'order_items' record",
	);
	assert.ok(
		orderIdx < firstItemIdx,
		"order record must precede item records in emit sequence",
	);
});

test("emitOrderAndItems: emits exactly one order record per call", async () => {
	const { deps, emitted } = makeRecordingDeps();
	await emitOrderAndItems(deps, makeListOrder(), makeDetail(), "2026-01-05");
	const orderRecords = emitted.filter((r) => r.stream === "orders");
	assert.equal(orderRecords.length, 1);
});

// ─── Invariant 2: merge order (list items first, then detail-only) ───────

test("emitOrderAndItems: items emit in mergeOrderItems order (list first, then detail-only appended)", async () => {
	const { deps, emitted } = makeRecordingDeps();
	// ASINs must be exactly 10 uppercase alphanumeric (schema/asinSchema);
	// currency strings must be $N.NN (schema/currencyStringSchema). The
	// original fixture used 11-char ASINs ("B01LIST0001") + cents-less
	// prices ("$10") which would have SKIP_RESULT'd in production — the
	// hand-rolled mock let them through silently.
	const listOrder = makeListOrder({
		items: [{ asin: "B01LIST000", name: "List Item", url: null }],
	});
	const detail = makeDetail({
		items: [
			makeDetailItem({
				asin: "B01LIST000",
				name: "List Item",
				unit_price: "$10.00",
			}),
			makeDetailItem({
				asin: "B02DETAIL0",
				name: "Detail-Only Item",
				unit_price: "$20.00",
			}),
		],
	});
	await emitOrderAndItems(deps, listOrder, detail, "2026-01-05");

	const itemRecords = emitted.filter((r) => r.stream === "order_items");
	assert.equal(itemRecords.length, 2, "expected list item + detail-only item");
	assert.equal(
		itemRecords[0]?.data.asin,
		"B01LIST000",
		"list-page item emitted first",
	);
	assert.equal(
		itemRecords[1]?.data.asin,
		"B02DETAIL0",
		"detail-only item appended after",
	);
});

// ─── Invariant 3: scope.streams filters cleanly ──────────────────────────

test("emitOrderAndItems: wantsOrders=false suppresses order records but not items", async () => {
	const { deps, emitted } = makeRecordingDeps({ wantsOrders: false });
	await emitOrderAndItems(deps, makeListOrder(), makeDetail(), "2026-01-05");
	assert.equal(emitted.filter((r) => r.stream === "orders").length, 0);
	assert.ok(emitted.filter((r) => r.stream === "order_items").length > 0);
});

test("emitOrderAndItems: wantsItems=false suppresses item records but not the order", async () => {
	const { deps, emitted } = makeRecordingDeps({ wantsItems: false });
	await emitOrderAndItems(deps, makeListOrder(), makeDetail(), "2026-01-05");
	assert.equal(emitted.filter((r) => r.stream === "order_items").length, 0);
	assert.equal(emitted.filter((r) => r.stream === "orders").length, 1);
});

test("emitOrderAndItems: both streams disabled → nothing emitted", async () => {
	const { deps, emitted } = makeRecordingDeps({
		wantsOrders: false,
		wantsItems: false,
	});
	await emitOrderAndItems(deps, makeListOrder(), makeDetail(), "2026-01-05");
	assert.equal(emitted.length, 0);
});

// ─── Invariant 4: detail-null fallback (skipDetail mode) ─────────────────

test("emitOrderAndItems: detail=null — still emits order record + list-page items only", async () => {
	const { deps, emitted } = makeRecordingDeps();
	const listOrder = makeListOrder({
		items: [
			{ asin: "B01ONE0000", name: "One", url: null },
			{ asin: "B02TWO0000", name: "Two", url: null },
		],
	});
	await emitOrderAndItems(deps, listOrder, null, "2026-01-05");

	const orderRecord = emitted.find((r) => r.stream === "orders");
	assert.ok(orderRecord);
	// List-page fields survive into the order record when detail is absent.
	assert.equal(orderRecord.data.delivery_status, "Delivered");

	const items = emitted.filter((r) => r.stream === "order_items");
	assert.equal(items.length, 2);
	assert.equal(items[0]?.data.asin, "B01ONE0000");
	assert.equal(items[1]?.data.asin, "B02TWO0000");
});

// ─── Invariant 5: item-level id stability (merge dedup + itemId) ─────────

test("emitOrderAndItems: duplicate ASINs across list+detail dedupe to one item record", async () => {
	const { deps, emitted } = makeRecordingDeps();
	const listOrder = makeListOrder({
		items: [
			{ asin: "B01DUPDUP0", name: "Dup", url: null },
			{ asin: "B01DUPDUP0", name: "Dup Again", url: null }, // same ASIN twice on list
		],
	});
	const detail = makeDetail({
		items: [
			makeDetailItem({ asin: "B01DUPDUP0", name: "Dup", unit_price: "$5.00" }),
		],
	});
	await emitOrderAndItems(deps, listOrder, detail, "2026-01-05");

	const items = emitted.filter((r) => r.stream === "order_items");
	assert.equal(
		items.length,
		1,
		"duplicate ASINs must collapse to one emitted item record",
	);
});

// ─── Invariant 6: emittedAt threads into the order record ────────────────

test("emitOrderAndItems: emittedAt propagates into the order record's fetched_at", async () => {
	const frozen = "2026-04-22T09:30:00.000Z";
	const { deps, emitted } = makeRecordingDeps({ emittedAt: frozen });
	await emitOrderAndItems(deps, makeListOrder(), makeDetail(), "2026-01-05");
	const orderRecord = emitted.find((r) => r.stream === "orders");
	assert.ok(orderRecord);
	assert.equal(orderRecord.data.fetched_at, frozen);
});

test("runYear reports non-PII granular progress across list pages and order processing", () => {
	const src = readFileSync(AMAZON_INDEX_PATH, "utf8");
	const progressMessages = [
		/Amazon year \$\{year\}: scanning page \$\{pageCount \+ 1\}/,
		/Amazon year \$\{year\}: no more orders after \$\{yearOrderCount\} seen/,
		/Amazon year \$\{year\}: page \$\{pageCount \+ 1\} found \$\{orders\.length\} orders/,
		/Amazon year \$\{year\}: processing order \$\{index \+ 1\}\/\$\{orders\.length\} on page \$\{pageCount \+ 1\}/,
	];
	for (const message of progressMessages) {
		assert.match(src, message);
	}
	assert.match(src, /deps\.progress\([\s\S]*?\{ stream: "orders" \}/);
	assert.doesNotMatch(src, /processing order \$\{o\.orderId\}/);
});

// ─── Unparseable-order-date drop evidence ─────────────────────────────────

// processListOrder with skipDetail:true never touches `page` for a parseable
// date, and for an unparseable date it returns false before any page access.
// A throwing stand-in proves we never reach the browser on the drop path.
const NEVER_CALLED_PAGE = new Proxy(
	{},
	{
		get(): never {
			throw new Error("page must not be touched in this test");
		},
	},
) as Page;

function makeRunFlags(): RunFlags {
	return {
		detailAttempts: 0,
		detailCaptured: false,
		failedDetailCaptured: false,
		repairAttempted: false,
		sessionRepairRequired: false,
		temporaryDetailFailures: 0,
	};
}

test("processListOrder: unparseable order date returns false (dropped) and emits no records", async () => {
	const { deps, emitted } = makeRecordingDeps({ skipDetail: true });
	const dropped = await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		makeRunFlags(),
		makeListOrder({ orderDateRaw: "not a real date" }),
	);
	assert.equal(dropped, false);
	assert.equal(emitted.length, 0, "a dropped order must emit no records");
});

test("processListOrder: empty/null order date is also a drop", async () => {
	const { deps, emitted } = makeRecordingDeps({ skipDetail: true });
	for (const raw of [null, ""]) {
		const dropped = await processListOrder(
			NEVER_CALLED_PAGE,
			deps,
			makeRunFlags(),
			makeListOrder({ orderDateRaw: raw }),
		);
		assert.equal(dropped, false);
	}
	assert.equal(emitted.length, 0);
});

test("processListOrder: parseable order date returns true and emits the order", async () => {
	const { deps, emitted } = makeRecordingDeps({ skipDetail: true });
	const processed = await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		makeRunFlags(),
		makeListOrder({ orderDateRaw: "January 5, 2026" }),
	);
	assert.equal(processed, true);
	assert.ok(
		emitted.some((r) => r.stream === "orders"),
		"a processed order must emit an 'orders' record",
	);
});

test("runYear emits bounded per-year unparseable-date SKIP_RESULT evidence with no raw order ids", () => {
	const src = readFileSync(AMAZON_INDEX_PATH, "utf8");
	// The count is accumulated from processListOrder's boolean result.
	assert.match(src, /unparseableDateCount\+\+/);
	// One bounded per-year SKIP_RESULT summary, gated on count > 0, count + total only.
	assert.match(
		src,
		/type:\s*"SKIP_RESULT"[\s\S]*?stream:\s*"orders"[\s\S]*?reason:\s*"unparseable_order_date"/,
	);
	assert.match(src, /dropped \$\{unparseableDateCount\} order row/);
	assert.match(src, /with unparseable dates \(of \$\{yearOrderCount\} seen\)/);
	assert.match(
		src,
		/diagnostics:\s*\{\s*dropped:\s*unparseableDateCount,\s*total_seen:\s*yearOrderCount,\s*year,?\s*\}/,
	);
	// The summary is tagged to the orders stream for dashboard routing.
	assert.match(src, /stream:\s*"orders"/);
	// It must NOT interpolate any raw order identifier.
	assert.doesNotMatch(src, /unparseable[\s\S]*?\$\{[^}]*orderId[^}]*\}/);
});

test("collect path does not advance a year cursor after unparseable order-date drops", () => {
	const src = readFileSync(AMAZON_INDEX_PATH, "utf8");
	assert.match(
		src,
		/if \(unparseableDateCount === 0\) \{[\s\S]*?last_scraped:\s*nowIso\(\),[\s\S]*?\} else \{[\s\S]*?Not advancing Amazon year \$\{year\} cursor/,
		"last_scraped must only advance on a year with zero required-row drops",
	);
});

test("amazon manifest: successful runs have a bounded freshness window", () => {
	// The bounded window is what this test is for: without
	// `maximum_staleness_seconds`, freshness is `unknown` and a successful run
	// cannot project `current`.
	//
	// The mode assertion moved from a hard-coded "manual" to the connector's
	// own declared facts. Amazon declares `background_safe: true` — the
	// browser session persists after the owner's first login — and mode is now
	// DERIVED from that (see reference-implementation/runtime/
	// refresh-mode-derivation.ts). Pinning "manual" here contradicted the
	// manifest's own background-safety claim.
	const manifest = JSON.parse(readFileSync(AMAZON_MANIFEST_PATH, "utf8")) as {
		capabilities?: {
			refresh_policy?: {
				background_safe?: boolean;
				interaction_posture?: string;
				maximum_staleness_seconds?: number;
				recommended_mode?: string;
			};
		};
	};
	const policy = manifest.capabilities?.refresh_policy;
	assert.equal(policy?.maximum_staleness_seconds, 86_400);
	// Amazon's first login is owner-present, and the session then persists.
	assert.equal(policy?.interaction_posture, "otp_likely");
	assert.equal(policy?.background_safe, true);
	assert.equal(policy?.recommended_mode, "automatic");
});

// ─── Empty list-page classification ──────────────────────────────────────

function makeEmptyPageDiagnostics(
	overrides: Partial<ListPageDiagnostics> = {},
): ListPageDiagnostics {
	return {
		any_card: 0,
		any_order_header: 0,
		body_preview: "",
		captcha: "false",
		no_orders_text: "false",
		order_cards: 0,
		sign_in_form: false,
		title: "Your Orders",
		url: "https://www.amazon.com/your-orders/orders?timeFilter=year-2024&startIndex=0",
		...overrides,
	};
}

test("classifyEmptyListPageDiagnostics: captcha/sign-in pages abort cursor advancement", () => {
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(
			makeEmptyPageDiagnostics({ captcha: "true" }),
			0,
		),
		{
			action: "abort",
			reason: "source_auth_or_challenge",
		},
	);
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(
			makeEmptyPageDiagnostics({ sign_in_form: true }),
			0,
		),
		{
			action: "abort",
			reason: "source_auth_or_challenge",
		},
	);
});

test("classifyEmptyListPageDiagnostics: selector drift aborts cursor advancement", () => {
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(
			makeEmptyPageDiagnostics({ any_order_header: 2 }),
			0,
		),
		{
			action: "abort",
			reason: "selector_drift",
		},
	);
});

test("classifyEmptyListPageDiagnostics: only proven terminal empty pages advance the cursor", () => {
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(
			makeEmptyPageDiagnostics({ no_orders_text: "true" }),
			0,
		),
		{
			action: "terminal",
			reason: "no_orders_text",
		},
	);
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(makeEmptyPageDiagnostics(), 10),
		{
			action: "terminal",
			reason: "pagination_exhausted",
		},
	);
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(makeEmptyPageDiagnostics(), 0),
		{
			action: "abort",
			reason: "empty_first_page_without_terminal_signal",
		},
	);
});

test("classifyEmptyListPageDiagnostics: current empty-year copy is terminal despite buy-again carousel sentinel", () => {
	const html = readFileSync(AMAZON_EMPTY_YEAR_FIXTURE, "utf8");
	const visibleText = html.replace(/<[^>]+>/g, " ");
	const noOrdersRe = new RegExp(AMAZON_NO_ORDERS_TEXT_PATTERN, "i");

	assert.match(visibleText, noOrdersRe);
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(
			makeEmptyPageDiagnostics({
				any_card: 1,
				no_orders_text: noOrdersRe.test(visibleText).toString(),
				order_cards: 1,
			}),
			0,
		),
		{
			action: "terminal",
			reason: "no_orders_text",
		},
	);
});

test("Amazon empty-page diagnostics retain structural facts but redact page text, title, and URL", () => {
	const redacted = redactAmazonListPageDiagnostics(
		makeEmptyPageDiagnostics({
			body_preview: "RECIPIENT NAME 123 Main Street",
			title: "Orders for Recipient Name",
			url: "https://www.amazon.com/your-orders?account=private",
		}),
	);

	assert.deepEqual(redacted, {
		...makeEmptyPageDiagnostics(),
		body_preview: "",
		title: "",
		url: "",
	});
	assert.doesNotMatch(
		JSON.stringify(redacted),
		/RECIPIENT|123 Main Street|amazon\.com|private/,
	);
});

test("scrapeListPage: a failed list navigation cannot reuse the prior page as a successful page", async () => {
	const staleListHtml = readFileSync(
		new URL("./__fixtures__/orders-list-minimal.html", import.meta.url),
		"utf8",
	);
	const messages: EmittedMessage[] = [];
	const page = Object.assign({} as Page, {
		content: (): Promise<string> => Promise.resolve(staleListHtml),
		goto: (): Promise<null> =>
			Promise.reject(new Error("net::ERR_CONNECTION_RESET")),
		locator: (): { first: () => { waitFor: () => Promise<null> } } => ({
			first: () => ({ waitFor: (): Promise<null> => Promise.resolve(null) }),
		}),
	});

	await assert.rejects(
		scrapeListPage(page, null, 2026, 10, (message) => {
			messages.push(message);
			return Promise.resolve();
		}),
		/amazon_list_page_navigation_failed/,
	);

	const skip = messages.find((message) => message.type === "SKIP_RESULT");
	assert.ok(skip, "navigation failure must produce a durable diagnostic");
	assert.equal(skip?.reason, "list_page_navigation_failed");
	assert.doesNotMatch(JSON.stringify(messages), /orders-list-minimal|B0/);
});

test("scrapeListPage: a card with no parseable order id is dropped AND reported, alongside a card that survives", async () => {
	// The "prove the drop happens today, is invisible today" half of the pair.
	// One card has a normal `.yohtmlc-order-id`; the other (modeling a
	// never-shipped/cancelled order rendering under a variant Amazon uses for
	// that order type) has none. Before this fix, the second card vanished
	// from `orders` with zero SKIP_RESULT anywhere — see
	// `countOrderCardsWithoutOrderId` in parsers.ts for the mechanism.
	const html = readFileSync(
		new URL(
			"./__fixtures__/orders-list-one-card-missing-order-id.html",
			import.meta.url,
		),
		"utf8",
	);
	const messages: EmittedMessage[] = [];
	const page = Object.assign({} as Page, {
		content: (): Promise<string> => Promise.resolve(html),
		goto: (): Promise<null> => Promise.resolve(null),
		locator: (): { first: () => { waitFor: () => Promise<null> } } => ({
			first: () => ({ waitFor: (): Promise<null> => Promise.resolve(null) }),
		}),
	});

	const orders = await scrapeListPage(page, null, 2024, 0, (message) => {
		messages.push(message);
		return Promise.resolve();
	});

	assert.equal(
		orders.length,
		1,
		"only the card with a parseable order id survives",
	);
	assert.equal(orders[0]?.orderId, "111-2222222-3333333");

	const skip = messages.find((message) => message.type === "SKIP_RESULT");
	assert.ok(skip, "the drop must be reported, not silent");
	assert.equal(skip?.reason, "list_page_order_id_not_found");
	assert.deepEqual(skip?.diagnostics, { dropped_card_count: 1 });
});

test("scrapeListPage: a page-2 renderer diagnostic failure aborts without STATE or coverage", async () => {
	const messages: EmittedMessage[] = [];
	const page = Object.assign({} as Page, {
		content: (): Promise<string> =>
			Promise.resolve("<html><body></body></html>"),
		evaluate: (): Promise<never> =>
			Promise.reject(new Error("private renderer URL and owner label")),
		goto: (): Promise<null> => Promise.resolve(null),
		locator: (): { first: () => { waitFor: () => Promise<null> } } => ({
			first: () => ({ waitFor: (): Promise<null> => Promise.resolve(null) }),
		}),
	});

	await assert.rejects(
		scrapeListPage(page, null, 2026, 10, (message) => {
			messages.push(message);
			return Promise.resolve();
		}),
		/amazon_empty_list_page_renderer_diagnostics_failed/,
	);

	const skip = messages.find((message) => message.type === "SKIP_RESULT");
	assert.ok(skip, "renderer failure must produce a structural diagnostic");
	assert.equal(skip?.reason, "renderer_diagnostics_failed");
	assert.deepEqual(skip?.diagnostics, { error_class: "Error" });
	assert.equal(
		messages.some(
			(message) =>
				message.type === "STATE" || message.type === "DETAIL_COVERAGE",
		),
		false,
		"renderer failure must not emit durable progress or coverage",
	);
	assert.doesNotMatch(
		JSON.stringify(messages),
		/private renderer|owner label|amazon\.com/,
	);
});

// ─── Proven-empty regression guard (prior-orders evidence) ────────────────
//
// A YEAR that has already yielded orders must never be able to complete a run
// as "proven empty". Amazon's own year-scoped empty copy is trustworthy for a
// year the owner did not shop; for a year we have already measured, the same
// page is a contradiction, not a result.
//
// The evidence is PER-YEAR, unlike H-E-B's account-wide checkpoint, because
// Amazon is year-partitioned: an account with thousands of orders legitimately
// renders "Looks like you didn't place an order in 2015." for an unshopped
// year, and that year must keep reporting empty forever.

const RESOLVED_EMPTY_YEAR_DIAG = (): ListPageDiagnostics =>
	makeEmptyPageDiagnostics({ no_orders_text: "true" });

/**
 * A Page stub serving Amazon's real captured empty-year list page. `content()`
 * feeds the DOM parser (which finds no order cards, the trigger for the
 * empty-page branch) and `evaluate()` returns diagnostics derived from the
 * SAME fixture text, so `no_orders_text` is decided by Amazon's own copy
 * rather than asserted by the test.
 */
function makeEmptyYearPageStub(): Page {
	const html = readFileSync(AMAZON_EMPTY_YEAR_FIXTURE, "utf8");
	const visibleText = html.replace(/<[^>]+>/g, " ");
	return Object.assign({} as Page, {
		content: (): Promise<string> => Promise.resolve(html),
		evaluate: (): Promise<ListPageDiagnostics> =>
			Promise.resolve(
				makeEmptyPageDiagnostics({
					no_orders_text: new RegExp(AMAZON_NO_ORDERS_TEXT_PATTERN, "i")
						.test(visibleText)
						.toString(),
				}),
			),
		goto: (): Promise<null> => Promise.resolve(null),
		locator: (): { first: () => { waitFor: () => Promise<null> } } => ({
			first: () => ({ waitFor: (): Promise<null> => Promise.resolve(null) }),
		}),
		screenshot: (): Promise<null> => Promise.resolve(null),
	});
}

test("classifyEmptyListPageDiagnostics: source-reported empty for a year with NO prior orders stays proven-empty", () => {
	// Preserves existing behavior. A year the owner did not shop is the case
	// where zero coverage is an honest measurement.
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(RESOLVED_EMPTY_YEAR_DIAG(), 0, {
			hasPriorOrders: false,
		}),
		{
			action: "terminal",
			reason: "no_orders_text",
		},
	);
});

test("classifyEmptyListPageDiagnostics: the prior-orders argument defaults to absent, so callers cannot silently opt in", () => {
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(RESOLVED_EMPTY_YEAR_DIAG(), 0),
		{
			action: "terminal",
			reason: "no_orders_text",
		},
	);
});

test("classifyEmptyListPageDiagnostics: source-reported empty for a year WITH prior orders aborts instead of proving zero", () => {
	// The defect this guard closes: without it, this exact input returned
	// {action:"terminal", reason:"no_orders_text"}, letting a year holding
	// hundreds of stored orders advance its cursor on a fabricated proven-zero.
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(RESOLVED_EMPTY_YEAR_DIAG(), 0, {
			hasPriorOrders: true,
		}),
		{
			action: "abort",
			reason: "amazon_empty_history_after_prior_orders",
		},
	);
});

test("classifyEmptyListPageDiagnostics: a legitimately empty year on an account with orders in OTHER years stays terminal", () => {
	// THE year-partition requirement, driven through Amazon's real 2015
	// empty-year capture. `priorOrdersEvidenceForYear` scopes evidence to the
	// year being scraped, so 2015 carries `hasPriorOrders: false` even though
	// 2024 and 2026 hold orders. Account-wide evidence would abort this year on
	// every run forever and break the incremental year sweep.
	const yearsState = {
		"2024": {
			frozen: true,
			last_scraped: "2026-08-01T00:00:00.000Z",
			order_count: 312,
		},
		"2026": {
			frozen: false,
			last_scraped: "2026-08-01T00:00:00.000Z",
			order_count: 44,
		},
	};
	const html = readFileSync(AMAZON_EMPTY_YEAR_FIXTURE, "utf8");
	const visibleText = html.replace(/<[^>]+>/g, " ");
	const noOrdersRe = new RegExp(AMAZON_NO_ORDERS_TEXT_PATTERN, "i");
	assert.match(
		visibleText,
		noOrdersRe,
		"the fixture must still carry Amazon's year-scoped empty copy",
	);

	assert.deepEqual(priorOrdersEvidenceForYear(yearsState, 2015), {
		hasPriorOrders: false,
	});
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(
			makeEmptyPageDiagnostics({
				any_card: 1,
				no_orders_text: "true",
				order_cards: 1,
			}),
			0,
			priorOrdersEvidenceForYear(yearsState, 2015),
		),
		{ action: "terminal", reason: "no_orders_text" },
		"an unshopped year must stay proven-empty on an account with orders elsewhere",
	);

	// Same account, same run, a year that DID yield orders: opposite verdict.
	assert.deepEqual(priorOrdersEvidenceForYear(yearsState, 2024), {
		hasPriorOrders: true,
	});
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(
			RESOLVED_EMPTY_YEAR_DIAG(),
			0,
			priorOrdersEvidenceForYear(yearsState, 2024),
		),
		{ action: "abort", reason: "amazon_empty_history_after_prior_orders" },
	);
});

test("classifyEmptyListPageDiagnostics: an auth/challenge page keeps its own reason even when the year has prior orders", () => {
	// Ordering guard, upper half. The auth check stays ABOVE the new branch:
	// when a challenge is actually established, that is the more specific and
	// more actionable diagnosis, and it must not be relabelled.
	const authOverrides: Partial<ListPageDiagnostics>[] = [
		{ captcha: "true" },
		{ sign_in_form: true },
	];
	for (const override of authOverrides) {
		assert.deepEqual(
			classifyEmptyListPageDiagnostics(
				makeEmptyPageDiagnostics({ no_orders_text: "true", ...override }),
				0,
				{
					hasPriorOrders: true,
				},
			),
			{ action: "abort", reason: "source_auth_or_challenge" },
		);
	}
});

test("classifyEmptyListPageDiagnostics: selector drift keeps its own reason even when the year has prior orders", () => {
	// Ordering guard, middle. Real markup change stays diagnosable as drift.
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(
			makeEmptyPageDiagnostics({ any_order_header: 2, no_orders_text: "true" }),
			0,
			{
				hasPriorOrders: true,
			},
		),
		{ action: "abort", reason: "selector_drift" },
	);
});

test("classifyEmptyListPageDiagnostics: prior orders do not relabel a page that never claimed to be empty", () => {
	// Ordering guard, lower half. The new branch is gated on `no_orders_text`,
	// so the existing terminal/abort verdicts for pages that make no empty claim
	// are untouched — the guard adds a failure mode, it does not swallow others.
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(makeEmptyPageDiagnostics(), 10, {
			hasPriorOrders: true,
		}),
		{
			action: "terminal",
			reason: "pagination_exhausted",
		},
	);
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(makeEmptyPageDiagnostics(), 0, {
			hasPriorOrders: true,
		}),
		{
			action: "abort",
			reason: "empty_first_page_without_terminal_signal",
		},
	);
});

test("classifyEmptyListPageDiagnostics: a later empty page in a year that just yielded orders is ordinary exhaustion", () => {
	// The guard is scoped to startIndex === 0 because only the FIRST page of a
	// year claims the year is empty. Amazon can serve its empty-state copy on a
	// trailing page; the rows before it were collected on THIS run, so this is
	// pagination exhaustion, not a contradiction. Without the startIndex scope,
	// every incremental run over a year with prior orders would abort on its
	// last page — the guard would break the connector for exactly the accounts
	// it exists to protect.
	assert.deepEqual(
		classifyEmptyListPageDiagnostics(RESOLVED_EMPTY_YEAR_DIAG(), 10, {
			hasPriorOrders: true,
		}),
		{
			action: "terminal",
			reason: "no_orders_text",
		},
	);
});

test("priorOrdersEvidenceForYear: a prior year order_count > 0 is what arms the guard", () => {
	// Pins the year-state-to-evidence link that collect() depends on. Without
	// this test, hardcoding `hasPriorOrders: false` in collect() would disarm
	// the guard for every connection while every other test still passed.
	const yearsState = {
		"2019": {
			frozen: true,
			last_scraped: "2026-08-01T00:00:00.000Z",
			order_count: 0,
		},
		"2024": {
			frozen: true,
			last_scraped: "2026-08-01T00:00:00.000Z",
			order_count: 312,
		},
	};
	assert.deepEqual(priorOrdersEvidenceForYear(yearsState, 2024), {
		hasPriorOrders: true,
	});
	// A year scraped and found genuinely empty commits `order_count: 0`. It must
	// stay free to report empty again — this is the year-partition case that
	// makes count, not cursor existence, the right evidence.
	assert.deepEqual(priorOrdersEvidenceForYear(yearsState, 2019), {
		hasPriorOrders: false,
	});
	// A never-scraped year has no cursor at all.
	assert.deepEqual(priorOrdersEvidenceForYear(yearsState, 2015), {
		hasPriorOrders: false,
	});
});

test("scrapeListPage: Amazon's empty-year page aborts when this year already yielded orders", async () => {
	// Integration half, through the same live empty-year capture the
	// proven-empty test uses. Same page, same markup, opposite verdict — the
	// only difference is that this year has a prior non-zero order count.
	const messages: EmittedMessage[] = [];
	const page = makeEmptyYearPageStub();

	await assert.rejects(
		scrapeListPage(
			page,
			null,
			2024,
			0,
			(message) => {
				messages.push(message);
				return Promise.resolve();
			},
			{ hasPriorOrders: true },
		),
		/amazon_empty_list_page_amazon_empty_history_after_prior_orders/,
		"a year with prior orders cannot be proven empty by a page render",
	);

	// The failure must be legible to the owner, and must not blame anything the
	// page does not establish.
	const skip = messages.find(
		(message) =>
			message.type === "SKIP_RESULT" &&
			message.reason === "amazon_empty_history_after_prior_orders",
	) as { diagnostics: Record<string, unknown>; message: string } | undefined;
	assert.ok(skip, "the abort must surface a SKIP_RESULT the owner can read");
	assert.match(skip.message, /previously collected orders/);
	assert.match(skip.message, /retained and untouched/);
	assert.doesNotMatch(
		skip.message,
		/selector|drift/i,
		"selector drift is not established and must not be blamed",
	);
	assert.doesNotMatch(
		skip.message,
		/block|bot|captcha/i,
		"a bot block is not established and must not be blamed",
	);
	assert.equal(skip.diagnostics.has_prior_orders, true);
	assert.equal(skip.diagnostics.year, 2024);

	// Nothing may be recorded, no cursor advanced, no coverage claimed. The
	// connector protocol has no delete or tombstone message, so proving it
	// emitted no RECORD and no STATE proves the stored copy and the prior year
	// cursor are both untouched.
	assert.deepEqual(
		[...new Set(messages.map((message) => message.type))].sort(),
		["SKIP_RESULT"],
		"the abort's only durable output is the owner-facing SKIP_RESULT",
	);
});

test("scrapeListPage: the same empty-year page still succeeds as proven-empty for a year with no prior orders", async () => {
	// The preservation half of the pair above: identical page, no prior orders,
	// no throw, no diagnostic. A first-ever run on a genuinely empty year is
	// unaffected by the guard.
	const messages: EmittedMessage[] = [];
	const orders = await scrapeListPage(
		makeEmptyYearPageStub(),
		null,
		2015,
		0,
		(message) => {
			messages.push(message);
			return Promise.resolve();
		},
	);

	assert.deepEqual(
		orders,
		[],
		"an empty year yields no orders and does not throw",
	);
	assert.equal(
		messages.some((message) => message.type === "SKIP_RESULT"),
		false,
		"a proven-empty year emits no skip diagnostic",
	);
});

// ─── planIncrementalYears ─────────────────────────────────────────────────

test("planIncrementalYears: no prior state → all discovered years planned (initial backfill)", () => {
	const years = [2026, 2025, 2024, 2023, 2022, 2010, 2005];
	const { planned, skipped } = planIncrementalYears(years, {}, 2026);
	assert.deepEqual(planned, years);
	assert.equal(skipped.length, 0);
});

test("planIncrementalYears: with prior state, current and previous year always planned", () => {
	const yearsState = {
		"2025": {
			frozen: false,
			last_scraped: "2026-01-01T00:00:00.000Z",
			order_count: 5,
		},
		"2024": {
			frozen: false,
			last_scraped: "2026-01-01T00:00:00.000Z",
			order_count: 10,
		},
		"2020": {
			frozen: true,
			last_scraped: "2026-01-01T00:00:00.000Z",
			order_count: 3,
		},
	};
	const years = [2026, 2025, 2024, 2023, 2020];
	const { planned } = planIncrementalYears(years, yearsState, 2026);
	assert.ok(planned.includes(2026), "current year must be planned");
	assert.ok(planned.includes(2025), "previous year must be planned");
});

test("planIncrementalYears: historical years with prior last_scraped are skipped", () => {
	const yearsState = {
		"2025": {
			frozen: false,
			last_scraped: "2026-01-01T00:00:00.000Z",
			order_count: 5,
		},
		"2024": {
			frozen: false,
			last_scraped: "2025-06-01T00:00:00.000Z",
			order_count: 12,
		},
		"2023": {
			frozen: false,
			last_scraped: "2025-06-01T00:00:00.000Z",
			order_count: 8,
		},
		"2010": {
			frozen: false,
			last_scraped: "2025-01-01T00:00:00.000Z",
			order_count: 2,
		},
	};
	const years = [2026, 2025, 2024, 2023, 2010];
	const { planned, skipped } = planIncrementalYears(years, yearsState, 2026);
	// Only current (2026) and previous (2025) should be planned
	assert.deepEqual(planned, [2026, 2025]);
	// 2024, 2023, 2010 have prior last_scraped and are ≥2 years old
	assert.equal(skipped.length, 3);
	assert.ok(skipped.some((s) => s.year === 2024));
	assert.ok(skipped.some((s) => s.year === 2023));
	assert.ok(skipped.some((s) => s.year === 2010));
});

test("planIncrementalYears: newly-discovered historical year (no prior state) is still planned", () => {
	// Scenario: user adds a new Amazon account with orders going back to 2015,
	// but only 2025/2026 have been scraped so far. 2015 has no prior state.
	const yearsState = {
		"2025": {
			frozen: false,
			last_scraped: "2026-01-01T00:00:00.000Z",
			order_count: 5,
		},
	};
	const years = [2026, 2025, 2015];
	const { planned } = planIncrementalYears(years, yearsState, 2026);
	assert.ok(
		planned.includes(2015),
		"newly-discovered year with no prior state must be included",
	);
});

test("planIncrementalYears: full refresh (no prior state) plans all discovered years", () => {
	// Simulates a forced full refresh where state is reset/null.
	const years = [2026, 2025, 2024, 2023, 2015, 2005];
	const { planned, skipped } = planIncrementalYears(years, {}, 2026);
	assert.deepEqual(
		planned,
		years,
		"full refresh with empty state must plan all years",
	);
	assert.equal(skipped.length, 0);
});

test("planIncrementalYears: legacy state shape (flat years object) treated as prior state", () => {
	// Legacy state may store years without last_scraped (order_count=0 first-pass).
	// Only entries WITH last_scraped should trigger skip.
	const yearsState = {
		"2024": {
			frozen: false,
			last_scraped: "2025-12-01T00:00:00.000Z",
			order_count: 3,
		},
		"2023": { frozen: false, order_count: 0, last_scraped: "" }, // empty last_scraped = no proof of scrape
	};
	const years = [2026, 2025, 2024, 2023];
	const { planned } = planIncrementalYears(years, yearsState, 2026);
	// 2024 has a real last_scraped → skip it. 2023 has empty string → falsy → treat as not scraped
	assert.ok(planned.includes(2026));
	assert.ok(planned.includes(2025));
	assert.ok(
		!planned.includes(2024),
		"2024 with real last_scraped should be skipped",
	);
	assert.ok(
		planned.includes(2023),
		"2023 with empty last_scraped treated as not-yet-scraped",
	);
});

// ─── Trailing orders STATE persistence when the year loop emits nothing ─────
//
// `planIncrementalYears` always plans the current AND previous year — and
// the previous year CAN already be frozen — so a run can have `years.length
// > 0` while every iteration `continue`s before reaching a STATE emit. A
// guard keyed on `years.length === 0` misses this case; `collect()` tracks
// whether the loop actually emitted STATE instead (`ordersStateEmitted`),
// which `shouldEmitTrailingOrdersState` decides on.

test("shouldEmitTrailingOrdersState: fires when every planned year was frozen (loop ran, never emitted) and known-hydrated proof exists", () => {
	// Reproduces the precondition directly: planIncrementalYears plans both
	// years (so years.length > 0, the old years.length===0 guard would NOT
	// fire), but both are already frozen, so collect()'s loop would `continue`
	// on every iteration and never set ordersStateEmitted.
	const yearsState = {
		"2025": {
			frozen: true,
			last_scraped: "2026-01-01T00:00:00.000Z",
			order_count: 5,
		},
		"2026": {
			frozen: true,
			last_scraped: "2026-07-01T00:00:00.000Z",
			order_count: 2,
		},
	};
	const { planned } = planIncrementalYears([2026, 2025], yearsState, 2026);
	assert.ok(
		planned.length > 0,
		"both years are still planned even though frozen (precondition: years.length > 0)",
	);

	const ordersStateEmitted = false; // every planned year was frozen; the loop never reached its STATE emit
	const hydratedOrders = new Map([["ord-1", "fp-1"]]); // recovery pass (or a carried-forward map) has durable progress
	assert.equal(
		shouldEmitTrailingOrdersState(ordersStateEmitted, hydratedOrders),
		true,
		"recovery-pass progress must still reach a STATE emit even though the year loop ran (years.length > 0) but froze out",
	);
});

test("shouldEmitTrailingOrdersState: does not fire when the loop already emitted STATE", () => {
	assert.equal(
		shouldEmitTrailingOrdersState(true, new Map([["ord-1", "fp-1"]])),
		false,
		"no redundant trailing emit when the loop's own STATE emit already carried the same progress forward",
	);
});

test("shouldEmitTrailingOrdersState: does not fire when there is no known-hydrated progress to persist", () => {
	assert.equal(
		shouldEmitTrailingOrdersState(false, new Map()),
		false,
		"nothing to carry forward — a trailing emit here would just repeat the year cursors for no reason",
	);
});

// ─── Progress signal invariants ───────────────────────────────────────────

test("auth-challenge PROGRESS signal: emitted with stream=orders tag on sign-in/CAPTCHA detection", () => {
	const src = readFileSync(AMAZON_INDEX_PATH, "utf8");
	// The PROGRESS emit must exist and reference stream: "orders" so the dashboard
	// can route the signal to the right stream column.
	assert.match(
		src,
		/type:\s*"PROGRESS"[\s\S]{0,200}stream:\s*"orders"[\s\S]{0,200}sign-in or CAPTCHA challenge detected/,
	);
	// The challenge message must not interpolate any order ID or user-identifying field.
	assert.doesNotMatch(src, /sign-in or CAPTCHA.*\$\{.*orderId/);
	assert.doesNotMatch(src, /sign-in or CAPTCHA.*\$\{.*recipient_name/);
});

test("PROGRESS messages do not interpolate Amazon order PII (recipient name, address, payment)", () => {
	const src = readFileSync(AMAZON_INDEX_PATH, "utf8");
	// Scan all PROGRESS message template literals for banned field references.
	// SKIP_RESULT messages may carry opaque IDs (order numbers) for diagnostics,
	// but PROGRESS messages are operator-visible and must stay PII-free.
	const progressBlocks = src.matchAll(
		/type:\s*"PROGRESS"[\s\S]{0,500}?(?=type:|$)/g,
	);
	const banned =
		/\b(?:recipient_name|shipping_address|payment_method|detail\.gift_order|r\.name|order\.name)\b/;
	for (const block of progressBlocks) {
		assert.doesNotMatch(
			block[0],
			banned,
			`PROGRESS block leaks PII: ${block[0].slice(0, 120)}`,
		);
	}
});

// ─── order_items detail coverage evidence ─────────────────────────────────
//
// Amazon enumerates the full per-year order list BEFORE hydrating any order
// detail page, so the processed-order set is a real "considered" denominator.
// The order_items stream is enriched by the detail page; a detail fetch that
// returns null still emits the list-page items but loses the detail
// enrichment — a degraded gap, not silence. These tests pin that the
// DETAIL_COVERAGE projection reports that honestly (denominator, hydrated
// numerator, gap set, policy-skip set) using the shared emitDetailCoverage
// helper, and that no per-order PII beyond the opaque order id crosses in.

type DetailCoverage = Extract<EmittedMessage, { type: "DETAIL_COVERAGE" }>;
type DetailGap = Extract<EmittedMessage, { type: "DETAIL_GAP" }>;

function findDetailCoverage(
	messages: EmittedMessage[],
): DetailCoverage | undefined {
	return messages.find(
		(m): m is DetailCoverage => m.type === "DETAIL_COVERAGE",
	);
}

function findDetailGaps(messages: EmittedMessage[]): DetailGap[] {
	return messages.filter((m): m is DetailGap => m.type === "DETAIL_GAP");
}

test("classifyDetailOutcome: skipDetail→unaccounted, null→gap, detail→hydrated", () => {
	assert.equal(
		classifyDetailOutcome(true, null),
		"unaccounted",
		"policy-skip unaccounted",
	);
	assert.equal(
		classifyDetailOutcome(true, makeDetail()),
		"unaccounted",
		"policy-skip unaccounted even with detail",
	);
	assert.equal(classifyDetailOutcome(false, null), "gap", "null/failed is gap");
	assert.equal(
		classifyDetailOutcome(false, makeDetail()),
		"hydrated",
		"parsed detail hydrates",
	);
});

test("reasonForDetailFailure: maps precise Amazon detail failures to redacted retry reasons", () => {
	assert.equal(
		reasonForDetailFailure("navigation_retry_exhausted"),
		"retry_exhausted",
	);
	assert.equal(
		reasonForDetailFailure("redirected_non_detail"),
		"temporary_unavailable",
	);
	assert.equal(
		reasonForDetailFailure("parse_missing"),
		"temporary_unavailable",
	);
	assert.equal(reasonForDetailFailure("deferred_budget"), "retry_exhausted");
	assert.equal(
		reasonForDetailFailure("session_repair_required"),
		"temporary_unavailable",
	);
});

test("classifyAmazonDetailFailure: maps each failure kind to its connector-neutral recovery class", () => {
	// The planned per-run cap / retry budget is a resumable blast-radius stop,
	// not source pressure.
	assert.equal(
		classifyAmazonDetailFailure("deferred_budget"),
		"run_cap_deferred",
	);
	// A dead authenticated session is the owner's to fix; retrying is busywork.
	assert.equal(
		classifyAmazonDetailFailure("session_repair_required"),
		"owner_repair_required",
	);
	// Transient DOM/navigation misses made no progress this attempt but stay
	// retryable — the runtime, not the connector, decides when repeated
	// no-progress becomes a durable connector defect.
	const transient: Parameters<typeof classifyAmazonDetailFailure>[0][] = [
		"navigation_retry_exhausted",
		"parse_missing",
		"redirected_non_detail",
	];
	for (const kind of transient) {
		assert.equal(
			classifyAmazonDetailFailure(kind),
			"transient_no_progress",
			`${kind} is transient no-progress`,
		);
	}
});

test("classifyAmazonDetailFailure: planned cap and owner repair are never transient", () => {
	// Guards the design-D4 separation: a planned cap and an owner-repair signal
	// must not collapse into the transient bucket that the runtime keeps retrying.
	const planned: AmazonRecoveryClass =
		classifyAmazonDetailFailure("deferred_budget");
	const ownerRepair: AmazonRecoveryClass = classifyAmazonDetailFailure(
		"session_repair_required",
	);
	assert.notEqual(planned, "transient_no_progress");
	assert.notEqual(ownerRepair, "transient_no_progress");
	assert.notEqual(planned, ownerRepair);
});

test("readPageContentWithin fails bounded when the renderer stops answering", async () => {
	const page = {
		content: (): Promise<string> => new Promise(() => undefined),
	};

	await assert.rejects(
		() => readPageContentWithin(page, 5),
		/page_content_timeout after 5ms/,
	);
});

test("recordDetailOutcome: every recorded order joins required; outcome picks hydrated or gap", () => {
	const coverage = newOrderItemsCoverage();
	recordDetailOutcome(coverage, "ord-hydrated", "hydrated");
	recordDetailOutcome(coverage, "ord-gap", "gap");

	assert.deepEqual(
		coverage.required,
		["ord-hydrated", "ord-gap"],
		"required is the denominator",
	);
	assert.deepEqual(coverage.hydrated, ["ord-hydrated"]);
	assert.deepEqual(coverage.gap, ["ord-gap"]);
});

test("emitOrderItemsCoverage: a fully hydrated run emits required=hydrated, no gap_keys", async () => {
	const { deps, protocolMessages } = makeRecordingDeps();
	const coverage: OrderItemsCoverage = {
		required: ["a", "b"],
		hydrated: ["a", "b"],
		gap: [],
	};
	await emitOrderItemsCoverage(deps, coverage);

	const msg = findDetailCoverage(protocolMessages);
	assert.ok(msg, "expected a DETAIL_COVERAGE message");
	assert.equal(msg.type, "DETAIL_COVERAGE");
	assert.equal(msg.reference_only, true);
	assert.equal(
		msg.stream,
		"order_items",
		"coverage describes the detail-enriched stream",
	);
	assert.equal(
		msg.state_stream,
		"orders",
		"coverage is anchored by the list/parent stream cursor",
	);
	assert.deepEqual(msg.required_keys, ["a", "b"]);
	assert.deepEqual(msg.hydrated_keys, ["a", "b"]);
	assert.equal(msg.considered, 2, "the run considered both orders");
	assert.equal(msg.covered, 2, "hydrated orders are counted as covered");
	// Empty optional sets are omitted by the shared builder — a clean run carries
	// no gap/skip noise.
	assert.equal(msg.gap_keys, undefined);
	assert.equal(msg.optional_skip_keys, undefined);
});

test("emitOrderItemsCoverage: a partial run reports gap_keys distinct from hydrated", async () => {
	const { deps, protocolMessages } = makeRecordingDeps();
	const coverage: OrderItemsCoverage = {
		required: ["a", "b", "c"],
		hydrated: ["a"],
		gap: ["b", "c"],
	};
	await emitOrderItemsCoverage(deps, coverage);

	const msg = findDetailCoverage(protocolMessages);
	assert.ok(msg);
	assert.deepEqual(msg.required_keys, ["a", "b", "c"]);
	assert.deepEqual(msg.hydrated_keys, ["a"]);
	assert.deepEqual(
		msg.gap_keys,
		["b", "c"],
		"degraded detail fetches surface as a real gap",
	);
	assert.equal(msg.optional_skip_keys, undefined);
});

test("emitOrderItemsCoverage: a steady-state run with zero required orders still emits considered 0 / covered 0", async () => {
	const { deps, protocolMessages } = makeRecordingDeps();
	// The caller (`collect()`) only reaches emitOrderItemsCoverage after the
	// year sweep runs to completion without throwing, so an empty
	// OrderItemsCoverage here always means "the sweep completed and swept zero
	// orders across every in-scope year" — a real, measured zero denominator,
	// not "the sweep never ran." Suppressing this would leave the stream
	// permanently unmeasured on an account with no in-scope years.
	await emitOrderItemsCoverage(deps, newOrderItemsCoverage());

	const msg = findDetailCoverage(protocolMessages);
	assert.ok(msg, "a zero-required run still emits DETAIL_COVERAGE");
	assert.equal(msg.stream, "order_items");
	assert.equal(msg.state_stream, "orders");
	assert.deepEqual(msg.required_keys, []);
	assert.deepEqual(msg.hydrated_keys, []);
	assert.equal(msg.considered, 0);
	assert.equal(msg.covered, 0);
	assert.equal(msg.gap_keys, undefined);
	assert.equal(msg.optional_skip_keys, undefined);
});

// ─── orders list-stream coverage evidence ──────────────────────────────────
//
// The manifest declares `orders` coverage_strategy: checkpoint_window, but
// prior to this fix the connector never emitted DETAIL_COVERAGE for the
// `orders` stream itself — only for `order_items` (the detail child). A run
// scoped to `orders` only (wantsItems: false) left the orders list stream
// permanently unmeasured at the connector-level projection even though real
// orders were being collected. These tests pin the fix: emitOrderAndItems
// records `orders` considered/covered independent of whether order_items is
// in scope, and emitOrdersCoverage reports it via the same self-referential
// emitDetailCoverage shape USAA/GitHub use for bare list streams.

function findAllDetailCoverage(messages: EmittedMessage[]): DetailCoverage[] {
	return messages.filter(
		(m): m is DetailCoverage => m.type === "DETAIL_COVERAGE",
	);
}

test("emitOrdersCoverage: reports considered/covered self-referentially on the orders stream", async () => {
	const { deps, protocolMessages } = makeRecordingDeps();
	const coverage: OrdersCoverage = {
		considered: ["a", "b"],
		covered: ["a", "b"],
		dateDropped: [],
	};
	await emitOrdersCoverage(deps, coverage);

	const msg = findDetailCoverage(protocolMessages);
	assert.ok(msg, "expected a DETAIL_COVERAGE message");
	assert.equal(
		msg.stream,
		"orders",
		"orders reports on itself — no separate detail-hydration phase",
	);
	assert.equal(msg.state_stream, "orders");
	assert.deepEqual(msg.required_keys, []);
	assert.deepEqual(msg.hydrated_keys, []);
	assert.equal(msg.considered, 2);
	assert.equal(msg.covered, 2);
});

test("emitOrdersCoverage: a steady-state run with zero considered orders still emits considered 0 / covered 0", async () => {
	const { deps, protocolMessages } = makeRecordingDeps();
	await emitOrdersCoverage(deps, newOrdersCoverage());

	const msg = findDetailCoverage(protocolMessages);
	assert.ok(msg, "a zero-considered run still emits DETAIL_COVERAGE");
	assert.equal(msg.stream, "orders");
	assert.equal(msg.considered, 0);
	assert.equal(msg.covered, 0);
});

test("emitOrderAndItems: records an order as considered+covered in ordersCoverage on a normal emit", async () => {
	const coverage = newOrdersCoverage();
	const { deps } = makeRecordingDeps({ ordersCoverage: coverage });
	await emitOrderAndItems(
		deps,
		makeListOrder({ orderId: "ord-1" }),
		null,
		"2026-01-05",
	);

	assert.deepEqual(coverage.considered, ["ord-1"]);
	assert.deepEqual(coverage.covered, ["ord-1"]);
	assert.deepEqual(coverage.dateDropped, []);
});

test("emitOrderAndItems: records orders coverage even when order_items is out of scope (wantsItems: false)", async () => {
	const coverage = newOrdersCoverage();
	const { deps, emitted } = makeRecordingDeps({
		ordersCoverage: coverage,
		wantsItems: false,
		wantsOrders: true,
	});
	await emitOrderAndItems(
		deps,
		makeListOrder({ orderId: "ord-1" }),
		null,
		"2026-01-05",
	);

	assert.deepEqual(
		coverage.considered,
		["ord-1"],
		"orders coverage does not depend on order_items scope",
	);
	assert.deepEqual(coverage.covered, ["ord-1"]);
	assert.ok(
		emitted.some((r) => r.stream === "orders"),
		"the orders record itself still emits",
	);
	assert.ok(
		!emitted.some((r) => r.stream === "order_items"),
		"order_items stays out of scope",
	);
});

test("emitOrderAndItems: a fingerprint-suppressed re-scrape still counts as covered (a real accounting decision)", async () => {
	const coverage = newOrdersCoverage();
	const listOrder = makeListOrder({ orderId: "ord-1" });
	// Prime a real FingerprintCursor with the exact record emitOrderAndItems
	// will build next, so shouldEmit() honestly reports "unchanged" — not a
	// fake stub.
	const orderRecord = buildOrderRecord(
		listOrder,
		null,
		"2026-01-05",
		"2026-04-22T12:00:00.000Z",
	);
	const ordersFingerprintCursor = openFingerprintCursor(
		{
			fingerprints: { "ord-1": recordFingerprint(orderRecord, ["fetched_at"]) },
		},
		{ excludeFromFingerprint: ["fetched_at"] },
	);
	const { deps, emitted } = makeRecordingDeps({
		ordersCoverage: coverage,
		ordersFingerprintCursor,
	});
	await emitOrderAndItems(deps, listOrder, null, "2026-01-05");

	assert.deepEqual(coverage.considered, ["ord-1"]);
	assert.deepEqual(
		coverage.covered,
		["ord-1"],
		"a suppressed re-scrape is still a real accounting decision",
	);
	assert.ok(
		!emitted.some((r) => r.stream === "orders"),
		"the fingerprint suppressed the actual emit",
	);
});

test("emitOrderAndItems: nothing recorded in ordersCoverage when orders is out of scope (wantsOrders: false)", async () => {
	const coverage = newOrdersCoverage();
	const { deps } = makeRecordingDeps({
		ordersCoverage: coverage,
		wantsOrders: false,
		wantsItems: true,
	});
	await emitOrderAndItems(
		deps,
		makeListOrder({ orderId: "ord-1" }),
		null,
		"2026-01-05",
	);

	assert.deepEqual(
		coverage.considered,
		[],
		"orders out of scope means no orders-coverage accounting at all",
	);
	assert.deepEqual(coverage.covered, []);
});

test("processListOrder: an unparseable order date is considered but not covered in ordersCoverage", async () => {
	const ordersCoverage = newOrdersCoverage();
	const { deps } = makeRecordingDeps({ ordersCoverage });
	const listOrder = makeListOrder({
		orderId: "ord-bad-date",
		orderDateRaw: "not a real date",
	});

	await processListOrder(NEVER_CALLED_PAGE, deps, makeRunFlags(), listOrder);

	assert.deepEqual(
		ordersCoverage.considered,
		["ord-bad-date"],
		"the list scan still enumerated this order",
	);
	assert.deepEqual(
		ordersCoverage.covered,
		[],
		"no accounting decision was made for its orders record",
	);
	assert.deepEqual(ordersCoverage.dateDropped, ["ord-bad-date"]);
});

test("processListOrder: an already-hydrated-and-unchanged order still counts as considered+covered", async () => {
	const ordersCoverage = newOrdersCoverage();
	const listOrder = makeListOrder({ orderId: "ord-1" });
	const orderDate = parseOrderDate(listOrder.orderDateRaw) as string;
	const fingerprint = listSurfaceFingerprint(
		listOrder,
		orderDate,
		"2026-04-22T12:00:00.000Z",
	);
	const hydratedOrders = new Map([["ord-1", fingerprint]]);
	const { deps } = makeRecordingDeps({
		ordersCoverage,
		hydratedOrders,
		wantsItems: true,
	});

	const handled = await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		makeRunFlags(),
		listOrder,
	);

	assert.equal(handled, true);
	assert.deepEqual(ordersCoverage.considered, ["ord-1"]);
	assert.deepEqual(
		ordersCoverage.covered,
		["ord-1"],
		"an unchanged already-hydrated order is still covered",
	);
});

test("collect(): orders scoped alone (order_items out of scope) still emits an orders DETAIL_COVERAGE", async () => {
	// Regression guard for the real production gap: a run requesting only
	// `orders` (no order_items) must still measure and report orders coverage.
	// Exercises the exact emit sequence collect() drives: emitOrderAndItems
	// (which populates ordersCoverage) followed by emitOrdersCoverage.
	const ordersCoverage = newOrdersCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		ordersCoverage,
		wantsItems: false,
		wantsOrders: true,
	});

	await emitOrderAndItems(
		deps,
		makeListOrder({ orderId: "ord-1" }),
		null,
		"2026-01-05",
	);
	await emitOrderAndItems(
		deps,
		makeListOrder({ orderId: "ord-2" }),
		null,
		"2026-01-06",
	);
	await emitOrdersCoverage(deps, ordersCoverage);

	const coverageMessages = findAllDetailCoverage(protocolMessages);
	const ordersMsg = coverageMessages.find((m) => m.stream === "orders");
	assert.ok(
		ordersMsg,
		"orders-scoped-only run must still emit an orders DETAIL_COVERAGE",
	);
	assert.equal(ordersMsg?.considered, 2);
	assert.equal(ordersMsg?.covered, 2);
	assert.ok(
		!coverageMessages.some((m) => m.stream === "order_items"),
		"order_items coverage is out of scope and must not appear",
	);
});

test("processListOrder: a hydrated detail records the order id in required + hydrated", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	// A fake detail page so fetchOrderDetail-equivalent succeeds. We drive
	// processListOrder through a page stub that returns a parseable detail DOM.
	const page = makeDetailPageStub(makeDetailHtml());
	await processListOrder(
		page,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-1" }),
	);

	assert.deepEqual(coverage.required, ["ord-1"]);
	assert.deepEqual(
		coverage.hydrated,
		["ord-1"],
		"a parsed detail counts as hydrated",
	);
	assert.deepEqual(coverage.gap, []);
	// A hydration is not a gap — it must emit no DETAIL_GAP.
	assert.equal(
		findDetailGaps(protocolMessages).length,
		0,
		"a hydrated detail emits no DETAIL_GAP",
	);
});

// ─── Already-hydrated orders skip repeat detail fetches ─────────────────────
//
// The current year is never frozen (orders are ongoing), so
// processListOrder re-lists every order on every run. Without a durable
// known-hydrated proof it would re-attempt detail hydration for every
// listed order every run, including ones already covered, exhausting the
// per-run detail budget on repeat work before reaching genuinely new
// orders. `hydratedOrders` (persisted in the `orders` STATE cursor) maps
// each known-hydrated order id to the LIST-SURFACE fingerprint observed at
// hydration time (see `listSurfaceFingerprint`) — proof is "hydrated AND
// the list surface has not moved since", not permanent. A list-row change
// (delivery status, a return becoming visible) invalidates the entry and
// forces a full re-hydration.

function orderDateFor(listOrder: ListPageOrder): string {
	const orderDate = parseOrderDate(listOrder.orderDateRaw);
	if (!orderDate) {
		throw new Error("test fixture must have a parseable orderDateRaw");
	}
	return orderDate;
}

test("processListOrder: an already-hydrated, UNCHANGED order emits nothing on either stream and never touches the browser", async () => {
	const coverage = newOrderItemsCoverage();
	const listOrder = makeListOrder({ orderId: "ord-known" });
	const orderDate = orderDateFor(listOrder);
	const emittedAt = "2026-04-22T12:00:00.000Z";
	const priorFingerprint = listSurfaceFingerprint(
		listOrder,
		orderDate,
		emittedAt,
	);
	const hydratedOrders = new Map([["ord-known", priorFingerprint]]);
	const { deps, emitted, protocolMessages } = makeRecordingDeps({
		emittedAt,
		orderItemsCoverage: coverage,
		hydratedOrders,
	});

	// NEVER_CALLED_PAGE proves the detail fetch is genuinely skipped, not just
	// returning a null/degraded result.
	await processListOrder(NEVER_CALLED_PAGE, deps, makeRunFlags(), listOrder);

	assert.deepEqual(coverage.required, ["ord-known"]);
	assert.deepEqual(
		coverage.hydrated,
		["ord-known"],
		"an already-hydrated, unchanged order counts as hydrated, not a gap",
	);
	assert.deepEqual(coverage.gap, []);
	assert.equal(
		findDetailGaps(protocolMessages).length,
		0,
		"an already-hydrated order emits no DETAIL_GAP",
	);
	assert.deepEqual(
		emitted,
		[],
		"neither `orders` nor `order_items` is re-emitted for an already-hydrated, unchanged order — re-emitting `orders` " +
			"here with detail:null would silently downgrade the durable enriched record (recipient/payment/status_detail nulled)",
	);
	assert.deepEqual(
		[...hydratedOrders.entries()],
		[["ord-known", priorFingerprint]],
		"the known-hydrated map is unchanged, not double-added or invalidated",
	);
});

test("processListOrder: a CHANGED list row invalidates the known-hydrated entry and fully re-hydrates both streams", async () => {
	const coverage = newOrderItemsCoverage();
	const emittedAt = "2026-04-22T12:00:00.000Z";
	const priorListOrder = makeListOrder({
		orderId: "ord-changed",
		deliveryStatus: "Shipped",
	});
	const priorOrderDate = orderDateFor(priorListOrder);
	const staleFingerprint = listSurfaceFingerprint(
		priorListOrder,
		priorOrderDate,
		emittedAt,
	);
	const hydratedOrders = new Map([["ord-changed", staleFingerprint]]);
	const { deps, emitted } = makeRecordingDeps({
		emittedAt,
		orderItemsCoverage: coverage,
		hydratedOrders,
	});

	// The list row's delivery status moved since hydration — the list surface
	// fingerprint no longer matches the stored proof.
	const changedListOrder = makeListOrder({
		orderId: "ord-changed",
		deliveryStatus: "Delivered",
	});
	const page = makeDetailPageStub(makeDetailHtml());
	await processListOrder(page, deps, makeRunFlags(), changedListOrder);

	assert.deepEqual(
		coverage.hydrated,
		["ord-changed"],
		"a real re-hydration still counts as hydrated",
	);
	assert.deepEqual(coverage.gap, []);
	assert.ok(
		emitted.some((r) => r.stream === "orders" && r.data.id === "ord-changed"),
		"the enriched `orders` record is re-emitted on a list-surface change",
	);
	assert.ok(
		emitted.some((r) => r.stream === "order_items"),
		"order_items is re-emitted (refreshed) on a list-surface change",
	);
	const newFingerprint = hydratedOrders.get("ord-changed");
	assert.ok(newFingerprint, "the entry is re-established after re-hydration");
	assert.notEqual(
		newFingerprint,
		staleFingerprint,
		"the refreshed entry carries the NEW list-surface fingerprint, not the stale one",
	);
});

test("processListOrder: a genuinely new detail hydration adds the order id to hydratedOrders, keyed to the observed list fingerprint", async () => {
	const coverage = newOrderItemsCoverage();
	const hydratedOrders = new Map<string, string>();
	const emittedAt = "2026-04-22T12:00:00.000Z";
	const { deps } = makeRecordingDeps({
		emittedAt,
		orderItemsCoverage: coverage,
		hydratedOrders,
	});
	const page = makeDetailPageStub(makeDetailHtml());
	const listOrder = makeListOrder({ orderId: "ord-new" });

	await processListOrder(page, deps, makeRunFlags(), listOrder);

	assert.deepEqual(coverage.hydrated, ["ord-new"]);
	const expectedFingerprint = listSurfaceFingerprint(
		listOrder,
		orderDateFor(listOrder),
		emittedAt,
	);
	assert.equal(
		hydratedOrders.get("ord-new"),
		expectedFingerprint,
		"a real hydration this run joins the durable known-hydrated map, keyed to the list surface observed THIS run",
	);
});

test("processListOrder: a degraded (gap) detail attempt does NOT add the order id to hydratedOrders", async () => {
	const coverage = newOrderItemsCoverage();
	const hydratedOrders = new Map<string, string>();
	const { deps } = makeRecordingDeps({
		orderItemsCoverage: coverage,
		hydratedOrders,
	});
	const page = makeDetailPageStub(NO_DETAIL_HTML);

	await processListOrder(
		page,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-gap" }),
	);

	assert.deepEqual(coverage.gap, ["ord-gap"]);
	assert.ok(
		!hydratedOrders.has("ord-gap"),
		"a degraded detail attempt must not be marked known-hydrated — it must remain reachable for recovery/retry",
	);
});

test("processListOrder: wantsItems=false does not mark durable known-hydrated proof, even on a real hydration", async () => {
	// An orders-only scoped run may still legitimately fetch detail (to
	// enrich the `orders` record), but the known-hydrated map's honest
	// meaning is "order_items durably emitted" — marking it here would let a
	// LATER item-scoped run skip an order that never actually got its
	// order_items recorded (a false-green: coverage would read "hydrated"
	// with zero item records and no durable gap to recover from).
	const coverage = newOrderItemsCoverage();
	const hydratedOrders = new Map<string, string>();
	const { deps } = makeRecordingDeps({
		orderItemsCoverage: coverage,
		hydratedOrders,
		wantsItems: false,
		wantsOrders: true,
	});
	const page = makeDetailPageStub(makeDetailHtml());

	await processListOrder(
		page,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-orders-only" }),
	);

	assert.equal(
		hydratedOrders.size,
		0,
		"a wantsItems=false run must never mark an order known-hydrated, regardless of whether detail was fetched",
	);
});

test("processListOrder: the already-hydrated skip frees per-run detail budget for a genuinely new order (tail convergence)", async () => {
	// Reproduces the live shape at small scale: a per-run budget that would be
	// exhausted by re-fetching N already-hydrated, unchanged orders now
	// reaches a NEW order instead, because the unchanged ones are skipped
	// entirely.
	const coverage = newOrderItemsCoverage();
	const emittedAt = "2026-04-22T12:00:00.000Z";
	const oldOrder1 = makeListOrder({ orderId: "ord-old-1" });
	const oldOrder2 = makeListOrder({ orderId: "ord-old-2" });
	const hydratedOrders = new Map([
		[
			"ord-old-1",
			listSurfaceFingerprint(oldOrder1, orderDateFor(oldOrder1), emittedAt),
		],
		[
			"ord-old-2",
			listSurfaceFingerprint(oldOrder2, orderDateFor(oldOrder2), emittedAt),
		],
	]);
	const { deps } = makeRecordingDeps({
		emittedAt,
		orderItemsCoverage: coverage,
		hydratedOrders,
	});
	// A budget that would have been fully consumed by the two already-hydrated
	// orders alone under the pre-fix always-refetch behavior.
	const flags = { ...makeRunFlags(), detailAttempts: 0 };
	const budgetCeiling = 2;

	// ord-old-1 / ord-old-2 are already known-hydrated and unchanged:
	// NEVER_CALLED_PAGE proves neither touches the browser, so
	// `flags.detailAttempts` stays 0.
	await processListOrder(NEVER_CALLED_PAGE, deps, flags, oldOrder1);
	await processListOrder(NEVER_CALLED_PAGE, deps, flags, oldOrder2);
	assert.equal(
		flags.detailAttempts,
		0,
		"already-hydrated, unchanged orders consume zero detail-attempt budget",
	);
	assert.ok(
		flags.detailAttempts < budgetCeiling,
		"budget remains available for a genuinely new order",
	);

	// A genuinely new order now gets a real detail attempt using the budget
	// that would otherwise have been wasted re-fetching ord-old-1/ord-old-2.
	const page = makeDetailPageStub(makeDetailHtml());
	await processListOrder(
		page,
		deps,
		flags,
		makeListOrder({ orderId: "ord-new-reaches-budget" }),
	);

	assert.deepEqual(
		coverage.hydrated.sort((a, b) => a.localeCompare(b)),
		["ord-new-reaches-budget", "ord-old-1", "ord-old-2"].sort((a, b) =>
			a.localeCompare(b),
		),
	);
	assert.deepEqual(
		coverage.gap,
		[],
		"no order in this run is left as a gap — budget was not wasted on repeat work",
	);
});

test("processListOrder: fopo Whole Foods detail URL hydrates instead of becoming a gap", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, emitted, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const html = readFileSync(AMAZON_FOPO_DETAIL_FIXTURE, "utf8");
	const page = makeDetailPageStub(
		html,
		"https://www.amazon.com/fopo/order-details/ref=ppx_hzod_rd_dt_b_fresh_fopo_rd?_encoding=UTF8&orderID=fixture",
	);

	await processListOrder(
		page,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-fopo-1" }),
	);

	assert.deepEqual(coverage.required, ["ord-fopo-1"]);
	assert.deepEqual(coverage.hydrated, ["ord-fopo-1"]);
	assert.deepEqual(coverage.gap, []);
	assert.equal(
		findDetailGaps(protocolMessages).length,
		0,
		"fopo detail pages must not emit degraded detail gaps",
	);
	assert.ok(
		emitted.some(
			(r) => r.stream === "order_items" && r.data.asin === "B01FOPO001",
		),
		"fopo detail items enrich emitted order_items",
	);
});

test("processListOrder: ufpo grocery detail URL hydrates instead of becoming a gap", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, emitted, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const html = readFileSync(AMAZON_UFPO_DETAIL_FIXTURE, "utf8");
	const page = makeDetailPageStub(
		html,
		"https://www.amazon.com/uff/your-account/order-details/ref=ppx_hzod_rd_dt_b_fresh_uff_rd?orderID=fixture",
	);

	await processListOrder(
		page,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-ufpo-1" }),
	);

	assert.deepEqual(coverage.required, ["ord-ufpo-1"]);
	assert.deepEqual(coverage.hydrated, ["ord-ufpo-1"]);
	assert.deepEqual(coverage.gap, []);
	assert.equal(
		findDetailGaps(protocolMessages).length,
		0,
		"ufpo detail pages must not emit degraded detail gaps",
	);
	assert.ok(
		emitted.some(
			(r) => r.stream === "order_items" && r.data.asin === "B02UFPO002",
		),
		"ufpo grocery detail items enrich emitted order_items",
	);
});

test("processListOrder: uff order-card detail URL hydrates instead of becoming a gap", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, emitted, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const html = readFileSync(AMAZON_UFF_DETAIL_FIXTURE, "utf8");
	const page = makeDetailPageStub(
		html,
		"https://www.amazon.com/uff/your-account/order-details/ref=ppx_hzod_rd_dt_b_fresh_uff_rd?orderID=fixture",
	);

	await processListOrder(
		page,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-uff-1" }),
	);

	assert.deepEqual(coverage.required, ["ord-uff-1"]);
	assert.deepEqual(coverage.hydrated, ["ord-uff-1"]);
	assert.deepEqual(coverage.gap, []);
	assert.equal(
		findDetailGaps(protocolMessages).length,
		0,
		"uff detail pages must not emit degraded detail gaps",
	);
	assert.ok(
		emitted.some(
			(r) => r.stream === "order_items" && r.data.asin === "B02HIJKLMN",
		),
		"uff order-card detail items enrich emitted order_items",
	);
});

test("processListOrder: a null detail (attempted, degraded) records a gap, not a hydration", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, emitted, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	// The detail page renders without an #orderDetails container, so
	// parseOrderDetailDom returns null — the same degraded outcome a layout
	// drift or non-detail redirect produces. The list-page items still emit.
	const page = makeDetailPageStub(NO_DETAIL_HTML);
	await processListOrder(
		page,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-2" }),
	);

	assert.deepEqual(coverage.required, ["ord-2"]);
	assert.deepEqual(
		coverage.gap,
		["ord-2"],
		"an attempted-but-failed detail is a degraded gap",
	);
	assert.deepEqual(coverage.hydrated, []);
	// A gap does not suppress collection: list-page items still flow.
	assert.ok(
		emitted.some((r) => r.stream === "order_items"),
		"list-page items emit even when detail enrichment degrades",
	);
	// The degraded gap MUST be backed by a durable pending DETAIL_GAP, or the
	// run's DETAIL_COVERAGE.gap_key has no durable gap and the run fails at
	// state-commit.
	const gaps = findDetailGaps(protocolMessages);
	assert.equal(
		gaps.length,
		1,
		"exactly one pending DETAIL_GAP per degraded order",
	);
	assert.equal(
		gaps[0]?.record_key,
		"ord-2",
		"the DETAIL_GAP record_key is the gap order id",
	);
	assert.equal(
		gaps[0]?.stream,
		"order_items",
		"the DETAIL_GAP is on the coverage stream",
	);
	assert.equal(
		gaps[0]?.reason,
		"temporary_unavailable",
		"parse-missing detail stays retryable but precise",
	);
	assert.equal(
		gaps[0]?.detail_locator.order_date,
		"2026-01-05",
		"future recovery needs the parsed order date",
	);
});

test("processListOrder: first failed detail captures one failed-detail checkpoint when capture is enabled", async () => {
	const coverage = newOrderItemsCoverage();
	const labels: string[] = [];
	const { deps, protocolMessages } = makeRecordingDeps({
		capture: {
			baseDir: "/tmp/pdpp-test-capture",
			captureDom: (_page, label): Promise<void> => {
				labels.push(label);
				return Promise.resolve();
			},
			captureHttp: (): void => undefined,
			finalize: (): void => undefined,
			keepOnSuccess: true,
			markSucceeded: (): void => undefined,
			recordRecord: (): void => undefined,
			hasRegisteredSecrets: (): boolean => false,
			registerSecrets: (): void => undefined,
			runId: "test-run",
		},
		orderItemsCoverage: coverage,
	});
	const flags = makeRunFlags();
	const page = makeDetailPageStub(NO_DETAIL_HTML);

	await processListOrder(
		page,
		deps,
		flags,
		makeListOrder({ orderId: "ord-fail-capture-1" }),
	);
	await processListOrder(
		page,
		deps,
		flags,
		makeListOrder({ orderId: "ord-fail-capture-2" }),
	);

	assert.deepEqual(
		labels,
		["order-detail-failed-parse_missing"],
		"failed-detail fixture capture is bounded once",
	);
	assert.equal(flags.failedDetailCaptured, true);
	assert.equal(
		findDetailGaps(protocolMessages).length,
		2,
		"capture does not suppress durable gap reporting",
	);
});

test("processListOrder: parse-missing detail failures do not trip source-pressure deferral", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const flags = makeRunFlags();
	const page = makeDetailPageStub(NO_DETAIL_HTML);

	await processListOrder(
		page,
		deps,
		flags,
		makeListOrder({ orderId: "ord-parse-1" }),
	);
	await processListOrder(
		page,
		deps,
		flags,
		makeListOrder({ orderId: "ord-parse-2" }),
	);
	await processListOrder(
		page,
		deps,
		flags,
		makeListOrder({ orderId: "ord-parse-3" }),
	);
	await processListOrder(
		page,
		deps,
		flags,
		makeListOrder({ orderId: "ord-parse-4" }),
	);

	const gaps = findDetailGaps(protocolMessages);
	assert.deepEqual(coverage.gap, [
		"ord-parse-1",
		"ord-parse-2",
		"ord-parse-3",
		"ord-parse-4",
	]);
	assert.deepEqual(
		gaps.map((gap) => [gap.record_key, gap.reason]),
		[
			["ord-parse-1", "temporary_unavailable"],
			["ord-parse-2", "temporary_unavailable"],
			["ord-parse-3", "temporary_unavailable"],
			["ord-parse-4", "temporary_unavailable"],
		],
		"layout/parser drift stays retryable but does not become source pressure",
	);
	assert.equal(
		flags.temporaryDetailFailures,
		0,
		"parse-missing details do not count as source-pressure failures",
	);
});

test("processListOrder: repeated retry-exhausted detail failures defer later details as non-pressure gaps", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const flags = { ...makeRunFlags(), temporaryDetailFailures: 3 };

	await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		flags,
		makeListOrder({ orderId: "ord-deferred-4" }),
	);

	assert.deepEqual(coverage.gap, ["ord-deferred-4"]);
	const gaps = findDetailGaps(protocolMessages);
	assert.deepEqual(
		gaps.map((gap) => [gap.record_key, gap.reason]),
		[["ord-deferred-4", "retry_exhausted"]],
		"connector-local detail budget defers the next detail without arming source-pressure cooldown",
	);
	assert.equal(gaps[0]?.last_error?.class, "run_cap_deferred");
	assert.equal(
		flags.temporaryDetailFailures,
		3,
		"deferred gaps do not keep ratcheting the temporary failure count",
	);
});

test("processListOrder: total detail-attempt budget defers later details without touching the page", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const flags = { ...makeRunFlags(), detailAttempts: 999 };

	await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		flags,
		makeListOrder({ orderId: "ord-attempt-budget" }),
	);

	assert.deepEqual(coverage.gap, ["ord-attempt-budget"]);
	const gaps = findDetailGaps(protocolMessages);
	assert.deepEqual(
		gaps.map((gap) => [gap.record_key, gap.reason, gap.last_error?.class]),
		[["ord-attempt-budget", "retry_exhausted", "run_cap_deferred"]],
		"total detail budget uses a non-source-pressure retryable gap",
	);
	assert.equal(
		flags.detailAttempts,
		999,
		"budget-deferred gaps do not touch the browser or increment attempts",
	);
});

// ─── Owner-repair: detail redirect to sign-in ────────────────────────────────

// A detail request that Amazon bounces to /ap/signin means the authenticated
// session is dead. `SIGNIN_URL` matches SIGNIN_URL_RE and not DETAIL_URL_RE.
const SIGNIN_REDIRECT_URL =
	"https://www.amazon.com/ap/signin?openid.return_to=order-details";

test("processListOrder: a detail redirect to sign-in latches owner-repair and gaps stay owner-repair, not transient", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const flags = makeRunFlags();
	const page = makeDetailPageStub(NO_DETAIL_HTML, SIGNIN_REDIRECT_URL);

	await processListOrder(
		page,
		deps,
		flags,
		makeListOrder({ orderId: "ord-signin-1" }),
	);

	assert.equal(
		flags.sessionRepairRequired,
		true,
		"a sign-in redirect latches the run into owner-repair",
	);
	assert.equal(
		flags.temporaryDetailFailures,
		0,
		"a dead session is not a transient no-progress failure and must not ratchet that budget",
	);
	const gaps = findDetailGaps(protocolMessages);
	assert.equal(
		gaps.length,
		1,
		"the degraded order still carries a durable pending gap",
	);
	assert.equal(gaps[0]?.record_key, "ord-signin-1");
	assert.equal(
		gaps[0]?.last_error?.class,
		"owner_repair_required",
		"the gap carries the owner-repair class so the runtime/UI route it to reconnect, not endless retry",
	);
});

test("processListOrder: once the session is dead, later orders defer without touching the browser (no retry busywork)", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	// Session already latched dead: the next detail attempt must not touch the
	// page at all (NEVER_CALLED_PAGE throws on any access).
	const flags = { ...makeRunFlags(), sessionRepairRequired: true };

	await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		flags,
		makeListOrder({ orderId: "ord-after-signin" }),
	);

	assert.deepEqual(
		coverage.gap,
		["ord-after-signin"],
		"the order is still recorded as a degraded gap",
	);
	const gaps = findDetailGaps(protocolMessages);
	assert.deepEqual(
		gaps.map((gap) => [gap.record_key, gap.reason, gap.last_error?.class]),
		[["ord-after-signin", "temporary_unavailable", "owner_repair_required"]],
		"post-session-death orders defer as owner-repair instead of hammering sign-in once per order",
	);
	assert.equal(
		flags.detailAttempts,
		0,
		"an owner-repair deferral never touches the browser or spends the budget",
	);
});

test("recoverPendingOrderItemDetailGaps: a sign-in redirect during recovery stops draining and re-defers as owner-repair", async () => {
	const { deps, emitted, protocolMessages } = makeRecordingDeps();
	const flags = makeRunFlags();
	const firstId = "111-1234567-8901234";
	const secondId = "111-1234567-8901235";
	// The recovery page stub always redirects to sign-in, so the FIRST gap trips
	// owner-repair; the SECOND gap in the same page must then defer without a
	// second browser touch.
	const result = await recoverPendingOrderItemDetailGaps(
		makeDetailPageStub(NO_DETAIL_HTML, SIGNIN_REDIRECT_URL),
		{
			capture: null,
			detailGaps: [firstId, secondId].map((orderId, i) => ({
				detail_locator: {
					kind: "amazon.order_detail",
					order_date: "2026-01-05",
					order_id: orderId,
				},
				gap_id: `gap_signin_${i}`,
				record_key: orderId,
				reference_only: true,
				status: "pending",
				stream: "order_items",
			})),
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		flags,
	);

	assert.equal(result.recovered, 0, "a dead session recovers nothing");
	assert.equal(
		result.stoppedWithPending,
		true,
		"recovery stops with the gaps still queued for the owner to unblock",
	);
	assert.equal(flags.sessionRepairRequired, true);
	assert.equal(
		emitted.length,
		0,
		"no order_items are emitted from a dead session",
	);
	const gaps = findDetailGaps(protocolMessages);
	assert.deepEqual(
		gaps.map((gap) => [gap.record_key, gap.last_error?.class]),
		[
			[firstId, "owner_repair_required"],
			[secondId, "owner_repair_required"],
		],
		"both gaps re-defer as owner-repair; the second never touched the browser",
	);
});

test("recoverPendingOrderItemDetailGaps: parse-missing recovery re-defers as transient no-progress", async () => {
	const { deps, emitted, protocolMessages } = makeRecordingDeps();
	const flags = makeRunFlags();
	const orderId = "111-1234567-8901299";
	const result = await recoverPendingOrderItemDetailGaps(
		makeDetailPageStub(NO_DETAIL_HTML),
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_date: "2026-01-05",
						order_id: orderId,
					},
					gap_id: "gap_parse_missing_1",
					record_key: orderId,
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		flags,
	);

	assert.deepEqual(result, { recovered: 0, stoppedWithPending: true });
	assert.equal(
		emitted.length,
		0,
		"no order_items are emitted from a failed detail fixture",
	);
	const gaps = findDetailGaps(protocolMessages);
	assert.deepEqual(
		gaps.map((gap) => [gap.record_key, gap.reason, gap.last_error?.class]),
		[[orderId, "temporary_unavailable", "transient_no_progress"]],
		"Amazon fixture no-progress stays connector-neutral so the runtime can escalate repeated failure",
	);
});

test("recoverPendingOrderItemDetailGaps: hydrates future Amazon order-item gaps and marks recovered", async () => {
	const { deps, emitted, protocolMessages } = makeRecordingDeps();
	const flags = makeRunFlags();
	const orderId = "111-1234567-8901234";
	const result = await recoverPendingOrderItemDetailGaps(
		makeDetailPageStub(makeDetailHtml()),
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_date: "2026-01-05",
						order_id: orderId,
					},
					gap_id: "gap_recover_1",
					record_key: orderId,
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		flags,
	);

	assert.deepEqual(result, { recovered: 1, stoppedWithPending: false });
	assert.ok(
		emitted.some(
			(record) =>
				record.stream === "order_items" && record.data.order_id === orderId,
		),
		"recovered detail emits order_items records",
	);
	assert.deepEqual(
		protocolMessages.find((message) => message.type === "DETAIL_GAP_RECOVERED"),
		{
			type: "DETAIL_GAP_RECOVERED",
			reference_only: true,
			gap_id: "gap_recover_1",
			stream: "order_items",
			record_key: orderId,
		},
	);
});

test("recoverPendingOrderItemDetailGaps: a recovered gap does NOT mark durable known-hydrated proof (no list-surface data available)", async () => {
	// The recovery path only has the gap locator's order id/date, not the
	// full list-page row (delivery status, list total, list item count) that
	// `listSurfaceFingerprint` needs. Marking known-hydrated here without a
	// real fingerprint would either always mismatch on the next forward walk
	// (useless) or fabricate a proof the connector cannot actually stand
	// behind. The next forward walk that lists this order establishes the
	// proof normally, with a real fingerprint — recovered orders are a
	// bounded, already-gapped set, so this costs at most one ordinary
	// re-fetch, not the unbounded repeat-work the fingerprint fix targets.
	const { deps } = makeRecordingDeps();
	const flags = makeRunFlags();
	const orderId = "111-1234567-8901234";

	const result = await recoverPendingOrderItemDetailGaps(
		makeDetailPageStub(makeDetailHtml()),
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_date: "2026-01-05",
						order_id: orderId,
					},
					gap_id: "gap_recover_hyd",
					record_key: orderId,
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		flags,
	);

	assert.equal(result.recovered, 1);
	assert.equal(
		(deps as { hydratedOrders?: Map<string, string> }).hydratedOrders,
		undefined,
		"AmazonDetailRecoveryDeps carries no hydratedOrders field — the recovery path cannot mark durable proof",
	);
});

test("recoverPendingOrderItemDetailGaps: keeps paging recovered gaps until pending work is empty", async () => {
	const { deps, protocolMessages } = makeRecordingDeps();
	const pageRequests: number[] = [];
	const secondOrderId = "111-1234567-8901235";
	const pages: BrowserCollectContext["detailGaps"][] = [
		[
			{
				detail_locator: {
					kind: "amazon.order_detail",
					order_date: "2026-01-06",
					order_id: secondOrderId,
				},
				gap_id: "gap_recover_2",
				record_key: secondOrderId,
				reference_only: true,
				status: "pending",
				stream: "order_items",
			},
		],
		[],
	];

	const result = await recoverPendingOrderItemDetailGaps(
		makeDetailPageStub(makeDetailHtml()),
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_date: "2026-01-05",
						order_id: "111-1234567-8901234",
					},
					gap_id: "gap_recover_1",
					record_key: "111-1234567-8901234",
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
			requestDetailGapPage: () => {
				pageRequests.push(pageRequests.length + 1);
				return Promise.resolve(pages.shift() ?? []);
			},
		},
		makeRunFlags(),
	);

	assert.deepEqual(result, { recovered: 2, stoppedWithPending: false });
	assert.deepEqual(
		pageRequests,
		[1, 2],
		"recovery keeps requesting pages until pending work is empty",
	);
	assert.deepEqual(
		protocolMessages
			.filter((message) => message.type === "DETAIL_GAP_RECOVERED")
			.map((message) => message.record_key),
		["111-1234567-8901234", secondOrderId],
	);
});

test("recoverPendingOrderItemDetailGaps: under-specified legacy gaps are left pending, not corrupted", async () => {
	const { deps, emitted, protocolMessages } = makeRecordingDeps();
	const result = await recoverPendingOrderItemDetailGaps(
		NEVER_CALLED_PAGE,
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_id: "legacy-gap-no-date",
					},
					gap_id: "gap_legacy",
					record_key: "legacy-gap-no-date",
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		makeRunFlags(),
	);

	assert.deepEqual(result, { recovered: 0, stoppedWithPending: true });
	assert.equal(
		emitted.length,
		0,
		"missing order_date cannot emit valid order_items",
	);
	assert.equal(
		protocolMessages.length,
		0,
		"legacy gap remains durable instead of being falsely recovered",
	);
});

test("recoverPendingOrderItemDetailGapsBeforeForwardRun: no order_items scope skips recovery and permits forward walk", async () => {
	const { deps } = makeRecordingDeps();
	const result = await recoverPendingOrderItemDetailGapsBeforeForwardRun(
		NEVER_CALLED_PAGE,
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_date: "2026-01-05",
						order_id: "111-1234567-8901234",
					},
					gap_id: "gap_recover_1",
					record_key: "111-1234567-8901234",
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		makeRunFlags(),
		{ wantsItems: false },
	);

	assert.deepEqual(result, {
		recovered: 0,
		stoppedWithPending: false,
		suppressForward: false,
	});
});

test("recoverPendingOrderItemDetailGapsBeforeForwardRun: zero-budget legacy stop still permits forward walk", async () => {
	const { deps } = makeRecordingDeps();
	const result = await recoverPendingOrderItemDetailGapsBeforeForwardRun(
		NEVER_CALLED_PAGE,
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_id: "legacy-gap-no-date",
					},
					gap_id: "gap_legacy",
					record_key: "legacy-gap-no-date",
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		makeRunFlags(),
		{ wantsItems: true },
	);

	assert.deepEqual(result, {
		recovered: 0,
		stoppedWithPending: true,
		suppressForward: false,
	});
});

test("recoverPendingOrderItemDetailGapsBeforeForwardRun: detail-budget exhaustion suppresses forward walk", async () => {
	const { deps } = makeRecordingDeps();
	const orderId = "111-1234567-8901234";
	const result = await recoverPendingOrderItemDetailGapsBeforeForwardRun(
		NEVER_CALLED_PAGE,
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_date: "2026-01-05",
						order_id: orderId,
					},
					gap_id: "gap_deferred",
					record_key: orderId,
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		{ ...makeRunFlags(), detailAttempts: 200 },
		{ wantsItems: true },
	);

	assert.deepEqual(result, {
		recovered: 0,
		stoppedWithPending: true,
		suppressForward: true,
	});
});

test("recoverPendingOrderItemDetailGapsBeforeForwardRun: recovery-only suppresses forward walk after clean drain", async () => {
	const { deps, emitted, protocolMessages } = makeRecordingDeps();
	const orderId = "111-1234567-8901234";
	const result = await recoverPendingOrderItemDetailGapsBeforeForwardRun(
		makeDetailPageStub(makeDetailHtml()),
		{
			capture: null,
			detailGaps: [
				{
					detail_locator: {
						kind: "amazon.order_detail",
						order_date: "2026-01-05",
						order_id: orderId,
					},
					gap_id: "gap_recover_1",
					record_key: orderId,
					reference_only: true,
					status: "pending",
					stream: "order_items",
				},
			],
			emit: deps.emit,
			emitRecord: deps.emitRecord,
		},
		makeRunFlags(),
		{ recoveryOnly: true, wantsItems: true },
	);

	assert.deepEqual(result, {
		recovered: 1,
		stoppedWithPending: false,
		suppressForward: true,
	});
	assert.ok(
		emitted.some(
			(record) =>
				record.stream === "order_items" && record.data.order_id === orderId,
		),
	);
	assert.ok(
		protocolMessages.some((message) => message.type === "DETAIL_GAP_RECOVERED"),
	);
});

test("processListOrder: skipDetail records as unaccounted (required but no outcome), never touches page", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps } = makeRecordingDeps({
		orderItemsCoverage: coverage,
		skipDetail: true,
	});
	await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-3" }),
	);

	// Unaccounted: required but absent from hydrated and gap (per spec: required key w/o outcome defers checkpoint)
	assert.deepEqual(
		coverage.required,
		["ord-3"],
		"PDPP_AMAZON_SKIP_DETAIL: required",
	);
	assert.deepEqual(coverage.gap, [], "no gap (no retry evidence)");
	assert.deepEqual(coverage.hydrated, [], "not hydrated");
});

test("processListOrder: an unparseable order date is never counted toward order-item coverage", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps } = makeRecordingDeps({
		orderItemsCoverage: coverage,
		skipDetail: true,
	});
	const processed = await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-bad", orderDateRaw: "not a real date" }),
	);
	assert.equal(
		processed,
		false,
		"an unparseable row is dropped before the detail lane",
	);
	assert.deepEqual(
		coverage.required,
		[],
		"a dropped row never enters the denominator",
	);
});

test("DETAIL_COVERAGE for order_items carries only opaque order ids, never recipient/address PII", async () => {
	// The coverage key sets are order ids; recipient/address/payment fields must
	// never appear in the emitted projection. Drive a hydrated order through and
	// assert the serialized message contains the order id and none of the PII the
	// detail page also exposes.
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const page = makeDetailPageStub(makeDetailHtml());
	await processListOrder(
		page,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "111-SECRET-0001" }),
	);
	await emitOrderItemsCoverage(deps, coverage);

	const msg = findDetailCoverage(protocolMessages);
	assert.ok(msg);
	assert.ok(
		msg.required_keys.includes("111-SECRET-0001"),
		"the opaque order id is the only key",
	);
	const serialized = JSON.stringify(msg);
	assert.doesNotMatch(
		serialized,
		/Fake Name|123 Fake St|Visa ending/,
		"no recipient/address/payment in coverage",
	);
});

// ─── pending DETAIL_GAP backing for coverage gap_keys ─────────────────────
//
// The runtime treats DETAIL_COVERAGE.gap_keys as a projection only: a
// `required` key is satisfied at state-commit by a hydration, an optional skip,
// or a *durable pending DETAIL_GAP* with a matching record_key
// (assertDetailCoverageSatisfiedBeforeCommit). So an otherwise-successful run
// that degraded any order detail fails at commit unless every gap_key is backed
// by a pending DETAIL_GAP. These tests pin that backing, its emission order
// (gaps before the run-level coverage), the reference-only redacted shape, and
// that policy skips / hydrations emit no gap. The polyfill-runtime spec
// ("partially hydrated run carries gap_keys matching emitted DETAIL_GAPs")
// makes this a contract, not just an implementation detail.

test("buildOrderDetailGap: redacted reference-only pending gap on order_items, keyed by the opaque order id", () => {
	const gap = buildOrderDetailGap("111-7654321-0000001");
	assert.equal(gap.type, "DETAIL_GAP");
	assert.equal(
		gap.stream,
		"order_items",
		"the gap is on the same stream the coverage describes",
	);
	assert.equal(gap.parent_stream, "orders", "the list/parent stream is orders");
	assert.equal(
		gap.record_key,
		"111-7654321-0000001",
		"record_key is the opaque order id",
	);
	assert.equal(gap.status, "pending", "a fresh gap is pending recovery");
	assert.equal(
		gap.retryable,
		true,
		"a degraded detail fetch is retryable next run",
	);
	assert.equal(
		gap.reference_only,
		true,
		"DETAIL_GAP is a reference-only projection",
	);
	assert.equal(
		gap.reason,
		"temporary_unavailable",
		"null-detail paths are mixed → temporary, not retry_exhausted",
	);
	assert.equal(
		gap.detail_locator.kind,
		"amazon.order_detail",
		"stable redacted locator kind",
	);
	assert.equal(
		gap.detail_locator.order_id,
		"111-7654321-0000001",
		"locator carries only the opaque order id",
	);
});

test("buildOrderDetailGap: serialized gap carries only the opaque order id, no recipient/address/payment/item text", () => {
	const gap = buildOrderDetailGap("111-SECRET-0002");
	const serialized = JSON.stringify(gap);
	assert.match(serialized, /111-SECRET-0002/, "the opaque order id is present");
	// None of the PII the order-detail page exposes may ride along on the gap.
	assert.doesNotMatch(
		serialized,
		/Fake Name|123 Fake St|Visa ending|Widget|Detail-Only Item/,
		"no recipient/address/payment/item title or text in the DETAIL_GAP",
	);
});

test("every coverage gap_key is backed by exactly one pending DETAIL_GAP with the same record_key", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	// Two degraded orders (null detail) and one hydrated order in the same run.
	const gapPage = makeDetailPageStub(NO_DETAIL_HTML);
	const hydratedPage = makeDetailPageStub(makeDetailHtml());
	await processListOrder(
		gapPage,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-gap-1" }),
	);
	await processListOrder(
		hydratedPage,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-ok-1" }),
	);
	await processListOrder(
		gapPage,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-gap-2" }),
	);
	await emitOrderItemsCoverage(deps, coverage);

	const cov = findDetailCoverage(protocolMessages);
	assert.ok(cov, "expected a run-level DETAIL_COVERAGE");
	assert.deepEqual(
		cov.gap_keys,
		["ord-gap-1", "ord-gap-2"],
		"coverage reports both degraded orders as gaps",
	);
	assert.deepEqual(
		cov.hydrated_keys,
		["ord-ok-1"],
		"the hydrated order is not a gap",
	);
	assert.equal(cov.considered, 3, "all three orders were considered");
	assert.equal(cov.covered, 1, "only the hydrated order counted as covered");

	const gaps = findDetailGaps(protocolMessages);
	const gapKeys = gaps.map((g) => g.record_key);
	// The runtime's assertDetailCoverageSatisfiedBeforeCommit matches gap.stream
	// === coverage.stream and gap.record_key against required_keys: every gap_key
	// must have a same-stream pending DETAIL_GAP carrying that record_key.
	const coverageStream = cov.stream;
	for (const key of cov.gap_keys ?? []) {
		const backing: DetailGap[] = gaps.filter(
			(g) =>
				g.record_key === key &&
				g.stream === coverageStream &&
				g.status === "pending",
		);
		assert.equal(
			backing.length,
			1,
			`gap_key ${key} must be backed by exactly one pending DETAIL_GAP on ${coverageStream}`,
		);
	}
	assert.deepEqual(
		gapKeys,
		["ord-gap-1", "ord-gap-2"],
		"no DETAIL_GAP for the hydrated order; one per degraded order",
	);
});

test("DETAIL_GAP messages emit before the run-level DETAIL_COVERAGE (commit-gate ordering)", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const gapPage = makeDetailPageStub(NO_DETAIL_HTML);
	await processListOrder(
		gapPage,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-gap-early" }),
	);
	await emitOrderItemsCoverage(deps, coverage);

	const gapIdx = protocolMessages.findIndex((m) => m.type === "DETAIL_GAP");
	const covIdx = protocolMessages.findIndex(
		(m) => m.type === "DETAIL_COVERAGE",
	);
	assert.notEqual(gapIdx, -1, "expected a DETAIL_GAP");
	assert.notEqual(covIdx, -1, "expected a DETAIL_COVERAGE");
	assert.ok(
		gapIdx < covIdx,
		"the pending DETAIL_GAP must precede the run-level DETAIL_COVERAGE",
	);
});

test("a fully hydrated run emits zero DETAIL_GAP messages", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	const hydratedPage = makeDetailPageStub(makeDetailHtml());
	await processListOrder(
		hydratedPage,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-ok-a" }),
	);
	await processListOrder(
		hydratedPage,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-ok-b" }),
	);
	await emitOrderItemsCoverage(deps, coverage);

	assert.equal(
		findDetailGaps(protocolMessages).length,
		0,
		"no degraded detail → no DETAIL_GAP",
	);
	const cov = findDetailCoverage(protocolMessages);
	assert.ok(cov);
	assert.equal(
		cov.gap_keys,
		undefined,
		"a clean run carries no gap_keys either",
	);
});

test("discriminator: policy-deferred (unaccounted) vs attempted-failed (gap) differ in outcome set", async () => {
	// Policy-deferred: required but not in gap (unaccounted: checkpoint withheld)
	const deferred = newOrderItemsCoverage();
	const { deps: deferredDeps } = makeRecordingDeps({
		orderItemsCoverage: deferred,
		skipDetail: true,
	});
	await processListOrder(
		NEVER_CALLED_PAGE,
		deferredDeps,
		makeRunFlags(),
		makeListOrder({ orderId: "deferred-1" }),
	);
	assert.deepEqual(
		deferred.required,
		["deferred-1"],
		"policy-deferred: required",
	);
	assert.deepEqual(deferred.gap, [], "policy-deferred: not in gap");

	// Attempted-but-failed: required + gap, backed by DETAIL_GAP for recovery
	const failed = newOrderItemsCoverage();
	const { deps: failedDeps, protocolMessages: failedMsgs } = makeRecordingDeps({
		orderItemsCoverage: failed,
	});
	const failedPage = makeDetailPageStub(NO_DETAIL_HTML); // detail page will fail
	await processListOrder(
		failedPage,
		failedDeps,
		makeRunFlags(),
		makeListOrder({ orderId: "failed-1" }),
	);
	assert.deepEqual(failed.required, ["failed-1"], "attempted: required");
	assert.deepEqual(failed.gap, ["failed-1"], "attempted-failed: in gap");
	assert.ok(
		findDetailGaps(failedMsgs).some((g) => g.record_key === "failed-1"),
		"gap backed by DETAIL_GAP",
	);
});

test("policy-skipped run (PDPP_AMAZON_SKIP_DETAIL): unaccounted required defers checkpoint", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
		skipDetail: true,
	});
	await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-skip-a" }),
	);
	await processListOrder(
		NEVER_CALLED_PAGE,
		deps,
		makeRunFlags(),
		makeListOrder({ orderId: "ord-skip-b" }),
	);
	await emitOrderItemsCoverage(deps, coverage);

	assert.equal(
		findDetailGaps(protocolMessages).length,
		0,
		"unaccounted emit no DETAIL_GAP",
	);
	const cov = findDetailCoverage(protocolMessages);
	assert.ok(cov);
	// Per spec: unaccounted required keys (in required but absent from hydrated/gap/optional) defer the checkpoint
	assert.deepEqual(
		cov.required_keys,
		["ord-skip-a", "ord-skip-b"],
		"policy-deferred: required",
	);
	assert.equal(
		cov.gap_keys,
		undefined,
		"no gap_keys (unaccounted, not attempted)",
	);
	assert.equal(cov.optional_skip_keys, undefined);
	assert.equal(cov.considered, 2, "both orders considered");
	assert.equal(
		cov.covered,
		0,
		"zero covered (unaccounted required defers checkpoint)",
	);
});

test("a run with zero considered orders still emits a zero-required DETAIL_COVERAGE, but no DETAIL_GAP", async () => {
	const coverage = newOrderItemsCoverage();
	const { deps, protocolMessages } = makeRecordingDeps({
		orderItemsCoverage: coverage,
	});
	// No order processed: the accumulator is empty, but the year sweep still
	// ran to completion (this call site is only reached after it does), so the
	// zero denominator was genuinely measured and must be reported.
	await emitOrderItemsCoverage(deps, coverage);
	const cov = findDetailCoverage(protocolMessages);
	assert.ok(cov, "a swept-to-zero run still emits DETAIL_COVERAGE");
	assert.equal(cov.considered, 0);
	assert.equal(cov.covered, 0);
	assert.deepEqual(cov.required_keys, []);
	assert.deepEqual(cov.hydrated_keys, []);
	assert.equal(
		findDetailGaps(protocolMessages).length,
		0,
		"zero considered orders produce no gaps",
	);
});

// ─── item_count reconciliation ──────────────────────────────────────────

/**
 * `item_count` is not a provider assertion — Amazon never states a count in any
 * markup this connector reads. The number is a count of item elements parsed
 * from two surfaces, so the only reconcilable claim is the detail page's own
 * item list: every item that page showed must survive into a record. A merged
 * list SHORTER than the detail list means an item was seen and then lost.
 */
function findItemCountShortfalls(
	protocolMessages: readonly unknown[],
): Record<string, unknown>[] {
	return protocolMessages.filter(
		(m) =>
			(m as { type?: string; reason?: string }).type === "SKIP_RESULT" &&
			(m as { reason?: string }).reason === "item_count_shortfall",
	) as Record<string, unknown>[];
}

test("emitOrderAndItems: every detail-page item becoming a record reports no shortfall", async () => {
	const { deps, protocolMessages, emitted } = makeRecordingDeps();
	const detail = makeDetail({
		items: [
			makeDetailItem({ asin: "B000000001", name: "Widget A" }),
			makeDetailItem({ asin: "B000000002", name: "Widget B" }),
		],
	});
	await emitOrderAndItems(
		deps,
		makeListOrder({ items: [] }),
		detail,
		"2026-01-05",
	);

	assert.equal(emitted.filter((r) => r.stream === "order_items").length, 2);
	assert.equal(
		findItemCountShortfalls(protocolMessages).length,
		0,
		"a complete order must not report a gap",
	);
});

test("emitOrderAndItems: a detail item that never becomes a record is reported as a shortfall", async () => {
	// Two detail items collapse to one record because they carry the same
	// identity, so one of the items the page showed us is not in the database.
	// Before this check that loss was silent.
	const { deps, protocolMessages, emitted } = makeRecordingDeps();
	const detail = makeDetail({
		items: [
			makeDetailItem({ asin: "B000000001", name: "Widget A" }),
			makeDetailItem({ asin: "B000000001", name: "Widget A" }),
		],
	});
	await emitOrderAndItems(
		deps,
		makeListOrder({ items: [] }),
		detail,
		"2026-01-05",
	);

	const emittedItems = emitted.filter((r) => r.stream === "order_items").length;
	const shortfalls = findItemCountShortfalls(protocolMessages);
	assert.equal(emittedItems, 1, "the two detail rows collapsed to one record");
	assert.equal(shortfalls.length, 1, "the lost item must be surfaced");
	assert.deepEqual(shortfalls[0]?.diagnostics, {
		order_id: makeListOrder().orderId,
		declared_item_count: 2,
		emitted_item_count: 1,
	});
});

test("emitOrderAndItems: no detail page means no denominator and no fabricated shortfall", async () => {
	// A 3+ item order whose list card collapsed its titles reaches here with an
	// empty list and no detail. Counting the list card as the denominator would
	// invent a gap on every such order.
	const { deps, protocolMessages } = makeRecordingDeps();
	await emitOrderAndItems(
		deps,
		makeListOrder({ items: [] }),
		null,
		"2026-01-05",
	);

	assert.equal(
		findItemCountShortfalls(protocolMessages).length,
		0,
		"an unfetched detail page is an unknown, not a proven shortfall",
	);
});

test("emitOrderAndItems: the denominator is the detail page, never the list card", async () => {
	// Pins WHICH surface supplies the claim. The list card here shows two items
	// that dedupe to one record — a merge outcome, not a loss, because the list
	// card is not an authority on how many items an order has. Only the detail
	// page's own item list is a claim worth holding the connector to; falling
	// back to the list card manufactures a gap out of ordinary deduplication.
	const { deps, protocolMessages, emitted } = makeRecordingDeps();
	const listOrder = makeListOrder({
		items: [
			{ asin: "B000000001", name: "Widget A", url: null },
			{ asin: "B000000001", name: "Widget A", url: null },
		],
	});
	await emitOrderAndItems(deps, listOrder, null, "2026-01-05");

	assert.equal(
		emitted.filter((r) => r.stream === "order_items").length,
		1,
		"the duplicate list rows collapse",
	);
	assert.equal(
		findItemCountShortfalls(protocolMessages).length,
		0,
		"the list card is not a provider claim, so its count must not become a denominator",
	);
});

test("emitOrderAndItems: items out of scope suppress the reconciliation entirely", async () => {
	const { deps, protocolMessages } = makeRecordingDeps({ wantsItems: false });
	const detail = makeDetail({
		items: [
			makeDetailItem({ asin: "B000000001" }),
			makeDetailItem({ asin: "B000000001" }),
		],
	});
	await emitOrderAndItems(
		deps,
		makeListOrder({ items: [] }),
		detail,
		"2026-01-05",
	);

	assert.equal(
		findItemCountShortfalls(protocolMessages).length,
		0,
		"a stream nobody asked for cannot report a gap against records it never tried to emit",
	);
});

// ─── Page-ceiling honesty (PAGE_LIMIT) ────────────────────────────────────
//
// `runYear` has two exits: the year genuinely ran out of orders
// (`orders.length === 0`) and the `PAGE_LIMIT` blast-radius ceiling. Only the
// first one means "this year is complete". Conflating them is uniquely
// dangerous on Amazon because year state feeds a freeze-once-stable policy:
// a capped prefix reproduces the SAME order_count every run, so `stableCount`
// goes true on the next run and a past year is frozen — and `collect()` skips
// frozen years entirely, making the untraversed tail unreachable forever.

test("applyYearCompletionState: a page-ceiling-truncated year is never recorded, so it can never freeze", async () => {
	const newYearsState: YearsCursor = {};
	const progressCalls: string[] = [];
	const progress = ((message: string): Promise<void> => {
		progressCalls.push(message);
		return Promise.resolve();
	}) as unknown as BrowserCollectContext["progress"];

	// The second run of a truncated year: prior state holds the SAME capped
	// count this run produced. That equality is exactly what `stableCount`
	// tests, so an unguarded implementation freezes the year here.
	await applyYearCompletionState({
		newYearsState,
		prior: {
			frozen: false,
			last_scraped: "2026-01-01T00:00:00.000Z",
			order_count: 500,
		},
		progress,
		truncated: true,
		unparseableDateCount: 0,
		year: 2024,
		yearOrderCount: 500,
	});

	assert.deepEqual(
		newYearsState,
		{},
		"a truncated year must not be written to year state at all — writing it is what lets the " +
			"freeze-once-stable policy mark a partially-scanned past year complete forever",
	);
	assert.ok(
		progressCalls.some(
			(m) => m.includes("page limit") || m.includes("-page limit"),
		),
		`the owner must be told the year stopped at its page limit; got ${JSON.stringify(progressCalls)}`,
	);
});

test("applyYearCompletionState: an honest (untruncated) stable past year still freezes", async () => {
	// The guard against over-correcting: freeze-once-stable is a real
	// optimization and must survive for years that genuinely completed.
	const newYearsState: YearsCursor = {};
	const progress = ((): Promise<void> =>
		Promise.resolve()) as unknown as BrowserCollectContext["progress"];

	await applyYearCompletionState({
		newYearsState,
		prior: {
			frozen: false,
			last_scraped: "2026-01-01T00:00:00.000Z",
			order_count: 312,
		},
		progress,
		truncated: false,
		unparseableDateCount: 0,
		year: 2024,
		yearOrderCount: 312,
	});

	const recorded = newYearsState["2024"] as
		| { frozen: boolean; order_count: number }
		| undefined;
	assert.equal(recorded?.order_count, 312, "an honest year is still recorded");
	assert.equal(
		recorded?.frozen,
		true,
		"an honest, stable, past year still freezes — the optimization is preserved",
	);
});

// ─── Current-year forward walk (multi-page) ───────────────────────────────
//
// A 2026-08-23 report claimed a live run against a year holding many more
// orders than were stored recorded collection_facts of
// covered:2/considered:2 and committed the checkpoint anyway, contradicting a
// captured page (`orders-list-current-year-ten-orders.html`, structurally
// modeled on a real 2026 capture whose PII has been replaced) that the
// connector's own `parseOrdersListDom` parses into 10 valid orders.
//
// This drives `scrapeListPage` the same way `runYear`'s forward loop does:
// page 1 (startIndex=0) returns the ten orders, page 2 (startIndex=10) is the
// natural end of pagination (no more cards). If the walk logic itself were
// the defect, this test would see fewer than 10 orders from page 1, or would
// need something other than genuine pagination exhaustion to stop. It does
// not: `scrapeListPage` and the loop shape in `runYear` both faithfully
// surface every order the page contains.

const AMAZON_CURRENT_YEAR_TEN_ORDERS_FIXTURE = new URL(
	"./__fixtures__/orders-list-current-year-ten-orders.html",
	import.meta.url,
);

function makeListPageStub(html: string): Page {
	return Object.assign({} as Page, {
		content: (): Promise<string> => Promise.resolve(html),
		goto: (): Promise<null> => Promise.resolve(null),
		locator: (): { first: () => { waitFor: () => Promise<null> } } => ({
			first: () => ({ waitFor: (): Promise<null> => Promise.resolve(null) }),
		}),
	});
}

test("scrapeListPage: a current-year page with ten orders yields all ten, not a truncated subset", async () => {
	const html = readFileSync(AMAZON_CURRENT_YEAR_TEN_ORDERS_FIXTURE, "utf8");
	const messages: EmittedMessage[] = [];
	const orders = await scrapeListPage(
		makeListPageStub(html),
		null,
		2026,
		0,
		(message) => {
			messages.push(message);
			return Promise.resolve();
		},
	);

	assert.equal(
		orders.length,
		10,
		"every order card on the page must be walked, not just the first two",
	);
	assert.deepEqual(
		orders.map((o) => o.orderId),
		[
			"111-0000001-0000001",
			"111-0000002-0000002",
			"111-0000003-0000003",
			"111-0000004-0000004",
			"111-0000005-0000005",
			"111-0000006-0000006",
			"111-0000007-0000007",
			"111-0000008-0000008",
			"111-0000009-0000009",
			"111-0000010-0000010",
		],
	);
	assert.equal(
		messages.some((message) => message.type === "SKIP_RESULT"),
		false,
		"a fully-parseable page must not report any diagnostic loss",
	);
});

test("scrapeListPage: the forward walk's natural stopping page (no more cards) is ordinary pagination exhaustion, not a truncation", async () => {
	// Models what `runYear` calls next after the ten-order page above: the
	// SAME year at startIndex=10, where Amazon's own list genuinely has no
	// more orders. `startIndex > 0` must fall through to the silent
	// `pagination_exhausted` terminal classification — never the
	// `amazon_empty_history_after_prior_orders` guard, which is scoped to
	// `startIndex === 0` only (a later page coming back empty is ordinary
	// exhaustion of a year that plainly did yield orders this run, not a claim
	// that the year is empty). This pins that boundary so a future change to
	// this walk cannot reopen the hole 6f9143f58 closed.
	const emptyHtml =
		'<html><body><div id="ordersContainer"></div></body></html>';
	const messages: EmittedMessage[] = [];
	const page = Object.assign({} as Page, {
		content: (): Promise<string> => Promise.resolve(emptyHtml),
		evaluate: (): Promise<ListPageDiagnostics> =>
			Promise.resolve(
				makeEmptyPageDiagnostics({
					order_cards: 0,
					any_card: 0,
					any_order_header: 0,
					no_orders_text: "false",
				}),
			),
		goto: (): Promise<null> => Promise.resolve(null),
		locator: (): { first: () => { waitFor: () => Promise<null> } } => ({
			first: () => ({ waitFor: (): Promise<null> => Promise.resolve(null) }),
		}),
	});

	const orders = await scrapeListPage(
		page,
		null,
		2026,
		10,
		(message) => {
			messages.push(message);
			return Promise.resolve();
		},
		{ hasPriorOrders: true },
	);

	assert.deepEqual(orders, [], "pagination exhaustion yields no orders");
	assert.deepEqual(
		messages,
		[],
		"ordinary pagination exhaustion is a silent, expected terminal state",
	);
});
