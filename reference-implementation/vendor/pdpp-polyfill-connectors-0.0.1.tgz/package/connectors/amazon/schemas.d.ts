/**
 * Zod schemas for Amazon stream records. Used for shape-check-before-emit
 * per docs/reference/connector-authoring-guide.md §3: records that don't match the
 * schema become SKIP_RESULT events instead of RECORD events, so the RS
 * never receives data that looks right but isn't.
 *
 * Each schema asserts:
 *   - primitive types correct
 *   - lengths bounded
 *   - no known cruft patterns in string fields (regex literals like
 *     "Buy it again", "Sold by" that only appear if row parsing failed)
 *   - currency/id shapes correct
 *
 * Schemas intentionally accept `null` for fields that can legitimately be
 * absent. Required fields (id, order_date) must be present.
 */
import { z } from "zod";
export declare const orderSchema: z.ZodObject<{
    id: z.ZodString;
    order_date: z.ZodString;
    order_total: z.ZodNullable<z.ZodString>;
    order_total_cents: z.ZodNullable<z.ZodNumber>;
    delivery_status: z.ZodNullable<z.ZodString>;
    status_detail: z.ZodNullable<z.ZodString>;
    recipient_name: z.ZodNullable<z.ZodString>;
    shipping_address_summary: z.ZodNullable<z.ZodString>;
    payment_method_summary: z.ZodNullable<z.ZodString>;
    gift_order: z.ZodBoolean;
    digital_order: z.ZodBoolean;
    item_count: z.ZodNullable<z.ZodNumber>;
    fetched_at: z.ZodString;
}, z.core.$strip>;
export declare const orderItemSchema: z.ZodObject<{
    id: z.ZodString;
    order_id: z.ZodString;
    order_date: z.ZodString;
    asin: z.ZodNullable<z.ZodString>;
    name: z.ZodString;
    url: z.ZodNullable<z.ZodURL>;
    unit_price: z.ZodNullable<z.ZodString>;
    unit_price_cents: z.ZodNullable<z.ZodNumber>;
    quantity: z.ZodNumber;
    seller: z.ZodNullable<z.ZodString>;
    item_image_url: z.ZodNullable<z.ZodString>;
    returned: z.ZodBoolean;
    refund_status: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const listPageOrderShape: z.ZodObject<{
    orderId: z.ZodString;
    orderDateRaw: z.ZodNullable<z.ZodString>;
    orderTotal: z.ZodNullable<z.ZodString>;
    deliveryStatus: z.ZodNullable<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        url: z.ZodNullable<z.ZodURL>;
        asin: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map