#!/usr/bin/env node
import type { BrowserContext, Page } from "playwright";
import { type BrowserCollectContext, type DetailGapMessage } from "../../src/connector-runtime.ts";
import { type FingerprintCursor } from "../../src/fingerprint-cursor.ts";
import type { ListPageDiagnostics, ListPageOrder, OrderDetail } from "./types.ts";
export interface YearState {
    frozen: boolean;
    last_scraped: string;
    order_count: number;
}
export interface YearsCursor {
    [year: string]: YearState | undefined;
}
type EmptyListPageAction = "abort" | "terminal";
interface EmptyListPageClassification {
    action: EmptyListPageAction;
    reason: string;
}
/**
 * What this connection already knows about the order history OF THE YEAR
 * currently being scraped, threaded explicitly into the otherwise-pure
 * empty-page classifier.
 *
 * `hasPriorOrders` is true when a prior run committed a `years[<year>]`
 * cursor whose `order_count` is greater than zero — the in-connector proof
 * that Amazon once listed orders for this account IN THIS YEAR.
 *
 * PER-YEAR, not per-account, and that is the whole difference from H-E-B.
 * H-E-B's list is one globally reverse-chronological feed, so any committed
 * checkpoint contradicts any empty page. Amazon is year-partitioned: it
 * renders a genuine, year-scoped "Looks like you didn't place an order in
 * 2015." for a year the owner simply did not shop, on an account holding
 * thousands of orders in other years. Account-wide evidence would abort every
 * such year forever and break the incremental year sweep. Only the SAME
 * year's own prior `order_count` can contradict that year's empty page.
 */
export interface PriorOrdersEvidence {
    hasPriorOrders: boolean;
}
/** Owner-facing message for the one classification whose whole point is to be
 *  read by a person. Says exactly what was observed and what was NOT
 *  concluded: neither selector drift nor a bot block is established, so
 *  neither is named. Stored records are untouched — this connector never
 *  deletes, tombstones, or overwrites on an empty page; it only declines to
 *  advance the year cursor. */
export declare const AMAZON_EMPTY_AFTER_PRIOR_ORDERS_MESSAGE: string;
export declare const AMAZON_NO_ORDERS_TEXT_PATTERN: string;
export type AmazonDetailGapReason = "retry_exhausted" | "temporary_unavailable" | "upstream_pressure";
type DetailFailureKind = "deferred_budget" | "navigation_retry_exhausted" | "parse_missing" | "redirected_non_detail" | "session_repair_required";
export type DetailFetchResult = {
    detail: OrderDetail;
    status: "hydrated";
} | {
    failureKind: DetailFailureKind;
    reason: AmazonDetailGapReason;
    status: "deferred";
} | {
    failureKind: DetailFailureKind;
    reason: AmazonDetailGapReason;
    status: "failed";
};
/**
 * Connector-neutral recovery class for one Amazon detail-attempt outcome.
 *
 * These are the design-D4 scheduling classes the runtime and owner UI reason
 * about. The connector's job (design D5) is to translate its Amazon-specific
 * failure kinds into this neutral vocabulary so the runtime never sees a local
 * label like `navigation_retry_exhausted` and the owner never sees it as copy.
 * The connector does NOT own the scheduling/quarantine budget that turns a
 * repeated `connector_defect` into a durable terminal gap — that lives in the
 * runtime terminal-gap classifier. This class is the honest signal the runtime
 * consumes; it is emitted on the gap's `detail.class`/`last_error.class`.
 *
 *   - `run_cap_deferred`        — planned blast-radius stop (per-run detail cap
 *                                 or retry budget). Resumable; NOT source
 *                                 pressure.
 *   - `transient_no_progress`   — a transient DOM/parse/navigation failure that
 *                                 made no progress this attempt. Retryable, but
 *                                 the runtime is responsible for escalating
 *                                 repeated no-progress to a connector issue.
 *   - `provider_pressure`       — Amazon rate-limited / throttled the request.
 *                                 Arms the source-pressure cooldown.
 *   - `owner_repair_required`   — the authenticated session is gone (detail
 *                                 request redirected to sign-in/challenge/MFA).
 *                                 The owner must reconnect; retrying is busywork.
 *   - `connector_defect`        — a deterministic parser/navigation defect the
 *                                 connector itself must be fixed for.
 */
export type AmazonRecoveryClass = "run_cap_deferred" | "transient_no_progress" | "provider_pressure" | "owner_repair_required" | "connector_defect";
export declare function reasonForDetailFailure(kind: DetailFailureKind): AmazonDetailGapReason;
/**
 * Map an Amazon detail failure kind to its connector-neutral recovery class.
 * Pure and exhaustive so the classification can be unit-tested without driving
 * the browser and so a newly added failure kind is a compile error until it is
 * classified.
 *
 * NOTE ON `parse_missing`: a single parse-missing attempt is `transient_no_progress`,
 * not `connector_defect`. Whether *repeated* deterministic no-progress becomes a
 * durable connector defect is a runtime decision (per-item attempt budget +
 * terminal-gap classifier), not a per-attempt connector call. See the recovery
 * governor design D4/D10 and the runtime dependency noted in the change report.
 */
export declare function classifyAmazonDetailFailure(kind: DetailFailureKind): AmazonRecoveryClass;
export declare function readPageContentWithin(page: Pick<Page, "content">, timeoutMs?: number): Promise<string>;
export type EmitFn = BrowserCollectContext["emit"];
export type EmitRecordFn = BrowserCollectContext["emitRecord"];
export type CaptureDep = BrowserCollectContext["capture"];
/** Ephemeral per-run flags that cross year boundaries. */
export interface RunFlags {
    detailAttempts: number;
    detailCaptured: boolean;
    failedDetailCaptured: boolean;
    /** One-shot budget: at most one mid-run automated session-repair attempt
     *  per run (see `attemptAutomatedSessionRepair`), regardless of how many
     *  detail fetches subsequently land on sign-in. Distinct from
     *  `sessionRepairRequired` — that flag starts `false` and is set `true`
     *  exactly once, by whichever sign-in bounce reaches it first (there is no
     *  code path that clears it back to `false` once set); this one is the
     *  same shape (starts `false`, set `true` at most once) but guards a
     *  different decision (spend vs. don't-spend the repair attempt, not
     *  latch vs. don't-latch the terminal state). */
    repairAttempted: boolean;
    /** Set once a detail attempt lands on Amazon's sign-in/challenge flow AND
     *  either the one-shot repair attempt was ineligible/failed, or the budget
     *  was already spent by an earlier bounce this run — there is no code path
     *  that clears this back to `false`, so once set it stays set for the rest
     *  of the run (a write-once latch, not a flag a successful repair resets).
     *  The authenticated session is dead for the rest of this run, so
     *  remaining detail attempts are deferred (a connector-local blast-radius
     *  stop) rather than hammering sign-in once per order. This is NOT
     *  cross-run scheduling — the runtime owns whether/when the next run
     *  retries. */
    sessionRepairRequired: boolean;
    temporaryDetailFailures: number;
}
/**
 * Per-run, order-item detail coverage accumulator.
 *
 * Amazon enumerates the full order list per scraped year BEFORE hydrating any
 * order-detail page, so the set of list-page order ids it processes is a real
 * "considered" denominator (not a gap-only inference). The `order_items` stream
 * is enriched by the per-order detail page (seller, unit_price, item image,
 * detail-only items). When that detail fetch succeeds the order's items are
 * hydrated; when it returns null the list-page items still emit but the detail
 * enrichment is missing — an honest degraded-coverage signal, not silence.
 *
 * Each set holds order ids (globally unique across years), so the accumulator
 * spans every scraped year and is reported once after the year loop:
 *   - `required`  — every order considered for detail hydration (denominator).
 *   - `hydrated`  — orders whose detail page fetched and parsed (numerator).
 *   - `gap`       — orders whose detail fetch was attempted but degraded (null, or deferred by policy).
 */
export interface OrderItemsCoverage {
    gap: string[];
    hydrated: string[];
    required: string[];
}
export declare function newOrderItemsCoverage(): OrderItemsCoverage;
/**
 * Per-run, `orders` list-stream coverage accumulator — a distinct denominator
 * from `OrderItemsCoverage` (that one tracks the `order_items` detail-page
 * enrichment; this one tracks the `orders` list stream itself, so
 * `orders`/`checkpoint_window` can report honest evidence even on a run that
 * skips order_items entirely).
 *
 * Every list-page order the year loop reaches `emitOrderAndItems` for is
 * "considered" (the denominator), whether or not `wantsOrders` is in scope —
 * the list scan enumerated it. An order is "covered" once the connector made
 * a real accounting decision for its `orders` record: either it emitted, or
 * the per-order fingerprint cursor deliberately suppressed a byte-identical
 * re-scrape (still a real decision, not a drop). An order whose date never
 * parses never reaches `emitOrderAndItems`, so it is recorded separately as
 * `dateDropped` — considered, but not covered, since no accounting decision
 * was made for it.
 */
export interface OrdersCoverage {
    considered: string[];
    covered: string[];
    dateDropped: string[];
}
export declare function newOrdersCoverage(): OrdersCoverage;
/** The detail-hydration outcome for one considered order. */
export type DetailOutcome = "hydrated" | "gap" | "unaccounted";
/**
 * Classify one order's detail outcome. Policy-deferred orders
 * (PDPP_AMAZON_SKIP_DETAIL=1) are "unaccounted": required but not in any
 * outcome set. Per spec, required_keys absent from outcomes defer the
 * checkpoint. Attempted-but-failed is gap (backed by DETAIL_GAP).
 */
export declare function classifyDetailOutcome(skipDetail: boolean, detail: OrderDetail | null): DetailOutcome;
/**
 * Record one order's detail outcome into the run-level coverage accumulator.
 * Pure aside from mutating the passed accumulator; only the order id (an opaque
 * Amazon order number, already carried in SKIP_RESULT diagnostics) crosses in,
 * never recipient/address/payment fields. Every recorded order joins
 * `required` (the denominator); the outcome decides which numerator/skip set it
 * also joins.
 */
export declare function recordDetailOutcome(coverage: OrderItemsCoverage, orderId: string, outcome: DetailOutcome): void;
/**
 * Build the per-order pending DETAIL_GAP for an order whose detail fetch was
 * attempted but came back null (a degraded gap, not a policy skip). The runtime
 * treats `DETAIL_COVERAGE.gap_keys` as a projection only — a `required` key is
 * satisfied at state-commit solely by a hydration, an optional skip, or a
 * durable pending DETAIL_GAP with a matching `record_key`
 * (`assertDetailCoverageSatisfiedBeforeCommit`). Emitting `gap_keys` without the
 * matching DETAIL_GAP would fail an otherwise-successful run at commit, so every
 * gap order MUST carry exactly one pending DETAIL_GAP on `order_items` (the same
 * stream the coverage report describes, so the runtime's
 * `gap.stream === coverage.stream` match holds).
 *
 * Reference-only and redacted: the opaque Amazon order id is the only datum that
 * crosses (it is already the `record_key`/`detail_locator.order_id`); no
 * recipient, address, payment, item title, or item text is carried. `reason`
 * stays redacted but precise enough to distinguish exhausted navigation retries
 * from parse-missing detail pages and connector-budget deferrals.
 */
export declare function buildOrderDetailGap(orderId: string, reason?: AmazonDetailGapReason, failureKind?: DetailFailureKind | undefined, orderDate?: string | undefined): DetailGapMessage;
/** Injectable override for `attemptAutomatedSessionRepair`'s call to the
 *  real `ensureAmazonSession` — lets tests substitute a fake reauth without
 *  driving the full interactive login flow against a stub Page. Mirrors
 *  the USAA connector's `EmitDeps.reauthenticate` seam. */
export type AmazonReauthFn = (input: {
    context: BrowserContext;
    credentials?: Readonly<Record<string, string | undefined>> | undefined;
    page: Page;
    sendInteraction: BrowserCollectContext["sendInteraction"];
}) => Promise<boolean>;
export interface AmazonDetailRecoveryDeps {
    capture: CaptureDep;
    /** Threaded through to `resolveOrderDetail`'s mid-run session-repair
     *  attempt. Optional so legacy callers/tests that don't exercise the
     *  repair path can omit it — see `EmitDeps.context`. */
    context?: BrowserContext | undefined;
    /** This connection's resolved sign-in pair, threaded to the mid-run repair
     *  gate. Optional for the same reason as `context`. */
    credentials?: Readonly<Record<string, string | undefined>> | undefined;
    detailGaps: readonly BrowserCollectContext["detailGaps"][number][];
    emit: EmitFn;
    emitRecord: EmitRecordFn;
    /** Test-only override for `attemptAutomatedSessionRepair`'s reauth call.
     *  Production callers omit it (falls back to the real `ensureAmazonSession`). */
    reauthenticate?: AmazonReauthFn | undefined;
    requestDetailGapPage?: BrowserCollectContext["requestDetailGapPage"] | undefined;
    sendInteraction?: BrowserCollectContext["sendInteraction"] | undefined;
}
export declare function recoverPendingOrderItemDetailGaps(page: Page, deps: AmazonDetailRecoveryDeps, flags: RunFlags): Promise<{
    recovered: number;
    stoppedWithPending: boolean;
}>;
export declare function recoverPendingOrderItemDetailGapsBeforeForwardRun(page: Page, deps: AmazonDetailRecoveryDeps, flags: RunFlags, options: {
    recoveryOnly?: boolean;
    wantsItems: boolean;
}): Promise<{
    recovered: number;
    stoppedWithPending: boolean;
    suppressForward: boolean;
}>;
/**
 * Emit the run-level `order_items` DETAIL_COVERAGE once after the year loop,
 * using the shared `emitDetailCoverage` helper. The detail stream described is
 * `order_items` (enriched by the per-order detail page); its cursor is anchored
 * by the `orders` list stream (`state_stream`). The caller (`collect()`) only
 * reaches this call site once the `for (const year of years)` sweep has run to
 * completion without throwing — a thrown error aborts the whole collect() call
 * before this line — so `coverage.required.length === 0` here always means
 * "the year sweep completed and considered zero orders across every in-scope
 * year," never "the sweep never ran." Always emits when the caller invokes it
 * (order_items in scope) — including that zero-required steady-state case
 * (considered: 0, covered: 0, empty key sets) — so a run that legitimately
 * swept its denominator to zero stays measured instead of silently
 * unreported. Reuses DETAIL_COVERAGE as a reference-only projection; it is
 * not promoted to portable protocol.
 */
export declare function emitOrderItemsCoverage(deps: EmitDeps, coverage: OrderItemsCoverage): Promise<void>;
/**
 * Emit the run-level `orders` DETAIL_COVERAGE once after the year loop, using
 * the shared `emitDetailCoverage` helper self-referentially (`stream` and
 * `stateStream` both `"orders"` — there is no separate detail-hydration phase
 * for the list stream itself, so `requiredKeys`/`hydratedKeys` stay empty and
 * the denominator/numerator live entirely in `considered`/`covered`, mirroring
 * the pattern used for USAA's `inbox_messages` and GitHub's `declareListConsidered`
 * streams). Always emits when the caller invokes it (orders in scope) —
 * including a zero-considered steady-state run — for the same reason
 * `emitOrderItemsCoverage` always emits: a completed sweep that considered
 * zero orders is a real measured zero, not silence.
 */
export declare function emitOrdersCoverage(deps: EmitDeps, coverage: OrdersCoverage): Promise<void>;
/** Per-run dependencies threaded through processListOrder → emitOrderAndItems. */
export interface EmitDeps {
    capture: CaptureDep;
    /** Threaded through to `resolveOrderDetail`'s mid-run session-repair
     *  attempt (see `attemptAutomatedSessionRepair`). Optional so legacy
     *  callers/tests that don't exercise the repair path can omit it — when
     *  absent, a sign-in bounce falls straight through to the existing
     *  terminal `session_repair_required` behavior, unchanged from before
     *  this fix. */
    context?: BrowserContext | undefined;
    /** This connection's resolved sign-in pair, threaded to the mid-run repair
     *  gate. Optional for the same reason as `context`. */
    credentials?: Readonly<Record<string, string | undefined>> | undefined;
    emit: EmitFn;
    emitRecord: EmitRecordFn;
    emittedAt: string;
    /** Order ids known to have a durably-hydrated `order_items` detail, mapped
     *  to the list-surface fingerprint (see `listSurfaceFingerprint`) observed
     *  at hydration time. Seeded from the PRIOR run's STATE cursor and mutated
     *  in place as THIS run hydrates more orders (see
     *  `readPriorHydratedOrders`). Proof is "hydrated AND the list surface has
     *  not moved since" — an order whose list row changes is treated as
     *  not-yet-hydrated and re-fetched. The current year is never frozen
     *  (orders are ongoing), so every unfrozen year is re-listed on every run;
     *  without this map `processListOrder` would re-attempt detail hydration
     *  for every already-covered, unchanged order every run, burning the
     *  per-run detail-attempt budget on repeat work instead of reaching
     *  genuinely new orders. Optional so legacy callers/tests that don't
     *  exercise the skip path can omit it. */
    hydratedOrders?: Map<string, string> | undefined;
    /** Run-level `order_items` detail coverage accumulator. Optional so legacy
     *  callers/tests that only exercise emit ordering can omit it; when present,
     *  processListOrder records each considered order's detail outcome here and
     *  collect() emits one DETAIL_COVERAGE after the year loop. */
    orderItemsCoverage?: OrderItemsCoverage | undefined;
    /** Run-level `orders` list-stream coverage accumulator. Optional so legacy
     *  callers/tests that only exercise emit ordering can omit it; when present,
     *  processListOrder records each considered order's list-accounting outcome
     *  here and collect() emits one self-referential DETAIL_COVERAGE after the
     *  year loop. */
    ordersCoverage?: OrdersCoverage | undefined;
    /** Per-order fingerprint cursor (excludes the run-clock `fetched_at`).
     *  Shared across all years for the whole orders stream because order ids
     *  are globally unique. Optional so legacy callers/tests emit
     *  unconditionally. */
    ordersFingerprintCursor?: FingerprintCursor | undefined;
    progress: BrowserCollectContext["progress"];
    /** Test-only override for `attemptAutomatedSessionRepair`'s reauth call.
     *  Production callers omit it (falls back to the real `ensureAmazonSession`). */
    reauthenticate?: AmazonReauthFn | undefined;
    /** Threaded through to `resolveOrderDetail`'s mid-run session-repair
     *  attempt alongside `context`. Optional for the same reason. */
    sendInteraction?: BrowserCollectContext["sendInteraction"] | undefined;
    skipDetail: boolean;
    wantsItems: boolean;
    wantsOrders: boolean;
}
/** Emit the order record + per-item records for a single list-page order.
 *
 * The invariants this enforces:
 *   1. The order record emits BEFORE its item records (so downstream
 *      readers see the parent-child relationship in order).
 *   2. Items emit in mergeOrderItems() order — list-page items first,
 *      detail-only items appended — which is the dedup + enrichment
 *      order consumers depend on.
 *   3. Streams disabled via scope (wantsOrders/wantsItems) emit nothing;
 *      the other stream still flows.
 * Regressing any of these is a real bug; integration.test.ts covers them.
 */
export declare function emitOrderAndItems(deps: EmitDeps, listOrder: ListPageOrder, detail: OrderDetail | null, orderDate: string): Promise<void>;
/** Browser text, titles, and URLs are useful for local classification but are
 * not durable connector evidence. Keep only structural facts in SKIP_RESULT. */
export declare function redactAmazonListPageDiagnostics(diag: ListPageDiagnostics): ListPageDiagnostics;
export declare function classifyEmptyListPageDiagnostics(diag: ListPageDiagnostics | null, startIndex: number, priorOrdersEvidence?: PriorOrdersEvidence): EmptyListPageClassification;
/**
 * Navigate to one list-page URL for `year` at `startIndex`, wait for the
 * list signal, optionally capture a fixture, and return the shape-checked
 * orders. On zero orders, emits drift diagnostics before returning [].
 */
export declare function scrapeListPage(page: Page, capture: CaptureDep, year: number, startIndex: number, emit: EmitFn, priorOrdersEvidence?: PriorOrdersEvidence): Promise<ListPageOrder[]>;
/**
 * The fingerprint of everything the LIST page alone can prove about an
 * order — computed the same way as an enriched `orders` record but with
 * `detail: null`, so detail-only fields (recipient, payment, status_detail,
 * gift/digital flags) are excluded and only list-observable fields
 * (delivery status, list total, list item count) participate. Comparing
 * this against the fingerprint recorded at hydration time is the change
 * trigger: if the list surface has not moved, the prior enriched detail is
 * still valid; if it has (delivery progressed, a return appeared), the
 * order must be re-hydrated.
 */
export declare function listSurfaceFingerprint(listOrder: ListPageOrder, orderDate: string, emittedAt: string): string;
export declare function processListOrder(page: Page, deps: EmitDeps, flags: RunFlags, listOrder: ListPageOrder): Promise<boolean>;
interface YearCompletionArgs {
    newYearsState: YearsCursor;
    prior: YearState | undefined;
    progress: BrowserCollectContext["progress"];
    /** A year cut short by the page ceiling must never be recorded as complete. */
    truncated: boolean;
    unparseableDateCount: number;
    year: number;
    yearOrderCount: number;
}
export declare function applyYearCompletionState({ newYearsState, prior, progress, truncated, unparseableDateCount, year, yearOrderCount, }: YearCompletionArgs): Promise<void>;
/**
 * Decide whether `collect()` must emit a trailing `orders` STATE after the
 * year loop, to persist durable progress the loop itself never reached a
 * STATE emit for. `ordersStateEmitted` (NOT `years.length === 0`) is the
 * right signal: `planIncrementalYears` always plans the current and
 * previous year and the previous year CAN be frozen, so the loop runs with
 * `years.length > 0` while every iteration `continue`s before its STATE
 * emit. Exported for direct unit coverage of this decision, independent of
 * a full `collect()` drive (which needs a browser context this repo's other
 * connector test suites also don't build).
 */
export declare function shouldEmitTrailingOrdersState(ordersStateEmitted: boolean, hydratedOrders: ReadonlyMap<string, string>): boolean;
/**
 * Derive the prior-orders evidence for ONE year from this connection's stored
 * `years` cursor. Exported and pure because `collect()` lives inside the
 * `isMainModule` block and cannot be driven from a test — without this seam
 * the year-state-to-evidence link would be the one untested link in the
 * chain, and a mutation that hardcodes `false` here (silently disarming the
 * guard for every connection) would go unnoticed.
 *
 * The evidence is `order_count > 0`, not the mere existence of a year cursor.
 * A year that was scraped and legitimately held zero orders commits a cursor
 * with `order_count: 0`; that year must stay free to report empty again on
 * every later run. Only a year that actually yielded orders can contradict a
 * later "no orders" page.
 */
export declare function priorOrdersEvidenceForYear(yearsState: YearsCursor, year: number): PriorOrdersEvidence;
/**
 * Given the full set of discovered years and prior year state, return the
 * subset that should be scraped on this run.
 *
 * Invariants:
 *   - Current year is always included (orders are ongoing).
 *   - Previous year is always included (returns / late-arriving shipments
 *     can post after year-end).
 *   - Any year ≥2 years ago that already has a `last_scraped` timestamp in
 *     prior state is skipped — it was captured on a previous run and
 *     re-scraping it on every incremental run is unbounded behaviour.
 *   - Any year ≥2 years ago with NO prior `last_scraped` (newly discovered)
 *     is included so first-time discovery still works.
 *   - If there is no prior scraped state at all (first run), all years are
 *     returned so the initial backfill completes normally.
 *
 * This function is exported for unit testing. The `currentYear` parameter
 * is injected to keep the function pure (no `new Date()` at call time).
 */
export declare function planIncrementalYears(years: number[], yearsState: YearsCursor, currentYear: number): {
    planned: number[];
    skipped: Array<{
        year: number;
        reason: string;
    }>;
};
export {};
//# sourceMappingURL=index.d.ts.map