/**
 * Zod schemas for Apple Health stream records. Shape-check-before-emit per
 * docs/reference/connector-authoring-guide.md §3.
 *
 * Ground truth: `buildHealthRecord` (records) and `buildWorkoutRecord`
 * (workouts) in parsers.ts — the only things index.ts passes to
 * `emitRecord(...)`. Schemas mirror the *emitted* shape, not the manifest:
 *
 *   - `id` is `hashId(...)` → a 24-char lowercase hex digest (sha256 sliced).
 *   - `start_date` / `end_date` come from `isoDate`, which is
 *     `new Date(v).toISOString()` → always `...T..:..:...sssZ`. The schema
 *     accepts that via an ISO-prefix regex.
 *   - `type` (records) is `healthTypeShort(...)` — the HK identifier with its
 *     `HKQuantityTypeIdentifier` / `HKCategoryTypeIdentifier` / `HKDataType`
 *     prefix stripped (e.g. `StepCount`, `HeartRate`). Defaults to the raw type
 *     or `"Unknown"` when absent, so it is always a non-empty structural token,
 *     NOT free-form human text. Required by the manifest.
 *   - `workout_activity_type` (workouts) is the HKWorkoutActivityType with its
 *     prefix stripped (e.g. `Running`), or null. Structural token, nullable.
 *   - `value` is `Number(attrs.value)` only when finite; otherwise null. It is
 *     FLOAT-CAPABLE (heart rate, body mass, etc. are non-integers) and is
 *     `z.number().nullable()`, NOT `.int()`. `value_raw` carries the original
 *     non-numeric string (e.g. a category value like `HKCategoryValueSleep...`)
 *     when `value` could not be parsed — a structural HK token, bounded string.
 *   - `unit` / `source_name` / `source_version` are short device/app metadata
 *     strings (`mg/dL`, `Apple Watch`, `10.1`), nullable structural strings.
 *   - workout numerics (`duration_minutes`, `total_energy_burned_kcal`,
 *     `total_distance_km`) are `Number(...)` passthroughs → float-capable,
 *     non-negative, nullable.
 *
 * `source_name` is device/app provenance, not free human prose, so it is a
 * bounded `z.string()` rather than `pdppSafeText`. Apple Health records carry
 * no free-form user text fields — every string is a structural HK token or a
 * device/app identifier.
 */
import { z } from "zod";
/**
 * records stream: one record per HKRecord element with a parseable startDate.
 * Cursor: start_date (last_start_date).
 */
export declare const recordsSchema: z.ZodObject<{
    id: z.ZodString;
    type: z.ZodString;
    source_name: z.ZodNullable<z.ZodString>;
    source_version: z.ZodNullable<z.ZodString>;
    unit: z.ZodNullable<z.ZodString>;
    value: z.ZodNullable<z.ZodNumber>;
    value_raw: z.ZodNullable<z.ZodString>;
    start_date: z.ZodString;
    end_date: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * workouts stream: one record per HKWorkout element with a parseable startDate.
 * Cursor: start_date (last_start_date).
 */
export declare const workoutsSchema: z.ZodObject<{
    id: z.ZodString;
    workout_activity_type: z.ZodNullable<z.ZodString>;
    duration_minutes: z.ZodNullable<z.ZodNumber>;
    total_energy_burned_kcal: z.ZodNullable<z.ZodNumber>;
    total_distance_km: z.ZodNullable<z.ZodNumber>;
    source_name: z.ZodNullable<z.ZodString>;
    start_date: z.ZodString;
    end_date: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map