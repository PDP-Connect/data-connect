import type { AppleHealthAttrs, HealthRecordOut, WorkoutRecordOut } from "./types.ts";
export declare const APPLE_HEALTH_TAG_RE: RegExp;
export declare function hashId(s: string): string;
export declare function parseAttrs(tag: string): AppleHealthAttrs;
export declare function healthTypeShort(t: string | undefined): string | null;
export declare function isoDate(v: string | undefined): string | null;
/**
 * Build a single `records`-stream record from a parsed HKRecord element.
 * Returns null when startDate is missing or unparseable; index.ts treats
 * that as "skip silently" since Apple Health emits some records without
 * a usable timestamp (e.g. metadata rows).
 */
export declare function buildHealthRecord(attrs: AppleHealthAttrs): HealthRecordOut | null;
/**
 * Build a single `workouts`-stream record from a parsed HKWorkout element.
 * Returns null when startDate is missing or unparseable.
 */
export declare function buildWorkoutRecord(attrs: AppleHealthAttrs): WorkoutRecordOut | null;
/**
 * Return true if `startDate` falls on or before the incremental cursor
 * `since`. index.ts uses this to skip already-emitted records.
 */
export declare function isBeforeCursor(startDate: string, since: string | undefined): boolean;
/** Monotonic max of an existing cursor and a new ISO date string. */
export declare function advanceCursor(prev: string | undefined, next: string): string;
//# sourceMappingURL=parsers.d.ts.map