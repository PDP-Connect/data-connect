import { type ZipReadPolicy } from "../../src/bounded-zip-archive.ts";
import type { AppleHealthAttrs, AppleHealthElement, AppleHealthGapCounts, AppleHealthWorkoutEvent, HealthRecordOut, WorkoutRecordOut } from "./types.ts";
export declare const APPLE_HEALTH_TAG_RE: RegExp;
export declare function hashId(s: string): string;
export declare function parseAttrs(tag: string): AppleHealthAttrs;
export declare function healthTypeShort(t: string | undefined): string | null;
export declare function isoDate(v: string | undefined): string | null;
/** Build a WorkoutEvent record from its raw attrs (type, date, optional duration/durationUnit). */
export declare function buildWorkoutEvent(attrs: AppleHealthAttrs): AppleHealthWorkoutEvent;
/**
 * Record a Record element's `type` in the gap tally when it does not match
 * any known HK*TypeIdentifier prefix. Apple Health's export format is
 * undocumented and has shifted across iOS versions (see
 * ai/research/apple-health-export-format/), so a new/unrecognized type
 * prefix is expected eventually — this project never drops that silently.
 */
export declare function trackUnrecognizedType(type: string | undefined, gaps: AppleHealthGapCounts): void;
export declare function newGapCounts(): AppleHealthGapCounts;
/**
 * Build a single `records`-stream record from a parsed HKRecord element
 * (attrs + any nested MetadataEntry children). Returns null when startDate
 * is missing or unparseable; index.ts counts that in `gaps` rather than
 * dropping it silently, since Apple Health emits some records without a
 * usable timestamp (e.g. metadata rows).
 */
export declare function buildHealthRecord(el: AppleHealthElement, gaps: AppleHealthGapCounts): HealthRecordOut | null;
/**
 * Build a single `workouts`-stream record from a parsed HKWorkout element
 * (attrs + nested MetadataEntry/WorkoutEvent/WorkoutStatistics children).
 * Returns null when startDate is missing or unparseable.
 */
export declare function buildWorkoutRecord(el: AppleHealthElement, gaps: AppleHealthGapCounts): WorkoutRecordOut | null;
/**
 * Return true if `startDate` falls on or before the incremental cursor
 * `since`. index.ts uses this to skip already-emitted records.
 */
export declare function isBeforeCursor(startDate: string, since: string | undefined): boolean;
/** Monotonic max of an existing cursor and a new ISO date string. */
export declare function advanceCursor(prev: string | undefined, next: string): string;
export declare function appleHealthZipPolicy(): ZipReadPolicy;
export declare function findUploadedExportCandidate(importDir: string): string | null;
export interface ResolvedExportExtraction {
    readonly extractedFromZip: boolean;
    readonly path: string;
}
export type ResolvedExportOutcome = {
    readonly kind: "resolved";
    readonly resolved: ResolvedExportExtraction;
} | {
    readonly kind: "not_found";
} | {
    readonly kind: "extraction_failed";
    readonly message: string;
};
/**
 * Resolve the real, ready-to-stream `export.xml` path for one collect run,
 * given an owner-uploaded candidate (`.xml` used directly, `.zip`
 * extracted). Extraction writes to a SIBLING file next to the uploaded zip
 * (`<zip-dir>/.extracted-export.xml`) via {@link streamZipEntryToFile} —
 * never buffering the inflated XML in memory (a real export.xml can be
 * hundreds of MB to multiple GB; see that function's own doc comment for
 * why this matters). Extraction is CACHED: if the sibling file already
 * exists and is newer than the zip, re-extraction is skipped, so a second
 * `collect` run against the same uploaded zip (e.g. a later incremental
 * sync) does not re-pay the extraction cost every time.
 */
export declare function resolveUploadedExportPath(candidatePath: string): Promise<ResolvedExportOutcome>;
/** Matches export.xml at any depth inside a zip's central directory — used
 *  by validation to sniff for the entry without extracting it. */
export declare function isExportXmlEntryName(name: string): boolean;
export interface ExportXmlSummary {
    readonly earliestStartDate: string | null;
    readonly latestStartDate: string | null;
    readonly looksLikeHealthExport: boolean;
    readonly recordCount: number;
    readonly workoutCount: number;
}
/**
 * Stream-scan `path` (an export.xml, however it got there — direct upload
 * or already-extracted from a zip) to produce validation-preview stats
 * WITHOUT emitting or retaining individual records — mirrors index.ts's
 * streamParse loop (same tag regex, same chunk size) but accumulates only
 * counts and a min/max date range, so peak memory stays O(1) regardless of
 * export size, matching the collect-time streaming guarantee this connector
 * makes everywhere else.
 */
export declare function scanExportXmlSummary(path: string): Promise<ExportXmlSummary>;
//# sourceMappingURL=parsers.d.ts.map