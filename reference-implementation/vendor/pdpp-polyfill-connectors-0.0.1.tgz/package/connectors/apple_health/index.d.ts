#!/usr/bin/env node
export type ResolveExportPathResult = {
    readonly kind: "found";
    readonly path: string;
} | {
    readonly kind: "not_found";
} | {
    readonly kind: "extraction_failed";
    readonly message: string;
};
//# sourceMappingURL=index.d.ts.map