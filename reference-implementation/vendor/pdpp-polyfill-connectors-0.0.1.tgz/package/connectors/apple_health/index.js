#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * PDPP Apple Health Connector (v0.1.0)
 *
 * Auth: none (file-based). User goes to iPhone → Health app → profile →
 * "Export All Health Data", then either uploads the resulting .zip (or its
 * extracted export.xml) through the console's manual-upload flow, or
 * places it directly under APPLE_HEALTH_EXPORT_DIR (defaults
 * ~/.pdpp/imports/apple_health/) for local/developer use. This connector
 * streams the XML, so even multi-GB exports parse incrementally with low
 * memory — extraction of an uploaded .zip is likewise streamed straight to
 * disk (see parsers.ts's resolveUploadedExportPath), never buffered whole.
 */
import { createReadStream, existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { runConnector } from "../../src/connector-runtime.js";
import { APPLE_HEALTH_TAG_RE, advanceCursor, buildHealthRecord, buildWorkoutEvent, buildWorkoutRecord, findUploadedExportCandidate, isBeforeCursor, newGapCounts, parseAttrs, resolveUploadedExportPath, } from "./parsers.js";
import { validateRecord } from "./schemas.js";
// Streaming buffer size — 64 KB balances memory and syscalls on large exports.
const READ_BUFFER_SIZE = 65_536;
// Emit a PROGRESS every N events so operators see progress on multi-GB exports.
const PROGRESS_INTERVAL_EVENTS = 10_000;
/**
 * Resolve the export.xml to stream-parse this run, trying (in order):
 *   1. The legacy pre-extracted developer layout (`<dir>/export.xml` or
 *      `<dir>/apple_health_export/export.xml`) — unchanged from v0.1.0, so
 *      an existing developer setup keeps working exactly as before.
 *   2. An owner-uploaded artifact via the manual-upload console flow: a
 *      bare `.xml` used directly, or a `.zip` extracted once (streamed,
 *      cached — see resolveUploadedExportPath) to a sibling file.
 */
async function resolveExportPath(dir) {
    const direct = join(dir, "export.xml");
    if (existsSync(direct)) {
        return { kind: "found", path: direct };
    }
    const nested = join(dir, "apple_health_export", "export.xml");
    if (existsSync(nested)) {
        return { kind: "found", path: nested };
    }
    const candidate = findUploadedExportCandidate(dir);
    if (!candidate) {
        return { kind: "not_found" };
    }
    const outcome = await resolveUploadedExportPath(candidate);
    if (outcome.kind === "resolved") {
        return { kind: "found", path: outcome.resolved.path };
    }
    if (outcome.kind === "extraction_failed") {
        return { kind: "extraction_failed", message: outcome.message };
    }
    return { kind: "not_found" };
}
function newElement(tag, attrs) {
    return { tag, attrs, metadata: [], workoutEvents: [], workoutStatistics: [] };
}
/** Attach a nested MetadataEntry/WorkoutEvent/WorkoutStatistics child to whichever Record/Workout is currently open. WorkoutRoute (GPS geometry) is counted in `gaps`, not captured — no emitted field represents route data today. */
function attachChild(current, openTag, attrString, gaps) {
    if (openTag === "WorkoutRoute") {
        gaps.workoutRoutesUncaptured += 1;
        return;
    }
    const attrs = parseAttrs(attrString);
    if (openTag === "MetadataEntry" && attrs.key !== undefined) {
        current.metadata.push({ key: attrs.key, value: attrs.value ?? "" });
    }
    else if (openTag === "WorkoutEvent") {
        current.workoutEvents.push(buildWorkoutEvent(attrs));
    }
    else if (openTag === "WorkoutStatistics") {
        current.workoutStatistics.push(attrs);
    }
}
/** Close out `state.current` on its matching `</Record>`/`</Workout>`, emitting the assembled element. */
async function handleCloseTag(closeTag, state, onRecord, onWorkout) {
    if (!(state.current && state.current.tag === closeTag)) {
        return;
    }
    if (closeTag === "Record") {
        await onRecord(state.current);
        state.recordCount += 1;
    }
    else {
        await onWorkout(state.current);
        state.workoutCount += 1;
    }
    state.current = null;
}
/** Handle a Record/Workout open tag: emit immediately if self-closing, otherwise open a span for nested children. */
async function handleTopLevelOpenTag(openTag, attrs, selfClose, state, onRecord, onWorkout) {
    if (selfClose !== "/") {
        // Non-self-closing: children (MetadataEntry/WorkoutEvent/
        // WorkoutStatistics) arrive before the matching close tag.
        state.current = newElement(openTag, attrs);
        return;
    }
    if (openTag === "Record") {
        await onRecord(newElement("Record", attrs));
        state.recordCount += 1;
    }
    else {
        await onWorkout(newElement("Workout", attrs));
        state.workoutCount += 1;
    }
}
/** Handle one regex match against the running scan state, emitting a completed Record/Workout when its span closes. */
async function handleTagMatch(m, state, gaps, onRecord, onWorkout) {
    const [, openTag, attrString, selfClose, closeTag] = m;
    if (closeTag === "Record" || closeTag === "Workout") {
        await handleCloseTag(closeTag, state, onRecord, onWorkout);
        return;
    }
    if (openTag === "Record" || openTag === "Workout") {
        await handleTopLevelOpenTag(openTag, parseAttrs(attrString ?? ""), selfClose ?? "", state, onRecord, onWorkout);
        return;
    }
    if (state.current && openTag) {
        attachChild(state.current, openTag, attrString ?? "", gaps);
    }
}
/**
 * Streaming scanner: walks Record/Workout open tags, their nested
 * MetadataEntry/WorkoutEvent/WorkoutStatistics children, and the matching
 * close tags, in document order across chunk boundaries. Because the export
 * is scanned strictly in order, "currently open Record/Workout" is enough
 * context to attribute a nested child to its parent without building a DOM —
 * this keeps the parser streaming-safe on a 500MB export. Apple Health does
 * not nest Record inside Workout or vice versa, so a single current-element
 * slot (not a stack) is sufficient.
 */
async function streamParse({ path, onRecord, onWorkout, onProgress, gaps, }) {
    // Async iteration on a Readable pauses the stream between awaits, so we can
    // await async handlers without losing chunks. Older sync-callback form got
    // away with unawaited promises; we cannot.
    const stream = createReadStream(path, {
        encoding: "utf8",
        highWaterMark: READ_BUFFER_SIZE,
    });
    let buf = "";
    const state = { current: null, recordCount: 0, workoutCount: 0 };
    for await (const chunk of stream) {
        buf += typeof chunk === "string" ? chunk : chunk.toString("utf8");
        const re = new RegExp(APPLE_HEALTH_TAG_RE.source, "g");
        let m = re.exec(buf);
        let lastEnd = 0;
        while (m !== null) {
            await handleTagMatch(m, state, gaps, onRecord, onWorkout);
            lastEnd = re.lastIndex;
            m = re.exec(buf);
        }
        buf = buf.slice(lastEnd);
        const total = state.recordCount + state.workoutCount;
        if (total > 0 && total % PROGRESS_INTERVAL_EVENTS === 0) {
            await onProgress(state.recordCount, state.workoutCount);
        }
    }
    await onProgress(state.recordCount, state.workoutCount);
}
function handleRecord(el, ref, gaps, requested, emitRecord) {
    if (!requested.has("records")) {
        return Promise.resolve();
    }
    const rec = buildHealthRecord(el, gaps);
    if (!rec) {
        return Promise.resolve();
    }
    if (isBeforeCursor(rec.start_date, ref.since)) {
        return Promise.resolve();
    }
    ref.latest = advanceCursor(ref.latest, rec.start_date);
    return emitRecord("records", { ...rec });
}
function handleWorkout(el, ref, gaps, requested, emitRecord) {
    if (!requested.has("workouts")) {
        return Promise.resolve();
    }
    const rec = buildWorkoutRecord(el, gaps);
    if (!rec) {
        return Promise.resolve();
    }
    if (isBeforeCursor(rec.start_date, ref.since)) {
        return Promise.resolve();
    }
    ref.latest = advanceCursor(ref.latest, rec.start_date);
    return emitRecord("workouts", { ...rec });
}
/** Render the gap tally as a single human-readable progress line. Never silent — an empty tally still reports "no gaps". */
function formatGapSummary(gaps) {
    const parts = [];
    if (gaps.recordsMissingStartDate > 0) {
        parts.push(`records_dropped_missing_start_date=${gaps.recordsMissingStartDate}`);
    }
    if (gaps.workoutsMissingStartDate > 0) {
        parts.push(`workouts_dropped_missing_start_date=${gaps.workoutsMissingStartDate}`);
    }
    if (gaps.unrecognizedRecordTypes.size > 0) {
        const byType = [...gaps.unrecognizedRecordTypes.entries()]
            .map(([type, count]) => `${type}:${count}`)
            .join(",");
        parts.push(`unrecognized_record_types=${byType}`);
    }
    if (gaps.workoutRoutesUncaptured > 0) {
        parts.push(`workout_routes_uncaptured=${gaps.workoutRoutesUncaptured}`);
    }
    if (parts.length === 0) {
        return "Apple Health phase=emit pass=emit gaps=none";
    }
    return `Apple Health phase=emit pass=emit gaps: ${parts.join(" ")}`;
}
runConnector({
    name: "apple_health",
    validateRecord,
    async collect({ state, requested, emit, emitRecord, progress }) {
        const dir = process.env.APPLE_HEALTH_EXPORT_DIR ||
            join(homedir(), ".pdpp/imports/apple_health");
        const resolved = await resolveExportPath(dir);
        if (resolved.kind === "extraction_failed") {
            await emit({
                type: "SKIP_RESULT",
                stream: "records",
                reason: "export_extraction_failed",
                message: resolved.message,
            });
            return;
        }
        if (resolved.kind === "not_found") {
            await emit({
                type: "SKIP_RESULT",
                stream: "records",
                reason: "export_not_found",
                message: "Apple Health export data was not found in the configured import directory",
            });
            return;
        }
        const { path } = resolved;
        const recordsState = (state.records ?? {});
        const workoutsState = (state.workouts ?? {});
        const recordRef = {
            since: recordsState.last_start_date,
            latest: recordsState.last_start_date,
        };
        const workoutRef = {
            since: workoutsState.last_start_date,
            latest: workoutsState.last_start_date,
        };
        const gaps = newGapCounts();
        await progress("Apple Health phase=emit pass=emit starting stream parse");
        await streamParse({
            gaps,
            path,
            onProgress: (rc, wc) => progress(`Apple Health phase=emit pass=emit records_parsed=${rc} workouts_parsed=${wc}`),
            onRecord: (el) => handleRecord(el, recordRef, gaps, requested, emitRecord),
            onWorkout: (el) => handleWorkout(el, workoutRef, gaps, requested, emitRecord),
        });
        await progress(formatGapSummary(gaps));
        if (requested.has("records")) {
            await emit({
                type: "STATE",
                stream: "records",
                cursor: { last_start_date: recordRef.latest },
            });
        }
        if (requested.has("workouts")) {
            await emit({
                type: "STATE",
                stream: "workouts",
                cursor: { last_start_date: workoutRef.latest },
            });
        }
    },
});
