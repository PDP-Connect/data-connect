#!/usr/bin/env node
// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { createConnectorHttpGovernor } from "../../src/connector-http-governor.js";
import { buildDetailCoverageMessage, politeDelay, runConnector, } from "../../src/connector-runtime.js";
import { notionPacingProfile } from "../../src/provider-profile.js";
import { validateRecord } from "./schemas.js";
// Single per-provider send governor + retry layer. `maxAttempts: 1` keeps the
// 429 throw byte-identical (cross-run cooldown via `retryablePattern`).
// §3 ProviderProfile: notion declares its own AUDITED pacing ceiling (500ms ≈
// 2 req/s, ~67% of Notion's documented 3 req/s average; WI-1b). NOT a borrow of
// ChatGPT's 250ms. See src/provider-profile.ts → notionPacingProfile and
// docs/research/per-connector-rate-profiles-2026-06-13.md for the derivation.
const httpGovernor = createConnectorHttpGovernor({
    name: "notion",
    maxAttempts: 1,
    profile: notionPacingProfile(),
});
const API = "https://api.notion.com/v1";
const NOTION_VERSION = "2022-06-28";
const PAGE_SIZE = 100;
const POLITE_DELAY_MS = 400;
async function ntn(path, token, body, progress, extra) {
    let raw;
    try {
        const r = await httpGovernor.request(async () => {
            const res = await fetch(`${API}${path}`, {
                method: "POST",
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Notion-Version": NOTION_VERSION,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(body),
            });
            const retryAfter = res.headers.get("retry-after");
            return {
                body: await res.text().catch(() => ""),
                ...(retryAfter === null
                    ? {}
                    : { headers: { "retry-after": retryAfter } }),
                status: res.status,
            };
        }, (resp) => ({ status: resp.status, value: resp }));
        raw = r.value;
    }
    catch (error) {
        if (error instanceof Error && error.message === "notion_rate_limited") {
            await progress?.("Notion search rate limited", {
                ...extra,
                phase: "rate_limit",
                rate_limit_pressure: 1,
            });
        }
        throw error;
    }
    if (raw.status === 401) {
        throw new Error("notion_auth_failed");
    }
    if (raw.status < 200 || raw.status >= 300) {
        throw new Error(`notion_http_${String(raw.status)}: ${raw.body.slice(0, 200)}`);
    }
    return JSON.parse(raw.body);
}
function extractTitle(obj) {
    // Pages: properties[*].title[].plain_text   Databases: title[].plain_text
    if (obj.properties) {
        for (const p of Object.values(obj.properties)) {
            if (p?.type === "title" && Array.isArray(p.title)) {
                return p.title.map((t) => t.plain_text || "").join("") || null;
            }
        }
    }
    if (Array.isArray(obj.title)) {
        return obj.title.map((t) => t.plain_text || "").join("") || null;
    }
    return null;
}
function parentId(parent) {
    if (!parent) {
        return null;
    }
    if (parent.page_id) {
        return parent.page_id;
    }
    if (parent.database_id) {
        return parent.database_id;
    }
    if (parent.workspace) {
        return typeof parent.workspace === "string" ? parent.workspace : null;
    }
    return null;
}
async function searchAll(token, filter, progress, streamName) {
    const results = [];
    let cursor;
    let pageIndex = 0;
    for (;;) {
        const body = {
            sort: { direction: "descending", timestamp: "last_edited_time" },
            page_size: PAGE_SIZE,
        };
        if (filter) {
            body.filter = filter;
        }
        if (cursor) {
            body.start_cursor = cursor;
        }
        const pageExtra = {
            stream: streamName,
            phase: "fetch",
            page_index: pageIndex,
            total_seen: results.length,
            cursor_present: Boolean(cursor),
        };
        await progress("Fetching Notion search page", pageExtra);
        const json = await ntn("/search", token, body, progress, pageExtra);
        results.push(...(json.results || []));
        await progress("Fetched Notion search page", {
            stream: streamName,
            phase: "page",
            page_index: pageIndex,
            item_count: json.results?.length ?? 0,
            total_seen: results.length,
            cursor_present: Boolean(json.has_more && json.next_cursor),
        });
        if (json.has_more !== true) {
            break;
        }
        // `has_more` is the provider's claim that another page exists. A missing
        // cursor contradicts that claim, so stopping here would silently hide the
        // unfetched tail and let runStream advance its edit-time watermark past
        // data this run never enumerated.
        const nextCursor = json.next_cursor;
        if (typeof nextCursor !== "string" || nextCursor.trim().length === 0) {
            throw new Error("notion_pagination_contradiction");
        }
        cursor = nextCursor;
        pageIndex += 1;
        await politeDelay(POLITE_DELAY_MS);
    }
    return results;
}
function toPageRecord(p) {
    return {
        id: p.id,
        object: p.object,
        parent_type: p.parent?.type ?? null,
        parent_id: parentId(p.parent),
        title: extractTitle(p),
        url: p.url ?? null,
        archived: p.archived ?? null,
        created_time: p.created_time ?? null,
        last_edited_time: p.last_edited_time ?? null,
        created_by_id: p.created_by?.id ?? null,
        last_edited_by_id: p.last_edited_by?.id ?? null,
    };
}
function toDatabaseRecord(d) {
    return {
        id: d.id,
        title: extractTitle(d),
        parent_type: d.parent?.type ?? null,
        parent_id: parentId(d.parent),
        url: d.url ?? null,
        archived: d.archived ?? null,
        created_time: d.created_time ?? null,
        last_edited_time: d.last_edited_time ?? null,
        property_names: d.properties ? Object.keys(d.properties) : [],
    };
}
async function runStream(args) {
    const { streamName, filter, toRecord, state, token, emit, emitRecord, progress, } = args;
    await progress(`Searching ${streamName}`, {
        stream: streamName,
        phase: "start",
    });
    const items = await searchAll(token, filter, progress, streamName);
    const streamState = state[streamName];
    const prior = streamState?.last_edited_time;
    let latest = prior;
    // Rows this run objectively accounted for — emitted-and-valid, or correctly
    // suppressed as unchanged. NEVER aliased to `items.length`: the schema is
    // strict (title ≤ 4000 chars, url ≤ 4096, safe-text), so a real page CAN be
    // rejected, and a rejected page must not be claimed as covered just because
    // it was enumerated. Tallied from the same `validateRecord` verdict the
    // runtime's emitRecord applies.
    let covered = 0;
    for (const item of items) {
        if (prior && item.last_edited_time && item.last_edited_time <= prior) {
            // Suppressed-unchanged: an earlier run's identical content already passed
            // the real emitRecord shape-check, so this is genuinely accounted for.
            covered += 1;
            continue;
        }
        const record = toRecord(item);
        if (validateRecord(streamName, record).ok) {
            covered += 1;
        }
        await emitRecord(streamName, record);
        if (item.last_edited_time && (!latest || item.last_edited_time > latest)) {
            latest = item.last_edited_time;
        }
    }
    await progress(`Emitted ${streamName}`, {
        stream: streamName,
        phase: "emit",
        item_count: items.length,
        total_seen: items.length,
        cursor_present: Boolean(latest || prior),
    });
    // The search result is the complete enumeration boundary for this stream.
    // Emit measured full-scan evidence even when it is empty; record counts alone
    // cannot distinguish a verified empty workspace from missing coverage proof.
    //
    // `considered` is that boundary (`items.length`, measured at the enumeration
    // site); `covered` is the independently tallied count above, so a page the
    // schema rejected reads a real `partial` instead of being silently absorbed.
    // `buildFullScanCoverageMessage` is deliberately NOT used: it forces
    // `covered === considered`, which cannot express a dropped page.
    //
    // Deletion-safe by construction: Notion reports a deleted page IN-BAND as
    // `archived: true` rather than omitting it, so a deletion stays inside the
    // boundary, is validated like any other row, and counts as covered. The
    // runtime turns it into a tombstone (`isTombstone`, below). An upstream
    // deletion is therefore a covered fact, never a coverage gap — which is what
    // keeps this proof from firing on PDPP's deliberate retention of records the
    // provider has since removed.
    await emit(buildDetailCoverageMessage({
        stream: streamName,
        stateStream: streamName,
        requiredKeys: [],
        hydratedKeys: [],
        considered: items.length,
        covered,
    }));
    await emit({
        type: "STATE",
        stream: streamName,
        cursor: { last_edited_time: latest || prior || null },
    });
}
runConnector({
    name: "notion",
    validateRecord,
    retryablePattern: /ECONN|fetch failed|rate_limited/i,
    auth: { kind: "env", required: ["NOTION_API_TOKEN"] },
    // Notion marks deleted items with archived=true rather than omitting them.
    isTombstone: (_stream, d) => d.archived === true,
    async collect({ state, requested, credentials, emit, emitRecord, progress }) {
        const token = credentials.NOTION_API_TOKEN;
        if (!token) {
            throw new Error("notion_auth_failed");
        }
        if (requested.has("pages")) {
            await runStream({
                streamName: "pages",
                filter: { property: "object", value: "page" },
                toRecord: toPageRecord,
                state,
                token,
                emit,
                emitRecord,
                progress,
            });
        }
        if (requested.has("databases")) {
            await runStream({
                streamName: "databases",
                filter: { property: "object", value: "database" },
                toRecord: toDatabaseRecord,
                state,
                token,
                emit,
                emitRecord,
                progress,
            });
        }
    },
});
