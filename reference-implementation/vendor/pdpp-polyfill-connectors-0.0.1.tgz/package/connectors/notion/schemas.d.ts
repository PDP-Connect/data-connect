import { z } from "zod";
/**
 * pages stream: one record per Notion page object.
 * Cursor: last_edited_time (descending search).
 */
export declare const pagesSchema: z.ZodObject<{
    id: z.ZodString;
    object: z.ZodNullable<z.ZodString>;
    parent_type: z.ZodNullable<z.ZodString>;
    parent_id: z.ZodNullable<z.ZodString>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    url: z.ZodNullable<z.ZodURL>;
    archived: z.ZodNullable<z.ZodBoolean>;
    created_time: z.ZodNullable<z.ZodString>;
    last_edited_time: z.ZodNullable<z.ZodString>;
    created_by_id: z.ZodNullable<z.ZodString>;
    last_edited_by_id: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * databases stream: one record per Notion database object.
 * `property_names` is the list of column names (Object.keys(properties));
 * each column name is free-form human text.
 */
export declare const databasesSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    parent_type: z.ZodNullable<z.ZodString>;
    parent_id: z.ZodNullable<z.ZodString>;
    url: z.ZodNullable<z.ZodURL>;
    archived: z.ZodNullable<z.ZodBoolean>;
    created_time: z.ZodNullable<z.ZodString>;
    last_edited_time: z.ZodNullable<z.ZodString>;
    property_names: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map