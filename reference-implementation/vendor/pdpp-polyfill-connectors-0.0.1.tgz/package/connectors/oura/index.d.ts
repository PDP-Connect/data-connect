#!/usr/bin/env node
import { type ConnectorHttpGovernor } from "../../src/connector-http-governor.ts";
import { type CollectContext } from "../../src/connector-runtime.ts";
/** Governor the walk actually sends through. Production always uses the paced
 *  module-level one; a test may substitute an unpaced governor so a two-page
 *  fixture does not have to wait out the real rate ceiling. The ceiling itself
 *  stays covered by `ouraPacingProfile()`'s own tests. */
type OuraHttpGovernor = Pick<ConnectorHttpGovernor, "request">;
export interface OuraCollectOptions {
    /** @see OuraHttpGovernor */
    readonly httpGovernor?: OuraHttpGovernor;
    /** Page ceiling actually enforced by each stream's walk. Injectable so a
     *  test can reach the capped exit with a two-page fixture. */
    readonly maxPages?: number;
}
export declare function collectOura(ctx: CollectContext, options?: OuraCollectOptions): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map