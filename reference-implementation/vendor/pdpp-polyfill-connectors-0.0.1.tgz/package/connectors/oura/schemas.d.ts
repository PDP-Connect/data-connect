/**
 * Zod schemas for Oura stream records. Shape-check-before-emit per
 * docs/reference/connector-authoring-guide.md §3.
 *
 * Ground truth: the `sleepRecord` / `readinessRecord` / `activityRecord`
 * builders in index.ts. Schemas mirror the *emitted* shape:
 *
 *   - `id` is the Oura document id — a UUID returned by the v2 API. Required
 *     (the builder reads `s.id` unconditionally).
 *   - `day` is the calendar date the document belongs to (`YYYY-MM-DD`); it is
 *     the cursor field, always present.
 *   - `bedtime_start` / `bedtime_end` are ISO-8601 datetimes (with offset) or
 *     null.
 *   - All physiological metrics are nullable numbers. They are NOT constrained
 *     to integers: Oura returns floats for HRV, efficiency, temperature deltas,
 *     and walking-equivalent distance, and the builder passes them through
 *     unchanged. Durations/steps/calories happen to arrive as integers but are
 *     left as `z.number()` to follow the passthrough rather than over-constrain.
 *   - `contributors` (readiness) is the raw Oura contributors object, an opaque
 *     provider map the builder forwards verbatim (`r.contributors ?? {}`). It
 *     is genuinely opaque key→score data, so it is typed as a record of
 *     numbers/nulls rather than enumerated — see note on the schema.
 *
 * No free-form human text fields exist on any Oura stream, so this module has
 * no `pdppSafeText` usage; every string is structurally constrained (UUID /
 * date / datetime).
 */
import { z } from "zod";
/**
 * sleep stream: one record per nightly sleep session.
 * Cursor: day.
 */
export declare const sleepSchema: z.ZodObject<{
    id: z.ZodString;
    day: z.ZodString;
    bedtime_start: z.ZodNullable<z.ZodString>;
    bedtime_end: z.ZodNullable<z.ZodString>;
    total_sleep_duration: z.ZodNullable<z.ZodNumber>;
    rem_sleep_duration: z.ZodNullable<z.ZodNumber>;
    deep_sleep_duration: z.ZodNullable<z.ZodNumber>;
    light_sleep_duration: z.ZodNullable<z.ZodNumber>;
    efficiency: z.ZodNullable<z.ZodNumber>;
    latency: z.ZodNullable<z.ZodNumber>;
    average_heart_rate: z.ZodNullable<z.ZodNumber>;
    lowest_heart_rate: z.ZodNullable<z.ZodNumber>;
    average_hrv: z.ZodNullable<z.ZodNumber>;
    temperature_delta: z.ZodNullable<z.ZodNumber>;
    sleep_score: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * readiness stream: one record per daily readiness document.
 * `contributors` is Oura's opaque contributors map (key → 0-100 sub-score).
 * The builder forwards it verbatim; we constrain values to nullable numbers
 * (their documented shape) without enumerating keys, since Oura adds/renames
 * contributors across firmware versions.
 */
export declare const readinessSchema: z.ZodObject<{
    id: z.ZodString;
    day: z.ZodString;
    score: z.ZodNullable<z.ZodNumber>;
    temperature_deviation: z.ZodNullable<z.ZodNumber>;
    temperature_trend_deviation: z.ZodNullable<z.ZodNumber>;
    contributors: z.ZodRecord<z.ZodString, z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>;
/**
 * activity stream: one record per daily activity document.
 * Cursor: day.
 */
export declare const activitySchema: z.ZodObject<{
    id: z.ZodString;
    day: z.ZodString;
    score: z.ZodNullable<z.ZodNumber>;
    active_calories: z.ZodNullable<z.ZodNumber>;
    total_calories: z.ZodNullable<z.ZodNumber>;
    steps: z.ZodNullable<z.ZodNumber>;
    target_calories: z.ZodNullable<z.ZodNumber>;
    equivalent_walking_distance: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map