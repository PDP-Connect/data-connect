#!/usr/bin/env node
import { type CollectContext } from "../../src/connector-runtime.ts";
export interface SpotifyPlaylist {
    collaborative?: boolean | null;
    description?: string | null;
    id: string;
    items?: {
        total?: number | null;
    };
    name?: string;
    owner?: {
        id?: string;
        display_name?: string;
    };
    public?: boolean | null;
    snapshot_id?: string | null;
    tracks?: {
        total?: number | null;
    };
}
/**
 * Spotify's `after` filter is strictly exclusive. Replaying the one-ms
 * boundary keeps same-timestamp plays recoverable; the composite record id
 * makes that replay idempotent at the runtime boundary.
 */
export declare function recentlyPlayedAfterCursor(lastPlayedAtUnix: number | undefined): number | undefined;
/**
 * Normalize Spotify's absolute `next` URL to the path accepted by `sp` while
 * rejecting cross-origin or no-progress links before another request is made.
 */
export declare function spotifyNextPath(next: string | null | undefined, currentPath: string): string | null;
export interface SpotifyCycleDetectorState {
    lambda: bigint;
    power: bigint;
    tortoise: string;
}
/**
 * Brent's online cycle detector for normalized cursor paths. It consumes each
 * observed path once and retains only fixed-size detector state.
 */
export declare function createSpotifyCycleDetector(initialPath: string): {
    observe: (path: string) => boolean;
    state: () => SpotifyCycleDetectorState;
};
export declare function spotifyPlaylistRecord(p: SpotifyPlaylist): Record<string, unknown>;
export declare function spotifyCollect({ state, requested, credentials, emit, emitRecord, progress, }: Pick<CollectContext, "state" | "requested" | "credentials" | "emit" | "emitRecord" | "progress">): Promise<void>;
//# sourceMappingURL=index.d.ts.map