import { z } from "zod";
/**
 * playlists stream: one record per playlist the user owns/follows.
 * No incremental cursor (full list each run).
 */
export declare const playlistsSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    owner_id: z.ZodNullable<z.ZodString>;
    owner_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    public: z.ZodNullable<z.ZodBoolean>;
    collaborative: z.ZodNullable<z.ZodBoolean>;
    track_count: z.ZodNullable<z.ZodNumber>;
    snapshot_id: z.ZodNullable<z.ZodString>;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
/**
 * saved_tracks stream: one record per "liked" track.
 * Cursor: added_at.
 */
export declare const savedTracksSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    artist_names: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    album_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    duration_ms: z.ZodNullable<z.ZodNumber>;
    popularity: z.ZodNullable<z.ZodNumber>;
    added_at: z.ZodString;
    isrc: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * top_artists stream: one record per top artist, per time window.
 */
export declare const topArtistsSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    genres: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    popularity: z.ZodNullable<z.ZodNumber>;
    followers: z.ZodNullable<z.ZodNumber>;
    time_range: z.ZodEnum<{
        long_term: "long_term";
        medium_term: "medium_term";
        short_term: "short_term";
    }>;
}, z.core.$strip>;
/**
 * recently_played stream: one record per play-history entry.
 * Cursor: played_at (epoch ms). `id` is the composite track:ms key.
 */
export declare const recentlyPlayedSchema: z.ZodObject<{
    id: z.ZodString;
    track_id: z.ZodOptional<z.ZodString>;
    track_name: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    artist_names: z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    album_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    played_at: z.ZodString;
    context_type: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map