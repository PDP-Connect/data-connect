import type { DirectHistoryDateOrder, ViewingActivityCSVRow, ViewingActivityRecord, ViewingActivitySourceSchema } from "./types.ts";
export declare function hashId(s: string): string;
/**
 * Parse a CSV file with proper quote and newline handling.
 * Supports RFC 4180 CSV format: quoted fields may contain commas and newlines,
 * escaped quotes are doubled ("").
 */
export declare function parseCSVLine(line: string, headers: string[]): Record<string, string | undefined>;
/**
 * Validate that a file path is within expectedDir and not a symlink escape.
 * Resolves both paths to absolute, checks containment, rejects symlinks.
 */
export declare function validateArchivePath(filePath: string, expectedDir: string): {
    ok: boolean;
    error?: string;
};
export declare function parseCSVFile(filePath: string): Promise<{
    headers: string[];
    rows: Record<string, string | undefined>[];
    malformedCount: number;
    error?: string;
}>;
export declare function parseCSVContentForValidation(content: string): {
    headers: string[];
    rows: Record<string, string | undefined>[];
    malformedCount: number;
    error?: string;
};
/**
 * Detect which of Netflix's two distinct CSV schemas a parsed header row
 * matches. Headers are matched by normalized substring (Netflix appends unit
 * suffixes like "(UTC)"/"(H:MM:SS)" that we don't want to hard-code exact
 * matches against), and BOTH schemas' full header sets must be present — a
 * header row that's neither, or a mix of both, is rejected as unrecognized
 * rather than guessed at.
 */
export declare function detectViewingActivitySchema(headers: string[]): ViewingActivitySourceSchema | null;
/**
 * Infer direct_history's date field ordering (DD/MM vs MM/DD — Netflix's own
 * help center documents the immediate CSV but not its date encoding, so this
 * is never assumed) from the dataset as a whole: scan every row's Date value
 * for the first one that is unambiguous on its own (day or month > 12), and
 * apply that SAME ordering to the entire file. This is a per-upload
 * inference, not a per-row guess — a file mixing "15/03/2024" (unambiguous:
 * DMY) and "05/03/2024" (ambiguous alone) resolves the ambiguous row using
 * the order the unambiguous row already proved for this dataset.
 *
 * Returns null only when every non-ISO row in the dataset is itself
 * ambiguous (no row has a field > 12) — callers must treat that as a real,
 * actionable gap (surface a typed coverage-gap / validation outcome asking
 * the owner to clarify date order), never silently guess or drop rows.
 */
export declare function inferDirectHistoryDateOrder(dateStrings: readonly (string | undefined)[]): DirectHistoryDateOrder | null;
/**
 * Convenience wrapper over inferDirectHistoryDateOrder for a batch of parsed
 * CSV rows (what index.ts/validation.ts actually have on hand).
 */
export declare function inferDirectHistoryDateOrderFromRows(rows: readonly ViewingActivityCSVRow[]): DirectHistoryDateOrder | null;
/**
 * Parse a direct_history "Date" value into a calendar day, applying a
 * dataset-inferred `order` (see inferDirectHistoryDateOrder) for
 * non-ISO/ambiguous-alone rows. ISO (YYYY-MM-DD) always parses regardless of
 * order — it has no field-order ambiguity. When `order` is null (the whole
 * dataset was ambiguous) and this row itself is ambiguous, returns null
 * rather than guessing.
 */
export declare function parseDirectHistoryDate(dateStr: string | undefined, order?: DirectHistoryDateOrder | null): string | null;
/**
 * Parse full_export's "Start Time (UTC)" — Netflix documents this column as
 * already UTC, so no timezone conversion is applied; only ISO-8601-parseable
 * forms are accepted (YYYY-MM-DD or YYYY-MM-DD HH:MM:SS).
 */
export declare function parseFullExportStartTime(tsStr: string | undefined): string | null;
/**
 * Parse full_export's "Duration (H:MM:SS)" into whole seconds. Returns null
 * for anything that doesn't match the documented H:MM:SS shape — no percent
 * or fractional-guessing, since Netflix's own column is already a duration,
 * not a completion percentage (the prior watch_duration_percent field was a
 * fabricated shape not grounded in either real Netflix CSV schema).
 */
export declare function parseFullExportDurationSeconds(durationStr: string | undefined): number | null;
/**
 * Build a viewing_activity record from a CSV row, dispatching on the
 * detected schema. Returns null for rows that don't carry a parseable
 * date/timestamp for their schema — caller is responsible for the
 * since-cursor filter. `dateOrder` is required for direct_history: the
 * dataset-inferred DD/MM-vs-MM/DD ordering (see inferDirectHistoryDateOrder),
 * applied consistently to every ambiguous row in the file rather than
 * guessed per row. Ignored for full_export (its Start Time (UTC) column has
 * no field-order ambiguity).
 */
export declare function buildViewingActivityRecord(row: ViewingActivityCSVRow, schema: ViewingActivitySourceSchema, dateOrder?: DirectHistoryDateOrder | null): ViewingActivityRecord | null;
/**
 * Resolve the ViewingActivity.csv file path within an extracted Netflix export archive.
 * Validates path containment and rejects symlink escapes.
 */
export declare function resolveViewingActivityFile(importDir: string): {
    path: string | null;
    error?: string | undefined;
};
/**
 * Search for and list all ViewingActivity.csv files in an import directory tree.
 * Used for archive traversal validation and diagnostics.
 */
export declare function findViewingActivityFiles(importDir: string): string[];
export type NetflixExportArtifactFormat = "viewing_activity_csv" | "viewing_activity_zip";
export interface ExtractedNetflixExportArtifact {
    csvText: string;
    format: NetflixExportArtifactFormat;
    sourceEntryName: string;
}
/**
 * Why an artifact extraction failed, distinguishing "this archive is too
 * large to safely process" (a real, valid Netflix export the owner should be
 * told to shrink or use a fallback for) from "this isn't a recognizable
 * Netflix export at all" (corrupt, wrong file type, or missing
 * ViewingActivity.csv). Callers (validation.ts, index.ts) MUST preserve this
 * distinction in what they report — collapsing both into one generic
 * "unsupported" status hides an actionable, honest signal from the owner.
 */
export type NetflixExportExtractionFailureCode = "entry_too_large" | "no_viewing_activity_entry" | "too_many_entries" | "total_too_large" | "unsafe_entry_name" | "unsupported_shape";
export interface NetflixExportExtractionFailure {
    readonly code: NetflixExportExtractionFailureCode;
    readonly message: string;
}
export type NetflixExportExtractionResult = ({
    ok: true;
} & ExtractedNetflixExportArtifact) | ({
    ok: false;
} & NetflixExportExtractionFailure);
/**
 * Extract ViewingActivity.csv text from an uploaded artifact: either the CSV
 * file directly, or Netflix's official export zip. Returns a discriminated
 * result rather than null so callers can distinguish an oversized-but-real
 * export (`entry_too_large`/`total_too_large`/`too_many_entries` — a
 * decompression-bomb-policy rejection) from a genuinely unrecognized/corrupt
 * artifact (`unsupported_shape`/`no_viewing_activity_entry`).
 *
 * `input` must already be fully buffered in memory. For an artifact that
 * already exists as a file on disk (the manual-upload staging case), use
 * {@link extractViewingActivityArtifactFromFile} instead, which reads the
 * zip archive from a file descriptor without ever materializing it as one
 * in-memory buffer.
 */
export declare function extractViewingActivityArtifact(filename: string, input: Buffer | Uint8Array | string): NetflixExportExtractionResult;
/**
 * File-backed variant of {@link extractViewingActivityArtifact}. `fd` is
 * caller-owned: this function neither opens nor closes it.
 *
 * IMPORTANT — this is bounded-memory ONLY for the .zip branch: it reads via
 * {@link readZipEntriesFromFile}, so a zip archive's central directory is
 * read as one small window and each entry's compressed bytes only when that
 * entry's `data()` is called — the archive's full bytes are never
 * materialized as a single in-memory buffer, mirroring the WhatsApp
 * connector's already-proven file-backed path.
 *
 * The .csv branch is NOT streaming: it still reads the whole file into one
 * buffer (`readSync` in place of the old `readFile`), because the CSV
 * parser this connector shares with the legacy-directory path
 * (parseCSVContentForValidation) consumes a complete string, not a stream —
 * and this module's own "bounded" reader for that path
 * (`readFileBounded`, used by {@link parseCSVFile}) is ALSO not
 * bounded-memory in the peak-RSS sense: it just accumulates the same whole
 * string incrementally via repeated `content +=`, which is no better (worse,
 * due to string-concat reallocation) than one read + one `toString`. There
 * is no existing streaming CSV boundary in this codebase to reuse without
 * writing a second parser, so the CSV branch is left explicitly unbounded
 * here, same as before this change — it is capped at MAX_CSV_BYTES (50 MiB),
 * which keeps the memory cost proportionate even though it is not
 * structurally bounded the way the zip branch now is.
 */
export declare function extractViewingActivityArtifactFromFile(fd: number, fileSize: number, filename: string): NetflixExportExtractionResult;
//# sourceMappingURL=parsers.d.ts.map