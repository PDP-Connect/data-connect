import { z } from "zod";
/**
 * viewing_activity: one entry per Netflix viewing session.
 * Cursor: watched_at (ISO).
 */
export declare const viewingActivitySchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    watched_at: z.ZodString;
    watched_at_precision: z.ZodEnum<{
        day: "day";
        instant: "instant";
    }>;
    watched_at_raw: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    device_type: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    duration_seconds: z.ZodNullable<z.ZodNumber>;
    profile_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    country: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    source_schema: z.ZodEnum<{
        direct_history: "direct_history";
        full_export: "full_export";
    }>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for the streams this
 * connector emits.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map