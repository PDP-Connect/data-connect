#!/usr/bin/env node
import type { Page } from "playwright";
import { type BrowserCollectContext } from "../../src/connector-runtime.ts";
import type { VenmoStory, VenmoUser } from "./types.ts";
export declare const MAX_FRIENDS_PAGES = 200;
export declare const MAX_TRANSACTION_PAGES = 400;
/**
 * `venmo_transport_error` (collect()'s page-fetch, see `makePageFetch` below)
 * and `venmo_probe_transport_error` (ensureSession's PRE-submit session
 * probe, see `src/auto-login/venmo.ts`) are the browser fetch's own "could
 * not run at all" fault (opaque origin, DNS, TLS, reset socket) —
 * deliberately retryable, distinct from `venmo_session_expired`. Every
 * transport-fault throw in this connector is always wrapped in one of these
 * named errors before it can reach the runtime's retryablePattern check —
 * nothing unwrapped escapes either module's own try/catch — so this pattern
 * names the two retryable errors EXACTLY rather than also matching bare
 * transport vocabulary (`fetch failed`/`ECONN`/etc.) as a redundant, and
 * here actively dangerous, catch-all.
 *
 * B4: that redundant bare-vocabulary form is what this pattern used to be
 * (`venmo_.*transport_error` plus `fetch failed|failed to fetch`), and it
 * silently made a THIRD, deliberately similarly-named error retryable too:
 * `probeVenmoAccount` throws `venmo_post_submit_probe_transport_error` for a
 * transport fault discovered immediately after a saved password was
 * submitted to Venmo's own sign-in form, and that message still CONTAINS
 * "Failed to fetch" (the redacted detail) even though its NAME must not
 * retry. A wildcard/bare-vocabulary pattern classified it retryable anyway
 * via the message text, and a runtime-level retry re-enters
 * `ensureVenmoSession` from scratch — resubmitting the SAME saved password
 * against Venmo's anti-automation gate on every retry, with no run-scoped
 * budget to stop it (see `src/auto-login/venmo.test.ts`'s "B4" oracle).
 * Naming exactly the two errors that must retry — and nothing else — is the
 * only form immune to a future transport-detail string reintroducing this
 * exact collision. Exported so both this connector's own tests and
 * `src/auto-login/venmo.test.ts` assert against the REAL pattern, not a
 * hand-copied stand-in that could silently drift from it.
 */
export declare const VENMO_RETRYABLE_PATTERN: RegExp;
interface VenmoProgressExtra {
    cursor_present?: boolean;
    item_count?: number;
    offset_ordinal?: number;
    phase?: string;
    stream?: string;
    total_seen?: number;
}
type VenmoProgress = (message: string, extra?: VenmoProgressExtra) => Promise<void>;
interface VenmoPageFetchResult {
    body: string;
    status: number;
}
/**
 * Fetch a Venmo JSON endpoint through the live page's own session cookie
 * (`credentials: "include"`) — no Authorization header, no device-id, no
 * custom User-Agent. This is the entire auth surface: the browser IS the
 * credential.
 */
export type VenmoPageFetch = (path: string, query?: Record<string, string>) => Promise<VenmoPageFetchResult>;
/**
 * `collect()`'s own call to `ensureVenmoOrigin`, extracted so it is
 * unit-testable without a real Playwright `page` (mirrors `errorDetail`/
 * `assertVenmoOk` below, both pulled out of the fetch loop for the same
 * reason). `ensureVenmoOrigin` now throws `venmo_origin_navigation_failed`
 * when the one-time navigation doesn't land on venmo.com (see its doc —
 * production run_1787101857760, the owner's first-ever Venmo run). Folded
 * into this connector's own `venmo_transport_error` naming so it matches
 * `VENMO_RETRYABLE_PATTERN` the same way any other transport fault in this
 * file's fetch loop already does, rather than escaping `collect()` as an
 * unrecognized, non-retryable name.
 */
export declare function establishVenmoCollectOrigin(page: Page): Promise<void>;
export declare function errorDetail(body: string): string;
export declare function fetchProfile(fetchPath: VenmoPageFetch): Promise<VenmoUser | null>;
export declare function fetchAllFriends(fetchPath: VenmoPageFetch, ownerId: string, progress: VenmoProgress, delay?: (ms: number) => Promise<void>): Promise<{
    friends: VenmoUser[];
    truncated: boolean;
}>;
export declare function fetchTransactionsPage(fetchPath: VenmoPageFetch, ownerId: string, beforeId: string | undefined): Promise<VenmoStory[]>;
export declare function collectTransactions(ctx: BrowserCollectContext, fetchPath: VenmoPageFetch, ownerId: string, delay?: (ms: number) => Promise<void>): Promise<{
    considered: number;
    covered: number;
    latestSeenAt: string | null;
    truncated: boolean;
}>;
/** Exported for integration tests — the full collect() body against an injected page fetch. */
export declare function collectAllStreams(ctx: BrowserCollectContext, fetchPath: VenmoPageFetch, ownerId: string, account: VenmoUser | null, delay?: (ms: number) => Promise<void>): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map