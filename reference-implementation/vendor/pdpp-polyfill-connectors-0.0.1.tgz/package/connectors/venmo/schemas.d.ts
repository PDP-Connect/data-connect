import { z } from "zod";
export declare const profileSchema: z.ZodObject<{
    id: z.ZodString;
    username: z.ZodNullable<z.ZodString>;
    first_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    last_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    phone: z.ZodNullable<z.ZodString>;
    profile_picture_url: z.ZodNullable<z.ZodString>;
    about: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    date_joined: z.ZodNullable<z.ZodString>;
    is_business: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
export declare const friendsSchema: z.ZodObject<{
    id: z.ZodString;
    username: z.ZodNullable<z.ZodString>;
    first_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    last_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    phone: z.ZodNullable<z.ZodString>;
    profile_picture_url: z.ZodNullable<z.ZodString>;
    about: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    date_joined: z.ZodNullable<z.ZodString>;
    is_group: z.ZodNullable<z.ZodBoolean>;
    is_active: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
export declare const transactionsSchema: z.ZodObject<{
    id: z.ZodString;
    payment_id: z.ZodNullable<z.ZodString>;
    date_created: z.ZodString;
    date_updated: z.ZodNullable<z.ZodString>;
    date_completed: z.ZodNullable<z.ZodString>;
    payment_type: z.ZodEnum<{
        charge: "charge";
        pay: "pay";
    }>;
    amount_cents: z.ZodNumber;
    audience: z.ZodNullable<z.ZodEnum<{
        friends: "friends";
        private: "private";
        public: "public";
    }>>;
    status: z.ZodNullable<z.ZodEnum<{
        cancelled: "cancelled";
        expired: "expired";
        failed: "failed";
        pending: "pending";
        settled: "settled";
    }>>;
    note: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    device_used: z.ZodNullable<z.ZodString>;
    actor: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        username: z.ZodNullable<z.ZodString>;
        display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>;
    target: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        username: z.ZodNullable<z.ZodString>;
        display_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>;
    is_owner_actor: z.ZodBoolean;
}, z.core.$strip>;
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map