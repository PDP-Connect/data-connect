import type { RecordData } from "../../src/connector-runtime.ts";
import type { VenmoStory, VenmoUser } from "./types.ts";
export declare const API_BASE = "https://api.venmo.com/v1";
/** Venmo's `amount` is a float in major units (dollars); PDPP records integer cents. */
export declare function dollarsToCents(amount: number | null | undefined): number;
export declare function userRecord(u: VenmoUser): RecordData;
export declare function profileRecord(u: VenmoUser): RecordData;
/**
 * Transaction ("story") record. `ownerId` is the authenticated profile's own
 * id, used only to derive `is_owner_actor` — never persisted as a foreign
 * concept in the schema beyond that one boolean.
 *
 * Returns `null` for story types this connector does not model (refunds,
 * bank transfers, top-ups, card authorizations/withdrawals, disbursements —
 * see venmo_api/models/transaction.py's TransactionType enum). Those never
 * carry a `payment` object in the documented shape, so they cannot be
 * represented by this schema without inventing fields; skipping them is
 * honest non-support, not data loss of a stream we claim to cover.
 */
export declare function transactionRecord(story: VenmoStory, ownerId: string): RecordData | null;
//# sourceMappingURL=parsers.d.ts.map