#!/usr/bin/env node
import { type ReferenceBlobRef } from "../../src/reference-blob-uploader.ts";
export declare const DEFAULT_MAX_ATTACHMENT_BYTES: number;
export declare function resolveMaxAttachmentBytes(env?: NodeJS.ProcessEnv): number;
export declare function resolveAttachmentsRoot(env?: NodeJS.ProcessEnv): string;
export interface AttachmentHydrationResult {
    blobRef: ReferenceBlobRef | null;
    bytes: Buffer | null;
    contentSha256: string | null;
    hydrationError: string | null;
    hydrationStatus: "deferred" | "hydrated" | "failed" | "too_large" | "missing";
    sizeBytes: number | null;
}
export declare function readAttachmentFileSync(localPath: string, maxBytes: number): AttachmentHydrationResult;
//# sourceMappingURL=index.d.ts.map