import { z } from "zod";
/**
 * messages stream: one record per message row.
 * Cursor: date (Apple epoch high-water mark tracked in STATE).
 */
export declare const messagesSchema: z.ZodObject<{
    id: z.ZodString;
    chat_id: z.ZodNullable<z.ZodString>;
    handle: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    service: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    is_from_me: z.ZodBoolean;
    text: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    date: z.ZodString;
    date_read: z.ZodNullable<z.ZodString>;
    has_attachments: z.ZodBoolean;
}, z.core.$strip>;
/**
 * participants stream: one record per (chat, handle) membership pair from
 * `chat_handle_join`. Semantics: mutable_state — full membership resnapshot
 * each run, not an incremental stream.
 */
export declare const participantsSchema: z.ZodObject<{
    id: z.ZodString;
    chat_id: z.ZodString;
    handle: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    is_from_me: z.ZodBoolean;
}, z.core.$strip>;
/**
 * attachments stream: one record per attachment row, joined through
 * message_attachment_join. Bytes are hydrated via a local read bounded to a
 * trusted attachments root (resolveSafeAttachmentPath in index.ts — rejects
 * `../` traversal, absolute-outside-root, and symlink escape) + BlobRef
 * upload; hydration_status/hydration_error report the outcome without
 * leaking the local filesystem path.
 */
export declare const attachmentsSchema: z.ZodObject<{
    id: z.ZodString;
    message_id: z.ZodNullable<z.ZodString>;
    chat_id: z.ZodNullable<z.ZodString>;
    filename: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    content_type: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    content_sha256: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    hydration_status: z.ZodEnum<{
        deferred: "deferred";
        failed: "failed";
        hydrated: "hydrated";
        missing: "missing";
        too_large: "too_large";
    }>;
    hydration_error: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    blob_ref: z.ZodNullable<z.ZodObject<{
        blob_id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        mime_type: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        sha256: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
        size_bytes: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map