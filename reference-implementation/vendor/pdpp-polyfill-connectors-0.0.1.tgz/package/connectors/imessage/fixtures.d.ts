export interface FixtureHandle {
    id: string;
    rowid: number;
}
export interface FixtureMessage {
    chatId: number;
    /** null simulates a chat.db row with message.date = NULL. */
    dateAppleSec: number | null;
    dateReadAppleSec?: number | null;
    guid: string;
    handleRowid: number | null;
    hasAttachments?: boolean;
    isFromMe: boolean;
    rowid: number;
    service?: string;
    text: string | null;
}
export interface FixtureAttachment {
    filename: string | null;
    messageRowid: number;
    mimeType: string | null;
    rowid: number;
    totalBytes?: number | null;
}
export interface ChatDbFixtureOptions {
    attachments?: FixtureAttachment[];
    chatIds?: number[];
    handles?: FixtureHandle[];
    /** Omit attachment/message_attachment_join tables entirely. */
    includeAttachmentTables?: boolean;
    /** Omit chat_handle_join (simulates a schema-version gap). */
    includeChatHandleJoin?: boolean;
    /** (chatId, handleRowid) membership pairs. */
    memberships?: Array<{
        chatId: number;
        handleRowid: number;
    }>;
    messages: FixtureMessage[];
}
/**
 * Apple epoch is seconds/nanos since 2001-01-01. Fixtures use plain seconds
 * (the "older macOS" branch of the heuristic in index.ts's appleDateToIso).
 */
export declare function appleSecFromUnixMs(unixMs: number): number;
export declare function buildChatDbFixture(dbPath: string, opts: ChatDbFixtureOptions): void;
//# sourceMappingURL=fixtures.d.ts.map