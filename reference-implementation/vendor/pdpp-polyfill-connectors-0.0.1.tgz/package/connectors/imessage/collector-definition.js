// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
export const IMESSAGE_DEFAULT_STREAMS = [
    "messages",
    "participants",
    "attachments",
];
/**
 * Only `messages` declares a `consent_time_field` (`date`). Participants are
 * standing entities and attachments carry no owner-moment of their own, so a
 * date bound is not measurable against either; both are collected whole.
 */
export const IMESSAGE_TIME_SCOPABLE_STREAMS = ["messages"];
export const imessageCollectorDefinition = {
    connector_id: "imessage",
    entry: "imessage",
    bindings: { filesystem: { required: true } },
    // Declared explicitly (not omitted): this definition targets the
    // connector-protocol 0.0.2 capability-declaration contract, which
    // requires an explicit array even when empty. This connector emits no
    // STREAM_EVIDENCE and needs no protocol capability today.
    protocol_capabilities: [],
    streams: IMESSAGE_DEFAULT_STREAMS,
    time_scopable_streams: IMESSAGE_TIME_SCOPABLE_STREAMS,
};
