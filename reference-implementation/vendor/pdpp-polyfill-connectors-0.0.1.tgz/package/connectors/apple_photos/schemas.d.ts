import { z } from "zod";
/**
 * photos stream: one record per discovered image/video file found under
 * APPLE_PHOTOS_EXPORT_DIR. Cursor: file_modified_at (last_modified).
 */
export declare const photosSchema: z.ZodObject<{
    id: z.ZodString;
    filename: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    content_type: z.ZodString;
    size_bytes: z.ZodNullable<z.ZodNumber>;
    content_sha256: z.ZodNullable<z.ZodString>;
    hydration_status: z.ZodString;
    hydration_error: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    blob_ref: z.ZodNullable<z.ZodObject<{
        blob_id: z.ZodString;
        mime_type: z.ZodString;
        sha256: z.ZodString;
        size_bytes: z.ZodNumber;
    }, z.core.$strip>>;
    taken_at: z.ZodNullable<z.ZodString>;
    file_modified_at: z.ZodString;
    latitude: z.ZodNullable<z.ZodNumber>;
    longitude: z.ZodNullable<z.ZodNumber>;
    camera_make: z.ZodNullable<z.ZodString>;
    camera_model: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * coverage_diagnostics stream: one row per known local store (currently just
 * "export_dir") reporting whether it exists and is being collected. Shared
 * shape with claude_code/codex's coverage_diagnostics — see
 * src/local-source-inventory.ts's buildLocalSourceInventory, the emitter
 * both this connector and those use.
 */
export declare const coverageDiagnosticsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    store: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    stream: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodEnum<{
        collected: "collected";
        deferred: "deferred";
        excluded: "excluded";
        inventory_only: "inventory_only";
        missing: "missing";
        unsupported: "unsupported";
    }>;
    reason: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map