import type { MediaHydrationResult } from "../../src/local-media-blob-hydration.ts";
import type { DiscoveredFile, PhotoRecordOut } from "./types.ts";
/** File extensions this connector will pick up when walking the export dir. */
export declare const SUPPORTED_EXTENSIONS: ReadonlySet<string>;
export declare function hashId(s: string): string;
/** Detects MIME type by file extension. Case-insensitive. */
export declare function detectMimeType(filename: string): string;
/**
 * Build a single `photos`-stream record from a discovered file and its
 * hydration result (bytes read/hashed/uploaded within the size cap — see
 * hydrateMediaBytes in src/local-media-blob-hydration.ts, shared with
 * google_takeout's photos stream).
 *
 * `id` is derived from content_sha256 ALONE (not filename/size/mtime) —
 * two files with byte-identical content (the same photo present in two
 * different Photos.app exports, or a re-export of the same album) collapse
 * to the same record id and the same underlying blob, so re-running this
 * connector against overlapping exports does not create duplicate photo
 * records or duplicate blob uploads. When content bytes could not be read
 * at all (hydration_status is "failed" with no contentSha256), the id falls
 * back to a filename+size+mtime identity so the file is still represented
 * rather than silently dropped — that fallback path cannot dedupe across
 * copies, which is an acceptable and expected consequence of not having
 * readable bytes to hash.
 *
 * No EXIF/XMP parsing is performed — taken_at, latitude, longitude,
 * camera_make, and camera_model are always null in this cut. See the header
 * comment in index.ts for why this is a bounded, explicit omission (no
 * EXIF-parsing dependency exists elsewhere in this package, and it was
 * judged out of scope for hand-rolling safely in a first pass) — this
 * connector does not and must not claim to reproduce full Apple Photos
 * metadata (people/album/face tags, edit history, EXIF/XMP), only what a
 * Photos.app "Export Unmodified Originals" run plus file-level metadata and
 * content hashing can honestly provide.
 */
export declare function buildPhotoRecord(file: DiscoveredFile, filename: string, hydration: MediaHydrationResult): PhotoRecordOut;
/**
 * Return true if `modifiedAt` falls on or before the incremental cursor
 * `since`. index.ts uses this to skip already-emitted files.
 */
export declare function isBeforeCursor(modifiedAt: string, since: string | undefined): boolean;
/** Monotonic max of an existing cursor and a new ISO date string. */
export declare function advanceCursor(prev: string | undefined, next: string): string;
//# sourceMappingURL=parsers.d.ts.map