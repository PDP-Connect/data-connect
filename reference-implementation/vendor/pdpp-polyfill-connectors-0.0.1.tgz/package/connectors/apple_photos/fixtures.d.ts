export interface FixtureFile {
    /** File contents. Small synthetic buffers are fine — no real photo data. */
    contents?: Buffer;
    /** Override mtime/atime; defaults to "now" if omitted. */
    mtime?: Date;
    /** Relative path (may include subdirectories) within the export dir. */
    relPath: string;
}
/**
 * Create a fresh temp directory and populate it with the given fixture
 * files (creating subdirectories as needed). Returns the directory path.
 */
export declare function buildExportDirFixture(files: FixtureFile[]): string;
/** Create an empty temp directory (simulates an export dir with nothing in it). */
export declare function buildEmptyExportDirFixture(): string;
//# sourceMappingURL=fixtures.d.ts.map