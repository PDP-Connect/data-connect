// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
export const APPLE_PHOTOS_DEFAULT_STREAMS = [
    "photos",
    "coverage_diagnostics",
];
/**
 * `photos` declares `file_modified_at`; `coverage_diagnostics` is the run's own
 * accounting and carries no owner-moment, so it is always collected whole.
 */
export const APPLE_PHOTOS_TIME_SCOPABLE_STREAMS = ["photos"];
export const applePhotosCollectorDefinition = {
    connector_id: "apple_photos",
    entry: "apple_photos",
    bindings: { filesystem: { required: true } },
    // Declared explicitly (not omitted): this definition targets the
    // connector-protocol 0.0.2 capability-declaration contract, which
    // requires an explicit array even when empty. This connector emits no
    // STREAM_EVIDENCE and needs no protocol capability today.
    protocol_capabilities: [],
    streams: APPLE_PHOTOS_DEFAULT_STREAMS,
    time_scopable_streams: APPLE_PHOTOS_TIME_SCOPABLE_STREAMS,
};
