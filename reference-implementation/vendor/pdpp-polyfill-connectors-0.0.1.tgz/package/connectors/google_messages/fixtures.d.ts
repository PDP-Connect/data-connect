/**
 * Canned `gmcli ... --json` output fixtures for Google Messages connector
 * tests, plus the `GmcliRunner` injection seam so tests can swap in a fake
 * runner instead of spawning a real subprocess.
 *
 * FIELD SHAPE PROVENANCE: this fixture shape mirrors gmcli's actual
 * `Conversation`/`Message` Go structs (github.com/johnlindquist/gmkit,
 * internal/store/conversations.go + messages.go), fetched and verified
 * directly from source — see schemas.ts's header comment for the exact
 * struct quotes. It is NOT captured from a real `gmcli chats list`/`gmcli
 * messages list` run (no live binary or paired device is available in this
 * environment), so field VALUES are synthetic, but field NAMES/shape are
 * source-verified, not guessed.
 */
export interface GmcliResult {
    readonly exitCode: number;
    readonly stderr: string;
    readonly stdout: string;
}
/** Swappable seam: production code spawns a real gmcli process; tests inject a fake. */
export type GmcliRunner = (args: readonly string[]) => Promise<GmcliResult>;
/** Conversation-shaped sample `gmcli --json --full chats list` output — one chat. */
export declare function buildChatsJsonFixture(): string;
/** No conversations at all — a paired-but-empty archive. */
export declare function buildEmptyChatsJsonFixture(): string;
/** Malformed chats output (missing conversation_id) for the schema-drift test. */
export declare function buildMalformedChatsJsonFixture(): string;
/** A two-message Message-shaped sample `gmcli messages list --conv <id> --json --full` output. */
export declare function buildMessagesJsonFixture(): string;
/** Empty result set for one conversation — no messages returned. */
export declare function buildEmptyMessagesJsonFixture(): string;
/**
 * A full page of messages (exactly `limit` rows) — the only detectable
 * proxy gmcli gives for "this conversation may have more history than we
 * fetched," since `--limit` has no accompanying total-count/cursor.
 */
export declare function buildFullPageMessagesJsonFixture(limit: number): string;
/** Malformed/schema-drifted messages output (missing required fields) for the schema-drift test. */
export declare function buildMalformedMessagesJsonFixture(): string;
/** Not-valid-JSON output at all — proves the parser fails closed on total garbage. */
export declare function buildNotJsonFixture(): string;
//# sourceMappingURL=fixtures.d.ts.map