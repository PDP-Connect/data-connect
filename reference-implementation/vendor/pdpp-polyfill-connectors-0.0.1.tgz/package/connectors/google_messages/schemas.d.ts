import { z } from "zod";
/**
 * messages stream: one record per gmcli Message row (`gmcli messages list
 * --conv <id> --json --full`, bounded by GMCLI_MESSAGES_PER_CHAT_LIMIT
 * per conversation). Cursor: a connector-side per-message-id content
 * fingerprint (index.ts's STATE section) — best-effort de-duplication, not
 * a gmcli-side incremental cursor; gmcli exposes no "since" pagination
 * token, so every run re-fetches the same bounded window per conversation
 * and the fingerprint gate is what stops that from re-emitting duplicates.
 */
export declare const messagesSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    chat_id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    chat_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    sender_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    sent_at: z.ZodString;
    direction: z.ZodString;
}, z.core.$strip>;
/**
 * coverage_diagnostics stream: one row per known local store (currently just
 * "gmcli_archive") reporting whether gmcli is installed/paired/readable.
 * Shared shape with apple_photos/claude_code/codex's coverage_diagnostics —
 * see src/local-source-inventory.ts's CoverageRecord.
 */
export declare const coverageDiagnosticsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    store: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    stream: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    status: z.ZodEnum<{
        collected: "collected";
        deferred: "deferred";
        excluded: "excluded";
        inventory_only: "inventory_only";
        missing: "missing";
        unsupported: "unsupported";
    }>;
    reason: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map