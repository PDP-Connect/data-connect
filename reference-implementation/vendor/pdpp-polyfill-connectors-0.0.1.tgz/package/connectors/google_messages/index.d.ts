#!/usr/bin/env node
import { type CollectContext } from "../../src/connector-runtime.ts";
import type { CoverageRecord } from "../../src/local-source-inventory.ts";
import type { GmcliResult } from "./fixtures.ts";
export declare function resolveGmcliBin(): string;
export declare function formatGmcliMissingError(bin: string): string;
export declare function redactGmcliOutput(output: string): string;
/**
 * gmcli invocation errors carry a `kind` so callers can distinguish
 * "binary missing" / "not paired" / "other query failure" without
 * re-parsing message text.
 */
export declare class GmcliError extends Error {
    readonly kind: "not_installed" | "not_paired" | "query_failed";
    constructor(message: string, kind: "not_installed" | "not_paired" | "query_failed", options?: {
        cause?: unknown;
    });
}
/**
 * Spawn `gmcli <args>` and collect stdout/stderr. Read-only query/sync
 * subcommands only — callers MUST NOT pass "auth", "serve", "mcp", or any
 * send-capable subcommand here.
 */
export declare function runGmcli(args: readonly string[], opts?: {
    timeoutMs?: number;
}): Promise<GmcliResult>;
interface ParsedGmcliChat {
    readonly id: string;
    readonly lastMessageTimeMs: number | null;
    readonly name: string | null;
}
interface ParsedGmcliMessage {
    readonly body: string;
    readonly chat_id: string;
    readonly chat_name: string | null;
    readonly direction: "incoming" | "outgoing";
    readonly id: string;
    readonly sender_id: string | null;
    readonly sent_at: string;
}
/**
 * Parse `gmcli --json --full chats list` output into chat ids (+ optional
 * display name). Throws a typed GmcliError on malformed JSON/shape — never
 * silently returns a wrong-shape/empty result on a parse failure.
 */
export declare function parseGmcliChatsJson(stdout: string): ParsedGmcliChat[];
/**
 * Parse `gmcli messages list --conv <id> --json --full` output (Message
 * rows) for one conversation into ParsedGmcliMessage records.
 */
export declare function parseGmcliMessagesJson(stdout: string, chatName?: string | null): ParsedGmcliMessage[];
export declare function sortChatsByRecency(chats: readonly ParsedGmcliChat[]): ParsedGmcliChat[];
interface GmcliFetchOutcome {
    /** Present when the chat list itself was cut to GMCLI_MAX_CHATS — distinct
     *  from `truncated` (per-chat message-limit truncation). `collect()` turns
     *  this into its own `messages` SKIP_RESULT so a run that silently
     *  dropped whole conversations cannot read as complete coverage.
     *
     *  `atLeastTotalCount` is a LOWER BOUND, not the true total: the
     *  `chats list --limit` probe (see fetchAndParseGmcliMessages's doc
     *  comment) only fetches `maxChats + 1` rows, so once truncation is
     *  detected the real archive could hold far more conversations than that
     *  — this connector has no way to learn the exact true count without an
     *  unbounded fetch, which would defeat the whole purpose of the cap. */
    readonly chatsTruncated?: {
        atLeastTotalCount: number;
        scannedCount: number;
    };
    readonly coverageReason: string;
    readonly coverageStatus: CoverageRecord["status"];
    /**
     * Flat `reason`/`message` fields (not a nested `skip: { reason, message
     * }` object) so the emission call site in `collect()` can write a
     * literal `reason:` property whose value is `outcome.reason` — a plain
     * one-hop `x.reason` MemberExpression the reason-code completeness
     * scanner already resolves via its existing same-file-call-result bound
     * — instead of `outcome.skip.reason`/`...outcome.skip`, both of which
     * need resolution depth beyond that deliberately bounded one hop (see
     * `reason-emission-scan.ts`'s doc comment on why this scanner does not
     * chase nested member chains or spreads).
     */
    readonly message?: string;
    readonly parsed?: ParsedGmcliMessage[];
    readonly reason?: string;
    readonly truncated?: readonly string[];
}
/**
 * Enumerate chats (`gmcli --json --full chats list`), then fetch each
 * chat's messages (`gmcli messages list --conv <id> ...`), bounded by
 * GMCLI_MAX_CHATS/GMCLI_MESSAGES_PER_CHAT_LIMIT. Collapses every failure
 * mode (binary missing, not paired, query failure, schema drift) into one
 * discriminated outcome. `collect()` only has to branch on `outcome.reason`
 * vs `outcome.parsed` — the fine-grained SKIP_RESULT reason and coverage
 * status/reason live here.
 *
 * `chats list` is called with an explicit `--limit`, sized to `maxChats + 1`
 * — NOT left unset. gmcli's own `chats list` defaults `--limit` to 50
 * server-side when the flag is absent (verified from gmkit's Go source:
 * `internal/cmd/chats.go`'s `chatsListCmd`, `IntVar(&limit, "limit", 50,
 * ...)`, clamped again in `internal/store/conversations.go`'s
 * `ListConversations` if `<= 0`). An unset `--limit` would silently cap the
 * chat enumeration at 50 UPSTREAM of this connector's own
 * `GMCLI_MAX_CHATS` bookkeeping — for any archive with more than 50
 * conversations and the default `GMCLI_MAX_CHATS` (200), the fetch would
 * never see chats 51+ at all, so `orderedChats.length > maxChats` could
 * never be true and the `gmcli_chat_scan_limit_reached` truncation signal
 * below would never fire, even though real conversations were silently
 * dropped from the scan.
 *
 * The probe is `maxChats + 1`, not `maxChats`, because fetching exactly
 * `maxChats` rows is indistinguishable between "the archive has exactly
 * `maxChats` conversations" (no truncation) and "the archive has more, but
 * gmcli's own `--limit` cut the response at exactly `maxChats`" (silent
 * truncation) — the same "exact cap vs. truncation" ambiguity this
 * connector already refuses to accept for the per-chat message limit (see
 * `fetchChatMessages`'s `possiblyTruncated: messages.length >= limit`).
 * Fetching one extra row resolves the ambiguity: exactly `maxChats + 1`
 * rows back means "at least one more exists beyond the cap" (truncated);
 * `maxChats` or fewer means "this is the true, complete count" (not
 * truncated). The 1 extra row is used only for this detection — it is
 * never scanned for messages; the connector still retains only the
 * `maxChats` most recently active chats (see sortChatsByRecency below).
 * gmcli's `--limit` has no documented upper clamp beyond the `<= 0` case
 * (verified from the same store source), so `maxChats + 1` is honored as a
 * literal SQL `LIMIT`, not silently re-capped to 50 by passing it explicitly.
 */
export declare function fetchAndParseGmcliMessages(invoke?: GmcliInvoker): Promise<GmcliFetchOutcome>;
export type GmcliInvoker = (args: readonly string[]) => Promise<GmcliResult>;
export declare function collect({ state, requested, emit, emitRecord, progress, }: CollectContext): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map