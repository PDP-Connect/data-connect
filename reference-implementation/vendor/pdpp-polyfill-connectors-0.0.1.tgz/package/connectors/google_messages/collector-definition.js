// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
export const GOOGLE_MESSAGES_DEFAULT_STREAMS = [
    "messages",
    "coverage_diagnostics",
];
/**
 * `messages` declares `sent_at`; `coverage_diagnostics` is the run's own
 * accounting and carries no owner-moment, so it is always collected whole.
 */
export const GOOGLE_MESSAGES_TIME_SCOPABLE_STREAMS = ["messages"];
export const googleMessagesCollectorDefinition = {
    connector_id: "google_messages",
    entry: "google_messages",
    bindings: { filesystem: { required: true } },
    // Declared explicitly (not omitted): this definition targets the
    // connector-protocol 0.0.2 capability-declaration contract, which
    // requires an explicit array even when empty. This connector emits no
    // STREAM_EVIDENCE and needs no protocol capability today.
    protocol_capabilities: [],
    streams: GOOGLE_MESSAGES_DEFAULT_STREAMS,
    time_scopable_streams: GOOGLE_MESSAGES_TIME_SCOPABLE_STREAMS,
};
