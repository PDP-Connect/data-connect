export declare const ACTIVITIES_CSV = "activities.csv";
/**
 * A Strava archive may contain many per-activity files, but the connector only
 * reads this one member. Metadata and actual inflated bytes stay bounded by
 * the shared ZIP policy before this module hands the CSV to the row parser.
 */
export declare const ZIP_POLICY: {
    readonly maxEntries: 200000;
    readonly maxEntryUncompressedBytes: number;
    readonly maxTotalUncompressedBytes: number;
};
export interface ActivitiesCsvSource {
    readonly close: () => void;
    readonly stream: AsyncIterable<string>;
}
export type ActivitiesCsvSourceResult = {
    readonly ok: true;
    readonly source: ActivitiesCsvSource;
} | {
    readonly ok: false;
    readonly message: string;
    readonly status?: "too_large";
};
/**
 * Create a UTF-8 CSV stream from an already-open artifact descriptor. The
 * descriptor remains caller-owned and is never closed here.
 *
 * Bare CSVs are read directly from `fd`. ZIPs are checked through the bounded
 * archive reader and only `activities.csv` is extracted to a scratch file;
 * the extracted file is then streamed and removed by `source.close()`.
 */
export declare function streamActivitiesCsvFromFile(fd: number, fileName: string, fileSize: number): Promise<ActivitiesCsvSourceResult>;
//# sourceMappingURL=artifact-stream.d.ts.map