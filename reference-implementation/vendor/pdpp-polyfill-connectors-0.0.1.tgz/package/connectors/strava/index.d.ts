#!/usr/bin/env node
import { type ConnectorHttpGovernor } from "../../src/connector-http-governor.ts";
import { type CollectContext } from "../../src/connector-runtime.ts";
/** Governor the walk actually sends through. Production always uses the paced
 *  module-level one; a test may substitute an unpaced governor so a two-page
 *  fixture does not have to wait out the real 10s-per-request rate ceiling.
 *  The ceiling itself stays covered by `stravaPacingProfile()`'s own tests. */
type StravaHttpGovernor = Pick<ConnectorHttpGovernor, "request">;
export interface StravaCollectOptions {
    /** @see StravaHttpGovernor */
    readonly httpGovernor?: StravaHttpGovernor;
    /** Page ceiling actually enforced by this walk. Injectable so a test can
     *  reach the capped exit with a two-page fixture instead of 200 real pages. */
    readonly maxPages?: number;
}
export declare function collectStrava(ctx: CollectContext, options?: StravaCollectOptions): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map