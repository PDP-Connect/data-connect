// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { createHash } from "node:crypto";
import { readZipEntries, ZipPolicyViolationError, zipBasename, } from "../../src/bounded-zip-archive.js";
import { ACTIVITIES_CSV, streamActivitiesCsvFromFile, ZIP_POLICY, } from "./artifact-stream.js";
import { buildActivityRecord, parseCsvRows, resolveColumns, streamCsvRows, } from "./parsers.js";
function remediationFor(status) {
    switch (status) {
        case "duplicate":
            return "This Strava account export was already imported. Request a newer archive from Strava if you need more recent activities.";
        case "empty":
            return "This looks like a Strava account export, but activities.csv contains no importable activities.";
        case "too_large":
            return "This Strava file is larger than the upload limit. Extract the archive yourself and upload only activities.csv.";
        case "unsupported":
            return "Choose the ZIP Strava emailed you containing activities.csv, or upload activities.csv from that archive. Other files are not supported.";
        case "valid":
            return null;
    }
}
function baseValidation(fileSha256, status = "unsupported") {
    return {
        date_range: { end: null, start: null },
        detected_format: "unsupported",
        detected_headers: null,
        estimated_records: 0,
        file_sha256: fileSha256,
        remediation: remediationFor(status),
        repeated_headers: null,
        status,
    };
}
function formatForFileName(fileName) {
    if (fileName?.toLowerCase().endsWith(".zip")) {
        return "strava_account_export_zip";
    }
    if (fileName?.toLowerCase().endsWith(".csv")) {
        return "strava_account_export_csv";
    }
    return null;
}
function hasExpectedRepeatedHeaders(columns) {
    return (columns.occurrences.get("Distance")?.length === 2 &&
        columns.occurrences.get("Elapsed Time")?.length === 2);
}
function dateRange(values) {
    let start = null;
    let end = null;
    for (const value of values) {
        if (!start || value < start) {
            start = value;
        }
        if (!end || value > end) {
            end = value;
        }
    }
    return { end, start };
}
class ValidationAccumulator {
    columns = null;
    earliest = null;
    latest = null;
    recordCount = 0;
    header = null;
    headerError = false;
    accept(row, exportedAt) {
        if (!this.header) {
            this.header = row;
            const resolved = resolveColumns(row);
            if (!("occurrences" in resolved)) {
                this.headerError = true;
                return;
            }
            this.columns = resolved;
            return;
        }
        if (this.headerError || !this.columns) {
            return;
        }
        if (row.length === 1 && row[0]?.trim() === "") {
            return;
        }
        const record = buildActivityRecord(row, this.columns, exportedAt);
        if (!record) {
            return;
        }
        this.recordCount += 1;
        if (!this.earliest || record.start_time < this.earliest) {
            this.earliest = record.start_time;
        }
        if (!this.latest || record.start_time > this.latest) {
            this.latest = record.start_time;
        }
    }
    result(format, fileSha256, existingFileHashes, parseError) {
        const base = baseValidation(fileSha256);
        if (!this.header || this.headerError || !this.columns || parseError) {
            return {
                ...base,
                detected_headers: this.header,
            };
        }
        if (!hasExpectedRepeatedHeaders(this.columns)) {
            return {
                ...base,
                detected_headers: this.header,
            };
        }
        const status = new Set(existingFileHashes ?? []).has(fileSha256)
            ? "duplicate"
            : this.recordCount === 0
                ? "empty"
                : "valid";
        return {
            date_range: dateRange([this.earliest, this.latest].filter((value) => value !== null)),
            detected_format: format,
            detected_headers: this.header,
            estimated_records: this.recordCount,
            file_sha256: fileSha256,
            remediation: remediationFor(status),
            repeated_headers: {
                distance: this.columns.occurrences.get("Distance") ?? [],
                elapsed_time: this.columns.occurrences.get("Elapsed Time") ?? [],
            },
            status,
        };
    }
}
function validateRows(rows, format, fileSha256, options, parseError) {
    const accumulator = new ValidationAccumulator();
    for (const row of rows) {
        accumulator.accept(row, null);
    }
    return accumulator.result(format, fileSha256, options.existingFileHashes, parseError);
}
function validateBufferContents(bytes, format, fileSha256, options) {
    if (format === "strava_account_export_csv") {
        const parsed = parseCsvRows(bytes.toString("utf8"));
        return validateRows(parsed.rows, format, fileSha256, options, parsed.error);
    }
    try {
        const entries = readZipEntries(bytes, ZIP_POLICY);
        const match = entries.find((entry) => zipBasename(entry.name).toLowerCase() === ACTIVITIES_CSV);
        if (!match) {
            return baseValidation(fileSha256);
        }
        const parsed = parseCsvRows(match.data().toString("utf8"));
        return validateRows(parsed.rows, format, fileSha256, options, parsed.error);
    }
    catch (error) {
        return baseValidation(fileSha256, error instanceof ZipPolicyViolationError ? "too_large" : "unsupported");
    }
}
export function validateStravaAccountExportArtifact(input, options = {}) {
    const bytes = typeof input === "string" ? Buffer.from(input, "utf8") : Buffer.from(input);
    const fileSha256 = createHash("sha256").update(bytes).digest("hex");
    const fileName = options.fileName ?? ACTIVITIES_CSV;
    const format = formatForFileName(fileName);
    if (options.maxFileBytes !== null &&
        options.maxFileBytes !== undefined &&
        bytes.byteLength > options.maxFileBytes) {
        return baseValidation(fileSha256, "too_large");
    }
    if (!format) {
        return baseValidation(fileSha256);
    }
    return validateBufferContents(bytes, format, fileSha256, options);
}
export async function validateStravaAccountExportArtifactFromFile(fd, _filePath, fileSize, options) {
    if (options.maxFileBytes !== null &&
        options.maxFileBytes !== undefined &&
        fileSize > options.maxFileBytes) {
        return baseValidation(options.fileSha256, "too_large");
    }
    const format = formatForFileName(options.fileName);
    if (!format) {
        return baseValidation(options.fileSha256);
    }
    const opened = await streamActivitiesCsvFromFile(fd, options.fileName, fileSize);
    if (!opened.ok) {
        return baseValidation(options.fileSha256, opened.status ?? "unsupported");
    }
    const accumulator = new ValidationAccumulator();
    try {
        const parsed = await streamCsvRows(opened.source.stream, async (row) => {
            accumulator.accept(row, null);
        });
        return accumulator.result(format, options.fileSha256, options.existingFileHashes, parsed.error);
    }
    catch {
        return baseValidation(options.fileSha256);
    }
    finally {
        opened.source.close();
    }
}
