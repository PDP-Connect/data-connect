/**
 * Parsing for the Strava account export's `activities.csv`.
 *
 * THE TRAP THIS FILE EXISTS TO AVOID. `activities.csv` has REPEATED column
 * headers: `Distance` and `Elapsed Time` each appear twice. The first
 * occurrence is in the athlete's own display units — which may be miles — and
 * the second is canonical metres and seconds. A header-name-to-index map keeps
 * whichever occurrence it saw last or first, and either way produces a number
 * that is unlabelled, plausible and wrong: a five-mile run read as five metres
 * is absurd enough to notice, but read as 8047 metres it is simply correct, and
 * read as `5` it is a number nobody questions until they do.
 *
 * So rows are carried as positional `string[]`, never as `Record<header,
 * value>`, and {@link resolveColumns} resolves each logical field to an
 * explicit index, taking the LAST occurrence for the repeated pair. The
 * resolution is returned rather than hidden, so parsers.test.ts can assert
 * which index each field came from and fail if the layout shifts.
 */
/** Logical fields this connector reads out of the export. */
export interface ColumnIndex {
    readonly activityDate: number;
    readonly activityType: number;
    readonly averageHeartRate: number | null;
    readonly calories: number | null;
    readonly distanceM: number;
    readonly elapsedTimeS: number;
    /**
     * The FIRST `Elapsed Time` column, read only when {@link elapsedTimeS} is
     * empty for a row. It is a display rendering, so it is not always seconds —
     * `numberOrNull` refuses a `MM:SS` cell, which is what makes the fallback
     * safe rather than a guess.
     */
    readonly elapsedTimeDisplayS: number | null;
    readonly elevationGainM: number | null;
    readonly gear: number | null;
    readonly id: number;
    readonly maxHeartRate: number | null;
    readonly movingTimeS: number | null;
    /** Every index each header name occupies, for tests and diagnostics. */
    readonly occurrences: ReadonlyMap<string, readonly number[]>;
}
export interface ColumnError {
    readonly message: string;
    readonly missing: readonly string[];
}
/**
 * The headers Strava repeats. Named one by one rather than handled by a general
 * "last wins" rule, so that a header Strava *starts* repeating later is a
 * visible failure to investigate rather than a silent change of meaning.
 *
 * Every entry was decided against a real account export (layout observed in
 * September 2026), and the reasoning is recorded per header because it does
 * not generalise — one takes the first occurrence and two take the last.
 *
 * - `Distance` — the LAST is canonical. The first is the athlete's display
 *   unit: measured across the archive, last/first is 1000, so the first was
 *   kilometres. Reading it would report a 9 km ride as 9 metres.
 * - `Elapsed Time` — the LAST is canonical seconds. The first is a display
 *   rendering, which in some archives is `MM:SS`, so it is read only as a
 *   fallback for a row the last leaves empty, and only when it is a bare
 *   number. Both columns were seconds and agreed on every row that carried
 *   both.
 * - `Max Heart Rate` — the FIRST is canonical. The last is a strict subset of
 *   it: every row carrying both agreed, many carried only the first, and none
 *   carried only the last. Taking the last would discard readings to no
 *   purpose. There is no unit hazard — both are bpm.
 * - `Relative Effort` and `Commute` are not read by this connector. They are
 *   named so that their repetition does not block a parse of the fields that
 *   are, and so the next person knows they were looked at rather than missed.
 */
export declare const REPEATED_HEADERS: readonly ["Commute", "Distance", "Elapsed Time", "Max Heart Rate", "Relative Effort"];
/**
 * RFC 4180 CSV reader returning positional rows.
 *
 * Deliberately returns `string[][]` and not keyed records — see the file
 * header. Handles quoted fields containing commas, newlines and doubled
 * quotes, which Strava's gear and type values do produce.
 */
export declare function parseCsvRows(text: string): {
    error?: string;
    rows: string[][];
};
/**
 * Parse a file-backed CSV incrementally. The callback is awaited after each
 * completed row, so a slow protocol emit cannot make the reader race ahead
 * and accumulate the remainder of a large export.
 */
export declare function streamCsvRows(chunks: AsyncIterable<string>, onRow: (row: string[]) => Promise<void> | void): Promise<{
    error?: string;
    rowCount: number;
}>;
/**
 * Resolve each logical field to a column index.
 *
 * A header that repeats is resolved per field, not by a blanket rule: which
 * occurrence is canonical differs between them, and {@link REPEATED_HEADERS}
 * records the evidence for each. For every other header the first (and only)
 * occurrence is used, and a header that repeats *without* being named there is
 * reported rather than silently resolved — the file's layout has changed and
 * guessing which column now means what is how a five-mile run becomes a five.
 */
export declare function resolveColumns(header: readonly string[]): ColumnIndex | ColumnError;
/**
 * An empty cell means the reading was never taken — a ride with no strap, a
 * manually entered activity with no calories. It becomes null and never 0,
 * because a zero here would reach an observation as though the owner's heart
 * rate had been measured at zero.
 */
export declare function numberOrNull(cell: string | undefined): number | null;
export declare function textOrNull(cell: string | undefined): string | null;
export interface ParsedStart {
    /** ISO-8601. Carries an offset only when the source stated one. */
    readonly iso: string;
    /** What the source actually told us about the clock — never a guess. */
    readonly basis: "utc" | "local" | "unknown";
}
/**
 * Parse the export's single `Activity Date` column.
 *
 * The basis is DERIVED, never assumed. Strava's own rendering carries no zone
 * marker at all, so it yields `unknown` — which is the honest answer and the
 * one a reader needs in order to decline time-of-day claims. Asserting UTC
 * here would be right for everyone who never travels and wrong by up to twelve
 * hours for everyone who does, which is the worst available failure: invisible
 * in testing, wrong in production.
 */
export declare function parseActivityDate(raw: string | undefined): ParsedStart | null;
export interface ActivityRecord {
    activity_type: string | null;
    average_heartrate: number | null;
    calories_kcal: number | null;
    distance_m: number | null;
    elapsed_time_s: number | null;
    exported_at: string | null;
    freshness: "live" | "snapshot";
    gear: string | null;
    id: string;
    max_heartrate: number | null;
    moving_time_s: number | null;
    start_date: string;
    start_time: string;
    start_time_basis: "utc" | "local" | "unknown";
    total_elevation_gain_m: number | null;
}
/**
 * Build one emitted record, or null when the row cannot be placed — no usable
 * id, or no parseable date. A null return is counted by the caller and
 * reported, never silently dropped.
 */
export declare function buildActivityRecord(row: readonly string[], columns: ColumnIndex, exportedAt: string | null): ActivityRecord | null;
//# sourceMappingURL=parsers.d.ts.map