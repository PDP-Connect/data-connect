import { z } from "zod";
/**
 * activities stream: one record per Strava athlete activity.
 * Cursor: last_start_epoch (derived from start_date).
 */
export declare const activitiesSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    type: z.ZodNullable<z.ZodString>;
    sport_type: z.ZodNullable<z.ZodString>;
    start_date: z.ZodString;
    start_date_local: z.ZodNullable<z.ZodString>;
    timezone: z.ZodNullable<z.ZodString>;
    distance_m: z.ZodNullable<z.ZodNumber>;
    moving_time_s: z.ZodNullable<z.ZodNumber>;
    elapsed_time_s: z.ZodNullable<z.ZodNumber>;
    total_elevation_gain_m: z.ZodNullable<z.ZodNumber>;
    average_speed_mps: z.ZodNullable<z.ZodNumber>;
    max_speed_mps: z.ZodNullable<z.ZodNumber>;
    average_heartrate: z.ZodNullable<z.ZodNumber>;
    max_heartrate: z.ZodNullable<z.ZodNumber>;
    kudos_count: z.ZodNullable<z.ZodNumber>;
    comment_count: z.ZodNullable<z.ZodNumber>;
    achievement_count: z.ZodNullable<z.ZodNumber>;
    start_latlng: z.ZodArray<z.ZodNumber>;
    end_latlng: z.ZodArray<z.ZodNumber>;
    map_polyline: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map