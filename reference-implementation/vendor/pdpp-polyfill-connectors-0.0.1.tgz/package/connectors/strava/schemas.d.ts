import { z } from "zod";
/**
 * `start_time` carries a UTC offset ONLY when the archive stated one. Strava's
 * own rendering does not, so a naked local-form timestamp is the normal case
 * and `start_time_basis` is what says whether an instant can be derived from
 * it. This is why the published schema does not claim `format: "date-time"` on
 * that field: RFC-3339 requires an offset, and declaring the format while
 * emitting a zoneless value would hand readers a false instant — the same
 * class of defect as reading miles as metres.
 */
/**
 * Which clock `start_time` is on. The archive carries a single date column and
 * does not state its basis anywhere, so this records what was determined from
 * the file rather than what was assumed about it. `unknown` is an honest and
 * expected value: a reader seeing it must not make time-of-day claims, because
 * an evening ride in one timezone is an afternoon one in another.
 */
export declare const START_TIME_BASES: readonly ["utc", "local", "unknown"];
/** How a reading was collected. An export is always a snapshot. */
export declare const FRESHNESS_VALUES: readonly ["live", "snapshot"];
/**
 * Why a covered window ends where it does. Closed, and always populated —
 * including on success, via `covered_in_full`. A nullable reason would invite
 * `if (reason)` as the failure test, which would classify "no activities last
 * week" as something going wrong.
 *
 * The values are next-action shaped rather than cause shaped: each one ends in
 * a different sentence to the owner, and each has a `reason_display_messages`
 * entry in the manifest carrying that sentence. `nothing_in_range` and
 * `collection_interrupted` are the pair that matters most — both can produce an
 * empty result, and they have opposite next actions.
 */
export declare const COVERAGE_REASONS: readonly ["covered_in_full", "nothing_in_range", "awaiting_upload", "source_unreadable", "source_limit_reached", "collection_interrupted", "records_unreadable", "sign_in_required", "window_unavailable"];
export declare const COVERAGE_STATUSES: readonly ["complete", "partial", "empty"];
/**
 * activities stream: one record per workout in the owner's export.
 * Cursor: start_time. Primary key: id, which is Strava's own activity id and
 * is stable across separate exports — two archives a month apart overlap
 * almost entirely, and this is what lets the overlap collapse instead of
 * double-counting.
 */
export declare const activitiesSchema: z.ZodObject<{
    id: z.ZodString;
    activity_type: z.ZodNullable<z.ZodString>;
    start_date: z.ZodString;
    start_time: z.ZodString;
    start_time_basis: z.ZodEnum<{
        local: "local";
        unknown: "unknown";
        utc: "utc";
    }>;
    distance_m: z.ZodNullable<z.ZodNumber>;
    moving_time_s: z.ZodNullable<z.ZodNumber>;
    elapsed_time_s: z.ZodNullable<z.ZodNumber>;
    total_elevation_gain_m: z.ZodNullable<z.ZodNumber>;
    average_heartrate: z.ZodNullable<z.ZodNumber>;
    max_heartrate: z.ZodNullable<z.ZodNumber>;
    calories_kcal: z.ZodNullable<z.ZodNumber>;
    gear: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    freshness: z.ZodEnum<{
        live: "live";
        snapshot: "snapshot";
    }>;
    exported_at: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * coverage_diagnostics stream: one record per stream per import, stating what
 * was covered and why it stops there.
 *
 * This is a separate stream rather than fields on each activity for a reason
 * that decides it on correctness, not taste: when nothing is collected there
 * are no activity records, so there would be nowhere for the diagnostic to
 * live — and "nothing in range" and "collection interrupted" are exactly the
 * two cases that produce an empty result and need telling apart.
 */
export declare const coverageDiagnosticsSchema: z.ZodObject<{
    id: z.ZodString;
    stream: z.ZodNullable<z.ZodString>;
    status: z.ZodEnum<{
        complete: "complete";
        empty: "empty";
        partial: "partial";
    }>;
    reason: z.ZodEnum<{
        awaiting_upload: "awaiting_upload";
        collection_interrupted: "collection_interrupted";
        covered_in_full: "covered_in_full";
        nothing_in_range: "nothing_in_range";
        records_unreadable: "records_unreadable";
        sign_in_required: "sign_in_required";
        source_limit_reached: "source_limit_reached";
        source_unreadable: "source_unreadable";
        window_unavailable: "window_unavailable";
    }>;
    record_count: z.ZodNullable<z.ZodNumber>;
    fields_unavailable: z.ZodArray<z.ZodString>;
    window_requested_from: z.ZodNullable<z.ZodString>;
    window_requested_to: z.ZodNullable<z.ZodString>;
    window_covered_from: z.ZodNullable<z.ZodString>;
    window_covered_to: z.ZodNullable<z.ZodString>;
    freshness: z.ZodEnum<{
        live: "live";
        snapshot: "snapshot";
    }>;
    exported_at: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * Stream → schema registry. Single source of truth for emitted streams.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map