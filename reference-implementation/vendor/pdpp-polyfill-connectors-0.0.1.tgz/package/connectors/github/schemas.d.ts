import { z } from "zod";
/**
 * user stream: stable identity and profile fields only.
 * Sampled metrics (followers, following, public_repos, public_gists) moved to user_stats.
 */
export declare const userSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    login: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    email: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    bio: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    company: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    location: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    blog: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    twitter_username: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    created_at: z.ZodNullable<z.ZodString>;
    updated_at: z.ZodNullable<z.ZodString>;
    avatar_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
}, z.core.$strip>;
/**
 * user_stats stream: sampled metrics keyed by {user_id}:{YYYY-MM-DD}.
 * One record per user per calendar day (UTC). Cursor: observed_on.
 */
export declare const userStatsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    user_id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    observed_on: z.ZodString;
    public_repos: z.ZodNullable<z.ZodNumber>;
    public_gists: z.ZodNullable<z.ZodNumber>;
    followers: z.ZodNullable<z.ZodNumber>;
    following: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * repositories stream: owned and org repos. Cursor: pushed_at.
 * Some records in production have sparse fields, so we use .optional()
 * to accept undefined in addition to null and valid values.
 */
export declare const repositoriesSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    name: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    full_name: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    owner_login: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    description: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    private: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    fork: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    archived: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    disabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    default_branch: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    language: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    topics: z.ZodOptional<z.ZodNullable<z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>>;
    stargazers_count: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    forks_count: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    open_issues_count: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    watchers_count: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    size_kb: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    license_key: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    html_url: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    homepage: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    created_at: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    updated_at: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    pushed_at: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
/**
 * starred stream: simple star records with starred_at timestamp.
 */
export declare const starredSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    full_name: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    language: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    stargazers_count: z.ZodNullable<z.ZodNumber>;
    html_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    starred_at: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * issues stream: issues (and PRs marked as is_pull_request=true).
 * Cursor: updated_at.
 */
export declare const issuesSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    number: z.ZodNullable<z.ZodNumber>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    state: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    state_reason: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    user_login: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    user_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    assignees: z.ZodNullable<z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    labels: z.ZodNullable<z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    milestone_title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    repository_full_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    repository_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    html_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    comments: z.ZodNullable<z.ZodNumber>;
    reactions_total_count: z.ZodNullable<z.ZodNumber>;
    created_at: z.ZodNullable<z.ZodString>;
    updated_at: z.ZodNullable<z.ZodString>;
    closed_at: z.ZodNullable<z.ZodString>;
    is_pull_request: z.ZodBoolean;
    pull_request_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    draft: z.ZodNullable<z.ZodBoolean>;
}, z.core.$strip>;
/**
 * pull_requests stream: PRs with detail fields.
 * Cursor: updated_at.
 */
export declare const pullRequestsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    number: z.ZodNullable<z.ZodNumber>;
    title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    body: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    state: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    state_reason: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    user_login: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    user_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    assignees: z.ZodNullable<z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    labels: z.ZodNullable<z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    milestone_title: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    repository_full_name: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    repository_id: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    html_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    comments: z.ZodNullable<z.ZodNumber>;
    reactions_total_count: z.ZodNullable<z.ZodNumber>;
    created_at: z.ZodNullable<z.ZodString>;
    updated_at: z.ZodNullable<z.ZodString>;
    closed_at: z.ZodNullable<z.ZodString>;
    draft: z.ZodBoolean;
    merged_at: z.ZodNullable<z.ZodString>;
    merged_by_login: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    commits_count: z.ZodNullable<z.ZodNumber>;
    additions: z.ZodNullable<z.ZodNumber>;
    deletions: z.ZodNullable<z.ZodNumber>;
    changed_files: z.ZodNullable<z.ZodNumber>;
    base_ref: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    head_ref: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    requested_reviewers: z.ZodNullable<z.ZodArray<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>>;
    review_comments_count: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/**
 * gists stream: gist metadata + file listing.
 * Cursor: updated_at.
 */
export declare const gistsSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">;
    description: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    public: z.ZodBoolean;
    html_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    files: z.ZodNullable<z.ZodArray<z.ZodObject<{
        filename: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        language: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
        size: z.ZodNullable<z.ZodNumber>;
        raw_url: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "PdppSafeText", "out">>;
    }, z.core.$strip>>>;
    files_truncated: z.ZodBoolean;
    files_total_count: z.ZodNullable<z.ZodNumber>;
    comments_count: z.ZodNullable<z.ZodNumber>;
    created_at: z.ZodNullable<z.ZodString>;
    updated_at: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/**
 * Schema registry: stream name → zod schema.
 */
export declare const SCHEMAS: Record<string, z.ZodTypeAny>;
export declare const validateRecord: import("@pdpp/connector-protocol").ValidateRecord;
//# sourceMappingURL=schemas.d.ts.map