import type { GitHubGist, GitHubIssue, GitHubLabelObj, GitHubPullDetail, GitHubRepo, GitHubStarredEntry, GitHubUser } from "./types.ts";
export declare const API_BASE = "https://api.github.com";
export declare function parseNextLink(link: string | null): string | null;
export declare function labelNames(labels: Array<string | GitHubLabelObj> | undefined): string[];
export declare function assigneeNames(assignees: Array<{
    login?: string;
}> | undefined): string[];
export declare function reviewerLogins(detail: GitHubPullDetail | null): string[];
export declare function repoFullFromUrl(url: string | null | undefined): string | null;
export declare function truncateBody(body: string | null | undefined): string | null;
/**
 * User entity record: stable identity and profile fields only.
 * Sampled metrics (followers, following, public_repos, public_gists) are
 * projected into `user_stats` to avoid creating false entity versions when
 * only counts change. See design: split-point-in-time-observation-streams.
 */
export declare function userRecord(u: GitHubUser): Record<string, unknown>;
/**
 * User stats observation record: sampled metrics keyed by {user_id}:{YYYY-MM-DD}.
 * `observedOn` is the UTC calendar date at the time of the connector run.
 * One record per user per day; same-day re-runs produce the same key (idempotent).
 */
export declare function userStatsRecord(u: GitHubUser, observedOn: string): Record<string, unknown>;
export declare function repoRecord(r: GitHubRepo): Record<string, unknown>;
export declare function starredRecord(entry: GitHubStarredEntry): Record<string, unknown> | null;
export declare function issueRecord(it: GitHubIssue): Record<string, unknown>;
export declare function pullRequestRecord(it: GitHubIssue, detail: GitHubPullDetail | null, repoFull: string | null): Record<string, unknown>;
export declare function gistRecord(g: GitHubGist): Record<string, unknown>;
export declare function laterIso(a: string | null | undefined, b: string | null | undefined): string | null;
export declare function isBeforeSince(iso: string | null | undefined, since: string | null): boolean;
export declare function isAtOrAfterUntil(iso: string | null | undefined, until: string | null): boolean;
//# sourceMappingURL=parsers.d.ts.map