#!/usr/bin/env node
import { type ConnectorHttpGovernor } from "../../src/connector-http-governor.ts";
import { type EmittedMessage } from "../../src/connector-runtime.ts";
interface GithubHttpGovernorOptions {
    restoredIntervalMs?: number;
    retrySleep?: (ms: number) => void | Promise<void>;
}
export declare function createGithubHttpGovernor(options?: GithubHttpGovernorOptions): ConnectorHttpGovernor;
/** Runtime retry classification, including the governor's exhausted 5xx form. */
export declare const GITHUB_RETRYABLE_PATTERN: RegExp;
/** Test-only cap injection; production keeps the bounded default. */
export declare function __setMaxGithubListPages(maxPages: number): void;
interface ProgressExtra {
    count?: number;
    cursor_present?: boolean;
    item_count?: number;
    page_index?: number;
    phase?: string;
    rate_limit_pressure?: number;
    stream?: string;
    total?: number;
    total_seen?: number;
}
export interface StreamCtx {
    emit: (msg: {
        type: "STATE";
        stream: string;
        cursor: unknown;
    } | Extract<EmittedMessage, {
        type: "SKIP_RESULT";
    }> | Extract<EmittedMessage, {
        type: "DETAIL_COVERAGE";
    }>) => Promise<void>;
    emitRecord: (stream: string, data: Record<string, unknown>) => Promise<void>;
    httpGovernor: ConnectorHttpGovernor;
    progress: (message: string, extra?: ProgressExtra) => Promise<void>;
    requested: Map<string, {
        name?: string;
        time_range?: {
            since?: string;
            until?: string;
        };
    }>;
    state: Record<string, unknown>;
    token: string;
    /**
     * Warm-start carrier: when `collectUser` writes the `user` STATE cursor it
     * records the cursor object here so `collect` can re-emit it at run end merged
     * with the FINAL learned pacing interval — persisting the rate the controller
     * settled on after the whole run, not the early-run rate. Undefined when `user`
     * was not collected (warm-start simply does not persist this run).
     */
    userCursor?: Record<string, unknown>;
}
export declare function collectUser(ctx: StreamCtx): Promise<void>;
export declare function collectRepositories(ctx: StreamCtx): Promise<void>;
export declare function collectStarred(ctx: StreamCtx): Promise<void>;
export declare function collectIssues(ctx: StreamCtx): Promise<void>;
/**
 * Per-year `created:` windows from the current year back to `floorYear`,
 * descending (newest first, matching the single-query `order=desc` shape).
 * `floorYear` is the user's account-creation year — no authored PR predates
 * the account. Exported for unit testing the window math without a network.
 */
export declare function prCreatedWindows(currentYear: number, floorYear: number): Array<{
    from: string;
    to: string;
}>;
/** Year of an ISO timestamp, or null when absent/unparseable. */
export declare function isoYear(iso: string | null | undefined): number | null;
export declare function collectPullRequests(ctx: StreamCtx): Promise<void>;
/**
 * Resolve the search windows to drain. Incremental runs (a `since` bound is
 * present) return a single unwindowed query (`[undefined]`); the updated-since
 * set is rarely over the cap. A full resync returns one `created:` window per
 * year from now back to the account-creation year so each stays under the cap.
 * `now`/`accountCreatedAt` are explicit so the windowing is testable without
 * wall-clock dependence.
 */
export declare function resolvePrSearchWindows(sinceParam: string | null, accountCreatedAt: string | null | undefined, now?: Date): Array<{
    from: string;
    to: string;
} | undefined>;
export declare function collectGists(ctx: StreamCtx): Promise<void>;
export {};
//# sourceMappingURL=index.d.ts.map