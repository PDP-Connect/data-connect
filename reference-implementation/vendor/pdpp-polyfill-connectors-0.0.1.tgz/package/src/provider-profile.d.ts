/**
 * ProviderProfile — the single declared home for every provider-specific
 * safety- / pressure- / terminal-shaped quantity (SLVP-ideal spec §3, §9-C5).
 *
 * THE RULE (spec §3 rule 6): "lift every provider-specific quantity out of
 * shared defaults into a required `ProviderProfile` that each connector author
 * must declare from THEIR OWN provider's observed behavior. No shared default
 * for a safety- or pressure-shaped quantity — a missing field is a build error,
 * not a silent borrow of ChatGPT's number."
 *
 * This file is the ONE source of truth for that field set. The three control
 * loops that consume it each take their slice as a NON-OPTIONAL argument so a
 * connector wired onto a loop without a declared profile fails at the type
 * boundary (the governor's `pacingMinIntervalMs`) or at a loud startup assertion
 * (`maybeTerminateGap` throws; the cooldown escalation no-ops on an absent
 * value). See the per-field notes below for which mechanism pins which field.
 *
 * WHY THESE FIELDS (and not the cosmetic knobs): a field belongs here iff
 * getting it wrong off the wrong provider's numbers risks a ban, a stall, or a
 * dishonest health verdict — i.e. it is safety-, pressure-, or terminal-shaped.
 * Discovery seeds, burst-tolerance, and AIMD horizons are derived/cosmetic and
 * stay shared-defaulted in the loop primitives; they are NOT forced here.
 *
 * Audit status (§9-C5): the FIELD SET and ChatGPT's values are
 * observation-backed (live ChatGPT probes 2026-06). The other five governor-using
 * connectors (github/notion/oura/spotify/ynab) now each carry an AUDITED
 * pacing ceiling derived from THAT provider's documented rate limit — the WI-1b
 * per-connector behavioral audit. Each value traces to a provider doc URL in its
 * factory below; the derivation (documented sustained rate → chosen ceiling +
 * safety margin) is recorded in
 * docs/research/per-connector-rate-profiles-2026-06-13.md. None of the five emit
 * detail gaps, so none declares a terminal-gap (§10-A) or cooldown (§10-B)
 * profile — they legitimately use the safe shared defaults (see that doc).
 *
 * Ref: docs/research/slvp-ideal-whole-system-spec-2026-06-11.md §3, §9-C5, §10
 *      docs/research/per-connector-rate-profiles-2026-06-13.md (WI-1b derivations)
 */
/**
 * The pacing slice every governor-using (API) connector MUST declare. This is
 * the compile-time-enforced part of the profile: it is a required field on
 * {@link ConnectorHttpGovernorOptions}, so `createConnectorHttpGovernor({ name })`
 * with no profile is a `tsc` error — the spec's "missing field = build error".
 */
export interface ProviderPacingProfile {
    /**
     * THE ONE OWNER NUMBER: the rate ceiling — the fastest inter-request interval
     * (= maximum sustained rate) the AIMD additive-increase loop may ever reach.
     * Required, NO cross-provider default (spec §3): ChatGPT's account-tuned 250ms
     * is meaningless for a provider that sends Retry-After or rate-limits by
     * slowdown rather than 429. Each connector author authors this below their
     * provider's observed behavioral flagging threshold.
     */
    readonly pacingMinIntervalMs: number;
}
/**
 * The terminal-gap slice (spec §10-A). Consumed by the JS terminal-gap
 * classifier (`reference-implementation/server/stores/terminal-gap-classifier.js`),
 * which is enforced at runtime: `maybeTerminateGap` THROWS when this field is
 * absent (a JS seam, so the honest equivalent of a build error is a loud startup
 * throw + the conformance test). A connector with NO declared terminal profile
 * is simply never terminalized — its fillable gaps stay `pending`, never silently
 * borrowing ChatGPT's attempt budget.
 */
export interface ProviderTerminalGapProfile {
    /**
     * Bounded recovery-attempt budget: after this many `in_progress` attempts
     * against a NON-transient error (404/410/permanent-403/401), a gap transitions
     * `pending → terminal`. Per-provider — retrying a deleted resource is pure
     * waste, and the right budget depends on the provider's own error semantics.
     */
    readonly maxRecoveryAttempts: number;
}
/**
 * The cross-run cooldown slice (spec §10-B). Consumed by
 * `reference-implementation/runtime/scheduler-source-pressure-cooldown.ts`.
 * Enforced softly: an absent value disables the no-progress escalation
 * (`recommendedHealthState` never reaches `needs_attention`) rather than
 * borrowing ChatGPT's cycle budget.
 */
export interface ProviderCooldownProfile {
    /**
     * No-progress escalation ceiling: after this many consecutive cooldown cycles
     * with ZERO forward progress and ZERO gap recovery, the connection escalates
     * `cooling_off → needs_attention` (the dead-but-429ing provider). Per-provider —
     * it is derived from the provider's observed recovery-window length.
     */
    readonly maxCooldownCycles: number;
}
/**
 * The full declared ProviderProfile. A connector author declares ONE of these
 * from their own provider's observed behavior; the three control loops each pull
 * their slice. Fields beyond the three slices above (e.g. 429 pressure semantics,
 * quota unit) are named in spec §3 as future profile fields and tracked in the
 * `generalize-adaptive-collection-governor` change (task 1b) — they are NOT yet
 * consumed by a loop, so adding them here without a consumer would be dead
 * declaration. They are listed in the spec, not stubbed here.
 */
export interface ProviderProfile extends ProviderPacingProfile, ProviderTerminalGapProfile, ProviderCooldownProfile {
}
/**
 * GitHub — 1000ms (60 req/min). Documented primary limit: 5,000 requests/hour for
 * authenticated users (=720ms / ~83 req/min at the limit); 1000ms is ~72% of that
 * ceiling. Read-only, single-threaded, so the secondary content-creation /
 * concurrency limits do not bind.
 * Doc: https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api
 */
export declare function githubPacingProfile(): ProviderPacingProfile;
/**
 * Notion — 500ms (120 req/min). Documented limit: an average of 3 requests/second
 * per integration, bursts allowed (=333ms / 180 req/min at the average); 500ms is
 * 2 req/s = ~67% of the documented average, sitting under the average (not just
 * the burst peak).
 * Doc: https://developers.notion.com/reference/request-limits
 */
export declare function notionPacingProfile(): ProviderPacingProfile;
/**
 * Oura — 250ms (240 req/min). Documented limit: 5,000 requests per 5-minute window
 * (=16.67 req/s, 60ms / ~1000 req/min at the limit); 250ms is 4 req/s = ~24% of
 * that ceiling — a deliberate 4× margin (we do not push to the 60ms hardware
 * ceiling: daily-grain wellness data does not need 1000 req/min and the wide
 * margin guards an undocumented per-account throttle).
 * Doc: https://cloud.ouraring.com/docs/error-handling
 */
export declare function ouraPacingProfile(): ProviderPacingProfile;
/**
 * Spotify — 500ms (120 req/min). Spotify computes its limit over a rolling 30s
 * window and does NOT publish the exact request count (it differs by app mode);
 * the commonly-observed development-mode figure is ~180 req/min (=333ms at the
 * cited rate). 500ms is ~67% of that — margin-heavy on purpose because the true
 * limit is undisclosed; the connector honors Retry-After on 429.
 * Doc: https://developer.spotify.com/documentation/web-api/concepts/rate-limits
 */
export declare function spotifyPacingProfile(): ProviderPacingProfile;
/**
 * YNAB — 20000ms (3 req/min). Documented limit: 200 requests per hour per access
 * token over a rolling 1-hour window (=0.0556 req/s, 18000ms / ~3.33 req/min
 * sustained). 20000ms is set BELOW that sustained rate so even a long run stays
 * under the 200/hr budget at the ceiling. A typical YNAB run is only tens of
 * requests (~7×budgets + one per walked month), so it finishes in a minute or two
 * far under budget; the conservative ceiling only binds a pathological run.
 * Doc: https://api.ynab.com/ (Usage → Rate Limiting)
 */
export declare function ynabPacingProfile(): ProviderPacingProfile;
/**
 * Slack (direct Web API calls for `stars.list`, `usergroups.list`,
 * `reminders.list`, `conversations.info`) — 3000ms (20 req/min). This governor
 * covers ONLY the four gap streams the archive-based collection cannot reach
 * (see openspec/changes/complete-slack-bundled-connector-coverage); it does not
 * pace slackdump's own subprocess calls. Slack's tiered rate limits put
 * `usergroups.list`/`reminders.list` at Tier 2 (20+ req/min = 3000ms) and
 * `stars.list`/`conversations.info` at Tier 3 (50+ req/min, faster); 3000ms is
 * set at the binding (slowest) Tier 2 floor across the four methods since one
 * governor call site paces all of them, not per-method.
 * Doc: https://docs.slack.dev/apis/web-api/rate-limits/,
 * https://docs.slack.dev/reference/methods/usergroups.list,
 * https://docs.slack.dev/reference/methods/reminders.list
 */
export declare function slackApiPacingProfile(): ProviderPacingProfile;
/**
 * Steam — 250ms (4 req/s, matching Oura). Steam Web API publishes no official
 * numeric rate limits on https://partner.steamgames.com/doc/webapi_overview/auth
 * or https://partner.steamgames.com/doc/webapi/iplayerservice (confirmed primary
 * sources 2026-08-07). Community reports document multi-hour 403 lockouts from
 * sustained high-frequency use, but no published threshold. Per PDPP policy:
 * when an undocumented provider has no numeric limit, use the least restrictive
 * existing operational ceiling (Oura's 250ms, proven safe in production), paired
 * with adaptive backoff (AIMD) to reduce rate on any 429/403 response. This lets
 * the governor accelerate under success and retreat on throttling, converging to
 * the provider's actual (undocumented) threshold without guessing. The manifest's
 * 1-hour polling interval is a separate conservative choice (infrastructure, not
 * API pacing). A 5-endpoint first run at 250ms ceiling takes 1.25s + network
 * latency; adaptive backoff will slow if Steam signals throttling.
 * Derived 2026-08-07: no published limit, use policy default.
 */
export declare function steamPacingProfile(): ProviderPacingProfile;
export declare function google_calendarPacingProfile(): ProviderPacingProfile;
export declare function google_contactsPacingProfile(): ProviderPacingProfile;
/**
 * GroupMe — 1000ms (60 req/min). GroupMe's API v3 documentation does not publish
 * exact rate limits. A one-second floor avoids bursts without turning a 41-chat
 * account into a half-hour scan. The shared governor still honors Retry-After and
 * backs off on 429/5xx responses, so provider feedback remains authoritative.
 * Doc: https://dev.groupme.com/docs/v3 (rate limits not specified)
 */
export declare function groupmePacingProfile(): ProviderPacingProfile;
/**
 * Jellyfin — PDPP operational default (100ms shared backoff, no invented limits).
 * Jellyfin is self-hosted with no published rate limits. We use PDPP's default
 * responsive pacing rather than inventing conservative figures. A typical run
 * fetches one /System/Info probe + one /Users/{id}/Views call + paginated
 * /Users/{id}/Items calls (500 items/page), totaling ~10-20 requests per run,
 * well within any self-hosted capacity. Honors Retry-After headers if returned.
 * Reference: Authority doc §10 (Jellyfin v10.11.11, self-hosted, no documented limits).
 */
export declare function jellyfinPacingProfile(): ProviderPacingProfile;
//# sourceMappingURL=provider-profile.d.ts.map