export interface PolyfillManifestEntry {
    file: string;
    manifest: unknown;
}
/** Every `*.json` file directly under this package's `manifests/` directory (or the test override), parsed. */
export declare function readPolyfillManifests(): PolyfillManifestEntry[];
//# sourceMappingURL=manifest-registry.d.ts.map