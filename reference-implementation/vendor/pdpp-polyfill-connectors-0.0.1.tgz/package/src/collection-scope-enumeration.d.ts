/** The owner-declared boundary, as connectors consume it. */
export interface EnumerationScope {
    readonly since?: string | null;
    readonly source_roots?: readonly string[] | null;
}
/**
 * Whether `candidate` is inside (or exactly equal to) `root`, by whole segments.
 *
 * Also true when the candidate is a PARENT of the root: a walker must be allowed
 * to descend through `a/` to reach the selected root `a/b/c`. Callers that mean
 * "is this leaf selected" should use {@link isPathWithinSourceRoots}, which does
 * not admit parents.
 */
export declare function pathContainsOrIsWithin(root: string, candidate: string): boolean;
/**
 * Whether a concrete source path falls inside at least one declared root.
 *
 * With no roots declared, every path is in scope — an absent boundary is not a
 * boundary. A path that merely CONTAINS a root (i.e. is an ancestor of it) is
 * not itself selected; use {@link shouldDescendIntoDirectory} while walking.
 */
export declare function isPathWithinSourceRoots(candidate: string, scope: EnumerationScope | null | undefined): boolean;
/**
 * Whether a walker should descend into a directory at all.
 *
 * True when the directory is inside a declared root OR is an ancestor on the way
 * to one. Everything else is pruned before its contents are ever listed, which
 * is where the I/O saving actually comes from.
 */
export declare function shouldDescendIntoDirectory(directory: string, scope: EnumerationScope | null | undefined): boolean;
export declare function dateDirectoryInRange(parts: {
    readonly day?: string | null;
    readonly month?: string | null;
    readonly year: string;
}, scope: EnumerationScope | null | undefined): boolean;
/**
 * Whether a flattened project-directory name denotes a path inside a declared
 * root.
 *
 * Claude Code stores each project under `~/.claude/projects/` as a single
 * directory whose name is the project's absolute path with the separators
 * replaced by `-` (e.g. `/home/u/code/pdpp` -> `-home-u-code-pdpp`). An owner
 * declaring a root types the natural thing — `/home/u/code/pdpp` — so matching
 * their input against the raw flattened name would find nothing and silently
 * collect an empty set.
 *
 * Decoding the name back to a path is impossible: `-` is also a legal character
 * inside a real directory name, so `-a-b` is ambiguous between `/a/b` and
 * `/a-b`. Encoding the ROOT is not ambiguous, so the comparison runs in that
 * direction instead.
 *
 * Two encodings are accepted because both appear in real corpora and the choice
 * is a Claude Code version detail, verified against a live `~/.claude/projects`
 * of 2,347 directories: `/home/u/.tmp/x` appears as `-home-u--tmp-x` (dot folded
 * into `-`) while `/home/u/code/p/.claude/worktrees/w` appears as
 * `...-p-.claude-worktrees-w` (dot preserved). Accepting either is the sound
 * direction: rejecting one would silently exclude real projects.
 *
 * A bare relative root (no separator, e.g. `pdpp`) is matched as a trailing
 * path SEGMENT, so an owner can name a project without typing its full path.
 * The match is still segment-anchored — `pdpp` does not select `pdpp-secrets` —
 * because the encoded form is compared on `-` boundaries, not by substring.
 */
export declare function projectDirMatchesSourceRoots(projectDir: string, scope: EnumerationScope | null | undefined): boolean;
/**
 * Stable fingerprint of the boundary a run enumerated under, stamped onto the
 * coverage records so it commits with the evidence it qualifies.
 *
 * MUST stay byte-identical to the runner's `collectorScopeFingerprint` and the
 * contract's `collectionScopeFingerprint` -- the server compares them to decide
 * whether stored proof still describes the declared scope, so drift would
 * silently invalidate valid proof or validate stale proof. `unscoped` is a real
 * value: a full pass is a declared boundary too.
 */
export declare function enumerationScopeFingerprint(scope: EnumerationScope | null | undefined): string;
/**
 * Whether the declared boundary bounds enumeration at all.
 *
 * Lets a connector report honestly that a run was enumeration-bounded rather
 * than merely emission-filtered — the distinction this whole module exists for.
 */
export declare function scopeBoundsEnumeration(scope: EnumerationScope | null | undefined): boolean;
/**
 * Read the boundary a connector should enforce out of its requested stream
 * scopes.
 *
 * Connectors receive `requested` from the runtime; the boundary is carried on
 * the stream scopes the runtime already threads through, so no new channel and
 * no connector-specific config is needed. `source_roots` rides alongside
 * `time_range` on the same scope entry.
 */
export declare function readEnumerationScope(requested: ReadonlyMap<string, {
    readonly source_roots?: unknown;
    readonly time_range?: {
        since?: string;
    };
}>, streams: readonly string[]): EnumerationScope | null;
//# sourceMappingURL=collection-scope-enumeration.d.ts.map