import type { BrowserContext, Page } from "playwright";
/** Minimal structural type that detectCloudflareChallenge requires from a page. */
export interface CloudflarePage {
    locator: (selector: string) => {
        count: () => Promise<number>;
    };
    title: () => Promise<string>;
}
/** Minimal structural type that detectCloudflareChallenge requires from a navigation response. */
export interface CloudflareNavResponse {
    headers: () => Record<string, string>;
    status: () => number;
}
/**
 * Passive probes the bootstrap flow uses to detect whether a given platform's
 * session is live in the shared browser profile. Each probe opens its
 * `probeUrl` and calls `isLoggedIn(page, context)` — if that returns true,
 * the bootstrap UI marks it as ok and moves on.
 *
 * Keep probes read-only. Never submit forms, never navigate elsewhere mid-
 * probe. The connectors themselves (not this file) do the real auth work.
 */
export interface PlatformProbe {
    bootstrapUrl: string;
    isLoggedIn: (page: Page, context: BrowserContext) => Promise<boolean>;
    label: string;
    probeUrl: string;
}
/**
 * A single observed Cloudflare-challenge signal. Each is an independently
 * sufficient marker of a real Cloudflare interstitial / Turnstile challenge.
 */
export type CloudflareSignal = "title_just_a_moment" | "cf_challenge_dom" | "challenge_platform_script" | "turnstile_iframe" | "cf_mitigated_header" | "http_403_cf";
export interface CloudflareVerdict {
    /** "confirmed" when isChallenge, else "none" — so callers never GUESS. */
    confidence: "confirmed" | "none";
    /** True iff at least one real Cloudflare-challenge signal was observed. */
    isChallenge: boolean;
    /** The specific signals that fired (for honest, legible diagnostics). */
    signals: CloudflareSignal[];
}
/**
 * Connector-AGNOSTIC detection of a Cloudflare bot challenge (the "Just a
 * moment…" interstitial / Turnstile "Verify you are human"). Browser connectors
 * (ChatGPT, Reddit, Amazon, …) all hit the same wall; before this, each GUESSED
 * "possibly Cloudflare challenge" purely from "expected login inputs not found"
 * — right by luck at best, and mislabeling ordinary UI drift at worst. This
 * earns the diagnosis from real artifacts so the operator-facing message,
 * interaction reason, and posture are honest.
 *
 * READ-ONLY by contract (matches this file's probe doctrine): it inspects title,
 * DOM, and the optional navigation response — it NEVER clicks, types, navigates,
 * or attempts to solve the Turnstile (auto-solving would risk the account and is
 * exactly the bot behavior the challenge exists to stop).
 *
 * Pass `opts.navResponse` (the Response from the goto/navigation that landed on
 * the suspect page) to additionally consult Cloudflare response headers/status.
 */
export declare function detectCloudflareChallenge(page: CloudflarePage, opts?: {
    navResponse?: CloudflareNavResponse | null;
}): Promise<CloudflareVerdict>;
export declare const PLATFORMS: Record<string, PlatformProbe>;
//# sourceMappingURL=platform-probes.d.ts.map