/**
 * Explicit allowlist of connectors that declare manifest streams but do NOT yet
 * wire emit-time record validation (`validateRecord` / `makeValidateRecord`).
 *
 * This is the machine-checked successor to the green-prep audit's prose
 * inventory (`tmp/workstreams/ri-connector-schema-green-prep-audit-report.md`,
 * finding F1). The construction rule it backs lives in OpenSpec
 * `polyfill-runtime`: "Connectors declaring manifest streams SHALL validate
 * emitted records or be on a justified schemaless allowlist."
 *
 * The gate test (`connector-schema-validation-honesty.test.ts`) cross-checks
 * this list against the tree in BOTH directions every CI run:
 *   - a connector with manifest streams and no `validateRecord` that is NOT
 *     here fails the build (no silent schemaless drift);
 *   - a connector listed here that HAS started wiring `validateRecord` also
 *     fails the build, forcing its entry to be removed.
 *
 * Therefore this list can only shrink. Each schema authored under audit Lanes
 * A–C must delete the corresponding entry. When the map is empty, every
 * stream-declaring connector validates its records and this module can be
 * removed.
 *
 * Adding an entry is a deliberate, reviewed act — it is the documented escape
 * hatch, not a default. A new connector validates by default.
 */
export type SchemalessJustification = string;
export declare const SCHEMALESS_CONNECTOR_ALLOWLIST: Readonly<Record<string, SchemalessJustification>>;
//# sourceMappingURL=connector-schema-allowlist.d.ts.map