import type { DetailGapStartEntry, EmittedMessage, RecordData, ValidateRecord } from "./connector-runtime.ts";
/** A record that passed (or bypassed) shape-check and would flow
 *  downstream as a RECORD in production. */
export interface EmittedRecord {
    data: RecordData;
    stream: string;
}
/** A record that failed shape-check — the runtime would convert this
 *  to a SKIP_RESULT. Tests can assert on `.skipped` to catch fixture
 *  drift. */
export interface SkippedRecord {
    issues: Array<{
        message: string;
        path: string;
    }>;
    stream: string;
}
/** A single event in the unified call-order trace. `.events` interleaves
 *  emitRecord() calls and emit() calls in the order the helper made
 *  them. Needed when a test has to prove something like "STATE emitted
 *  AFTER the last RECORD" — the separate `.emitted` / `.protocolMessages`
 *  arrays can't express cross-kind ordering because they're two lists
 *  with no shared sequence. */
export type RecordedEvent = {
    kind: "record";
    stream: string;
    data: RecordData;
    skipped: false;
} | {
    kind: "record-skipped";
    stream: string;
    issues: Array<{
        message: string;
        path: string;
    }>;
    skipped: true;
} | {
    kind: "message";
    message: EmittedMessage;
};
export interface RecordingEmit {
    emit: (msg: EmittedMessage) => Promise<void>;
    emitRecord: (stream: string, data: RecordData) => Promise<void>;
    emitted: EmittedRecord[];
    /** Unified time-ordered trace of every emit() and emitRecord() call,
     *  in invocation order. Use this when the assertion is cross-kind
     *  ordering (e.g. "STATE lands after the last RECORD"). */
    events: RecordedEvent[];
    protocolMessages: EmittedMessage[];
    skipped: SkippedRecord[];
}
export interface ConnectorSubprocessResult {
    code: number | null;
    messages: EmittedMessage[];
    /** Peak resident set size (bytes) sampled from /proc/<pid>/status while
     *  the child ran, at `peakRssPollIntervalMs` resolution. `null` when
     *  `peakRssPollIntervalMs` was not requested, or on a platform without
     *  /proc (non-Linux) — callers that need this proof should assert it is
     *  non-null rather than silently skip on an unsupported platform, so a
     *  CI environment that can't run the check is visible, not silently
     *  green. A sampled peak (not a V8 heap-limit flag): --max-old-space-size
     *  only bounds the V8-managed heap, NOT Buffer/ArrayBuffer allocations
     *  (Buffers live in Node's external/arrayBuffers memory) — the exact
     *  allocation shape a whole-file readFile()/ZipEntry.data() produces. RSS
     *  sampling has no such blind spot: it measures real process memory
     *  regardless of which allocator produced it. */
    peakRssBytes: number | null;
    rawStdout: string;
    signal: NodeJS.Signals | null;
    stderr: string;
}
export interface ConnectorSubprocessOptions {
    allowFailedDone?: boolean;
    cwd: string;
    entrypoint: string;
    env?: NodeJS.ProcessEnv;
    /** When set, poll /proc/<pid>/status at this interval (ms) for VmRSS and
     *  report the peak via the result's `peakRssBytes`. Opt-in: the extra
     *  poll timer is pure overhead for the many tests that don't need a
     *  memory proof. */
    peakRssPollIntervalMs?: number;
    start: {
        /** Mirrors the real runtime's START `collection_mode` field, so a test can
         *  exercise the owner-triggered full-refresh bypass end to end rather than
         *  reaching past the wire to construct a CollectContext by hand. */
        collection_mode?: "full_refresh" | "incremental";
        /** Currently-pending detail gaps to replay on START, mirroring the real runtime's `detail_gaps` field. */
        detail_gaps?: readonly DetailGapStartEntry[];
        scope: {
            streams: Array<{
                name: string;
                resources?: string[];
                time_range?: {
                    since?: string;
                    until?: string;
                };
            }>;
        };
        state?: Record<string, unknown>;
        type: "START";
    };
    timeoutMs?: number;
}
/**
 * Returns an emit/emitRecord pair that validates records through
 * `validateRecord`. Records that pass land in `.emitted`; records that
 * fail land in `.skipped` (same semantics as the runtime's RECORD
 * shape-check). The `.emit` side-channel records any direct protocol
 * messages (PROGRESS, STATE, SKIP_RESULT, INTERACTION) the helper
 * under test emits.
 *
 * If `validateRecord` is omitted, `emitRecord` is pass-through — useful
 * for tests where the helper is a pure function and the shape-check
 * isn't the point (e.g. scope-filter gates, ordering invariants on
 * synthetic data that intentionally omits fields).
 */
export declare function makeRecordingEmit(validateRecord?: ValidateRecord): RecordingEmit;
/**
 * Run a connector entrypoint as a real child process and drive the
 * Collection Profile protocol over stdio. Unlike `makeRecordingEmit`,
 * this proves START parsing, stdout JSONL framing, DONE emission, and
 * process exit behavior without importing the connector module directly.
 */
export declare function runConnectorProtocolSubprocess(options: ConnectorSubprocessOptions): Promise<ConnectorSubprocessResult>;
//# sourceMappingURL=test-harness.d.ts.map