// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
const BUNDLED_STATIC_SECRET_CREDENTIAL_KINDS = new Set([
    "secret_bundle",
    "username_password",
]);
const FULLY_BUNDLED_STATIC_SECRET_CREDENTIAL_KINDS = new Set(["secret_bundle"]);
export function isBundledStaticSecretCredentialKind(kind) {
    return BUNDLED_STATIC_SECRET_CREDENTIAL_KINDS.has(kind);
}
/** True when every capture field, not only secret fields, is sealed into the credential bundle. */
export function isFullyBundledStaticSecretCredentialKind(kind) {
    return FULLY_BUNDLED_STATIC_SECRET_CREDENTIAL_KINDS.has(kind);
}
/** Thrown when a manifest's `credential_capture` violates the shared contract this module enforces. */
export class StaticSecretCredentialCaptureError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.name = "StaticSecretCredentialCaptureError";
        this.code = code;
    }
}
function cleanString(value) {
    return typeof value === "string" && value.trim().length > 0
        ? value.trim()
        : null;
}
function normalizeFieldType(raw) {
    const rawType = cleanString(raw.type)?.toLowerCase();
    if (rawType === "email" || rawType === "password" || rawType === "text") {
        return rawType;
    }
    // `type: "password"` implies secrecy even without an explicit `secret:
    // true` — a manifest author writing a password-shaped field is declaring
    // intent to capture a secret, and treating that as non-secret is the exact
    // shape that let a manifest satisfy setup's classifier while being invisible
    // to runtime injection.
    if (raw.secret === true) {
        return "password";
    }
    return "text";
}
function normalizeField(connectorKey, raw) {
    const name = cleanString(raw?.name);
    if (!name) {
        return null;
    }
    const type = normalizeFieldType(raw);
    const secret = raw.secret === true || type === "password";
    const label = cleanString(raw?.label);
    if (!label) {
        if (secret) {
            throw new StaticSecretCredentialCaptureError("static_secret_field_label_required", `Connector '${connectorKey}' credential_capture field '${name}' is a secret field (secret:true or ` +
                'type:"password") with no label. label is contract-required for a secret field: it is the copy the ' +
                "owner sees when sealing this credential, and a secret field with no presentation copy would classify " +
                "as static-secret for runtime injection while being unable to render a capture form for setup, or vice " +
                "versa. Add a label to this field in the manifest.");
        }
        return null;
    }
    const env = Array.isArray(raw.env)
        ? raw.env.filter((value) => cleanString(value) !== null)
        : [];
    if (secret && env.length === 0) {
        throw new StaticSecretCredentialCaptureError("static_secret_field_env_required", `Connector '${connectorKey}' credential_capture field '${name}' is a secret field with zero env aliases. ` +
            "A secret field with no env var name(s) can never be injected at runtime — add at least one entry to " +
            'this field\'s env array in the manifest, or remove secret:true/type:"password" if it is not actually a ' +
            "secret.");
    }
    return {
        autocomplete: cleanString(raw.autocomplete),
        description: cleanString(raw.description),
        env,
        helpText: cleanString(raw.help_text),
        helpUrl: cleanString(raw.help_url),
        identity: raw.identity === true,
        label,
        name,
        placeholder: cleanString(raw.placeholder),
        required: raw.required !== false,
        secret,
        type,
    };
}
/**
 * Normalizes one manifest's `setup.credential_capture` block. Returns `null`
 * when the manifest has no credential_capture, no declared kind, or no
 * secret field (i.e. it is not a static-secret connector at all) — those are
 * absence-of-declaration, not malformed-declaration, so they are not errors.
 *
 * Throws `StaticSecretCredentialCaptureError` when a field IS declared secret
 * but violates the contract both setup and runtime injection depend on
 * (missing label, zero env aliases) — see the module doc for why these fail
 * loud instead of silently dropping the field or the connector.
 *
 * `connectorKey` is used only for diagnostic messages; it does not affect
 * classification (a connector never needs special-casing here — see the
 * module doc).
 */
export function normalizeStaticSecretCredentialCapture(connectorKey, capture) {
    if (!capture || typeof capture !== "object") {
        return null;
    }
    const kind = cleanString(capture.credential_kind) ?? cleanString(capture.kind);
    if (!kind) {
        return null;
    }
    const fields = Array.isArray(capture.fields)
        ? capture.fields
            .map((field) => normalizeField(connectorKey, field))
            .filter((field) => field !== null)
        : [];
    if (!fields.some((field) => field.secret)) {
        return null;
    }
    return {
        description: cleanString(capture.description),
        fields,
        kind,
        label: cleanString(capture.label) ?? kind,
        required: capture.required !== false,
        submitLabel: cleanString(capture.submit_label),
    };
}
