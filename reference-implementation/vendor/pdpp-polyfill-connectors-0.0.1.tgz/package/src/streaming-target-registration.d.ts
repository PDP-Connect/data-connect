/**
 * Reference-internal streaming-target registration client.
 *
 * PUTs/DELETEs an interaction-scoped CDP page-target wsUrl, or POSTs a
 * non-CDP target descriptor, against the reference server's
 * `/admin/runs/:runId/interactions/:interactionId/streaming-target`
 * endpoints. Used by the connector runtime / browser binding when it
 * decides which exact page the human should control for a given
 * `manual_action` interaction, so the reference server's streaming
 * companion factory can resolve the live wsUrl by `(runId, interactionId)`
 * when an operator opens a streaming session for that interaction.
 *
 * Boundary: this is reference-runtime orchestration plumbing, NOT a PDPP
 * wire surface (no manifest fields, no connector browser-mode vocabulary). The
 * boundary that exists IS the registration HTTP call across the
 * connector-runtime / reference-server process boundary established by
 * `introduce-local-collector-runner`. See:
 *   - openspec/changes/add-run-interaction-streaming-companion/design-notes/
 *     advisor-response-streaming-process-boundary-2026-05-04.md
 *   - openspec/changes/add-run-interaction-streaming-companion/design-notes/
 *     implementation-decisions-2026-05-04.md
 *
 * Authority: device-exporter bearer auth, same boundary used by
 * `LocalDeviceClient`. We do NOT mint a new credential type — registration
 * piggybacks on the existing local-collector authority. The reference
 * server's per-run nonce path (Mode A, in-process runtime) is also
 * accepted transparently — the same nonce authenticates registrations
 * for any interactionId within its run.
 *
 * Failure mode: every method is best-effort. Network errors, 401/403/4xx
 * from the server, malformed wsUrl — all surface as `false` from
 * `register`/`unregister`. The browser launch and the connector run MUST
 * proceed regardless. The honest consequence of a failed registration is
 * that streaming will not work for that interaction; the records still flow.
 */
declare const REGISTRATION_PATH: (runId: string, interactionId: string) => string;
declare const ALLOWED_CDP_TARGET_HOSTS: Set<string>;
export interface RegistrationLogger {
    /**
     * Best-effort warn channel; we keep the surface intentionally tiny so
     * `console` and pino-style loggers both satisfy the type.
     */
    warn: (message: string, data?: Record<string, unknown>) => void;
}
export interface CreateRegistrationClientOptions {
    /**
     * Reference server base URL — the same value the surrounding collector
     * runner uses when calling `LocalDeviceClient`.
     */
    readonly baseUrl: string;
    /**
     * Device-exporter bearer token, sourced from collector-runner enrollment.
     * Without this, the reference server's `requireDeviceExporterCredential`
     * middleware rejects with 401, so the client should not be constructed
     * at all when the token is absent — let the call site decide.
     */
    readonly deviceToken: string;
    /**
     * Injectable for tests. Defaults to `globalThis.fetch`. Honours the
     * standard `fetch` typing.
     */
    readonly fetch?: typeof fetch;
    /**
     * Optional structured logger. Defaults to a logger that writes to
     * `process.stderr`, since this code runs inside the connector runtime
     * which uses stdio for protocol traffic.
     */
    readonly logger?: RegistrationLogger;
}
interface RegisterMetadataArgs {
    readonly pageTitle?: string;
    /**
     * Optional diagnostic metadata. Forward-compatible: the server accepts,
     * stores, and surfaces these on debug paths but does not consult them
     * for resolution. Useful for "why did the operator see THIS page?"
     * postmortems.
     */
    readonly pageUrl?: string;
    readonly reason?: string;
}
interface BaseRegisterArgs extends RegisterMetadataArgs {
    /**
     * Interaction id (e.g. `int_…`) of the manual_action this page handoff
     * belongs to. The composite `(runId, interactionId)` is the registry key;
     * a single run may host multiple manual_action interactions over its
     * lifetime, each bound to its own page identity.
     */
    readonly interactionId: string;
    /** Stable run id (e.g. `run_…`) shared between connector and server. */
    readonly runId: string;
}
export interface CdpRegisterArgs extends BaseRegisterArgs {
    /**
     * CDP remains the default to preserve existing callers that only pass
     * `wsUrl`.
     */
    readonly backend?: "cdp";
    /**
     * Page-target CDP WebSocket URL. MUST target an allowed local/container
     * CDP host (`127.0.0.1`, `localhost`, or managed n.eko host `neko`) or
     * the registration is short-circuited locally; the server enforces the
     * same constraint.
     */
    readonly wsUrl: string;
}
export type NekoTargetDescriptor = Readonly<Record<string, unknown>>;
export interface NekoRegisterArgs extends BaseRegisterArgs {
    readonly backend: "neko";
    /**
     * Opaque n.eko target descriptor owned by the reference server. It is not
     * a CDP bearer URL, so the client forwards it without CDP wsUrl
     * validation.
     */
    readonly descriptor: NekoTargetDescriptor;
}
/**
 * Legacy CDP registration args. Kept as the CDP-only alias so existing
 * contextual callback types can keep treating `wsUrl` as required.
 */
export type RegisterArgs = CdpRegisterArgs;
export type StreamingTargetRegisterArgs = RegisterArgs | NekoRegisterArgs;
export interface UnregisterArgs {
    readonly interactionId: string;
    readonly runId: string;
}
export interface RegistrationClient {
    /**
     * PUT /admin/runs/:runId/interactions/:interactionId/streaming-target
     *
     * Idempotent: same-value re-PUT for an existing key succeeds silently;
     * different-value PUT replaces the prior value (the server logs a
     * diagnostic warn). Returns true on 2xx, false on any failure
     * (network, HTTP, validation). Never throws.
     */
    register: (args: StreamingTargetRegisterArgs) => Promise<boolean>;
    /**
     * DELETE /admin/runs/:runId/interactions/:interactionId/streaming-target
     * Returns true on 2xx, false on any failure. Never throws. Cleanup is
     * best-effort; a stale record will be evicted by the server's TTL.
     */
    unregister: (args: UnregisterArgs) => Promise<boolean>;
}
/**
 * Construct a registration client bound to a base URL and device token.
 * The client never throws; all errors are logged + returned as `false`.
 */
export declare function createRegistrationClient(options: CreateRegistrationClientOptions): RegistrationClient;
/** Exported for tests that want to validate URL shapes without a server. */
export { ALLOWED_CDP_TARGET_HOSTS, REGISTRATION_PATH };
/**
 * Two env var names exist for the bearer credential the registration
 * client sends to the reference server, one per deployment mode:
 *
 *  - `PDPP_STREAMING_REGISTRATION_TOKEN` — Mode A (in-process runtime).
 *    The reference server's controller mints a per-run nonce at spawn
 *    time and passes it to the connector child. The server-side route
 *    accepts the nonce against a per-run nonce store. There is no
 *    "device" in Mode A — the parent process is the issuing authority.
 *    The same nonce authenticates registrations for any interactionId
 *    that arises during the run.
 *
 *  - `PDPP_LOCAL_DEVICE_TOKEN` — Mode B (collector-runner). A separate
 *    collector process (often on the operator's host) holds a real
 *    device-exporter bearer token and forwards it to the connector
 *    child. The server-side route accepts the token against the
 *    device-exporter authority. The collector boundary is the place
 *    where the device identity is real.
 *
 * The route handler accepts EITHER auth shape transparently; the env
 * var name disambiguates which mode the child is operating in for
 * diagnostics, and lets us evolve the two modes' semantics independently
 * without conflating them in one env namespace.
 */
declare const STREAMING_REGISTRATION_TOKEN_ENV = "PDPP_STREAMING_REGISTRATION_TOKEN";
declare const LOCAL_DEVICE_TOKEN_ENV = "PDPP_LOCAL_DEVICE_TOKEN";
export interface StreamingTargetRegistrationHooks {
    register: (args: StreamingTargetRegisterArgs) => Promise<boolean>;
    readonly runId: string;
    unregister: (args: UnregisterArgs) => Promise<boolean>;
}
/**
 * Resolve optional streaming-target registration hooks from env vars.
 *
 * Returns `undefined` when ANY of the three required pieces (runId,
 * reference base URL, registration bearer token) is missing. This is the
 * "honest no-op" mode: connector runs that aren't spawned with the
 * registration env vars simply skip registration, and operator-side
 * streaming for that run will be unavailable.
 *
 * `interactionId` is intentionally NOT sourced from env: it is per-call
 * runtime context (a single run can have multiple manual_action
 * interactions, each with its own page identity). Callers pass it on
 * each `register()` call.
 *
 * Token precedence: `PDPP_STREAMING_REGISTRATION_TOKEN` wins over
 * `PDPP_LOCAL_DEVICE_TOKEN`. The two correspond to different deployment
 * modes (in-process runtime vs collector-runner) — see the env-var
 * comment block above. Either token is accepted by the server-side route.
 *
 * Why env vars: the runtime entry point is the connector subprocess
 * itself. Whatever spawned it (collector-runner OR in-process runtime)
 * is the right place to pass in `runId` + bearer context. Existing
 * patterns (PDPP_TRACE, PDPP_CAPTURE_FIXTURES, PDPP_BROWSER_HEADLESS) all use
 * the same env-var channel.
 */
export declare function resolveStreamingRegistrationFromEnv(env?: NodeJS.ProcessEnv): Promise<StreamingTargetRegistrationHooks | undefined>;
/** Exported for tests that want to assert env-var precedence. */
export { LOCAL_DEVICE_TOKEN_ENV, STREAMING_REGISTRATION_TOKEN_ENV };
//# sourceMappingURL=streaming-target-registration.d.ts.map