export interface RedactedStderr {
    redacted: boolean;
    text: string;
}
/**
 * Reason tokens the CONNECTOR DECLARED, which `LONG_OPAQUE_RE` must not eat.
 *
 * `LONG_OPAQUE_RE` is an ENTROPY heuristic, not a PII control: it redacts any
 * >=24-char alnum run because raw API keys look like that. Categorical reason
 * tokens look like that too. Production 2026-08-18: HEB connection
 * `cin_c875ca3ec8b6ce2c283a4288` recorded
 * `connector_error_json.message = "heb_session_failed: [REDACTED]"` — the
 * literal string `[REDACTED]` was the entire cause. The eaten token was a
 * PII-free categorical constant (`login_form_never_appeared`, 25 chars);
 * `source_unavailable` (18 chars) survived the same pass. Length, not content,
 * decided which failures stayed diagnosable.
 *
 * Shape alone CANNOT fix this, and that is the load-bearing finding. A tighter
 * "alphabetic snake_case" rule admits `login_form_never_appeared` but also
 * admits `tim_nunamaker_gmail_com` — a personal name is alphabetic snake_case
 * too. No regex separates a declared reason from a name, because the
 * difference is PROVENANCE, not spelling.
 *
 * So the safety property here is DECLARATION, not spelling. A token survives
 * only if the connector declared it ahead of time as part of its reason
 * vocabulary; the declaration is reviewable in the connector's source, where a
 * human can see `login_form_never_appeared` is a constant and would see a name
 * for what it is. Anything undeclared redacts exactly as before, so this can
 * only ever REDUCE what escapes — never widen it.
 */
export interface StderrRedactionOptions {
    readonly declaredReasonTokens?: ReadonlySet<string>;
    /**
     * Credential values this run actually resolved, redacted by IDENTITY
     * wherever they appear — see the module doc for why shape rules cannot do
     * this. Omitted callers get byte-identical behaviour to before.
     *
     * These are the resolved plaintext values, not references to them. The
     * caller already holds them (the runtime injects them into the connector
     * child's environment), so passing them here moves no secret to a place it
     * was not already; it tells redaction what to look for.
     */
    readonly knownSecrets?: Iterable<string>;
}
export declare function redactStderrTail(text: unknown, options?: StderrRedactionOptions): RedactedStderr;
//# sourceMappingURL=stderr-redact.d.ts.map