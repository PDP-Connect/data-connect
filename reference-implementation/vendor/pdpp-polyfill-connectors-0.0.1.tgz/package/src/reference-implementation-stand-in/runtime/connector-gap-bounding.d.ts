/**
 * Sanitize a connector-authored error message before persisting it as
 * `connector_error_message` on a terminal spine event.  The message is
 * connector-authored and therefore untrusted: apply the same redaction
 * as redactStderrTail and cap the length.
 *
 * `declaredReasonTokens` is optional and additive — omitted callers see
 * byte-identical behavior to before. When supplied (see
 * `runtime/declared-reason-tokens.ts`), a token in the set survives
 * `redactStderrTail`'s length-based `LONG_OPAQUE_RE` pass instead of being
 * collapsed to `[REDACTED]` — see that module's doc for why a categorical,
 * connector-declared fault-class name (e.g. `venmo_probe_transport_error`)
 * is not the kind of secret that heuristic exists to catch.
 */
export declare function boundConnectorErrorMessage(value: unknown, declaredReasonTokens?: ReadonlySet<string>): string | null;
/**
 * Validate a connector-declared `error.code` before it is copied verbatim
 * onto `connector_error_code` (see `buildTerminalConnectorFields` below).
 * Unlike `boundConnectorErrorMessage`, this does NOT redact/truncate —
 * `code` is a typed, non-secret channel by contract, so anything that
 * doesn't already match the strict charset/length is untrustworthy and
 * dropped (fails closed to `null`) rather than passed through in any form.
 * A dropped code still leaves the (redacted) `message` field for the owner
 * to read — this only withholds the free-form value from the unredacted
 * column, it never surfaces it elsewhere.
 */
export declare function boundConnectorErrorCode(value: unknown): string | null;
//# sourceMappingURL=connector-gap-bounding.d.ts.map