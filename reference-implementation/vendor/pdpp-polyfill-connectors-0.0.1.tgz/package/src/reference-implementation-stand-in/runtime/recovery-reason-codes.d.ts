/**
 * RI-owned generic recovery reason vocabulary: the finite set of connector-neutral
 * codes that recovery-decision.ts classifies as normalized recovery classes.
 * This module has no external dependencies, allowing test packages to import
 * the authoritative reason set without pulling in server-side modules (auth, CIMD, etc.)
 * that have incompatible lib typings.
 *
 * This is the single source of truth for generic recovery codes.
 * display-messages.ts checks that all codes here have vetted copy.
 * recovery-decision.ts imports from here to classify reasons.
 * The connector test imports from here to check connector-emitted codes.
 */
/** Codes indicating source pressure rather than a connector defect. */
export declare const PROVIDER_PRESSURE_REASONS: ReadonlySet<string>;
/**
 * Codes requiring owner re-authentication (auth failure, credential expiry).
 */
export declare const OWNER_REQUIRED_REASONS: ReadonlySet<string>;
/**
 * Codes indicating connector/system defects or permanent unavailability.
 */
export declare const CONNECTOR_DEFECT_REASONS: ReadonlySet<string>;
/**
 * Informational, non-recoverable reason codes (user disabled, out of scope).
 */
export declare const INFORMATIONAL_RECOVERY_REASONS: ReadonlySet<string>;
/**
 * Complete set of RI-owned generic reason codes.
 * Test code (`reason-display-messages.test.ts`) imports this to verify all
 * connector-emitted reasons have display copy. display-messages.ts uses this
 * to verify all codes have corresponding vetted copy.
 */
export declare const RUNTIME_GENERIC_REASON_CODES: ReadonlySet<string>;
//# sourceMappingURL=recovery-reason-codes.d.ts.map