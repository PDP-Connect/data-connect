export interface NtfyAction {
    action: string;
    clear?: boolean;
    label: string;
    url: string;
}
export interface NtfyOptions {
    actions?: readonly NtfyAction[];
    clickUrl?: string;
    message: string;
    priority?: "default" | "low" | "high" | "urgent";
    tags?: readonly string[];
    title?: string;
}
export interface NtfyResult {
    error?: string;
    id?: string;
    ok?: boolean;
    skipped?: boolean;
    status?: number;
}
export declare function notify(opts: NtfyOptions): Promise<NtfyResult>;
export interface InboxItemNotice {
    connector_id: string;
    kind: string;
    message?: string;
}
export declare function notifyInboxItem(item: InboxItemNotice): Promise<NtfyResult>;
export interface OvernightSummary {
    counts?: Record<string, string | number>;
    failures?: readonly string[];
    ok: boolean;
}
export declare function notifyOvernightSummary({ ok, counts, failures, }: OvernightSummary): Promise<NtfyResult>;
//# sourceMappingURL=ntfy.d.ts.map