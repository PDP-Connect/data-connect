// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import test from "node:test";
import type { EmittedMessage } from "@pdpp/connector-protocol";
import type { BrowserContext, Page } from "playwright";
import {
	type BrowserLaunchSource,
	type BrowserRuntimeVisibility,
	buildDetailCoverageMessage,
	buildDetailGap,
	captureBrowserPage,
	closeBrowserContextPagesExcept,
	closeBrowserPage,
	composeNormalizedTerminalError,
	createConnectorFailure,
	decorateBrowserManualAction,
	describeUnexpectedFailure,
	emitDetailCoverage,
	emitDetailGap,
	type InteractionRequest,
	isContextDisconnected,
	isReusableBrowserRunPage,
	makeBrowserInteractionKeepalive,
	makeTracer,
	resolveBrowserLaunchSource,
	resolveBrowserRuntimeVisibility,
	selectBrowserPageForRun,
	shouldCloseBrowserPageAfterRun,
} from "./connector-runtime.ts";
import type { CaptureSession } from "./fixture-capture.ts";

const HEADLESS: BrowserRuntimeVisibility = {
	envKey: "PDPP_BROWSER_HEADLESS",
	headless: true,
	profileName: "reddit",
};

const MANUAL_ACTION: InteractionRequest = {
	kind: "manual_action",
	message: "Log in to reddit.com in the browser window and re-run.",
	timeout_seconds: 1800,
};

interface KeepaliveTestBrowser {
	isConnected: () => boolean;
	newBrowserCDPSession: () => Promise<{
		detach: () => Promise<void>;
		send: (method: string) => Promise<unknown>;
	}>;
	off?: (event: "disconnected", listener: () => void) => KeepaliveTestBrowser;
	on?: (event: "disconnected", listener: () => void) => KeepaliveTestBrowser;
}

function makeKeepaliveContext(
	browser: KeepaliveTestBrowser,
	pages: Page[] = [],
): Pick<BrowserContext, "browser" | "pages"> {
	return {
		browser: () => browser as ReturnType<BrowserContext["browser"]>,
		pages: () => pages,
	};
}

function makeDiagnosticPage(url: string, closed = false): Page {
	const fake: Pick<Page, "isClosed" | "url"> = {
		isClosed: () => closed,
		url: () => url,
	};
	return fake as Page;
}

function makePageSelectionContext(existingPages: Page[] = []): {
	context: Pick<BrowserContext, "newPage" | "pages">;
	newPage: Page;
	newPageCalls: () => number;
} {
	let calls = 0;
	const newPage = makeDiagnosticPage("about:blank");
	return {
		context: {
			newPage: () => {
				calls += 1;
				return Promise.resolve(newPage);
			},
			pages: () => existingPages,
		},
		newPage,
		newPageCalls: () => calls,
	};
}

function makeClosablePage(closed = false): { closeCalls: number; page: Page } {
	let isClosed = closed;
	let closeCalls = 0;
	const fake: Pick<Page, "close" | "isClosed"> = {
		close: () => {
			closeCalls += 1;
			isClosed = true;
			return Promise.resolve();
		},
		isClosed: () => isClosed,
	};
	return {
		get closeCalls() {
			return closeCalls;
		},
		page: fake as Page,
	};
}

test("closeBrowserContextPagesExcept closes stale open pages while keeping the working page alive", async () => {
	const first = makeClosablePage(false);
	const alreadyClosed = makeClosablePage(true);
	const working = makeClosablePage(false);

	const closedCount = await closeBrowserContextPagesExcept(
		{
			pages: () => [first.page, alreadyClosed.page, working.page],
		},
		working.page,
	);

	assert.equal(closedCount, 1);
	assert.equal(first.closeCalls, 1);
	assert.equal(alreadyClosed.closeCalls, 0);
	assert.equal(working.closeCalls, 0);
});

test("closeBrowserPage closes the runtime-owned working page best-effort", async () => {
	const working = makeClosablePage(false);

	assert.equal(await closeBrowserPage(working.page), true);
	assert.equal(working.closeCalls, 1);
	assert.equal(await closeBrowserPage(working.page), false);
	assert.equal(working.closeCalls, 1);
});

test("closeBrowserPage ignores remote target cleanup errors", async () => {
	let closeCalls = 0;
	const page = {
		close: () => {
			closeCalls += 1;
			return Promise.reject(new Error("Target page has been closed"));
		},
		isClosed: () => false,
	};

	assert.equal(await closeBrowserPage(page), false);
	assert.equal(closeCalls, 1);
});

test("closeBrowserPage abandons a wedged remote target close after the deadline", async () => {
	let closeCalls = 0;
	const page = {
		close: () => {
			closeCalls += 1;
			return new Promise<never>(() => undefined);
		},
		isClosed: () => false,
	};

	const startedAt = Date.now();
	assert.equal(await closeBrowserPage(page, 20), false);
	assert.equal(closeCalls, 1);
	assert.ok(Date.now() - startedAt < 1000);
});

test("selectBrowserPageForRun creates a fresh page by default", async () => {
	const existing = makeDiagnosticPage("https://chatgpt.com/");
	const { context, newPage, newPageCalls } = makePageSelectionContext([
		existing,
	]);

	assert.equal(await selectBrowserPageForRun(context, {}), newPage);
	assert.equal(newPageCalls(), 1);
});

test("selectBrowserPageForRun reuses a non-blank page when preserving successful pages", async () => {
	const existing = makeDiagnosticPage("https://chatgpt.com/");
	const { context, newPageCalls } = makePageSelectionContext([existing]);

	assert.equal(
		await selectBrowserPageForRun(context, { preservePageOnSuccess: true }),
		existing,
	);
	assert.equal(newPageCalls(), 0);
});

test("selectBrowserPageForRun reuses a non-blank page when preserving failed pages", async () => {
	const existing = makeDiagnosticPage("https://chatgpt.com/");
	const { context, newPageCalls } = makePageSelectionContext([existing]);

	assert.equal(
		await selectBrowserPageForRun(context, { preservePageOnFailure: true }),
		existing,
	);
	assert.equal(newPageCalls(), 0);
});

test("selectBrowserPageForRun ignores closed and blank pages", async () => {
	const reusable = makeDiagnosticPage("https://chatgpt.com/");
	const { context, newPageCalls } = makePageSelectionContext([
		makeDiagnosticPage("https://chatgpt.com/", true),
		makeDiagnosticPage("about:blank"),
		makeDiagnosticPage("data:text/html,<html></html>"),
		reusable,
	]);

	assert.equal(
		await selectBrowserPageForRun(context, { preservePageOnSuccess: true }),
		reusable,
	);
	assert.equal(newPageCalls(), 0);
});

test("isReusableBrowserRunPage treats non-blank open pages as reusable", () => {
	assert.equal(
		isReusableBrowserRunPage(makeDiagnosticPage("https://chatgpt.com/")),
		true,
	);
	assert.equal(
		isReusableBrowserRunPage(makeDiagnosticPage("about:blank")),
		false,
	);
	assert.equal(
		isReusableBrowserRunPage(
			makeDiagnosticPage("data:text/html,<html></html>"),
		),
		false,
	);
	assert.equal(
		isReusableBrowserRunPage(makeDiagnosticPage("https://chatgpt.com/", true)),
		false,
	);
});

test("shouldCloseBrowserPageAfterRun preserves only opted-in run outcomes", () => {
	assert.equal(shouldCloseBrowserPageAfterRun({}, true), true);
	assert.equal(shouldCloseBrowserPageAfterRun({}, false), true);
	assert.equal(
		shouldCloseBrowserPageAfterRun({ preservePageOnSuccess: true }, false),
		true,
	);
	assert.equal(
		shouldCloseBrowserPageAfterRun({ preservePageOnSuccess: true }, true),
		false,
	);
	assert.equal(
		shouldCloseBrowserPageAfterRun({ preservePageOnFailure: true }, true),
		true,
	);
	assert.equal(
		shouldCloseBrowserPageAfterRun({ preservePageOnFailure: true }, false),
		false,
	);
	assert.equal(
		shouldCloseBrowserPageAfterRun(
			{ preservePageOnFailure: true, preservePageOnSuccess: true },
			true,
		),
		false,
	);
	assert.equal(
		shouldCloseBrowserPageAfterRun(
			{ preservePageOnFailure: true, preservePageOnSuccess: true },
			false,
		),
		false,
	);
});

test("resolveBrowserRuntimeVisibility defaults every local browser session to headed", () => {
	assert.deepEqual(resolveBrowserRuntimeVisibility({}, "reddit", {}), {
		envKey: "PDPP_BROWSER_HEADLESS",
		headless: false,
		profileName: "reddit",
	});

	assert.deepEqual(
		resolveBrowserRuntimeVisibility({}, "reddit", {
			PDPP_BROWSER_HEADLESS: "1",
		}),
		{
			envKey: "PDPP_BROWSER_HEADLESS",
			headless: true,
			profileName: "reddit",
		},
	);

	assert.deepEqual(
		resolveBrowserRuntimeVisibility({}, "reddit", {
			PDPP_BROWSER_HEADLESS: "0",
		}),
		{
			envKey: "PDPP_BROWSER_HEADLESS",
			headless: false,
			profileName: "reddit",
		},
	);
});

test("resolveBrowserRuntimeVisibility keeps browser mode deployment-owned across profiles", () => {
	assert.deepEqual(
		resolveBrowserRuntimeVisibility({ profileName: "chatgpt" }, "ignored", {}),
		{
			envKey: "PDPP_BROWSER_HEADLESS",
			headless: false,
			profileName: "chatgpt",
		},
	);
});

test("resolveBrowserRuntimeVisibility isolates local profiles by connector instance", () => {
	assert.deepEqual(
		resolveBrowserRuntimeVisibility({ profileName: "chatgpt" }, "ignored", {
			PDPP_CONNECTOR_INSTANCE_ID: "cin_second_account",
		}),
		{
			envKey: "PDPP_BROWSER_HEADLESS",
			headless: false,
			profileName: "chatgpt__cin_second_account",
		},
	);
});

test("resolveBrowserLaunchSource prefers managed n.eko lease env over legacy profile CDP env", () => {
	assert.deepEqual(
		resolveBrowserLaunchSource(
			{ profileName: "chatgpt" },
			{
				PDPP_BROWSER_SURFACE_REQUIRED: "neko",
				PDPP_BROWSER_SURFACE_LEASE_ID: "lease_123",
				PDPP_BROWSER_SURFACE_PROFILE_KEY: "chatgpt:owner",
				PDPP_BROWSER_SURFACE_REMOTE_CDP_URL: "http://managed-neko:9223",
				PDPP_CHATGPT_REMOTE_CDP_URL: "http://legacy-dev:9223",
			},
		),
		{
			kind: "managed_neko",
			leaseId: "lease_123",
			profileKey: "chatgpt:owner",
			remoteCdpUrl: "http://managed-neko:9223",
		} satisfies BrowserLaunchSource,
	);
});

test("resolveBrowserLaunchSource fails closed for required n.eko without managed CDP URL", () => {
	assert.throws(
		() =>
			resolveBrowserLaunchSource(
				{ profileName: "chatgpt" },
				{
					PDPP_BROWSER_SURFACE_REQUIRED: "neko",
					PDPP_CHATGPT_REMOTE_CDP_URL: "http://legacy-dev:9223",
				},
			),
		/PDPP_BROWSER_SURFACE_REQUIRED=neko.*PDPP_BROWSER_SURFACE_REMOTE_CDP_URL is missing/u,
	);
});

test("resolveBrowserLaunchSource keeps unmanaged per-profile CDP env as a dev override", () => {
	assert.deepEqual(
		resolveBrowserLaunchSource(
			{ profileName: "chatgpt" },
			{
				PDPP_CHATGPT_REMOTE_CDP_URL: "http://legacy-dev:9223",
			},
		),
		{
			envKey: "PDPP_CHATGPT_REMOTE_CDP_URL",
			kind: "legacy_remote_cdp",
			remoteCdpUrl: "http://legacy-dev:9223",
		} satisfies BrowserLaunchSource,
	);
});

test("resolveBrowserLaunchSource falls back to isolated local launch only when no remote surface applies", () => {
	assert.deepEqual(resolveBrowserLaunchSource({ profileName: "chatgpt" }, {}), {
		kind: "isolated_local",
	} satisfies BrowserLaunchSource);
});

test("decorateBrowserManualAction appends recovery copy for headless browser runs", () => {
	const decorated = decorateBrowserManualAction(MANUAL_ACTION, HEADLESS);

	assert.notEqual(decorated, MANUAL_ACTION);
	// The decoration should point operators at the streaming companion as the
	// primary path, with the headless-rerun env var as the alternative.
	assert.match(decorated.message, /streaming companion/iu);
	assert.match(decorated.message, /PDPP_BROWSER_HEADLESS=0/u);
});

test("decorateBrowserManualAction leaves non-manual interactions unchanged", () => {
	const otp: InteractionRequest = {
		kind: "otp",
		message: "Enter the verification code.",
	};

	assert.equal(decorateBrowserManualAction(otp, HEADLESS), otp);
});

test("decorateBrowserManualAction leaves visible-browser-capable runs unchanged", () => {
	assert.equal(
		decorateBrowserManualAction(MANUAL_ACTION, {
			...HEADLESS,
			headless: false,
		}),
		MANUAL_ACTION,
	);
});

test("decorateBrowserManualAction does not duplicate existing recovery copy", () => {
	const alreadyActionable: InteractionRequest = {
		kind: "manual_action",
		message:
			"If it is headless, cancel this interaction and rerun headed with PDPP_BROWSER_HEADLESS=0.",
		timeout_seconds: 1800,
	};

	assert.equal(
		decorateBrowserManualAction(alreadyActionable, HEADLESS),
		alreadyActionable,
	);
});

test("makeBrowserInteractionKeepalive sends browser-level CDP pings while interaction is pending", async () => {
	let pingCalls = 0;
	let detachCalls = 0;
	const context = makeKeepaliveContext({
		isConnected: () => true,
		newBrowserCDPSession: () =>
			Promise.resolve({
				detach: () => {
					detachCalls += 1;
					return Promise.resolve();
				},
				send: (method: string) => {
					assert.equal(method, "Browser.getVersion");
					pingCalls += 1;
					return Promise.resolve({});
				},
			}),
	});
	let resolveInteraction:
		| ((value: {
				request_id: string;
				status: "success";
				type: "INTERACTION_RESPONSE";
		  }) => void)
		| undefined;
	const wrapped = makeBrowserInteractionKeepalive({
		context,
		intervalMs: 5,
		sendInteraction: (req) =>
			new Promise((resolve) => {
				resolveInteraction = resolve;
				assert.equal(req.kind, "otp");
			}),
	});

	const responsePromise = wrapped({ kind: "otp", message: "Enter OTP" });
	await delay(20);
	assert.ok(
		pingCalls > 0,
		"expected Browser.getVersion CDP pings while waiting",
	);

	resolveInteraction?.({
		request_id: "int_test",
		status: "success",
		type: "INTERACTION_RESPONSE",
	});
	assert.equal((await responsePromise).status, "success");
	await delay(5);
	assert.equal(detachCalls, 1);
	const callsAfterResponse = pingCalls;
	await delay(20);
	assert.equal(pingCalls, callsAfterResponse);
});

test("makeBrowserInteractionKeepalive stops after interaction errors", async () => {
	let pingCalls = 0;
	let detachCalls = 0;
	const wrapped = makeBrowserInteractionKeepalive({
		context: makeKeepaliveContext({
			isConnected: () => true,
			newBrowserCDPSession: () =>
				Promise.resolve({
					detach: () => {
						detachCalls += 1;
						return Promise.resolve();
					},
					send: () => {
						pingCalls += 1;
						return Promise.resolve({});
					},
				}),
		}),
		intervalMs: 5,
		sendInteraction: async () => {
			await delay(15);
			throw new Error("interaction_failed");
		},
	});

	await assert.rejects(
		() => wrapped({ kind: "manual_action", message: "Continue in browser" }),
		/interaction_failed/u,
	);
	await delay(5);
	assert.equal(detachCalls, 1);
	const callsAfterError = pingCalls;
	await delay(20);
	assert.equal(pingCalls, callsAfterError);
});

test("makeBrowserInteractionKeepalive skips pings when browser is already disconnected", async () => {
	let newSessionCalls = 0;
	const wrapped = makeBrowserInteractionKeepalive({
		context: makeKeepaliveContext({
			isConnected: () => false,
			newBrowserCDPSession: () => {
				newSessionCalls += 1;
				return Promise.resolve({
					detach: () => Promise.resolve(),
					send: () => Promise.resolve({}),
				});
			},
		}),
		intervalMs: 5,
		sendInteraction: async (req) => ({
			request_id: req.request_id ?? "int_test",
			status: "success",
			type: "INTERACTION_RESPONSE",
		}),
	});

	assert.equal(
		(await wrapped({ kind: "otp", message: "Enter OTP" })).status,
		"success",
	);
	await delay(10);
	assert.equal(newSessionCalls, 0);
});

test("makeBrowserInteractionKeepalive ignores CDP ping errors without failing interaction", async () => {
	let pingCalls = 0;
	const wrapped = makeBrowserInteractionKeepalive({
		context: makeKeepaliveContext({
			isConnected: () => true,
			newBrowserCDPSession: () =>
				Promise.resolve({
					detach: () => Promise.resolve(),
					send: () => {
						pingCalls += 1;
						return Promise.reject(new Error("cdp_unavailable"));
					},
				}),
		}),
		intervalMs: 5,
		sendInteraction: async (req) =>
			new Promise((resolve) =>
				setTimeout(
					() =>
						resolve({
							request_id: req.request_id ?? "int_test",
							status: "success",
							type: "INTERACTION_RESPONSE",
						}),
					15,
				),
			),
	});

	assert.equal(
		(await wrapped({ kind: "otp", message: "Enter OTP" })).status,
		"success",
	);
	assert.ok(pingCalls > 0);
});

test("makeBrowserInteractionKeepalive emits gated browser-surface diagnostics around interactions", async () => {
	const progressMessages: string[] = [];
	let resolveInteraction:
		| ((value: {
				request_id: string;
				status: "success";
				type: "INTERACTION_RESPONSE";
		  }) => void)
		| undefined;
	const wrapped = makeBrowserInteractionKeepalive({
		context: makeKeepaliveContext(
			{
				isConnected: () => true,
				newBrowserCDPSession: () =>
					Promise.resolve({
						detach: () => Promise.resolve(),
						send: () => Promise.resolve({}),
					}),
			},
			[
				makeDiagnosticPage(
					"https://secure.chase.com/web/auth/?secret=redacted",
				),
			],
		),
		diagnostics: true,
		intervalMs: 5,
		progress: (message) => {
			progressMessages.push(message);
			return Promise.resolve();
		},
		sendInteraction: (req) =>
			new Promise((resolve) => {
				assert.equal(req.kind, "otp");
				resolveInteraction = resolve;
			}),
	});

	const responsePromise = wrapped({
		kind: "otp",
		message: "Enter OTP",
		request_id: "int_test",
	});
	await delay(15);
	resolveInteraction?.({
		request_id: "int_test",
		status: "success",
		type: "INTERACTION_RESPONSE",
	});
	assert.equal((await responsePromise).status, "success");

	assert.equal(progressMessages.length, 2);
	const diagnostics = progressMessages.map((message) => {
		assert.match(message, /^browser_surface\.diagnostic /u);
		return JSON.parse(
			message.replace(/^browser_surface\.diagnostic /u, ""),
		) as {
			keepalive: null | { pingAttempts: number; pingSuccesses: number };
			phase: string;
			response_status: string | null;
			surface: { pages: Array<{ url: string | null }> };
		};
	});
	assert.equal(diagnostics[0]?.phase, "interaction_start");
	assert.equal(diagnostics[0]?.keepalive, null);
	assert.equal(diagnostics[1]?.phase, "interaction_response");
	assert.equal(diagnostics[1]?.response_status, "success");
	assert.ok((diagnostics[1]?.keepalive?.pingAttempts ?? 0) > 0);
	assert.equal(
		diagnostics[1]?.surface.pages[0]?.url,
		"https://secure.chase.com/web/auth/",
	);
});

test("makeBrowserInteractionKeepalive records browser disconnect timing in diagnostics", async () => {
	const progressMessages: string[] = [];
	let connected = true;
	let disconnectedListener: (() => void) | undefined;
	let detachCalls = 0;
	let resolvePing: (() => void) | undefined;
	const pingReady = new Promise<void>((resolve) => {
		resolvePing = resolve;
	});
	let resolveInteraction:
		| ((value: {
				request_id: string;
				status: "success";
				type: "INTERACTION_RESPONSE";
		  }) => void)
		| undefined;
	const browser: KeepaliveTestBrowser = {
		isConnected: () => connected,
		newBrowserCDPSession: () =>
			Promise.resolve({
				detach: () => {
					detachCalls += 1;
					return Promise.resolve();
				},
				send: () => {
					resolvePing?.();
					return Promise.resolve({});
				},
			}),
		off: (_event, offListener) => {
			if (disconnectedListener === offListener) {
				disconnectedListener = undefined;
			}
			return browser;
		},
		on: (_event, onListener) => {
			disconnectedListener = onListener;
			return browser;
		},
	};
	const wrapped = makeBrowserInteractionKeepalive({
		context: makeKeepaliveContext(browser),
		diagnostics: true,
		intervalMs: 1000,
		progress: (message) => {
			progressMessages.push(message);
			return Promise.resolve();
		},
		sendInteraction: (req) =>
			new Promise((resolve) => {
				resolveInteraction = () =>
					resolve({
						request_id: req.request_id ?? "int_test",
						status: "success",
						type: "INTERACTION_RESPONSE",
					});
			}),
	});

	const responsePromise = wrapped({
		kind: "otp",
		message: "Enter OTP",
		request_id: "int_test",
	});
	await pingReady;
	connected = false;
	const listener = disconnectedListener;
	if (!listener) {
		assert.fail("expected keepalive to attach a browser disconnected listener");
	}
	listener();
	resolveInteraction?.({
		request_id: "int_test",
		status: "success",
		type: "INTERACTION_RESPONSE",
	});
	assert.equal((await responsePromise).status, "success");

	const responseDiagnostic = JSON.parse(
		progressMessages.at(-1)?.replace(/^browser_surface\.diagnostic /u, "") ??
			"{}",
	) as {
		keepalive?: {
			browserConnectedAtStop: boolean;
			disconnectEventCount: number;
			disconnectEventElapsedMs?: number;
			firstObservedDisconnectedElapsedMs?: number;
			lastSuccessfulPingElapsedMs?: number;
		};
	};
	assert.equal(responseDiagnostic.keepalive?.browserConnectedAtStop, false);
	assert.equal(responseDiagnostic.keepalive?.disconnectEventCount, 1);
	assert.equal(
		typeof responseDiagnostic.keepalive?.disconnectEventElapsedMs,
		"number",
	);
	assert.equal(
		typeof responseDiagnostic.keepalive?.firstObservedDisconnectedElapsedMs,
		"number",
	);
	assert.equal(
		typeof responseDiagnostic.keepalive?.lastSuccessfulPingElapsedMs,
		"number",
	);
	assert.equal(detachCalls, 1);
	assert.equal(disconnectedListener, undefined);
});

test("makeBrowserInteractionKeepalive records poll-only disconnect timing without an event listener", async () => {
	const progressMessages: string[] = [];
	let connected = true;
	let resolvePollObserved: (() => void) | undefined;
	const pollObserved = new Promise<void>((resolve) => {
		resolvePollObserved = resolve;
	});
	const browser: KeepaliveTestBrowser = {
		isConnected: () => {
			if (!connected) {
				resolvePollObserved?.();
			}
			return connected;
		},
		newBrowserCDPSession: () =>
			Promise.resolve({
				detach: () => Promise.resolve(),
				send: () =>
					Promise.resolve({}).then(() => {
						connected = false;
						return {};
					}),
			}),
	};
	const wrapped = makeBrowserInteractionKeepalive({
		context: makeKeepaliveContext(browser),
		diagnostics: true,
		intervalMs: 1,
		progress: (message) => {
			progressMessages.push(message);
			return Promise.resolve();
		},
		sendInteraction: async (req) => {
			await pollObserved;
			return {
				request_id: req.request_id ?? "poll_test",
				status: "success",
				type: "INTERACTION_RESPONSE",
			};
		},
	});

	// The production readline owner keeps the event loop alive while waiting
	// for input. Keep that ownership explicit in this synthetic poll-only test;
	// the keepalive timer itself is intentionally unref'ed.
	const inputOwner = setTimeout(() => undefined, 100);
	try {
		assert.equal(
			(await wrapped({ kind: "otp", message: "Enter OTP" })).status,
			"success",
		);
		const responseDiagnostic = JSON.parse(
			progressMessages.at(-1)?.replace(/^browser_surface\.diagnostic /u, "") ??
				"{}",
		) as {
			keepalive?: {
				disconnectEventElapsedMs?: number;
				firstObservedDisconnectedElapsedMs?: number;
				pingAttempts: number;
				skippedDisconnected: number;
			};
		};
		assert.equal(
			responseDiagnostic.keepalive?.disconnectEventElapsedMs,
			undefined,
		);
		assert.equal(
			typeof responseDiagnostic.keepalive?.firstObservedDisconnectedElapsedMs,
			"number",
		);
		assert.equal(responseDiagnostic.keepalive?.skippedDisconnected, 1);
		assert.equal(responseDiagnostic.keepalive?.pingAttempts, 1);
	} finally {
		clearTimeout(inputOwner);
	}
});

function delay(ms: number): Promise<void> {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

function makeFakeCapture(): {
	captureDomCalls: { label: string; closed: boolean }[];
	session: CaptureSession;
} {
	const captureDomCalls: { label: string; closed: boolean }[] = [];
	const session: CaptureSession = {
		baseDir: "/tmp/fake-capture",
		keepOnSuccess: false,
		runId: "fake-run",
		captureDom: (page, label) => {
			captureDomCalls.push({ label, closed: page.isClosed() });
			return Promise.resolve();
		},
		captureHttp: () => {
			/* no-op */
		},
		finalize: () => {
			/* no-op */
		},
		markSucceeded: () => {
			/* no-op */
		},
		hasRegisteredSecrets: () => false,
		registerSecrets: () => undefined,
		recordRecord: () => {
			/* no-op */
		},
	};
	return { captureDomCalls, session };
}

test("captureBrowserPage skips capture when the page is already closed", async () => {
	const { captureDomCalls, session } = makeFakeCapture();
	const closedPage = {
		isClosed: () => true,
	} as Page;

	await captureBrowserPage(session, closedPage, "runtime-error");

	assert.equal(captureDomCalls.length, 0);
});

test("captureBrowserPage forwards live pages to capture.captureDom", async () => {
	const { captureDomCalls, session } = makeFakeCapture();
	const livePage = {
		isClosed: () => false,
	} as Page;

	await captureBrowserPage(session, livePage, "runtime-collect-start");

	assert.deepEqual(captureDomCalls, [
		{ label: "runtime-collect-start", closed: false },
	]);
});

test("captureBrowserPage no-ops when capture session is null", async () => {
	await captureBrowserPage(null, { isClosed: () => false } as Page, "label");
	// Reaching here without throw is the assertion.
});

type DisconnectableBrowser = Pick<
	NonNullable<ReturnType<BrowserContext["browser"]>>,
	"isConnected"
>;
interface DisconnectableContext {
	browser: () => DisconnectableBrowser | null;
}

test("isContextDisconnected reports disconnected when browser.isConnected() returns false", () => {
	const ctx: DisconnectableContext = {
		browser: () => ({ isConnected: () => false }) as DisconnectableBrowser,
	};
	assert.equal(
		isContextDisconnected(ctx as Pick<BrowserContext, "browser">),
		true,
	);
});

test("isContextDisconnected reports connected when browser.isConnected() returns true", () => {
	const ctx: DisconnectableContext = {
		browser: () => ({ isConnected: () => true }) as DisconnectableBrowser,
	};
	assert.equal(
		isContextDisconnected(ctx as Pick<BrowserContext, "browser">),
		false,
	);
});

test("isContextDisconnected treats missing browser as connected (best-effort fallback)", () => {
	const ctx: DisconnectableContext = {
		browser: () => null,
	};
	assert.equal(
		isContextDisconnected(ctx as Pick<BrowserContext, "browser">),
		false,
	);
});

test("isContextDisconnected treats throwing bridges as disconnected", () => {
	const ctx: DisconnectableContext = {
		browser: () => {
			throw new Error("ipc lost");
		},
	};
	assert.equal(
		isContextDisconnected(ctx as Pick<BrowserContext, "browser">),
		true,
	);
});

interface FakeTracingShape {
	start: (options: { name: string }) => Promise<void>;
	startChunk?: (options?: { title?: string }) => Promise<void>;
	stop: (options?: { path?: string }) => Promise<void>;
	stopChunk?: (options?: { path?: string }) => Promise<void>;
}

function makeTracingContext(
	tracing: FakeTracingShape,
	browser: { isConnected: () => boolean } | null,
): BrowserContext {
	// BrowserContext has dozens of methods we don't need for the trace
	// lifecycle test. Cast through the structurally-sufficient subset.
	const partial: Pick<BrowserContext, "browser" | "tracing"> = {
		browser: () => browser as ReturnType<BrowserContext["browser"]>,
		tracing: tracing as BrowserContext["tracing"],
	};
	return partial as BrowserContext;
}

test("makeTracer.stop() short-circuits when the browser is already disconnected", async () => {
	const previousFixtures = process.env.PDPP_CAPTURE_FIXTURES;
	const previousOnFailure = process.env.PDPP_CAPTURE_ON_FAILURE;
	const previousTrace = process.env.PDPP_TRACE;
	process.env.PDPP_TRACE = "1";
	delete process.env.PDPP_CAPTURE_FIXTURES;
	delete process.env.PDPP_CAPTURE_ON_FAILURE;
	try {
		let stopCalled = false;
		let stopChunkCalled = false;
		const tracing: FakeTracingShape = {
			start: () => Promise.resolve(),
			startChunk: () => Promise.resolve(),
			stop: () => {
				stopCalled = true;
				return Promise.reject(
					new Error("Target page, context or browser has been closed"),
				);
			},
			stopChunk: () => {
				stopChunkCalled = true;
				return Promise.resolve();
			},
		};
		let connected = true;
		const ctx = makeTracingContext(tracing, { isConnected: () => connected });
		const tracer = makeTracer(ctx, "fake-connector", null);
		await tracer.start();
		// Now the browser drops.
		connected = false;
		// stop() should not reach tracing.stop() / tracing.stopChunk() — they
		// would throw and the disconnect guard prevents the noisy Playwright
		// error from surfacing.
		await tracer.stop();
		assert.equal(stopCalled, false);
		assert.equal(stopChunkCalled, false);
	} finally {
		if (previousFixtures === undefined) {
			delete process.env.PDPP_CAPTURE_FIXTURES;
		} else {
			process.env.PDPP_CAPTURE_FIXTURES = previousFixtures;
		}
		if (previousOnFailure === undefined) {
			delete process.env.PDPP_CAPTURE_ON_FAILURE;
		} else {
			process.env.PDPP_CAPTURE_ON_FAILURE = previousOnFailure;
		}
		if (previousTrace === undefined) {
			delete process.env.PDPP_TRACE;
		} else {
			process.env.PDPP_TRACE = previousTrace;
		}
	}
});

test("makeTracer.stop() is idempotent — second call does not retry against a disconnected context", async () => {
	const previousTrace = process.env.PDPP_TRACE;
	process.env.PDPP_TRACE = "1";
	try {
		let stopCallCount = 0;
		const tracing: FakeTracingShape = {
			start: () => Promise.resolve(),
			startChunk: () => Promise.resolve(),
			stop: () => {
				stopCallCount += 1;
				return Promise.resolve();
			},
			stopChunk: () => Promise.resolve(),
		};
		const ctx = makeTracingContext(tracing, { isConnected: () => true });
		const tracer = makeTracer(ctx, "idempotent", null);
		await tracer.start();
		await tracer.stop();
		await tracer.stop();
		assert.equal(stopCallCount, 1);
	} finally {
		if (previousTrace === undefined) {
			delete process.env.PDPP_TRACE;
		} else {
			process.env.PDPP_TRACE = previousTrace;
		}
	}
});

test("buildDetailCoverageMessage emits a valid reference-only DETAIL_COVERAGE", () => {
	const msg = buildDetailCoverageMessage({
		stream: "messages",
		stateStream: "conversations",
		requiredKeys: ["a", "b", "c"],
		hydratedKeys: ["a", "b"],
		gapKeys: ["c"],
	});
	assert.equal(msg.type, "DETAIL_COVERAGE");
	assert.equal(msg.reference_only, true);
	assert.equal(msg.stream, "messages");
	assert.equal(msg.state_stream, "conversations");
	assert.deepEqual(msg.required_keys, ["a", "b", "c"]);
	assert.deepEqual(msg.hydrated_keys, ["a", "b"]);
	assert.deepEqual(msg.gap_keys, ["c"]);
	assert.equal("optional_skip_keys" in msg, false);
});

test("buildDetailCoverageMessage omits empty optional key sets", () => {
	const msg = buildDetailCoverageMessage({
		stream: "messages",
		stateStream: "conversations",
		requiredKeys: [1, 2],
		hydratedKeys: [1, 2],
		gapKeys: [],
		optionalSkipKeys: [],
	});
	assert.deepEqual(msg.required_keys, [1, 2]);
	assert.deepEqual(msg.hydrated_keys, [1, 2]);
	assert.equal(
		"gap_keys" in msg,
		false,
		"empty gap_keys must be omitted, not []",
	);
	assert.equal(
		"optional_skip_keys" in msg,
		false,
		"empty optional_skip_keys must be omitted, not []",
	);
});

test("buildDetailCoverageMessage carries optional_skip_keys when present", () => {
	const msg = buildDetailCoverageMessage({
		stream: "messages",
		stateStream: "conversations",
		requiredKeys: ["a", "b", "c"],
		hydratedKeys: ["a"],
		optionalSkipKeys: ["b", "c"],
	});
	assert.deepEqual(msg.optional_skip_keys, ["b", "c"]);
	assert.equal("gap_keys" in msg, false);
});

test("buildDetailCoverageMessage carries a non-negative-integer considered (list-stream denominator)", () => {
	// A list stream with no detail-hydration phase declares its enumerated
	// inventory via empty key arrays + an explicit considered (task 4.1).
	const msg = buildDetailCoverageMessage({
		stream: "repositories",
		stateStream: "repositories",
		requiredKeys: [],
		hydratedKeys: [],
		considered: 12,
	});
	assert.equal(msg.considered, 12);
	assert.deepEqual(msg.required_keys, []);
	assert.deepEqual(msg.hydrated_keys, []);
	assert.equal("gap_keys" in msg, false);
});

test("buildDetailCoverageMessage carries considered: 0 (an empty enumeration is a fact, not unknown)", () => {
	const msg = buildDetailCoverageMessage({
		stream: "repositories",
		stateStream: "repositories",
		requiredKeys: [],
		hydratedKeys: [],
		considered: 0,
	});
	assert.equal(
		"considered" in msg,
		true,
		"considered: 0 must be carried, not dropped as falsy",
	);
	assert.equal(msg.considered, 0);
});

test("buildDetailCoverageMessage omits considered when absent or not a non-negative integer", () => {
	const absent = buildDetailCoverageMessage({
		stream: "messages",
		stateStream: "conversations",
		requiredKeys: ["a"],
		hydratedKeys: ["a"],
	});
	assert.equal(
		"considered" in absent,
		false,
		"no considered passed -> key omitted (unknown)",
	);

	for (const bad of [-1, 3.5, Number.NaN, Number.POSITIVE_INFINITY]) {
		const msg = buildDetailCoverageMessage({
			stream: "messages",
			stateStream: "conversations",
			requiredKeys: ["a"],
			hydratedKeys: ["a"],
			considered: bad,
		});
		assert.equal(
			"considered" in msg,
			false,
			`considered=${String(bad)} must be omitted at the builder, never fabricated`,
		);
	}
});

test("buildDetailCoverageMessage copies input arrays", () => {
	const requiredKeys = ["a", "b"];
	const hydratedKeys = ["a"];
	const msg = buildDetailCoverageMessage({
		stream: "messages",
		stateStream: "conversations",
		requiredKeys,
		hydratedKeys,
	});
	requiredKeys.push("mutated");
	hydratedKeys.push("mutated");
	assert.deepEqual(
		msg.required_keys,
		["a", "b"],
		"message must not alias caller's requiredKeys array",
	);
	assert.deepEqual(
		msg.hydrated_keys,
		["a"],
		"message must not alias caller's hydratedKeys array",
	);
});

test("emitDetailCoverage forwards exactly one built message to ctx.emit", async () => {
	const emitted: EmittedMessage[] = [];
	const ctx = {
		emit: (emittedMsg: EmittedMessage): Promise<void> => {
			emitted.push(emittedMsg);
			return Promise.resolve();
		},
	};
	await emitDetailCoverage(ctx, {
		stream: "messages",
		stateStream: "conversations",
		requiredKeys: ["a", "b"],
		hydratedKeys: ["a"],
		gapKeys: ["b"],
	});
	assert.equal(emitted.length, 1);
	const [msg] = emitted;
	assert.ok(msg, "exactly one message must be emitted");
	assert.equal(msg.type, "DETAIL_COVERAGE");
	assert.deepEqual(
		msg,
		buildDetailCoverageMessage({
			stream: "messages",
			stateStream: "conversations",
			requiredKeys: ["a", "b"],
			hydratedKeys: ["a"],
			gapKeys: ["b"],
		}),
		"emitDetailCoverage must emit precisely what buildDetailCoverageMessage builds",
	);
});

test("buildDetailGap emits a valid reference-only pending retryable DETAIL_GAP", () => {
	const msg = buildDetailGap({
		stream: "messages",
		recordKey: "conv-1",
		reason: "upstream_pressure",
		locator: { kind: "chatgpt.conversation", conversation_id: "conv-1" },
		error: {
			class: "upstream_pressure",
			httpStatus: 429,
			networkPressure: {
				endpoint_route: "/conversation/{id}",
				error_class: "rate_limit_density",
				method: "GET",
			},
		},
	});
	assert.equal(msg.type, "DETAIL_GAP");
	assert.equal(msg.reference_only, true);
	assert.equal(msg.status, "pending");
	assert.equal(msg.retryable, true);
	assert.equal(msg.stream, "messages");
	assert.equal(msg.record_key, "conv-1");
	assert.equal(msg.reason, "upstream_pressure");
	assert.deepEqual(msg.detail_locator, {
		kind: "chatgpt.conversation",
		conversation_id: "conv-1",
	});
});

test("buildDetailGap fans identical error context into detail and last_error", () => {
	const msg = buildDetailGap({
		stream: "messages",
		recordKey: 7,
		reason: "rate_limited",
		locator: { kind: "x.item" },
		error: {
			class: "rate_limited",
			httpStatus: 429,
			networkPressure: {
				endpoint_route: "/r",
				error_class: "rate",
				method: "GET",
				retry_after_ms: 1000,
			},
		},
	});
	// The connector hand-rolled two identical copies; the helper must keep them
	// deep-equal so a downstream reader sees one consistent error shape.
	assert.deepEqual(msg.detail, msg.last_error);
	assert.equal(msg.detail?.class, "rate_limited");
	assert.equal(msg.detail?.http_status, 429);
	assert.deepEqual(msg.detail?.network_pressure, {
		endpoint_route: "/r",
		error_class: "rate",
		method: "GET",
		retry_after_ms: 1000,
	});
});

test("buildDetailGap omits empty optional error fields", () => {
	const msg = buildDetailGap({
		stream: "messages",
		recordKey: "conv-2",
		reason: "retry_exhausted",
		locator: { kind: "chatgpt.conversation", conversation_id: "conv-2" },
		error: { class: "retry_exhausted" },
	});
	assert.equal(msg.detail?.class, "retry_exhausted");
	assert.equal(
		"http_status" in (msg.detail ?? {}),
		false,
		"absent http status must be omitted, not undefined",
	);
	assert.equal(
		"network_pressure" in (msg.detail ?? {}),
		false,
		"absent network pressure must be omitted, not undefined",
	);
	assert.deepEqual(msg.detail, msg.last_error);
});

test("emitDetailGap forwards exactly one built message to ctx.emit", async () => {
	const emitted: EmittedMessage[] = [];
	const ctx = {
		emit: (emittedMsg: EmittedMessage): Promise<void> => {
			emitted.push(emittedMsg);
			return Promise.resolve();
		},
	};
	const params = {
		stream: "messages",
		recordKey: "conv-3",
		reason: "upstream_pressure" as const,
		locator: { kind: "chatgpt.conversation", conversation_id: "conv-3" },
		error: { class: "upstream_pressure_deferred" },
	};
	await emitDetailGap(ctx, params);
	assert.equal(emitted.length, 1);
	const [msg] = emitted;
	assert.ok(msg, "exactly one message must be emitted");
	assert.equal(msg.type, "DETAIL_GAP");
	assert.deepEqual(
		msg,
		buildDetailGap(params),
		"emitDetailGap must emit precisely what buildDetailGap builds",
	);
});

test("buildDetailGap carries an optional parent_stream for list-plus-detail fan-outs", () => {
	// Chase's accounts -> transactions detail pass: the gap names its parent
	// stream so a reader can attribute the partial detail to the right list.
	const msg = buildDetailGap({
		stream: "transactions",
		parentStream: "accounts",
		recordKey: "acct-1",
		reason: "temporary_unavailable",
		locator: { kind: "chase.account", account_id: "acct-1" },
		error: { class: "qfx_download_failed" },
	});
	assert.equal(msg.parent_stream, "accounts");
	assert.equal(msg.stream, "transactions");
	assert.equal(msg.record_key, "acct-1");
	assert.equal(msg.detail?.class, "qfx_download_failed");
});

test("buildDetailGap carries an optional list_cursor for resuming the parent list", () => {
	// Amazon-style: the next run resumes the order list at this opaque cursor
	// rather than re-walking from the top to reach the gapped item's detail.
	const cursor = { page_token: "opaque-123", index: 42 };
	const msg = buildDetailGap({
		stream: "order_items",
		parentStream: "orders",
		listCursor: cursor,
		recordKey: "order-9",
		reason: "rate_limited",
		locator: { kind: "amazon.order", order_id: "order-9" },
		error: { class: "rate_limited", httpStatus: 429 },
	});
	assert.deepEqual(msg.list_cursor, cursor);
	assert.equal(msg.parent_stream, "orders");
	assert.equal(msg.detail?.http_status, 429);
});

test("buildDetailGap omits absent optional protocol fields entirely", () => {
	// USAA's statement gap: no parent stream, no list cursor, and — crucially —
	// no error context at all, so neither detail nor last_error is on the wire.
	const msg = buildDetailGap({
		stream: "statements",
		recordKey: "stmt-hash",
		reason: "temporary_unavailable",
		locator: { kind: "usaa.statement", statement_id: "stmt-hash" },
	});
	assert.equal(
		"parent_stream" in msg,
		false,
		"absent parent_stream must be omitted, not undefined",
	);
	assert.equal(
		"list_cursor" in msg,
		false,
		"absent list_cursor must be omitted, not undefined",
	);
	assert.equal(
		"detail" in msg,
		false,
		"an error-less gap must omit detail, not emit an empty block",
	);
	assert.equal(
		"last_error" in msg,
		false,
		"an error-less gap must omit last_error, not emit an empty block",
	);
	// The fixed reference-only / pending / retryable spine is still intact.
	assert.equal(msg.type, "DETAIL_GAP");
	assert.equal(msg.reference_only, true);
	assert.equal(msg.status, "pending");
	assert.equal(msg.retryable, true);
});

test("buildDetailGap puts error.message on last_error only (detail has no message field)", () => {
	const msg = buildDetailGap({
		stream: "messages",
		recordKey: "conv-4",
		reason: "retry_exhausted",
		locator: { kind: "chatgpt.conversation", conversation_id: "conv-4" },
		error: {
			class: "retry_exhausted",
			httpStatus: 503,
			message: "apiFetch retry budget exhausted",
		},
	});
	assert.equal(msg.last_error?.message, "apiFetch retry budget exhausted");
	assert.equal(
		"message" in (msg.detail ?? {}),
		false,
		"detail must not carry a message field",
	);
	// Shared error fields still agree across the two blocks.
	assert.equal(msg.detail?.class, "retry_exhausted");
	assert.equal(msg.last_error?.class, "retry_exhausted");
	assert.equal(msg.detail?.http_status, 503);
	assert.equal(msg.last_error?.http_status, 503);
});

test("emitDetailGap forwards a gap with optional parent_stream and list_cursor verbatim", async () => {
	const emitted: EmittedMessage[] = [];
	const ctx = {
		emit: (emittedMsg: EmittedMessage): Promise<void> => {
			emitted.push(emittedMsg);
			return Promise.resolve();
		},
	};
	const params = {
		stream: "transactions",
		parentStream: "accounts",
		listCursor: { page: 2 },
		recordKey: "acct-2",
		reason: "upstream_pressure" as const,
		locator: { kind: "chase.account", account_id: "acct-2" },
		error: {
			class: "upstream_pressure_deferred",
			networkPressure: {
				endpoint_route: "/qfx/{id}",
				error_class: "rate_limit_density",
				method: "GET",
			},
		},
	};
	await emitDetailGap(ctx, params);
	assert.equal(emitted.length, 1);
	const [msg] = emitted;
	assert.ok(msg, "exactly one message must be emitted");
	assert.deepEqual(
		msg,
		buildDetailGap(params),
		"emitDetailGap must emit precisely what buildDetailGap builds, including optional fields",
	);
});

// ─── composeNormalizedTerminalError: stable infrastructure codes must ──────
// survive connector-supplied normalizeTerminalError overrides ──────────────
//
// Every current connector's normalizeTerminalError (e.g. ChatGPT's) only
// destructures `{ message, retryable }` and returns a fresh object, so an
// incoming infrastructure code (thrown by the runtime itself, e.g.
// TerminalError.code from the browser-launch attach-race exhaustion) would
// be silently dropped without this composition step. This must hold
// generically for ANY connector's normalizer, not be special-cased per
// connector.

test("composeNormalizedTerminalError backfills an infrastructure code the connector normalizer dropped", () => {
	// Simulates the real shape: a normalizer that only destructures
	// { message, retryable } (as every current connector normalizer does).
	const normalizeTerminalError = ({
		message,
		retryable,
	}: {
		message: string;
		retryable: boolean;
	}) => ({
		message: `wrapped: ${message}`,
		retryable,
	});
	const result = composeNormalizedTerminalError({
		message: "could not open browser profile: session closed",
		retryable: true,
		code: "browser_surface_attach_exhausted",
		normalizeTerminalError,
	});
	assert.equal(result.code, "browser_surface_attach_exhausted");
	assert.equal(
		result.message,
		"wrapped: could not open browser profile: session closed",
	);
	assert.equal(result.retryable, true);
});

test("composeNormalizedTerminalError lets a connector's deliberate code override the infrastructure code", () => {
	const normalizeTerminalError = () => ({
		message: "credential rejected",
		code: "credential_rejected",
		retryable: false,
	});
	const result = composeNormalizedTerminalError({
		message: "could not open browser profile: session closed",
		retryable: true,
		code: "browser_surface_attach_exhausted",
		normalizeTerminalError,
	});
	assert.equal(
		result.code,
		"credential_rejected",
		"a connector-chosen code is a deliberate override, not data loss to backfill",
	);
});

test("composeNormalizedTerminalError is a no-op when there is no infrastructure code", () => {
	const normalizeTerminalError = ({
		message,
		retryable,
	}: {
		message: string;
		retryable: boolean;
	}) => ({
		message,
		retryable,
	});
	const result = composeNormalizedTerminalError({
		message: "some connector error",
		retryable: false,
		normalizeTerminalError,
	});
	assert.equal(result.code, undefined);
});

test("the identity default normalizeTerminalError (no connector override) passes the infrastructure code through unchanged", () => {
	const identity = <T>(error: T): T => error;
	const result = composeNormalizedTerminalError({
		message: "could not open browser profile: session closed",
		retryable: true,
		code: "browser_surface_attach_exhausted",
		normalizeTerminalError: identity,
	});
	assert.equal(result.code, "browser_surface_attach_exhausted");
});

test("ChatGPT's real normalizeChatGptTerminalError (which destructures only message/retryable) still surfaces browser_surface_attach_exhausted via composeNormalizedTerminalError", async () => {
	// Proves the fix through a REAL connector-configured normalizer, not just
	// a synthetic stand-in. `normalizeChatGptTerminalError`'s default branch
	// (no auth/manual-action match) returns { message, retryable } with no
	// `code` — exactly the drop shape this test guards against.
	const { normalizeChatGptTerminalError } = await import(
		"../connectors/chatgpt/index.ts"
	);
	const result = composeNormalizedTerminalError({
		message:
			"could not open browser profile: Protocol error (Network.setCacheDisabled): Internal server error, session closed.",
		retryable: true,
		code: "browser_surface_attach_exhausted",
		normalizeTerminalError: normalizeChatGptTerminalError,
	});
	assert.equal(result.code, "browser_surface_attach_exhausted");
	assert.match(
		result.message,
		/runtime_exception/,
		"ChatGPT's own message wrapping is preserved",
	);
});

// ─── createConnectorFailure: the one shared constructor for a typed, ───────
// validated connector failure code ───────────────────────────────────────
//
// `error.code` / `connector_error_code` is copied verbatim onto
// `connector_error_json` with NO redaction (unlike `error.message`, which
// always goes through `boundConnectorErrorMessage`/`redactStderrTail`). That
// is safe only because `code` is constrained to a small, connector-declared
// vocabulary that a connector author writes deliberately at each throw
// site — never derived by pattern-matching arbitrary caught text. These
// tests pin `createConnectorFailure` as the one validated entry point onto
// that channel: a well-formed code survives, a malformed/oversized code
// fails closed (throws, does not silently pass through or get truncated),
// and `message` is ordinary text with no special treatment.

test("createConnectorFailure attaches a well-formed code, message, and retryable bit to a TerminalError-shaped throw", () => {
	const err = createConnectorFailure(
		"auth_failed",
		"Apple ID or app-specific password was rejected",
		{
			retryable: false,
		},
	) as Error & { code?: string; retryable?: boolean };
	assert.equal(err.message, "Apple ID or app-specific password was rejected");
	assert.equal(err.code, "auth_failed");
	assert.equal(err.retryable, false);
});

test("createConnectorFailure defaults retryable to false when omitted", () => {
	const err = createConnectorFailure(
		"discovery_failed",
		"discovery failed",
	) as Error & { retryable?: boolean };
	assert.equal(err.retryable, false);
});

test("createConnectorFailure accepts an explicit retryable: true", () => {
	const err = createConnectorFailure("carddav_request_failed", "sync failed", {
		retryable: true,
	}) as Error & {
		retryable?: boolean;
	};
	assert.equal(err.retryable, true);
});

test("createConnectorFailure fails closed on a code that is too long", () => {
	const maxLength = `a${"b".repeat(63)}`; // 64 chars total: the maximum allowed length.
	assert.doesNotThrow(
		() => createConnectorFailure(maxLength, "message"),
		"the max-length code itself must be accepted",
	);
	const tooLong = `a${"b".repeat(64)}`; // 65 chars: one over the cap.
	assert.throws(
		() => createConnectorFailure(tooLong, "message"),
		/connector_failure_invalid_code/,
	);
});

test("createConnectorFailure fails closed on a code with disallowed characters", () => {
	const badCodes = [
		"Auth_Failed", // uppercase
		"auth-failed", // hyphen (message-redaction charset, not the code charset)
		"auth failed", // space
		"auth.failed", // punctuation
		"1auth_failed", // must start with a letter
		"", // empty
		"a", // single char, below the 2-char minimum
	];
	for (const code of badCodes) {
		assert.throws(
			() => createConnectorFailure(code, "message"),
			/connector_failure_invalid_code/,
			`expected "${code}" to be rejected`,
		);
	}
});

test("createConnectorFailure fails closed rather than truncating or stripping an invalid code into something valid", () => {
	// A naive "sanitize" implementation might slice/lowercase/strip an
	// invalid code down to something that passes — that would silently
	// accept a connector bug (or a deliberately malformed code trying to
	// smuggle content through the unredacted, un-length-capped-below-64
	// channel) instead of surfacing it. Mixed-case, punctuation-bearing
	// strings are exactly the shape a real secret (an API key, a bearer
	// token) would take, and exactly what a naive lowercase()+truncate()
	// "fix" would silently coerce into something charset-valid. This proves
	// createConnectorFailure throws instead of coercing.
	const mixedCaseCode = "sk_LIVE_AbCdEfGhIjKlMnOpQrStUvWxYz012345";
	assert.throws(
		() => createConnectorFailure(mixedCaseCode, "message"),
		/connector_failure_invalid_code/,
	);
	// Sanity: a lowered/truncated rewrite of the same string DOES pass —
	// proving createConnectorFailure never performs that rewrite itself; the
	// exception above is the only outcome for the original invalid input.
	const rewritten = mixedCaseCode.toLowerCase().slice(0, 20);
	assert.doesNotThrow(() => createConnectorFailure(rewritten, "message"));
});

test("createConnectorFailure's message is ordinary text with no code-channel special treatment", () => {
	// message is NOT validated by createConnectorFailure at all — it is
	// free-form text that goes through the SAME redaction as any other
	// connector-authored message later in the pipeline (boundConnectorErrorMessage
	// / redactStderrTail), never through the strict code charset check.
	const err = createConnectorFailure(
		"carddav_request_failed",
		"status=401, Authorization: Bearer abc123",
	) as Error;
	assert.equal(err.message, "status=401, Authorization: Bearer abc123");
});

// ─── describeUnexpectedFailure: an unclassified throw's own .message can be ─
// contentless while the real explanation sits on a side field ──────────────
//
// Regression for a live-DB gmail run (run_1786142622018_1) that reached
// connector_error_json as {"message":"Command failed","retryable":false} with
// zero further detail. imapflow (the gmail connector's IMAP client) throws
// `new Error('Command failed')` for every IMAP NO/BAD server response
// (imap-flow.js's settleRequest) and puts the actual explanation on
// `.responseText` (the server's own error text) and `.executedCommand` (the
// IMAP command line, password arguments already redacted by imapflow's own
// isLogging compiler). The generic `run().catch` in this file used to read
// only `.message`, discarding both. See docs/inbox/report-gmail-command-failed.md.

test("describeUnexpectedFailure folds an imapflow-shaped error's responseText and executedCommand into the message", () => {
	const err = new Error("Command failed") as Error & {
		executedCommand?: string;
		responseText?: string;
	};
	err.responseText = "[AUTHENTICATIONFAILED] Invalid credentials (Failure)";
	err.executedCommand = 'A2 LOGIN "user@gmail.com" "(* value hidden *)"';
	const message = describeUnexpectedFailure(err);
	assert.match(message, /Command failed/);
	assert.match(
		message,
		/AUTHENTICATIONFAILED/,
		"the server's own explanation must survive, not just the generic message",
	);
	assert.match(
		message,
		/A2 LOGIN/,
		"the executed command must survive for diagnosis",
	);
	assert.match(
		message,
		/value hidden/,
		"sanity: the fixture's password arg is already imapflow-redacted upstream, not re-exposed here",
	);
});

test("describeUnexpectedFailure is a no-op passthrough for a plain Error with no known side fields", () => {
	const message = describeUnexpectedFailure(new Error("ECONNRESET"));
	assert.equal(message, "ECONNRESET");
});

test("describeUnexpectedFailure stringifies a non-Error throw exactly as the old inline ternary did", () => {
	assert.equal(
		describeUnexpectedFailure("raw string throw"),
		"raw string throw",
	);
	assert.equal(describeUnexpectedFailure(42), "42");
});

test("describeUnexpectedFailure bounds a pathological responseText so it cannot bloat the terminal row", () => {
	const err = new Error("Command failed") as Error & { responseText?: string };
	err.responseText = "x".repeat(5000);
	const message = describeUnexpectedFailure(err);
	assert.ok(
		message.length <= 301,
		`expected bounded length, got ${message.length}`,
	);
	assert.match(message, /…$/);
});
