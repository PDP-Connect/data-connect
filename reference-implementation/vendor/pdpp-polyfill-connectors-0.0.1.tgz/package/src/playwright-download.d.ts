import type { Download } from "playwright";
export type PlaywrightDownloadLike = Pick<Download, "saveAs"> & Partial<Pick<Download, "createReadStream" | "failure" | "suggestedFilename" | "url">>;
/**
 * Diagnostic info captured while persisting a Playwright Download. Surfaced
 * up to callers so a `download_empty` outcome carries the evidence needed
 * to root-cause it (saveAs error string, stream fallback bytes/error, the
 * remote browser's own `download.failure()` report) instead of being a
 * blind dead-end.
 */
export interface PlaywrightDownloadOutcome {
    bytes: number;
    downloadFailure?: string | null;
    saveAsError?: string;
    source: "dataUrl" | "saveAs" | "createReadStream";
    streamError?: string;
}
export declare function readPlaywrightDownloadBuffer(download: PlaywrightDownloadLike): Promise<Buffer>;
/**
 * Persist a Playwright Download and return rich outcome metadata. Identical
 * to `readPlaywrightDownloadBuffer` for the happy path, but reports the
 * fallback path taken and the byte count actually written. Used by the USAA
 * export driver to surface `download_empty` evidence in the timeline.
 */
export declare function readPlaywrightDownloadBufferDetailed(download: PlaywrightDownloadLike): Promise<{
    buffer: Buffer;
    outcome: PlaywrightDownloadOutcome;
}>;
export declare function savePlaywrightDownload(download: PlaywrightDownloadLike, targetPath: string): Promise<void>;
/**
 * Try `saveAs` (Playwright's documented primary primitive), and fall back
 * to `createReadStream` when it either throws or silently writes a zero-byte
 * artifact. The zero-byte case has been observed with `connectOverCDP`-style
 * remote browsers (n.eko) where the artifact transfer can complete without
 * an error but without bytes — exactly the failure mode the USAA export
 * driver was hitting under `download_empty`.
 */
export declare function savePlaywrightDownloadDetailed(download: PlaywrightDownloadLike, targetPath: string): Promise<PlaywrightDownloadOutcome>;
//# sourceMappingURL=playwright-download.d.ts.map