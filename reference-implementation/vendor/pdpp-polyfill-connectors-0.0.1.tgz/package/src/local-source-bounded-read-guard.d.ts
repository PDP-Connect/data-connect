export type BoundedReadPattern = "readFile" | "readFileSync" | "all";
export interface BoundedReadException {
    readonly connector: string;
    readonly file: string;
    readonly lineIncludes: string;
    readonly pattern: BoundedReadPattern;
    readonly reason: string;
}
export interface BoundedReadFinding {
    readonly connector: string;
    readonly file: string;
    readonly line: number;
    readonly pattern: BoundedReadPattern;
    readonly text: string;
}
export declare const BOUNDED_READ_EXCEPTIONS: readonly BoundedReadException[];
export declare const EXPLICIT_LOCAL_CLASS_CONNECTORS: readonly string[];
export declare function discoverLocalSourceConnectors(root?: string): string[];
export interface FindUnapprovedBoundedReadsOptions {
    readonly exceptions?: readonly BoundedReadException[];
    readonly root?: string;
}
export declare function findUnapprovedBoundedReads(options?: FindUnapprovedBoundedReadsOptions): BoundedReadFinding[];
//# sourceMappingURL=local-source-bounded-read-guard.d.ts.map