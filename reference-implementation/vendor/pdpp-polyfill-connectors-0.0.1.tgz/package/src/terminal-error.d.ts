/**
 * The typed terminal-failure primitive shared by the connector runtime and
 * the session-establishment flow (`session-establish.ts`). Kept in its own
 * module so both can construct/instanceof-check the same class without a
 * runtime import cycle. Connectors never import this module directly: their
 * constructor is `createConnectorFailure` in `connector-runtime.ts`, which
 * composes this class with the code-charset gate below.
 */
export interface TerminalErrorDetails {
    code?: string;
    message: string;
    /** Provider-neutral action for the runtime to preserve on DONE.error. */
    recovery_hint?: string | {
        action: string;
        retryable?: boolean;
    };
    retryable: boolean;
}
/**
 * A failure that the runtime should convert to a terminal DONE rather than
 * let it bubble as an unhandled rejection. Carries an explicit `retryable`
 * bit so the outer catch doesn't have to heuristically pattern-match the
 * message. The optional `code` carries a stable, infrastructure-set
 * machine-actionable code (e.g. `browser_surface_attach_exhausted`) through
 * to `DONE.error.code` — see `emitFailed`'s composition with a connector's
 * `normalizeTerminalError` for how this survives connector overrides.
 */
export declare class TerminalError extends Error {
    readonly code?: string;
    readonly retryable: boolean;
    constructor(message: string, options?: {
        cause?: unknown;
        code?: string;
        retryable?: boolean;
    });
}
/**
 * Validate a connector-declared terminal-error `code` against the strict
 * charset/length contract `CONNECTOR_ERROR_CODE_RE` documents. Throws
 * (fails closed) rather than silently truncating, stripping, or passing an
 * invalid code through — an invalid code is a connector programming error,
 * not a runtime condition to paper over, because `code` reaches
 * `connector_error_json` with no further redaction.
 */
export declare function assertValidConnectorErrorCode(code: string): void;
/**
 * Non-throwing sibling of `assertValidConnectorErrorCode`: does `value`
 * already satisfy the unredacted `code` charset/length contract?
 *
 * Used by callers that catch an arbitrary thrown `Error` (e.g.
 * `session-establish.ts`'s `ensureSession` catch block) and want to
 * opportunistically recover a `code` FROM the thrown message when the
 * connector happened to throw a bare `Error("some_snake_case_token")` —
 * which is exactly what every `ensureHebSession`/`ensureUsaaSession`/etc.
 * throw site already does. The anchored `^...$` regex (no spaces, no
 * colons) is what keeps this safe: a compound message like
 * "usaa_session_failed: source_unavailable: ..." fails the check and is
 * correctly left to the redacted `message` channel only — only a thrown
 * message that IS, in its entirety, one short snake_case token is treated
 * as code-shaped.
 */
export declare function isConnectorErrorCodeShaped(value: string): boolean;
//# sourceMappingURL=terminal-error.d.ts.map