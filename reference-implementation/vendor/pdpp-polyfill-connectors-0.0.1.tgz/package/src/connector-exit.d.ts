interface FlushAndExitOptions {
    exit?: (code: number) => void;
    runtimeAckTimeoutMs?: number;
    stdin?: RuntimeAckReadable;
    stdout?: RuntimeAckWritable;
    stdoutDrainTimeoutMs?: number;
}
interface RuntimeAckReadable {
    destroyed: boolean;
    off: (event: "close" | "end" | "error", listener: () => void) => unknown;
    once: (event: "close" | "end" | "error", listener: () => void) => unknown;
    readableEnded: boolean;
}
interface RuntimeAckWritable {
    off: (event: "drain", listener: () => void) => unknown;
    once: (event: "drain", listener: () => void) => unknown;
    writableLength: number;
}
/**
 * Connector terminal handshake.
 *
 * Draining stdout only proves bytes reached the OS pipe. The reference runtime
 * closes connector stdin after it has consumed DONE and completed final ingest;
 * waiting for that EOF prevents records_emitted validation races on slow RS
 * flushes. The long ACK timeout is a last-resort orphan guard, not normal flow.
 */
export declare function flushAndExitAfterRuntimeAck(code: number, options?: FlushAndExitOptions): void;
export {};
//# sourceMappingURL=connector-exit.d.ts.map