import type { Page } from "playwright";
export interface CapturedBodyResponse {
    body: Buffer;
    contentType: string;
    method: string;
    source: "cdp" | "playwright";
    status: number;
    suggestedFilename: string | null;
    url: string;
}
export interface BodyResponseCandidateDiagnostic {
    bodyBytes?: number;
    bodyError?: string;
    contentDisposition: string;
    contentType: string;
    method: string;
    reason: "body_error" | "matched" | "not_expected_body";
    source: "cdp" | "playwright";
    status: number;
    url: string;
}
export interface BodyResponseDiagnostics {
    candidates: BodyResponseCandidateDiagnostic[];
    cdpError: string | null;
    cdpReady: boolean;
}
export interface BodyResponseQueue {
    detach: () => void;
    diagnostics: () => BodyResponseDiagnostics;
    ready: Promise<void>;
    waitForNextResponse: (opts?: {
        timeoutMs?: number;
    }) => Promise<CapturedBodyResponse>;
}
export interface BodyResponseQueueOptions {
    isExpectedBody: (body: Buffer, headers: Record<string, string>) => boolean;
    maxDiagnostics?: number;
    redactUrl?: (url: string) => string;
    shouldInspect: (headers: Record<string, string>, url: string) => boolean;
    truncateMessageLength?: number;
}
export declare function waitForOptionalBodyResponse(responsePromise: Promise<CapturedBodyResponse>, timeoutMs: number): Promise<CapturedBodyResponse | null>;
export declare function suggestedFilenameFromHeaders(headers: Record<string, string>): string | null;
export declare function normalizeResponseHeaders(headers: Record<string, unknown>): Record<string, string>;
export declare function isLikelyPdfResponseBody(body: Buffer, headers: Record<string, string>): boolean;
export declare function attachBodyResponseQueue(page: Page, options: BodyResponseQueueOptions): BodyResponseQueue;
//# sourceMappingURL=browser-artifact-response.d.ts.map