/**
 * A provider-neutral OAuth2 authorization-code adapter, constructed
 * entirely from a connector manifest's `capabilities.auth` declaration
 * (`authorization_url`, `token_url`, `userinfo_url`, `scopes`,
 * `authorization_params`, `deployment_config`). This module names no
 * specific provider anywhere in its own source: every URL, scope, and
 * deployment-config value it uses comes from the manifest and the injected
 * deployment-config resolver — never a literal env var name, and never an
 * implicit default query parameter.
 *
 * Registers itself under the "oauth2_generic" kind at module load.
 */
import type { ProviderAuthAdapter } from "./provider-auth-adapter.ts";
export declare class Oauth2GenericProviderAuthError extends Error {
    readonly code: string;
    readonly status: number;
    constructor(code: string, message: string, status?: number);
}
export declare const OAUTH2_GENERIC_EXCHANGER_KIND = "oauth2_generic";
export declare const oauth2GenericAdapter: ProviderAuthAdapter;
//# sourceMappingURL=oauth2-generic-provider-auth.d.ts.map