// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { RetryExhaustedError, retryHttp, TerminalHttpStatusError, } from "@pdpp/connector-protocol/http-retry";
import { ProviderPacing } from "./provider-pacing.js";
/**
 * The terminal error a 429 exhaustion throws — `<name>_rate_limited` — so the
 * existing connector `retryablePattern` cross-run contract still fires.
 */
export class ConnectorRateLimitedError extends Error {
    constructor(name, options) {
        super(`${name}_rate_limited`, options);
        this.name = "ConnectorRateLimitedError";
    }
}
const DEFAULT_MAX_ATTEMPTS = 4;
const DEFAULT_BASE_DELAY_MS = 1000;
const DEFAULT_MAX_DELAY_MS = 60_000;
const DEFAULT_MAX_RETRY_AFTER_MS = 5 * 60_000;
/**
 * Cold-start DISCOVERY seed (ms) every governor enters the AIMD ramp from when
 * no fresh learned interval is restored. "Safe but not glacial": polite against
 * an unknown-quota API, well above the ceiling. Live-calibrated on ChatGPT
 * (run_1781139968889) and adopted as the shared default for all API connectors.
 */
export const DEFAULT_PACING_INITIAL_INTERVAL_MS = 1000;
/**
 * ChatGPT's live-calibrated rate ceiling (ms), retained as a NAMED, AUDITED
 * reference value — NOT a silent cross-provider default. As of the §3
 * ProviderProfile generalization the governor no longer falls back to this:
 * every governor-using connector declares its own ceiling via the required
 * `profile.pacingMinIntervalMs` (spec §3 rule 6). This export survives only as
 * documentation of ChatGPT's audited number and for tests that pin it; a new
 * connector author must NOT reach for it (author a per-connector profile factory
 * in `provider-profile.ts` derived from the provider's documented limit instead —
 * see the WI-1b factories, e.g. `githubPacingProfile()`).
 */
export const DEFAULT_PACING_MIN_INTERVAL_MS = 250;
export function createConnectorHttpGovernor(options) {
    // Belt-and-braces for the spec §3 "missing field = build error" rule: the type
    // makes `profile.pacingMinIntervalMs` required, but a JS caller (no tsc) could
    // still omit it. Fail LOUD rather than silently borrowing a shared default —
    // an omitted safety ceiling must never pass quietly.
    if (!options.profile ||
        typeof options.profile.pacingMinIntervalMs !== "number" ||
        !Number.isFinite(options.profile.pacingMinIntervalMs) ||
        options.profile.pacingMinIntervalMs <= 0) {
        throw new Error(`createConnectorHttpGovernor({ name: "${options.name}" }) requires a per-provider ` +
            "profile.pacingMinIntervalMs (the rate ceiling). Declare one from this provider's " +
            "observed behavior — there is NO cross-provider default (SLVP-ideal spec §3 rule 6).");
    }
    // Adaptive collection is ON by default: a `{ name, profile }` call yields
    // slow-start discovery + AIMD accelerate-under-success + ceiling-bounded
    // back-off. Pass `pacingInitialIntervalMs: 0` to opt out of pacing entirely.
    const pacingInitialIntervalMs = options.pacingInitialIntervalMs ?? DEFAULT_PACING_INITIAL_INTERVAL_MS;
    // The rate ceiling comes from the REQUIRED per-provider profile — never a
    // shared fallback (spec §3). A missing profile is a compile-time error on the
    // options type, so by the time we are here `pacingMinIntervalMs` is always a
    // declared, per-provider value.
    const { pacingMinIntervalMs } = options.profile;
    const pacingEnabled = pacingInitialIntervalMs > 0;
    // Warm-start: seed from the prior run's learned interval when the connector
    // restored one (already staleness-guarded by readPersistedPacingInterval).
    const restored = options.restoredIntervalMs === null ||
        options.restoredIntervalMs === undefined ||
        !Number.isFinite(options.restoredIntervalMs)
        ? null
        : options.restoredIntervalMs;
    const pacing = new ProviderPacing({
        initialIntervalMs: pacingInitialIntervalMs,
        // A zero discovery interval is the explicit pacing opt-out. Do not let the
        // provider floor turn that disabled path into a newly introduced wait.
        minIntervalMs: pacingEnabled ? pacingMinIntervalMs : 0,
        ...(restored === null ? {} : { restoredIntervalMs: restored }),
        ...(options.now === undefined ? {} : { now: options.now }),
        ...(options.sleep === undefined
            ? {}
            : { sleep: (ms) => Promise.resolve(options.sleep?.(ms)) }),
    });
    // The single pre-flight wait. ProviderPacing.admit() is the ONE governor for
    // these serial API connectors. There is deliberately no second pre-flight
    // gate to compose with — that is the convergence invariant.
    const governor = {
        acquire: () => pacing.admit(),
    };
    const baseDelayMs = options.baseDelayMs ?? DEFAULT_BASE_DELAY_MS;
    const maxAttempts = options.maxAttempts ?? DEFAULT_MAX_ATTEMPTS;
    const maxDelayMs = options.maxDelayMs ?? DEFAULT_MAX_DELAY_MS;
    const maxRetryAfterMs = options.maxRetryAfterMs ?? DEFAULT_MAX_RETRY_AFTER_MS;
    async function request(send, classify) {
        try {
            const response = await retryHttp({
                baseDelayMs,
                // The single pre-flight gate fires before each attempt (initial + retry),
                // so retries pass through the same governor as originals (prior-art
                // transferable pattern #3).
                beforeAttempt: () => governor.acquire(),
                maxAttempts,
                maxDelayMs,
                maxRetryAfterMs,
                ...(options.random === undefined ? {} : { random: options.random }),
                ...(options.retryBudget === undefined
                    ? {}
                    : { retryBudget: options.retryBudget }),
                ...((options.retrySleep ?? options.sleep) === undefined
                    ? {}
                    : { sleep: options.retrySleep ?? options.sleep }),
                request: async () => {
                    const raw = await send();
                    const c = classify(raw);
                    const result = {
                        status: c.status,
                        value: c.value,
                    };
                    if (c.headers) {
                        result.headers = c.headers;
                    }
                    return result;
                },
                onRetry: () => {
                    // Feed the pacing AIMD with the throttle signal (multiplicative
                    // fill-rate decrease) ONLY. Crucially we do NOT forward Retry-After
                    // into the pacing bucket: `retryHttp` already sleeps the Retry-After
                    // (or jittered backoff) for this attempt. Re-queuing it as a pacing
                    // pre-flight wait would double-pay the same delay — the exact
                    // `retryAfterAlreadySlept` / `absorbedByRequestWait` guard. The
                    // backoff (post-failure) and pacing (pre-flight) stay one wait each.
                    pacing.recordThrottle({});
                },
            });
            pacing.recordSuccess();
            return response;
        }
        catch (error) {
            if (isRateLimitTerminal(error)) {
                throw new ConnectorRateLimitedError(options.name, { cause: error });
            }
            throw error;
        }
    }
    function snapshot() {
        return pacingEnabled ? pacing.snapshot() : null;
    }
    return { governor, request, snapshot };
}
function isRateLimitTerminal(error) {
    if (error instanceof RetryExhaustedError) {
        const cause = error.originalCause;
        return (typeof cause === "object" &&
            cause !== null &&
            cause.status === 429);
    }
    if (error instanceof TerminalHttpStatusError) {
        return error.status === 429;
    }
    return false;
}
// ─── Warm-start persistence + observability helpers (shared, opt-in) ─────────
//
// These let any governor-using connector thread the learned rate across runs and
// surface it to operators with ~2 lines of glue, instead of hand-rolling the
// read/write/snapshot logic the ChatGPT detail path pioneered. The governor owns
// the GCRA mechanics; the connector owns where its durable state lives.
/** Default state sub-key the persisted learned interval is stored under. */
export const PACING_STATE_INTERVAL_KEY = "pacing_interval_ms";
/** Default state sub-key the persist timestamp (ms epoch) is stored under. */
export const PACING_STATE_RECORDED_AT_KEY = "pacing_recorded_at_ms";
/**
 * Default staleness guard (ms): a learned interval older than this is discarded
 * so a long-idle resume cold-starts conservatively against a possibly-reset
 * provider quota.
 *
 * Rationale: provider quotas reset on hour/day scales and scheduled connector
 * runs are spaced hours apart, so a learned interval is meaningful for HOURS.
 * 6 hours covers typical quota-reset cadences (most providers use daily or
 * per-hour windows) and matches the expected gap between scheduled runs, while
 * still discarding rates from arbitrarily distant prior sessions.
 * Operator-tunable via the `stalenessMs` option if a connector's quota resets
 * faster (or if you want a larger safety margin).
 */
export const DEFAULT_PACING_STALENESS_MS = 6 * 60 * 60 * 1000; // 6 hours
/**
 * Read a fresh learned interval out of a connector's durable state cursor for
 * warm-start, applying the staleness guard. Returns `null` when absent, malformed,
 * or older than `stalenessMs` (→ cold start). Pass the result as the governor's
 * `restoredIntervalMs`. `stateSlice` is the per-stream cursor object the connector
 * persisted the pacing fields into (e.g. `state.messages`).
 */
export function readPersistedPacingInterval(stateSlice, options = {}) {
    if (!stateSlice || typeof stateSlice !== "object") {
        return null;
    }
    const intervalKey = options.intervalKey ?? PACING_STATE_INTERVAL_KEY;
    const recordedAtKey = options.recordedAtKey ?? PACING_STATE_RECORDED_AT_KEY;
    const stalenessMs = options.stalenessMs ?? DEFAULT_PACING_STALENESS_MS;
    const now = options.now ?? Date.now;
    const intervalMs = stateSlice[intervalKey];
    const recordedAtMs = stateSlice[recordedAtKey];
    if (typeof intervalMs !== "number" ||
        !Number.isFinite(intervalMs) ||
        intervalMs <= 0) {
        return null;
    }
    if (typeof recordedAtMs !== "number" || !Number.isFinite(recordedAtMs)) {
        return null;
    }
    if (now() - recordedAtMs > stalenessMs) {
        return null;
    }
    return intervalMs;
}
/**
 * Build the durable state fields that persist a governor's learned interval for
 * the next run's warm-start. Spread the result into the connector's STATE cursor
 * alongside its own cursor fields. Returns `{}` when pacing is disabled (nothing
 * to persist).
 *
 * SEED-POISONING GUARD: the persisted interval is CAPPED at the cold-start
 * baseline (`initialIntervalMs`). Warm-start exists only to let the next run START
 * FASTER than a cold start by reusing a learned healthy operating rate — it must
 * never make the next run start SLOWER than cold. A run that ended deep in
 * throttle (an interval the AIMD backed off to, or a provider Retry-After spike)
 * would otherwise persist that transient backoff as the seed, so the next run
 * would crawl back toward the ceiling from an interval worse than cold-start (the
 * descent compounding across runs). Capping at cold-start means a healthy run
 * persists its fast learned interval while a throttled run persists at most the
 * cold-start baseline (a clean cold re-entry). Within-run backoff still protects
 * the live account; only the CROSS-run seed is floored.
 */
export function buildPacingStateFields(governor, options = {}) {
    const snapshot = governor?.snapshot();
    if (!snapshot) {
        return {};
    }
    const intervalKey = options.intervalKey ?? PACING_STATE_INTERVAL_KEY;
    const recordedAtKey = options.recordedAtKey ?? PACING_STATE_RECORDED_AT_KEY;
    const now = options.now ?? Date.now;
    return {
        [intervalKey]: Math.min(snapshot.intervalMs, snapshot.initialIntervalMs),
        [recordedAtKey]: now(),
    };
}
/** Requests/min from an interval (ms); 0 interval reads as 0 rate (never ∞). */
function ratePerMinFromInterval(intervalMs) {
    return intervalMs > 0 ? Math.round(60_000 / intervalMs) : 0;
}
/**
 * Build the operator-legible `collection_rate` progress from a governor's live
 * snapshot, or `null` when pacing is disabled. PURE; carries no account content —
 * only rate numbers and the last back-off reason (SLVP ideal §5: legibility).
 * The shape matches the `CollectionRateProgress` runtime-protocol type so the
 * caller can emit it as `{ type: "PROGRESS", collection_rate }`.
 */
export function buildCollectionRateProgress(governor) {
    const snapshot = governor?.snapshot();
    if (!snapshot) {
        return null;
    }
    return {
        ceiling_interval_ms: snapshot.minIntervalMs,
        ceiling_rate_per_min: ratePerMinFromInterval(snapshot.minIntervalMs),
        current_interval_ms: snapshot.intervalMs,
        effective_rate_per_min: ratePerMinFromInterval(snapshot.intervalMs),
        last_backoff: snapshot.lastBackoff
            ? {
                at_interval_ms: snapshot.lastBackoff.atIntervalMs,
                reason: snapshot.lastBackoff.reason,
            }
            : null,
        object: "collection_rate",
    };
}
