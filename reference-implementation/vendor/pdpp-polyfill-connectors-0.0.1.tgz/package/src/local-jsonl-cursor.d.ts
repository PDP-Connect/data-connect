export interface LocalJsonlPhysicalCursorV1 {
    committed_offset_bytes: number;
    committed_line_count?: number;
    committed_prefix_sha256: string;
    observed_mtime_ms: number;
    observed_size_bytes: number;
}
export type LocalJsonlDecision = {
    kind: "fast_skip";
} | {
    kind: "verified_noop";
} | {
    kind: "append";
    start_offset_bytes: number;
} | {
    kind: "rebuild";
    reason: "invalid_cursor" | "prefix_changed" | "shrunk_before_offset";
};
export interface LocalJsonlScanResult {
    cursor: LocalJsonlPhysicalCursorV1;
    decision: LocalJsonlDecision;
    lines_delivered: number;
    prefix_bytes_hashed: number;
    tail_bytes_parsed: number;
}
export interface ScanLocalJsonlArgs {
    /** Byte offset is the start of the line; line numbers are one-based. */
    onLine: (line: Buffer, byteOffset: number, lineNumber: number) => Promise<void>;
    onIncompleteLine?: (line: Buffer, byteOffset: number, lineNumber: number) => Promise<void>;
    path: string;
    prior: LocalJsonlPhysicalCursorV1 | undefined;
}
export declare class LocalJsonlUnstableSourceError extends Error {
    constructor(message: string);
}
/** Filesystem failure, distinct from callback or output-transport failure. */
export declare class LocalJsonlSourceReadError extends Error {
    readonly path: string;
    readonly operation: "open" | "read" | "stat" | "close";
    constructor(path: string, operation: LocalJsonlSourceReadError["operation"], cause: unknown);
}
/** A complete line was present but could not be parsed as JSON. */
export declare class LocalJsonlMalformedLineError extends Error {
    readonly committed_offset_bytes: number;
    constructor(committedOffsetBytes: number, options?: ErrorOptions);
}
export declare function isLocalJsonlPhysicalCursorV1(value: unknown): value is LocalJsonlPhysicalCursorV1;
/**
 * Scan one local JSONL file through a fixed open-file snapshot. The callback is
 * invoked only for LF-terminated lines. A caller that rejects a malformed line
 * prevents this function from returning a cursor, so the source boundary stays
 * before the rejected line. STATE is returned only after the path stays
 * compatible with the opened handle, so a caller that emits it after this
 * promise resolves keeps the connector's existing checkpoint barrier intact.
 */
export declare function scanLocalJsonl({ onLine, onIncompleteLine, path, prior, }: ScanLocalJsonlArgs): Promise<LocalJsonlScanResult>;
//# sourceMappingURL=local-jsonl-cursor.d.ts.map