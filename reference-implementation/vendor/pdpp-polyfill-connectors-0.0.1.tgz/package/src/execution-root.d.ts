export declare class CollectorExecutionRootError extends Error {
    constructor(message: string);
}
export interface ResolveExecutionRootInput {
    readonly args: readonly string[];
}
export declare function resolveExecutionRoot(spec: ResolveExecutionRootInput, startUrl?: string | URL): string;
//# sourceMappingURL=execution-root.d.ts.map