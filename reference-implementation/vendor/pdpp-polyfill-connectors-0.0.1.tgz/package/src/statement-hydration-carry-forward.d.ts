/** The content-addressed PDF pointer fields plus the positive content
 *  fingerprint, carried across runs. The blob pointers
 *  (`document_url`/`pdf_path`/`pdf_sha256`) point at bytes a prior run stored
 *  and never move; the content fields (`pdf_text_sha256`/`pdf_page_count`) are
 *  derived from those same bytes, so a previously-hydrated statement that fails
 *  to re-download this run carries BOTH forward together — otherwise a
 *  transient failure would drop the content fingerprint and flip the canonical
 *  exclusion back to conservative for that run, re-versioning an immutable
 *  statement. Content fields are optional so legacy persisted entries (written
 *  before this field existed) decode cleanly. */
export interface StatementHydration {
    document_url: string | null;
    pdf_page_count?: number | null;
    pdf_path: string | null;
    pdf_sha256: string | null;
    pdf_text_sha256?: string | null;
}
/** The all-null index-only triple a never-hydrated statement emits. */
export declare const NEVER_HYDRATED: StatementHydration;
/** True iff this hydration entry carries a real (non-null) pointer. A prior
 *  entry whose `pdf_path` is null was itself an index-only emit — there is
 *  nothing to carry forward, so the statement stays index-only. */
export declare function isHydrated(h: StatementHydration | undefined): h is StatementHydration;
export interface StatementHydrationCursor {
    /** Drop ids not `note`d this run. Idempotent. Only valid on full-scan
     *  streams (both statement streams are full scans of the documents index),
     *  so a statement no longer listed stops being carried forever. Call in
     *  lockstep with the fingerprint cursor's `dropUnseenIds()`. */
    dropUnseenIds: () => void;
    /** Record this statement id's hydration pointers into the next-run map and
     *  the seen-set. MUST be called for every observed statement id this run —
     *  with the freshly hydrated pointers on success, and (after carry-forward)
     *  with the resolved pointers on failure — so the next run's prior map is
     *  complete and the prune step has the right inputs. */
    note: (id: string, value: StatementHydration) => void;
    /** The pointers to emit for a statement that failed hydration this run:
     *  the prior hydrated pointers if the statement was previously hydrated,
     *  otherwise the all-null index-only triple. Pure: does not mutate the
     *  cursor (call `note` separately with the resolved value). */
    resolveOnFailure: (id: string) => StatementHydration;
    /** Number of ids in the next map. */
    size: () => number;
    /** Serializable next-run map for the `hydration` key of the statements
     *  STATE cursor. */
    toState: () => Record<string, StatementHydration>;
}
/** Open a statement hydration carry-forward cursor seeded from the prior
 *  STATE cursor's decoded `hydration` map. Reuses the shared
 *  `openCarryForwardCursor` seed/seen/prune/serialize lifecycle. */
export declare function openStatementHydrationCursor(prior: ReadonlyMap<string, StatementHydration>): StatementHydrationCursor;
/** Decode the prior `statements` STATE cursor's `hydration` map. Keyed by
 *  statement `id`. Tolerant of legacy cursors (no `hydration`), missing
 *  field, wrong types, or values from a partially-different schema — bad
 *  entries are silently dropped rather than failing the whole run. A legacy
 *  cursor decodes to an empty map, so the first post-deploy run rebuilds it
 *  and any statement that fails hydration before it has ever been seen
 *  hydrated stays honestly index-only. */
export declare function readPriorStatementHydration(streamState: unknown): Map<string, StatementHydration>;
//# sourceMappingURL=statement-hydration-carry-forward.d.ts.map