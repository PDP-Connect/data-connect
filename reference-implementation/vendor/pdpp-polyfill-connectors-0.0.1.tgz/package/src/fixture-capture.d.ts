import type { Page } from "playwright";
import type { RecordData } from "./connector-runtime.ts";
/** Metadata for a single captured HTTP response. */
export interface HttpCaptureMeta {
    method?: string;
    path?: string;
    status?: number;
    [extra: string]: unknown;
}
export type LocatorProbe = {
    description?: string;
    id: string;
    kind: "css";
    selector: string;
} | {
    description?: string;
    exact?: boolean;
    id: string;
    kind: "label";
    text: string;
} | {
    description?: string;
    exact?: boolean;
    id: string;
    kind: "placeholder";
    text: string;
} | {
    description?: string;
    exact?: boolean;
    id: string;
    kind: "role";
    name?: string;
    namePattern?: string;
    nameFlags?: string;
    role: Parameters<Page["getByRole"]>[0];
} | {
    description?: string;
    exact?: boolean;
    id: string;
    kind: "text";
    text: string;
};
interface LocatorProbeLocator {
    ariaSnapshot: (options?: Parameters<ReturnType<Page["locator"]>["ariaSnapshot"]>[0]) => Promise<string>;
    count: () => Promise<number>;
    first: () => LocatorProbeLocator;
    isEnabled: (options?: Parameters<ReturnType<Page["locator"]>["isEnabled"]>[0]) => Promise<boolean>;
    isVisible: () => Promise<boolean>;
}
export type LocatorProbePage = Pick<Page, "title" | "url"> & {
    getByLabel?: (text: Parameters<Page["getByLabel"]>[0], options?: Parameters<Page["getByLabel"]>[1]) => LocatorProbeLocator;
    getByPlaceholder?: (text: Parameters<Page["getByPlaceholder"]>[0], options?: Parameters<Page["getByPlaceholder"]>[1]) => LocatorProbeLocator;
    getByRole?: (role: Parameters<Page["getByRole"]>[0], options?: Parameters<Page["getByRole"]>[1]) => LocatorProbeLocator;
    getByText?: (text: Parameters<Page["getByText"]>[0], options?: Parameters<Page["getByText"]>[1]) => LocatorProbeLocator;
    locator: (selector: Parameters<Page["locator"]>[0], options?: Parameters<Page["locator"]>[1]) => LocatorProbeLocator;
};
/** Handle returned by createCaptureSession when capture is enabled. */
export interface CaptureSession {
    readonly baseDir: string;
    captureDom: (page: Page, label: string) => Promise<void>;
    captureHttp: (label: string, body: unknown, meta?: HttpCaptureMeta) => void;
    captureLocatorProbe?: (page: LocatorProbePage, label: string, probes: readonly LocatorProbe[]) => Promise<void>;
    /**
     * Apply post-run retention policy:
     *   - PDPP_CAPTURE_FIXTURES mode: no-op (always retain).
     *   - PDPP_CAPTURE_ON_FAILURE mode: if markSucceeded() was called,
     *     delete the raw run directory. Otherwise retain.
     * Safe to call multiple times; the second call is a no-op.
     */
    finalize: () => void;
    /**
     * True once any credential value has been registered for this run.
     *
     * This is the trace-suppression gate. Playwright records `fill()` action
     * PARAMETERS into `trace.trace`, so a trace taken after a credential is
     * typed contains that credential verbatim and no tracing option removes it.
     * `makeTracer` reads this to decide whether a trace may be persisted.
     * Deliberately a method, not a snapshot boolean: the tracer asks at stop()
     * time, long after credentials resolve.
     */
    hasRegisteredSecrets: () => boolean;
    /** True when this session retains raw fixtures on success. */
    readonly keepOnSuccess: boolean;
    /**
     * Mark the run as successful. Combined with `finalize()`, this drives
     * the failure-only retention policy. With `keepOnSuccess=true` (the
     * always-retain default), calling this has no effect.
     */
    markSucceeded: () => void;
    recordRecord: (msg: {
        stream: string;
        data: RecordData;
    }) => void;
    /**
     * Register credential values the run holds so capture can redact them
     * wherever they appear, including fields no rule would recognize as secret.
     * Call as soon as credentials resolve and before any page interaction.
     * Values shorter than the matching floor are ignored — see capture-redaction.
     *
     * Registering ANY value also disarms trace persistence for the run, even a
     * value below the matching floor: the floor governs text substitution, not
     * whether the run handles credentials at all.
     */
    registerSecrets: (values: Iterable<string>) => void;
    readonly runId: string;
    setTraceCheckpointHook?: (hook: ((label: string) => Promise<void>) | null) => void;
}
export declare function createCaptureSession(connectorName: string): CaptureSession | null;
export {};
//# sourceMappingURL=fixture-capture.d.ts.map