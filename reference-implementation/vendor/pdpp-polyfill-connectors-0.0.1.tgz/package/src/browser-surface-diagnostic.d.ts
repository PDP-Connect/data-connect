export type BrowserSurfaceKind = "chase_current_activity" | "usaa_transaction_export";
export type BrowserSurfacePosture = "recognized" | "verified_empty" | "parser_zero" | "unexpected";
export type BrowserSurfaceManagedState = "isolated" | "legacy_remote" | "managed" | "unknown";
export type BrowserSurfaceRoute = "expected" | "interstitial" | "unknown";
export type BrowserSurfaceWaitOutcome = "not_needed" | "resolved" | "timed_out" | "unknown";
/** Exact persisted contract; all members are finite, bounded structural facts. */
export interface BrowserSurfaceDiagnostic {
    readonly account_detail_marker_count: number;
    readonly activity_table_marker_count: number;
    readonly dashboard_marker_count: number;
    readonly managed_surface: BrowserSurfaceManagedState;
    readonly navigation_marker_count: number;
    readonly parser_count: number;
    readonly phase: "final_snapshot" | "no_export_affordance";
    readonly posture: BrowserSurfacePosture;
    readonly read_count: number;
    readonly route: BrowserSurfaceRoute;
    readonly surface: BrowserSurfaceKind;
    readonly target_count: number;
    readonly transaction_marker_count: number;
    readonly verified_empty_marker_count: number;
    readonly wait_outcome: BrowserSurfaceWaitOutcome;
}
export interface BrowserSurfaceDiagnosticInput {
    readonly accountDetailMarkerCount?: unknown;
    readonly activityTableMarkerCount?: unknown;
    readonly dashboardMarkerCount?: unknown;
    readonly kind: unknown;
    readonly managedSurface: unknown;
    readonly navigationMarkerCount?: unknown;
    readonly parserCount?: unknown;
    readonly readCount?: unknown;
    readonly route: unknown;
    readonly targetCount?: unknown;
    readonly transactionMarkerCount?: unknown;
    readonly verifiedEmptyMarkerCount?: unknown;
    readonly waitOutcome: unknown;
}
/** Map the runtime's non-sensitive launch kind to durable evidence vocabulary. */
export declare function browserSurfaceManagedState(value: string | undefined): BrowserSurfaceManagedState;
/**
 * Return null unless every categorical input is part of the closed contract.
 * Counts are normalized to bounded integers; all unrecognized source values
 * are rejected rather than copied into durable output.
 */
export declare function buildBrowserSurfaceDiagnostic(input: BrowserSurfaceDiagnosticInput): BrowserSurfaceDiagnostic | null;
//# sourceMappingURL=browser-surface-diagnostic.d.ts.map