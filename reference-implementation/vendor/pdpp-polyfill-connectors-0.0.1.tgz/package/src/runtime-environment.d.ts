export interface ContainerDetectionEnv {
    PDPP_FORCE_CONTAINER?: string;
}
export interface ContainerDetectionDeps {
    fileExists?: (path: string) => boolean;
}
/**
 * Returns true when the current process appears to be running inside a
 * container. Pure: no I/O is performed beyond an `existsSync` against a
 * known sentinel path; tests can inject `fileExists` to control the
 * outcome deterministically without touching the host filesystem.
 */
export declare function isRunningInContainer(env?: NodeJS.ProcessEnv | ContainerDetectionEnv, deps?: ContainerDetectionDeps): boolean;
//# sourceMappingURL=runtime-environment.d.ts.map