export declare const DEFAULT_AS_URL: string;
export declare const DEFAULT_RS_URL: string;
export declare const DEFAULT_SUBJECT_ID: string;
export declare const MANIFEST_DIR: string;
export declare const CONNECTORS_DIR: string;
export interface ConnectorPaths {
    connectorPath: string;
    manifestPath: string;
}
export declare const KNOWN_CONNECTOR_NAMES: string[];
export declare function getConnectorPaths(name: string): ConnectorPaths;
export interface Manifest {
    connector_id: string;
    [extra: string]: unknown;
}
export declare function readManifest(name: string): Manifest;
/**
 * The connector set `bin/register-all.ts`'s smoke test registers: every
 * connector in the registry. Lifecycle tier controls what the owner is
 * offered; it does not remove a manifest from developer registration smoke
 * tests. Registering a Development manifest does not call its provider or
 * claim that its upstream remains available.
 *
 * This is the ONLY filter — manual-upload, local-device, and unlisted
 * connectors stay included, matching prior behavior: register-all's job is
 * "does the manifest parse and register", not "is this connector
 * owner-visible or auto-schedulable".
 */
export declare function selectRegisterAllConnectors(connectorNames: readonly string[], _readManifestFn: (name: string) => Manifest): string[];
export declare function registerManifest(asUrl: string, manifest: Manifest): Promise<unknown>;
export declare function issueOwnerToken(asUrl: string, subjectId?: string): Promise<string>;
export interface StartEmbeddedServerOptions {
    dbPath?: string;
}
export declare function startEmbeddedServer({ dbPath, }?: StartEmbeddedServerOptions): Promise<unknown>;
export declare function loadPriorState(rsUrl: string, ownerToken: string, connectorId: string): Promise<Record<string, unknown> | null>;
export interface RunOneOptions {
    asUrl?: string;
    onInteraction?: (msg: unknown) => Promise<unknown> | unknown;
    rsUrl?: string;
    subjectId?: string;
}
export interface RunOneResult {
    manifest: Manifest;
    ownerToken: string;
    result: unknown;
}
export declare function runOne(name: string, { asUrl, rsUrl, subjectId, onInteraction, }?: RunOneOptions): Promise<RunOneResult>;
export interface QueryStreamOptions {
    connectorId?: string;
    limit?: number;
    [filter: string]: string | number | undefined;
}
export interface QueryStreamResult {
    body: unknown;
    status: number;
}
export declare function queryStream(rsUrl: string, ownerToken: string, stream: string, { limit, connectorId, ...filters }?: QueryStreamOptions): Promise<QueryStreamResult>;
//# sourceMappingURL=orchestrator.d.ts.map