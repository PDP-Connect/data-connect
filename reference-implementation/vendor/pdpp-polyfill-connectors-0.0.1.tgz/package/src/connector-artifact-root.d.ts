export interface ConnectorArtifactRootEnv {
    PDPP_CONNECTOR_ARTIFACT_ROOT?: string;
    PDPP_DB_PATH?: string;
}
/**
 * Which of the three resolution rules produced the root.
 *
 * `local-development-fallback` is the only one that is NOT deployment-owned;
 * callers disclose it rather than let it pass unnoticed.
 */
export type ConnectorArtifactRootSource = "explicit-override" | "database-directory" | "local-development-fallback";
export interface ConnectorArtifactRoot {
    /** True when the root is deployment-owned (rules 1 and 2). */
    deploymentOwned: boolean;
    /** Absolute path to the durable root. */
    root: string;
    source: ConnectorArtifactRootSource;
}
/**
 * Resolve the durable artifact root. Pure: reads env only, touches no
 * filesystem, creates nothing. Callers `mkdir` their own subdirectory —
 * resolution must stay side-effect free so tests and diagnostics can ask
 * "where would this go?" without provisioning it.
 */
export declare function resolveConnectorArtifactRoot(env?: NodeJS.ProcessEnv | ConnectorArtifactRootEnv): ConnectorArtifactRoot;
/**
 * Resolve the durable directory for one connector's artifacts, namespaced by
 * connector so two connectors never collide inside the shared root.
 *
 * `segments` are appended verbatim (e.g. a Slack workspace subdomain). They
 * come from connector-controlled values, not raw remote input; callers that
 * pass anything user-supplied sanitize it first.
 */
export declare function resolveConnectorArtifactDir(connectorName: string, segments?: readonly string[], env?: NodeJS.ProcessEnv | ConnectorArtifactRootEnv): ConnectorArtifactRoot;
/**
 * One-line disclosure of where durable artifacts landed and why. Connectors
 * emit this through their progress channel so the local-development fallback
 * is stated in the run log instead of being inferred from a missing archive
 * three container replacements later.
 */
export declare function describeConnectorArtifactRoot(resolved: ConnectorArtifactRoot): string;
//# sourceMappingURL=connector-artifact-root.d.ts.map