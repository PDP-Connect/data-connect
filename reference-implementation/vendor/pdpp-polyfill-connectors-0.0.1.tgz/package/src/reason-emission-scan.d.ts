export interface ReasonEmissionScanResult {
    /** Reason codes resolved (directly or via one hop) to a finite literal set. */
    literalReasons: string[];
    /** In-scope `reason:` values that could not be resolved within one hop. */
    unresolved: {
        file: string;
        line: number;
        snippet: string;
    }[];
}
/** Every non-test `.ts`/`.tsx` file directly under a connector's own directory (not recursive into subdirectories). */
export declare function connectorProductionFiles(connectorDir: string): string[];
export declare const DETAIL_GAP_MESSAGE_REASON_LITERALS: readonly string[];
/** Scans one file's source for every reason code emitted on a SKIP_RESULT/connector_error/DETAIL_GAP object literal. */
export declare function scanFileForReasonEmissions(absPath: string): ReasonEmissionScanResult;
/** Scans every production file in a connector's directory. */
export declare function scanConnectorForReasonEmissions(connectorDir: string): ReasonEmissionScanResult;
//# sourceMappingURL=reason-emission-scan.d.ts.map