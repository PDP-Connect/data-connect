import { type PacingOptions, type PacingSnapshot, ProviderPacing, type ThrottleSignal } from "./provider-pacing.ts";
import { RunBudget, type RunBudgetOptions, type RunBudgetTrip } from "./run-budget.ts";
import type { SendDelayHint } from "./send-governor.ts";
export type ProviderBudgetDeferReason = RunBudgetTrip | "circuit_open" | "retry_budget";
/**
 * How the controller's GCRA pacing participates in the request path.
 *
 * - `"preflight"` (default, pre-convergence): the controller owns pacing as its
 *   own pre-flight wait — `beforeRequest()` `await`s `pacing.admit()`. When the
 *   caller ALSO runs a concurrency send governor (e.g. an adaptive lane with a
 *   launch delay), this is the two-gate stacking the rate-governance
 *   convergence forbids. Retained as the default so existing connector behavior
 *   is byte-identical until an owner opts into convergence.
 * - `"signal"` (converged): the controller performs NO pre-flight wait. Pacing
 *   becomes a {@link SendDelayHint} (`pacingDelayHint()`) the single send
 *   governor folds into its one wait. The controller is then a pure
 *   admission-decision + signal layer — a second pre-flight gate is not
 *   expressible.
 */
export type ProviderBudgetPacingMode = "preflight" | "signal";
export type CircuitBreakerState = "closed" | "half_open" | "open";
export type ProviderBudgetCircuitTransitionTrigger = "before_request" | "provider_failure" | "provider_throttle" | "success";
export interface ProviderBudgetCircuitTransition {
    elapsedMs: number;
    previousState: CircuitBreakerState;
    reason: "provider_failure" | "provider_throttle" | "reset_timeout" | "success";
    requestCount: number;
    retryTokensRemaining: number;
    state: CircuitBreakerState;
    trigger: ProviderBudgetCircuitTransitionTrigger;
}
export interface ProviderBudgetStop {
    circuitState?: CircuitBreakerState;
    elapsedMs: number;
    reason: ProviderBudgetDeferReason;
    requestCount: number;
    retryTokensRemaining: number;
}
export type ProviderBudgetGate = {
    ok: true;
} | ({
    ok: false;
} & ProviderBudgetStop);
export interface RetryBudgetOptions {
    /** Maximum retry tokens. Infinity disables retry-budget exhaustion. */
    capacity?: number;
    /** Starting retry tokens. Defaults to capacity. */
    initialTokens?: number;
    /** Tokens refilled per successful provider response. Default: 1. */
    refillPerSuccess?: number;
}
export declare class RetryBudget {
    readonly capacity: number;
    readonly refillPerSuccess: number;
    private tokens;
    constructor(options?: RetryBudgetOptions);
    consume(): boolean;
    recordSuccess(): void;
    get remaining(): number;
}
export interface CircuitBreakerOptions {
    /** Failure ratio required to open the circuit. Default: 0.5. */
    failureRateThreshold?: number;
    /** Number of observations required before the breaker may open. Default: 5. */
    minimumThroughput?: number;
    /** Clock used for reset timeout checks. Default: Date.now. */
    now?: () => number;
    /** How long the circuit stays open before a half-open probe. Default: 60s. */
    resetTimeoutMs?: number;
    /** Sliding observation window size. Default: 10. */
    windowSize?: number;
}
export declare class CircuitBreaker {
    private readonly failureRateThreshold;
    private readonly minimumThroughput;
    private readonly now;
    private readonly resetTimeoutMs;
    private readonly windowSize;
    private openedAt;
    private outcomes;
    private _state;
    constructor(options?: CircuitBreakerOptions);
    beforeRequest(): ProviderBudgetGate;
    recordSuccess(): void;
    recordFailure(): void;
    get state(): CircuitBreakerState;
    /**
     * Milliseconds until an open circuit auto-transitions to `half_open` (the next
     * `beforeRequest()` would probe). `0` when the circuit is not open, or already
     * eligible to half-open. A transient back-off can sleep this exact duration to
     * resume the instant the cool-down elapses — distinguishing a transient
     * provider-pressure trip ("slow down, then continue") from genuine budget
     * exhaustion ("stop"). PURE: reads only, never advances state.
     */
    remainingCooldownMs(): number;
    private close;
    private open;
    private recordOutcome;
}
export interface ProviderBudgetOptions {
    circuitBreaker?: CircuitBreaker | CircuitBreakerOptions | false;
    pacing?: ProviderPacing | PacingOptions | false;
    /**
     * Whether pacing runs as the controller's own pre-flight wait (`"preflight"`,
     * default) or as a delay hint for a single external send governor
     * (`"signal"`, converged). See {@link ProviderBudgetPacingMode}. Has no effect
     * when `pacing` is disabled.
     */
    pacingMode?: ProviderBudgetPacingMode;
    retryBudget?: RetryBudget | RetryBudgetOptions | false;
    runBudget?: RunBudget | RunBudgetOptions | false;
}
export declare class ProviderBudgetController implements SendDelayHint {
    readonly circuitBreaker: CircuitBreaker | null;
    readonly pacing: ProviderPacing | null;
    readonly pacingMode: ProviderBudgetPacingMode;
    readonly retryBudget: RetryBudget | null;
    readonly runBudget: RunBudget | null;
    private readonly circuitTransitions;
    constructor(options?: ProviderBudgetOptions);
    beforeRequest(): Promise<ProviderBudgetGate>;
    /**
     * The {@link SendDelayHint} the single send governor folds into its one
     * pre-flight wait. Computes pacing's owed delay and advances GCRA state
     * without sleeping. Returns 0 when pacing is disabled or in `"preflight"`
     * mode (where the controller already owns the wait, so handing a hint to the
     * governor too would re-create the stacking the convergence removes).
     */
    nextDelayMs(): number;
    /** Alias of {@link nextDelayMs} with a request-path-readable name. */
    pacingDelayHint(): number;
    /**
     * Operator-legible snapshot of the rate controller's live state, or null when
     * pacing is disabled. The connector persists `snapshot.intervalMs` for
     * warm-start across runs and surfaces the snapshot as redacted run-trace
     * progress. PURE: reads only, never advances GCRA state.
     */
    snapshotPacing(): PacingSnapshot | null;
    /**
     * Milliseconds until an open circuit auto-transitions to `half_open`, or `0`
     * when the circuit is closed/half-open/absent. A `circuit_open` gate is a
     * TRANSIENT back-off, not budget exhaustion: a caller can sleep this exact
     * cool-down (bounded by its own remaining run budget) and re-admit, instead of
     * deferring all remaining work. PURE: reads only, never advances state.
     */
    circuitCooldownMs(): number;
    recordRequest(): void;
    /**
     * §10-D (SLVP-ideal): pass `{ suppressAdditiveIncrease: true }` when this
     * success fires from the cooldown-exempt recovery lane so the shared pacer
     * interval is not decreased (un-learning the back-off the cooldown protects).
     * Throttles still fire unconditionally — recovery may decelerate, never
     * accelerate the shared pacer during cooldown.
     */
    recordSuccess(opts?: {
        suppressAdditiveIncrease?: boolean;
    }): void;
    recordThrottle(signal?: ThrottleSignal & {
        retryAfterAlreadySlept?: boolean;
    }): void;
    recordFailure(): void;
    consumeRetry(): ProviderBudgetGate;
    /**
     * Returns `true` when a retry budget is configured on this controller.
     * Each wait-out gate uses this to decide whether to consume a token or fall
     * back to the densityWaitCycles / circuitWaitCycle cycle cap:
     *
     * ```
     * const waitAllowed = providerBudget?.hasRetryBudget()
     *   ? providerBudget.tryConsumeRetryToken()
     *   : cycleFallback;
     * ```
     *
     * This ensures the cycle-cap fallback fires for BOTH "no controller" and
     * "controller present but no retryBudget" — the two cases that must behave
     * identically from the gate's perspective.
     */
    hasRetryBudget(): boolean;
    /**
     * Consume one retry token from the budget for a wait-out attempt.
     * Returns `true` when the budget has tokens remaining, `false` when depleted.
     * ONLY call this after confirming `hasRetryBudget()` returns `true` — calling
     * without a budget is a logic error and will throw in development.
     */
    tryConsumeRetryToken(): boolean;
    /**
     * Returns the number of retry tokens currently remaining, or `null` when no
     * retry budget is configured. Use this in progress messages to show the
     * actual governing give-up signal when the budget is active.
     */
    retryTokensRemaining(): number | null;
    currentStop(reason: ProviderBudgetDeferReason): ProviderBudgetStop;
    drainCircuitTransitions(): ProviderBudgetCircuitTransition[];
    private stop;
    private recordCircuitTransition;
}
export declare function retryBudgetCapacityFromRequestCap({ maxRequests, minCapacity, ratio, }: {
    maxRequests: number;
    minCapacity?: number;
    ratio?: number;
}): number;
//# sourceMappingURL=provider-budget.d.ts.map