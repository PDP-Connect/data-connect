/**
 * Read the first non-blank line of a connector's scrubbed pilot-shape sample
 * for the given stream, parsed as JSON.
 *
 * `connectorKey` and `stream` must match an existing
 * `fixtures/<connectorKey>/scrubbed/pilot-real-shape/records/<stream>.jsonl`
 * file shipped with this package.
 */
export declare function readSampleRecord(connectorKey: string, stream: string): Record<string, unknown>;
//# sourceMappingURL=fixture-samples.d.ts.map