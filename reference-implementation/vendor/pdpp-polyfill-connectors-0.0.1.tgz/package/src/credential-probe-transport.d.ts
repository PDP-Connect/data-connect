/**
 * Live transports for the static-secret credential probe.
 *
 * `credential-probe.ts` is pure orchestration with an INJECTED transport. This
 * module supplies the REAL transport — the single bounded network request each
 * connector's probe needs — and lives here, in the connector package, because
 * the provider dependency lives here: imapflow (a Gmail/IMAP dep) is not, and
 * should not be, reachable from the reference server's own dependency tree, and
 * the GitHub probe reuses the same `fetch`/auth shape the GitHub connector uses.
 *
 * The reference server imports `createLiveCredentialProbeTransport` only at the
 * point of use (the owner-session capture route). Tests inject deterministic
 * doubles directly and never import this module, so no live provider call is
 * ever made under test.
 *
 * This module is reference-only: it is NOT re-exported from the runner barrel
 * (`@pdpp/collector-runtime`), so the publishable local-collector slice never
 * carries it. Each transport performs exactly ONE bounded request and never
 * logs the secret.
 */
import type { CredentialProbeTransport } from "./credential-probe.ts";
/**
 * Build the live transport for one connector's probe. Returns an empty object
 * for connectors with no probe; the caller checks `hasCredentialProbe` first.
 */
export declare function createLiveCredentialProbeTransport(connectorKey: string): CredentialProbeTransport;
//# sourceMappingURL=credential-probe-transport.d.ts.map