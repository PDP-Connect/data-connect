/** Default prefix budget. Matches the Codex connector's `GUARD_PREFIX_BYTES`
 *  (64 KiB) — comfortably larger than any connector preview char limit even at
 *  4 UTF-8 bytes/char, while capping per-blob memory at a small constant. */
export declare const BOUNDED_PREVIEW_MAX_BYTES: number;
export interface BoundedFilePreview {
    /** Leading bytes of the file, trimmed to a complete UTF-8 code point. */
    readonly buffer: Buffer;
    /** Number of bytes actually retained in {@link buffer}. */
    readonly bytesRead: number;
    /** True when the file was longer than the bytes retained (preview is a
     *  prefix, not the whole file). */
    readonly truncated: boolean;
}
/**
 * Read at most `maxBytes` from the head of `path`. The returned buffer ends on
 * a complete UTF-8 code point. On any read error returns `null` (the caller
 * decides whether a missing/unreadable blob is fatal), matching the prior
 * `readFile(...).catch()` behavior at the tool-result call site.
 */
export declare function readBoundedFilePreview(path: string, maxBytes?: number): Promise<BoundedFilePreview | null>;
//# sourceMappingURL=bounded-file-preview.d.ts.map