// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Shared helper for persisting a Playwright `Download` artifact to disk.
 *
 * Playwright's `download.saveAs()` is the primary synchronization primitive:
 * it is safe to call while the download is still in progress and waits for
 * the artifact before copying it. If a remote browser reports a Download but
 * its backing file disappears before `saveAs()` can copy it, fall back to the
 * official `createReadStream()` API. Do not call `download.path()` first:
 * official Playwright docs note that `path()` throws when connected remotely,
 * which is exactly the shape used by Docker/n.eko browser surfaces.
 */
import { createWriteStream } from "node:fs";
import { mkdir, mkdtemp, readFile, rm, stat, writeFile, } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { pipeline } from "node:stream/promises";
export async function readPlaywrightDownloadBuffer(download) {
    const tempDir = await mkdtemp(join(tmpdir(), "pdpp-playwright-download-"));
    try {
        const target = join(tempDir, download.suggestedFilename?.() || "download.bin");
        await savePlaywrightDownload(download, target);
        return await readFile(target);
    }
    finally {
        await rm(tempDir, { recursive: true, force: true });
    }
}
/**
 * Persist a Playwright Download and return rich outcome metadata. Identical
 * to `readPlaywrightDownloadBuffer` for the happy path, but reports the
 * fallback path taken and the byte count actually written. Used by the USAA
 * export driver to surface `download_empty` evidence in the timeline.
 */
export async function readPlaywrightDownloadBufferDetailed(download) {
    const tempDir = await mkdtemp(join(tmpdir(), "pdpp-playwright-download-"));
    try {
        const target = join(tempDir, download.suggestedFilename?.() || "download.bin");
        const outcome = await savePlaywrightDownloadDetailed(download, target);
        const buffer = await readFile(target);
        return { buffer, outcome: { ...outcome, bytes: buffer.length } };
    }
    finally {
        await rm(tempDir, { recursive: true, force: true });
    }
}
export async function savePlaywrightDownload(download, targetPath) {
    await savePlaywrightDownloadDetailed(download, targetPath);
}
/**
 * Try `saveAs` (Playwright's documented primary primitive), and fall back
 * to `createReadStream` when it either throws or silently writes a zero-byte
 * artifact. The zero-byte case has been observed with `connectOverCDP`-style
 * remote browsers (n.eko) where the artifact transfer can complete without
 * an error but without bytes — exactly the failure mode the USAA export
 * driver was hitting under `download_empty`.
 */
export async function savePlaywrightDownloadDetailed(download, targetPath) {
    await mkdir(dirname(targetPath), { recursive: true });
    const dataUrlBuffer = readDownloadDataUrl(download);
    if (dataUrlBuffer) {
        await writeFile(targetPath, dataUrlBuffer);
        return { bytes: dataUrlBuffer.length, source: "dataUrl" };
    }
    let saveAsError;
    try {
        await download.saveAs(targetPath);
        const size = await statSize(targetPath);
        if (size > 0) {
            return { bytes: size, source: "saveAs" };
        }
        saveAsError = "saveAs_returned_zero_bytes";
    }
    catch (saveErr) {
        saveAsError = downloadErrorMessage(saveErr);
    }
    if (!download.createReadStream) {
        const failure = download.failure
            ? await download.failure().catch(() => null)
            : null;
        throw new Error(`download.saveAs failed (${saveAsError})${failure ? `; download.failure=${failure}` : ""}`);
    }
    try {
        const stream = await download.createReadStream();
        await pipeline(stream, createWriteStream(targetPath));
        const size = await statSize(targetPath);
        return { bytes: size, source: "createReadStream", saveAsError };
    }
    catch (streamErr) {
        const failure = download.failure
            ? await download.failure().catch(() => null)
            : null;
        throw new Error(`download.saveAs failed (${saveAsError}); createReadStream failed (${downloadErrorMessage(streamErr)})${failure ? `; download.failure=${failure}` : ""}`, { cause: streamErr });
    }
}
async function statSize(path) {
    try {
        const info = await stat(path);
        return info.size;
    }
    catch {
        return 0;
    }
}
function downloadErrorMessage(err) {
    return err instanceof Error ? err.message : String(err);
}
function readDownloadDataUrl(download) {
    if (!download.url) {
        return null;
    }
    let url;
    try {
        url = download.url();
    }
    catch {
        return null;
    }
    if (!url.startsWith("data:")) {
        return null;
    }
    const commaIndex = url.indexOf(",");
    if (commaIndex < 0) {
        return null;
    }
    const metadata = url.slice("data:".length, commaIndex).toLowerCase();
    const payload = url.slice(commaIndex + 1);
    try {
        if (metadata.split(";").includes("base64")) {
            return Buffer.from(payload, "base64");
        }
        return Buffer.from(decodeURIComponent(payload), "utf8");
    }
    catch {
        return null;
    }
}
