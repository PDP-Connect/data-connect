// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
// ─── Audited per-connector pacing profiles (WI-1b, §3 / §9-C5) ───────────────
//
// Each value below is a DECLARED ceiling derived from THAT provider's documented
// rate limit — never a borrow of ChatGPT's 250ms, never a shared default. The
// ceiling is the FASTEST inter-request interval the AIMD may reach; per spec §3
// it is set AT OR BELOW the provider's documented sustained rate (a safety prior:
// even a fully-accelerated controller stays under the provider's budget). The
// derivation (documented limit → chosen ceiling + margin) for every connector is
// recorded in docs/research/per-connector-rate-profiles-2026-06-13.md. All five
// connectors are single-threaded (concurrency 1) and read-only, so the read/
// primary limit — not upload/content-creation secondary limits — is the binding
// axis. None of the five emits detail gaps, so none declares a terminal-gap
// (§10-A) or cooldown (§10-B) profile; they use the safe shared defaults.
/**
 * GitHub — 1000ms (60 req/min). Documented primary limit: 5,000 requests/hour for
 * authenticated users (=720ms / ~83 req/min at the limit); 1000ms is ~72% of that
 * ceiling. Read-only, single-threaded, so the secondary content-creation /
 * concurrency limits do not bind.
 * Doc: https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api
 */
export function githubPacingProfile() {
    return { pacingMinIntervalMs: 1000 };
}
/**
 * Notion — 500ms (120 req/min). Documented limit: an average of 3 requests/second
 * per integration, bursts allowed (=333ms / 180 req/min at the average); 500ms is
 * 2 req/s = ~67% of the documented average, sitting under the average (not just
 * the burst peak).
 * Doc: https://developers.notion.com/reference/request-limits
 */
export function notionPacingProfile() {
    return { pacingMinIntervalMs: 500 };
}
/**
 * Oura — 250ms (240 req/min). Documented limit: 5,000 requests per 5-minute window
 * (=16.67 req/s, 60ms / ~1000 req/min at the limit); 250ms is 4 req/s = ~24% of
 * that ceiling — a deliberate 4× margin (we do not push to the 60ms hardware
 * ceiling: daily-grain wellness data does not need 1000 req/min and the wide
 * margin guards an undocumented per-account throttle).
 * Doc: https://cloud.ouraring.com/docs/error-handling
 */
export function ouraPacingProfile() {
    return { pacingMinIntervalMs: 250 };
}
/**
 * Spotify — 500ms (120 req/min). Spotify computes its limit over a rolling 30s
 * window and does NOT publish the exact request count (it differs by app mode);
 * the commonly-observed development-mode figure is ~180 req/min (=333ms at the
 * cited rate). 500ms is ~67% of that — margin-heavy on purpose because the true
 * limit is undisclosed; the connector honors Retry-After on 429.
 * Doc: https://developer.spotify.com/documentation/web-api/concepts/rate-limits
 */
export function spotifyPacingProfile() {
    return { pacingMinIntervalMs: 500 };
}
/**
 * YNAB — 20000ms (3 req/min). Documented limit: 200 requests per hour per access
 * token over a rolling 1-hour window (=0.0556 req/s, 18000ms / ~3.33 req/min
 * sustained). 20000ms is set BELOW that sustained rate so even a long run stays
 * under the 200/hr budget at the ceiling. A typical YNAB run is only tens of
 * requests (~7×budgets + one per walked month), so it finishes in a minute or two
 * far under budget; the conservative ceiling only binds a pathological run.
 * Doc: https://api.ynab.com/ (Usage → Rate Limiting)
 */
export function ynabPacingProfile() {
    return { pacingMinIntervalMs: 20_000 };
}
/**
 * Slack (direct Web API calls for `stars.list`, `usergroups.list`,
 * `reminders.list`, `conversations.info`) — 3000ms (20 req/min). This governor
 * covers ONLY the four gap streams the archive-based collection cannot reach
 * (see openspec/changes/complete-slack-bundled-connector-coverage); it does not
 * pace slackdump's own subprocess calls. Slack's tiered rate limits put
 * `usergroups.list`/`reminders.list` at Tier 2 (20+ req/min = 3000ms) and
 * `stars.list`/`conversations.info` at Tier 3 (50+ req/min, faster); 3000ms is
 * set at the binding (slowest) Tier 2 floor across the four methods since one
 * governor call site paces all of them, not per-method.
 * Doc: https://docs.slack.dev/apis/web-api/rate-limits/,
 * https://docs.slack.dev/reference/methods/usergroups.list,
 * https://docs.slack.dev/reference/methods/reminders.list
 */
export function slackApiPacingProfile() {
    return { pacingMinIntervalMs: 3000 };
}
/**
 * Steam — 250ms (4 req/s, matching Oura). Steam Web API publishes no official
 * numeric rate limits on https://partner.steamgames.com/doc/webapi_overview/auth
 * or https://partner.steamgames.com/doc/webapi/iplayerservice (confirmed primary
 * sources 2026-08-07). Community reports document multi-hour 403 lockouts from
 * sustained high-frequency use, but no published threshold. Per PDPP policy:
 * when an undocumented provider has no numeric limit, use the least restrictive
 * existing operational ceiling (Oura's 250ms, proven safe in production), paired
 * with adaptive backoff (AIMD) to reduce rate on any 429/403 response. This lets
 * the governor accelerate under success and retreat on throttling, converging to
 * the provider's actual (undocumented) threshold without guessing. The manifest's
 * 1-hour polling interval is a separate conservative choice (infrastructure, not
 * API pacing). A 5-endpoint first run at 250ms ceiling takes 1.25s + network
 * latency; adaptive backoff will slow if Steam signals throttling.
 * Derived 2026-08-07: no published limit, use policy default.
 */
export function steamPacingProfile() {
    return { pacingMinIntervalMs: 250 };
}
/**
 * Google Calendar / Google Contacts (People API) — 200ms (5 req/s, 300 req/min)
 * each, shared derivation. Both connectors are the same Google Cloud project's
 * per-user quota family. Calendar's documented per-project-per-user ceiling
 * (May 2026 restructuring, corrected in the reconciliation report from the
 * originally-claimed and FALSE "10,000/sec, 1,000,000/day/user") is 600
 * requests/minute/user/project (=100ms sustained). People API publishes no
 * static numeric quota (its quota page has no table; it points to a
 * project-configurable Cloud Console setting) — treated conservatively as no
 * looser than Calendar's documented per-user ceiling since both APIs share a
 * project's quota pool. 200ms (300 req/min) sits at half Calendar's documented
 * 600 req/min ceiling, leaving headroom for both connectors' requests to share
 * the same per-user budget without either one alone draining it. Exposed as two
 * distinct named factories (matching the one-factory-per-connector convention
 * every other governor-using connector follows) rather than one shared export,
 * so each connector's own audited-profile import stays literally grep-able.
 * Factory names intentionally match each connector's directory name verbatim
 * (`google_calendar`, `google_contacts`, not camelCased) — the existing
 * `provider-profile-conformance.test.ts` roster check greps for the literal
 * substring `${connectorDirName}PacingProfile` in each connector's source.
 * Doc: https://developers.google.com/workspace/calendar/api/guides/quota,
 *      https://developers.google.com/people/legacy/limits
 */
const GOOGLE_CALENDAR_CONTACTS_PACING_MIN_INTERVAL_MS = 200;
export function google_calendarPacingProfile() {
    return {
        pacingMinIntervalMs: GOOGLE_CALENDAR_CONTACTS_PACING_MIN_INTERVAL_MS,
    };
}
export function google_contactsPacingProfile() {
    return {
        pacingMinIntervalMs: GOOGLE_CALENDAR_CONTACTS_PACING_MIN_INTERVAL_MS,
    };
}
/**
 * GroupMe — 1000ms (60 req/min). GroupMe's API v3 documentation does not publish
 * exact rate limits. A one-second floor avoids bursts without turning a 41-chat
 * account into a half-hour scan. The shared governor still honors Retry-After and
 * backs off on 429/5xx responses, so provider feedback remains authoritative.
 * Doc: https://dev.groupme.com/docs/v3 (rate limits not specified)
 */
export function groupmePacingProfile() {
    return { pacingMinIntervalMs: 1000 };
}
/**
 * Jellyfin — PDPP operational default (100ms shared backoff, no invented limits).
 * Jellyfin is self-hosted with no published rate limits. We use PDPP's default
 * responsive pacing rather than inventing conservative figures. A typical run
 * fetches one /System/Info probe + one /Users/{id}/Views call + paginated
 * /Users/{id}/Items calls (500 items/page), totaling ~10-20 requests per run,
 * well within any self-hosted capacity. Honors Retry-After headers if returned.
 * Reference: Authority doc §10 (Jellyfin v10.11.11, self-hosted, no documented limits).
 */
export function jellyfinPacingProfile() {
    return { pacingMinIntervalMs: 100 };
}
