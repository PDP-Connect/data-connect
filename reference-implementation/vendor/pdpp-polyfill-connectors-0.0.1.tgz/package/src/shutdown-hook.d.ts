export declare function withShutdownRelease(release: () => Promise<unknown>, options?: {
    finalize?: () => Promise<unknown>;
}): () => void;
//# sourceMappingURL=shutdown-hook.d.ts.map