export interface GeneratedStaticSecretDescriptor {
    /** `false` only when the manifest's credential_capture.required is explicitly false; omitted (defaults true) otherwise. */
    readonly captureRequired?: false;
    readonly credentialKind: string;
    readonly optionalSecretBundleFields?: readonly string[];
    readonly secretEnvVars?: readonly string[];
    readonly secretFieldEnvVars?: Readonly<Record<string, readonly string[]>>;
    readonly setupFieldEnvVars?: Readonly<Record<string, readonly string[]>>;
}
/** Every manifest-declared static-secret connector's injection mapping, keyed by connector_key. */
export declare const GENERATED_STATIC_SECRET_REGISTRY: Readonly<Record<string, GeneratedStaticSecretDescriptor>>;
//# sourceMappingURL=static-secret-registry.generated.d.ts.map