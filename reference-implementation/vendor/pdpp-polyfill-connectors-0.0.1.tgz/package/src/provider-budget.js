// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { ProviderPacing, } from "./provider-pacing.js";
import { RunBudget, } from "./run-budget.js";
export class RetryBudget {
    capacity;
    refillPerSuccess;
    tokens;
    constructor(options = {}) {
        this.capacity = sanitizeNonNegative(options.capacity ?? Number.POSITIVE_INFINITY);
        this.refillPerSuccess = sanitizeNonNegative(options.refillPerSuccess ?? 1);
        this.tokens = Math.min(sanitizeNonNegative(options.initialTokens ?? this.capacity), this.capacity);
    }
    consume() {
        if (this.capacity === Number.POSITIVE_INFINITY) {
            return true;
        }
        if (this.tokens < 1) {
            return false;
        }
        this.tokens -= 1;
        return true;
    }
    recordSuccess() {
        if (this.capacity === Number.POSITIVE_INFINITY) {
            return;
        }
        this.tokens = Math.min(this.capacity, this.tokens + this.refillPerSuccess);
    }
    get remaining() {
        return this.tokens;
    }
}
export class CircuitBreaker {
    failureRateThreshold;
    minimumThroughput;
    now;
    resetTimeoutMs;
    windowSize;
    openedAt = null;
    outcomes = [];
    _state = "closed";
    constructor(options = {}) {
        this.failureRateThreshold = clampRatio(options.failureRateThreshold ?? 0.5);
        this.minimumThroughput = Math.max(1, Math.floor(options.minimumThroughput ?? 5));
        this.now = options.now ?? Date.now;
        this.resetTimeoutMs = Math.max(0, Math.floor(options.resetTimeoutMs ?? 60_000));
        this.windowSize = Math.max(this.minimumThroughput, Math.floor(options.windowSize ?? 10));
    }
    beforeRequest() {
        if (this._state !== "open") {
            return { ok: true };
        }
        const elapsedOpenMs = this.openedAt === null ? 0 : Math.max(0, this.now() - this.openedAt);
        if (elapsedOpenMs >= this.resetTimeoutMs) {
            this._state = "half_open";
            return { ok: true };
        }
        return {
            ok: false,
            circuitState: this._state,
            elapsedMs: 0,
            reason: "circuit_open",
            requestCount: 0,
            retryTokensRemaining: Number.POSITIVE_INFINITY,
        };
    }
    recordSuccess() {
        if (this._state === "half_open") {
            this.close();
            return;
        }
        if (this._state === "closed") {
            this.recordOutcome(true);
        }
    }
    recordFailure() {
        if (this._state === "half_open") {
            this.open();
            return;
        }
        if (this._state !== "closed") {
            return;
        }
        this.recordOutcome(false);
        if (this.outcomes.length < this.minimumThroughput) {
            return;
        }
        const failures = this.outcomes.filter((ok) => !ok).length;
        if (failures / this.outcomes.length >= this.failureRateThreshold) {
            this.open();
        }
    }
    get state() {
        return this._state;
    }
    /**
     * Milliseconds until an open circuit auto-transitions to `half_open` (the next
     * `beforeRequest()` would probe). `0` when the circuit is not open, or already
     * eligible to half-open. A transient back-off can sleep this exact duration to
     * resume the instant the cool-down elapses — distinguishing a transient
     * provider-pressure trip ("slow down, then continue") from genuine budget
     * exhaustion ("stop"). PURE: reads only, never advances state.
     */
    remainingCooldownMs() {
        if (this._state !== "open" || this.openedAt === null) {
            return 0;
        }
        const elapsedOpenMs = Math.max(0, this.now() - this.openedAt);
        return Math.max(0, this.resetTimeoutMs - elapsedOpenMs);
    }
    close() {
        this._state = "closed";
        this.openedAt = null;
        this.outcomes = [];
    }
    open() {
        this._state = "open";
        this.openedAt = this.now();
    }
    recordOutcome(ok) {
        this.outcomes.push(ok);
        if (this.outcomes.length > this.windowSize) {
            this.outcomes.shift();
        }
    }
}
export class ProviderBudgetController {
    circuitBreaker;
    pacing;
    pacingMode;
    retryBudget;
    runBudget;
    circuitTransitions = [];
    constructor(options = {}) {
        this.circuitBreaker = resolveCircuitBreaker(options.circuitBreaker);
        this.pacing = resolveProviderPacing(options.pacing);
        this.pacingMode = options.pacingMode ?? "preflight";
        this.retryBudget = resolveRetryBudget(options.retryBudget);
        this.runBudget = resolveRunBudget(options.runBudget);
    }
    async beforeRequest() {
        const runTrip = this.runBudget?.tripReason() ?? null;
        if (runTrip) {
            return this.stop(runTrip);
        }
        const previousCircuitState = this.circuitBreaker?.state ?? null;
        const circuitGate = this.circuitBreaker?.beforeRequest() ?? { ok: true };
        this.recordCircuitTransition(previousCircuitState, "before_request");
        if (!circuitGate.ok) {
            return this.stop("circuit_open");
        }
        // In `"signal"` (converged) mode the controller performs NO pre-flight wait:
        // pacing is handed to the single send governor via `pacingDelayHint()`. Only
        // legacy `"preflight"` mode sleeps here. This is the one line that decides
        // whether the controller is a second pre-flight gate.
        if (this.pacingMode === "preflight") {
            await this.pacing?.admit();
        }
        return { ok: true };
    }
    /**
     * The {@link SendDelayHint} the single send governor folds into its one
     * pre-flight wait. Computes pacing's owed delay and advances GCRA state
     * without sleeping. Returns 0 when pacing is disabled or in `"preflight"`
     * mode (where the controller already owns the wait, so handing a hint to the
     * governor too would re-create the stacking the convergence removes).
     */
    nextDelayMs() {
        if (this.pacingMode !== "signal") {
            return 0;
        }
        return this.pacing?.nextDelayMs() ?? 0;
    }
    /** Alias of {@link nextDelayMs} with a request-path-readable name. */
    pacingDelayHint() {
        return this.nextDelayMs();
    }
    /**
     * Operator-legible snapshot of the rate controller's live state, or null when
     * pacing is disabled. The connector persists `snapshot.intervalMs` for
     * warm-start across runs and surfaces the snapshot as redacted run-trace
     * progress. PURE: reads only, never advances GCRA state.
     */
    snapshotPacing() {
        return this.pacing?.snapshot() ?? null;
    }
    /**
     * Milliseconds until an open circuit auto-transitions to `half_open`, or `0`
     * when the circuit is closed/half-open/absent. A `circuit_open` gate is a
     * TRANSIENT back-off, not budget exhaustion: a caller can sleep this exact
     * cool-down (bounded by its own remaining run budget) and re-admit, instead of
     * deferring all remaining work. PURE: reads only, never advances state.
     */
    circuitCooldownMs() {
        return this.circuitBreaker?.remainingCooldownMs() ?? 0;
    }
    recordRequest() {
        this.runBudget?.recordRequest();
    }
    /**
     * §10-D (SLVP-ideal): pass `{ suppressAdditiveIncrease: true }` when this
     * success fires from the cooldown-exempt recovery lane so the shared pacer
     * interval is not decreased (un-learning the back-off the cooldown protects).
     * Throttles still fire unconditionally — recovery may decelerate, never
     * accelerate the shared pacer during cooldown.
     */
    recordSuccess(opts) {
        this.retryBudget?.recordSuccess();
        this.pacing?.recordSuccess(opts);
        const previousCircuitState = this.circuitBreaker?.state ?? null;
        this.circuitBreaker?.recordSuccess();
        this.recordCircuitTransition(previousCircuitState, "success");
    }
    recordThrottle(signal = {}) {
        const pacingSignal = signal.retryAfterAlreadySlept ? {} : signal;
        this.pacing?.recordThrottle(pacingSignal);
        const previousCircuitState = this.circuitBreaker?.state ?? null;
        this.circuitBreaker?.recordFailure();
        this.recordCircuitTransition(previousCircuitState, "provider_throttle");
    }
    recordFailure() {
        const previousCircuitState = this.circuitBreaker?.state ?? null;
        this.circuitBreaker?.recordFailure();
        this.recordCircuitTransition(previousCircuitState, "provider_failure");
    }
    consumeRetry() {
        if (this.retryBudget && !this.retryBudget.consume()) {
            return this.stop("retry_budget");
        }
        return { ok: true };
    }
    /**
     * Returns `true` when a retry budget is configured on this controller.
     * Each wait-out gate uses this to decide whether to consume a token or fall
     * back to the densityWaitCycles / circuitWaitCycle cycle cap:
     *
     * ```
     * const waitAllowed = providerBudget?.hasRetryBudget()
     *   ? providerBudget.tryConsumeRetryToken()
     *   : cycleFallback;
     * ```
     *
     * This ensures the cycle-cap fallback fires for BOTH "no controller" and
     * "controller present but no retryBudget" — the two cases that must behave
     * identically from the gate's perspective.
     */
    hasRetryBudget() {
        return this.retryBudget !== null;
    }
    /**
     * Consume one retry token from the budget for a wait-out attempt.
     * Returns `true` when the budget has tokens remaining, `false` when depleted.
     * ONLY call this after confirming `hasRetryBudget()` returns `true` — calling
     * without a budget is a logic error and will throw in development.
     */
    tryConsumeRetryToken() {
        if (!this.retryBudget) {
            // Guard against misuse: if hasRetryBudget() was checked first this branch
            // is unreachable. Fail closed so the gate does not allow infinite waits.
            return false;
        }
        return this.retryBudget.consume();
    }
    /**
     * Returns the number of retry tokens currently remaining, or `null` when no
     * retry budget is configured. Use this in progress messages to show the
     * actual governing give-up signal when the budget is active.
     */
    retryTokensRemaining() {
        return this.retryBudget ? this.retryBudget.remaining : null;
    }
    currentStop(reason) {
        return {
            ...(this.circuitBreaker
                ? { circuitState: this.circuitBreaker.state }
                : {}),
            elapsedMs: this.runBudget?.elapsedMs() ?? 0,
            reason,
            requestCount: this.runBudget?.count ?? 0,
            retryTokensRemaining: this.retryBudget?.remaining ?? Number.POSITIVE_INFINITY,
        };
    }
    drainCircuitTransitions() {
        return this.circuitTransitions.splice(0);
    }
    stop(reason) {
        return { ok: false, ...this.currentStop(reason) };
    }
    recordCircuitTransition(previousState, trigger) {
        if (!this.circuitBreaker ||
            previousState === null ||
            previousState === this.circuitBreaker.state) {
            return;
        }
        this.circuitTransitions.push({
            elapsedMs: this.runBudget?.elapsedMs() ?? 0,
            previousState,
            reason: providerBudgetTransitionReason(trigger, previousState, this.circuitBreaker.state),
            requestCount: this.runBudget?.count ?? 0,
            retryTokensRemaining: this.retryBudget?.remaining ?? Number.POSITIVE_INFINITY,
            state: this.circuitBreaker.state,
            trigger,
        });
    }
}
export function retryBudgetCapacityFromRequestCap({ maxRequests, minCapacity = 1, ratio = 0.2, }) {
    if (!Number.isFinite(maxRequests)) {
        return Number.POSITIVE_INFINITY;
    }
    return Math.max(Math.floor(minCapacity), Math.ceil(Math.max(0, maxRequests) * clampRatio(ratio)));
}
function clampRatio(value) {
    if (!Number.isFinite(value)) {
        return 1;
    }
    return Math.min(1, Math.max(0, value));
}
function sanitizeNonNegative(value) {
    if (value === Number.POSITIVE_INFINITY) {
        return value;
    }
    if (!Number.isFinite(value) || value <= 0) {
        return 0;
    }
    return value;
}
function providerBudgetTransitionReason(trigger, previousState, state) {
    if (trigger === "before_request" &&
        previousState === "open" &&
        state === "half_open") {
        return "reset_timeout";
    }
    if (trigger === "provider_throttle") {
        return "provider_throttle";
    }
    if (trigger === "provider_failure") {
        return "provider_failure";
    }
    return "success";
}
function resolveCircuitBreaker(value) {
    if (value === false || value === undefined) {
        return null;
    }
    if (value instanceof CircuitBreaker) {
        return value;
    }
    return new CircuitBreaker(value);
}
function resolveProviderPacing(value) {
    if (value === false || value === undefined) {
        return null;
    }
    if (value instanceof ProviderPacing) {
        return value;
    }
    return new ProviderPacing(value);
}
function resolveRetryBudget(value) {
    if (value === false || value === undefined) {
        return null;
    }
    if (value instanceof RetryBudget) {
        return value;
    }
    return new RetryBudget(value);
}
function resolveRunBudget(value) {
    if (value === false || value === undefined) {
        return null;
    }
    if (value instanceof RunBudget) {
        return value;
    }
    return new RunBudget(value);
}
