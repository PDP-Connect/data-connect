/** Absolute path of the durable outbox the child should enqueue into. */
export declare const ARTIFACT_OUTBOX_PATH_ENV = "PDPP_ARTIFACT_OUTBOX_PATH";
/** Absolute root of the content-addressed blob spool the child should write. */
export declare const ARTIFACT_SPOOL_ROOT_ENV = "PDPP_ARTIFACT_SPOOL_ROOT";
/** The connection this run collects for, so enqueued rows are attributable. */
export declare const ARTIFACT_SOURCE_INSTANCE_ENV = "PDPP_ARTIFACT_SOURCE_INSTANCE_ID";
export interface ArtifactCaptureEnvInput {
    outboxPath: string;
    sourceInstanceId: string;
    spoolRoot?: string;
}
/**
 * The spool sits beside the outbox by default, so one queue path configures
 * both stores and a per-connection queue keeps its own bytes.
 */
export declare function defaultArtifactSpoolRoot(outboxPath: string): string;
/**
 * Build the child env that enables artifact capture for this run.
 *
 * Both paths are resolved against the HOST's working directory before they are
 * forwarded. The contract above promises absolute paths, but a caller may hold
 * a relative one — `--queue-path .pdpp/queue.sqlite` is ordinary CLI usage. A
 * relative path forwarded verbatim is interpreted against the CHILD's working
 * directory, which need not match the parent's, so the child would open a
 * DIFFERENT outbox and spool: capture would silently write bytes nobody later
 * reads, or fail on a directory that does not exist there.
 *
 * Resolving here, once, at the boundary that knows the intended base, keeps the
 * promise the env var names make. An already-absolute path is unchanged.
 */
export declare function buildArtifactCaptureEnv(input: ArtifactCaptureEnvInput): Record<string, string>;
export interface ResolvedArtifactCaptureEnv {
    outboxPath: string;
    sourceInstanceId: string;
    spoolRoot: string;
}
/**
 * Read the contract back inside the connector child.
 *
 * Returns null when the run did not supply it — a fixture, a dry run, or a
 * caller that has not opted in. That is a capability statement, and the
 * connector records it as `unavailable` rather than failing the run.
 */
export declare function resolveArtifactCaptureEnv(env?: NodeJS.ProcessEnv): ResolvedArtifactCaptureEnv | null;
//# sourceMappingURL=artifact-capture-env.d.ts.map