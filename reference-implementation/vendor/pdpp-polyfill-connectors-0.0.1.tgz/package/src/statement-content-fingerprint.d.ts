/** The two positive content-fingerprint fields a statement record carries. */
export declare const STATEMENT_CONTENT_FIELDS: readonly ["pdf_text_sha256", "pdf_page_count"];
/** The blob/acquisition-identity fields that move on every re-download with no
 *  owner-visible content change. `pdf_path` and `document_url` embed the
 *  `pdf_sha256`, so all three move together; `fetched_at` is the run clock. */
export declare const STATEMENT_BLOB_IDENTITY_KEYS: readonly ["pdf_sha256", "pdf_path", "document_url"];
/** The run-clock-only exclusion used when the positive content fields are
 *  absent — identical to the conservative pre-content behavior. */
export declare const STATEMENT_RUN_CLOCK_EXCLUDE_KEYS: readonly ["fetched_at"];
/** The full content-gated exclusion used when both content fields are present:
 *  the blob/acquisition-identity fields PLUS the run clock. */
export declare const STATEMENT_CONTENT_GATED_EXCLUDE_KEYS: readonly ["pdf_sha256", "pdf_path", "document_url", "fetched_at"];
/** The positive content fingerprint a connector emits per statement. Both
 *  fields are `null` when text extraction failed or returned empty text
 *  (fail-closed). */
export interface StatementContentFingerprint {
    pdf_page_count: number | null;
    pdf_text_sha256: string | null;
}
/** The all-null fingerprint emitted on extraction failure / empty text. */
export declare const NO_STATEMENT_CONTENT_FINGERPRINT: StatementContentFingerprint;
/**
 * Deterministic normalization of extracted PDF text so the sha is stable
 * across text-extractor whitespace/line-wrap jitter:
 *   - Unicode NFC (canonical composition),
 *   - runs of whitespace (including newlines/tabs) collapsed to a single space,
 *   - leading/trailing whitespace trimmed.
 *
 * The evidence already showed `pdftotext`/`pdf-parse` output was content-stable
 * across re-downloads; this normalization is the belt-and-braces guard against
 * a future extractor version that re-wraps lines.
 */
export declare function normalizeStatementText(text: string): string;
/**
 * Compute the positive content fingerprint from a PDF's already-extracted text
 * and page count. The connector owns *how* it extracts (USAA reuses its
 * existing `pdf-parse` pass; Chase gains one) — this is the shared shaping so
 * both connectors hash identically.
 *
 * Fail-closed: an empty/whitespace-only normalized text yields all-null, which
 * makes the canonical fingerprint fall back to the conservative run-clock-only
 * exclusion. A genuinely empty statement is never silently treated as a
 * content match for a non-empty one.
 */
export declare function statementContentFingerprintFromText(text: string | null | undefined, pageCount: number | null | undefined): StatementContentFingerprint;
/**
 * Extract a statement PDF's full text and page count in one shared `pdf-parse`
 * pass. `getText()` returns both the concatenated document `text` and `total`
 * (page count), so the content fingerprint costs no extra parse on top of any
 * extraction a connector already runs. Both statement connectors call this so
 * the fingerprint is computed identically; a connector SHALL NOT introduce a
 * second PDF-text library for this purpose.
 *
 * `pdf-parse` is lazy-imported so connectors that never hit the PDF path pay
 * no startup cost.
 */
export declare function extractStatementPdfTextAndPages(buffer: Buffer): Promise<{
    text: string;
    pageCount: number | null;
}>;
/**
 * Derive the positive content fingerprint from a statement PDF's bytes using
 * the shared extraction path. Fail-closed: any extraction error yields the
 * all-null fingerprint so the canonical exclusion stays conservative and the
 * statement record is still emitted.
 */
export declare function extractStatementContentFingerprint(buffer: Buffer): Promise<StatementContentFingerprint>;
/** True iff a record carries BOTH positive content fields, present and
 *  non-null. Requiring both fails closed against a partial extraction (text
 *  but no page count, or vice versa). */
export declare function hasStatementContentFingerprint(record: Record<string, unknown>): boolean;
/**
 * The content-gated canonical fingerprint exclusion list for one statement
 * record. This is the single shared rule the connector no-op cursor AND the
 * compaction policy both consume, so a "removable historical version"
 * classification matches the connector's "no-op emit" classification.
 *
 *   - both content fields present → exclude the blob/acquisition-identity
 *     fields plus the run clock (excluding them is lossless because the
 *     positive content signal remains in the fingerprint);
 *   - either content field absent → exclude only the run clock (the
 *     conservative pre-content behavior, so a content-less version is never
 *     collapsed against a content-bearing version).
 */
export declare function statementFingerprintExcludeKeys(record: Record<string, unknown>): readonly string[];
//# sourceMappingURL=statement-content-fingerprint.d.ts.map