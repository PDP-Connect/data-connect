// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Typed probe failure. `code` is a stable, owner-causal reason string (e.g.
 * `gmail_credential_rejected`, `github_credential_rejected`,
 * `github_credential_insufficient_scope`); `message` is owner-voiced and names
 * the provider and artifact. Neither carries the secret or a raw provider error
 * body. `retryable` distinguishes a transient reach-the-provider failure (the
 * owner can retry) from a definite rejection (the owner must fix the
 * credential).
 */
export class CredentialProbeError extends Error {
    code;
    retryable;
    constructor(code, message, options) {
        super(message);
        this.name = "CredentialProbeError";
        this.code = code;
        this.retryable = options?.retryable ?? false;
    }
}
function gmailAddressFromContext(context) {
    const fields = context.setupFields;
    if (!fields) {
        return null;
    }
    const value = fields.account_email ?? fields.gmail_address ?? fields.email;
    return typeof value === "string" && value.trim().length > 0
        ? value.trim()
        : null;
}
const gmailProbe = async ({ context, secret, transport, }) => {
    const address = gmailAddressFromContext(context);
    if (!address) {
        throw new CredentialProbeError("gmail_address_missing", "Enter the Gmail address for this mailbox so the app password can be checked.");
    }
    const imapTransport = transport;
    if (typeof imapTransport.imapLogin !== "function") {
        throw new CredentialProbeError("gmail_probe_transport_missing", "Gmail validation is unavailable on this instance right now. Try again, or skip validation and start the first sync.");
    }
    try {
        await imapTransport.imapLogin({ address, password: secret });
    }
    catch {
        // imapflow surfaces a bad app password as an authentication failure. The
        // owner-causal reading is "Google rejected this app password" — never the
        // raw IMAP error, never the secret. Deliberately no `cause`: attaching
        // the raw error would leak it back out through the error chain.
        throw new CredentialProbeError("gmail_credential_rejected", "Google rejected this app password for that mailbox. Check the Gmail address and create a fresh app password, then try again.");
    }
    return { identity: address, detail: null };
};
const githubProbe = async ({ secret, transport }) => {
    const ghTransport = transport;
    if (typeof ghTransport.getUser !== "function") {
        throw new CredentialProbeError("github_probe_transport_missing", "GitHub validation is unavailable on this instance right now. Try again, or skip validation and start the first sync.");
    }
    let response;
    try {
        response = await ghTransport.getUser({ token: secret });
    }
    catch {
        throw new CredentialProbeError("github_unreachable", "Could not reach GitHub to check this token. Try again in a moment.", { retryable: true });
    }
    if (response.status === 401) {
        throw new CredentialProbeError("github_credential_rejected", "GitHub rejected this token — it may be expired or revoked. Create a new token and try again.");
    }
    if (response.status === 403) {
        throw new CredentialProbeError("github_credential_insufficient", "GitHub accepted this token but refused the account check — the token may be missing the required scope. Create a token with read access to your profile.");
    }
    if (response.status < 200 || response.status >= 300) {
        throw new CredentialProbeError("github_unreachable", "GitHub returned an unexpected response while checking this token. Try again in a moment.", { retryable: true });
    }
    const login = typeof response.login === "string" && response.login.trim().length > 0
        ? response.login.trim()
        : null;
    if (!login) {
        throw new CredentialProbeError("github_identity_unavailable", "GitHub accepted this token but did not return an account login. Try a token tied to a user account.");
    }
    return { identity: login, detail: null };
};
// ─── Registry ──────────────────────────────────────────────────────────────
/**
 * Connectors with a synchronous credential probe. A connector here advertises
 * `validation: "synchronous"`; one absent advertises `"first_sync"`. The keys
 * are canonical connector keys (post-registry-prefix strip), matching
 * `STATIC_SECRET_CONNECTOR_REGISTRY`.
 */
export const CREDENTIAL_PROBE_REGISTRY = Object.freeze({
    gmail: Object.freeze({
        credentialKind: "app_password",
        probe: gmailProbe,
    }),
    github: Object.freeze({
        credentialKind: "personal_access_token",
        probe: githubProbe,
    }),
});
/** True when the connector advertises a synchronous credential probe. */
export function hasCredentialProbe(connectorKey) {
    return (typeof connectorKey === "string" &&
        Object.hasOwn(CREDENTIAL_PROBE_REGISTRY, connectorKey));
}
/**
 * The validation mode a static-secret connector advertises. Connectors with a
 * registered probe validate `synchronous`ly at credential capture; the rest
 * validate at `first_sync`. This is the single source the setup planner,
 * descriptor route, owner-agent intent, and CLI projection all read.
 */
export function credentialValidationMode(connectorKey) {
    return hasCredentialProbe(connectorKey) ? "synchronous" : "first_sync";
}
/**
 * Run a connector's synchronous credential probe.
 *
 * Returns a non-secret identity on success. Throws `CredentialProbeError` when
 * the credential is rejected (or the provider is unreachable). Throws a
 * `no_credential_probe` `CredentialProbeError` when the connector has no probe —
 * callers should check `hasCredentialProbe` first and take the first-sync path
 * rather than treating absence as a validation failure.
 *
 * The `transport` is injected by the caller; in production it is the live
 * network implementation, in tests a deterministic double.
 */
export async function probeCredential(args) {
    const descriptor = CREDENTIAL_PROBE_REGISTRY[args.connectorKey];
    if (!descriptor) {
        throw new CredentialProbeError("no_credential_probe", `Connector '${args.connectorKey}' has no synchronous credential probe.`);
    }
    if (typeof args.secret !== "string" || args.secret.length === 0) {
        throw new CredentialProbeError("probe_secret_invalid", "A non-empty provider secret is required to validate.");
    }
    return await descriptor.probe({
        context: args.context ?? {},
        secret: args.secret,
        transport: args.transport,
    });
}
