/**
 * Run `criticalSection` inside the per-profile mutex. Returns whatever the
 * critical section returns. Re-thrown errors propagate normally; the
 * mutex chain is preserved regardless (subsequent callers wait for
 * settlement, not for success).
 */
type MaybePromise<T> = T | Promise<T>;
export declare function withProfileLockMutex<T>(profileDir: string, criticalSection: () => MaybePromise<T>): Promise<T>;
/**
 * Remove the three Chromium singleton files from `profileDir` if they
 * exist. No-ops on missing files. Touches no other path. Idempotent.
 *
 * MUST be called inside `withProfileLockMutex(profileDir, ...)` to be safe
 * against concurrent in-process launches against the same profile.
 *
 * Returns the names of files that were actually removed (for logging /
 * test introspection).
 */
export declare function removeChromiumSingletonResidue(profileDir: string): Promise<string[]>;
export {};
//# sourceMappingURL=profile-lock.d.ts.map