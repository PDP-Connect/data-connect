export interface ZipReadPolicy {
    /** Reject archives whose central directory declares more entries than this. */
    readonly maxEntries: number;
    /** Bounds inflation of any single entry, enforced at inflate time via zlib's maxOutputLength. */
    readonly maxEntryUncompressedBytes: number;
    /**
     * Bounds the sum of ACTUAL bytes returned across every `data()` call made
     * against entries returned from one read-entries call — tracked with a
     * real running counter over genuine inflate output, not the untrusted
     * declared `uncompressed_size` field. Extracting entries beyond this budget
     * throws {@link ZipPolicyViolationError}.
     */
    readonly maxTotalUncompressedBytes: number;
}
export declare class ZipPolicyViolationError extends Error {
    readonly code: "entry_too_large" | "too_many_entries" | "total_too_large" | "unsafe_entry_name";
    constructor(code: ZipPolicyViolationError["code"], message: string, options?: {
        cause?: unknown;
    });
}
export interface ZipEntry {
    readonly compressedSize: number;
    readonly data: () => Buffer;
    readonly name: string;
    readonly uncompressedSize: number;
}
export declare function zipBasename(path: string): string;
export declare function hasZipLocalFileSignature(bytes: Buffer): boolean;
/**
 * Read a ZIP archive's central directory and return one entry per file, each
 * with a lazy `data()` accessor that decompresses on demand. All entries
 * returned from one `readZipEntries` call share one extraction budget (see
 * {@link ZipReadPolicy.maxTotalUncompressedBytes}): calling `data()` past the
 * budget throws {@link ZipPolicyViolationError}, regardless of what any
 * entry's central-directory metadata claimed. Returns an empty list for
 * non-ZIP or truncated/corrupt input rather than throwing. Throws
 * {@link ZipPolicyViolationError} up front if the archive's OWN declared
 * metadata already violates `maxEntries` or a single entry's declared size
 * exceeds `maxEntryUncompressedBytes` — a cheap fast-reject that avoids
 * building entries for an obviously-bad archive, but is not the security
 * boundary by itself (that's the running budget above, since declared sizes
 * are untrusted).
 *
 * `bytes` must already be fully buffered in memory — for a multi-GB archive
 * where that is unacceptable, use {@link readZipEntriesFromFile} instead,
 * which reads the same way but pulls each window from a file descriptor.
 */
export declare function readZipEntries(bytes: Buffer, policy: ZipReadPolicy): ZipEntry[];
/**
 * Same algorithm and same security properties as {@link readZipEntries}, but
 * reads from an open file descriptor instead of a pre-buffered `Buffer`. The
 * archive's full bytes are never materialized as one in-memory buffer — the
 * central directory (metadata; small even for a huge archive) is read as one
 * bounded window, and each entry's compressed bytes are read from disk only
 * when that entry's `data()` is called. This is what makes multi-GB archive
 * support possible without multi-GB memory allocations: only the central
 * directory and, at any given moment, one entry's compressed+inflated bytes
 * need to be resident.
 *
 * `fd` is caller-owned: this function never opens or closes it.
 */
export declare function readZipEntriesFromFile(fd: number, fileSize: number, policy: ZipReadPolicy): ZipEntry[];
//# sourceMappingURL=bounded-zip-archive.d.ts.map