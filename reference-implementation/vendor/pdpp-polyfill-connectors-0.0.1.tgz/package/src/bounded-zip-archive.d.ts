export interface ZipReadPolicy {
    /** Reject archives whose central directory declares more entries than this. */
    readonly maxEntries: number;
    /** Bounds inflation of any single entry, enforced at inflate time via zlib's maxOutputLength. */
    readonly maxEntryUncompressedBytes: number;
    /**
     * Bounds the sum of ACTUAL bytes returned across every `data()` call made
     * against entries returned from one read-entries call — tracked with a
     * real running counter over genuine inflate output, not the untrusted
     * declared `uncompressed_size` field. Extracting entries beyond this budget
     * throws {@link ZipPolicyViolationError}.
     */
    readonly maxTotalUncompressedBytes: number;
}
export declare class ZipPolicyViolationError extends Error {
    readonly code: "entry_too_large" | "too_many_entries" | "total_too_large" | "unsafe_entry_name";
    constructor(code: ZipPolicyViolationError["code"], message: string, options?: {
        cause?: unknown;
    });
}
export interface ZipEntry {
    readonly compressedSize: number;
    readonly data: () => Buffer;
    readonly name: string;
    readonly uncompressedSize: number;
}
export declare function zipBasename(path: string): string;
export declare function hasZipLocalFileSignature(bytes: Buffer): boolean;
/**
 * Read a ZIP archive's central directory and return one entry per file, each
 * with a lazy `data()` accessor that decompresses on demand. All entries
 * returned from one `readZipEntries` call share one extraction budget (see
 * {@link ZipReadPolicy.maxTotalUncompressedBytes}): calling `data()` past the
 * budget throws {@link ZipPolicyViolationError}, regardless of what any
 * entry's central-directory metadata claimed. Returns an empty list for
 * non-ZIP or truncated/corrupt input rather than throwing. Throws
 * {@link ZipPolicyViolationError} up front if the archive's OWN declared
 * metadata already violates `maxEntries` or a single entry's declared size
 * exceeds `maxEntryUncompressedBytes` — a cheap fast-reject that avoids
 * building entries for an obviously-bad archive, but is not the security
 * boundary by itself (that's the running budget above, since declared sizes
 * are untrusted).
 *
 * `bytes` must already be fully buffered in memory — for a multi-GB archive
 * where that is unacceptable, use {@link readZipEntriesFromFile} instead,
 * which reads the same way but pulls each window from a file descriptor.
 */
export declare function readZipEntries(bytes: Buffer, policy: ZipReadPolicy): ZipEntry[];
/**
 * Same algorithm and same security properties as {@link readZipEntries}, but
 * reads from an open file descriptor instead of a pre-buffered `Buffer`. The
 * archive's full bytes are never materialized as one in-memory buffer — the
 * central directory (metadata; small even for a huge archive) is read as one
 * bounded window, and each entry's compressed bytes are read from disk only
 * when that entry's `data()` is called. This is what makes multi-GB archive
 * support possible without multi-GB memory allocations: only the central
 * directory and, at any given moment, one entry's compressed+inflated bytes
 * need to be resident.
 *
 * `fd` is caller-owned: this function never opens or closes it.
 */
export declare function readZipEntriesFromFile(fd: number, fileSize: number, policy: ZipReadPolicy): ZipEntry[];
export declare class ZipEntryNotFoundError extends Error {
    constructor(name: string);
}
export interface StreamZipEntryResult {
    readonly bytesWritten: number;
    readonly found: boolean;
}
/**
 * Extract exactly one named entry's payload to `destPath`, inflating (or
 * copying, for STORE-method entries) in bounded chunks so neither the
 * compressed nor the inflated bytes are ever fully resident in memory —
 * unlike {@link ZipEntry.data}, which returns one complete in-memory Buffer
 * and is appropriate only for entries policy already caps to a modest size.
 * This is the path for archive members that can legitimately be hundreds of
 * MB to multiple GB (e.g. an Apple Health `export.xml` inside the iOS Health
 * app's zip export): compressed bytes are read from `fd` in
 * {@link STREAM_READ_CHUNK_BYTES} windows and fed incrementally into a
 * `zlib.createInflateRaw()` transform stream piped straight to a
 * `fs.WriteStream` at `destPath`.
 *
 * Enforces the same declared-size gates as `readZipEntriesFromFile`
 * (per-entry and aggregate ceilings across every record walked, not just the
 * match) PLUS an actual-bytes cap on the entry being extracted, tracked by
 * counting real bytes written to `destPath` — an adversarial archive cannot
 * bypass the cap by lying about `uncompressedSize`, because the write count
 * is real, not declared.
 *
 * Returns `{ found: false, bytesWritten: 0 }` (no file created) when no
 * entry matches `entryName` (exact name or basename) — the archive itself
 * may still be a valid zip that simply doesn't contain the requested member,
 * which callers must distinguish from a policy violation (thrown, not
 * returned) or a genuinely corrupt archive.
 *
 * `fd` is caller-owned: this function never opens or closes it. On any
 * thrown error, a partially-written `destPath` is removed by the caller, not
 * here — this function has no opinion on cleanup ownership.
 */
export declare function streamZipEntryToFile(fd: number, fileSize: number, entryName: string, destPath: string, policy: ZipReadPolicy): Promise<StreamZipEntryResult>;
//# sourceMappingURL=bounded-zip-archive.d.ts.map