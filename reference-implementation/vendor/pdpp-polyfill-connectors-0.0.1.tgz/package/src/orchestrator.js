// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
/**
 * Polyfill orchestrator.
 *
 * Starts (or connects to) the reference-implementation personal server,
 * registers polyfill manifests, issues an owner token, and runs connectors
 * end-to-end via runConnector(). Records land in the RS; you can query them.
 */
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
const __dirname = dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = join(__dirname, "..");
const REFERENCE_IMPL_DIR = join(PACKAGE_ROOT, "..", "..", "reference-implementation");
/**
 * Absolute path to a specifier `import()` accepts on every platform.
 *
 * A bare absolute path works on POSIX by accident: it happens to look like a
 * root-relative URL. On Windows it does not, because "D:\..." parses as a URL
 * with scheme "d:", and Node's ESM loader rejects it with
 * ERR_UNSUPPORTED_ESM_URL_SCHEME. Matches the `pathToFileURL` form already
 * used in src/scrubber.ts and bin/scrub-fixtures.ts.
 */
function moduleSpecifier(...segments) {
    return pathToFileURL(join(...segments)).href;
}
export const DEFAULT_AS_URL = process.env.AS_URL || "http://localhost:7662";
export const DEFAULT_RS_URL = process.env.RS_URL || "http://localhost:7663";
export const DEFAULT_SUBJECT_ID = process.env.PDPP_SUBJECT_ID || "owner_local";
const OWNER_BOOTSTRAP_CLIENT = "pdpp-polyfill-owner-bootstrap";
export const MANIFEST_DIR = join(PACKAGE_ROOT, "manifests");
export const CONNECTORS_DIR = join(PACKAGE_ROOT, "connectors");
function c(name) {
    return {
        connectorPath: join(CONNECTORS_DIR, name, "index.ts"),
        manifestPath: join(MANIFEST_DIR, `${name}.json`),
    };
}
const KNOWN_CONNECTORS = {
    ynab: c("ynab"),
    gmail: c("gmail"),
    chatgpt: c("chatgpt"),
    usaa: c("usaa"),
    amazon: c("amazon"),
    github: c("github"),
    oura: c("oura"),
    spotify: c("spotify"),
    anthropic: c("anthropic"),
    shopify: c("shopify"),
    heb: c("heb"),
    wholefoods: c("wholefoods"),
    linkedin: c("linkedin"),
    meta: c("meta"),
    loom: c("loom"),
    uber: c("uber"),
    doordash: c("doordash"),
    whatsapp: c("whatsapp"),
    slack: c("slack"),
    pocket: c("pocket"),
    google_takeout: {
        connectorPath: join(CONNECTORS_DIR, "google_takeout", "index.ts"),
        manifestPath: join(MANIFEST_DIR, "google_takeout.json"),
    },
    google_maps: {
        connectorPath: join(CONNECTORS_DIR, "google_maps", "index.ts"),
        manifestPath: join(MANIFEST_DIR, "google_maps.json"),
    },
    google_maps_data_portability: c("google_maps_data_portability"),
    twitter_archive: {
        connectorPath: join(CONNECTORS_DIR, "twitter_archive", "index.ts"),
        manifestPath: join(MANIFEST_DIR, "twitter_archive.json"),
    },
    imessage: c("imessage"),
    strava: c("strava"),
    notion: c("notion"),
    reddit: c("reddit"),
    whoop: c("whoop"),
    claude_code: {
        connectorPath: join(CONNECTORS_DIR, "claude_code", "index.ts"),
        manifestPath: join(MANIFEST_DIR, "claude_code.json"),
    },
    codex: c("codex"),
    apple_health: {
        connectorPath: join(CONNECTORS_DIR, "apple_health", "index.ts"),
        manifestPath: join(MANIFEST_DIR, "apple_health.json"),
    },
    apple_photos: c("apple_photos"),
    ical: c("ical"),
    chase: c("chase"),
    apple_contacts: c("apple_contacts"),
    google_messages: c("google_messages"),
    google_calendar: c("google_calendar"),
    google_contacts: c("google_contacts"),
    groupme: c("groupme"),
    jellyfin: c("jellyfin"),
    netflix_export: c("netflix_export"),
    steam: c("steam"),
    venmo: c("venmo"),
    signal: c("signal"),
};
export const KNOWN_CONNECTOR_NAMES = Object.keys(KNOWN_CONNECTORS);
export function getConnectorPaths(name) {
    const paths = KNOWN_CONNECTORS[name];
    if (!paths) {
        throw new Error(`unknown connector: ${name}`);
    }
    return paths;
}
export function readManifest(name) {
    const { manifestPath } = getConnectorPaths(name);
    return JSON.parse(readFileSync(manifestPath, "utf8"));
}
/**
 * The connector set `bin/register-all.ts`'s smoke test registers: every
 * connector in the registry. Lifecycle tier controls what the owner is
 * offered; it does not remove a manifest from developer registration smoke
 * tests. Registering a Development manifest does not call its provider or
 * claim that its upstream remains available.
 *
 * This is the ONLY filter — manual-upload, local-device, and unlisted
 * connectors stay included, matching prior behavior: register-all's job is
 * "does the manifest parse and register", not "is this connector
 * owner-visible or auto-schedulable".
 */
export function selectRegisterAllConnectors(connectorNames, _readManifestFn) {
    return [...connectorNames];
}
async function asFetch(asUrl, path, opts = {}) {
    const res = await fetch(`${asUrl}${path}`, opts);
    const text = await res.text();
    let body;
    try {
        body = text ? JSON.parse(text) : {};
    }
    catch {
        body = { raw: text };
    }
    return { status: res.status, body };
}
export async function registerManifest(asUrl, manifest) {
    const { status, body } = await asFetch(asUrl, "/connectors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(manifest),
    });
    // 409 Conflict on re-register is fine — manifest version unchanged.
    if (status !== 201 && status !== 200 && status !== 409) {
        throw new Error(`register manifest failed ${status}: ${JSON.stringify(body)}`);
    }
    return body;
}
/**
 * Sign in to the AS as the owner when `PDPP_OWNER_PASSWORD` is set, returning
 * the session cookie to attach to subsequent gated requests (e.g. /device/approve).
 * When the password is unset the AS leaves the gate disabled and we return null.
 */
async function ownerLoginCookie(asUrl) {
    const password = process.env.PDPP_OWNER_PASSWORD;
    if (!password) {
        return null;
    }
    const res = await fetch(`${asUrl}/owner/login`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ password }).toString(),
        redirect: "manual",
    });
    if (res.status !== 302 && res.status !== 303) {
        const t = await res.text().catch(() => "");
        throw new Error(`/owner/login failed ${res.status}: ${t.slice(0, 200)}`);
    }
    const setCookie = res.headers.get("set-cookie");
    if (!setCookie) {
        throw new Error("/owner/login returned no Set-Cookie header");
    }
    // First name=value pair only; strip attributes like Path, HttpOnly, Max-Age.
    return setCookie.split(";")[0] ?? null;
}
export async function issueOwnerToken(asUrl, subjectId = DEFAULT_SUBJECT_ID) {
    const clientId = OWNER_BOOTSTRAP_CLIENT;
    const cookie = await ownerLoginCookie(asUrl);
    const cookieHeader = cookie ? { Cookie: cookie } : {};
    const deviceReq = await asFetch(asUrl, "/oauth/device_authorization", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ client_id: clientId }).toString(),
    });
    if (deviceReq.status !== 200) {
        throw new Error(`device_authorization failed ${deviceReq.status}: ${JSON.stringify(deviceReq.body)}`);
    }
    const device = deviceReq.body;
    const approveRes = await fetch(`${asUrl}/device/approve`, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            ...cookieHeader,
        },
        body: new URLSearchParams({
            user_code: device.user_code,
            subject_id: subjectId,
        }).toString(),
    });
    if (!approveRes.ok) {
        const t = await approveRes.text().catch(() => "");
        throw new Error(`device/approve failed ${approveRes.status}: ${t}`);
    }
    const tokenReq = await asFetch(asUrl, "/oauth/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            grant_type: "urn:ietf:params:oauth:grant-type:device_code",
            device_code: device.device_code,
            client_id: clientId,
        }).toString(),
    });
    if (tokenReq.status !== 200) {
        throw new Error(`/oauth/token failed ${tokenReq.status}: ${JSON.stringify(tokenReq.body)}`);
    }
    return tokenReq.body.access_token;
}
export async function startEmbeddedServer({ dbPath = join(PACKAGE_ROOT, ".pdpp-data/pdpp.sqlite"), } = {}) {
    const { startServer } = (await import(__rewriteRelativeImportExtension(moduleSpecifier(REFERENCE_IMPL_DIR, "server/index.ts"))));
    // Ensure dir exists
    const { mkdirSync } = await import("node:fs");
    mkdirSync(dirname(dbPath), { recursive: true });
    const server = await startServer({
        asPort: 0, // ephemeral — avoid collision with other PDPP servers
        rsPort: 0,
        dbPath,
        preRegisteredPublicClients: [
            {
                client_id: OWNER_BOOTSTRAP_CLIENT,
                metadata: {
                    client_name: "PDPP Polyfill Owner Bootstrap",
                    token_endpoint_auth_method: "none",
                },
            },
        ],
    });
    return server;
}
export async function loadPriorState(rsUrl, ownerToken, connectorId) {
    const { loadSyncState } = (await import(__rewriteRelativeImportExtension(moduleSpecifier(REFERENCE_IMPL_DIR, "runtime/index.ts"))));
    return loadSyncState({ connectorId, ownerToken, rsUrl });
}
export async function runOne(name, { asUrl = DEFAULT_AS_URL, rsUrl = DEFAULT_RS_URL, subjectId = DEFAULT_SUBJECT_ID, onInteraction, } = {}) {
    const manifest = readManifest(name);
    const { connectorPath } = getConnectorPaths(name);
    await registerManifest(asUrl, manifest);
    const ownerToken = await issueOwnerToken(asUrl, subjectId);
    const state = await loadPriorState(rsUrl, ownerToken, manifest.connector_id).catch(() => null);
    const collectionMode = state && Object.keys(state).length ? "incremental" : "full_refresh";
    const { runConnector } = (await import(__rewriteRelativeImportExtension(moduleSpecifier(REFERENCE_IMPL_DIR, "runtime/index.ts"))));
    const result = await runConnector({
        connectorPath,
        connectorId: manifest.connector_id,
        ownerToken,
        manifest,
        state: state && Object.keys(state).length ? state : null,
        collectionMode,
        persistState: true,
        rsUrl,
        onInteraction,
        onProgress: () => {
            /* noop */
        },
    });
    return { manifest, result, ownerToken };
}
export async function queryStream(rsUrl, ownerToken, stream, { limit = 5, connectorId, ...filters } = {}) {
    const url = new URL(`/v1/streams/${encodeURIComponent(stream)}/records`, rsUrl);
    url.searchParams.set("limit", String(limit));
    if (connectorId) {
        url.searchParams.set("connector_id", connectorId);
    }
    for (const [k, v] of Object.entries(filters)) {
        if (v !== undefined) {
            url.searchParams.set(k, String(v));
        }
    }
    const res = await fetch(url, {
        headers: { Authorization: `Bearer ${ownerToken}` },
    });
    const body = (await res.json());
    return { status: res.status, body };
}
