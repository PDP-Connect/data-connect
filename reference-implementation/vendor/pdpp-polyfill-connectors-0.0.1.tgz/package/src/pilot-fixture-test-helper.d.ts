import type { ValidateRecord } from "./connector-runtime.ts";
export interface PilotFixtureTestArgs {
    /** Connector directory name under `connectors/` (also matches the
     *  `fixtures/<connector>/` directory). */
    connector: string;
    /** Pilot fixtures lock record shape only; behavioral evidence belongs in focused connector tests. */
    evidence?: "shape-only";
    /** Validator from the connector's `schemas.ts`. */
    validateRecord: ValidateRecord;
}
/**
 * Register one `node:test` case per stream in the connector's pilot
 * fixture. Each test loads `records/<stream>.jsonl`, parses every
 * non-blank line, and asserts `validateRecord(stream, row).ok === true`.
 *
 * Behavior:
 *   - Missing fixture directory → registers a single test that fails
 *     with a clear "fixture missing" message. We intentionally do NOT
 *     skip — a connector that ships a `schemas.ts` SHOULD ship a
 *     fixture, and the test should make that visible. To opt out for
 *     a specific connector (legitimately), call `expectMissing: true`.
 *   - Empty fixture file → fails the test. A pilot fixture with zero
 *     rows isn't locking anything.
 *   - Per-row schema failure → fails the test with the issue list and
 *     the offending record's id.
 */
export declare function registerPilotFixtureTests(args: PilotFixtureTestArgs & {
    expectMissing?: boolean;
}): void;
//# sourceMappingURL=pilot-fixture-test-helper.d.ts.map