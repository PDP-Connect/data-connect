// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Test/observability seam that counts pre-flight wait sources on a request path.
 *
 * A correctly-converged path increments this exactly once per admitted request
 * (the single {@link SendGovernor}). Two increments on one request mean two
 * pre-flight gates are stacked — the spec violation the convergence forbids.
 * Wrap each sleep call site with {@link wrap}; the stacking regression test
 * asserts `count === 1` over a single admitted request.
 */
export class PreflightWaitProbe {
    _count = 0;
    _totalMs = 0;
    /** Number of pre-flight wait sources that fired since the last reset. */
    get count() {
        return this._count;
    }
    /** Total pre-flight wait time (ms) observed since the last reset. */
    get totalMs() {
        return this._totalMs;
    }
    reset() {
        this._count = 0;
        this._totalMs = 0;
    }
    /**
     * Wrap a sleep so a non-zero wait is counted as one pre-flight wait source.
     * Zero-or-negative waits are no-ops and are not counted: a governor that
     * computes a 0ms delay did not actually gate the request.
     */
    wrap(sleep) {
        return async (ms) => {
            if (ms > 0) {
                this._count += 1;
                this._totalMs += ms;
            }
            await sleep(ms);
        };
    }
}
