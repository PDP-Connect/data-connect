import { type EnrollmentExchangeResponse, LocalDeviceClient, LocalDeviceQueue, type LocalDeviceRecordEnvelope } from "@pdpp/collector-runtime";
import type { EmittedMessage, StartMessage } from "@pdpp/connector-protocol";
export declare const CODEX_CONNECTOR_ID = "codex";
export declare const CLAUDE_CODE_CONNECTOR_ID = "claude-code";
export declare const AMAZON_CONNECTOR_ID = "amazon";
export declare const IMESSAGE_CONNECTOR_ID = "imessage";
export declare const DEFAULT_CODEX_STREAMS: readonly ["sessions", "messages", "function_calls", "rules", "prompts", "skills"];
export declare const DEFAULT_CLAUDE_CODE_STREAMS: readonly ["sessions", "messages", "attachments", "memory_notes", "skills", "slash_commands"];
export declare const DEFAULT_AMAZON_STREAMS: readonly ["orders", "order_items"];
export declare const DEFAULT_IMESSAGE_STREAMS: readonly ["messages", "participants", "attachments"];
/**
 * Per-connector wiring for the local-device exporter. The device-envelope
 * export path (enroll → spawn connector → wrap RECORDs in
 * {device_id, source_instance_id, record_key} envelopes → ingest) is
 * connector-agnostic; this table is the only connector-specific part.
 *
 * The default child command is `tsx <entrypoint>`; the connector itself owns
 * its source-home resolution from env (CODEX_HOME, CLAUDE_CODE_HOME, …), so
 * binding a source home to a connector instance is a matter of running the
 * exporter once per (source_instance_id, source-home env) pair.
 */
export interface LocalDeviceConnectorProfile {
    readonly connectorId: string;
    readonly defaultStreams: readonly string[];
    readonly entrypoint: string;
}
export declare const LOCAL_DEVICE_CONNECTOR_PROFILES: Readonly<Record<string, LocalDeviceConnectorProfile>>;
export declare function resolveLocalDeviceConnectorProfile(connectorId: string): LocalDeviceConnectorProfile;
export interface LocalDeviceEnrollmentConfig {
    baseUrl: string;
    code: string;
    deviceLabel?: string;
}
export interface LocalDeviceRuntimeConfig {
    baseUrl: string;
    batchSize?: number;
    /** @deprecated use connectorArgs */
    codexArgs?: string[];
    /** @deprecated use connectorCommand */
    codexCommand?: string;
    /** @deprecated use connectorEnv */
    codexEnv?: NodeJS.ProcessEnv;
    /** Override the child args (defaults to the profile entrypoint). */
    connectorArgs?: string[];
    /** Override the child command (defaults to `tsx`). */
    connectorCommand?: string;
    /** Connector child env (e.g. CLAUDE_CODE_HOME / CODEX_HOME source-home binding). */
    connectorEnv?: NodeJS.ProcessEnv;
    /**
     * Connector to export. Defaults to {@link CODEX_CONNECTOR_ID} for backward
     * compatibility with the original Codex-only exporter. Claude Code source
     * homes export through this same path via {@link CLAUDE_CODE_CONNECTOR_ID}.
     */
    connectorId?: string;
    deviceId: string;
    deviceToken: string;
    queuePath: string;
    /**
     * Bound the number of records queued to a proof pass, e.g. for a UAT run
     * that should not push an operator's full source on first try. The
     * connector still reads its full local scope before this truncates the
     * result (this runtime is batch, not streaming, so there is no cheaper
     * abort point) — appropriate for a local-disk read like chat.db, not a
     * paginated network source. Unset queues every record the connector emits.
     *
     * Counts SUBSTANTIVE records only — `coverage_diagnostics` proof rows
     * (e.g. `collected`) are never part of the sampled count, so a small
     * limit like `0` truncates data without being satisfied by a diagnostic
     * row alone. See {@link LocalDeviceRuntimeResult.recordsQueued}.
     */
    sampleLimit?: number;
    sourceInstanceId: string;
    streams?: readonly string[];
}
export interface LocalDeviceRuntimeResult {
    done: Extract<EmittedMessage, {
        type: "DONE";
    }> | null;
    enqueuedBatches: number;
    /**
     * Records actually queued for ingest. `sampleLimit` bounds only the
     * SUBSTANTIVE (non-`coverage_diagnostics`) portion of this count — on an
     * UNTRUNCATED run (substantive records fit within `sampleLimit`, or no
     * `sampleLimit` was given) this number may additionally include the
     * run's `coverage_diagnostics` proof rows, which ride along uncounted
     * against the limit. On a TRUNCATED run, `coverage_diagnostics` rows are
     * withheld entirely — see `truncatedBySample`.
     */
    recordsQueued: number;
    /** Total records the connector emitted before any `sampleLimit` truncation. */
    recordsSeen: number;
    sentBatches: number;
    /** True when `sampleLimit` truncated the queued records below what the connector emitted. */
    truncatedBySample: boolean;
}
export declare function enrollLocalDevice(config: LocalDeviceEnrollmentConfig): Promise<EnrollmentExchangeResponse>;
/**
 * Run the local-device exporter for any supported connector. Binds the given
 * source home (carried in `connectorEnv`) to `sourceInstanceId`: every RECORD
 * the connector emits is wrapped in an envelope tagged with that
 * source-instance + device identity before it is queued and ingested, so two
 * source homes that share connector-local record keys never collide — the
 * reference store keys records by `(connector_instance_id, stream,
 * record_key)`, and each enrolled source home resolves to a distinct
 * connector instance.
 */
export declare function runLocalDeviceExporter(config: LocalDeviceRuntimeConfig): Promise<LocalDeviceRuntimeResult>;
/** @deprecated use {@link runLocalDeviceExporter}; retained for back-compat. */
export declare function runCodexLocalDeviceExporter(config: LocalDeviceRuntimeConfig): Promise<LocalDeviceRuntimeResult>;
export declare function buildLocalDeviceStartMessage(streams: readonly string[]): StartMessage;
/** @deprecated use {@link buildLocalDeviceStartMessage}. */
export declare function buildCodexStartMessage(streams?: readonly string[]): StartMessage;
export declare function transformRecordsToLocalDeviceEnvelopes(input: {
    batchId: string;
    batchSeq: number;
    connectorId?: string;
    deviceId: string;
    messages: readonly EmittedMessage[];
    sourceInstanceId: string;
}): LocalDeviceRecordEnvelope[];
export declare function drainLocalDeviceQueue(input: {
    client: Pick<LocalDeviceClient, "ingestBatch">;
    queue: LocalDeviceQueue;
}): Promise<number>;
//# sourceMappingURL=local-device-runtime.d.ts.map