/**
 * Platform-owned authority for whether a connector config option shapes
 * collection scope or only transport tuning.
 *
 * D10 (scripts/canary/otp-posture.ts): "qualification is proven, never
 * self-declared." A manifest's `options_schema[key].declared_option_kind`
 * is that connector's CLAIM. This registry is the platform's decision, and
 * it is the one connector_instance_config_store.propose() actually trusts
 * -- a manifest cannot widen its own eligibility by mislabeling a
 * collection-shaping knob as "transport" (which self-activates without
 * owner confirmation) instead of "collection_scope" (which does not).
 *
 * Deliberately asymmetric like the OTP posture derivation: a key absent
 * from this registry is NOT trusted as "transport" by omission -- callers
 * must look it up and treat an unknown key as collection_scope (the safer,
 * more restrictive default) rather than silently trusting whatever the
 * manifest wrote. See connector-config-option-kind-honesty.test.ts, which
 * fails the build if a manifest's declared_option_kind disagrees with this
 * registry for any key both sides know about.
 */
export type ConfigOptionKind = "collection_scope" | "transport";
export declare function platformOptionKind(connectorKey: string, optionKey: string): ConfigOptionKind | null;
/**
 * Resolve the kind the runtime will actually enforce for a manifest-declared
 * option: the platform's classification when registered, otherwise the
 * conservative collection_scope default -- never the manifest's own claim.
 */
export declare function resolveEnforcedOptionKind(connectorKey: string, optionKey: string): ConfigOptionKind;
//# sourceMappingURL=connector-config-option-kind-registry.d.ts.map