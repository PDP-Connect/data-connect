/**
 * Walk a paginated source without confusing a safety ceiling with a terminal
 * page. `fetchPage` performs the fetch and processing for one page, then
 * returns whether the provider says another page is available.
 *
 * The callback is allowed to return `true` on the final permitted page. That
 * is the important case: the provider still has unread data, so the result
 * must be marked truncated rather than complete.
 */
export declare function walkPagesWithCeiling(args: {
    readonly maxPages: number;
    readonly fetchPage: (pageNumber: number) => boolean | Promise<boolean>;
}): Promise<{
    pagesFetched: number;
    truncated: boolean;
}>;
//# sourceMappingURL=page-ceiling.d.ts.map