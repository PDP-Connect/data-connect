// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
export function manifestAuth(manifest) {
    return manifest.capabilities?.auth ?? null;
}
/**
 * The provider identity group a manifest declares, falling back to its own
 * connector key — two connectors sharing one provider app declare the same
 * group, so their deployment config resolves to one shared entry.
 */
export function identityGroup(manifest) {
    const raw = manifestAuth(manifest)?.provider_identity_group;
    const declared = typeof raw === "string" ? raw.trim() : "";
    return (declared ||
        manifest.connector_key?.trim() ||
        manifest.connector_id?.trim() ||
        "");
}
function readTrimmed(record, ...keys) {
    for (const key of keys) {
        const value = record[key];
        if (typeof value === "string" && value.trim()) {
            return value.trim();
        }
    }
    return null;
}
function deploymentConfigEntry(entry) {
    if (typeof entry === "string") {
        return entry.trim() ? { envAlias: null, logicalKey: entry.trim() } : null;
    }
    if (!(entry && typeof entry === "object")) {
        return null;
    }
    const record = entry;
    const logicalKey = readTrimmed(record, "logical_key", "key");
    return logicalKey
        ? { envAlias: readTrimmed(record, "env_alias"), logicalKey }
        : null;
}
/**
 * Normalizes a manifest's `capabilities.auth.deployment_config` — which may
 * declare each entry either as a bare logical-key string or as an object
 * with `logical_key`/`key` plus an optional `env_alias` — into one shape.
 */
export function deploymentConfigEntries(manifest) {
    const declared = manifestAuth(manifest)?.deployment_config;
    if (!Array.isArray(declared)) {
        return [];
    }
    return declared
        .map(deploymentConfigEntry)
        .filter((value) => value !== null);
}
export function findDeploymentEntry(entries, logicalKey) {
    return entries.find((entry) => entry.logicalKey === logicalKey) ?? null;
}
// ─── Deterministic eager registration ──────────────────────────────────
const adapters = new Map();
/**
 * Binds one `exchanger_kind` to its adapter. Called only by
 * provider-auth-adapters.ts, which owns the adapter list — an adapter module
 * never calls this itself, so an adapter's dependency on this module stays
 * type-only and the import graph stays acyclic. A second registration under
 * the same `kind` is a configuration error, not last-writer-wins.
 */
export function registerProviderAuthAdapter(kind, adapter) {
    if (adapters.has(kind)) {
        throw new Error(`provider_auth_adapter_kind_duplicate: ${kind}`);
    }
    adapters.set(kind, adapter);
}
/** Looks up an already-registered adapter. Callers go through
 * provider-auth-adapters.ts's `resolveProviderAuthAdapter`, which guarantees
 * registration has happened first. */
export function getRegisteredProviderAuthAdapter(kind) {
    return adapters.get(kind) ?? null;
}
/**
 * Test-only: drops in-process registration so a harness can re-register
 * without tripping the duplicate guard. Concrete adapter modules never call
 * this.
 */
export function _clearProviderAuthAdapterRegistryForTests() {
    adapters.clear();
}
