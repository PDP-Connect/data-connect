// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { AsyncLocalStorage } from "node:async_hooks";
import PQueue from "p-queue";
export class AdaptiveLaneQueueFullError extends Error {
    constructor(name, maxQueueSize) {
        super(`adaptive lane ${name} queue is full (maxQueueSize=${maxQueueSize})`);
        this.name = "AdaptiveLaneQueueFullError";
    }
}
export class AdaptiveLaneCancelledError extends Error {
    constructor(name, reason = "cancelled") {
        super(`adaptive lane ${name} cancelled: ${reason}`);
        this.name = "AdaptiveLaneCancelledError";
    }
}
export class AdaptiveLaneAttemptTimeoutError extends Error {
    attempt;
    constructor(name, attempt, timeoutMs) {
        super(`adaptive lane ${name} attempt ${attempt} timed out after ${timeoutMs}ms`);
        this.name = "AdaptiveLaneAttemptTimeoutError";
        this.attempt = attempt;
    }
}
const defaultSleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const runContextStorage = new AsyncLocalStorage();
export function currentAdaptiveLaneRunContext() {
    return runContextStorage.getStore();
}
function errorName(error) {
    return error instanceof Error ? error.name : typeof error;
}
function clampInt(value, min, max) {
    return Math.min(max, Math.max(min, Math.floor(value)));
}
function normalizeOutcome(outcome) {
    return typeof outcome === "string" ? { kind: outcome } : outcome;
}
export function createAdaptiveLane(options) {
    const minConcurrency = Math.max(1, Math.floor(options.minConcurrency));
    const maxConcurrency = Math.max(minConcurrency, Math.floor(options.maxConcurrency));
    const initialConcurrency = clampInt(options.initialConcurrency, minConcurrency, maxConcurrency);
    const maxAttempts = Math.max(1, Math.floor(options.maxAttempts ?? 1));
    const successWindow = Math.max(1, Math.floor(options.successWindow ?? Math.max(3, maxConcurrency)));
    const random = options.random ?? Math.random;
    const sleep = options.sleep ?? defaultSleep;
    const pressureMinDelayMs = Math.max(0, Math.floor(options.pressureMinDelayMs ?? options.minDelayMs));
    const pressureMaxDelayMs = Math.max(pressureMinDelayMs, Math.floor(options.pressureMaxDelayMs ?? options.maxDelayMs));
    const queue = new PQueue({ concurrency: initialConcurrency });
    let currentConcurrency = initialConcurrency;
    let cleanSuccesses = 0;
    let launchCount = 0;
    let pendingLaunchCooldownMs = 0;
    let cancelled = null;
    const laneController = new AbortController();
    const queued = new Set();
    const snapshot = () => ({
        activeCount: queue.pending,
        concurrency: currentConcurrency,
        maxConcurrency,
        minConcurrency,
        name: options.name,
        pendingCount: queue.pending,
        queueSize: queue.size,
    });
    const emit = async (event) => {
        const fullEvent = { ...snapshot(), ...event };
        await options.emitTelemetry?.(fullEvent);
        await options.emitProgress?.(fullEvent);
    };
    const emitSafely = (event) => {
        emit(event).catch(() => undefined);
    };
    const ensureNotCancelled = (signal) => {
        if (cancelled) {
            throw cancelled;
        }
        if (signal?.aborted) {
            throw new AdaptiveLaneCancelledError(options.name, "signal aborted");
        }
    };
    const wait = async (ms, signal) => {
        ensureNotCancelled(signal);
        if (ms <= 0) {
            return;
        }
        const abort = () => {
            throw (cancelled ??
                new AdaptiveLaneCancelledError(options.name, "signal aborted"));
        };
        let rejectAbort;
        const abortPromise = new Promise((_, reject) => {
            rejectAbort = reject;
        });
        const onAbort = () => rejectAbort(cancelled ??
            new AdaptiveLaneCancelledError(options.name, "signal aborted"));
        signal?.addEventListener("abort", onAbort, { once: true });
        laneController.signal.addEventListener("abort", onAbort, { once: true });
        try {
            if (signal?.aborted || laneController.signal.aborted) {
                abort();
            }
            await Promise.race([Promise.resolve(sleep(ms)), abortPromise]);
            ensureNotCancelled(signal);
        }
        finally {
            signal?.removeEventListener("abort", onAbort);
            laneController.signal.removeEventListener("abort", onAbort);
        }
    };
    const boundedDelay = (outcome, minDelayMs = options.minDelayMs, maxDelayMs = options.maxDelayMs) => {
        const { retryAfterMs } = outcome;
        if (retryAfterMs !== undefined) {
            return clampInt(retryAfterMs, minDelayMs, maxDelayMs);
        }
        const span = Math.max(0, maxDelayMs - minDelayMs);
        return minDelayMs + Math.floor(random() * (span + 1));
    };
    const boundedExplicitDelay = (delayMs) => clampInt(delayMs, pressureMinDelayMs, pressureMaxDelayMs);
    const launchDelay = () => {
        if (launchCount === 0) {
            return 0;
        }
        const span = Math.max(0, options.maxDelayMs - options.minDelayMs);
        return options.minDelayMs + Math.floor(random() * (span + 1));
    };
    const decreaseConcurrency = async (reason) => {
        const next = reason === "rate_limited"
            ? minConcurrency
            : Math.max(minConcurrency, Math.floor(currentConcurrency / 2));
        cleanSuccesses = 0;
        if (next !== currentConcurrency) {
            currentConcurrency = next;
            queue.concurrency = next;
            await emit({ reason, type: "concurrency_decreased" });
        }
    };
    const pressureOutcome = (pressure) => {
        const outcome = {
            kind: pressure.kind === "rate_limited" ? "rate_limited" : "retryable",
            reason: pressure.kind,
        };
        if (pressure.retryAfterMs !== undefined) {
            outcome.retryAfterMs = pressure.retryAfterMs;
        }
        return outcome;
    };
    const reportPressure = async (pressure, attempt, signal) => {
        ensureNotCancelled(signal);
        const outcome = pressureOutcome(pressure);
        await decreaseConcurrency(outcome.kind);
        const delayMs = pressure.delayMs === undefined
            ? boundedDelay(outcome, pressureMinDelayMs, pressureMaxDelayMs)
            : boundedExplicitDelay(pressure.delayMs);
        // When the reporting task already slept `delayMs` inside its own retry loop
        // and then succeeded, mirroring the same wait into the next-launch cooldown
        // double-pays the backoff. Reduce concurrency and surface the event, but
        // skip the cooldown — the normal inter-launch pace (launchDelay) still
        // applies, so this removes duplicated waiting without becoming aggressive.
        if (!pressure.absorbedByRequestWait) {
            pendingLaunchCooldownMs = Math.max(pendingLaunchCooldownMs, delayMs);
        }
        await emit(outcomeEvent({
            attempt,
            delayMs,
            outcome,
            type: outcome.kind === "rate_limited" ? "cooldown" : "retry_scheduled",
        }));
    };
    const maybeIncreaseConcurrency = async () => {
        cleanSuccesses += 1;
        if (cleanSuccesses < successWindow ||
            currentConcurrency >= maxConcurrency) {
            return;
        }
        cleanSuccesses = 0;
        currentConcurrency += 1;
        queue.concurrency = currentConcurrency;
        await emit({
            reason: "clean_success_window",
            type: "concurrency_increased",
        });
    };
    const cancel = (reason = "cancelled") => {
        if (cancelled) {
            return;
        }
        cancelled = new AdaptiveLaneCancelledError(options.name, reason);
        laneController.abort(cancelled);
        queue.clear();
        for (const entry of queued) {
            if (!entry.started) {
                entry.reject(cancelled);
            }
        }
        queued.clear();
        emitSafely({ reason, type: "cancelled" });
    };
    const runContext = (attempt, signal) => {
        const context = {
            attempt,
            reportPressure: (pressure) => reportPressure(pressure, attempt, signal),
        };
        if (signal) {
            context.signal = signal;
        }
        return context;
    };
    const runAttempt = (task, attempt, signal) => {
        const context = runContext(attempt, signal);
        const attemptPromise = runContextStorage.run(context, () => Promise.resolve(task(context)));
        if (options.attemptTimeoutMs === undefined) {
            return attemptPromise;
        }
        return Promise.race([
            attemptPromise,
            wait(options.attemptTimeoutMs, signal).then(() => {
                throw new AdaptiveLaneAttemptTimeoutError(options.name, attempt, options.attemptTimeoutMs ?? 0);
            }),
        ]);
    };
    const outcomeEvent = (event) => {
        const base = {
            attempt: event.attempt,
            outcome: event.outcome.kind,
            type: event.type,
        };
        if (event.delayMs !== undefined) {
            base.delayMs = event.delayMs;
        }
        if (event.error !== undefined) {
            base.errorName = errorName(event.error);
        }
        if (event.outcome.reason !== undefined) {
            base.reason = event.outcome.reason;
        }
        if (event.outcome.retryAfterMs !== undefined) {
            base.retryAfterMs = event.outcome.retryAfterMs;
        }
        return base;
    };
    const handlePressure = async (outcome, attempt, signal, error) => {
        if (outcome.kind === "terminal" || attempt >= maxAttempts) {
            await decreaseConcurrency(outcome.kind);
            await emit(outcomeEvent({ attempt, error, outcome, type: "completed" }));
            return "stop";
        }
        await decreaseConcurrency(outcome.kind);
        const delayMs = boundedDelay(outcome);
        await emit(outcomeEvent({
            attempt,
            delayMs,
            error,
            outcome,
            type: outcome.kind === "rate_limited" ? "cooldown" : "retry_scheduled",
        }));
        await wait(delayMs, signal);
        return "retry";
    };
    const runAttempts = async (task, signal) => {
        for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
            try {
                const result = await runAttempt(task, attempt, signal);
                const outcome = normalizeOutcome(options.classifyOutcome({ result }));
                if (outcome.kind === "ok") {
                    await maybeIncreaseConcurrency();
                    await emit({ attempt, outcome: outcome.kind, type: "completed" });
                    return result;
                }
                if ((await handlePressure(outcome, attempt, signal)) === "stop") {
                    return result;
                }
            }
            catch (error) {
                const outcome = normalizeOutcome(options.classifyOutcome({ error }));
                if (outcome.kind === "ok") {
                    throw error;
                }
                if ((await handlePressure(outcome, attempt, signal, error)) === "stop") {
                    throw error;
                }
            }
        }
        throw new Error(`adaptive lane ${options.name} exhausted without terminal outcome`);
    };
    const startQueuedTask = async (entry, task, runOptions, signal) => {
        try {
            entry.started = true;
            queued.delete(entry);
            ensureNotCancelled(signal);
            runOptions.onBeforeStart?.();
            const delayMs = launchDelay();
            const cooldownMs = pendingLaunchCooldownMs;
            pendingLaunchCooldownMs = 0;
            // Fold the optional pre-flight delay signal (e.g. GCRA pacing) into the
            // SINGLE launch wait. `max`, never sum: pacing influences velocity through
            // the one governor instead of stacking a second pre-flight wait.
            const hintMs = options.launchDelayHint?.() ?? 0;
            const launchWaitMs = Math.max(delayMs, cooldownMs, hintMs);
            launchCount += 1;
            if (launchWaitMs > 0) {
                await wait(launchWaitMs, signal);
            }
            await emit({ type: "started" });
            return await runAttempts(task, signal);
        }
        catch (error) {
            runOptions.onFailure?.(error);
            throw error;
        }
    };
    const run = (task, runOptions = {}) => {
        const { signal } = runOptions;
        ensureNotCancelled(signal);
        if (options.maxQueueSize >= 0 &&
            queue.size + queue.pending >= options.maxQueueSize) {
            const error = new AdaptiveLaneQueueFullError(options.name, options.maxQueueSize);
            emitSafely({ errorName: error.name, type: "queue_rejected" });
            return Promise.reject(error);
        }
        return new Promise((resolve, reject) => {
            const entry = { reject, started: false };
            queued.add(entry);
            const onAbort = () => {
                reject(new AdaptiveLaneCancelledError(options.name, "signal aborted"));
            };
            signal?.addEventListener("abort", onAbort, { once: true });
            emitSafely({ type: "queued" });
            queue
                .add(() => startQueuedTask(entry, task, runOptions, signal))
                .then(resolve, reject)
                .finally(() => {
                signal?.removeEventListener("abort", onAbort);
                queued.delete(entry);
            });
        });
    };
    return {
        name: options.name,
        cancel,
        run,
        runAll: async (items, task, runOptions) => {
            let firstFailure = null;
            const sharedRunOptions = {
                onBeforeStart: () => {
                    if (firstFailure) {
                        throw firstFailure;
                    }
                },
                onFailure: (error) => {
                    firstFailure ??= error;
                },
            };
            if (runOptions?.signal) {
                sharedRunOptions.signal = runOptions.signal;
            }
            const runs = items.map((item) => run((context) => task(item, context), sharedRunOptions));
            try {
                return await Promise.all(runs);
            }
            catch (error) {
                firstFailure ??= error;
                await Promise.allSettled(runs);
                throw firstFailure;
            }
        },
        snapshot,
    };
}
