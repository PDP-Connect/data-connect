// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Shared test harness for connector integration tests.
 *
 * Every integration test needs a fake `emit` + `emitRecord` pair that
 * captures what the collect() layer would push over the wire. Until
 * this file existed, each connector rolled its own, and the hand-rolled
 * `emitRecord` skipped the zod shape-check that the production runtime
 * applies. That meant a record that would SKIP_RESULT in production
 * silently landed in `.emitted` inside tests — tests looked green,
 * truth looked different.
 *
 * `makeRecordingEmit(validateRecord)` fixes that. It mirrors the
 * runtime's RECORD path: records that pass the zod check land in
 * `.emitted`; records that fail land in `.skipped`. Pass no validator
 * and you get pass-through mode for tests where the shape-check isn't
 * what's under test (e.g. pure scope-filter gates).
 *
 * This module has no side effects at import time. It exports only
 * factories and pure helpers.
 */
import { spawn } from "node:child_process";
import { readFileSync } from "node:fs";
import { stringifyForJsonl } from "@pdpp/connector-protocol";
const VM_RSS_STATUS_RE = /VmRSS:\s*(\d+)\s*kB/;
/**
 * Returns an emit/emitRecord pair that validates records through
 * `validateRecord`. Records that pass land in `.emitted`; records that
 * fail land in `.skipped` (same semantics as the runtime's RECORD
 * shape-check). The `.emit` side-channel records any direct protocol
 * messages (PROGRESS, STATE, SKIP_RESULT, INTERACTION) the helper
 * under test emits.
 *
 * If `validateRecord` is omitted, `emitRecord` is pass-through — useful
 * for tests where the helper is a pure function and the shape-check
 * isn't the point (e.g. scope-filter gates, ordering invariants on
 * synthetic data that intentionally omits fields).
 */
export function makeRecordingEmit(validateRecord) {
    const emitted = [];
    const skipped = [];
    const protocolMessages = [];
    const events = [];
    const emit = (msg) => {
        protocolMessages.push(msg);
        events.push({ kind: "message", message: msg });
        return Promise.resolve();
    };
    const emitRecord = (stream, data) => {
        if (validateRecord) {
            const result = validateRecord(stream, data);
            if (!result.ok) {
                skipped.push({ stream, issues: result.issues });
                events.push({
                    kind: "record-skipped",
                    stream,
                    issues: result.issues,
                    skipped: true,
                });
                return Promise.resolve();
            }
        }
        emitted.push({ stream, data });
        events.push({ kind: "record", stream, data, skipped: false });
        return Promise.resolve();
    };
    return { emit, emitRecord, emitted, events, skipped, protocolMessages };
}
/**
 * Run a connector entrypoint as a real child process and drive the
 * Collection Profile protocol over stdio. Unlike `makeRecordingEmit`,
 * this proves START parsing, stdout JSONL framing, DONE emission, and
 * process exit behavior without importing the connector module directly.
 */
export function runConnectorProtocolSubprocess(options) {
    const timeoutMs = options.timeoutMs ?? 15_000;
    return new Promise((resolve, reject) => {
        const child = spawn(process.execPath, ["--import", "tsx", options.entrypoint], {
            cwd: options.cwd,
            env: {
                ...process.env,
                PATCHRIGHT_SKIP_BROWSER_DOWNLOAD: "1",
                PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD: "1",
                ...options.env,
            },
            stdio: ["pipe", "pipe", "pipe"],
        });
        let peakRssBytes = null;
        let rssPoller;
        const { pid } = child;
        if (options.peakRssPollIntervalMs && pid) {
            rssPoller = setInterval(() => {
                try {
                    const status = readFileSync(`/proc/${pid}/status`, "utf8");
                    const match = VM_RSS_STATUS_RE.exec(status);
                    if (match?.[1]) {
                        const bytes = Number.parseInt(match[1], 10) * 1024;
                        peakRssBytes =
                            peakRssBytes === null ? bytes : Math.max(peakRssBytes, bytes);
                    }
                }
                catch {
                    // /proc/<pid>/status is unavailable (non-Linux, or the process
                    // already exited between the tick firing and the read) -- leave
                    // peakRssBytes at its last known value.
                }
            }, options.peakRssPollIntervalMs);
        }
        const messages = [];
        let rawStdout = "";
        let stderr = "";
        let stdoutBuffer = "";
        let settled = false;
        let timer;
        const finish = (fn) => {
            if (settled) {
                return;
            }
            settled = true;
            clearTimeout(timer);
            if (rssPoller) {
                clearInterval(rssPoller);
            }
            fn();
        };
        const rejectAndKill = (error) => {
            if (!child.killed) {
                child.kill("SIGKILL");
            }
            finish(() => reject(error));
        };
        const parseLine = (line) => {
            if (!line.trim()) {
                return;
            }
            try {
                messages.push(JSON.parse(line));
            }
            catch (err) {
                const message = err instanceof Error ? err.message : String(err);
                rejectAndKill(new Error(`connector emitted invalid JSONL: ${message}; line=${line}`));
            }
        };
        timer = setTimeout(() => {
            rejectAndKill(new Error(`connector subprocess timed out after ${String(timeoutMs)}ms; stderr=${stderr}`));
        }, timeoutMs);
        child.stdout?.on("data", (chunk) => {
            const text = chunk.toString();
            rawStdout += text;
            stdoutBuffer += text;
            let newlineIndex = stdoutBuffer.indexOf("\n");
            while (newlineIndex !== -1) {
                const line = stdoutBuffer.slice(0, newlineIndex);
                stdoutBuffer = stdoutBuffer.slice(newlineIndex + 1);
                parseLine(line);
                newlineIndex = stdoutBuffer.indexOf("\n");
            }
        });
        child.stderr?.on("data", (chunk) => {
            stderr += chunk.toString();
        });
        child.on("error", (err) => {
            finish(() => reject(err));
        });
        // 'close' (not 'exit'): 'exit' can fire before the stdio pipes have
        // finished draining their last buffered chunk, so `messages` may still be
        // missing the connector's final PROGRESS/DONE line at that instant. 'close'
        // is documented to fire only after the stdio streams have ended, so every
        // byte the child wrote is guaranteed parsed into `messages` by then.
        child.on("close", (code, signal) => {
            if (stdoutBuffer.trim()) {
                parseLine(stdoutBuffer);
            }
            if (settled) {
                return;
            }
            const done = messages.findLast((m) => m.type === "DONE");
            if (!done) {
                finish(() => reject(new Error(`connector subprocess exited without DONE: code=${String(code)} signal=${String(signal)} stderr=${stderr}`)));
                return;
            }
            if (done.status === "failed" && options.allowFailedDone === true) {
                finish(() => resolve({ code, messages, peakRssBytes, rawStdout, signal, stderr }));
                return;
            }
            if (code !== 0 || signal) {
                finish(() => reject(new Error(`connector subprocess exited non-zero after DONE: code=${String(code)} signal=${String(signal)} stderr=${stderr}`)));
                return;
            }
            if (done.status === "failed") {
                finish(() => reject(new Error(`connector subprocess reported failed: ${done.error?.message ?? "unknown"}; code=${String(code)} stderr=${stderr}`)));
                return;
            }
            finish(() => resolve({ code, messages, peakRssBytes, rawStdout, signal, stderr }));
        });
        child.stdin?.end(stringifyForJsonl(options.start));
    });
}
