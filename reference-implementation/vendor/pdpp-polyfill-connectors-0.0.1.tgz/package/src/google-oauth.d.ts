export type GoogleOAuthFetch = (url: string, init: RequestInit) => Promise<Response>;
export interface GoogleOAuthCredentials {
    readonly clientId: string;
    readonly clientSecret: string;
    readonly refreshToken: string;
}
export interface GoogleAccessToken {
    readonly accessToken: string;
    /** Epoch ms this token expires at, per Google's `expires_in` (seconds). */
    readonly expiresAt: number;
}
export declare class GoogleOAuthError extends Error {
    readonly bodySnippet: string;
    readonly status: number;
    constructor(status: number, bodySnippet: string);
}
/**
 * Resolve the shared Google OAuth app credentials + this connector's refresh
 * token from the environment. `refreshTokenEnvVar` lets each connector own a
 * distinct refresh token (Calendar and Contacts are typically separate
 * consent grants even against the same app registration) while sharing the
 * client id/secret.
 */
export declare function resolveGoogleOAuthCredentials(env: NodeJS.ProcessEnv | Record<string, string | undefined>, refreshTokenEnvVar: string): GoogleOAuthCredentials;
/**
 * Exchange a refresh_token for a fresh access_token via Google's token
 * endpoint (RFC 6749 §6). Callers cache the result for the run's duration;
 * this function performs no caching itself — it is a single, pure network
 * call so it stays testable with an injected `fetch`.
 */
export declare function refreshGoogleAccessToken(credentials: GoogleOAuthCredentials, options?: {
    fetch?: GoogleOAuthFetch;
    now?: () => number;
    tokenUrl?: string;
}): Promise<GoogleAccessToken>;
/**
 * True when a Google API response's error body indicates the grant itself is
 * dead (revoked consent, expired/invalid refresh token) rather than a
 * transient failure. Both Calendar and Contacts connectors use this to
 * distinguish "ask the owner to reconnect" from "retry next run" — matching
 * the reconciliation report's requirement to detect expired-token full-resync
 * conditions explicitly rather than treating every 401 as retryable.
 */
export declare function isGoogleOAuthGrantInvalid(error: unknown): boolean;
//# sourceMappingURL=google-oauth.d.ts.map