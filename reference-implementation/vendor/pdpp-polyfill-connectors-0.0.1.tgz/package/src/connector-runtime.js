// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * One runtime for every connector.
 *
 * The protocol — START → RECORD/STATE/SKIP_RESULT/PROGRESS → DONE — is
 * framework, not business logic. A connector should express WHAT it
 * collects, not HOW the protocol handshake works. This module owns the
 * handshake; connectors own the collection.
 *
 *   import { runConnector } from '../../src/connector-runtime.js';
 *   import { validateRecord } from './schemas.js';
 *
 *   runConnector({
 *     name: 'notion',
 *     validateRecord,
 *     async collect({ scope, state, emit, emitRecord, progress }) {
 *       // pure business logic
 *     },
 *   });
 *
 * For browser-based connectors, add `browser: { profileName }` and the
 * runtime acquires an isolated Playwright context, passing `page` and
 * `context` into collect(). Browser mode is deployment-owned: Core defaults
 * local sessions to headed Patchright Chromium under managed Xvfb, while the
 * single `PDPP_BROWSER_HEADLESS=1` override selects the advanced headless
 * path. Optional `ensureSession` and `probeSession` callbacks automate
 * re-auth on session expiry.
 *
 * What the runtime owns (connector never writes this code again):
 *   - Reading START from stdin, validating shape
 *   - Building scope.streams into a Map + resourceSet filters
 *   - Zod shape-check via validateRecord; SKIP_RESULT on drift
 *   - Scope time_range filter on records with a configurable date field
 *   - Counters (emitted + skipped)
 *   - Browser acquire + release + finally cleanup
 *   - Playwright tracing lifecycle (PDPP_TRACE=1)
 *   - Fixture capture lifecycle (PDPP_CAPTURE_FIXTURES=1 always-retain;
 *     PDPP_CAPTURE_ON_FAILURE=1 retain-on-failure with on-success cleanup)
 *   - Terminal DONE + flushAndExit on both success and throw
 *   - Retryable-error detection via retryablePattern regex
 *   - Auth strategy resolution before collect() runs
 */
import { rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { createInterface } from "node:readline";
import { emitToStdout, resourceSet } from "@pdpp/connector-protocol";
import { resolveAuth } from "@pdpp/connector-protocol/auth";
import { DEADLINE_TIMEOUT, prepareBrowserInteractionTarget, unregisterBrowserInteractionTarget, withDeadline, } from "./browser-handoff.js";
import { flushAndExitAfterRuntimeAck } from "./connector-exit.js";
import { createCaptureSession, } from "./fixture-capture.js";
import { DEFAULT_RETRYABLE_PATTERN, establishSession, } from "./session-establish.js";
import { assertValidConnectorErrorCode, TerminalError, } from "./terminal-error.js";
/**
 * The one shared constructor for a connector-declared typed terminal
 * failure. Every connector that wants a stable `error.code` on its DONE
 * message (rather than relying purely on free-form, redacted `message`
 * text) should throw `createConnectorFailure(...)` instead of hand-rolling
 * `throw new Error(...)` or an ad hoc `{ code, message }` object — this is
 * the single point that validates `code` before it can ever reach the
 * unredacted `connector_error_code` column.
 *
 * `message` is ordinary human-readable free-form text: it still goes
 * through `boundConnectorErrorMessage`/`redactStderrTail` exactly like any
 * other connector-authored message, so it must never itself be treated as
 * safe — write it as you would write any other diagnostic string.
 */
export function createConnectorFailure(code, message, options = {}) {
    assertValidConnectorErrorCode(code);
    return new TerminalError(message, { ...options, code });
}
export const BROWSER_HEADLESS_ENV = "PDPP_BROWSER_HEADLESS";
const TRACE_TIMESTAMP_UNSAFE = /[:.]/g;
/**
 * Compose a stable, infrastructure-set terminal-error `code` (e.g.
 * `browser_surface_attach_exhausted`, thrown by the runtime itself via
 * `TerminalError.code` — never a connector-authored message-parse result)
 * with whatever a connector's `normalizeTerminalError` returns.
 *
 * Every current connector normalizer (e.g. ChatGPT's
 * `normalizeChatGptTerminalError`) destructures only `{ message, retryable }`
 * and returns a fresh object, so an incoming infrastructure code is silently
 * dropped unless something restores it. That is data loss, not a deliberate
 * override — a connector never had the chance to see or reject the code it
 * never destructured.
 *
 * Precedence: if the connector's normalizer output ALREADY carries its own
 * `code` (e.g. ChatGPT's explicit `credential_rejected`), that choice is
 * deliberate and wins outright. The infrastructure code only backfills a
 * `code` field the normalized result left empty.
 *
 * Exported and pure so this composition rule is unit-testable without
 * driving the full `runConnector` process/stdio wiring.
 */
export function composeNormalizedTerminalError({ message, retryable, code, normalizeTerminalError, }) {
    const normalized = normalizeTerminalError({
        message,
        retryable,
        ...(code ? { code } : {}),
    });
    return code && !normalized.code ? { ...normalized, code } : normalized;
}
const UNEXPECTED_FAILURE_DETAIL_MAX = 300;
/**
 * Known third-party error shapes that carry their real diagnostic detail on
 * SIDE FIELDS rather than in `.message` — e.g. imapflow's protocol errors
 * (`new Error('Command failed')`, imap-flow.js's `settleRequest`) always use
 * the same generic message and put the server's actual NO/BAD explanation on
 * `.responseText`, with the IMAP command that triggered it on
 * `.executedCommand`. `run().catch` below used to read only `.message`,
 * so every IMAP auth/throttle/quota rejection reached the owner as the
 * indistinguishable, contentless "Command failed" (see docs/inbox/
 * report-gmail-command-failed.md). `executedCommand` is safe to surface:
 * imapflow's compiler is built with `isLogging: true` for this exact field,
 * which replaces any field marked `sensitive` (LOGIN's password argument)
 * with the literal string `(* value hidden *)` before it ever reaches this
 * object -- see imap-flow.js's settleRequest and commands/login.js.
 */
function extractKnownErrorDetail(err) {
    const withDetail = err;
    const parts = [];
    if (typeof withDetail.responseText === "string" &&
        withDetail.responseText.length > 0) {
        parts.push(`server: ${withDetail.responseText}`);
    }
    if (typeof withDetail.executedCommand === "string" &&
        withDetail.executedCommand.length > 0) {
        parts.push(`command: ${withDetail.executedCommand}`);
    }
    return parts.length > 0 ? parts.join("; ") : null;
}
/**
 * Builds the message an UNEXPECTED (non-`TerminalError`) throw carries into
 * `DONE.error.message` -- an unexpected throw's own `.message` alone is
 * sometimes a generic, contentless string (imapflow's `'Command failed'`
 * for every IMAP NO/BAD response) while the real explanation sits on a
 * side field the generic catch previously never looked at. Bounded so a
 * pathological response body can't bloat the terminal DB row; must never
 * include credential material (see `extractKnownErrorDetail`'s doc comment
 * on why `executedCommand` is already redacted at the source).
 */
export function describeUnexpectedFailure(err) {
    if (!(err instanceof Error)) {
        return String(err);
    }
    const detail = extractKnownErrorDetail(err);
    const combined = detail ? `${err.message} (${detail})` : err.message;
    return combined.length > UNEXPECTED_FAILURE_DETAIL_MAX
        ? `${combined.slice(0, UNEXPECTED_FAILURE_DETAIL_MAX)}…`
        : combined;
}
/** Returns true if the scope's time_range excludes this record's date value. */
function isOutsideTimeRange(timeRange, dateValue) {
    if (typeof dateValue !== "string" || !dateValue) {
        return false;
    }
    if (timeRange.since && dateValue < timeRange.since.slice(0, 10)) {
        return true;
    }
    if (timeRange.until && dateValue >= timeRange.until.slice(0, 10)) {
        return true;
    }
    return false;
}
/** Build a SKIP_RESULT for a shape-check failure. */
function makeShapeCheckSkip(stream, data, issues) {
    const message = `${String(data.id)}: ${issues.map((i) => `${i.path}: ${i.message}`).join("; ")}`;
    return {
        type: "SKIP_RESULT",
        stream,
        reason: "shape_check_failed",
        message,
        diagnostics: { id: data.id, issues, record: data },
    };
}
/**
 * Build the SKIP_RESULT-shaped diagnostic for a record that was RETAINED
 * despite carrying a value the schema does not model (see `makeValidateRecord`).
 *
 * This is a report, not a skip: the record emits normally and this rides
 * alongside it. It reuses the SKIP_RESULT envelope because that is the existing
 * per-record diagnostic channel the console already surfaces, and carries a
 * distinct `reason` so a reader can tell "we kept this and here is the drift"
 * from "we dropped this". Values are reported verbatim so the operator can see
 * what the vendor actually sent and widen the schema against real data.
 */
function makeShapeAnomalyReport(stream, data, anomalies) {
    const detail = anomalies
        .map((a) => `${a.path}: unmodeled value ${JSON.stringify(a.value)}`)
        .join("; ");
    return {
        type: "SKIP_RESULT",
        stream,
        reason: "shape_check_unmodeled_value",
        message: `${String(data.id)}: retained with ${detail}`,
        diagnostics: { id: data.id, anomalies, retained: true },
    };
}
/**
 * Build one parent-boundary DETAIL_COVERAGE message after that detail work
 * settles. A shared detail stream emits one message per independently
 * checkpointed parent. Pure: the caller owns when/whether to emit. Empty
 * optional key sets are omitted so a fully hydrated boundary carries no gap
 * fields.
 */
export function buildDetailCoverageMessage(params) {
    const { stream, stateStream, requiredKeys, hydratedKeys, gapKeys, optionalSkipKeys, considered, covered, } = params;
    return {
        type: "DETAIL_COVERAGE",
        reference_only: true,
        stream,
        state_stream: stateStream,
        required_keys: [...requiredKeys],
        hydrated_keys: [...hydratedKeys],
        // Only emit `considered` when the connector supplied a non-negative integer.
        // The runtime re-validates and drops anything unsafe to `unknown`; omitting
        // it here keeps a no-considered run byte-identical to the prior shape.
        ...(typeof considered === "number" &&
            Number.isInteger(considered) &&
            considered >= 0
            ? { considered }
            : {}),
        // Same drop-don't-fabricate posture for the optional `covered` count: omitting
        // it when absent or unsafe keeps a no-covered run byte-identical to the prior
        // shape, so every existing declarer is unaffected.
        ...(typeof covered === "number" && Number.isInteger(covered) && covered >= 0
            ? { covered }
            : {}),
        ...(gapKeys?.length ? { gap_keys: [...gapKeys] } : {}),
        ...(optionalSkipKeys?.length
            ? { optional_skip_keys: [...optionalSkipKeys] }
            : {}),
    };
}
/**
 * Build the self-coverage DETAIL_COVERAGE for a full-scan stream: one whose
 * whole boundary is re-enumerated every run and which has no separate detail
 * hydration phase, so the key sets stay empty and `stream === state_stream`.
 *
 * `considered` is the enumerated boundary size, measured at the enumeration
 * site — never the emitted count (see `DetailCoverageParams.considered`). Every
 * in-boundary item is either emitted or suppressed as unchanged, so `covered`
 * equals `considered` and a steady-state run reads covered rather than a false
 * `partial`. A successful enumeration that found nothing declares
 * `considered === covered === 0`: proven-empty is a fact, and it is the only
 * way an empty stream can prove coverage rather than merely lack evidence.
 *
 * The caller owns when to emit, and MUST emit only on a successful
 * enumeration — a fetch or parse failure never proves an empty boundary.
 */
export function buildFullScanCoverageMessage(stream, considered) {
    return buildDetailCoverageMessage({
        stream,
        stateStream: stream,
        requiredKeys: [],
        hydratedKeys: [],
        considered,
        covered: considered,
    });
}
/**
 * Thin emit wrapper for connectors adopting the detail coverage contract. `ctx`
 * is structural so both the collect context and connector-local dependency bags
 * can use it without importing a heavier runtime type.
 */
export function emitDetailCoverage(ctx, params) {
    return ctx.emit(buildDetailCoverageMessage(params));
}
/**
 * Build a recoverable `DETAIL_GAP` message. Pure: the caller owns when/whether to
 * emit. The fixed reference-only shape (`status: "pending"`, `retryable: true`,
 * `reference_only: true`) is centralized here so a connector states only what
 * varies. Optional protocol fields (`parent_stream`, `list_cursor`, `detail`,
 * `last_error`) are omitted from the wire message when their input is absent, so
 * a minimal gap carries no empty blocks. When `error` is supplied, the `detail`
 * and `last_error` blocks share the same class / http_status / network_pressure;
 * `error.message` (if any) is added to `last_error` only, since the protocol's
 * `detail` block has no `message` field.
 */
export function buildDetailGap(params) {
    const { stream, recordKey, reason, locator, parentStream, listCursor, error, } = params;
    let errorBlocks = {};
    if (error) {
        const sharedBlock = {
            class: error.class,
            ...(error.httpStatus == null ? {} : { http_status: error.httpStatus }),
            ...(error.networkPressure == null
                ? {}
                : { network_pressure: error.networkPressure }),
        };
        errorBlocks = {
            detail: sharedBlock,
            last_error: error.message == null
                ? sharedBlock
                : { ...sharedBlock, message: error.message },
        };
    }
    return {
        type: "DETAIL_GAP",
        stream,
        ...(parentStream == null ? {} : { parent_stream: parentStream }),
        record_key: recordKey,
        status: "pending",
        reason,
        detail_locator: locator,
        ...(listCursor === undefined ? {} : { list_cursor: listCursor }),
        retryable: true,
        reference_only: true,
        ...errorBlocks,
    };
}
/**
 * Thin emit wrapper for connectors adopting the detail-gap contract. `ctx` is
 * structural so both the collect context and connector-local dependency bags can
 * use it without importing a heavier runtime type. Mirrors `emitDetailCoverage`.
 */
export function emitDetailGap(ctx, params) {
    return ctx.emit(buildDetailGap(params));
}
export const nowIso = () => new Date().toISOString();
/**
 * Intentional pacing delay for anti-bot throttling between requests.
 * Distinct from Playwright's sync primitives (waitForSelector, waitForURL)
 * which wait for a page condition. This one is "slow us down so we look
 * human", not "wait until X is ready". See authoring guide §7.
 */
export const politeDelay = (ms) => new Promise((r) => setTimeout(r, ms));
// ─── Runtime entry point ────────────────────────────────────────────────
/**
 * Run a connector end-to-end. The only entry point connectors should use.
 */
export function runConnector(config) {
    if (!config.name) {
        throw new Error("runConnector: config.name required");
    }
    if (typeof config.collect !== "function") {
        throw new Error("runConnector: config.collect required");
    }
    const { name, validateRecord, collect, browser, normalizeTerminalError = (error) => error, onDurableCommit, retryablePattern = DEFAULT_RETRYABLE_PATTERN, timeRangeField = "date", isTombstone, auth, authOptional = false, } = config;
    // ensureSession/probeSession are only on BrowserConnectorConfig; extract
    // after the browser-narrowing check.
    const ensureSession = browser ? config.ensureSession : undefined;
    const probeSession = browser ? config.probeSession : undefined;
    const timeRangeFieldFor = typeof timeRangeField === "function"
        ? timeRangeField
        : () => timeRangeField;
    // Capture session: null unless PDPP_CAPTURE_FIXTURES=1.
    const capture = createCaptureSession(name);
    // stdin reader for START + INTERACTION_RESPONSE.
    const rl = createInterface({ input: process.stdin, terminal: false });
    // Wraps stdout write with backpressure. RECORD messages auto-captured.
    const emit = (msg) => {
        if (capture && msg.type === "RECORD") {
            capture.recordRecord(msg);
        }
        return emitToStdout(msg);
    };
    if (capture) {
        const modeLabel = capture.keepOnSuccess
            ? "PDPP_CAPTURE_FIXTURES=1 (always retain)"
            : "PDPP_CAPTURE_ON_FAILURE=1 (retain on failure only)";
        process.stderr.write(`[capture] ${modeLabel}; writing to ${capture.baseDir}\n`);
    }
    const flushAndExit = (code) => {
        // On a successful run, run the optional durable-commit hook after the
        // runtime acknowledges ingest (the `exit` callback fires post-ack) and
        // before the real process exit. Best-effort: a hook failure never changes
        // the already-committed run's outcome.
        if (code === 0 && onDurableCommit) {
            const logDurableCommit = (message) => {
                process.stderr.write(`[onDurableCommit] ${message}\n`);
            };
            flushAndExitAfterRuntimeAck(code, {
                exit: (finalCode) => {
                    Promise.resolve()
                        .then(() => onDurableCommit(logDurableCommit))
                        .catch(() => undefined)
                        .finally(() => {
                        process.exit(finalCode);
                    });
                },
            });
            return;
        }
        flushAndExitAfterRuntimeAck(code);
    };
    let observedCounters = null;
    let reportedStreamFailure = null;
    const emitFailed = (message, retryable = false, records_emitted = observedCounters?.totalEmitted ?? 0, code) => {
        // The runtime ACK handshake may outlive every ref'd process handle. Mark
        // the natural exit path before emitting DONE so it cannot contradict the
        // failed terminal status if Node exits before the explicit callback.
        process.exitCode = 1;
        const terminalError = composeNormalizedTerminalError({
            message,
            retryable,
            code,
            normalizeTerminalError,
        });
        // Fire-and-forget. emit() resolves after stdout drains; we're about to
        // exit(1) anyway, so we don't need to block. If it rejects (the write
        // fails), the process is dying either way.
        emit({
            type: "DONE",
            status: "failed",
            records_emitted,
            error: terminalError,
        }).catch(() => undefined);
        flushAndExit(1);
    };
    let interactionCounter = 0;
    const nextInteractionId = () => {
        interactionCounter += 1;
        return `int_${Date.now()}_${interactionCounter}`;
    };
    let detailGapPageCounter = 0;
    const nextDetailGapPageRequestId = () => {
        detailGapPageCounter += 1;
        return `dgp_${Date.now()}_${detailGapPageCounter}`;
    };
    let assistanceCounter = 0;
    const nextAssistanceId = () => {
        assistanceCounter += 1;
        return `asst_${Date.now()}_${assistanceCounter}`;
    };
    const sendInteraction = (req) => {
        const request_id = req.request_id ?? nextInteractionId();
        const wrapped = {
            type: "INTERACTION",
            request_id,
            kind: req.kind,
            message: req.message,
            ...(req.schema === undefined ? {} : { schema: req.schema }),
            ...(req.timeout_seconds === undefined
                ? {}
                : { timeout_seconds: req.timeout_seconds }),
        };
        // Fire the INTERACTION; response arrives separately on stdin.
        emit(wrapped).catch(() => undefined);
        return new Promise((resolve, reject) => {
            let settled = false;
            const cleanup = () => {
                rl.off("line", onLine);
                rl.off("close", onClose);
                process.stdin.off("end", onClose);
                process.stdin.off("error", onError);
            };
            const settle = (fn) => {
                if (settled) {
                    return;
                }
                settled = true;
                cleanup();
                fn();
            };
            const onLine = (line) => {
                try {
                    const parsed = JSON.parse(line);
                    if (parsed.type === "INTERACTION_RESPONSE" &&
                        parsed.request_id === request_id) {
                        settle(() => resolve(parsed));
                    }
                }
                catch (err) {
                    settle(() => reject(err instanceof Error ? err : new Error(String(err))));
                }
            };
            const onClose = () => {
                settle(() => reject(new Error(`Interaction ${request_id} ended before a response`)));
            };
            const onError = (err) => {
                settle(() => reject(new Error(`Interaction ${request_id} stdin error: ${err.message}`)));
            };
            rl.on("line", onLine);
            rl.once("close", onClose);
            process.stdin.once("end", onClose);
            process.stdin.once("error", onError);
        });
    };
    const readStart = () => new Promise((resolve, reject) => {
        let settled = false;
        const cleanup = () => {
            rl.off("line", onLine);
            rl.off("close", onClose);
            process.stdin.off("end", onClose);
            process.stdin.off("error", onError);
        };
        const settle = (fn) => {
            if (settled) {
                return;
            }
            settled = true;
            cleanup();
            fn();
        };
        const onLine = (line) => {
            settle(() => {
                try {
                    resolve(JSON.parse(line));
                }
                catch (err) {
                    reject(err instanceof Error ? err : new Error(String(err)));
                }
            });
        };
        const onClose = () => {
            settle(() => reject(new Error("Missing START message before stdin closed")));
        };
        const onError = (err) => {
            settle(() => reject(new Error(`Missing START message before stdin error: ${err.message}`)));
        };
        rl.once("line", onLine);
        rl.once("close", onClose);
        process.stdin.once("end", onClose);
        process.stdin.once("error", onError);
    });
    const requestDetailGapPage = (req = {}) => {
        const request_id = nextDetailGapPageRequestId();
        const streams = Array.isArray(req.streams)
            ? req.streams.filter((stream) => typeof stream === "string" && stream.length > 0)
            : undefined;
        const maxBytes = typeof req.maxBytes === "number" &&
            Number.isFinite(req.maxBytes) &&
            req.maxBytes > 0
            ? Math.floor(req.maxBytes)
            : undefined;
        emit({
            type: "DETAIL_GAPS_PAGE_REQUEST",
            reference_only: true,
            request_id,
            ...(streams && streams.length > 0 ? { streams } : {}),
            ...(maxBytes ? { max_bytes: maxBytes } : {}),
        }).catch(() => undefined);
        return new Promise((resolve, reject) => {
            const onLine = (line) => {
                try {
                    const parsed = JSON.parse(line);
                    if (parsed.type !== "DETAIL_GAPS_PAGE_RESPONSE" ||
                        parsed.request_id !== request_id) {
                        return;
                    }
                    rl.off("line", onLine);
                    if (parsed.reference_only !== true ||
                        !Array.isArray(parsed.detail_gaps)) {
                        reject(new Error("Invalid DETAIL_GAPS_PAGE_RESPONSE envelope"));
                        return;
                    }
                    resolve(parsed.detail_gaps);
                }
                catch (err) {
                    rl.off("line", onLine);
                    reject(err instanceof Error ? err : new Error(String(err)));
                }
            };
            rl.on("line", onLine);
        });
    };
    const progress = (message, extra = {}) => emit({ type: "PROGRESS", message, ...extra });
    const assist = async (req) => {
        const assistance_request_id = req.assistance_request_id ?? nextAssistanceId();
        await emit({ type: "ASSISTANCE", ...req, assistance_request_id });
        return assistance_request_id;
    };
    const completeAssistance = (assistanceRequestId, status, extra = {}) => emit({
        type: "ASSISTANCE_STATUS",
        assistance_request_id: assistanceRequestId,
        status,
        ...extra,
    });
    const reportStreamFailure = async (stream, message, options = {}) => {
        if (!stream.trim()) {
            throw new TerminalError("Stream failure report is missing a stream", {
                code: "stream_failure_invalid",
            });
        }
        const normalizedMessage = message.trim();
        if (!normalizedMessage) {
            throw new TerminalError("Stream failure report is missing a message", {
                code: "stream_failure_invalid",
            });
        }
        const retryable = options.retryable === true;
        reportedStreamFailure ??= { message: normalizedMessage, retryable, stream };
        await emit({
            type: "SKIP_RESULT",
            stream,
            reason: "stream_collection_failed",
            message: normalizedMessage,
            recovery_hint: { action: "retry_by_runtime", retryable },
        });
    };
    // Kick off the run. The outer catch distinguishes TerminalError (which
    // the runtime threw deliberately with an explicit retryable bit) from
    // unexpected throws (where we pattern-match the message).
    run().catch((err) => {
        if (err instanceof TerminalError) {
            emitFailed(err.message, err.retryable, undefined, err.code);
            return;
        }
        const message = describeUnexpectedFailure(err);
        emitFailed(message, retryablePattern.test(message));
    });
    async function run() {
        const startMsg = await parseStart(readStart);
        const requested = buildRequested(startMsg);
        const credentials = await resolveCredentials(auth, {
            authOptional,
            sendInteraction,
            connectorName: name,
        });
        // Registered before any page interaction so a capture taken mid-login can
        // redact these values wherever they surface — including a field no
        // field-name rule would recognize as secret.
        capture?.registerSecrets(Object.values(credentials));
        const emitRecord = makeEmitRecord({
            requested,
            emit,
            emittedAt: nowIso(),
            validateRecord,
            isTombstone,
            timeRangeFieldFor,
        });
        observedCounters = emitRecord.counters;
        const emittedAt = nowIso();
        const baseCtx = {
            scope: startMsg.scope,
            state: startMsg.state ?? {},
            requested,
            credentials,
            emit,
            emitRecord: emitRecord.emit,
            assist,
            completeAssistance,
            progress,
            reportStreamFailure,
            capture,
            sendInteraction,
            emittedAt,
            detailGaps: startMsg.detail_gaps ?? [],
            requestDetailGapPage,
            // §4.3: forward recovery_only from the START message so connectors can
            // suppress the forward walk while draining non-pressure detail gaps.
            recoveryOnly: startMsg.recovery_only === true,
            // Defaults to "incremental" when absent — see BaseCollectContext's doc
            // comment: an ordinary run (no collection_mode on the wire) must behave
            // exactly as before this field existed.
            collectionMode: startMsg.collection_mode === "full_refresh"
                ? "full_refresh"
                : "incremental",
        };
        if (browser) {
            await runInBrowser({
                browser,
                name,
                sendInteraction,
                assist,
                completeAssistance,
                nextAssistanceRequestId: nextAssistanceId,
                progress,
                ensureSession,
                probeSession,
                collect,
                baseCtx,
                retryablePattern,
            });
        }
        else {
            await collect(baseCtx);
        }
        if (reportedStreamFailure) {
            emitFailed(`stream collection failed: ${reportedStreamFailure.stream}: ${reportedStreamFailure.message}`, reportedStreamFailure.retryable, emitRecord.counters.totalEmitted, "stream_collection_failed");
            return;
        }
        await finalizeRun(emitRecord.counters, progress, emit);
        flushAndExit(0);
    }
}
// ─── run() helpers (top-level so each is independently readable) ───────
/**
 * Read the first line of stdin and parse it as a START message. Throws
 * TerminalError on malformed input or wrong type — the runtime can't
 * proceed without a valid START.
 */
async function parseStart(readStart) {
    const startMsg = await readStart();
    if (startMsg.type !== "START") {
        throw new TerminalError("Expected START message");
    }
    return startMsg;
}
/** Build the requested-streams map; the runtime requires at least one stream. */
function buildRequested(startMsg) {
    const requested = new Map((startMsg.scope.streams ?? []).map((s) => [s.name, s]));
    if (requested.size === 0) {
        throw new TerminalError("START.scope.streams is required");
    }
    return requested;
}
/** Resolve credentials via the configured auth strategy. */
/**
 * `<connector>_credentials_missing` — the exact message the `env` auth strategy
 * throws when a `credentials` INTERACTION is declined or times out. Matched by
 * name rather than by class because the strategy lives in
 * `@pdpp/connector-protocol` and throws a plain `Error`.
 */
function isCredentialsMissingError(connectorName, message) {
    return message === `${connectorName}_credentials_missing`;
}
/**
 * Resolve credentials via the configured auth strategy.
 *
 * When `authOptional` is set, a missing credential is a supported state rather
 * than a run-ending failure: the connector authenticates through the owner's
 * browser profile and treats a stored username/password as an optional
 * auto-login shortcut. Present credentials are used exactly as before; absent
 * ones resolve to an empty set WITHOUT ever prompting.
 *
 * Root cause history. 6f6765bbb (2026-08-26) fixed half of this: it stopped a
 * declined prompt from failing the run. But it caught the failure AFTER the
 * `env` strategy had already opened the `credentials` interaction and awaited
 * it — it suppressed the ERROR, not the PROMPT. Live prod run
 * run_1788004675387 showed the remaining half: the run leased and readied a
 * browser surface, then immediately emitted a `credentials` interaction. The
 * repair page put a username/password form in front of the owner, which is
 * unanswerable for a Google-SSO account and blocks the required journey
 * (repair page -> run -> streamed browser -> owner completes SSO there).
 * A scheduled run has nobody to answer it at all.
 *
 * The flag is now threaded into `AuthStrategyContext` so the strategy returns
 * before asking, rather than being talked out of the answer afterwards. The
 * post-hoc catch below is retained deliberately: it still covers a strategy
 * that reaches the missing-credential branch by another route, and it keeps
 * this behavior pinned if an older protocol build is ever installed.
 *
 * Narrowly scoped on purpose: only connectors that opt in are affected, and
 * only the credential question is skipped — an `assist`/`manual_action`
 * interaction from the same run still reaches the owner, which is what the
 * browser login depends on. Every OTHER auth failure
 * (`auth_env_required_missing`, `auth_strategy_unknown`, a strategy's own
 * throw) still fails the run closed, and connectors that never set
 * `authOptional` — every API connector, e.g. github/ynab/notion — keep the
 * unchanged prompt-then-fail-closed behavior rather than proceeding
 * token-less.
 */
export async function resolveCredentials(auth, ctx) {
    if (!auth) {
        return {};
    }
    try {
        return await resolveAuth(auth, ctx);
    }
    catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        if (ctx.authOptional &&
            isCredentialsMissingError(ctx.connectorName, message)) {
            return {};
        }
        throw new TerminalError(message, { cause: err });
    }
}
/** Factory: returns the emitRecord closure + a live-updating counters object. */
function makeEmitRecord(deps) {
    const { requested, emit, emittedAt, validateRecord, isTombstone, timeRangeFieldFor, } = deps;
    // `totalAnomalous` counts records RETAINED despite unmodeled values; it is a
    // subset of totalEmitted, not a sibling of totalSkipped.
    const counters = { totalEmitted: 0, totalSkipped: 0, totalAnomalous: 0 };
    const resFilters = new Map();
    for (const [streamName, scope] of requested) {
        resFilters.set(streamName, resourceSet(scope));
    }
    const emitRecord = (stream, data, options = {}) => {
        if (data.id == null) {
            return Promise.resolve();
        }
        const rs = resFilters.get(stream);
        if (!options.skipResourceFilter && rs && !rs.has(String(data.id))) {
            return Promise.resolve();
        }
        if (isTombstone?.(stream, data)) {
            counters.totalEmitted += 1;
            return emit({
                type: "RECORD",
                stream,
                key: String(data.id),
                data: { id: data.id },
                emitted_at: emittedAt,
                op: "delete",
            });
        }
        const streamScope = requested.get(stream);
        const field = timeRangeFieldFor(stream);
        if (streamScope?.time_range &&
            isOutsideTimeRange(streamScope.time_range, data[field])) {
            return Promise.resolve();
        }
        const validation = validateRecord?.(stream, data);
        if (validation && !validation.ok) {
            counters.totalSkipped += 1;
            return emit(makeShapeCheckSkip(stream, data, validation.issues));
        }
        // Present only when the record was RETAINED despite carrying a value the
        // schema does not model (see makeValidateRecord in schema-registry.ts).
        const anomalies = validation?.anomalies;
        counters.totalEmitted += 1;
        const record = {
            type: "RECORD",
            stream,
            key: String(data.id),
            data,
            emitted_at: emittedAt,
        };
        // A retained-with-drift record still emits; its diagnostic rides alongside
        // so the unmodeled value is visible rather than silently tolerated. Reported
        // BEFORE the RECORD so a truncated stream never shows the record without the
        // caveat attached to it.
        if (anomalies?.length) {
            counters.totalAnomalous += 1;
            return emit(makeShapeAnomalyReport(stream, data, anomalies)).then(() => emit(record));
        }
        return emit(record);
    };
    return { emit: emitRecord, counters };
}
/**
 * Keep the streamed-page target's lifecycle coupled to the structured
 * assistance request. This is deliberately separate from session logic: a
 * failed readiness probe must still terminally close the assistance and free
 * the target before its error reaches the run lifecycle.
 */
export function createBrowserSurfaceAssistanceLifecycle({ assist, completeAssistance, nextAssistanceRequestId, page, prepareTarget = prepareBrowserInteractionTarget, unregisterTarget = unregisterBrowserInteractionTarget, }) {
    const openAssistanceIds = new Set();
    return {
        assist: async (request) => {
            const assistanceRequestId = request.assistance_request_id ?? nextAssistanceRequestId();
            if (request.attachments?.some((attachment) => attachment.kind === "browser_surface")) {
                openAssistanceIds.add(assistanceRequestId);
                // Registration precedes ASSISTANCE so the reference server can mint a
                // stream only for this exact ready (run, assistance) target.
                await prepareTarget({
                    interactionId: assistanceRequestId,
                    page,
                    reason: "manual_action",
                });
            }
            return assist({ ...request, assistance_request_id: assistanceRequestId });
        },
        complete: async (assistanceRequestId, status, extra = {}) => {
            try {
                await completeAssistance(assistanceRequestId, status, extra);
            }
            finally {
                if (openAssistanceIds.delete(assistanceRequestId)) {
                    await unregisterTarget({ interactionId: assistanceRequestId });
                }
            }
        },
        close: async () => {
            await Promise.all([...openAssistanceIds].map((interactionId) => unregisterTarget({ interactionId })));
            openAssistanceIds.clear();
        },
    };
}
/** Run collect() inside an acquired browser context, with session + tracing. */
async function runInBrowser(args) {
    const { browser, name, sendInteraction, assist, completeAssistance, nextAssistanceRequestId, progress, ensureSession, probeSession, collect, baseCtx, retryablePattern, } = args;
    const { context: ctx, release } = await acquireBrowser(browser, name);
    const visibility = resolveBrowserRuntimeVisibility(browser, name);
    const browserSurface = resolveBrowserLaunchSource(visibility).kind;
    // Prevention layer (Layer A): register a SIGTERM/SIGINT handler that
    // awaits release() before exit. Without this, Docker stop / controller
    // restart kills this child process before the `finally` block below
    // runs, Chromium dies with its profile-lock symlink still pointing at
    // this PID, and the next launch fails the hostname check. See
    // `shutdown-hook.ts` for the design and `profile-lock.ts` for the
    // correction-layer counterpart.
    const { withShutdownRelease } = await import("./shutdown-hook.js");
    const tracer = makeTracer(ctx, name, baseCtx.capture);
    // Finalization runs before release(). On SIGTERM/SIGINT this is what
    // gives the operator a usable trace/capture artifact for the in-flight
    // run; without it, Docker stop / scheduler restart drops the trace.
    let traceFinalized = false;
    const finalizeDiagnostics = async () => {
        if (traceFinalized) {
            return;
        }
        traceFinalized = true;
        baseCtx.capture?.setTraceCheckpointHook?.(null);
        await tracer.stop();
    };
    const disposeShutdownHook = withShutdownRelease(release, {
        finalize: finalizeDiagnostics,
    });
    await tracer.start();
    baseCtx.capture?.setTraceCheckpointHook?.((label) => tracer.checkpoint(label));
    let page = null;
    let runSucceeded = false;
    let browserSurfaceAssistance = null;
    try {
        page = await selectBrowserPageForRun(ctx, browser);
        browserSurfaceAssistance = createBrowserSurfaceAssistanceLifecycle({
            assist,
            completeAssistance,
            nextAssistanceRequestId,
            page: page,
        });
        const browserAssist = browserSurfaceAssistance.assist;
        const browserCompleteAssistance = browserSurfaceAssistance.complete;
        const browserSendInteraction = makeBrowserInteractionKeepalive({
            context: ctx,
            diagnostics: process.env.PDPP_BROWSER_SURFACE_DIAGNOSTICS === "1",
            progress,
            sendInteraction: async (req) => {
                const decorated = decorateBrowserManualAction(req, visibility);
                if (decorated.kind !== "otp") {
                    return sendInteraction(decorated);
                }
                const { interactionId } = await prepareBrowserInteractionTarget({
                    page: page,
                    reason: "2fa",
                    ...(decorated.request_id
                        ? { interactionId: decorated.request_id }
                        : {}),
                });
                return sendInteraction({ ...decorated, request_id: interactionId });
            },
        });
        await captureBrowserPage(baseCtx.capture, page, "runtime-run-page");
        await closeBrowserContextPagesExcept(ctx, page);
        // Session establishment is the window the watchdog guards. A wedged
        // renderer can hang a connector's ensureSession indefinitely with no
        // INTERACTION ever emitted, so the controller's mid-wait detector cannot
        // help. The watchdog keys on checkpoint progress (paused while an
        // interaction is open) and fails closed if establishment stalls.
        const watchdog = makeSessionEstablishWatchdog({
            capture: baseCtx.capture,
            name,
            page,
            // Checkpoints already name every sign-in phase, but they only ever wrote
            // to `capture` — which is opt-in and was OFF in production, so a failed
            // browser sign-in left ONE progress event for the whole run and the
            // timeline could not say which phase it died in. Threading `progress`
            // here puts the phase names on the durable timeline regardless of
            // whether capture is enabled.
            progress,
        });
        await watchdog.run(() => establishSession({ ensureSession, probeSession }, {
            assist: watchdog.wrapAssist(browserAssist),
            capture: baseCtx.capture,
            checkpoint: watchdog.checkpoint,
            completeAssistance: watchdog.wrapCompleteAssistance(browserCompleteAssistance),
            context: ctx,
            credentials: baseCtx.credentials,
            page: page,
            name,
            progress,
            retryablePattern,
            sendInteraction: watchdog.wrapSendInteraction(browserSendInteraction),
        }));
        await captureBrowserPage(baseCtx.capture, page, "runtime-session-established");
        await captureBrowserPage(baseCtx.capture, page, "runtime-collect-start");
        await collect({
            ...baseCtx,
            browserSurface,
            context: ctx,
            page,
            sendInteraction: browserSendInteraction,
        });
        await captureBrowserPage(baseCtx.capture, page, "runtime-collect-complete");
        // Mark success before the finally so tracer.stop() deletes chunks on a
        // clean run, and capture.finalize() can scrub the raw dir in
        // PDPP_CAPTURE_ON_FAILURE mode. Anything thrown after this point (only
        // release/page-close) is treated as benign teardown.
        tracer.markSucceeded();
        baseCtx.capture?.markSucceeded?.();
        runSucceeded = true;
    }
    catch (err) {
        if (page) {
            await captureBrowserPage(baseCtx.capture, page, "runtime-error");
        }
        throw err;
    }
    finally {
        await finalizeDiagnostics();
        await browserSurfaceAssistance?.close();
        if (shouldCloseBrowserPageAfterRun(browser, runSucceeded)) {
            await closeBrowserPage(page);
        }
        await release().catch(() => undefined);
        disposeShutdownHook();
        baseCtx.capture?.finalize?.();
    }
}
// A wedged renderer can hang the CDP-backed reads inside captureDom
// (`page.content()`, `page.title()`, `page.ariaSnapshot()`) with no per-call
// timeout. Bound the whole capture so a diagnostic snapshot during teardown of
// a wedged run cannot itself re-hang the teardown.
const CAPTURE_DOM_DEADLINE_MS = 10_000;
const PAGE_CLOSE_DEADLINE_MS = 10_000;
export function isReusableBrowserRunPage(page) {
    if (page.isClosed()) {
        return false;
    }
    const url = page.url();
    return Boolean(url) && url !== "about:blank" && !url.startsWith("data:");
}
export async function selectBrowserPageForRun(context, browser) {
    if (browser.preservePageOnSuccess || browser.preservePageOnFailure) {
        for (const page of context.pages()) {
            if (isReusableBrowserRunPage(page)) {
                return page;
            }
        }
    }
    return await context.newPage();
}
/**
 * Mirrors `browser-launch.ts`'s `HAR_RECORD_PATH_ENV`/
 * `STORAGE_STATE_RECORD_PATH_ENV` string values as literals rather than a
 * static import — this module dynamically `import()`s `browser-launch.ts`
 * only inside `acquireBrowser` specifically so a fetch-only connector never
 * pays for pulling in `patchright`/`playwright` at load time (see that
 * call site). Same string-literal-mirror precedent as
 * `publishCdpEndpointToEnv`'s doc comment in browser-launch.ts (mirrored in
 * the other direction here). Kept in sync by hand; a mismatch here would
 * only make `browserRecordingRequested` under-detect (never over-detect),
 * since a wrong name simply reads `undefined` from `process.env`.
 */
const HAR_RECORD_PATH_ENV_MIRROR = "PDPP_SCENARIO_HAR_RECORD_PATH";
const STORAGE_STATE_RECORD_PATH_ENV_MIRROR = "PDPP_SCENARIO_STORAGE_STATE_RECORD_PATH";
/**
 * True when `bin/scenario-record.ts --record-har` requested HAR and/or
 * storageState capture for this run — the same env-var presence check
 * `acquireBrowserForConnector` uses to decide whether to pass `recordHar`/
 * a storageState snapshot to Playwright at all.
 *
 * BUG THIS GUARDS AGAINST (found live against a real reddit `--record-har`
 * run: HAR flushed with entries, storageState never did): Patchright's
 * `launchPersistentContext` ties the whole context's CDP transport to its
 * pages — closing the connector's LAST open page tears the context down
 * enough that a subsequent `context.storageState()` throws "Target page,
 * context or browser has been closed", even though `context.close()`
 * itself hasn't run yet. `runInBrowser`'s teardown was closing the page
 * BEFORE calling `release()` (whose `storageState()` read happens just
 * before `context.close()`), so a recording run always lost storageState
 * silently — `writeStorageStateBestEffort` swallows the error and only
 * logs to the subprocess's own stderr, which `bin/scenario-record.ts`
 * discards on a successful run. HAR still flushed because network-event
 * buffering is independent of page lifecycle, which is why the two
 * artifacts diverged instead of failing together.
 */
function browserRecordingRequested(env = process.env) {
    return Boolean(env[HAR_RECORD_PATH_ENV_MIRROR]?.trim() ||
        env[STORAGE_STATE_RECORD_PATH_ENV_MIRROR]?.trim());
}
export function shouldCloseBrowserPageAfterRun(browser, runSucceeded, env = process.env) {
    // A `--record-har` run needs the context's last page to stay open until
    // `release()` reads `storageState()` — see `browserRecordingRequested`'s
    // doc comment. `release()`'s own `context.close()` closes the page right
    // afterward, so skipping this pre-release close costs nothing on a
    // recording run; it is a no-op change in shape (close happens a moment
    // later, inside `release()`, instead of here).
    if (browserRecordingRequested(env)) {
        return false;
    }
    if (runSucceeded && browser.preservePageOnSuccess) {
        return false;
    }
    if (!runSucceeded && browser.preservePageOnFailure) {
        return false;
    }
    return true;
}
export async function captureBrowserPage(capture, page, label, deadlineMs = CAPTURE_DOM_DEADLINE_MS) {
    if (!capture) {
        return;
    }
    // After a CDP transport drop / remote target loss the page may already
    // be closed by the time we try to capture (`runtime-error` is the
    // common case). Skipping cleanly here keeps a bounded diagnostic line
    // out of Playwright's noisy "Target page, context or browser has been
    // closed" exception path.
    if (page.isClosed()) {
        process.stderr.write(`[capture] page already closed at ${label}; skipping dom snapshot\n`);
        return;
    }
    // captureDom is best-effort by construction (each internal step swallows its
    // own errors to stderr), so it never rejects; on timeout the detached promise
    // simply keeps running harmlessly while teardown proceeds.
    const captureWork = capture.captureDom(page, label);
    captureWork.catch(() => undefined);
    await withDeadline(captureWork, deadlineMs, () => {
        process.stderr.write(`[capture] dom snapshot for ${label} exceeded ${String(deadlineMs)}ms (wedged renderer?); abandoning this capture.\n`);
    });
}
export async function closeBrowserContextPagesExcept(context, keepPage, deadlineMs = PAGE_CLOSE_DEADLINE_MS) {
    let pages;
    try {
        pages = context.pages();
    }
    catch {
        return 0;
    }
    let closed = 0;
    for (const page of pages) {
        if (page === keepPage || page.isClosed()) {
            continue;
        }
        if (await closeBrowserPage(page, deadlineMs)) {
            closed += 1;
        }
    }
    return closed;
}
export async function closeBrowserPage(page, deadlineMs = PAGE_CLOSE_DEADLINE_MS) {
    if (!page || page.isClosed()) {
        return false;
    }
    try {
        const closeWork = page.close();
        closeWork.catch(() => undefined);
        const result = await withDeadline(closeWork, deadlineMs, () => {
            process.stderr.write(`[browser-runtime] page.close() exceeded ${String(deadlineMs)}ms (wedged renderer?); abandoning close.\n`);
        });
        return result !== DEADLINE_TIMEOUT;
    }
    catch {
        // Remote-CDP targets can disappear underneath us during banking OTP/manual
        // waits. Cleanup must never mask the connector's real terminal reason.
        return false;
    }
}
const BROWSER_INTERACTION_KEEPALIVE_INTERVAL_MS = 15_000;
export function makeBrowserInteractionKeepalive(args) {
    const { context, diagnostics = false, intervalMs = BROWSER_INTERACTION_KEEPALIVE_INTERVAL_MS, progress, sendInteraction, } = args;
    return async (req) => {
        await emitBrowserSurfaceDiagnostic({
            context,
            diagnostics,
            phase: "interaction_start",
            progress,
            req,
        });
        const keepalive = startBrowserConnectionKeepalive(context, intervalMs);
        try {
            const response = await sendInteraction(req);
            await emitBrowserSurfaceDiagnostic({
                context,
                diagnostics,
                keepalive: keepalive.stop(),
                phase: "interaction_response",
                progress,
                req,
                responseStatus: response.status,
            });
            return response;
        }
        catch (err) {
            await emitBrowserSurfaceDiagnostic({
                context,
                diagnostics,
                error: err,
                keepalive: keepalive.stop(),
                phase: "interaction_error",
                progress,
                req,
            });
            throw err;
        }
    };
}
async function emitBrowserSurfaceDiagnostic(args) {
    const { context, diagnostics, error, keepalive, phase, progress, req, responseStatus, } = args;
    if (!(diagnostics && progress)) {
        return;
    }
    let errorMessage = null;
    if (error instanceof Error) {
        errorMessage = error.message;
    }
    else if (error != null) {
        errorMessage = String(error);
    }
    const payload = {
        phase,
        interaction_kind: req.kind,
        request_id: req.request_id ?? null,
        response_status: responseStatus ?? null,
        surface: describeBrowserSurface(context),
        keepalive: keepalive ?? null,
        error: errorMessage,
    };
    try {
        await progress(`browser_surface.diagnostic ${JSON.stringify(payload)}`);
    }
    catch (progressError) {
        const message = progressError instanceof Error
            ? progressError.message
            : String(progressError);
        process.stderr.write(`[browser-surface-diagnostics] progress emit failed: ${message}\n`);
    }
}
function describeBrowserSurface(context) {
    const browser = context.browser();
    let pages = [];
    try {
        pages = typeof context.pages === "function" ? context.pages() : [];
    }
    catch {
        pages = [];
    }
    return {
        browser_connected: Boolean(browser?.isConnected()),
        page_count: typeof context.pages === "function" ? pages.length : null,
        pages: pages.slice(0, 5).map((page) => ({
            closed: page.isClosed(),
            url: sanitizeDiagnosticUrl(page),
        })),
    };
}
function sanitizeDiagnosticUrl(page) {
    if (page.isClosed()) {
        return null;
    }
    try {
        const rawUrl = page.url();
        if (!rawUrl || rawUrl === "about:blank") {
            return rawUrl || null;
        }
        const url = new URL(rawUrl);
        return `${url.origin}${url.pathname}`;
    }
    catch {
        return "unparseable";
    }
}
function normalizeDiagnosticError(error) {
    const raw = error instanceof Error ? error.message : String(error);
    return raw.slice(0, 300);
}
function summarizeInactiveKeepalive(browser, startedAt) {
    return {
        browserConnectedAtStart: Boolean(browser?.isConnected()),
        browserConnectedAtStop: Boolean(browser?.isConnected()),
        elapsedMs: Date.now() - startedAt,
        disconnectEventCount: 0,
        pingAttempts: 0,
        pingFailures: 0,
        pingInFlight: false,
        pingSuccesses: 0,
        skippedDisconnected: 0,
    };
}
function startBrowserConnectionKeepalive(context, intervalMs) {
    const startedAt = Date.now();
    const browser = context.browser();
    if (intervalMs <= 0 || !browser?.isConnected()) {
        return { stop: () => summarizeInactiveKeepalive(browser, startedAt) };
    }
    let sessionPromise = null;
    let pingInFlight = false;
    let pingAttempts = 0;
    let pingFailures = 0;
    let pingSuccesses = 0;
    let skippedDisconnected = 0;
    let stopped = false;
    let lastError;
    let lastSuccessfulPingElapsedMs;
    let firstObservedDisconnectedElapsedMs;
    let disconnectEventElapsedMs;
    let disconnectEventCount = 0;
    const browserConnectedAtStart = browser.isConnected();
    const removeDisconnectedListener = attachBrowserDisconnectedDiagnostic(browser, () => {
        disconnectEventCount += 1;
        const elapsedMs = Date.now() - startedAt;
        disconnectEventElapsedMs ??= elapsedMs;
        firstObservedDisconnectedElapsedMs ??= elapsedMs;
        process.stderr.write(`[browser-keepalive] browser disconnected during interaction after ${elapsedMs}ms\n`);
    });
    const sessionFor = (connectedBrowser) => {
        sessionPromise ??= connectedBrowser.newBrowserCDPSession();
        return sessionPromise;
    };
    const ping = async () => {
        if (stopped || pingInFlight) {
            return;
        }
        if (!browser.isConnected()) {
            firstObservedDisconnectedElapsedMs ??= Date.now() - startedAt;
            skippedDisconnected += 1;
            return;
        }
        pingInFlight = true;
        pingAttempts += 1;
        try {
            const session = await sessionFor(browser);
            await session.send("Browser.getVersion");
            pingSuccesses += 1;
            lastSuccessfulPingElapsedMs = Date.now() - startedAt;
        }
        catch (err) {
            sessionPromise = null;
            pingFailures += 1;
            lastError = normalizeDiagnosticError(err);
            process.stderr.write(`[browser-keepalive] Browser.getVersion failed: ${lastError}\n`);
        }
        finally {
            pingInFlight = false;
        }
    };
    const timer = setInterval(ping, intervalMs);
    timer.unref?.();
    ping().catch(() => undefined);
    return {
        stop: () => {
            stopped = true;
            clearInterval(timer);
            removeDisconnectedListener();
            sessionPromise
                ?.then((session) => session.detach())
                .catch(() => undefined);
            return {
                browserConnectedAtStart,
                browserConnectedAtStop: browser.isConnected(),
                disconnectEventCount,
                ...(disconnectEventElapsedMs === undefined
                    ? {}
                    : { disconnectEventElapsedMs }),
                elapsedMs: Date.now() - startedAt,
                ...(firstObservedDisconnectedElapsedMs === undefined
                    ? {}
                    : { firstObservedDisconnectedElapsedMs }),
                ...(lastSuccessfulPingElapsedMs === undefined
                    ? {}
                    : { lastSuccessfulPingElapsedMs }),
                pingAttempts,
                pingFailures,
                pingInFlight,
                pingSuccesses,
                skippedDisconnected,
                ...(lastError ? { lastError } : {}),
            };
        },
    };
}
function attachBrowserDisconnectedDiagnostic(browser, onDisconnected) {
    const eventTarget = browser;
    if (typeof eventTarget.on !== "function") {
        return () => undefined;
    }
    eventTarget.on("disconnected", onDisconnected);
    return () => {
        if (typeof eventTarget.off === "function") {
            eventTarget.off("disconnected", onDisconnected);
        }
    };
}
/** Emit the final PROGRESS summary (if any skips) and the succeeded DONE. */
async function finalizeRun(counters, progress, emit) {
    if (counters.totalSkipped > 0) {
        await progress(`shape-check skipped ${String(counters.totalSkipped)} record(s); see SKIP_RESULT events above`);
    }
    // Retained-with-drift records are emitted, so they are absent from the skip
    // line above; surfacing the count keeps schema drift from going unnoticed
    // simply because nothing was lost to it.
    if (counters.totalAnomalous) {
        await progress(`shape-check retained ${String(counters.totalAnomalous)} record(s) carrying unmodeled values; see SKIP_RESULT events above`);
    }
    await emit({
        type: "DONE",
        status: "succeeded",
        records_emitted: counters.totalEmitted,
    });
}
const MANUAL_ACTION_RECOVERY_RE = /\bheadless\b|local collector|rerun .*headed|PDPP_BROWSER_HEADLESS/iu;
export function resolveBrowserRuntimeVisibility(browser, name, env = process.env) {
    const baseProfileName = browser.profileName ?? name;
    const connectorInstanceId = env.PDPP_CONNECTOR_INSTANCE_ID?.trim();
    const profileName = connectorInstanceId
        ? `${baseProfileName}__${connectorInstanceId}`
        : baseProfileName;
    return {
        envKey: BROWSER_HEADLESS_ENV,
        headless: env[BROWSER_HEADLESS_ENV]?.trim() === "1",
        profileName,
    };
}
export function resolveBrowserLaunchSource(visibility, env = process.env) {
    const managedRequired = env.PDPP_BROWSER_SURFACE_REQUIRED?.trim().toLowerCase() === "neko";
    const managedRemoteCdpUrl = env.PDPP_BROWSER_SURFACE_REMOTE_CDP_URL?.trim();
    if (managedRequired) {
        if (!managedRemoteCdpUrl) {
            throw new TerminalError("browser surface required: PDPP_BROWSER_SURFACE_REQUIRED=neko but PDPP_BROWSER_SURFACE_REMOTE_CDP_URL is missing");
        }
        return {
            kind: "managed_neko",
            remoteCdpUrl: managedRemoteCdpUrl,
            ...(env.PDPP_BROWSER_SURFACE_LEASE_ID?.trim()
                ? { leaseId: env.PDPP_BROWSER_SURFACE_LEASE_ID.trim() }
                : {}),
            ...(env.PDPP_BROWSER_SURFACE_PROFILE_KEY?.trim()
                ? { profileKey: env.PDPP_BROWSER_SURFACE_PROFILE_KEY.trim() }
                : {}),
        };
    }
    const legacyRemoteCdpEnvKey = `PDPP_${visibility.profileName.toUpperCase()}_REMOTE_CDP_URL`;
    const legacyRemoteCdpUrl = env[legacyRemoteCdpEnvKey]?.trim();
    if (legacyRemoteCdpUrl) {
        return {
            envKey: legacyRemoteCdpEnvKey,
            kind: "legacy_remote_cdp",
            remoteCdpUrl: legacyRemoteCdpUrl,
        };
    }
    return { kind: "isolated_local" };
}
export function decorateBrowserManualAction(req, visibility) {
    if (req.kind !== "manual_action") {
        return req;
    }
    if (!visibility.headless) {
        return req;
    }
    if (MANUAL_ACTION_RECOVERY_RE.test(req.message)) {
        return req;
    }
    return {
        ...req,
        message: `${req.message}\n\n` +
            "Open the streaming companion to drive the connector's browser from your phone or laptop. " +
            `Or rerun with ${visibility.envKey}=0 (or unset it) on a browser-capable deployment to use headed Chromium instead.`,
    };
}
/**
 * Acquire a browser context for the connector via the native isolated
 * launcher. Throws TerminalError on failure; preserves
 * HeadedBrowserUnavailableError's stable code in the message so
 * downstream logs/dashboards can pattern-match.
 *
 * If a streaming-target registration credential is available in env
 * (PDPP_RUN_ID + PDPP_REFERENCE_BASE_URL + either
 * PDPP_STREAMING_REGISTRATION_TOKEN (Mode A, in-process runtime) or
 * PDPP_LOCAL_DEVICE_TOKEN (Mode B, collector-runner — all three required),
 * the launcher exposes a loopback CDP endpoint. The browser handoff seam
 * registers the exact page target when a browser interaction is emitted;
 * launch alone never creates a run-wide or placeholder target.
 */
async function acquireBrowser(browser, name) {
    const { acquireBrowserForConnector, CdpAttachSessionRaceExhaustedError, HeadedBrowserUnavailableError, } = await import("./browser-launch.js");
    const visibility = resolveBrowserRuntimeVisibility(browser, name);
    const { headless, profileName } = visibility;
    // Streaming env vars are present iff the controller wired up Mode-A
    // streaming for this run. Their presence is the signal to launch
    // Chromium in CDP-port mode (so the handoff helper can compose
    // wsUrls). Actual per-interaction registration happens in the binding
    // path via `manualAction(...)`, not at launch — so we don't need the
    // full registration client here, just the env presence check.
    const streamingEnabled = Boolean(process.env.PDPP_RUN_ID?.trim()) &&
        Boolean(process.env.PDPP_REFERENCE_BASE_URL?.trim()) &&
        Boolean(process.env.PDPP_STREAMING_REGISTRATION_TOKEN?.trim() ||
            process.env.PDPP_LOCAL_DEVICE_TOKEN?.trim());
    const launchSource = resolveBrowserLaunchSource(visibility);
    const remoteCdpUrl = launchSource.kind === "managed_neko" ||
        launchSource.kind === "legacy_remote_cdp"
        ? launchSource.remoteCdpUrl
        : undefined;
    try {
        return await acquireBrowserForConnector({
            profileName,
            headless,
            ...(browser.preservePageOnSuccess || browser.preservePageOnFailure
                ? { preserveRemotePagesOnAcquire: true }
                : {}),
            ...(streamingEnabled ? { streamingEnabled: true } : {}),
            ...(remoteCdpUrl ? { remoteCdpUrl } : {}),
        });
    }
    catch (err) {
        if (err instanceof HeadedBrowserUnavailableError) {
            // Surface the stable code in the terminal-error message so the
            // controller's run-failed copy can render the deployment-config
            // error state rather than a generic browser failure.
            throw new TerminalError(`[${err.code}] ${err.message}`, {
                code: err.code,
                cause: err,
            });
        }
        if (err instanceof CdpAttachSessionRaceExhaustedError) {
            // The narrow attach-session race (see browser-launch.ts) exhausted its
            // bounded retry budget. Carry the stable code so the reference
            // runtime's managed-surface lifecycle can decide the leased dynamic
            // surface itself needs recycling, without re-parsing this message.
            throw new TerminalError(`could not open browser profile: ${err.message}`, {
                retryable: true,
                code: err.code,
                cause: err,
            });
        }
        const message = err instanceof Error ? err.message : String(err);
        throw new TerminalError(`could not open browser profile: ${message}`, {
            cause: err,
        });
    }
}
// ─── Session-establishment watchdog ─────────────────────────────────────
//
// Guards the window between the browser page being created and the connector
// returning from session establishment. A wedged renderer can hang a
// connector's ensureSession indefinitely with no INTERACTION ever emitted, so
// the controller-side mid-wait surface-loss detector (which only arms once an
// interaction is open) cannot help. The watchdog keys on *checkpoint progress*
// rather than wall-clock so a legitimately slow-but-progressing auth flow is
// never killed; a stall (no checkpoint for longer than the deadline, with no
// interaction open) fails the run closed so it cannot sit active indefinitely.
const DEFAULT_SESSION_ESTABLISH_WATCHDOG_MS = 120_000;
const SESSION_ESTABLISH_WATCHDOG_ENV = "PDPP_SESSION_ESTABLISH_WATCHDOG_MS";
export function resolveSessionEstablishWatchdogMs(env = process.env) {
    const raw = env[SESSION_ESTABLISH_WATCHDOG_ENV]?.trim();
    if (!raw) {
        return DEFAULT_SESSION_ESTABLISH_WATCHDOG_MS;
    }
    const parsed = Number.parseInt(raw, 10);
    if (!(Number.isFinite(parsed) && parsed > 0)) {
        return DEFAULT_SESSION_ESTABLISH_WATCHDOG_MS;
    }
    return parsed;
}
/**
 * Build a session-establishment watchdog. Exposed (with injectable `deadlineMs`,
 * `now`, `pollIntervalMs`, and `onTrip`) so tests can drive it deterministically
 * without real-time sleeps.
 */
export function makeSessionEstablishWatchdog(args) {
    const now = args.now ?? Date.now;
    const deadlineMs = args.deadlineMs ?? resolveSessionEstablishWatchdogMs();
    // Poll often enough to trip near the deadline without busy-waiting; never
    // longer than the deadline itself so a small test deadline still trips.
    const pollIntervalMs = args.pollIntervalMs ??
        Math.max(1, Math.min(1000, Math.floor(deadlineMs / 4)));
    let lastProgressAt = now();
    let lastLabel = null;
    const openAssistance = new Map();
    let openInteractions = 0;
    let tripped = false;
    const markProgress = (label) => {
        lastProgressAt = now();
        if (label !== null) {
            lastLabel = label;
        }
    };
    const checkpoint = async (label) => {
        markProgress(label);
        // Durable phase trace. Best-effort and never fails the run, matching the
        // capture call below.
        try {
            await args.progress?.(`session-establish phase: ${label}`);
        }
        catch {
            // A progress emit must never fail session establishment.
        }
        // Best-effort durable diagnostic so a hang no longer leaves only the
        // initial blank-page artifact. captureBrowserPage already guards a closed
        // page; the bounded-title fix keeps the underlying metadata read from
        // hanging. A failed capture never fails the run.
        try {
            await captureBrowserPage(args.capture, args.page, `session-establish-${label}`);
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            process.stderr.write(`[session-watchdog] checkpoint capture failed for ${label}: ${message}\n`);
        }
    };
    // A no-response assistance is owned by the connector: the runtime keeps
    // working or watching for readiness while the owner acts elsewhere or on a
    // browser surface. It must pause the establishment watchdog regardless of
    // posture, otherwise a blocked streamed login is killed at the ordinary
    // no-progress deadline before its declared handoff timeout can elapse.
    const assistancePausesWatchdog = (req) => req.response_contract === "none";
    const pruneExpiredAssistance = () => {
        const current = now();
        let pruned = false;
        for (const [id, expiresAt] of openAssistance) {
            if (expiresAt > current) {
                continue;
            }
            openAssistance.delete(id);
            pruned = true;
        }
        if (pruned) {
            // Give post-timeout fallback logic a fresh watchdog window.
            markProgress(null);
        }
    };
    const wrapAssist = (assist) => async (req) => {
        markProgress(null);
        const assistanceRequestId = await assist(req);
        if (assistancePausesWatchdog(req)) {
            const timeoutMs = typeof req.timeout_seconds === "number" &&
                Number.isFinite(req.timeout_seconds) &&
                req.timeout_seconds > 0
                ? req.timeout_seconds * 1000
                : deadlineMs;
            openAssistance.set(assistanceRequestId, now() + timeoutMs + deadlineMs);
            markProgress(null);
        }
        return assistanceRequestId;
    };
    const wrapCompleteAssistance = (completeAssistance) => async (assistanceRequestId, status, extra = {}) => {
        try {
            await completeAssistance(assistanceRequestId, status, extra);
        }
        finally {
            if (openAssistance.delete(assistanceRequestId)) {
                markProgress(null);
            }
        }
    };
    const wrapSendInteraction = (send) => async (req) => {
        // An open interaction means the run is legitimately waiting on the owner;
        // pause the watchdog so a long CAPTCHA/OTP wait is not killed. Reset the
        // deadline on resolve so post-interaction work gets a fresh window.
        openInteractions += 1;
        markProgress(null);
        try {
            return await send(req);
        }
        finally {
            openInteractions -= 1;
            markProgress(null);
        }
    };
    const run = async (work) => {
        let timer;
        let tripInfo = null;
        // The trip path *resolves* (rather than rejects) a sentinel and the caller
        // throws afterward. Rejecting from inside the interval callback opens a
        // one-microtask window where the rejection has no attached handler yet,
        // which Node surfaces as PromiseRejectionHandledWarning / an unhandled
        // rejection. Resolving avoids that window entirely; the TerminalError is
        // constructed and thrown synchronously in `run` once the race settles.
        const TRIP = Symbol("session-establish-trip");
        const tripPromise = new Promise((resolve) => {
            const onTick = () => {
                pruneExpiredAssistance();
                if (tripped || openInteractions > 0 || openAssistance.size > 0) {
                    return;
                }
                const sinceMs = now() - lastProgressAt;
                if (sinceMs <= deadlineMs) {
                    return;
                }
                tripped = true;
                if (timer) {
                    clearInterval(timer);
                }
                tripInfo = { lastLabel, sinceMs };
                args.onTrip?.(tripInfo);
                resolve(TRIP);
            };
            timer = setInterval(onTick, pollIntervalMs);
        });
        const workPromise = work();
        // If the watchdog wins the race, `workPromise` may still settle later
        // (e.g. the wedged call finally rejects). Attach a no-op catch so that
        // late rejection cannot surface as an unhandled rejection after we have
        // already failed the run closed.
        workPromise.catch(() => undefined);
        try {
            const outcome = await Promise.race([workPromise, tripPromise]);
            if (outcome === TRIP) {
                const info = tripInfo;
                const sinceMs = info?.sinceMs ?? deadlineMs;
                const lastCheckpoint = info?.lastLabel ?? "<none>";
                throw new TerminalError(`${args.name}_session_establish_timeout: no session-establishment progress for ${String(sinceMs)}ms ` +
                    `(last checkpoint: ${lastCheckpoint}); failing run closed`, { retryable: true });
            }
        }
        finally {
            if (timer) {
                clearInterval(timer);
            }
        }
    };
    return {
        checkpoint,
        wrapAssist,
        wrapCompleteAssistance,
        wrapSendInteraction,
        run,
    };
}
/**
 * Best-effort check that the underlying browser is still connected.
 * Patchright exposes `context.browser()?.isConnected()`; we tolerate any
 * shape by treating an unknown answer as "connected" so this guard never
 * silently disables a working trace stop.
 */
export function isContextDisconnected(context) {
    try {
        const browser = context.browser?.();
        if (!browser) {
            return false;
        }
        if (typeof browser.isConnected === "function") {
            return browser.isConnected() === false;
        }
    }
    catch {
        // If the bridge itself throws, treat that as a disconnect signal.
        return true;
    }
    return false;
}
/**
 * Start/stop Playwright tracing. With raw fixture capture active, traces are
 * flushed as chunks at every fixture checkpoint so a later browser/context
 * closure does not destroy the entire diagnostic artifact.
 *
 * Storage note: traces with screenshots+snapshots+sources can be 20–100 MB per
 * run. To keep the on-disk footprint bounded, written trace chunks are deleted
 * after a clean run (markSucceeded() called before stop()) and retained on
 * failure for post-mortem debugging.
 *
 * CREDENTIAL SAFETY — why a trace is DISCARDED once secrets are registered.
 *
 * A real owner password was recovered from 8 of 14 trace zips in one Venmo
 * run. The bytes sat in the `trace.trace` entry, and because a trace is a ZIP,
 * a plain `grep` over the file found nothing — the leak was invisible to the
 * obvious check.
 *
 * The value does NOT arrive via DOM snapshots. Playwright's action recorder
 * writes each call's PARAMETERS, so `page.fill(selector, password)` is logged
 * as `{"method":"fill","params":{"value":"<password>"}}` plus an echoing
 * `{"type":"log","message":"fill(\"<password>\")"}`. Measured against
 * Playwright 1.62.1: with `snapshots:false, screenshots:false, sources:false`
 * the password still appeared 4 times in `trace.trace`.
 *
 * That rules out the two tempting fixes:
 *   - Tracing options cannot help. `screenshots`/`snapshots`/`sources` are the
 *     only knobs `tracing.start()` has, and none governs action parameters.
 *   - Rewriting the zip afterwards would still write the credential to disk
 *     first, and chunks land at EVERY checkpoint, so the plaintext would sit
 *     in the capture directory for the whole run before any cleanup ran.
 *
 * So a run that touched a credential does not get to keep a trace. Traces are
 * still recorded (an in-flight trace is what makes chunking possible) and are
 * still fully retained for runs that never register a secret — which is every
 * API-only connector and every browser run that reuses a stored session.
 */
export function makeTracer(context, name, capture) {
    const enabled = process.env.PDPP_TRACE === "1" || capture !== null;
    const traceName = `${name}-${new Date().toISOString().replace(TRACE_TIMESTAMP_UNSAFE, "-")}`;
    const tracePath = capture
        ? join(capture.baseDir, "traces", `${traceName}.zip`)
        : `/tmp/${traceName}.zip`;
    const traceBaseDir = capture ? join(capture.baseDir, "traces") : null;
    const tracing = context.tracing;
    let started = false;
    let chunkStarted = false;
    let chunkSeq = 0;
    let succeeded = false;
    const writtenTraceFiles = [];
    const safeChunkLabel = (label) => String(label)
        .replace(/[^A-Za-z0-9_.-]/g, "_")
        .slice(0, 80);
    const writeTraceDiagnostic = (phase, err) => {
        const message = err instanceof Error ? err.message : String(err);
        process.stderr.write(`[trace] ${phase} failed: ${message}\n`);
        if (!traceBaseDir) {
            return;
        }
        try {
            writeFileSync(join(traceBaseDir, `${traceName}-${String(chunkSeq).padStart(3, "0")}-${safeChunkLabel(phase)}.error.json`), JSON.stringify({
                captured_at: new Date().toISOString(),
                error: message,
                phase,
            }, null, 2));
        }
        catch {
            // Diagnostics must never affect the connector outcome.
        }
    };
    const startChunk = async (label) => {
        if (!traceBaseDir || typeof tracing.startChunk !== "function") {
            return;
        }
        try {
            await tracing.startChunk({ title: `${traceName}:${label}` });
            chunkStarted = true;
        }
        catch (err) {
            chunkStarted = false;
            writeTraceDiagnostic("start-chunk", err);
        }
    };
    const stopChunk = async (label) => {
        if (!(traceBaseDir && chunkStarted) ||
            typeof tracing.stopChunk !== "function") {
            return;
        }
        chunkSeq += 1;
        const path = join(traceBaseDir, `${traceName}-${String(chunkSeq).padStart(3, "0")}-${safeChunkLabel(label)}.zip`);
        try {
            await tracing.stopChunk({ path });
            writtenTraceFiles.push(path);
        }
        catch (err) {
            writeTraceDiagnostic(`stop-chunk-${safeChunkLabel(label)}`, err);
        }
        finally {
            chunkStarted = false;
        }
    };
    const deleteWrittenTraces = () => {
        for (const path of writtenTraceFiles) {
            try {
                rmSync(path, { force: true });
            }
            catch (err) {
                writeTraceDiagnostic("delete-on-success", err);
            }
        }
        writtenTraceFiles.length = 0;
    };
    /**
     * True when this run has handled a credential, which makes every trace
     * artifact it produced unsafe to keep. Asked at stop() time rather than
     * cached, because credentials resolve after the tracer is constructed.
     */
    const credentialsInPlay = () => capture?.hasRegisteredSecrets?.() === true;
    /**
     * Delete every trace this run wrote and record why, so the absence of a
     * trace is self-explaining to whoever goes looking for one.
     */
    const discardTracesForCredentialSafety = () => {
        const count = writtenTraceFiles.length;
        deleteWrittenTraces();
        try {
            rmSync(tracePath, { force: true });
        }
        catch {
            // Best-effort: the single-trace path may never have written this file.
        }
        process.stderr.write(`[trace] run handled credentials; ${count} trace chunk(s) discarded — Playwright records fill() values into trace.trace and no tracing option suppresses them\n`);
        if (!traceBaseDir) {
            return;
        }
        try {
            writeFileSync(join(traceBaseDir, `${traceName}.suppressed.json`), JSON.stringify({
                captured_at: new Date().toISOString(),
                discarded_chunks: count,
                reason: "credentials_registered",
                detail: "Playwright's action recorder writes fill() parameters into the trace.trace entry, so a trace taken after a credential is typed contains it verbatim. No tracing option removes it, so the trace is not persisted.",
            }, null, 2));
        }
        catch {
            // Diagnostics must never affect the connector outcome.
        }
    };
    return {
        async start() {
            if (!enabled) {
                return;
            }
            try {
                // Max-fidelity flags: screenshots+snapshots+sources. Expect ~20–100 MB
                // per run; retain-on-failure (see stop()) keeps the disk cost bounded.
                await context.tracing.start({
                    name: traceName,
                    screenshots: true,
                    snapshots: true,
                    sources: true,
                });
                started = true;
            }
            catch (err) {
                writeTraceDiagnostic("start", err);
                return;
            }
            await startChunk("start");
            process.stderr.write(`[trace] tracing enabled; ${traceBaseDir ? `writing chunks under ${traceBaseDir}` : `will write ${tracePath} on exit`}\n`);
        },
        async checkpoint(label) {
            if (!(enabled && started && traceBaseDir) ||
                typeof tracing.startChunk !== "function") {
                return;
            }
            await stopChunk(label);
            await startChunk(label);
        },
        markSucceeded() {
            succeeded = true;
        },
        async stop() {
            if (!(enabled && started)) {
                return;
            }
            started = false; // idempotent: SIGTERM finalize + finally block both call stop().
            // If the browser is already disconnected (CDP transport drop), the
            // server has buffered events we can't retrieve. Skip the stop call
            // and keep the chunks we've already written rather than throwing a
            // noisy "Target page, context or browser has been closed".
            if (isContextDisconnected(context)) {
                finalizeDisconnected();
                return;
            }
            try {
                if (traceBaseDir && typeof tracing.stopChunk === "function") {
                    await stopChunkedTrace();
                    return;
                }
                await stopSingleTrace();
            }
            catch (err) {
                writeTraceDiagnostic("stop", err);
            }
        },
    };
    function finalizeDisconnected() {
        writeTraceDiagnostic("stop-disconnected", new Error("browser disconnected before trace stop"));
        // Checked before the traceBaseDir guard: a disconnect must not become a
        // path that leaves credential-bearing chunks behind.
        if (credentialsInPlay()) {
            discardTracesForCredentialSafety();
            return;
        }
        if (!traceBaseDir) {
            return;
        }
        if (succeeded) {
            deleteWrittenTraces();
            process.stderr.write(`[trace] run succeeded but browser disconnected; trace chunks deleted from ${traceBaseDir}\n`);
        }
        else {
            process.stderr.write(`[trace] browser disconnected before stop; chunks retained under ${traceBaseDir}\n`);
        }
    }
    async function stopChunkedTrace() {
        await stopChunk("final");
        await context.tracing.stop();
        if (credentialsInPlay()) {
            discardTracesForCredentialSafety();
            return;
        }
        if (succeeded) {
            deleteWrittenTraces();
            process.stderr.write(`[trace] run succeeded; trace chunks deleted from ${traceBaseDir}\n`);
        }
        else {
            process.stderr.write(`[trace] run failed; trace chunks retained under ${traceBaseDir}\n`);
        }
    }
    async function stopSingleTrace() {
        await context.tracing.stop({ path: tracePath });
        // Also covers PDPP_TRACE=1 with no capture session, where the trace lands
        // in /tmp. A credential is no safer there than under fixtures/.
        if (credentialsInPlay()) {
            discardTracesForCredentialSafety();
            return;
        }
        if (!succeeded) {
            process.stderr.write(`[trace] run failed; trace retained at ${tracePath}\n`);
            return;
        }
        try {
            rmSync(tracePath, { force: true });
            process.stderr.write(`[trace] run succeeded; trace deleted (${tracePath})\n`);
        }
        catch (err) {
            writeTraceDiagnostic("delete-on-success", err);
        }
    }
}
