/**
 * Explicit allowlist of query affordances that a first-party connector stream
 * intentionally does NOT declare, even though the field looks useful for
 * search, range filtering, time bucketing, or faceting.
 *
 * This backs the OpenSpec change `complete-connector-query-affordances`
 * (capability `polyfill-runtime`): "A readable field SHALL NOT be treated as
 * searchable, range-filterable, aggregatable, or facetable unless the manifest
 * declares that affordance or the field appears on an explicit justified
 * non-support list."
 *
 * The gate test (`query-affordance-manifest-honesty.test.ts`) cross-checks this
 * list against the manifest tree in BOTH directions every CI run:
 *   - a stream with a useful undeclared affordance that is NOT here fails the
 *     build (no silent affordance drift);
 *   - an allowlist entry whose affordance is ALSO declared in the manifest, or
 *     whose stream/field no longer exists, fails the build, forcing the stale
 *     entry to be removed.
 *
 * Adding an entry is a deliberate, reviewed act — it is the documented escape
 * hatch, not a default. The default is to declare the affordance.
 *
 * Keys are `${connectorKey}.${stream}.${field}.${affordance}` where
 * `connectorKey` is the manifest's canonical `connector_key` (hyphenated, e.g.
 * `claude-code`) and affordance is one of: `lexical`, `semantic`, `range`,
 * `group_by_time`, `group_by`.
 */
export type AffordanceJustification = string;
export declare const QUERY_AFFORDANCE_ALLOWLIST: Readonly<Record<string, AffordanceJustification>>;
//# sourceMappingURL=query-affordance-allowlist.d.ts.map