/**
 * Hand-maintained roster of real owner-visible connectors: every Supported
 * or Preview manifest that is expected to collect data rather than emit an
 * unconditional `SKIP_RESULT` placeholder.
 *
 * This is executable data, not documentation, and one of three disjoint,
 * exhaustive roster categories `connector-conformance.test.ts` checks every
 * manifest connector key against (the others are `REAL_UNLISTED_CONNECTORS`,
 * `KNOWN_SCAFFOLD_CONNECTORS` below). Every connector key MUST land in
 * exactly one. Category transitions are deliberate roster edits.
 *
 * `connector-conformance.test.ts` cross-checks this roster:
 *   1. its connector set matches exactly which manifests declare Supported
 *      or Preview (a visible connector missing from the roster fails CI);
 *   2. every roster entry's `testFile` exists on disk;
 *   3. its connector set is disjoint from `KNOWN_SCAFFOLD_CONNECTORS`
 *      (anthropic, doordash, linkedin, loom, meta, shopify, uber,
 *      wholefoods) — all of which MUST remain Development until they collect.
 *
 * `testFile` names each connector's own named collection/integration test —
 * the behavioral oracle for whether it really collects real data. This
 * roster does not re-run or re-prove that oracle; it only asserts the oracle
 * exists and that lifecycle tier hasn't drifted from it. Each connector's own
 * suite remains authoritative for its collection behavior.
 */
export declare const PRODUCTION_READY_CONNECTORS: Record<string, {
    testFile: string;
}>;
/**
 * Connectors that are scaffolded (unconditional `SKIP_RESULT`, no real
 * collection) and MUST stay outside `PRODUCTION_READY_CONNECTORS` and outside
 * the owner-selectable listing until they actually collect.
 */
export declare const KNOWN_SCAFFOLD_CONNECTORS: readonly ["anthropic", "doordash", "linkedin", "loom", "meta", "shopify", "uber", "wholefoods"];
/**
 * Connectors with a REAL collector (verified: no unconditional `SKIP_RESULT`
 * stub, genuine parsing/pagination/cursor logic) and a real behavioral-oracle
 * test file, but whose lifecycle tier is Development. This is distinct from
 * a scaffold: real parsing or collection code exists, but live evidence does
 * not yet justify offering it. Promote an entry when its tier becomes Preview
 * or Supported; the conformance test keeps the rosters disjoint.
 */
export declare const REAL_UNLISTED_CONNECTORS: Record<string, {
    testFile: string;
}>;
//# sourceMappingURL=connector-conformance-roster.d.ts.map