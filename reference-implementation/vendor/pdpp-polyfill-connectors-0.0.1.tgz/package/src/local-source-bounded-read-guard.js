// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { readdirSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
export const BOUNDED_READ_EXCEPTIONS = [
    {
        connector: "google_takeout",
        file: "parsers.ts",
        pattern: "readFile",
        lineIncludes: 'import { readFile } from "node:fs/promises";',
        reason: "Imports readFile for reviewed Takeout JSON sidecar reads below.",
    },
    {
        connector: "google_takeout",
        file: "parsers.ts",
        pattern: "readFile",
        lineIncludes: 'JSON.parse(await readFile(path, "utf8"))',
        reason: "Reads one Takeout JSON sidecar per call; streaming migration is deferred until large fixtures justify it.",
    },
    {
        connector: "ical",
        file: "index.ts",
        pattern: "readFile",
        lineIncludes: 'import { readdir, readFile } from "node:fs/promises";',
        reason: "Imports readFile for reviewed per-calendar ICS reads below.",
    },
    {
        connector: "ical",
        file: "index.ts",
        pattern: "readFile",
        lineIncludes: 'await readFile(join(dir, f), "utf8")',
        reason: "Reads each ICS calendar file as a per-artifact input. Keep reviewed until a large-calendar fixture proves risk.",
    },
    {
        connector: "slack",
        file: "index.ts",
        pattern: "all",
        lineIncludes: "return db.prepare(sql).all() as T[];",
        reason: "Reviewed safeAll helper for bounded lookup tables such as workspace, users, channels, files, and canvases. The unbounded MESSAGE table now uses iterateMessageRows.",
    },
];
const READ_FILE_CALL = /\bawait\s+readFile\s*\(/;
const READ_FILE_IMPORT = /import\s+\{[^}]*\breadFile\b[^}]*\}\s+from\s+["']node:fs\/promises["']/;
const READ_FILE_SYNC = /\breadFileSync\s*\(/;
const DOT_ALL = /\.all\s*\(/;
const MANIFEST_JSON_SUFFIX = /\.json$/;
const MATCHERS = [
    {
        pattern: "readFile",
        test: (line) => READ_FILE_CALL.test(line) || READ_FILE_IMPORT.test(line),
    },
    { pattern: "readFileSync", test: (line) => READ_FILE_SYNC.test(line) },
    { pattern: "all", test: (line) => DOT_ALL.test(line) },
];
export const EXPLICIT_LOCAL_CLASS_CONNECTORS = [];
function packageRoot() {
    return fileURLToPath(new URL("..", import.meta.url));
}
export function discoverLocalSourceConnectors(root = packageRoot()) {
    const manifestsDir = new URL("manifests/", new URL(`${root}/`, "file:"));
    const discovered = new Set(EXPLICIT_LOCAL_CLASS_CONNECTORS);
    for (const entry of readdirSync(manifestsDir)) {
        if (!entry.endsWith(".json")) {
            continue;
        }
        const manifest = JSON.parse(readFileSync(new URL(entry, manifestsDir), "utf8"));
        if (declaresFilesystemBinding(manifest)) {
            discovered.add(entry.replace(MANIFEST_JSON_SUFFIX, ""));
        }
    }
    return [...discovered].sort();
}
function declaresFilesystemBinding(manifest) {
    if (typeof manifest !== "object" || manifest === null) {
        return false;
    }
    const runtimeRequirements = manifest
        .runtime_requirements;
    if (typeof runtimeRequirements !== "object" || runtimeRequirements === null) {
        return false;
    }
    const { bindings } = runtimeRequirements;
    if (typeof bindings !== "object" || bindings === null) {
        return false;
    }
    const { filesystem } = bindings;
    return (typeof filesystem === "object" &&
        filesystem !== null &&
        filesystem.required === true);
}
function connectorSourceFiles(connectorDir) {
    return readdirSync(connectorDir).filter((file) => file.endsWith(".ts") &&
        !file.includes(".test.") &&
        !file.includes(".fixture."));
}
function stripComments(lines) {
    let inBlock = false;
    return lines.map((line) => {
        let out = "";
        for (let i = 0; i < line.length; i += 1) {
            const pair = line.slice(i, i + 2);
            if (inBlock) {
                if (pair === "*/") {
                    inBlock = false;
                    i += 1;
                }
                continue;
            }
            if (pair === "/*") {
                inBlock = true;
                i += 1;
                continue;
            }
            if (pair === "//") {
                break;
            }
            out += line[i];
        }
        return out;
    });
}
function isAllowed(exceptions, connector, file, pattern, rawLine) {
    return exceptions.some((exception) => exception.connector === connector &&
        exception.file === file &&
        exception.pattern === pattern &&
        rawLine.includes(exception.lineIncludes));
}
export function findUnapprovedBoundedReads(options = {}) {
    const root = options.root ?? packageRoot();
    const connectorsRoot = new URL("connectors/", new URL(`${root}/`, "file:"));
    const exceptions = options.exceptions ?? BOUNDED_READ_EXCEPTIONS;
    const findings = [];
    for (const connector of discoverLocalSourceConnectors(root)) {
        const connectorDir = new URL(`${connector}/`, connectorsRoot);
        for (const file of connectorSourceFiles(connectorDir)) {
            const rawLines = readFileSync(new URL(file, connectorDir), "utf8").split("\n");
            const codeLines = stripComments(rawLines);
            codeLines.forEach((line, index) => {
                for (const matcher of MATCHERS) {
                    if (matcher.test(line) &&
                        !isAllowed(exceptions, connector, file, matcher.pattern, rawLines[index] ?? "")) {
                        findings.push({
                            connector,
                            file,
                            line: index + 1,
                            pattern: matcher.pattern,
                            text: (rawLines[index] ?? "").trim(),
                        });
                    }
                }
            });
        }
    }
    return findings;
}
