import type { ReferenceBlobRef } from "./reference-blob-uploader.ts";
export type { ReferenceBlobRef } from "./reference-blob-uploader.ts";
export declare const DEFAULT_MAX_MEDIA_BYTES: number;
/** Guesses a MIME type from a filename's extension; unknown extensions fall back to a generic binary type. */
export declare function contentTypeForFileName(fileName: string): string;
/** Strips path-shaped substrings and caps length so a diagnostic never leaks a local filesystem location. */
export declare function sanitizeHydrationError(message: string): string;
export declare function resolveMaxMediaBytes(envVar: string, env?: NodeJS.ProcessEnv): number;
/**
 * Reads a media file's bytes bounded by maxBytes. Stats first so an
 * oversized file is never fully read into memory; only files at or under the
 * cap are hashed and returned.
 */
export declare function readBoundedMediaBytes(path: string, maxBytes: number): Promise<{
    bytes: Buffer | null;
    sizeBytes: number;
    tooLarge: boolean;
}>;
export declare function uploadMediaBlob(args: {
    bytes: Buffer;
    connectorId: string;
    mimeType: string;
    recordKey: string;
    stream: string;
}): Promise<ReferenceBlobRef | null>;
export type MediaHydrationStatus = "failed" | "hydrated" | "skipped_too_large" | "unavailable";
export interface MediaHydrationResult {
    blobRef: ReferenceBlobRef | null;
    contentSha256: string | null;
    hydrationError: string | null;
    hydrationStatus: MediaHydrationStatus;
    sizeBytes: number | null;
}
/**
 * Read, hash, and attempt blob upload for a local media file within the size
 * cap. Never throws — unreadable/oversized files return a hydration_status
 * describing why bytes are absent, so a caller's stream never fabricates a
 * deletion or silently drops a discovered file.
 */
export declare function hydrateMediaBytes(args: {
    connectorId: string;
    filePath: string;
    fileName: string;
    maxBytes: number;
    stream: string;
}): Promise<MediaHydrationResult>;
//# sourceMappingURL=local-media-blob-hydration.d.ts.map