export type OptionParseKind = "int" | "bool" | "csv" | "string";
export interface OptionFieldSpec {
    default: unknown;
    parse: OptionParseKind;
}
export interface OptionsSpec {
    envPrefix: string;
    fields: Record<string, OptionFieldSpec>;
}
export interface StartMessageWithOptions {
    connector_options?: Record<string, unknown>;
}
/**
 * Read options for a connector. Example spec:
 *
 *   {
 *     envPrefix: 'SLACK_',
 *     fields: {
 *       LOOKBACK_DAYS: { parse: 'int', default: 7 },
 *       CHANNEL_ALLOWLIST: { parse: 'csv', default: [] },
 *       SKIP_FILES: { parse: 'bool', default: false },
 *       CHANNEL_TYPES: { parse: 'csv', default: ['public', 'private', 'im', 'mpim'] },
 *     },
 *   }
 */
export declare function readOptions(startMsg: StartMessageWithOptions | null | undefined, spec: OptionsSpec): Record<string, unknown>;
//# sourceMappingURL=connector-options.d.ts.map