export interface ConnectorImplementation {
    /** A file URL for the connector's brand icon in the installed package. */
    readonly brandIcon: string;
    /** A file URL for the built JavaScript implementation, safe for `import()`. */
    readonly entry: string;
    readonly manifest: Record<string, unknown>;
}
export declare class ConnectorImplementationNotFoundError extends Error {
    readonly code = "ERR_PDPP_CONNECTOR_IMPLEMENTATION_NOT_FOUND";
    constructor(connectorId: string);
}
/**
 * Resolve a manifest connector ID without discovering connector files.
 *
 * `entry` and `brandIcon` are file URLs rooted in the installed package.
 * Consumers can call `await import(implementation.entry)` directly.
 */
export declare function resolveConnectorImplementation(connectorId: string): ConnectorImplementation;
//# sourceMappingURL=resolve.d.ts.map