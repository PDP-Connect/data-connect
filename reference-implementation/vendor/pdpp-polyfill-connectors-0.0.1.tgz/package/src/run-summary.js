// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
function isDetailCoverageMessage(message) {
    return message.type === "DETAIL_COVERAGE";
}
function streamFor(name, streams) {
    const existing = streams[name];
    if (existing) {
        return existing;
    }
    const created = { records: 0, state_emitted: false };
    streams[name] = created;
    return created;
}
function latestRecordEmittedAt(messages) {
    let latest;
    for (const message of messages) {
        if (message.type !== "RECORD") {
            continue;
        }
        const { emitted_at: emittedAt } = message;
        if (typeof emittedAt === "string" &&
            emittedAt &&
            (!latest || emittedAt > latest)) {
            latest = emittedAt;
        }
    }
    return latest;
}
function buildCoverage(messages) {
    const coverageMessages = messages.filter(isDetailCoverageMessage);
    if (coverageMessages.length === 0) {
        return;
    }
    const streamNames = new Set();
    let considered = 0;
    let covered = 0;
    for (const message of coverageMessages) {
        streamNames.add(message.stream);
        considered += message.considered ?? message.required_keys.length;
        covered += message.covered ?? message.hydrated_keys.length;
    }
    return { considered, covered, streams: [...streamNames] };
}
function buildDone(messages) {
    const done = messages.findLast((message) => message.type === "DONE");
    const coverage = buildCoverage(messages);
    const latestRecordEmittedAtValue = latestRecordEmittedAt(messages);
    if (!done) {
        return {
            status: "no_done",
            ...(coverage ? { coverage } : {}),
            ...(latestRecordEmittedAtValue
                ? { latest_record_emitted_at: latestRecordEmittedAtValue }
                : {}),
        };
    }
    return {
        status: done.status,
        ...(coverage ? { coverage } : {}),
        ...(latestRecordEmittedAtValue
            ? { latest_record_emitted_at: latestRecordEmittedAtValue }
            : {}),
        ...(done.status === "failed" && done.error
            ? {
                error: {
                    message: done.error.message,
                    retryable: done.error.retryable,
                    ...(done.error.code ? { code: done.error.code } : {}),
                },
            }
            : {}),
    };
}
/**
 * Widen a stream's observed `emitted_at` window. Records arrive in emission
 * order per stream but interleave across streams, and `emitted_at` is
 * connector-supplied, so neither bound can be assumed from arrival position.
 * Non-string and empty timestamps leave the window untouched.
 */
function widenRecordWindow(stream, emittedAt) {
    if (typeof emittedAt !== "string" || !emittedAt) {
        return;
    }
    if (!stream.first_record_at || emittedAt < stream.first_record_at) {
        stream.first_record_at = emittedAt;
    }
    if (!stream.last_record_at || emittedAt > stream.last_record_at) {
        stream.last_record_at = emittedAt;
    }
}
/**
 * Fold a connector's protocol message stream into a `RunSummary`.
 *
 * Edge cases this handles explicitly (see `src/run-summary.test.ts`):
 *   - No STATE ever emitted for a stream that produced records — the
 *     stream's `state_emitted` stays `false` so a developer can see a
 *     connector emitted records but never even sent a checkpoint message
 *     (this tool makes no claim about durable commit either way — see
 *     `RunSummaryStream.state_emitted`'s doc comment).
 *   - A run that fails mid-stream (no terminal DONE at all, or a DONE with
 *     `status: "failed"`) still gets a well-formed summary with whatever
 *     partial per-stream counts were observed before failure.
 *   - Multiple streams interleaved in the message order — counts are
 *     attributed per-`stream` field, not per-arrival-order.
 */
export function buildRunSummary(messages, meta) {
    const streams = {};
    let skips = 0;
    for (const message of messages) {
        if (message.type === "RECORD") {
            const stream = streamFor(message.stream, streams);
            stream.records += 1;
            widenRecordWindow(stream, message.emitted_at);
        }
        else if (message.type === "STATE") {
            streamFor(message.stream, streams).state_emitted = true;
        }
        else if (message.type === "SKIP_RESULT") {
            skips += 1;
        }
    }
    for (const stream of Object.values(streams)) {
        if (stream.first_record_at && stream.last_record_at) {
            const span = Date.parse(stream.last_record_at) - Date.parse(stream.first_record_at);
            if (Number.isFinite(span) && span >= 0) {
                stream.elapsed_ms = span;
            }
        }
    }
    const startedMs = Date.parse(meta.started_at);
    const finishedMs = Date.parse(meta.finished_at);
    const durationMs = Number.isFinite(startedMs) && Number.isFinite(finishedMs)
        ? Math.max(0, finishedMs - startedMs)
        : 0;
    return {
        format: "pdpp.run-summary/1",
        connector: meta.connector,
        tool_version: meta.tool_version,
        started_at: meta.started_at,
        finished_at: meta.finished_at,
        duration_ms: durationMs,
        streams,
        skips,
        done: buildDone(messages),
        generated_by: "connector-dev",
        provider_contact_observed: false,
    };
}
