/**
 * Shared scrub rules every connector inherits. PII patterns that are
 * universally unsafe to commit, regardless of source platform.
 *
 * Connector-specific rules live in `connectors/<name>/scrub-rules.ts`
 * and are applied AFTER defaults. Order matters: earlier rules that
 * catch a PII shape should precede broader fallbacks.
 *
 * This list is intentionally conservative — false positives are harmless
 * (replacing non-PII), but false negatives leak user data. When in doubt,
 * add a rule here rather than leaving it for per-connector authors.
 */
import type { ScrubRule } from "./scrubber.ts";
export declare const defaultScrubRules: readonly ScrubRule[];
//# sourceMappingURL=scrub-defaults.d.ts.map