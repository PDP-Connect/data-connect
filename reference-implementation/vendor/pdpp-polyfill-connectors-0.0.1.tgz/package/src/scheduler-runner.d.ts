export interface InteractionMessageShape {
    connectorId?: string;
    kind: string;
    message?: string;
    [extra: string]: unknown;
}
export interface InboxHandler {
    park: (msg: InteractionMessageShape) => Promise<string>;
    waitFor: (itemId: string) => Promise<unknown>;
}
export interface StartPolyfillSchedulerOptions {
    asUrl: string;
    connectors: readonly string[];
    inboxHandler: InboxHandler;
    nightlySummary?: false | NightlySummaryOptions;
    rsUrl: string;
    schedulerStore?: false | SchedulerPersistenceStore;
    subjectId?: string;
}
interface SchedulerStats {
    lastRun?: {
        error?: string;
        status?: string;
    };
    succeeded: number;
    totalRecords: number;
    totalRuns: number;
}
interface Scheduler {
    getStats: () => Record<string, SchedulerStats>;
    start: () => void;
    stop: () => void;
}
export interface SchedulerPersistenceStore {
    appendRunHistory: (record: unknown) => Promise<void> | void;
    listLastRunTimes: () => Promise<readonly unknown[]> | readonly unknown[];
    listRunHistory: (limit: number) => Promise<readonly unknown[]> | readonly unknown[];
    upsertLastRunTime: (connectorId: string, lastRunTimeMs: number, updatedAt: string) => Promise<void> | void;
}
export interface SchedulerSummary {
    counts: Record<string, string>;
    failures: string[];
    ok: boolean;
}
export interface PolyfillSchedulerHandle {
    notifySummary: () => Promise<SchedulerSummary>;
    scheduler: Scheduler;
    stop: () => void;
    summarize: () => Promise<SchedulerSummary>;
}
type SummaryNotifier = (summary: SchedulerSummary) => Promise<unknown>;
interface TimerLike {
    unref?: () => void;
}
export interface NightlySummarySchedule {
    stop: () => void;
}
export interface NightlySummaryOptions {
    clearTimeout?: (timer: TimerLike) => void;
    hour?: number;
    minute?: number;
    notify?: SummaryNotifier;
    now?: () => Date;
    setTimeout?: (callback: () => void, delayMs: number) => TimerLike;
}
export declare function millisecondsUntilNextNightlySummary(now: Date, hour?: number, minute?: number): number;
export declare function notifyOvernightSummarySafely(summary: SchedulerSummary, notify?: SummaryNotifier): Promise<void>;
export declare function scheduleNightlySummary(handle: Pick<PolyfillSchedulerHandle, "summarize">, { hour, minute, now, notify, setTimeout: setTimer, clearTimeout: clearTimer, }?: NightlySummaryOptions): NightlySummarySchedule;
export declare function loadDefaultSchedulerPersistenceStore(): Promise<SchedulerPersistenceStore>;
export declare function resolveSchedulerPersistenceStore(schedulerStore: false | SchedulerPersistenceStore | undefined, loadDefaultStore?: () => Promise<SchedulerPersistenceStore>): Promise<SchedulerPersistenceStore | null>;
export declare function startPolyfillScheduler({ asUrl, rsUrl, connectors, subjectId, inboxHandler, nightlySummary, schedulerStore: schedulerStoreOption, }: StartPolyfillSchedulerOptions): Promise<PolyfillSchedulerHandle>;
export {};
//# sourceMappingURL=scheduler-runner.d.ts.map