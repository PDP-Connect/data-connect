// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { delimiter, join } from "node:path";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import { buildLocalDeviceRecordEnvelope, LocalDeviceClient, LocalDeviceQueue, } from "@pdpp/collector-runtime";
import { buildAgentVersion } from "@pdpp/collector-runtime/collector-build-info";
import { buildLocalDeviceIngestBatchRequest } from "@pdpp/collector-runtime/local-device-envelope";
import { resolveConnectorCommand } from "./resolve-tsx-binary.js";
/**
 * Stream name a connector's per-store proof claims (e.g. `collected`) ride
 * on. Kept in sync with the same literal in `collector-runner.ts` and
 * `ref-control.ts` — the wire contract, not a shared module, is the source
 * of truth for connectors written outside this package.
 */
const LOCAL_COVERAGE_DIAGNOSTICS_STREAM = "coverage_diagnostics";
export const CODEX_CONNECTOR_ID = "codex";
export const CLAUDE_CODE_CONNECTOR_ID = "claude-code";
export const AMAZON_CONNECTOR_ID = "amazon";
export const IMESSAGE_CONNECTOR_ID = "imessage";
export const DEFAULT_CODEX_STREAMS = [
    "sessions",
    "messages",
    "function_calls",
    "rules",
    "prompts",
    "skills",
];
export const DEFAULT_CLAUDE_CODE_STREAMS = [
    "sessions",
    "messages",
    "attachments",
    "memory_notes",
    "skills",
    "slash_commands",
];
export const DEFAULT_AMAZON_STREAMS = ["orders", "order_items"];
export const DEFAULT_IMESSAGE_STREAMS = [
    "messages",
    "participants",
    "attachments",
];
const PACKAGE_ROOT = fileURLToPath(new URL("..", import.meta.url));
const REPO_ROOT = join(PACKAGE_ROOT, "..", "..");
const CONNECTOR_ENTRYPOINT_EXTENSION = import.meta.filename.endsWith(".js")
    ? "js"
    : "ts";
export const LOCAL_DEVICE_CONNECTOR_PROFILES = {
    [CODEX_CONNECTOR_ID]: {
        connectorId: CODEX_CONNECTOR_ID,
        defaultStreams: DEFAULT_CODEX_STREAMS,
        entrypoint: `connectors/codex/index.${CONNECTOR_ENTRYPOINT_EXTENSION}`,
    },
    [CLAUDE_CODE_CONNECTOR_ID]: {
        connectorId: CLAUDE_CODE_CONNECTOR_ID,
        defaultStreams: DEFAULT_CLAUDE_CODE_STREAMS,
        entrypoint: `connectors/claude_code/index.${CONNECTOR_ENTRYPOINT_EXTENSION}`,
    },
    // Amazon is a browser-bound connector. Unlike codex/claude-code it requires a
    // real, owner-mediated browser session (live login, possibly 2FA) to produce
    // RECORDs, so spawning it in a headless/no-human context will fail at the
    // session probe — that is expected and is exactly the step the
    // browser-collector proof keeps owner-mediated. Registering the profile here
    // is the deterministic monorepo-runner wiring the owner-run live proof needs;
    // it does NOT add a new browser transport, and it is intentionally absent from the published
    // `@pdpp/local-collector` bundle (see `src/runner.ts` — that registry stays
    // filesystem-class only so the publish stays browser-free). The
    // device-exporter ingest path it feeds is connector-agnostic; binding-aware
    // enrollment records this connector as `browser_collector`.
    [AMAZON_CONNECTOR_ID]: {
        connectorId: AMAZON_CONNECTOR_ID,
        defaultStreams: DEFAULT_AMAZON_STREAMS,
        entrypoint: `connectors/amazon/index.${CONNECTOR_ENTRYPOINT_EXTENSION}`,
    },
    // iMessage's PRIMARY operator path is `npx @pdpp/local-collector setup`
    // (it is a registered `LOCAL_COLLECTOR_DEFINITIONS` entry — see
    // collector-registry.ts — because it reads chat.db via node:sqlite, not a
    // native module, so it ships in that bundle like Claude Code/Codex). This
    // profile registers the same connector on the lower-level monorepo-only
    // exporter as an optional fallback for scripting/CI contexts that already
    // run from a checkout — not a second advertised setup path. macOS-only,
    // and requires Full Disk Access for the terminal/Node binary that runs it.
    [IMESSAGE_CONNECTOR_ID]: {
        connectorId: IMESSAGE_CONNECTOR_ID,
        defaultStreams: DEFAULT_IMESSAGE_STREAMS,
        entrypoint: `connectors/imessage/index.${CONNECTOR_ENTRYPOINT_EXTENSION}`,
    },
};
export function resolveLocalDeviceConnectorProfile(connectorId) {
    const profile = LOCAL_DEVICE_CONNECTOR_PROFILES[connectorId];
    if (!profile) {
        const known = Object.keys(LOCAL_DEVICE_CONNECTOR_PROFILES).join(", ");
        throw new Error(`unsupported local-device connector "${connectorId}" (known: ${known})`);
    }
    return profile;
}
export async function enrollLocalDevice(config) {
    const client = new LocalDeviceClient({ baseUrl: config.baseUrl });
    return await client.exchangeEnrollment({
        enrollment_code: config.code,
        ...(config.deviceLabel ? { device_label: config.deviceLabel } : {}),
    });
}
/**
 * Run the local-device exporter for any supported connector. Binds the given
 * source home (carried in `connectorEnv`) to `sourceInstanceId`: every RECORD
 * the connector emits is wrapped in an envelope tagged with that
 * source-instance + device identity before it is queued and ingested, so two
 * source homes that share connector-local record keys never collide — the
 * reference store keys records by `(connector_instance_id, stream,
 * record_key)`, and each enrolled source home resolves to a distinct
 * connector instance.
 */
export async function runLocalDeviceExporter(config) {
    const profile = resolveLocalDeviceConnectorProfile(config.connectorId ?? CODEX_CONNECTOR_ID);
    const batchSize = config.batchSize ?? 100;
    const queue = new LocalDeviceQueue({ path: config.queuePath });
    const client = new LocalDeviceClient({
        baseUrl: config.baseUrl,
        deviceId: config.deviceId,
        deviceToken: config.deviceToken,
    });
    await client.heartbeat({
        agent_version: buildAgentVersion(),
        connector_id: profile.connectorId,
        records_pending: (await queue.list()).filter((item) => item.status !== "sent").length,
        source_instance_id: config.sourceInstanceId,
        status: "starting",
    });
    const messages = await collectConnectorMessages(profile, config);
    const allRecords = messages.filter((msg) => msg.type === "RECORD");
    const done = messages.findLast((msg) => msg.type === "DONE") ?? null;
    const { sampleLimit } = config;
    const recordsSeen = allRecords.length;
    // `coverage_diagnostics` records are a per-store proof claim (e.g.
    // `collected`), not sampled content — they must never ride through a
    // sample-limit slice that cuts off the data records they vouch for. Sample
    // ONLY the substantive records; a truncated run drops its coverage claims
    // instead of asserting proof over data it never queued. This is
    // ordering-independent (`allRecords` is partitioned by stream, not
    // position), so it holds whether a connector emits diagnostics before or
    // after its data. `sampleLimit: 0` truncates whenever any substantive
    // record exists (0 < substantiveRecords.length); a verified-empty run
    // with zero substantive records is never "truncated" by a limit it never
    // needed, so its diagnostics still ride through.
    const diagnosticRecords = allRecords.filter((record) => record.stream === LOCAL_COVERAGE_DIAGNOSTICS_STREAM);
    const substantiveRecords = allRecords.filter((record) => record.stream !== LOCAL_COVERAGE_DIAGNOSTICS_STREAM);
    const sampledSubstantive = sampleLimit !== undefined && sampleLimit >= 0
        ? substantiveRecords.slice(0, sampleLimit)
        : substantiveRecords;
    const truncatedBySample = sampledSubstantive.length < substantiveRecords.length;
    const records = truncatedBySample
        ? sampledSubstantive
        : [...sampledSubstantive, ...diagnosticRecords];
    let recordsQueued = 0;
    let enqueuedBatches = 0;
    let batchSeq = nextBatchSeq(await queue.list(), config.sourceInstanceId);
    for (const chunk of chunkRecords(records, batchSize)) {
        const batchId = `${config.sourceInstanceId}-${batchSeq}-${randomUUID()}`;
        const envelopes = chunk.map((record) => buildLocalDeviceRecordEnvelope({
            batchId,
            batchSeq,
            connectorId: profile.connectorId,
            deviceId: config.deviceId,
            record,
            sourceInstanceId: config.sourceInstanceId,
        }));
        await queue.enqueue({
            batchId,
            batchSeq,
            records: envelopes,
            sourceInstanceId: config.sourceInstanceId,
        });
        recordsQueued += envelopes.length;
        enqueuedBatches += 1;
        batchSeq += 1;
    }
    const sentBatches = await drainLocalDeviceQueue({ client, queue });
    await client.heartbeat({
        agent_version: buildAgentVersion(),
        connector_id: profile.connectorId,
        records_pending: (await queue.list()).filter((item) => item.status !== "sent").length,
        source_instance_id: config.sourceInstanceId,
        status: "healthy",
    });
    return {
        done,
        enqueuedBatches,
        recordsQueued,
        recordsSeen,
        sentBatches,
        truncatedBySample,
    };
}
/** @deprecated use {@link runLocalDeviceExporter}; retained for back-compat. */
export function runCodexLocalDeviceExporter(config) {
    return runLocalDeviceExporter({
        ...config,
        connectorId: config.connectorId ?? CODEX_CONNECTOR_ID,
    });
}
export function buildLocalDeviceStartMessage(streams) {
    return {
        scope: { streams: streams.map((name) => ({ name })) },
        type: "START",
    };
}
/** @deprecated use {@link buildLocalDeviceStartMessage}. */
export function buildCodexStartMessage(streams = DEFAULT_CODEX_STREAMS) {
    return buildLocalDeviceStartMessage(streams);
}
export function transformRecordsToLocalDeviceEnvelopes(input) {
    const connectorId = input.connectorId ?? CODEX_CONNECTOR_ID;
    return input.messages
        .filter((msg) => msg.type === "RECORD")
        .map((record) => buildLocalDeviceRecordEnvelope({
        batchId: input.batchId,
        batchSeq: input.batchSeq,
        connectorId,
        deviceId: input.deviceId,
        record,
        sourceInstanceId: input.sourceInstanceId,
    }));
}
export async function drainLocalDeviceQueue(input) {
    let sent = 0;
    for (;;) {
        const item = await input.queue.dequeueReady();
        if (!item) {
            return sent;
        }
        try {
            await sendQueueItem(input.client, item);
            await input.queue.markSent(item.batch_id);
            sent += 1;
        }
        catch (error) {
            await input.queue.markRetry(item.batch_id, error instanceof Error ? error.message : String(error));
            return sent;
        }
    }
}
async function sendQueueItem(client, item) {
    const [firstRecord] = item.records;
    if (!firstRecord) {
        throw new Error(`local device batch has no records: ${item.batch_id}`);
    }
    await client.ingestBatch(buildLocalDeviceIngestBatchRequest({
        batchId: item.batch_id,
        batchSeq: item.batch_seq,
        connectorId: firstRecord.connector_id,
        deviceId: firstRecord.device_id,
        records: item.records,
        sourceInstanceId: item.source_instance_id,
    }));
}
async function collectConnectorMessages(profile, config) {
    const streams = config.streams ?? profile.defaultStreams;
    const child = spawnConnector(profile, config);
    const messages = [];
    const stderr = [];
    const exitPromise = new Promise((resolve, reject) => {
        child.once("error", reject);
        child.once("close", resolve);
    });
    const outputPromise = (async () => {
        const lines = createInterface({ input: child.stdout, terminal: false });
        for await (const line of lines) {
            if (!line.trim()) {
                continue;
            }
            messages.push(JSON.parse(line));
        }
    })();
    child.stdin.on("error", () => {
        // Missing commands or early child exits can close stdin before START
        // is accepted. Preserve the child error/exit diagnostic.
    });
    child.stderr.on("data", (chunk) => stderr.push(chunk));
    child.stdin.end(`${JSON.stringify(buildLocalDeviceStartMessage(streams))}\n`);
    let exitCode;
    try {
        [exitCode] = await Promise.all([exitPromise, outputPromise]);
    }
    catch (error) {
        throw new Error(`${profile.connectorId} connector failed to start or stream output: ${error instanceof Error ? error.message : String(error)}`, { cause: error });
    }
    if (exitCode !== 0) {
        throw new Error(`${profile.connectorId} connector exited ${exitCode}: ${Buffer.concat(stderr).toString("utf8").trim()}`);
    }
    return messages;
}
function spawnConnector(profile, config) {
    const env = { ...process.env, ...config.codexEnv, ...config.connectorEnv };
    env.PATH = buildLocalDeviceChildPath(env.PATH);
    // Resolve `tsx` to an absolute path rather than trusting the augmented PATH
    // alone: the augmentation is necessary for the child's own tooling but is
    // not sufficient for the spawn itself under a minimal-environment supervisor.
    const command = resolveConnectorCommand(config.connectorCommand ?? config.codexCommand ?? "tsx");
    const args = config.connectorArgs ?? config.codexArgs ?? [profile.entrypoint];
    return spawn(command, args, {
        cwd: PACKAGE_ROOT,
        env,
    });
}
function buildLocalDeviceChildPath(pathValue) {
    return [
        join(PACKAGE_ROOT, "node_modules", ".bin"),
        join(REPO_ROOT, "node_modules", ".bin"),
        pathValue,
    ]
        .filter((part) => Boolean(part))
        .join(delimiter);
}
function chunkRecords(records, size) {
    const chunks = [];
    for (let index = 0; index < records.length; index += size) {
        chunks.push(records.slice(index, index + size));
    }
    return chunks;
}
function nextBatchSeq(items, sourceInstanceId) {
    return (Math.max(0, ...items
        .filter((item) => item.source_instance_id === sourceInstanceId)
        .map((item) => item.batch_seq)) + 1);
}
