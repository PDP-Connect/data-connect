// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Resolves a connector's owner-facing config form: the SHAPE it declares in
 * its own manifest `options_schema`, merged with the KIND the platform
 * decides in `connector-config-option-kind-registry.ts`.
 *
 * The split is the whole point, and it is deliberately asymmetric:
 *
 *   SHAPE is connector-owned. Field names, types, labels, defaults and
 *   validation bounds are that connector's own facts, declared as data in
 *   its manifest exactly like `streams` and `reason_display_messages`. This
 *   is what lets the config surface reach all 45 connectors without a
 *   core-repo edit per connector.
 *
 *   KIND is platform-owned. Whether a knob is `transport` (self-activates)
 *   or `collection_scope` (lands `proposed`, inert until the owner
 *   confirms) is decided ONLY by the registry. A manifest's
 *   `declared_option_kind` is never read by this module at all. It exists
 *   so `connector-config-option-kind-honesty.test.ts` can fail the build on
 *   a connector whose claim disagrees with the registry -- a documentation
 *   claim under test, not an input to any runtime decision.
 *
 * If a manifest value could influence the kind, a connector could label its
 * own collection-shaping knob `transport` and thereby self-activate it,
 * bypassing owner confirmation entirely. So this module fails closed twice
 * over: `resolveEnforcedOptionKind` returns `collection_scope` for any key
 * the registry does not know, and the manifest's claim is never consulted
 * as an input to that decision. An unregistered connector gets a fully
 * renderable form in which EVERY field requires owner confirmation -- the
 * safe direction to be wrong in.
 *
 * Shape validation is intentionally thin. It covers what a form actually
 * needs to render a control and reject bad input before it reaches the
 * config store, and nothing more; this is not a JSON Schema implementation
 * and should not grow into one.
 */
import { platformOptionKind, resolveEnforcedOptionKind, } from "./connector-config-option-kind-registry.js";
import { readPolyfillManifests } from "./manifest-registry.js";
export class ConnectorOptionsSchemaError extends Error {
}
const OPTION_TYPES = new Set([
    "boolean",
    "integer",
    "string",
    "string_array",
]);
const REGISTRY_URL_PREFIX = "https://registry.pdpp.dev/connectors/";
const JSON_SUFFIX_RE = /\.json$/;
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function manifestKey(manifest, fallbackFile) {
    if (typeof manifest.connector_key === "string" &&
        manifest.connector_key.trim()) {
        return manifest.connector_key.trim();
    }
    if (typeof manifest.connector_id === "string" &&
        manifest.connector_id.trim()) {
        return manifest.connector_id.startsWith(REGISTRY_URL_PREFIX)
            ? manifest.connector_id.slice(REGISTRY_URL_PREFIX.length)
            : manifest.connector_id;
    }
    return fallbackFile.replace(JSON_SUFFIX_RE, "");
}
/**
 * The declared JSON-Schema-ish `type`/`items` collapsed onto the closed set
 * of controls a form can actually render. Anything outside that set is a
 * manifest authoring error, not something to guess at.
 */
function readOptionType(where, prop) {
    const declared = prop.type;
    if (typeof declared !== "string" ||
        !OPTION_TYPES.has(declared === "array" ? "string_array" : declared)) {
        throw new ConnectorOptionsSchemaError(`${where}: type must be one of boolean, integer, string, array (of string); got ${JSON.stringify(declared)}`);
    }
    if (declared !== "array") {
        return declared;
    }
    const { items } = prop;
    if (!isRecord(items) || items.type !== "string") {
        throw new ConnectorOptionsSchemaError(`${where}: an array option must declare items.type "string"`);
    }
    return "string_array";
}
function readDefaultValue(where, type, raw) {
    if (raw === undefined) {
        throw new ConnectorOptionsSchemaError(`${where}: a default is required, so a form can render an unset option`);
    }
    switch (type) {
        case "boolean": {
            if (typeof raw !== "boolean") {
                throw new ConnectorOptionsSchemaError(`${where}: default must be a boolean`);
            }
            return raw;
        }
        case "integer": {
            if (typeof raw !== "number" || !Number.isInteger(raw)) {
                throw new ConnectorOptionsSchemaError(`${where}: default must be an integer`);
            }
            return raw;
        }
        case "string": {
            if (typeof raw !== "string") {
                throw new ConnectorOptionsSchemaError(`${where}: default must be a string`);
            }
            return raw;
        }
        default: {
            if (!(Array.isArray(raw) && raw.every((entry) => typeof entry === "string"))) {
                throw new ConnectorOptionsSchemaError(`${where}: default must be an array of strings`);
            }
            return Object.freeze([...raw]);
        }
    }
}
function readBound(where, field, raw) {
    if (raw === undefined) {
        return null;
    }
    if (typeof raw !== "number" || !Number.isInteger(raw)) {
        throw new ConnectorOptionsSchemaError(`${where}: ${field} must be an integer when declared`);
    }
    return raw;
}
function readEnumValues(where, raw) {
    if (raw === undefined) {
        return null;
    }
    if (!(Array.isArray(raw) &&
        raw.length > 0 &&
        raw.every((entry) => typeof entry === "string"))) {
        throw new ConnectorOptionsSchemaError(`${where}: enum must be a non-empty array of strings when declared`);
    }
    return Object.freeze([...raw]);
}
function readDescription(where, raw) {
    if (typeof raw !== "string" || raw.trim().length === 0) {
        throw new ConnectorOptionsSchemaError(`${where}: description must be a non-empty string`);
    }
    return raw;
}
function resolveOption(connectorKey, where, optionKey, prop) {
    const type = readOptionType(where, prop);
    const minimum = readBound(where, "minimum", prop.minimum);
    const maximum = readBound(where, "maximum", prop.maximum);
    if (minimum !== null && maximum !== null && minimum > maximum) {
        throw new ConnectorOptionsSchemaError(`${where}: minimum ${minimum} exceeds maximum ${maximum}`);
    }
    // The KIND comes from the platform registry and ONLY the platform
    // registry. `prop.declared_option_kind` is deliberately not read here: a
    // manifest that could influence this line could grant itself
    // self-activation. Unknown keys fall back to collection_scope.
    const platformKind = resolveEnforcedOptionKind(connectorKey, optionKey);
    return Object.freeze({
        defaultValue: readDefaultValue(where, type, prop.default),
        description: readDescription(where, prop.description),
        enumValues: readEnumValues(where, prop.enum),
        maximum,
        minimum,
        optionKind: platformKind,
        optionKey,
        // Distinguishes "the registry classified this key" from "the registry
        // has never heard of it, so it failed closed to collection_scope". Both
        // enforce identically; only the owner-facing explanation differs.
        platformClassified: platformOptionKind(connectorKey, optionKey) !== null,
        type,
    });
}
/** Parses one manifest's `options_schema`, or returns null when it declares none. */
export function resolveOptionsSchemaFromManifest(manifest, file) {
    const typed = manifest;
    const raw = typed.options_schema;
    if (raw === undefined) {
        return null;
    }
    const connectorKey = manifestKey(typed, file);
    if (!isRecord(raw)) {
        throw new ConnectorOptionsSchemaError(`${file}: options_schema must be an object`);
    }
    if (raw.type !== "object") {
        throw new ConnectorOptionsSchemaError(`${file}: options_schema.type must be "object"`);
    }
    const { properties } = raw;
    if (!isRecord(properties)) {
        throw new ConnectorOptionsSchemaError(`${file}: options_schema.properties must be an object`);
    }
    const options = [];
    for (const optionKey of Object.keys(properties).sort()) {
        const prop = properties[optionKey];
        if (!isRecord(prop)) {
            throw new ConnectorOptionsSchemaError(`${file}: options_schema.properties.${optionKey} must be an object`);
        }
        options.push(resolveOption(connectorKey, `${file}: options_schema.${optionKey}`, optionKey, prop));
    }
    return Object.freeze({
        connectorKey,
        description: typeof raw.description === "string" ? raw.description : "",
        options: Object.freeze(options),
    });
}
/**
 * Every shipped connector's resolved config form, keyed by connector_key.
 * Connectors declaring no `options_schema` are absent. Re-derived per call
 * (manifests are small, this is not a hot path) so a test pointing
 * `PDPP_POLYFILL_MANIFESTS_DIR` at a scratch directory sees it immediately.
 */
export function connectorOptionsSchemas() {
    const out = {};
    for (const { file, manifest } of readPolyfillManifests()) {
        const resolved = resolveOptionsSchemaFromManifest(manifest, file);
        if (resolved) {
            out[resolved.connectorKey] = resolved;
        }
    }
    return Object.freeze(out);
}
/** One connector's resolved config form, or `null` when it declares no options. */
export function connectorOptionsSchema(connectorKey) {
    if (!connectorKey) {
        return null;
    }
    return connectorOptionsSchemas()[connectorKey] ?? null;
}
