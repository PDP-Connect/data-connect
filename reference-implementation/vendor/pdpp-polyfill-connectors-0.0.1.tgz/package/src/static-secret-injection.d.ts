/** Credential kinds the per-connection store can hold. Mirrors the store. */
export type StaticSecretCredentialKind = "access_token" | "api_key" | "app_password" | "personal_access_token" | "secret_bundle" | "username_password";
export interface RecoveredStaticSecret {
    /** The kind of secret, used to validate it matches the connector's expectation. */
    readonly credentialKind: StaticSecretCredentialKind;
    /** The recovered plaintext provider secret. Ephemeral — inject, never persist. */
    readonly secret: string;
}
interface StaticSecretInjectionMapping {
    /** Credential kind this connector authenticates with. */
    readonly credentialKind: StaticSecretCredentialKind;
    /**
     * Names from `secretFieldEnvVars` that may be absent from the recovered
     * bundle without failing injection. Every other `secretFieldEnvVars` name
     * remains required. Used when one connector accepts more than one
     * credential shape sealed into the SAME bundle (e.g. jellyfin's
     * username+password OR a bare api_key) rather than two mutually exclusive
     * `acceptedCredentialVariants`, because the manifest's `credential_kind` is
     * one fixed string and cannot switch between variants at capture time.
     */
    readonly optionalSecretBundleFields?: ReadonlySet<string>;
    /**
     * Env var name(s) the connector reads the secret from. The connector resolves
     * the first non-empty; the injection sets all of them to the same recovered
     * value so the connector finds it regardless of which alias it prefers.
     */
    readonly secretEnvVars?: readonly string[];
    /**
     * Secret fields inside an opaque sealed JSON credential bundle. Used when a
     * connector needs more than one bearer-equivalent value for one connection
     * (for example a token plus cookie, or OAuth password-flow credentials).
     */
    readonly secretFieldEnvVars?: Readonly<Record<string, readonly string[]>>;
    /** Non-secret setup fields to inject for connector runtime configuration. */
    readonly setupFieldEnvVars?: Readonly<Record<string, readonly string[]>>;
}
interface StaticSecretConnectorDescriptor extends StaticSecretInjectionMapping {
    /**
     * Backward-compatible credential shapes that can still authenticate the
     * connector. The primary `credentialKind` is the shape new captures should
     * use; variants keep older stored rows runnable during migrations.
     */
    readonly acceptedCredentialVariants?: readonly StaticSecretInjectionMapping[];
    /**
     * `false` only when the manifest's block-level `credential_capture.required`
     * is explicitly `false` (e.g. Venmo — the connector always falls back to a
     * browser-driven sign-in that works with zero saved credentials); `true`
     * for every connector that omits the fact. See `injectSecretBundle`'s use
     * of this: it is what lets an entirely EMPTY recovered bundle inject
     * nothing (valid "sign in by hand" choice) instead of throwing
     * `recovered_secret_bundle_field_missing` on the first field a required
     * capture (e.g. Jellyfin) would still correctly fail closed on.
     */
    readonly captureRequired: boolean;
}
/**
 * Registry of static-secret connectors and the env vars each reads its secret
 * from, generated from every shipped manifest's `setup.credential_capture`
 * (see `./generated/static-secret-registry.generated.ts`) plus the minimal,
 * explicit `LEGACY_CREDENTIAL_KIND_MIGRATIONS` table above for stored
 * credential shapes a current manifest cannot express.
 *
 * A connector absent from this registry is NOT a static-secret connector for
 * the purposes of injection; callers must not invent env var names for it.
 */
export declare const STATIC_SECRET_CONNECTOR_REGISTRY: Readonly<Record<string, StaticSecretConnectorDescriptor>>;
export declare class StaticSecretInjectionError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** True when the connector authenticates with an injectable static secret. */
export declare function isStaticSecretConnector(connectorId: string): boolean;
/**
 * True when THIS connector's manifest declares `credential_capture.required:
 * false` — the same block-level, provider-neutral fact `captureRequired`
 * already carries for injection (see `StaticSecretConnectorDescriptor`'s
 * doc). Exposed as its own predicate so a run-orchestration seam that has no
 * business reading manifests directly (e.g. `resolveStaticSecretRunEnv`) can
 * still ask "does a missing credential here mean the owner chose manual
 * sign-in, or is it a genuine fail-closed gap" without re-deriving the fact
 * or introducing a second, connector-name-keyed source of truth. Returns
 * `false` for a connector absent from the registry (not a static-secret
 * connector at all) or with no explicit opt-out — the same
 * backward-compatible default every other layer uses.
 */
export declare function isStaticSecretCaptureOptional(connectorId: string): boolean;
/**
 * Build the connection-scoped env fragment for one connector run.
 *
 * The returned object carries ONLY the secret env var(s) for this one
 * connection. It is intended for the per-run child environment:
 *
 *   const env = { ...declaredConnectorEnv, ...buildConnectionScopedSecretEnv(id, cred) };
 *
 * Never mutate `process.env` with the result. The fragment's lifetime is the one
 * run; runtime-owned platform and protocol controls retain precedence, and
 * nothing here logs or returns the secret outside the fragment.
 *
 * Throws when the connector is not a known static-secret connector, or when the
 * recovered credential's kind does not match the connector's expectation (a
 * guard against injecting one connector's credential kind into another
 * connector's runtime.
 */
export declare function buildConnectionScopedSecretEnv(connectorId: string, recovered: RecoveredStaticSecret, sourceBinding?: unknown): Record<string, string>;
export {};
//# sourceMappingURL=static-secret-injection.d.ts.map