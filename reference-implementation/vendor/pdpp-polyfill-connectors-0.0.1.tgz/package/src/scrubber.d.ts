/** Which captured file type a rule applies to. */
export type ScrubScope = "all" | "html" | "json";
/** A single scrub rule. `replacement` may be a string or a replacer function. */
export interface ScrubRule {
    pattern: RegExp;
    replacement: string | ((substring: string, ...args: string[]) => string);
    scope: ScrubScope;
}
export interface StructuredRedaction {
    reason: string;
    replacement: string;
    text: string;
}
export interface StructuredRedactionPlan {
    redactions: StructuredRedaction[];
    version: 1;
}
export declare function fileScopeOf(path: string): ScrubScope;
export declare function applyScrubRules(content: string, rules: readonly ScrubRule[], fileScope: ScrubScope): string;
export declare function parseStructuredRedactionPlan(value: unknown): StructuredRedactionPlan;
export declare function applyStructuredRedactionPlan(content: string, plan: StructuredRedactionPlan): string;
export declare function loadConnectorScrubRules(packageRoot: string, connector: string): Promise<ScrubRule[]>;
//# sourceMappingURL=scrubber.d.ts.map