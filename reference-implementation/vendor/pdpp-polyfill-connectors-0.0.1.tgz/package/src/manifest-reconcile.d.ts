export interface ManifestStreams {
    /** Stream names declared in the manifest, preserving order. */
    declared: string[];
}
export interface SchemaStreams {
    /** Stream names registered in the connector's SCHEMAS object. */
    registered: string[];
}
export interface EmittedStreams {
    /** Stream-name literals scanned from connector source. */
    emitted: string[];
}
export interface ReconcileReport {
    connector: string;
    declared: string[];
    emitted: string[];
    /** Streams declared in the manifest but neither schema-registered nor emitted. */
    missing_emit: string[];
    /** Streams emitted but not in manifest. */
    missing_manifest: string[];
    /** Streams emitted but not in SCHEMAS — runtime won't validate them. */
    missing_schema: string[];
    /** True iff every set is consistent (3 empty drift arrays). */
    ok: boolean;
    registered: string[];
}
export declare function parseManifestStreams(json: string): ManifestStreams;
export declare function parseSchemaStreams(source: string): SchemaStreams;
export declare function scanEmittedStreams(sources: readonly string[]): EmittedStreams;
export declare function reconcile(args: {
    connector: string;
    declared: readonly string[];
    registered: readonly string[];
    emitted: readonly string[];
}): ReconcileReport;
export interface ReconcileFromDiskArgs {
    connector: string;
    /** Connector source files to scan for emit-stream literals. Typically
     *  `connectors/<name>/index.ts` and `connectors/<name>/parsers.ts`,
     *  but the caller decides — passing an empty list yields an empty
     *  emitted[] which can be intentional for static-only connectors. */
    emitSourcePaths: readonly string[];
    manifestPath: string;
    /** May be null for connectors that don't ship a schemas.ts. Reported
     *  as empty registered[] in that case. */
    schemaPath: string | null;
}
/** Top-level convenience: reads files from disk, runs the parsers, and
 *  returns the reconciliation report. CLI uses this; tests build the
 *  args directly via the parse* helpers above. */
export declare function reconcileFromDisk(args: ReconcileFromDiskArgs): ReconcileReport;
//# sourceMappingURL=manifest-reconcile.d.ts.map