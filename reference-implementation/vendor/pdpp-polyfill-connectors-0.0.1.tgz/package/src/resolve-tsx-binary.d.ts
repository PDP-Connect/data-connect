/**
 * Walk up from `startDir` looking for `node_modules/.bin/tsx`.
 *
 * Connector children are TypeScript entrypoints, so the collector spawns them
 * through `tsx`. Spawning the bare string `"tsx"` delegates the lookup to the
 * child's PATH, which is only correct when the collector itself was launched
 * from a shell whose PATH already contained `node_modules/.bin` — true under
 * `pnpm run`, false under a systemd unit, a launchd agent, or any supervisor
 * that starts the collector with a minimal environment. In that posture the
 * spawn fails with a bare `spawn tsx ENOENT` that names neither the cause nor
 * the fix. Resolving the absolute path here removes the PATH dependency from
 * the success path entirely.
 *
 * Returns `null` when no `tsx` is reachable; callers surface
 * `TSX_MISSING_MESSAGE` rather than attempting a spawn that can only fail.
 */
export declare function resolveTsxBinary(startDir?: string): string | null;
/**
 * Actionable hint replacing the opaque `spawn tsx ENOENT`. Kept textually in
 * sync with `packages/cli/src/collector/runner.ts`, which cannot import this
 * module (see that file's note on the slim-CLI invariant).
 */
export declare const TSX_MISSING_MESSAGE: string;
/**
 * Resolve the command used to spawn a connector child.
 *
 * An explicitly configured command (operator override, or a non-`tsx` runtime
 * such as `node`) is passed through untouched — only the implicit `tsx`
 * default is resolved to an absolute path. Throws `TSX_MISSING_MESSAGE` when
 * `tsx` is the command but no binary is reachable, so the failure names the
 * missing dependency instead of surfacing an ENOENT from deep inside spawn.
 */
export declare function resolveConnectorCommand(command: string, resolveBinary?: (startDir?: string) => string | null): string;
//# sourceMappingURL=resolve-tsx-binary.d.ts.map