// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * Closed, structural browser-surface evidence. This module intentionally
 * accepts no text, URL, selector, DOM, fixture, or account-derived fields.
 * The reference runtime independently revalidates this shape before durable
 * persistence, so a connector cannot widen the evidence contract.
 */
const MAX_STRUCTURAL_COUNT = 1_000_000;
/** Map the runtime's non-sensitive launch kind to durable evidence vocabulary. */
export function browserSurfaceManagedState(value) {
    switch (value) {
        case "managed_neko":
            return "managed";
        case "legacy_remote_cdp":
            return "legacy_remote";
        case "isolated_local":
            return "isolated";
        default:
            return "unknown";
    }
}
function boundedCount(value) {
    if (!(typeof value === "number" && Number.isSafeInteger(value) && value >= 0)) {
        return 0;
    }
    return Math.min(value, MAX_STRUCTURAL_COUNT);
}
function isKind(value) {
    return (value === "chase_current_activity" || value === "usaa_transaction_export");
}
function isManagedState(value) {
    return (value === "isolated" ||
        value === "legacy_remote" ||
        value === "managed" ||
        value === "unknown");
}
function isRoute(value) {
    return (value === "expected" || value === "interstitial" || value === "unknown");
}
function isWaitOutcome(value) {
    return (value === "not_needed" ||
        value === "resolved" ||
        value === "timed_out" ||
        value === "unknown");
}
/**
 * Return null unless every categorical input is part of the closed contract.
 * Counts are normalized to bounded integers; all unrecognized source values
 * are rejected rather than copied into durable output.
 */
export function buildBrowserSurfaceDiagnostic(input) {
    if (!(isKind(input.kind) &&
        isManagedState(input.managedSurface) &&
        isRoute(input.route) &&
        isWaitOutcome(input.waitOutcome))) {
        return null;
    }
    const dashboardMarkerCount = boundedCount(input.dashboardMarkerCount);
    const activityTableMarkerCount = boundedCount(input.activityTableMarkerCount);
    const accountDetailMarkerCount = boundedCount(input.accountDetailMarkerCount);
    const transactionMarkerCount = boundedCount(input.transactionMarkerCount);
    const navigationMarkerCount = boundedCount(input.navigationMarkerCount);
    const targetCount = boundedCount(input.targetCount);
    const parserCount = boundedCount(input.parserCount);
    const verifiedEmptyMarkerCount = boundedCount(input.verifiedEmptyMarkerCount);
    const recognizedMarkerCount = dashboardMarkerCount +
        activityTableMarkerCount +
        accountDetailMarkerCount +
        transactionMarkerCount +
        navigationMarkerCount;
    let posture = "unexpected";
    if (input.kind === "chase_current_activity") {
        if (parserCount > 0 || targetCount > 0) {
            posture = "recognized";
        }
        else if (verifiedEmptyMarkerCount > 0) {
            posture = "verified_empty";
        }
        else if (dashboardMarkerCount > 0 || activityTableMarkerCount > 0) {
            posture = "parser_zero";
        }
    }
    else if (targetCount > 0 || recognizedMarkerCount > 0) {
        posture = "recognized";
    }
    return {
        account_detail_marker_count: accountDetailMarkerCount,
        activity_table_marker_count: activityTableMarkerCount,
        dashboard_marker_count: dashboardMarkerCount,
        managed_surface: input.managedSurface,
        navigation_marker_count: navigationMarkerCount,
        parser_count: parserCount,
        phase: input.kind === "chase_current_activity"
            ? "final_snapshot"
            : "no_export_affordance",
        posture,
        read_count: boundedCount(input.readCount),
        route: input.route,
        surface: input.kind,
        target_count: targetCount,
        transaction_marker_count: transactionMarkerCount,
        verified_empty_marker_count: verifiedEmptyMarkerCount,
        wait_outcome: input.waitOutcome,
    };
}
