/**
 * The one place that lists which provider-auth adapter modules exist, and
 * the only place that registers them.
 *
 * Registration is inverted rather than self-registering: each adapter module
 * exports its `ProviderAuthAdapter` object and the `exchanger_kind` it
 * implements, and this barrel binds the two. That keeps every adapter's
 * dependency on provider-auth-adapter.ts type-only, so there is no runtime
 * import cycle (an adapter that imported `registerProviderAuthAdapter` as a
 * value would close the loop registry -> adapter -> registry).
 *
 * Registration is also deterministic rather than import-order-dependent:
 * the list below is eagerly loaded once, memoized, before any resolution, so
 * a lookup never depends on which caller imported an adapter file first.
 * Adding a new `exchanger_kind` means adding one entry here — nowhere else.
 */
import { type ProviderAuthAdapter } from "./provider-auth-adapter.ts";
export declare function loadProviderAuthAdapterModules(): Promise<void>;
/**
 * Resolves a manifest-declared `exchanger_kind` to its adapter. Always
 * awaits the deterministic eager-load of every module above first, so the
 * result never depends on call order or on which caller ran first.
 */
export declare function resolveProviderAuthAdapter(kind: string): Promise<ProviderAuthAdapter | null>;
/**
 * Test-only: drops both the memoized eager-load and the registry contents so
 * a harness can re-run registration from scratch.
 */
export declare function _resetProviderAuthAdapterRegistryForTests(): void;
//# sourceMappingURL=provider-auth-adapters.d.ts.map