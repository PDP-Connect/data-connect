// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
/**
 * Polyfill scheduler runner.
 *
 * Wraps reference-implementation/runtime/scheduler.js with:
 *   - ntfy notifications on INTERACTION and on run failures
 *   - inbox integration (INTERACTION → parkInteraction → wait)
 *   - per-connector interval + jitter
 *   - persistent sync state via RS /v1/state/{connector_id}
 *   - persistent scheduler history and last-run interval gates
 */
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { notifyInboxItem, notifyOvernightSummary, } from "./ntfy.js";
import { getConnectorPaths, issueOwnerToken, readManifest, registerManifest, } from "./orchestrator.js";
const __dirname = dirname(fileURLToPath(import.meta.url));
const REFERENCE_IMPL_DIR = join(__dirname, "..", "..", "..", "reference-implementation");
const DEFAULT_INTERVALS = {
    ynab: 4 * 60 * 60 * 1000, // 4h
    gmail: 30 * 60 * 1000, // 30m
    chatgpt: 6 * 60 * 60 * 1000, // 6h
    usaa: 4 * 60 * 60 * 1000, // 4h
    amazon: 12 * 60 * 60 * 1000, // 12h
};
function jitter(ms) {
    const pct = 0.25; // ±25%
    const delta = (Math.random() * 2 - 1) * ms * pct;
    return Math.max(1000, Math.round(ms + delta));
}
export function millisecondsUntilNextNightlySummary(now, hour = 7, minute = 0) {
    const next = new Date(now);
    next.setHours(hour, minute, 0, 0);
    if (next.getTime() <= now.getTime()) {
        next.setDate(next.getDate() + 1);
    }
    return next.getTime() - now.getTime();
}
export async function notifyOvernightSummarySafely(summary, notify = notifyOvernightSummary) {
    try {
        await notify(summary);
    }
    catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.error(`[scheduler] failed to send overnight summary: ${message}`);
    }
}
export function scheduleNightlySummary(handle, { hour = 7, minute = 0, now = () => new Date(), notify = notifyOvernightSummary, setTimeout: setTimer = setTimeout, clearTimeout: clearTimer = (pendingTimer) => {
    clearTimeout(pendingTimer);
}, } = {}) {
    let stopped = false;
    let timer;
    const scheduleNext = () => {
        if (stopped) {
            return;
        }
        const delayMs = millisecondsUntilNextNightlySummary(now(), hour, minute);
        timer = setTimer(() => {
            Promise.resolve()
                .then(async () => {
                const summary = await handle.summarize();
                await notifyOvernightSummarySafely(summary, notify);
                scheduleNext();
            })
                .catch((err) => {
                const message = err instanceof Error ? err.message : String(err);
                console.error(`[scheduler] failed to build overnight summary: ${message}`);
                scheduleNext();
            });
        }, delayMs);
        timer.unref?.();
    };
    scheduleNext();
    return {
        stop: () => {
            stopped = true;
            if (timer) {
                clearTimer(timer);
            }
        },
    };
}
export async function loadDefaultSchedulerPersistenceStore() {
    const { initPostgresStorage, resolveStorageBackend } = (await import(__rewriteRelativeImportExtension(join(REFERENCE_IMPL_DIR, "server/postgres-storage.js"))));
    await initPostgresStorage(resolveStorageBackend());
    const { getDefaultSchedulerStore } = (await import(__rewriteRelativeImportExtension(join(REFERENCE_IMPL_DIR, "server/stores/scheduler-store.js"))));
    return getDefaultSchedulerStore();
}
export function resolveSchedulerPersistenceStore(schedulerStore, loadDefaultStore = loadDefaultSchedulerPersistenceStore) {
    if (schedulerStore === false) {
        return Promise.resolve(null);
    }
    if (schedulerStore) {
        return Promise.resolve(schedulerStore);
    }
    return loadDefaultStore();
}
export async function startPolyfillScheduler({ asUrl, rsUrl, connectors, subjectId = "owner_local", inboxHandler, nightlySummary, schedulerStore: schedulerStoreOption, }) {
    const { createScheduler } = (await import(__rewriteRelativeImportExtension(join(REFERENCE_IMPL_DIR, "runtime/scheduler.js"))));
    const { loadSyncState } = (await import(__rewriteRelativeImportExtension(join(REFERENCE_IMPL_DIR, "runtime/index.ts"))));
    const schedulerStore = await resolveSchedulerPersistenceStore(schedulerStoreOption);
    // Register all requested manifests first
    const schedules = [];
    const ownerToken = await issueOwnerToken(asUrl, subjectId);
    for (const name of connectors) {
        const manifest = readManifest(name);
        const { connectorPath } = getConnectorPaths(name);
        try {
            await registerManifest(asUrl, manifest);
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            console.error(`[scheduler] failed to register ${name}: ${message}`);
            continue;
        }
        schedules.push({
            connectorId: manifest.connector_id,
            connectorPath,
            manifest,
            ownerToken,
            intervalMs: jitter(DEFAULT_INTERVALS[name] || 60 * 60 * 1000),
            maxRetries: 2,
            grantAccessMode: "continuous",
        });
    }
    const schedulerArgs = {
        connectors: schedules,
        rsUrl,
        onInteraction: async (msg) => {
            // Forward to inbox (parks until responded or timeout). The inboxHandler
            // is expected to return an INTERACTION_RESPONSE-shaped object.
            const itemId = await inboxHandler.park(msg);
            // Build the notice without setting `message: undefined`. Under
            // exactOptionalPropertyTypes, `{ message: undefined }` ≠ `{}`; we want
            // the key to be absent when there's no message.
            const notice = msg.message === undefined
                ? { kind: msg.kind, connector_id: msg.connectorId || "unknown" }
                : {
                    kind: msg.kind,
                    connector_id: msg.connectorId || "unknown",
                    message: msg.message,
                };
            await notifyInboxItem(notice);
            return inboxHandler.waitFor(itemId);
        },
        onRunComplete: (record) => {
            console.error(`[scheduler] run ${record.connectorId} status=${record.status} records=${String(record.recordsEmitted)}`);
        },
        getState: async (connectorId) => {
            try {
                return await loadSyncState({ connectorId, ownerToken, rsUrl });
            }
            catch {
                return null;
            }
        },
        setState: async () => {
            // Scheduler-side no-op: runConnector with persistState=true already
            // handles state via /v1/state/{connector_id}. This hook is retained for
            // symmetry but isn't needed.
        },
    };
    if (schedulerStore) {
        schedulerArgs.schedulerStore = schedulerStore;
    }
    const scheduler = createScheduler(schedulerArgs);
    scheduler.start();
    let nightlySummarySchedule;
    const handle = {
        scheduler,
        stop: () => {
            nightlySummarySchedule?.stop();
            scheduler.stop();
        },
        summarize() {
            const stats = scheduler.getStats();
            const counts = {};
            const failures = [];
            for (const [cid, s] of Object.entries(stats)) {
                counts[cid] =
                    `${String(s.succeeded)}/${String(s.totalRuns)} succeeded, ${String(s.totalRecords)} records`;
                if (s.lastRun?.status === "failed") {
                    failures.push(`${cid}: ${s.lastRun.error || "unknown"}`);
                }
            }
            return Promise.resolve({
                counts,
                failures,
                ok: failures.length === 0,
            });
        },
        async notifySummary() {
            const sum = await this.summarize();
            await notifyOvernightSummarySafely(sum);
            return sum;
        },
    };
    if (nightlySummary !== false) {
        nightlySummarySchedule = scheduleNightlySummary(handle, nightlySummary);
    }
    return handle;
}
