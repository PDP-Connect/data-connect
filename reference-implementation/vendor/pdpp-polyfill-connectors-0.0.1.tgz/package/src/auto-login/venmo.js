// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { redactTransportDetail } from "@pdpp/connector-protocol/http-retry";
import { DEADLINE_TIMEOUT, manualBrowserLogin, withDeadline, } from "../browser-handoff.js";
import { locatorIsVisible } from "./locator-helpers.js";
/** Same bound `index.ts`'s `errorDetail` applies after redaction — keeps one link short and legible without truncating mid-token. */
const PROBE_TRANSPORT_DETAIL_MAX = 200;
/**
 * Per-probe bounds for the page-context account probe — see
 * {@link probeVenmoAccount}. The outer (`evaluate`) bound is deliberately
 * longer than the inner (`fetch`) one so a healthy page reports its own abort
 * as a clean transport error rather than racing the outer deadline.
 */
const PROBE_FETCH_TIMEOUT_MS = 8000;
const PROBE_EVALUATE_TIMEOUT_MS = 12_000;
/**
 * Fault-class name for a transport failure discovered by the PRE-submit
 * session probe — see {@link probeVenmoAccount}'s B4 doc for why this must
 * stay distinct from the post-submit name below.
 */
export const VENMO_PROBE_TRANSPORT_ERROR = "venmo_probe_transport_error";
/** Fault-class name for a transport failure discovered by the POST-submit probe — see the B4 doc. Deliberately excluded from `VENMO_RETRYABLE_PATTERN`. */
export const VENMO_POST_SUBMIT_PROBE_TRANSPORT_ERROR = "venmo_post_submit_probe_transport_error";
/** Fault-class name for {@link ensureVenmoOrigin} failing to land the page on the venmo.com origin — see that function's doc (production run_1787101857760). */
export const VENMO_ORIGIN_NAVIGATION_FAILED = "venmo_origin_navigation_failed";
/**
 * Fault-class name for the password screen never arriving after a successful
 * identifier submit on Venmo's two-step sign-in — see {@link fillVenmoPassword}.
 *
 * Deliberately a distinct, named, NON-retryable-by-omission class rather than
 * a fall-through: the identifier has been sent to Venmo at this point, so a
 * blind retry re-enters `ensureVenmoSession` and re-submits it. It is also
 * distinct from the OTP vocabulary on purpose — a missing password field is
 * not evidence Venmo asked for a code, and treating it as one is exactly the
 * fabricated-prompt defect class this file's OTP path already guards against.
 *
 * Declared here rather than beside its sibling sign-in constants below because
 * {@link VENMO_DECLARED_REASON_TOKENS} is built eagerly at module load and
 * would read it from the temporal dead zone otherwise.
 */
export const VENMO_PASSWORD_SCREEN_TIMEOUT = "venmo_password_screen_timeout";
/** The SMS offer rendered, but its Remember this device control was not usable. */
export const VENMO_SMS_OFFER_CHECKBOX_UNAVAILABLE = "venmo_sms_offer_checkbox_unavailable";
/** The SMS offer rendered, but its Send code control was not usable. */
export const VENMO_SMS_OFFER_SEND_CODE_UNAVAILABLE = "venmo_sms_offer_send_code_unavailable";
/** Venmo accepted Send code but did not render a usable OTP input within the bound. */
export const VENMO_SMS_OFFER_CODE_INPUT_TIMEOUT = "venmo_sms_offer_code_input_timeout";
/**
 * Venmo refused the sign-in on an INVISIBLE bot score, not on the credential.
 *
 * reCAPTCHA Enterprise v3 renders no widget and no checkbox — it scores the
 * session and returns a verdict the page acts on silently. So the visible-frame
 * detector ({@link CAPTCHA_FRAME_SELECTOR}) correctly finds nothing, no error
 * copy is rendered, and the submit control simply stays in its loading state.
 * That signature is identical to a slow provider unless it is named.
 *
 * Deliberately NOT the ordinary `captcha` handoff vocabulary: that path asks
 * the owner to solve something. There is nothing to solve here — v3 scores the
 * browser, so an owner staring at the same automated session changes nothing.
 * Conflating the two would send them to a challenge that does not exist.
 */
export const VENMO_SCORING_CHALLENGE = "venmo_invisible_scoring_challenge";
/**
 * This connector's classifying fault-class names — single source of truth,
 * built from the same constants every throw site below uses, so it cannot
 * drift from the vocabulary it names. Every one of these is >=24 chars and
 * therefore invisible to an owner today: `runtime/connector-gap-bounding.ts`'s
 * `boundConnectorErrorMessage` redacts any bare token this long
 * (`stderr-redact.ts`'s `LONG_OPAQUE_RE`, an entropy heuristic for
 * unlabelled API keys) with no notion that a categorical, PII-free reason
 * code is not the kind of secret that rule exists to catch — the same
 * defect class production hit for HEB (`heb_session_failed: [REDACTED]`,
 * see `runtime/stderr-redact.ts`'s `declaredReasonTokens` doc) and, on
 * 2026-08-18, for Venmo's own first live run (`run_1787101857760`:
 * `venmo_session_failed: [REDACTED]: Failed to fetch` — the eaten token was
 * exactly `VENMO_PROBE_TRANSPORT_ERROR`). Consumed by
 * `runtime/declared-reason-tokens.ts` on the RS side so these survive that
 * redaction pass without a hand-copied, driftable string list on the other
 * side of the process boundary.
 */
export const VENMO_DECLARED_REASON_TOKENS = new Set([
    VENMO_PROBE_TRANSPORT_ERROR,
    VENMO_POST_SUBMIT_PROBE_TRANSPORT_ERROR,
    VENMO_ORIGIN_NAVIGATION_FAILED,
    VENMO_PASSWORD_SCREEN_TIMEOUT,
    VENMO_SCORING_CHALLENGE,
    VENMO_SMS_OFFER_CHECKBOX_UNAVAILABLE,
    VENMO_SMS_OFFER_SEND_CODE_UNAVAILABLE,
    VENMO_SMS_OFFER_CODE_INPUT_TIMEOUT,
]);
const HOME_URL = "https://venmo.com/";
const LOGIN_URL = "https://venmo.com/login";
/**
 * The probe hits the SAME endpoint `collect()` does — `api.venmo.com/v1/account`
 * (`connectors/venmo/parsers.ts`'s `API_BASE`), the one that actually returns
 * the `data.user.id` JSON this function parses.
 *
 * It used to point at `https://venmo.com/account`, which is not that endpoint
 * and never returned JSON at all. That URL is Venmo's own web app route, and
 * as of 2026-08-18 it answers a redirect chain that terminates on plain HTTP:
 *
 *   https://venmo.com/account          -> 302 https://account.venmo.com/account
 *   https://account.venmo.com/account  -> 307 http://account.venmo.com:8080/
 *
 * A `fetch` issued from the HTTPS `venmo.com` page follows those redirects and
 * is then blocked by the browser's mixed-content rule on the final http:// hop.
 * A blocked redirect surfaces to page JS as exactly `TypeError: Failed to
 * fetch` — indistinguishable, from inside the callback, from a network
 * failure. That is production `run_1787108832272`'s
 * `venmo_probe_transport_error: Failed to fetch`, on a host where
 * `https://venmo.com/` itself was reachable and returning 200.
 *
 * The origin guard below is still required and still correct: `api.venmo.com`
 * grants a credentialed cross-origin fetch only to `Access-Control-Allow-Origin:
 * https://venmo.com`. The previous URL made that guard look like the whole
 * story, because a same-origin `venmo.com` URL needs no CORS grant at all —
 * so the guard could never have fixed a fault the URL itself was causing.
 */
export const ACCOUNT_PROBE_URL = "https://api.venmo.com/v1/account";
/**
 * The ONE origin a credentialed page-context fetch may run from. Not a
 * stylistic preference: `api.venmo.com` answers a `credentials:"include"`
 * cross-origin fetch with `Access-Control-Allow-Origin: https://venmo.com`,
 * and the CORS spec forbids the wildcard form entirely once credentials are
 * involved — the header must echo one exact origin. So `id.venmo.com` and
 * `account.venmo.com` are real Venmo hosts that still cannot issue this
 * fetch. This value is the fetch PRECONDITION, not the trust boundary; see
 * {@link VENMO_FAMILY_HOSTS} for the latter.
 */
const VENMO_ORIGIN = "https://venmo.com";
/**
 * Venmo's real first-party host family — the hosts a correct, non-hostile
 * sign-in flow legitimately parks the page on before {@link ensureVenmoOrigin}
 * navigates back to {@link VENMO_ORIGIN}.
 *
 * Each entry is load-bearing, verified against live behavior 2026-08-18:
 *   - `venmo.com`         the canonical app origin and the only CORS-granted one.
 *   - `www.venmo.com`     the marketing/apex alias venmo.com itself redirects between.
 *   - `id.venmo.com`      where sign-in actually happens (`id.venmo.com/signin?...`).
 *   - `account.venmo.com` where a signed-in `venmo.com/account` request lands
 *                         (302 -> account.venmo.com, per ACCOUNT_PROBE_URL's doc).
 *   - `api.venmo.com`     the JSON API `collect()` and the probe both read.
 *
 * An EXACT host set, deliberately not a suffix test. `"evil-venmo.com"` and
 * `"notvenmo.com"` both satisfy `endsWith("venmo.com")`, so a suffix match
 * would hand an attacker-controlled page the same "this is Venmo, carry on"
 * verdict as the real thing. Membership is `Set.has(hostname)` — the same
 * shape `streaming-target-registration.ts`'s `ALLOWED_CDP_TARGET_HOSTS` uses
 * for the same reason.
 */
const VENMO_FAMILY_HOSTS = new Set([
    "account.venmo.com",
    "api.venmo.com",
    "id.venmo.com",
    "venmo.com",
    "www.venmo.com",
]);
/**
 * Whether `url` is a page on Venmo's own https host family.
 *
 * HTTPS is required, not incidental: `venmo.com`'s own redirect chain
 * terminates on `http://account.venmo.com:8080/` (see {@link ACCOUNT_PROBE_URL}),
 * and a plain-http Venmo page is both a downgraded origin and one whose
 * credentialed fetch the browser's mixed-content rule blocks anyway. Treating
 * it as "close enough to Venmo" would re-admit exactly the fault that
 * production `run_1787108832272` recorded.
 */
export function isVenmoFamilyUrl(url) {
    let parsed;
    try {
        parsed = new URL(url);
    }
    catch {
        // `about:blank` and any other unparseable/opaque page land here.
        return false;
    }
    if (parsed.protocol !== "https:") {
        return false;
    }
    return VENMO_FAMILY_HOSTS.has(parsed.hostname);
}
/** The host Venmo actually serves sign-in, captcha, and OTP from. */
const VENMO_IDENTITY_HOST = "id.venmo.com";
/**
 * Whether `url` is a page the owner can complete sign-in ON, right now.
 *
 * Strictly narrower than {@link isVenmoFamilyUrl}: this asks "is there a live
 * sign-in flow on this page worth preserving", not "is this Venmo". The
 * distinction is load-bearing for {@link waitForManualLogin}, which must
 * navigate a page that CANNOT be signed in from (`about:blank` on a fresh
 * run, or the logged-out `venmo.com/` the pre-handoff probe leaves behind)
 * while leaving a live `id.venmo.com` screen — the captcha or OTP the owner
 * was just asked to solve — exactly as it stands.
 */
export function isVenmoSignInUrl(url) {
    let parsed;
    try {
        parsed = new URL(url);
    }
    catch {
        return false;
    }
    return (parsed.protocol === "https:" && parsed.hostname === VENMO_IDENTITY_HOST);
}
/**
 * Venmo's identifier field, across both sign-in generations.
 *
 * `input[name="login_email"]` is the CURRENT one and the reason this connector
 * had collected zero records ever. Read live over CDP during production
 * `run_1787164654406`: `https://id.venmo.com/signin?...` renders exactly two
 * enabled, visible inputs — `{type: email, name: "login_email"}` and an unnamed
 * `{type: password}` — under the copy "Log in" / "Enter email, mobile, or
 * username" / "Next". None of the three prior candidates
 * (`phoneEmailUsername`, `#username`, `[autocomplete="username"]`) match
 * `login_email`, so `loginWithSavedCredentials` found no identifier field,
 * concluded the sign-in form had not rendered, and handed off to the owner on
 * every run regardless of the saved credentials being present and correct.
 *
 * The older candidates are KEPT, not replaced: they cost one selector-union
 * branch each, and Venmo demonstrably serves more than one sign-in generation
 * (this is the second shape this file has had to learn). A union that still
 * matches the previous shape degrades to the old behavior rather than to a
 * handoff if Venmo rolls back or A/B-splits.
 */
const USERNAME_SELECTOR = 'input[name="login_email"], input[name="phoneEmailUsername"], input#username, input[autocomplete="username"]';
const PASSWORD_SELECTOR = 'input[name="password"], input#password, input[type="password"]';
/**
 * The step-one ("Next") control on Venmo's two-step sign-in.
 *
 * Venmo now splits sign-in across two screens: identifier -> `Next` ->
 * password. The live page carries a submit button with id `btnNext`, whose
 * accessible name ("Next") {@link SUBMIT_BUTTON_NAME_RE} already matches — so
 * this id is a FALLBACK for the case where the accessible name is absent,
 * localized, or rendered as an icon, not the primary path. See
 * {@link clickVenmoLoginSubmit}.
 */
const STEP_ONE_SUBMIT_SELECTOR = "#btnNext";
/**
 * How long to wait for the password screen after submitting the identifier.
 *
 * A real bound, not a sleep: the prior code slept a fixed 1500ms and then
 * looked once, so a slower-than-1.5s second screen was misread as "no password
 * field" and a faster one wasted the remainder. This is the ceiling on a wait
 * that resolves as soon as the field is actually visible.
 */
const PASSWORD_SCREEN_TIMEOUT_MS = 15_000;
/**
 * Copy/markup that means a human-verification challenge is blocking the flow.
 *
 * Venmo's own sign-in page embeds a reCAPTCHA iframe from `paypalobjects.com`
 * (confirmed live, `run_1787164654406`). Solving it is explicitly NOT a goal:
 * when one blocks progress the connector hands the page to the owner via the
 * existing `manual_action` path with `reason: "captcha"`, the same shape
 * reddit/amazon/chatgpt use. The alternative failure modes are the two this
 * must never produce — a silent failure, or a spin.
 */
const CAPTCHA_FRAME_SELECTOR = 'iframe[src*="recaptcha"], iframe[src*="paypalobjects.com"], iframe[title*="recaptcha" i], div.g-recaptcha';
const OTP_SELECTOR = 'input[name="otp"], input[name="code"], input[autocomplete="one-time-code"], input[name="smsCode"]';
/**
 * The screen Venmo renders before it has sent an SMS. This is deliberately
 * distinct from {@link OTP_SELECTOR}: the captured offer has no code input.
 *
 * Retained production capture 2026-08-27T03-23-25-318Z:
 * - `.listHeader`: "To verify it’s you, we’ll text you a code"
 * - `.venmoRemeberMeDevice input[type="checkbox"]`
 * - `button[data-testid="button-next"][name="Send code"][type="submit"]`
 */
const SMS_OFFER_TEXT_RE = /to verify it.?s you, we.?ll text you a code/i;
const SMS_OFFER_REMEMBER_DEVICE_SELECTOR = '.venmoRemeberMeDevice input[type="checkbox"]';
const SMS_OFFER_SEND_CODE_SELECTOR = 'button[data-testid="button-next"][name="Send code"][type="submit"]';
const SMS_OFFER_CODE_INPUT_TIMEOUT_MS = 15_000;
const SUBMIT_BUTTON_NAME_RE = /^(log in|sign in|continue|next)$/i;
/**
 * Copy that ACCOMPANIES a code-entry screen. Necessary but never sufficient:
 * "we sent"/"we texted" is ordinary Venmo prose that also appears on device-
 * approval screens and notification banners, none of which can accept a code.
 * See {@link hasUsableVenmoOtpInput}.
 */
const OTP_PROMPT_TEXT_RE = /verification code|enter the code|we (?:sent|texted)|2-step|two-factor/i;
/**
 * A split per-digit layout has one input per digit. Venmo's current web
 * sign-in renders a single 6-digit field, but the bound keeps a redesign to a
 * boxed layout classifiable instead of silently unrecognized. Anything larger
 * is a page full of inputs, not a code entry.
 */
const MAX_SPLIT_CODE_DIGITS = 10;
const MANUAL_LOGIN_WITHOUT_CREDENTIALS_MESSAGE = "No optional Venmo sign-in details were provided. Sign in to Venmo in the secure browser, then respond success.";
/**
 * Anything the owner could actually act on during a handoff: the sign-in form
 * itself, a code box, or a rendered human-verification challenge.
 *
 * Deliberately a UNION rather than the sign-in form alone. The handoff exists
 * precisely for the screens this connector could not drive, so waiting only for
 * `USERNAME_SELECTOR`/`PASSWORD_SELECTOR` would time out on the captcha and OTP
 * handoffs — the two cases most likely to need a human — and hand over an
 * unpainted page anyway.
 */
const ACTIONABLE_HANDOFF_SELECTOR = `${USERNAME_SELECTOR}, ${PASSWORD_SELECTOR}, ${OTP_SELECTOR}, ${CAPTCHA_FRAME_SELECTOR}`;
/**
 * Appended to a handoff message when the page never painted anything the owner
 * could act on. Names the state and the one action that recovers it, instead of
 * leaving them to guess at an empty card.
 */
const HANDOFF_BLANK_SURFACE_SUFFIX = "(Venmo's sign-in screen has not finished loading — if the browser shows an empty card, reload the page to bring the form back.)";
/**
 * How long to wait for a handoff page to paint something actionable.
 *
 * Bounds a wait that resolves the instant the page is usable; it is not a
 * sleep. Sized well under the 1800s handoff window so a page that never paints
 * still reaches the owner (with an honest message) rather than silently
 * consuming their whole window.
 */
const HANDOFF_PAINT_TIMEOUT_MS = 15_000;
/**
 * How long to wait for the submitted login to reach an OBSERVABLE outcome
 * before calling it incomplete. Not a poll-and-hope: the wait keys on the
 * submit control leaving its in-flight state, and expiring is reported as
 * "the login did not complete", never as a credential rejection.
 */
const POST_SUBMIT_SETTLE_TIMEOUT_MS = 30_000;
/** Gap between post-submit liveness polls. */
const POST_SUBMIT_POLL_INTERVAL_MS = 1000;
const LOGIN_LOCATOR_PROBES = [
    {
        id: "username",
        kind: "css",
        selector: USERNAME_SELECTOR,
        description: "Venmo username/phone/email field candidates used by the connector.",
    },
    {
        id: "password",
        kind: "css",
        selector: PASSWORD_SELECTOR,
        description: "Venmo password field candidates used by the connector.",
    },
    {
        id: "submit-role",
        kind: "role",
        role: "button",
        namePattern: SUBMIT_BUTTON_NAME_RE.source,
        nameFlags: "i",
        description: "Semantic log in/continue/next button candidate.",
    },
    {
        id: "otp",
        kind: "css",
        selector: OTP_SELECTOR,
        description: "OTP candidates; hidden fields must not trigger an OTP interaction.",
    },
    {
        id: "step-one-submit",
        kind: "css",
        selector: STEP_ONE_SUBMIT_SELECTOR,
        description: "Venmo's two-step identifier ('Next') control; absence means a one-screen or unrecognized form.",
    },
    {
        id: "captcha",
        kind: "css",
        selector: CAPTCHA_FRAME_SELECTOR,
        description: "Human-verification frames; presence explains a stalled password step but never blocks a healthy one.",
    },
];
/**
 * Ensure `page` is on the `venmo.com` origin before a credentialed
 * page-context fetch: `api.venmo.com`'s CORS allowlist grants
 * `credentials:"include"` only to `Access-Control-Allow-Origin:
 * https://venmo.com` (confirmed live 2026-08-10, /tmp/review-venmo-
 * browser-redesign-0810.md §1). `about:blank` has an opaque origin and
 * hard-fails the same fetch with `TypeError: Failed to fetch` — not a
 * session signal, a transport precondition. Every sibling browser
 * connector navigates before its first credentialed fetch
 * (reddit.ts:100, amazon.ts:90); this was the one that didn't.
 *
 * Production `run_1787101857760` (2026-08-18, the owner's first-ever Venmo
 * run — a brand-new persistent profile, so `page.url()` starts on
 * `about:blank`): the pre-submit probe threw
 * `venmo_probe_transport_error: Failed to fetch`. The prior version of this
 * function swallowed a failed `page.goto` with `.catch(() => undefined)` and
 * returned regardless of whether the navigation actually landed on
 * `venmo.com` — so a transient failure of THIS `goto` (not the eventual
 * fetch) silently left the page on its opaque `about:blank` origin, and the
 * caller's credentialed fetch then failed for a reason this function was
 * supposed to have already ruled out. Every DOM-probing sibling connector
 * (chase.ts's `probeSession`, reddit.ts's credential-less `isSessionLive`)
 * has the same swallowed `.catch`, but degrades gracefully: a `waitFor`/
 * `count` against an unnavigated page just times out to "not logged in".
 * Venmo's probe is `fetch`-based, so the same swallowed failure surfaces as
 * an opaque transport throw instead of a clean liveness signal — verifying
 * the navigation actually landed is the fix that closes that gap for a
 * fetch-based probe specifically.
 *
 * This function checks TWO different facts, and conflating them is what broke
 * production `run_1787151856448`:
 *
 *   1. PRECONDITION — the page must END on `https://venmo.com`, because that
 *      is the single origin `api.venmo.com` grants a credentialed fetch to
 *      (see {@link VENMO_ORIGIN}). Nothing weaker satisfies CORS.
 *   2. TRUST — landing on another of Venmo's OWN hosts
 *      ({@link VENMO_FAMILY_HOSTS}) is normal, expected behavior after a real
 *      sign-in; landing off that family entirely is not.
 *
 * The first version tested only (1) and treated any miss as fatal, so an owner
 * who genuinely signed in at `id.venmo.com` — the correct flow — had the run
 * terminalled by the guard meant to protect it. A guard that fires on correct
 * behavior teaches operators to ignore it, so the family case now re-navigates
 * instead of throwing, while a landing outside the family still fails loudly.
 */
export async function ensureVenmoOrigin(page) {
    let currentOrigin = null;
    try {
        currentOrigin = new URL(page.url()).origin;
    }
    catch {
        currentOrigin = null;
    }
    if (currentOrigin === VENMO_ORIGIN) {
        return;
    }
    await page
        .goto(HOME_URL, { waitUntil: "domcontentloaded", timeout: 30_000 })
        .catch(() => undefined);
    const landedUrl = page.url();
    let landedOrigin = null;
    try {
        landedOrigin = new URL(landedUrl).origin;
    }
    catch {
        landedOrigin = null;
    }
    // A landing anywhere in Venmo's own host family is CORRECT behavior, not a
    // fault. Production `run_1787151856448` (connection
    // cin_94f4a295dda3f17d0f307a33), captured via PDPP_BROWSER_SURFACE_DIAGNOSTICS:
    //   interaction_start    -> https://id.venmo.com/signin
    //   interaction_response -> https://account.venmo.com/   (status: success)
    // The owner completed a real sign-in and this guard terminalled the run on
    // the SUCCESS page.
    //
    // `venmo.com` is still the only origin the credentialed `api.venmo.com`
    // fetch can run from (CORS forbids a wildcard once credentials are sent), so
    // a family host is not "good enough" to return on — it is grounds to
    // navigate once more rather than to fail. Bounded to exactly one extra
    // attempt: no loop, and a non-family landing gets no retry at all.
    //
    // Honest limit: if Venmo ever 302s a signed-in `venmo.com/` request to
    // `account.venmo.com` DETERMINISTICALLY, this retry cannot converge and the
    // run fails with the named error. That is the correct failure — it is a real
    // inability to satisfy the fetch precondition, reported as such, rather than
    // a silent proceed into an opaque `TypeError: Failed to fetch`. The probe
    // that follows is the actual evidence of session liveness; this guard only
    // guarantees that probe runs from an origin where a negative result MEANS
    // something.
    if (landedOrigin !== VENMO_ORIGIN && isVenmoFamilyUrl(landedUrl)) {
        await page
            .goto(HOME_URL, { waitUntil: "domcontentloaded", timeout: 30_000 })
            .catch(() => undefined);
        try {
            landedOrigin = new URL(page.url()).origin;
        }
        catch {
            landedOrigin = null;
        }
    }
    if (landedOrigin !== VENMO_ORIGIN) {
        // Named distinctly from `venmo_probe_transport_error`/`venmo_transport_error`
        // (the callers' own catch-and-wrap throws) so this fault's cause is legible
        // on its own — "navigation to venmo.com did not land" rather than a bare
        // "Failed to fetch" with no indication the origin was never established.
        // Still retryable: this is the same class of transient-navigation fault
        // VENMO_RETRYABLE_PATTERN already treats as safe to retry pre-submit, and
        // both callers wrap this in their own try/catch that classifies it via
        // that pattern the same way as any other transport error.
        // `landedOrigin` is an ORIGIN (scheme+host+port), never a full URL — no
        // path, query, or fragment, so no session token or account identifier can
        // ride along into `connector_error_json`. A non-Venmo origin is reported
        // as an opaque class rather than echoed: if a hostile redirect landed us
        // somewhere, its hostname is attacker-chosen text and this message is
        // owner-visible.
        const landedDescription = describeLandedOrigin(landedOrigin, page.url());
        throw new Error(`${VENMO_ORIGIN_NAVIGATION_FAILED}: could not establish the venmo.com origin (landed on ${landedDescription})`);
    }
}
/**
 * How a failed landing is described in the owner-visible error text.
 *
 * A Venmo-family origin is named outright — that is the diagnostically useful
 * case ("we ended on id.venmo.com and could not get back"). Anything else is
 * reported as an opaque class: an origin we did not expect may be
 * attacker-chosen text, and this string lands in `connector_error_json`.
 * Origins carry no path/query/fragment, so nothing token-shaped rides along
 * either way.
 */
function describeLandedOrigin(landedOrigin, landedUrl) {
    if (landedOrigin === null) {
        return "unknown";
    }
    return isVenmoFamilyUrl(landedUrl) ? landedOrigin : "a non-venmo.com origin";
}
const noopCheckpoint = () => Promise.resolve();
const noopProgress = () => Promise.resolve();
/**
 * Returned by the sign-in helpers to mean "the page was handed to the owner
 * (or an automated replay ran on their behalf) and that interaction is over —
 * stop automating this flow". It deliberately carries NO liveness payload:
 * every path that returns it has stopped probing the page once the owner's
 * response (or a replay triggered by it) landed, so there is nothing truthful
 * left to report here. Liveness is proven one layer later, by the collection
 * step that already re-establishes the venmo.com origin and fetches
 * `/account` for its own purposes (see {@link waitForManualLogin}'s doc).
 *
 * This exists as its own type rather than reusing `VenmoAccountProbeResult`
 * because a `{ live: true }` returned from a path that never checked would be
 * a lie the type system would help spread.
 */
const OWNER_HANDOFF_COMPLETE = Symbol("venmo_owner_handoff_complete");
/**
 * Page-context probe: fetch `/account` under the real session cookie
 * (`credentials: "include"`, no Authorization header, no device-id, no
 * spoofed User-Agent). A 2xx body carrying `data.user.id` proves the
 * session is live and gives the owner id for free — the same call
 * `fetchProfile`/`collectProfile` will make once collection starts.
 *
 * Navigates to `venmo.com` first when not already there: the page starts
 * on `about:blank` (opaque origin) on a fresh run, and `api.venmo.com`'s
 * CORS allowlist only grants a credentialed fetch from `https://venmo.com`
 * — see {@link ensureVenmoOrigin}. A probe that skipped this would read
 * every live session as dead and never actually test session state.
 *
 * `phase` (default `"pre_submit"`) governs the NAME of a transport-fault
 * throw, not just its text — see the "B4" note above `throw` below.
 */
export async function probeVenmoAccount(page, phase = "pre_submit", { evaluateTimeoutMs = PROBE_EVALUATE_TIMEOUT_MS, } = {}) {
    let outcome;
    try {
        // Folded into the same try/catch as the fetch below: a failed navigation
        // (ensureVenmoOrigin now throws rather than silently proceeding — see its
        // doc) must be classified through the SAME phase-aware transport-error
        // path as a fetch failure, not escape unwrapped and skip the B4
        // post-submit non-retry invariant this function exists to enforce.
        await ensureVenmoOrigin(page);
        // Bounded on both layers, for the same reasons as reddit.ts's
        // `isSessionLive`: the in-page `fetch` has no default timeout (an
        // accepted-but-unanswered connection hangs the callback forever, and the
        // `catch` cannot see a hang), and `page.evaluate` has no default timeout
        // either (a wedged page context never runs the callback at all, so the
        // inner abort has nothing to abort).
        const evaluated = await withDeadline(page.evaluate(async ({ fetchTimeoutMs, url }) => {
            try {
                const res = await fetch(url, {
                    credentials: "include",
                    headers: { accept: "application/json" },
                    signal: AbortSignal.timeout(fetchTimeoutMs),
                });
                if (res.status < 200 || res.status >= 300) {
                    return { kind: "dead" };
                }
                const body = (await res.json().catch(() => null));
                const ownerId = body?.data?.user?.id ?? null;
                return ownerId
                    ? { kind: "live", ownerId }
                    : { kind: "dead" };
            }
            catch (err) {
                return {
                    kind: "transport_error",
                    message: err instanceof Error ? err.message : String(err),
                };
            }
        }, { fetchTimeoutMs: PROBE_FETCH_TIMEOUT_MS, url: ACCOUNT_PROBE_URL }), evaluateTimeoutMs);
        // A page context that never answers is a transport fault, not a dead
        // session — and it stays phase-aware, so a post-submit hang still gets
        // the non-retryable name (B4) rather than silently retrying a password.
        outcome =
            evaluated === DEADLINE_TIMEOUT
                ? {
                    kind: "transport_error",
                    message: `probe did not return within ${evaluateTimeoutMs}ms`,
                }
                : evaluated;
    }
    catch (err) {
        // Either `ensureVenmoOrigin` threw (navigation never landed on venmo.com)
        // or `page.evaluate` itself rejected — the execution context was
        // destroyed (navigation raced the probe) or the page/browser crashed.
        // Same "could not run at all" classification as a fetch throwing inside
        // the callback: a transport fault, not proof the session is dead.
        outcome = {
            kind: "transport_error",
            message: err instanceof Error ? err.message : String(err),
        };
    }
    if (outcome.kind === "transport_error") {
        const detail = redactTransportDetail(outcome.message).slice(0, PROBE_TRANSPORT_DETAIL_MAX);
        // B4: a transport blip has NO cost to retry before a password was ever
        // typed (`pre_submit` — nothing has been sent to Venmo yet), but the SAME
        // fault immediately after `loginWithSavedCredentials` submits the saved
        // password (`post_submit` — this probe is verifying that submission's
        // outcome) is a different risk entirely: this repo's own
        // `venmo_.*transport_error` wildcard classified BOTH names as retryable,
        // so a transient network blip landing on the post-submit probe alone
        // (session establishment already succeeded) would terminal the run
        // retryable, and a runtime-level retry re-enters ensureVenmoSession from
        // scratch — re-submitting the SAME saved password against Venmo's own
        // login form on every retry, with no run-scoped budget (unlike usaa's
        // sessionRepairAttempted) to stop it. Venmo's own anti-automation gate
        // (this file's header) makes repeated automated logins against one real
        // account exactly the kind of signal that risks a lockout. Naming this
        // throw distinctly (`venmo_post_submit_probe_transport_error`, deliberately
        // NOT matching connectors/venmo/index.ts's retryablePattern) makes the
        // runtime terminal this run permanently instead of retrying it — losing
        // one run's-worth of collection is the safe failure mode, not repeatedly
        // re-submitting a real password.
        const name = phase === "post_submit"
            ? VENMO_POST_SUBMIT_PROBE_TRANSPORT_ERROR
            : VENMO_PROBE_TRANSPORT_ERROR;
        throw new Error(`${name}: ${detail}`);
    }
    return outcome.kind === "live"
        ? { live: true, ownerId: outcome.ownerId }
        : { live: false, ownerId: null };
}
/**
 * Every OTP input this module recognizes, unnarrowed — the countable form of
 * {@link findVenmoOtpInput}. Classification needs to count candidates (a split
 * per-digit layout has several); the fill path needs exactly one. Both read the
 * same selector so a page can never be classified off an input the fill path
 * would not find.
 */
function venmoOtpInputCandidates(page) {
    return page.locator(OTP_SELECTOR);
}
function findVenmoOtpInput(page) {
    return venmoOtpInputCandidates(page).first();
}
function isViableVenmoOtpDigitCount(codeCount) {
    return (codeCount === 1 || (codeCount > 1 && codeCount <= MAX_SPLIT_CODE_DIGITS));
}
/**
 * Count the OTP inputs that are actually usable right now — visible AND
 * enabled. `locatorIsVisible` answers only the first half: a disabled field
 * still reports itself visible, so a rendered-but-inert code box passed the
 * old check and reached the prompt. Presence, and even visibility, is not
 * evidence; usability is.
 */
async function countUsableVenmoOtpInputs(page) {
    const candidates = venmoOtpInputCandidates(page);
    const count = await candidates.count().catch(() => 0);
    let usable = 0;
    for (let i = 0; i < count; i += 1) {
        const candidate = candidates.nth(i);
        const [visible, enabled] = await Promise.all([
            candidate.isVisible().catch(() => false),
            candidate.isEnabled().catch(() => false),
        ]);
        if (visible && enabled) {
            usable += 1;
        }
    }
    return usable;
}
/**
 * Whether this page can actually ACCEPT a code right now.
 *
 * This is the evidence that makes an OTP classification honest. Prompting the
 * owner commits them to fetching a secret out of band, and a fabricated prompt
 * on a payments account trains them to expect code demands Venmo never sent.
 * So the bar is a real, visible, enabled code input: one field, or the split
 * per-digit layout.
 */
async function hasUsableVenmoOtpInput(page) {
    return isViableVenmoOtpDigitCount(await countUsableVenmoOtpInputs(page));
}
/**
 * Wait for the submitted login to reach an OBSERVABLE outcome, then report
 * whether the session went live.
 *
 * The signal it keys on is the submit control leaving its in-flight state.
 * Venmo renders a spinner INSIDE that button while the login POST is
 * outstanding, which replaces its accessible name — so "a button named Log
 * in / Sign in / Continue is present again, or the button is gone entirely
 * (navigated away)" is a definite, observable completion signal, not a guess
 * that enough time has passed.
 *
 * Deliberately NOT poll-then-assume. Two distinct outcomes:
 *   - settled -> probe once and return that verdict, which is now a real
 *     answer about the session rather than a read taken mid-request;
 *   - never settled within the bound -> return `settled: false`, so the
 *     caller can say "the login did not complete" instead of asserting the
 *     owner's credentials were rejected. A timeout is not a rejection.
 *
 * The bound exists because a wait that cannot end is the unbounded-await
 * defect this codebase has already paid for twice.
 */
async function pollForLiveSessionAfterSubmit(page, settleTimeoutMs = POST_SUBMIT_SETTLE_TIMEOUT_MS) {
    const deadline = Date.now() + settleTimeoutMs;
    let lastProbe = null;
    while (Date.now() < deadline) {
        // The probe itself IS the definite signal — it asks Venmo's own API
        // whether this browser context is authenticated. A `live` answer is
        // observable completion; anything else means the outcome is not yet
        // known, so keep asking until it is or the bound expires.
        //
        // Keying on the probe rather than on button pixels is deliberate: the
        // spinner is a rendering detail that varies by page generation, while
        // "the API says we are signed in" is the property the caller actually
        // needs and the same one it already trusted for a single sample.
        const probe = await probeVenmoAccount(page, "post_submit");
        if (probe.live) {
            return { probe, settled: true };
        }
        // A transport fault is "could not ask", not "answered no" — retrying is
        // correct. A clean `dead` this early may still be mid-request, so it also
        // keeps polling; if it is a genuine rejection the answer stays `dead` and
        // the bound below reports honestly rather than guessing.
        lastProbe = probe;
        await page.waitForTimeout(POST_SUBMIT_POLL_INTERVAL_MS);
    }
    // The bound expired with the session never going live. We do NOT know that
    // the credentials were rejected — we know only that no outcome arrived in
    // time, which is a different fact and must be reported as itself. The last
    // probe travels with it as evidence, but `settled: false` is what decides
    // the caller's wording.
    return { probe: lastProbe, settled: false };
}
/**
 * Wait for the input that makes a dispatched SMS code actionable. The offer is
 * not an OTP page yet: prompting before this wait would ask the owner for a
 * code that Venmo has not sent or cannot accept.
 */
async function waitForVenmoSmsOfferCodeInput(page) {
    const inputAppeared = await findVenmoOtpInput(page)
        .waitFor({ state: "visible", timeout: SMS_OFFER_CODE_INPUT_TIMEOUT_MS })
        .then(() => true)
        .catch(() => false);
    if (!(inputAppeared && (await hasUsableVenmoOtpInput(page)))) {
        throw new Error(`${VENMO_SMS_OFFER_CODE_INPUT_TIMEOUT}: Venmo did not render a usable code input within ${SMS_OFFER_CODE_INPUT_TIMEOUT_MS}ms after Send code`);
    }
}
/**
 * Dispatch Venmo's SMS only after preserving the device-trust choice. The
 * checkbox is idempotent: the retained capture was already checked, and a
 * blind click would undo the future unattended-login benefit we need.
 */
async function submitVenmoSmsOffer(page) {
    const rememberDevice = page
        .locator(SMS_OFFER_REMEMBER_DEVICE_SELECTOR)
        .first();
    if (!((await locatorIsVisible(rememberDevice)) &&
        (await rememberDevice.isEnabled().catch(() => false)))) {
        throw new Error(`${VENMO_SMS_OFFER_CHECKBOX_UNAVAILABLE}: Remember this device is not usable`);
    }
    const remembered = await rememberDevice.isChecked().catch(() => null);
    if (remembered === null) {
        throw new Error(`${VENMO_SMS_OFFER_CHECKBOX_UNAVAILABLE}: could not read Remember this device`);
    }
    if (!remembered) {
        await rememberDevice.click().catch((error) => {
            throw new Error(`${VENMO_SMS_OFFER_CHECKBOX_UNAVAILABLE}: could not select Remember this device`, {
                cause: error,
            });
        });
        if (!(await rememberDevice.isChecked().catch(() => false))) {
            throw new Error(`${VENMO_SMS_OFFER_CHECKBOX_UNAVAILABLE}: Remember this device did not stay selected`);
        }
    }
    const sendCode = page.locator(SMS_OFFER_SEND_CODE_SELECTOR).first();
    if (!((await locatorIsVisible(sendCode)) &&
        (await sendCode.isEnabled().catch(() => false)))) {
        throw new Error(`${VENMO_SMS_OFFER_SEND_CODE_UNAVAILABLE}: Send code is not usable`);
    }
    await sendCode.click().catch((error) => {
        throw new Error(`${VENMO_SMS_OFFER_SEND_CODE_UNAVAILABLE}: could not send the code`, { cause: error });
    });
    await waitForVenmoSmsOfferCodeInput(page);
}
/**
 * Click the sign-in form's submit control. Returns `false` when no control
 * could be found — the caller decides whether that is fatal.
 *
 * Candidate order is deliberate. The semantic role query comes first because
 * an accessible name is the most stable thing about a button; `extraSelectors`
 * (Venmo's `#btnNext` on the identifier screen) is tried before the generic
 * `button[type="submit"]` because on a page carrying more than one submit
 * control the generic selector's `.first()` is a coin flip, whereas the id is
 * exact.
 */
async function clickVenmoLoginSubmit(page, extraSelectors = []) {
    const semantic = page
        .getByRole("button", { name: SUBMIT_BUTTON_NAME_RE })
        .first();
    if (await locatorIsVisible(semantic)) {
        await semantic.click();
        return true;
    }
    for (const selector of [...extraSelectors, 'button[type="submit"]']) {
        const fallback = page.locator(selector).first();
        if (await locatorIsVisible(fallback)) {
            await fallback.click();
            return true;
        }
    }
    return false;
}
/**
 * Whether a human-verification challenge is currently rendered.
 *
 * Presence of the frame is the signal, and it is deliberately checked only
 * where a challenge would EXPLAIN a stall — never as a precondition for
 * proceeding. Venmo embeds reCAPTCHA on the sign-in page unconditionally
 * (`run_1787164654406`), including on flows that complete without ever
 * challenging the user, so treating a mere embed as "blocked" would hand every
 * healthy login to the owner. See {@link fillVenmoPassword}.
 */
async function hasVenmoCaptcha(page) {
    return await locatorIsVisible(page.locator(CAPTCHA_FRAME_SELECTOR));
}
/**
 * Did this page load reCAPTCHA Enterprise **v3** — the invisible, scoring kind?
 *
 * Keys on the SCRIPT, never on visibility, because that is the whole point: v3
 * renders nothing. Presence alone is not proof the score blocked anything —
 * Venmo loads this on healthy sign-ins too — so callers must only ask once the
 * login has ALREADY failed to complete. It answers "here is the mechanism that
 * best explains this failure", not "a challenge is being shown".
 *
 * Matches the enterprise v3 asset paths observed live (`grcenterprise_v3.html`,
 * `recaptchav3.js`) rather than the bare word "recaptcha", which also matches
 * the v2 visible widget the sibling {@link hasVenmoCaptcha} already handles.
 */
async function pageLoadedInvisibleScoringChallenge(page) {
    return await page
        .locator('script[src*="recaptchav3"], iframe[src*="grcenterprise_v3"], script[src*="grcenterprise_v3"]')
        .first()
        .count()
        .then((n) => n > 0)
        .catch(() => false);
}
/**
 * Wait for the password screen to actually render, bounded.
 *
 * `waitFor` resolves the instant the field is visible and rejects at the
 * deadline — the replacement for a fixed `waitForTimeout(1500)` that could
 * neither wait long enough for a slow screen nor return early from a fast one.
 * There is no polling loop here and therefore nothing that can spin.
 */
async function waitForVenmoPasswordScreen(page, timeoutMs) {
    return await page
        .locator(PASSWORD_SELECTOR)
        .first()
        .waitFor({ state: "visible", timeout: timeoutMs })
        .then(() => true)
        .catch(() => false);
}
/**
 * Wait, bounded, for a handoff page to render something the owner can act on.
 *
 * Returns whether anything actionable painted. Never throws and never
 * navigates: a page that stays blank is still handed over (the owner can
 * reload or navigate themselves inside the secure browser), it is just handed
 * over with an honest message rather than a silent empty card.
 *
 * This exists because URL is a poor proxy for "ready". Venmo's sign-in is a
 * client-rendered SPA whose shell — logo, one input outline, two rounded
 * buttons — paints on the correct origin well before hydration fills it in,
 * so a URL check alone cannot tell a usable screen from a placeholder.
 */
async function waitForActionableHandoffSurface(page, timeoutMs) {
    return await page
        .locator(ACTIONABLE_HANDOFF_SELECTOR)
        .first()
        .waitFor({ state: "attached", timeout: timeoutMs })
        .then(() => true)
        .catch(() => false);
}
async function captureLoginState(capture, page, label) {
    if (!capture) {
        return;
    }
    await capture.captureDom(page, label).catch(() => undefined);
    await capture
        .captureLocatorProbe?.(page, label, LOGIN_LOCATOR_PROBES)
        .catch(() => undefined);
}
/**
 * True while a replay is running, so no prompt site may ask the owner again.
 * Managed only by {@link withSuppressedManualPrompts}, which restores the
 * previous value — see that function for why the guard lives at the boundary
 * rather than at each individual handoff.
 */
let manualPromptSuppressed = false;
/**
 * Hand the page to the owner, navigating to the real sign-in page first so
 * the handoff shows a Venmo sign-in screen rather than `about:blank` — the
 * page at handoff time has no `preservePageOnSuccess`/`preservePageOnFailure`
 * guarantee and may still be on its initial blank state (F2 in
 * /tmp/review-venmo-browser-redesign-0810.md).
 *
 * Deliberately does NOT probe after the owner responds. The probe it used to
 * run began with {@link ensureVenmoOrigin}, whose cross-origin `page.goto` is
 * a full network navigation — it destroyed the authenticated page state the
 * owner had just created, and could walk the session back through the wall
 * they had just cleared (production run_1787918248525: the owner completed
 * sign-in, then the run failed). `resumeFill`, when given, still runs — it
 * fills whatever the owner's completion made reachable, which is a distinct
 * concern from probing it — but nothing probes the result. Liveness is not
 * asserted here at all; it is established by the COLLECTION step, which
 * already navigates to the `venmo.com` origin itself
 * (`establishVenmoCollectOrigin`) and fetches `/account` — the exact same
 * evidence this probe used to gather, on the layer that owns it. A session
 * that is not actually live surfaces there as `venmo_session_expired`, which
 * is deliberately absent from `VENMO_RETRYABLE_PATTERN`: a named,
 * non-retryable, owner-facing failure, never a silent green.
 */
async function waitForManualLogin({ assist, capture, completeAssistance, message, page, reason, resumeFill, sendInteraction, }) {
    // Navigate ONLY when the page is not already somewhere the owner can sign in
    // from. The unconditional `goto` this replaces threw away real, load-bearing
    // page state at the exact moment the owner was asked to act on it: a rendered
    // captcha (the `reason: "captcha"` handoff navigates away from the very
    // challenge it is asking them to solve), Venmo's OTP screen, and any partly
    // completed form. It also resets a two-step sign-in back to step one, which is
    // why production run_1787319714987's handoff screenshot showed a pristine
    // "Log in / Enter email, mobile, or username / Next" form while the message
    // described a post-submit failure — two different page states separated by
    // this navigation.
    //
    // Only a page on Venmo's IDENTITY host (`id.venmo.com`, where sign-in, the
    // captcha, and the OTP screen all actually live) is state worth preserving.
    // Every other page — `about:blank` on a fresh run, and the logged-out
    // `venmo.com/` the pre-handoff probe leaves behind — is not somewhere the
    // owner can sign in from, so those still navigate to the real login page
    // (F2). That keeps the existing "hand the owner a real sign-in page, not
    // about:blank" guarantee intact while no longer destroying the one screen
    // the handoff is asking them to act on.
    if (!isVenmoSignInUrl(page.url())) {
        await page
            .goto(LOGIN_URL, { waitUntil: "domcontentloaded", timeout: 30_000 })
            .catch(() => undefined);
    }
    // Being on the right URL is not the same as having something on screen.
    // `isVenmoSignInUrl` matches on origin alone, so a page that is mid-
    // navigation to a fresh sign-in context satisfies the guard above while
    // rendering only Venmo's pre-hydration skeleton. That is production
    // run_1787537596833: the handoff frame's screenshot is byte-identical
    // (md5 da2529a174ff25c160ceca54cd5ea4ef) to the `venmo-signin-loaded`
    // shell captured 5s earlier, and its aria snapshot is the single line
    // `- iframe [ref=e2]` — an empty placeholder, not the filled password form
    // the owner had been looking at 2s before. The owner was asked to finish
    // signing in on a blank card.
    //
    // Waiting for the page to paint something actionable costs nothing on a
    // healthy handoff (it resolves as soon as the form is up) and converts the
    // blank-surface failure into either a usable screen or an honest message.
    // It never navigates, so the captcha/OTP state-preservation guarantee above
    // is untouched.
    if (manualPromptSuppressed) {
        // Defence in depth: no path may prompt twice in one run, including the
        // direct callers that do not route through requestManualLoginForChallenge.
        // Nothing probes here either — see this function's doc.
        return OWNER_HANDOFF_COMPLETE;
    }
    const painted = await waitForActionableHandoffSurface(page, HANDOFF_PAINT_TIMEOUT_MS);
    if (!painted) {
        // Still hand off — the owner can reload or navigate inside the secure
        // browser — but say so, rather than letting them stare at an empty card
        // wondering what they are supposed to complete.
        await captureLoginState(capture, page, "venmo-handoff-surface-blank");
    }
    await manualBrowserLogin({
        // Deliberately NOT wired with `isProbeSuccessful`: see `EnsureVenmoSessionArgs.assist`'s
        // doc for why no self-poll is safe here yet (it would navigate the owner
        // off their in-progress captcha/OTP screen). `manualBrowserLogin` treats
        // `assist` without `isProbeSuccessful` as a no-op, so this keeps
        // click-first behavior unchanged while staying ready to wire the self-
        // resolve path the moment a navigation-free liveness signal exists.
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...(completeAssistance ? { completeAssistance } : {}),
        message: painted ? message : `${message} ${HANDOFF_BLANK_SURFACE_SUFFIX}`,
        page,
        probe: async () => {
            // Replay only. The owner's completion is what MAKES the form reachable
            // — filling it is still worth doing, since the automation holds the
            // credential the owner does not (run_1787880916346) — but nothing here
            // may probe the result: that navigation is the defect (see this
            // function's doc). `resumeFill` itself, and everything it calls
            // (`loginWithSavedCredentials`'s own post-submit poll), already carries
            // whatever classification it needs; this callback does not add one.
            //
            // NOT wrapped in `.catch()`. `resumeSignInAfterChallenge` already
            // absorbs every PRE-submit failure by returning normally (the replay
            // found no form — the owner's manual completion, unverified, is the
            // honest fallback). The only errors that reach here are POST-submit
            // ones, which arrive already carrying the correct non-retryable
            // classification. Catching them would discard that and let the run fall
            // through as if nothing happened — the exact defect a `.catch(() =>
            // false)` here used to cause.
            if (resumeFill) {
                await resumeFill();
            }
        },
        ...(reason ? { reason } : {}),
        sendInteraction,
        timeoutSeconds: 1800,
    });
    return OWNER_HANDOFF_COMPLETE;
}
async function ensureManualSessionWithoutCredentials({ assist, capture, checkpoint, completeAssistance, page, sendInteraction, }) {
    await checkpoint("venmo-signin-manual-required");
    return await waitForManualLogin({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...(completeAssistance ? { completeAssistance } : {}),
        message: MANUAL_LOGIN_WITHOUT_CREDENTIALS_MESSAGE,
        page,
        sendInteraction,
    });
}
/**
 * At most ONE owner prompt per run, enforced at the single boundary every
 * handoff passes through.
 *
 * The replay re-enters `loginWithSavedCredentials`, which can reach FIVE
 * separate prompt sites (the challenge handoff itself, `fillVenmoPassword`'s
 * unrecognized-password-screen branch, `handleVenmoOtpIfPresent`, the
 * post-submit-incomplete handoff, and the no-credentials path). Guarding only
 * the site the replay was launched from left the other four able to ask the
 * owner a second time for the same run — the reviewer's finding, and a real
 * one: an owner who cleared a bot check should never be asked again mid-replay.
 *
 * A depth flag at the boundary is the smallest complete guard. Every site is
 * covered because every site funnels through here, and it cannot drift as new
 * handoff sites are added.
 */
async function withSuppressedManualPrompts(run) {
    const previous = manualPromptSuppressed;
    manualPromptSuppressed = true;
    try {
        return await run();
    }
    finally {
        manualPromptSuppressed = previous;
    }
}
/**
 * Hand a pre-credential challenge (bot check / CAPTCHA / device approval) to
 * the owner, then RESUME BY FILLING — not by validating.
 *
 * Production run_1787880916346, 2026-08-28: the page at the signin URL was a
 * DataDome interstitial (`geo.ddc.venmo.com/interstitial/`, only hidden
 * `adsdd*` inputs — no username or password field anywhere in the DOM). The
 * username locator never appeared, so this handoff fired BEFORE any credential
 * was typed. The owner cleared the bot check in the viewer, Venmo then rendered
 * the real sign-in form — and the resume only PROBED. Nothing filled the form
 * that had finally appeared, so the probe saw a signed-out page and the run
 * died `venmo_session_failed` with the owner's work already done.
 *
 * The owner cannot finish this alone by design: the system holds the password
 * and he does not know it. Asking him to "complete sign-in" was asking for the
 * one step only the automation can take. He does the human-only part (the
 * challenge); the automation does the credential part, after.
 *
 * So on resume: if the sign-in form is now present, fill it and let the normal
 * flow continue. Only if it is still absent — or the fill itself fails — do we
 * fall back to validating whatever session the owner may have established by
 * hand, which is the previous behavior and still correct for an owner who
 * signed in manually.
 */
async function requestManualLoginForChallenge({ assist, capture, completeAssistance, page, reason, replaySignIn, sendInteraction, }) {
    if (manualPromptSuppressed) {
        // Inside a replay: the owner has already been asked once for this run.
        // Nothing probes here either — see waitForManualLogin's doc — so there is
        // nothing left to do but report that the (single) handoff is over.
        return OWNER_HANDOFF_COMPLETE;
    }
    return await waitForManualLogin({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...(completeAssistance ? { completeAssistance } : {}),
        message: challengeHandoffMessage(reason, replaySignIn !== undefined),
        page,
        ...(replaySignIn
            ? {
                resumeFill: async () => {
                    await withSuppressedManualPrompts(() => resumeSignInAfterChallenge(replaySignIn));
                },
            }
            : {}),
        sendInteraction,
    });
}
/**
 * The owner-facing sentence, split by what the owner can actually do.
 *
 * When we hold the credentials, naming "sign in" first is a false ask — see
 * `login-credentials.ts`'s note on page-shaped messages hiding
 * credential-shaped truths. Name the challenge, and say the rest is automatic.
 */
function challengeHandoffMessage(reason, hasCredentials) {
    if (hasCredentials) {
        return `Venmo is showing a security check instead of the sign-in form (${reason}). Complete the check — CAPTCHA, device approval, or verification — in the secure browser, then respond success. Your stored credentials are entered automatically afterward; you do not need the password.`;
    }
    return `Venmo did not render the expected sign-in form (${reason}). Complete sign-in — including any device approval, CAPTCHA, or verification step — in the secure browser, then respond success.`;
}
/**
 * Resume a pre-credential challenge by REPLAYING THE WHOLE SIGN-IN.
 *
 * The first version of this filled username+password and returned `true`,
 * leaving the form sitting UNSUBMITTED while `waitForManualLogin` probed it.
 * Independent review caught that, and it was the right catch: filling is not
 * signing in. It skipped `clickVenmoLoginSubmit` and its
 * `venmo_login_submit_missing` guard, the `onCredentialSubmit`
 * retry-classification marker, the durable `venmo_credential_submit` progress
 * event, the `domcontentloaded` wait, `handleVenmoOtpIfPresent`, and the POLLED
 * post-submit verify — each of which exists because a real run once failed
 * without it.
 *
 * Re-entering `loginWithSavedCredentials` is the smallest COMPLETE correction.
 * The challenge handoff is raised from the top of that function, so calling it
 * again after the owner clears the check re-runs the identical proven sequence
 * instead of a second, thinner copy that would drift from it.
 *
 * Nothing here reports liveness — see `waitForManualLogin`'s doc for why
 * nothing probes after a handoff. This only decides whether a failure
 * partway through the replay should propagate (a real password reached
 * Venmo, so the failure is that submission's own diagnosis) or be absorbed
 * (the replay found no form at all, so the caller's honest fallback is simply
 * that the handoff is over, unverified).
 */
async function resumeSignInAfterChallenge(replaySignIn) {
    let submitted = false;
    try {
        await replaySignIn(() => {
            submitted = true;
        });
    }
    catch (error) {
        // Do NOT flatten. A failure AFTER the password reached Venmo — a
        // post-submit verify, an OTP step, a settle timeout — carries its own
        // classification (notably the non-retryable
        // `venmo_post_submit_probe_transport_error`). Swallowing it here would
        // discard that diagnosis in favor of a generic "handoff complete" that
        // hides what actually happened after a real password went out.
        //
        // Before submission there is nothing to preserve: the replay simply did not
        // find a form, and the caller's fallback (report the handoff as over,
        // unverified) is the honest answer.
        if (submitted) {
            throw error;
        }
    }
}
/**
 * Fill the password field, advancing Venmo's two-step sign-in when needed.
 *
 * Venmo's current flow (live `run_1787164654406`) is identifier -> `Next` ->
 * password on a SECOND screen. The one-screen shape is still handled first and
 * costs nothing: if a password field is already visible, this fills it and
 * returns without ever clicking anything.
 *
 * Returns `null` when the password was filled and the caller should continue
 * to the password submit; returns a probe result when the flow was handed to
 * the owner instead. Throws {@link VENMO_PASSWORD_SCREEN_TIMEOUT} when the
 * second screen never arrives for a reason we cannot attribute.
 *
 * THIS FUNCTION NEVER MARKS THE CREDENTIAL AS SUBMITTED. The click it performs
 * sends the IDENTIFIER only — an email/username, not a secret — so the
 * `onCredentialSubmit` marker and its non-retryable classification stay with
 * the password submit in {@link loginWithSavedCredentials}. Firing the marker
 * here would classify every identifier-screen fault as "a password went out",
 * permanently terminalling runs that cost nothing to retry.
 */
async function fillVenmoPassword(args) {
    const { assist, capture, completeAssistance, page, password, passwordScreenTimeoutMs = PASSWORD_SCREEN_TIMEOUT_MS, sendInteraction, } = args;
    const passwordIn = page.locator(PASSWORD_SELECTOR).first();
    // A visible password box is NOT proof of a one-screen form. Venmo's step-one
    // screen renders an UNNAMED `input[type="password"]` alongside the
    // `login_email` identifier field (live CDP reading, run_1787164654406 — see
    // USERNAME_SELECTOR's doc), and PASSWORD_SELECTOR's third alternative
    // matches it. Treating that as "both fields are here, fill and submit" typed
    // the password into screen one and then clicked `Next`, which submits the
    // IDENTIFIER alone: Venmo stayed on step one, the post-submit probe read
    // dead, and the run handed off with the post_submit copy ("automated sign-in
    // did not complete") ~5s in, having never sent the password. That is
    // production run_1787319714987.
    //
    // The discriminator is the step-one control, not the password box: `#btnNext`
    // exists only while the identifier screen is up. So a page showing a password
    // field AND a step-one control is screen one and must be advanced; a password
    // field with no step-one control is a genuine one-screen form.
    const stepOneControl = page.locator(STEP_ONE_SUBMIT_SELECTOR).first();
    const onStepOne = await locatorIsVisible(stepOneControl);
    if (!onStepOne && (await locatorIsVisible(passwordIn))) {
        await passwordIn.fill(password);
        return null;
    }
    // Two-step flow: advance past the identifier-only screen. `#btnNext` is
    // Venmo's current step-one control; the semantic "Next" name inside
    // clickVenmoLoginSubmit matches it first when the accessible name is
    // present.
    if (!(await clickVenmoLoginSubmit(page, [STEP_ONE_SUBMIT_SELECTOR]))) {
        // No way to advance at all. This is the genuinely-unrecognized page the
        // handoff exists for, so it hands off rather than throwing — nothing has
        // been submitted, and the owner can still finish by hand.
        await captureLoginState(capture, page, "venmo-step-one-submit-missing");
        return await requestManualLoginForChallenge({
            ...(assist ? { assist } : {}),
            ...(capture ? { capture } : {}),
            ...(completeAssistance ? { completeAssistance } : {}),
            page,
            reason: "could not advance past the sign-in identifier step",
            sendInteraction,
        });
    }
    await captureLoginState(capture, page, "venmo-identifier-submitted");
    if (await waitForVenmoPasswordScreen(page, passwordScreenTimeoutMs)) {
        await page.locator(PASSWORD_SELECTOR).first().fill(password);
        return null;
    }
    // The password screen did not arrive within the bound. A rendered captcha is
    // the one cause we can attribute and the one the owner can actually resolve,
    // so it routes to the existing manual path with an honest message rather
    // than to a named failure they cannot act on. Checked only HERE — after a
    // real stall — because Venmo embeds reCAPTCHA on healthy sign-ins too.
    await captureLoginState(capture, page, "venmo-password-screen-missing");
    if (await hasVenmoCaptcha(page)) {
        return await waitForManualLogin({
            ...(assist ? { assist } : {}),
            ...(capture ? { capture } : {}),
            ...(completeAssistance ? { completeAssistance } : {}),
            message: "Venmo is showing a human-verification challenge (CAPTCHA) that PDPP will not attempt to solve. " +
                "Complete the challenge and finish signing in to Venmo in the secure browser, then respond success.",
            page,
            reason: "captcha",
            sendInteraction,
        });
    }
    // No captcha, no password screen, and no evidence of what Venmo did. Fail
    // with a named, bounded error rather than falling through into the OTP path,
    // where an absent password field would be misread as a verification prompt
    // and fabricate a code demand the owner never received.
    throw new Error(`${VENMO_PASSWORD_SCREEN_TIMEOUT}: the password step did not render within ${passwordScreenTimeoutMs}ms after the identifier was submitted`);
}
/**
 * Handle Venmo's post-submit verification step, if one rendered. A usable OTP
 * input takes the existing interaction path. The prior SMS offer is a distinct
 * state: it must dispatch the code and wait for that input before it can use
 * the same interaction path. Returns `null` when no verification step was
 * detected (the caller proceeds to the final session probe).
 *
 * Once the owner's response to the code interaction resolves — whether they
 * supplied a code or cancelled/dismissed it — this function is done probing,
 * for the same reason {@link waitForManualLogin} is: the owner just acted on
 * the page, and a probe (or the page-context fetch/navigation underneath one)
 * is the next thing that could destroy or race the state that action created.
 * The code, if supplied, is still submitted — that is automation the owner
 * cannot do themselves — but nothing here asserts what Venmo did with it.
 * Both outcomes return {@link OWNER_HANDOFF_COMPLETE}, which
 * `loginWithSavedCredentials` already treats as "stop, do not reach the
 * post-submit settle poll" (same truthy short-circuit as every other handoff
 * path). Liveness is established one layer later, by collection — see
 * {@link waitForManualLogin}'s doc for why that is the correct owner of this
 * evidence.
 */
async function handleVenmoOtpIfPresent(args) {
    const { assist, capture, completeAssistance, page, sendInteraction } = args;
    const otpIn = findVenmoOtpInput(page);
    const bodyText = (await page
        .locator("body")
        .innerText()
        .catch(() => "")).slice(0, 1000);
    // A usable code input is what makes this an OTP challenge. Matching copy
    // alone still routes to a handoff below rather than a prompt, but a code box
    // that is merely RENDERED is not evidence either: a disabled field reports
    // itself visible, so `locatorIsVisible` alone let an inert box demand a code
    // Venmo never sent.
    const usableOtpInput = await hasUsableVenmoOtpInput(page);
    const smsOfferPresent = SMS_OFFER_TEXT_RE.test(bodyText) &&
        (await locatorIsVisible(page.locator(SMS_OFFER_SEND_CODE_SELECTOR).first()));
    if (!(usableOtpInput || OTP_PROMPT_TEXT_RE.test(bodyText) || smsOfferPresent)) {
        return null;
    }
    await captureLoginState(capture, page, "venmo-otp-detected");
    if (!usableOtpInput) {
        if (smsOfferPresent) {
            await submitVenmoSmsOffer(page);
            // Re-enter only after a real, usable input arrived. This preserves the
            // existing OTP interaction, validation, fill, and submit behavior.
            return await handleVenmoOtpIfPresent(args);
        }
        // Either the prompt copy matched with no known input shape, or an input
        // rendered that cannot accept a code. Hand off rather than guess a
        // selector for a UI we can't confirm — and never fabricate a code demand.
        return await requestManualLoginForChallenge({
            ...(assist ? { assist } : {}),
            ...(capture ? { capture } : {}),
            ...(completeAssistance ? { completeAssistance } : {}),
            page,
            reason: "verification step did not match a known input",
            sendInteraction,
        });
    }
    // Last line of defense before the owner is asked for a secret. Classification
    // already required a usable code input, but Venmo can re-render or navigate
    // between that check and this one. Fail loudly with a named error rather than
    // prompting against a page that cannot accept a code.
    if (!(await hasUsableVenmoOtpInput(page))) {
        throw new Error("venmo_otp_input_missing");
    }
    const resp = await sendInteraction({
        kind: "otp",
        message: "Venmo requires a verification code. Enter the code sent to your phone or email:",
        schema: {
            type: "object",
            properties: { code: { type: "string", pattern: "^\\d{4,8}$" } },
            required: ["code"],
        },
        timeout_seconds: 300,
    });
    const code = resp.data?.code ?? resp.value ?? null;
    if (!code) {
        // The owner's response to the code interaction resolved without a code —
        // cancelled or dismissed. Nothing was submitted, so there is nothing to
        // probe for: nothing here may run a page-context probe/navigation after
        // an owner interaction response, the same invariant `waitForManualLogin`
        // enforces for every other handoff. Report the handoff as over,
        // unverified, exactly like those paths.
        return OWNER_HANDOFF_COMPLETE;
    }
    await otpIn.fill(code);
    await clickVenmoLoginSubmit(page).catch(() => false);
    await page
        .waitForLoadState("domcontentloaded", { timeout: 30_000 })
        .catch(() => null);
    await captureLoginState(capture, page, "venmo-otp-after-submit");
    // The code was submitted — real automation the owner could not do
    // themselves — but collection, not this probe, is the next liveness
    // authority: see this function's doc.
    return OWNER_HANDOFF_COMPLETE;
}
/**
 * Drive Venmo's own web sign-in form with the owner's saved credentials.
 * This assists login only — every branch that hits an unexpected UI (no
 * username field, no OTP match against the copy Venmo actually renders)
 * hands off to the owner rather than guessing further, exactly like
 * amazon.ts/reddit.ts.
 */
/** Bundles the assist/completeAssistance forwarding once so call sites spread one object instead of two separate conditionals each. */
function venmoAssistHooks({ assist, completeAssistance, }) {
    return {
        ...(assist ? { assist } : {}),
        ...(completeAssistance ? { completeAssistance } : {}),
    };
}
async function loginWithSavedCredentials({ assist, attempt = 0, capture, checkpoint, completeAssistance, onCredentialSubmit, page, passwordScreenTimeoutMs, postSubmitSettleTimeoutMs = POST_SUBMIT_SETTLE_TIMEOUT_MS, progress = noopProgress, sendInteraction, username, password, }) {
    const assistHooks = venmoAssistHooks({ assist, completeAssistance });
    await page
        .goto(LOGIN_URL, { waitUntil: "domcontentloaded", timeout: 30_000 })
        .catch(() => undefined);
    await captureLoginState(capture, page, "venmo-login-page");
    await checkpoint("venmo-signin-loaded");
    const userIn = page.locator(USERNAME_SELECTOR).first();
    const usernameAppeared = await userIn
        .waitFor({ state: "attached", timeout: 10_000 })
        .then(() => true)
        .catch(() => false);
    if (!usernameAppeared) {
        // On the REPLAY (attempt 1) the owner has already been asked once and the
        // form still is not here: a genuinely unrecognized page, not a cleared bot
        // check. Nothing probes here either — see waitForManualLogin's doc — so
        // this reports the handoff as over, unverified, and guarantees the owner
        // is never prompted twice for the same run.
        if (attempt === 1) {
            return OWNER_HANDOFF_COMPLETE;
        }
        return await requestManualLoginForChallenge({
            ...assistHooks,
            ...(capture ? { capture } : {}),
            page,
            reason: "sign-in form did not render",
            // Replay the whole sign-in after the owner clears the check. `attempt`
            // bounds it: the replay runs with attempt=1, whose challenge branch no
            // longer re-arms, so a provider trading bot checks cannot loop.
            ...(attempt === 0
                ? {
                    replaySignIn: (onSubmit) => loginWithSavedCredentials({
                        ...assistHooks,
                        ...(capture ? { capture } : {}),
                        attempt: 1,
                        checkpoint,
                        // Chain, do not replace: the run's own marker still fires (it
                        // drives retry classification in session-establish.ts), and the
                        // replay additionally records that a password reached Venmo so
                        // the following probe can be classified `post_submit` per B4.
                        onCredentialSubmit: () => {
                            onCredentialSubmit?.();
                            onSubmit();
                        },
                        page,
                        password,
                        ...(passwordScreenTimeoutMs === undefined
                            ? {}
                            : { passwordScreenTimeoutMs }),
                        ...(postSubmitSettleTimeoutMs === undefined
                            ? {}
                            : { postSubmitSettleTimeoutMs }),
                        progress,
                        sendInteraction,
                        username,
                    }),
                }
                : {}),
            sendInteraction,
        });
    }
    await userIn.fill(username);
    // Two-step flow, submit 1 of 2: `fillVenmoPassword` may click Venmo's `Next`
    // control to reach the password screen. That click sends the IDENTIFIER, not
    // a secret, so it deliberately does NOT fire `onCredentialSubmit` — see that
    // function's doc.
    const passwordHandoff = await fillVenmoPassword({
        ...assistHooks,
        ...(capture ? { capture } : {}),
        page,
        password,
        ...(passwordScreenTimeoutMs === undefined
            ? {}
            : { passwordScreenTimeoutMs }),
        sendInteraction,
    });
    if (passwordHandoff) {
        return passwordHandoff;
    }
    await captureLoginState(capture, page, "venmo-login-before-submit");
    await checkpoint("venmo-password-submit");
    // Submit 2 of 2 — the one that sends the saved PASSWORD. Everything after
    // this line is post-submit: the marker fires here and only here, and it must
    // stay immediately after the click that succeeded so no branch can reach the
    // post-submit probes without having set it.
    if (!(await clickVenmoLoginSubmit(page))) {
        await captureLoginState(capture, page, "venmo-login-submit-missing");
        throw new Error("venmo_login_submit_missing");
    }
    onCredentialSubmit?.();
    // Durable, non-secret marker: no credential value, just the fact and phase.
    // Before this, the run spine had no way to distinguish "the saved password
    // was submitted and Venmo rejected it" from "the flow never got this far" —
    // `onCredentialSubmit` only flips an in-process retry-classification flag
    // (session-establish.ts) and was never itself observable in spine_events.
    await progress("venmo_credential_submit: saved password submitted to sign-in form, awaiting result");
    await page
        .waitForLoadState("domcontentloaded", { timeout: 30_000 })
        .catch(() => null);
    await captureLoginState(capture, page, "venmo-login-after-submit");
    await checkpoint("venmo-2fa-decision");
    const otpHandoff = await handleVenmoOtpIfPresent({
        ...assistHooks,
        ...(capture ? { capture } : {}),
        page,
        sendInteraction,
    });
    if (otpHandoff) {
        return otpHandoff;
    }
    await checkpoint("venmo-final-verify");
    // post_submit: this is the direct outcome check for the password submit
    // above — see probeVenmoAccount's B4 doc for why a transport fault here
    // must not be classified the same as a fault that happened before any
    // password was ever typed.
    //
    // POLLED, not sampled once. Venmo's sign-in submits over XHR and never
    // navigates, so the `waitForLoadState("domcontentloaded")` above returns
    // immediately and guarantees nothing about the login having completed.
    // A single probe here therefore asks "are we signed in?" while the request
    // is still in flight, gets `dead` because Venmo has not answered yet, and
    // throws `venmo_login_incomplete_after_submit` on a login that was about to
    // succeed.
    //
    // Proven from the failed run's retained capture frames (2026-08-26,
    // run_1787774371364, `fixture-captures/venmo/raw/2026-08-26T19-59-31-630Z/`):
    // `venmo-login-after-submit.png` shows the password screen reached, the
    // identifier resolved to the owner's real account, the password field
    // filled, and the submit button rendering a SPINNER — the POST still in
    // flight. `session-establish-venmo-final-verify.png`, captured ~1s later, is
    // pixel-identical: still spinning. The credentials and the flow were both
    // correct; only the verification was early.
    //
    // Same class as the identifier read-back guard added earlier in this file:
    // verify AFTER the async settles, never during. Bounded by
    // POST_SUBMIT_SETTLE_TIMEOUT_MS so a genuinely failed login still fails —
    // a poll that cannot end is the unbounded-await defect wearing a fix's
    // clothes.
    const settleOutcome = await pollForLiveSessionAfterSubmit(page, postSubmitSettleTimeoutMs);
    if (!settleOutcome.settled) {
        // Never reached an observable outcome. Say THAT — an unsettled login is
        // not evidence that the owner's password is wrong, and reporting it as a
        // rejection is how a working credential gets blamed for a slow provider.
        await captureLoginState(capture, page, "venmo-login-did-not-settle");
        // An INVISIBLE scoring challenge is the one cause we can name here, and
        // naming it changes what the owner does about it. reCAPTCHA Enterprise v3
        // renders no widget and no checkbox — it scores the session silently — so
        // the visible-frame check above cannot see it and no error copy appears on
        // the page. Left unnamed, its signature is indistinguishable from a slow
        // provider, which sends the owner looking for a network problem that is
        // not there. Proven live on run_1787785348388: `_GRECAPTCHA` was written
        // one second before the password submit and the request never completed.
        if (await pageLoadedInvisibleScoringChallenge(page)) {
            throw new Error(`${VENMO_SCORING_CHALLENGE}: Venmo scored this sign-in with an invisible reCAPTCHA Enterprise v3 check and never completed it within ${postSubmitSettleTimeoutMs}ms. There is no challenge to solve — v3 scores the browser itself, so retrying unattended will not clear it.`);
        }
        throw new Error(`venmo_login_did_not_complete: no sign-in outcome within ${postSubmitSettleTimeoutMs}ms`);
    }
    const finalProbe = settleOutcome.probe;
    if (finalProbe?.live) {
        return finalProbe;
    }
    return await requestManualLoginForChallenge({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...(completeAssistance ? { completeAssistance } : {}),
        page,
        reason: "automated sign-in did not complete",
        sendInteraction,
    });
}
/**
 * Establish a Venmo browser session, or throw if establishment fails.
 *
 * Resolves with a {@link VenmoAccountProbeResult} on the paths that actually
 * probed — an already-live session, or a completed automated sign-in — and
 * with `null` on every path that ended in an owner handoff (including a
 * replay the handoff triggered). `null` means "the owner's turn is over",
 * NOT "the session is live": those paths deliberately no longer probe,
 * because doing so navigated across origins and destroyed the session the
 * owner had just created (see {@link waitForManualLogin}). The collection
 * step re-establishes origin and fetches `/account` itself, so a handoff
 * that did not really sign in fails there as a named, non-retryable
 * `venmo_session_expired` rather than being asserted — falsely — here.
 *
 * The `null` is load-bearing: returning a fabricated `{ live: true }` would
 * let a caller believe a check happened that never did.
 */
export async function ensureVenmoSession({ assist, capture, checkpoint = noopCheckpoint, completeAssistance, credentials = {}, onCredentialSubmit, page, passwordScreenTimeoutMs, postSubmitSettleTimeoutMs, progress, sendInteraction, }) {
    await checkpoint("venmo-auth-probe");
    const initial = await probeVenmoAccount(page);
    if (initial.live) {
        await checkpoint("venmo-session-already-live");
        return initial;
    }
    const username = credentials.VENMO_USERNAME;
    const password = credentials.VENMO_PASSWORD;
    if (!(username && password)) {
        await ensureManualSessionWithoutCredentials({
            ...(assist ? { assist } : {}),
            ...(capture ? { capture } : {}),
            checkpoint,
            ...(completeAssistance ? { completeAssistance } : {}),
            page,
            sendInteraction,
        });
        // Owner handoff, no probe — see this function's doc.
        return null;
    }
    const result = await loginWithSavedCredentials({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        checkpoint,
        ...(completeAssistance ? { completeAssistance } : {}),
        ...(onCredentialSubmit ? { onCredentialSubmit } : {}),
        page,
        ...(passwordScreenTimeoutMs === undefined
            ? {}
            : { passwordScreenTimeoutMs }),
        ...(postSubmitSettleTimeoutMs === undefined
            ? {}
            : { postSubmitSettleTimeoutMs }),
        ...(progress ? { progress } : {}),
        sendInteraction,
        username,
        password,
    });
    if (result === OWNER_HANDOFF_COMPLETE) {
        // Owner handoff, no probe — see this function's doc.
        return null;
    }
    if (result.live) {
        return result;
    }
    throw new Error("venmo_login_incomplete_after_submit");
}
