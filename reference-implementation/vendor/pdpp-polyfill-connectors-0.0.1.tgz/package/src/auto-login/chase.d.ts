/**
 * Chase automated session management.
 *
 * Chase uses `mds-*` custom elements (Web Components with Shadow DOM) for
 * its 2FA flow. The visual options and submit buttons are not clickable
 * via attribute selectors on the host elements — the host elements have
 * zero bounding box because the actual rendered content lives inside
 * mds-list's shadow root. Playwright's text-based and role-based locators
 * pierce shadow DOM and return the real clickable nodes.
 *
 * Flow:
 *   1. Probe — navigate to /web/auth/dashboard, check for "Sign out" text
 *   2. Logon — fill #userId-text-input-field + #password-text-input-field
 *      and click #signin-button
 *   3. Identity challenge — "Confirm Your Identity" page asks the user to
 *      pick a method (text / call / email). We auto-pick per
 *      CHASE_2FA_METHOD env (default 'text'). The method options render as
 *      `<a href="javascript:void(0)">` with aria-label starting with the
 *      short label ("Get a text" / "Call me" / "Email me").
 *   4. OTP — an `mds-text-input-secure#otpInput` wraps a shadow-DOM
 *      `<input type="password">`. Target that component explicitly:
 *      generic password selectors can hit the login password field or
 *      stale hidden controls.
 *      `pressSequentially` fires per-character events that the framework's
 *      validation listens for (bulk fill() did not trigger validation).
 *   5. Submit — click the rendered button inside `mds-button#next-content`.
 *      Text locators can resolve to Chase's hidden accessibility label.
 *
 * Selectors verified live 2026-04-21. Detailed probe history lives in git.
 */
import type { BrowserContext, Page } from "playwright";
import type { InteractionRequest, InteractionResponse } from "../connector-runtime.ts";
interface EnsureChaseSessionArgs {
    context: BrowserContext;
    /**
     * Credentials the runtime resolved for THIS run's connection (see
     * `login-credentials.ts`). Optional so a direct, non-runtime caller can omit
     * it; an absent credential is a supported state that routes to manual
     * sign-in, not an error.
     */
    credentials?: Readonly<Record<string, string | undefined>>;
    onCredentialSubmit?: () => void;
    page: Page;
    sendInteraction: (req: InteractionRequest) => Promise<InteractionResponse>;
}
type ChaseBrowserSurfaceState = "open" | "page_closed" | "context_closed" | "browser_disconnected";
interface ChaseBrowserSurfaceMonitor {
    browserDisconnected: () => boolean;
    contextClosed: () => boolean;
}
export declare function classifyChaseBrowserSurface(page: Page, surface: ChaseBrowserSurfaceMonitor): ChaseBrowserSurfaceState;
export declare function probeChaseSession(context: BrowserContext, page: Page): Promise<{
    loggedIn: boolean;
    page: Page;
}>;
export declare function ensureChaseSession({ context, credentials, onCredentialSubmit, page, sendInteraction, }: EnsureChaseSessionArgs): Promise<boolean>;
export {};
//# sourceMappingURL=chase.d.ts.map