// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
/**
 * First aliased name whose value is present and non-blank.
 *
 * Written as `find` rather than a loop with a trailing `return undefined`
 * because two enabled rules disagree about that trailing statement: Biome's
 * `noUselessUndefined` rejects the explicit `return undefined`, and
 * TypeScript's `noImplicitReturns` rejects its absence. Satisfying one fails
 * the other, and `verify` runs both. `find` has a single exit, so neither rule
 * has anything to object to and neither needs suppressing.
 */
function firstNonEmpty(credentials, names) {
    return names
        .map((name) => credentials[name])
        .find((value) => typeof value === "string" && value.trim().length > 0);
}
/**
 * Resolve one connection's sign-in pair from the runtime-supplied credentials.
 *
 * Returns a discriminated result rather than throwing or returning
 * `undefined`: an absent credential is a normal, expected state (the owner may
 * have deliberately chosen to sign in by hand), but it must be *named* as such
 * so the caller cannot silently conflate it with a page failure.
 *
 * A pair is BOTH-OR-NOTHING. A username with no password is reported absent
 * with the password named as missing, never submitted as half a login — the
 * same fail-closed rule `injectSecretBundle` applies one layer down.
 */
export function resolveLoginCredentials(credentials, fields, connectorName) {
    const source = credentials ?? {};
    const username = firstNonEmpty(source, fields.username);
    const password = firstNonEmpty(source, fields.password);
    if (username && password) {
        return { kind: "resolved", password, username };
    }
    const missing = [];
    if (!username) {
        missing.push(fields.username[0] ?? "username");
    }
    if (!password) {
        missing.push(fields.password[0] ?? "password");
    }
    return {
        kind: "absent",
        missing,
        reason: noStoredCredentialReason(connectorName, missing),
    };
}
/**
 * The owner-facing sentence for an absent credential.
 *
 * Deliberately says "no stored credential for this connection" rather than
 * anything about the page. Before this existed, a run with no credential
 * reported "sign-in form did not render" / "unexpected UI" — which reads as a
 * provider outage and sent owners to debug the wrong thing.
 */
export function noStoredCredentialReason(connectorName, missing) {
    const fieldList = missing.length > 0 ? missing.join(", ") : "username, password";
    return (`no stored credential for this ${connectorName} connection (missing: ${fieldList}). ` +
        "Automated sign-in was not attempted. Save this connection's credentials to enable it.");
}
