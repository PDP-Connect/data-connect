/**
 * GitHub automated login + sudo-mode re-auth.
 *
 * Probes the shared Playwright profile for a live github.com session.
 * Falls back to username/password login. Handles sudo mode (required before
 * creating PATs, ~2h session). TOTP codes always come via INTERACTION —
 * the operator supplies the 6-digit code (ntfy → phone or file drop).
 *
 * Device-verification email on first login from a new IP/UA is NOT handled
 * automatically — the owner must have done a headed bootstrap-browser pass first
 * so the IP + profile are trusted.
 */
import type { Page } from "playwright";
import type { InteractionRequest, InteractionResponse } from "../connector-runtime.ts";
type SendInteraction = (req: InteractionRequest) => Promise<InteractionResponse>;
interface EnsureGithubSessionArgs {
    page: Page;
    sendInteraction: SendInteraction;
}
interface EnsureSudoModeArgs {
    sendInteraction?: SendInteraction;
}
/**
 * Ensure the browser is logged into github.com. Returns when ready.
 */
export declare function ensureGithubSession({ page, sendInteraction, }: EnsureGithubSessionArgs): Promise<boolean>;
/**
 * Ensure the session is in sudo mode (required for PAT creation). Caller
 * should navigate the page to a sudo-triggering URL first (e.g.
 * /settings/tokens/new) and then call this.
 */
export declare function ensureSudoMode(page: Page, { sendInteraction }?: EnsureSudoModeArgs): Promise<boolean>;
export {};
//# sourceMappingURL=github.d.ts.map