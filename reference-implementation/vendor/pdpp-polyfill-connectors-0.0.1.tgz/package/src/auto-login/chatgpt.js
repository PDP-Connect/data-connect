// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { manualAction } from "../browser-handoff.js";
import { detectCloudflareChallenge } from "../platform-probes.js";
import { resolveLoginCredentials, } from "./login-credentials.js";
/**
 * Where ChatGPT's sign-in pair lives in the runtime-resolved `credentials`
 * object. Must match the manifest's `credential_capture` env mapping (see
 * `src/generated/static-secret-registry.generated.ts`).
 */
const CHATGPT_LOGIN_FIELDS = {
    password: ["CHATGPT_PASSWORD"],
    username: ["CHATGPT_USERNAME"],
};
const APPROVE_SIGN_IN_TEXT = /approve sign-in/i;
const CHATGPT_DEVICE_TEXT = /chatgpt app|your devices/i;
const CONTINUE_WITH_PASSWORD_NAME = /^continue with password$/i;
const LOG_IN_NAME = /^log in$/i;
const RESEND_PROMPT_TEXT = /resend prompt/i;
const SENT_NOTIFICATION_TEXT = /sent a notification/i;
const TRY_WITH_EMAIL_TEXT = /try with email/i;
const STORED_CREDENTIAL_REJECTION_TEXT = /incorrect email address or password|incorrect password|invalid password|wrong password|email or password is incorrect/i;
export const CHATGPT_PUSH_APPROVAL_ASSISTANCE_MESSAGE = "ChatGPT sent an app approval notification. Approve it in the ChatGPT app; PDPP will continue automatically after ChatGPT confirms the session.";
export const CHATGPT_PUSH_APPROVAL_PROGRESS_MESSAGE = CHATGPT_PUSH_APPROVAL_ASSISTANCE_MESSAGE;
export const CHATGPT_PUSH_APPROVAL_FALLBACK_MESSAGE = "ChatGPT approval did not complete automatically; open the ChatGPT app to approve it. PDPP resumes when the session continues.";
export const CHATGPT_BROWSER_LOGIN_ASSISTANCE_MESSAGE = "ChatGPT could not finish sign-in automatically; open the browser to continue. PDPP resumes when sign-in succeeds.";
export const CHATGPT_BROWSER_LOGIN_FALLBACK_MESSAGE = "ChatGPT could not finish sign-in automatically; open the browser to continue. PDPP resumes when sign-in succeeds.";
export const CHATGPT_SESSION_REQUIRED_NON_INTERACTIVE_MESSAGE = "chatgpt_session_required: ChatGPT session is not active; start an owner-attended manual refresh to repair authentication.";
export const CHATGPT_STORED_CREDENTIAL_REJECTED_MESSAGE = "chatgpt_stored_credential_rejected: ChatGPT rejected the stored username/password credential.";
const PUSH_APPROVAL_POLL_INTERVAL_MS = 5000;
const BROWSER_LOGIN_POLL_INTERVAL_MS = 5000;
/**
 * Bounded retry for the INITIAL `/api/auth/session` probe in
 * `navigateAndProbeSession`. Root cause (chatgpt-assistance-false-positive,
 * 2026-08-18): production evidence showed a run with a cookie DB proving a
 * valid, unexpired `__Secure-next-auth.session-token` (good for months)
 * still got `api_session_user: false` on a single unretried probe fired
 * exactly 3s after `page.goto` — a transient Cloudflare re-check or
 * cookie-sync race on that one fetch, not a genuinely dead session. Because
 * `checkSession` collapses every failure mode (network error, non-2xx,
 * challenge-page HTML instead of JSON) into the same `false`, that one blip
 * fell through to the full credential-login path, which immediately hit the
 * "ChatGPT sent an app approval notification" assistance prompt on an
 * account that never needed to re-authenticate — and when the push-approval
 * poll timed out (15 min), the whole run failed for something a few extra
 * seconds of retry would have avoided entirely. A single owner-attended
 * account re-auth is expensive (a live login); a handful of cheap in-process
 * retries on an already-open page is not.
 */
const SESSION_PROBE_RETRY_ATTEMPTS = 4;
const SESSION_PROBE_RETRY_DELAY_MS = 1500;
/**
 * Default push-approval observation budget. Raised from the original 180s
 * (36 × 5s) to 900s so realistic human app-approval latency auto-resumes via
 * the non-blocking poll instead of falling through to the blocking owner-click
 * fallback. Override with `PDPP_CHATGPT_PUSH_APPROVAL_TIMEOUT_MS`.
 *
 * The poll checkpoints on every iteration (see `handlePushApproval`), so the
 * session-establishment watchdog is not tripped by a long-but-progressing wait
 * even though this budget exceeds the watchdog's default 120s no-progress
 * deadline.
 */
const PUSH_APPROVAL_DEFAULT_TIMEOUT_MS = 900_000;
const PUSH_APPROVAL_TIMEOUT_ENV = "PDPP_CHATGPT_PUSH_APPROVAL_TIMEOUT_MS";
const BROWSER_LOGIN_DEFAULT_TIMEOUT_MS = 1_800_000;
const BROWSER_LOGIN_TIMEOUT_ENV = "PDPP_CHATGPT_BROWSER_LOGIN_TIMEOUT_MS";
const CHATGPT_HOME_URL = "https://chatgpt.com/";
const CHATGPT_ORIGIN_PROBE_EVERY_ATTEMPTS = 6;
/**
 * Resolve the push-approval observation budget in ms. Honors a positive-integer
 * `PDPP_CHATGPT_PUSH_APPROVAL_TIMEOUT_MS`; otherwise the raised default.
 */
export function resolveChatGptPushApprovalTimeoutMs(env = process.env) {
    const raw = env[PUSH_APPROVAL_TIMEOUT_ENV]?.trim();
    if (!raw) {
        return PUSH_APPROVAL_DEFAULT_TIMEOUT_MS;
    }
    const parsed = Number.parseInt(raw, 10);
    if (!(Number.isFinite(parsed) && parsed > 0)) {
        return PUSH_APPROVAL_DEFAULT_TIMEOUT_MS;
    }
    return parsed;
}
/** Number of poll iterations for the resolved budget (at least one). */
function pushApprovalPollAttempts(env = process.env) {
    return Math.max(1, Math.ceil(resolveChatGptPushApprovalTimeoutMs(env) / PUSH_APPROVAL_POLL_INTERVAL_MS));
}
export function resolveChatGptBrowserLoginTimeoutMs(env = process.env) {
    const raw = env[BROWSER_LOGIN_TIMEOUT_ENV]?.trim();
    if (!raw) {
        return BROWSER_LOGIN_DEFAULT_TIMEOUT_MS;
    }
    const parsed = Number.parseInt(raw, 10);
    if (!(Number.isFinite(parsed) && parsed > 0)) {
        return BROWSER_LOGIN_DEFAULT_TIMEOUT_MS;
    }
    return parsed;
}
function browserLoginPollAttempts(env = process.env) {
    return Math.max(1, Math.ceil(resolveChatGptBrowserLoginTimeoutMs(env) / BROWSER_LOGIN_POLL_INTERVAL_MS));
}
export function chatGptPushApprovalAssistance(env = process.env) {
    return {
        message: CHATGPT_PUSH_APPROVAL_ASSISTANCE_MESSAGE,
        progress_posture: "running",
        owner_action: "act_elsewhere",
        response_contract: "none",
        sensitivity: "non_secret",
        timeout_seconds: Math.ceil(resolveChatGptPushApprovalTimeoutMs(env) / 1000),
    };
}
export function chatGptBrowserLoginAssistance(env = process.env) {
    return {
        attachments: [{ kind: "browser_surface", role: "streaming_companion" }],
        message: CHATGPT_BROWSER_LOGIN_ASSISTANCE_MESSAGE,
        owner_action: "operate_attachment",
        progress_posture: "blocked",
        response_contract: "none",
        sensitivity: "non_secret",
        timeout_seconds: Math.ceil(resolveChatGptBrowserLoginTimeoutMs(env) / 1000),
    };
}
export function interactionResponseCode(resp) {
    return resp.data?.code ?? resp.value ?? null;
}
function chatGptAuthProbeDiagnosticMessage(diagnostic) {
    return `ChatGPT auth probe diagnostic ${JSON.stringify(diagnostic)}`;
}
function checkpointOption(checkpoint) {
    return checkpoint ? { checkpoint } : {};
}
function sessionAssistanceHooks(hooks) {
    const result = {};
    if (hooks.assist) {
        result.assist = hooks.assist;
    }
    if (hooks.capture) {
        result.capture = hooks.capture;
    }
    if (hooks.checkpoint) {
        result.checkpoint = hooks.checkpoint;
    }
    if (hooks.completeAssistance) {
        result.completeAssistance = hooks.completeAssistance;
    }
    if (hooks.progress) {
        result.progress = hooks.progress;
    }
    return result;
}
export function chatGptAllowsInteractiveAuthRepair(env = process.env) {
    const triggerKind = env.PDPP_RUN_TRIGGER_KIND?.trim();
    if (!triggerKind) {
        return true;
    }
    return triggerKind === "manual";
}
async function checkSession(page) {
    try {
        const r = await page.evaluate(async () => {
            try {
                const res = await fetch("/api/auth/session", {
                    credentials: "include",
                });
                if (!res.ok) {
                    return null;
                }
                const text = await res.text();
                try {
                    return JSON.parse(text);
                }
                catch {
                    return null;
                }
            }
            catch {
                return null;
            }
        });
        return Boolean(r?.user);
    }
    catch {
        return false;
    }
}
/**
 * Retry the `/api/auth/session` probe a bounded number of times before
 * concluding the session is genuinely inactive. See
 * `SESSION_PROBE_RETRY_ATTEMPTS` for why: `checkSession` collapses network
 * error, non-2xx, and challenge-page HTML into the same `false`, so a single
 * unretried call cannot distinguish "the cookie is dead" from "this one
 * request got a transient hiccup." Returns as soon as any attempt succeeds;
 * `attempts` in the result is how many calls it actually took, so the
 * diagnostic honestly shows whether a `false` verdict survived retry.
 *
 * Waits via `page.waitForTimeout` (not a bare `setTimeout`) — same wait
 * primitive every other poll in this module uses, so tests can drive it
 * through the existing `page.waitForTimeout` mock instead of real wall-clock
 * delay.
 */
async function checkSessionWithRetry(page, attempts = SESSION_PROBE_RETRY_ATTEMPTS) {
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
        if (await checkSession(page)) {
            return { active: true, attempts: attempt };
        }
        if (attempt < attempts) {
            await page.waitForTimeout(SESSION_PROBE_RETRY_DELAY_MS);
        }
    }
    return { active: false, attempts };
}
async function checkLoggedInViaDOMDetails(page) {
    try {
        const result = await page.evaluate(() => {
            const allButtons = document.querySelectorAll("button, a");
            const hasLoginButton = Array.from(allButtons).some((el) => {
                const text = el.textContent?.toLowerCase() ?? "";
                return text.includes("log in") || text.includes("sign up");
            });
            const hasSidebar = !!document.querySelector('nav[aria-label="Chat history"]') ||
                !!document.querySelector('nav a[href^="/c/"]') ||
                document.querySelectorAll("nav").length > 0;
            const hasUserMenu = !!document.querySelector('[data-testid="profile-button"]') ||
                !!document.querySelector('button[aria-label*="User menu"]');
            return {
                dom_logged_in: !hasLoginButton && (hasSidebar || hasUserMenu),
                has_login_or_signup: hasLoginButton,
                has_sidebar: hasSidebar,
                has_user_menu: hasUserMenu,
            };
        });
        if (result && typeof result === "object") {
            return {
                dom_logged_in: result.dom_logged_in === true,
                has_login_or_signup: result.has_login_or_signup === true,
                has_sidebar: result.has_sidebar === true,
                has_user_menu: result.has_user_menu === true,
            };
        }
        if (typeof result === "boolean") {
            return {
                dom_logged_in: result,
                has_login_or_signup: false,
                has_sidebar: result,
                has_user_menu: false,
            };
        }
    }
    catch {
        // Fall through to the all-false safe diagnostic below.
    }
    return {
        dom_logged_in: false,
        has_login_or_signup: false,
        has_sidebar: false,
        has_user_menu: false,
    };
}
async function checkLoggedInViaDOM(page) {
    return (await checkLoggedInViaDOMDetails(page)).dom_logged_in;
}
export function isLikelyChatGptPushApprovalText(text) {
    const normalized = text.toLowerCase().replace(/\s+/g, " ").trim();
    if (!normalized) {
        return false;
    }
    const hasApproveHeading = normalized.includes("approve sign-in");
    const hasNotificationCopy = normalized.includes("sent a notification");
    const hasDeviceCopy = normalized.includes("chatgpt app") || normalized.includes("your devices");
    const hasResendPrompt = normalized.includes("resend prompt");
    const hasEmailFallback = normalized.includes("try with email");
    return ((hasApproveHeading &&
        (hasNotificationCopy || hasDeviceCopy || hasResendPrompt)) ||
        (hasNotificationCopy && hasDeviceCopy) ||
        (hasResendPrompt &&
            hasEmailFallback &&
            (hasNotificationCopy || hasDeviceCopy)));
}
async function hasVisibleText(page, text) {
    try {
        await page
            .getByText(text)
            .first()
            .waitFor({ state: "visible", timeout: 500 });
        return true;
    }
    catch {
        return false;
    }
}
async function clickFirstVisible(locators, timeoutMs = 1000) {
    for (const locator of locators) {
        const candidate = locator.first();
        try {
            await candidate.waitFor({ state: "visible", timeout: timeoutMs });
            await candidate.click({ timeout: timeoutMs });
            return true;
        }
        catch {
            // Try the next bounded, accessible locator.
        }
    }
    return false;
}
async function isLikelyChatGptPushApprovalPage(page) {
    const [hasApproveHeading, hasNotificationCopy, hasDeviceCopy, hasResendPrompt, hasEmailFallback,] = await Promise.all([
        hasVisibleText(page, APPROVE_SIGN_IN_TEXT),
        hasVisibleText(page, SENT_NOTIFICATION_TEXT),
        hasVisibleText(page, CHATGPT_DEVICE_TEXT),
        hasVisibleText(page, RESEND_PROMPT_TEXT),
        hasVisibleText(page, TRY_WITH_EMAIL_TEXT),
    ]);
    return ((hasApproveHeading &&
        (hasNotificationCopy || hasDeviceCopy || hasResendPrompt)) ||
        (hasNotificationCopy && hasDeviceCopy) ||
        (hasResendPrompt &&
            hasEmailFallback &&
            (hasNotificationCopy || hasDeviceCopy)));
}
function currentPageUrl(page) {
    try {
        const raw = page.url();
        return raw.length > 0 ? raw : null;
    }
    catch {
        return null;
    }
}
function isChatGptOrigin(url) {
    if (!url) {
        return false;
    }
    try {
        return new URL(url).hostname === "chatgpt.com";
    }
    catch {
        return false;
    }
}
async function isChatGptSessionActiveOnPage(page) {
    return (await checkSession(page)) || (await checkLoggedInViaDOM(page));
}
async function activatePrimaryPageFromChatGptOriginProbe(page) {
    if (isChatGptOrigin(currentPageUrl(page))) {
        return false;
    }
    let probePage = null;
    try {
        probePage = await page.context().newPage();
        await probePage
            .goto(CHATGPT_HOME_URL, {
            waitUntil: "domcontentloaded",
            timeout: 30_000,
        })
            .catch(() => undefined);
        await probePage.waitForTimeout(1000);
        if (!(await isChatGptSessionActiveOnPage(probePage))) {
            return false;
        }
        // The same browser context now has a live ChatGPT session. Move the primary
        // connector page back to ChatGPT before collection starts; otherwise the
        // collector would keep running API fetches from the auth.openai.com approval
        // page that triggered the cross-origin probe.
        await page
            .goto(CHATGPT_HOME_URL, {
            waitUntil: "domcontentloaded",
            timeout: 30_000,
        })
            .catch(() => undefined);
        await page.waitForTimeout(1000);
        return await isChatGptSessionActiveOnPage(page);
    }
    catch {
        return false;
    }
    finally {
        await probePage?.close().catch(() => undefined);
    }
}
async function isChatGptSessionActive(page, options = {}) {
    if (await isChatGptSessionActiveOnPage(page)) {
        return true;
    }
    return options.allowOriginProbe === true
        ? await activatePrimaryPageFromChatGptOriginProbe(page)
        : false;
}
async function isStoredCredentialRejectedPage(page) {
    return await hasVisibleText(page, STORED_CREDENTIAL_REJECTION_TEXT);
}
function classifyChatGptRoute(page) {
    const maybeUrl = page.url;
    if (typeof maybeUrl !== "function") {
        return "unknown";
    }
    let rawUrl;
    try {
        rawUrl = String(maybeUrl.call(page) ?? "");
    }
    catch {
        return "unknown";
    }
    if (!rawUrl) {
        return "unknown";
    }
    if (rawUrl === "about:blank") {
        return "about_blank";
    }
    let url;
    try {
        url = new URL(rawUrl);
    }
    catch {
        return "unparseable";
    }
    if (url.hostname !== "chatgpt.com") {
        return "other";
    }
    if (url.pathname === "/" || url.pathname === "") {
        return "home";
    }
    if (url.pathname.startsWith("/auth")) {
        return "auth";
    }
    if (url.pathname.startsWith("/c/")) {
        return "conversation";
    }
    return "other";
}
async function navigateAndProbeSession(page, progress) {
    await page
        .goto("https://chatgpt.com/", {
        waitUntil: "domcontentloaded",
        timeout: 30_000,
    })
        .catch(() => undefined);
    await page.waitForTimeout(3000);
    const { active: apiSessionUser, attempts: apiSessionUserAttempts } = await checkSessionWithRetry(page);
    const domProbe = await checkLoggedInViaDOMDetails(page);
    await progress?.(chatGptAuthProbeDiagnosticMessage({
        object: "chatgpt_auth_probe",
        stage: "initial",
        api_session_user: apiSessionUser,
        api_session_user_attempts: apiSessionUserAttempts,
        ...domProbe,
        route_class: classifyChatGptRoute(page),
        decision: apiSessionUser
            ? "accepted_by_api_session"
            : "credential_login_required",
    }));
    return apiSessionUser;
}
async function openChatGptLogin(page) {
    await page.goto("https://chatgpt.com/auth/login", {
        waitUntil: "domcontentloaded",
        timeout: 30_000,
    });
    await page.waitForTimeout(2500);
}
async function clickIntermediateLogin(page) {
    await clickFirstVisible([
        page.getByRole("button", { name: LOG_IN_NAME }),
        page.getByRole("link", { name: LOG_IN_NAME }),
    ]);
    await page.waitForTimeout(3000);
}
async function pollSessionReadiness({ checkpoint, intervalMs, page, attempts, waitingCheckpointDetailPrefix, waitingCheckpointPrefix, }) {
    for (let attempt = 0; attempt < attempts; attempt += 1) {
        await checkpoint?.(waitingCheckpointPrefix);
        await page.waitForTimeout(intervalMs);
        if ((attempt + 1) % 12 === 0) {
            await checkpoint?.(`${waitingCheckpointDetailPrefix ?? waitingCheckpointPrefix}-${String(attempt + 1)}`);
        }
        const allowOriginProbe = attempt === 0 ||
            (attempt + 1) % CHATGPT_ORIGIN_PROBE_EVERY_ATTEMPTS === 0;
        if (await isChatGptSessionActive(page, { allowOriginProbe })) {
            return true;
        }
    }
    return false;
}
export async function handleBrowserLoginAssistance({ assist, capture, checkpoint, completeAssistance, diagnosticMessage, message = CHATGPT_BROWSER_LOGIN_ASSISTANCE_MESSAGE, page, progress, reason = "login", sendInteraction, }) {
    let assistanceRequestId = null;
    if (assist) {
        assistanceRequestId = await assist({
            ...chatGptBrowserLoginAssistance(),
            message,
        });
    }
    else {
        await progress?.(message);
    }
    if (await pollSessionReadiness({
        ...checkpointOption(checkpoint),
        attempts: browserLoginPollAttempts(),
        intervalMs: BROWSER_LOGIN_POLL_INTERVAL_MS,
        page,
        waitingCheckpointPrefix: "chatgpt-browser-login-poll",
    })) {
        if (assistanceRequestId && completeAssistance) {
            await completeAssistance(assistanceRequestId, "resolved", {
                message: "ChatGPT login completed and the connector is continuing.",
            });
        }
        await progress?.("ChatGPT login completed; continuing collection.");
        return true;
    }
    if (assistanceRequestId && completeAssistance) {
        await completeAssistance(assistanceRequestId, "escalated", {
            message: diagnosticMessage ??
                "ChatGPT login did not complete automatically; waiting for explicit browser confirmation.",
        });
    }
    else if (diagnosticMessage) {
        await progress?.(diagnosticMessage);
    }
    await manualAction({
        ...(capture ? { capture } : {}),
        page,
        message: assist ? CHATGPT_BROWSER_LOGIN_FALLBACK_MESSAGE : message,
        reason,
        timeoutSeconds: 1800,
    }, sendInteraction);
    await page.waitForTimeout(3000);
    return await isChatGptSessionActive(page);
}
/**
 * Hand the unexpected/Cloudflare-challenge login UI to the operator, then
 * re-probe the session. Returns `true` when the operator completed login in
 * the streaming companion (or on a host desktop) and the session is now
 * active; `false` when login still has not happened.
 *
 * This mirrors `fallbackForPostSubmitLogin` and the reddit connector's
 * captcha fallback: completing the manual step is a *signal to re-check*, not
 * an instruction to end the run. Earlier this helper threw unconditionally
 * after `manualAction` resolved, so the operator's "I completed login" click
 * always ended the run even when they had just solved the challenge — the
 * message tells them to "complete login," so the connector must honor that.
 */
async function fallbackForUnexpectedLoginUi({ assist, capture, checkpoint, completeAssistance, page, progress, sendInteraction, }) {
    const cf = await detectCloudflareChallenge(page);
    const diagnosticMessage = cf.isChallenge
        ? `Cloudflare challenge confirmed (signals: ${cf.signals.join(", ")}). Complete the "Verify you are human" check in the streaming companion, then the run will resume — or rerun with PDPP_BROWSER_HEADLESS=0 (or unset it) on a browser-capable deployment.`
        : "ChatGPT login inputs were not found and no Cloudflare challenge was detected (the login page may have changed). Complete login in the streaming companion, or rerun with PDPP_BROWSER_HEADLESS=0 (or unset it) on a browser-capable deployment.";
    return await handleBrowserLoginAssistance({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...(checkpoint ? { checkpoint } : {}),
        ...(completeAssistance ? { completeAssistance } : {}),
        diagnosticMessage,
        message: CHATGPT_BROWSER_LOGIN_FALLBACK_MESSAGE,
        page,
        ...(progress ? { progress } : {}),
        reason: "captcha",
        sendInteraction,
    });
}
/**
 * Returns `true` when login is already complete (the operator finished it in
 * the streaming companion during the unexpected-UI fallback) and the caller
 * should stop the automated flow; `false` when the connector should continue
 * driving the form. Throws `chatgpt_login_unexpected_ui` only when the
 * expected inputs never appear *and* the operator's manual step did not yield
 * an active session.
 */
async function findAndFillEmail({ assist, capture, checkpoint, completeAssistance, email, page, progress, sendInteraction, }) {
    const emailIn = page
        .locator('input[type="email"], input[name="username"], input[name="email"]')
        .first();
    if (!(await emailIn.count())) {
        if (await fallbackForUnexpectedLoginUi({
            ...(assist ? { assist } : {}),
            ...(capture ? { capture } : {}),
            ...(checkpoint ? { checkpoint } : {}),
            ...(completeAssistance ? { completeAssistance } : {}),
            page,
            ...(progress ? { progress } : {}),
            sendInteraction,
        })) {
            return true;
        }
        throw new Error("chatgpt_login_unexpected_ui");
    }
    await emailIn.fill(email);
    await page
        .locator('button[type="submit"], :text-is("Continue")')
        .first()
        .click()
        .catch(() => undefined);
    await page.waitForTimeout(3000);
    return false;
}
async function continueWithPasswordIfPresent(page) {
    const clicked = await clickFirstVisible([
        page.getByRole("button", { name: CONTINUE_WITH_PASSWORD_NAME }),
        page.getByRole("link", { name: CONTINUE_WITH_PASSWORD_NAME }),
    ]);
    if (clicked) {
        await page.waitForTimeout(3000);
    }
}
/**
 * Drive the ChatGPT app push-approval flow. Exported for focused tests of the
 * non-blocking observation poll (watchdog checkpointing, auto-resume without an
 * interaction, and escalation ordering); production reaches it via
 * `submitPasswordAndHandleSecondFactor`.
 */
export async function handlePushApproval({ assist, capture, checkpoint, completeAssistance, page, progress, sendInteraction, }) {
    if (!(await isLikelyChatGptPushApprovalPage(page))) {
        return false;
    }
    await capture?.captureDom(page, "auth-push-approval-detected");
    let assistanceRequestId = null;
    if (assist) {
        assistanceRequestId = await assist(chatGptPushApprovalAssistance());
    }
    else {
        await progress?.(CHATGPT_PUSH_APPROVAL_PROGRESS_MESSAGE);
    }
    await checkpoint?.("chatgpt-push-approval-requested");
    // Non-blocking observation window: poll session readiness across the (now
    // owner-configurable) budget. The owner approves the sign-in in the ChatGPT
    // app out of band; the moment the session goes active we resolve the
    // assistance and continue — no INTERACTION, no owner click. `checkpoint` is
    // called on every iteration so the session-establishment watchdog sees
    // forward progress and does not fail the run closed even though this budget
    // exceeds its default 120s no-progress deadline (the run IS progressing — it
    // is actively probing readiness). A genuinely wedged page that hangs the
    // probe stops advancing the checkpoint, so the watchdog still catches it.
    if (await pollSessionReadiness({
        ...checkpointOption(checkpoint),
        attempts: pushApprovalPollAttempts(),
        intervalMs: PUSH_APPROVAL_POLL_INTERVAL_MS,
        page,
        waitingCheckpointDetailPrefix: "chatgpt-push-approval-waiting",
        waitingCheckpointPrefix: "push-approval-poll",
    })) {
        if (assistanceRequestId && completeAssistance) {
            await completeAssistance(assistanceRequestId, "resolved", {
                message: "The external approval completed and the connector is continuing.",
            });
        }
        await progress?.("ChatGPT app approval accepted; continuing collection.");
        return true;
    }
    if (assistanceRequestId && completeAssistance) {
        await completeAssistance(assistanceRequestId, "escalated", {
            message: "External approval did not complete automatically; falling back to browser confirmation.",
        });
    }
    await manualAction({
        ...(capture ? { capture } : {}),
        page,
        message: CHATGPT_PUSH_APPROVAL_FALLBACK_MESSAGE,
        reason: "2fa",
        timeoutSeconds: 1800,
    }, sendInteraction);
    await page.waitForTimeout(3000);
    return await isChatGptSessionActive(page);
}
async function handleOtpIfPresent({ page, sendInteraction, }) {
    const tfaIn = page
        .locator('input[name="code"], input[type="tel"], input[inputmode="numeric"]')
        .first();
    if (!(await tfaIn.count())) {
        return;
    }
    const resp = await sendInteraction({
        kind: "otp",
        message: "ChatGPT requires a 2FA verification code. Enter the 6-digit code:",
        timeout_seconds: 300,
    });
    const code = interactionResponseCode(resp);
    if (!code) {
        return;
    }
    await tfaIn.fill(code);
    await page
        .locator('button[type="submit"]')
        .first()
        .click()
        .catch(() => undefined);
    await page.waitForTimeout(5000);
}
async function submitPasswordAndHandleSecondFactor({ assist, capture, checkpoint, completeAssistance, onCredentialSubmit, page, password, progress, sendInteraction, }) {
    const passwordIn = page.locator('input[type="password"]').first();
    if (!(await passwordIn.count())) {
        throw new Error("chatgpt_login_no_password_field");
    }
    await passwordIn.fill(password);
    await page
        .locator('button[type="submit"], :text-is("Continue")')
        .first()
        .click()
        .catch(() => undefined);
    onCredentialSubmit?.();
    await page.waitForTimeout(5000);
    await capture?.captureDom(page, "auth-after-password-submit");
    if (await isStoredCredentialRejectedPage(page)) {
        throw new Error(CHATGPT_STORED_CREDENTIAL_REJECTED_MESSAGE);
    }
    if (await handlePushApproval({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...(completeAssistance ? { completeAssistance } : {}),
        ...checkpointOption(checkpoint),
        page,
        ...(progress ? { progress } : {}),
        sendInteraction,
    })) {
        return true;
    }
    await handleOtpIfPresent({ page, sendInteraction });
    return false;
}
async function waitForSubmittedLogin(page) {
    for (let attempt = 0; attempt < 18; attempt += 1) {
        await page.waitForTimeout(5000);
        if (await isChatGptSessionActive(page)) {
            return true;
        }
    }
    return false;
}
async function fallbackForPostSubmitLogin({ assist, capture, checkpoint, completeAssistance, page, progress, sendInteraction, }) {
    return await handleBrowserLoginAssistance({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...(checkpoint ? { checkpoint } : {}),
        ...(completeAssistance ? { completeAssistance } : {}),
        diagnosticMessage: "ChatGPT login submitted but session still is not active. Use the streaming companion to complete login (Cloudflare challenge, 2FA, etc.). PDPP will continue automatically after ChatGPT confirms the session.",
        message: CHATGPT_BROWSER_LOGIN_FALLBACK_MESSAGE,
        page,
        ...(progress ? { progress } : {}),
        reason: "login",
        sendInteraction,
    });
}
/**
 * Drive the password form, second-factor (push approval / OTP), and the
 * post-submit confirmation / manual fallback once the login UI is present and
 * the email step has been completed. Returns `true` when the session is active;
 * throws `chatgpt_login_post_submit_failed` only when every path has been
 * exhausted without an active session. Extracted from `ensureChatGptSession`
 * to keep that entrypoint's branching legible.
 */
async function driveLoginFormAndConfirm({ assist, capture, checkpoint, completeAssistance, onCredentialSubmit, page, password, progress, sendInteraction, }) {
    await continueWithPasswordIfPresent(page);
    const hooks = sessionAssistanceHooks({
        assist,
        capture,
        checkpoint,
        completeAssistance,
        progress,
    });
    if (await submitPasswordAndHandleSecondFactor({
        ...hooks,
        ...(onCredentialSubmit ? { onCredentialSubmit } : {}),
        page,
        password,
        sendInteraction,
    })) {
        return true;
    }
    if (await waitForSubmittedLogin(page)) {
        return true;
    }
    if (await fallbackForPostSubmitLogin({
        ...hooks,
        page,
        sendInteraction,
    })) {
        return true;
    }
    throw new Error("chatgpt_login_post_submit_failed");
}
async function repairWithManualBrowserLogin({ assist, capture, checkpoint, completeAssistance, credentialReason, page, progress, sendInteraction, }) {
    await openChatGptLogin(page);
    return await handleBrowserLoginAssistance({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...checkpointOption(checkpoint),
        ...(completeAssistance ? { completeAssistance } : {}),
        ...(credentialReason
            ? {
                message: `${credentialReason} ${CHATGPT_BROWSER_LOGIN_ASSISTANCE_MESSAGE}`,
            }
            : {}),
        page,
        ...(progress ? { progress } : {}),
        reason: "login",
        sendInteraction,
    });
}
async function driveStoredCredentialAuthRepair({ assist, capture, checkpoint, completeAssistance, email, onCredentialSubmit, page, password, progress, sendInteraction, }) {
    await openChatGptLogin(page);
    await clickIntermediateLogin(page);
    // If the expected login UI is missing (e.g. a Cloudflare challenge), the
    // operator completes login in the streaming companion. When that succeeds we
    // stop here instead of driving the password form against an already
    // authenticated page.
    if (await findAndFillEmail({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...checkpointOption(checkpoint),
        ...(completeAssistance ? { completeAssistance } : {}),
        email,
        page,
        ...(progress ? { progress } : {}),
        sendInteraction,
    })) {
        return true;
    }
    return await driveLoginFormAndConfirm({
        ...(assist ? { assist } : {}),
        ...(capture ? { capture } : {}),
        ...checkpointOption(checkpoint),
        ...(completeAssistance ? { completeAssistance } : {}),
        ...(onCredentialSubmit ? { onCredentialSubmit } : {}),
        page,
        password,
        ...(progress ? { progress } : {}),
        sendInteraction,
    });
}
export async function ensureChatGptSession({ assist, allowInteractiveAuthRepair, capture, checkpoint, completeAssistance, context: _context, credentials, onCredentialSubmit, page, progress, sendInteraction, }) {
    if (await navigateAndProbeSession(page, progress)) {
        return true;
    }
    const interactiveAuthRepairAllowed = allowInteractiveAuthRepair ?? chatGptAllowsInteractiveAuthRepair();
    if (!interactiveAuthRepairAllowed) {
        await progress?.("ChatGPT session is not active; automatic refresh will not start interactive auth repair.");
        throw new Error(CHATGPT_SESSION_REQUIRED_NON_INTERACTIVE_MESSAGE);
    }
    // Connection-scoped, never ambient: `credentials` belongs to the ONE
    // connection this run is for. See `login-credentials.ts` for why reading
    // process.env here is banned (scripts/check-no-direct-credential-env.ts).
    const resolved = resolveLoginCredentials(credentials, CHATGPT_LOGIN_FIELDS, "chatgpt");
    const hooks = sessionAssistanceHooks({
        assist,
        capture,
        checkpoint,
        completeAssistance,
        progress,
    });
    if (resolved.kind === "absent") {
        // No reusable session AND no stored credential. Reaching this point means the
        // connection is browser-session-bound (a static-secret-BOUND connection with
        // no usable credential fails closed in `resolveStaticSecretRunEnv` before the
        // run starts, so it never gets here). A browser-session connection — e.g. one
        // that logs in via SSO through the browser — repairs by session repair, so
        // the interactive browser login IS the correct owner-mediated repair here.
        // (Binding-first repair selection is owned by the connection-health
        // projection + console routing; see route-credentialless-repair-to-capture.)
        // The reason still LEADS the copy even on the SSO path: an owner who did
        // intend to store a credential must be able to see that none reached this
        // run, rather than reading it as a routine browser-session repair.
        if (await repairWithManualBrowserLogin({
            ...hooks,
            credentialReason: resolved.reason,
            page,
            sendInteraction,
        })) {
            return true;
        }
        throw new Error("chatgpt_login_post_submit_failed");
    }
    const { password, username: email } = resolved;
    return await driveStoredCredentialAuthRepair({
        ...hooks,
        email,
        ...(onCredentialSubmit ? { onCredentialSubmit } : {}),
        page,
        password,
        sendInteraction,
    });
}
