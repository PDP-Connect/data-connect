// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { manualBrowserLogin } from "../browser-handoff.js";
import { locatorIsUsable } from "./locator-helpers.js";
const DASHBOARD_URL = "https://www.usaa.com/my/usaa";
const LOGIN_URL = "https://www.usaa.com/my/logon";
const LOGGED_IN_TEXT = /Log Off|Good (Morning|Afternoon|Evening)/i;
const SESSION_COOKIE = /^(LtpaToken2|AST|MemberGlobalSession)$/;
/**
 * Copy that ACCOMPANIES the delivery-method chooser. Necessary but never
 * sufficient: this phrase also appears on USAA's security-settings pages and
 * in the chooser's own post-dispatch confirmation line, neither of which is a
 * chooser awaiting a click. See {@link findUsaaTextCodeChoice}.
 */
const TEXT_CODE_PROMPT = /Text security code/i;
/**
 * The delivery control itself — the thing the click actually targets. USAA
 * renders each method as a clickable row whose label begins "Text security
 * code to:" followed by a masked destination. Scoped to interactive roles so
 * it cannot match the same words appearing in body prose.
 */
const TEXT_CODE_CHOICE_SELECTOR = ':text-matches("Text security code to:", "i")';
const OTP_INPUT_SELECTOR = 'input[autocomplete="one-time-code"], input[name*="code" i], input[placeholder*="code" i]';
const OTP_RETRY_TEXT = /retry|invalid|incorrect|expired|try again/i;
const LOGIN_NAVIGATION_INTERVENTION_ERROR = /page\.goto: net::ERR_(HTTP2_PROTOCOL_ERROR|CONNECTION_RESET|FAILED)\b/i;
// Deliberately narrow: only phrases that specifically assert the *provider's
// own system* is down. "try again later" alone is common boilerplate on
// challenge, lockout, and rate-limit pages too (which need a real owner
// action, not a suppressed retry) — it must not by itself classify as
// source_unavailable. Matches (with common wording variants) only the two
// phrases that unambiguously identify USAA's generic system-outage page.
const USAA_SOURCE_UNAVAILABLE_TEXT = /unable to complete (your|this) request|(our |the )?system is (currently )?unavailable/i;
const USAA_LOGIN_ACTION_NAME = /^(Log in|Log On)$/i;
const USAA_ORIGIN = "https://www.usaa.com";
const MEMBER_ID_INPUT = 'input[name="memberId"]';
const MAX_OTP_ATTEMPTS = 3;
const MANUAL_LOGIN_MESSAGE = "USAA could not finish sign-in automatically; open the browser to continue. PDPP resumes when sign-in succeeds.";
const MANUAL_LOGIN_WITHOUT_CREDENTIALS_MESSAGE = "No optional USAA sign-in details were provided. Sign in to USAA in the secure browser, then respond success.";
const MANUAL_LOGIN_MESSAGE_CHOICE_MISSING = "USAA asked for a security code but PDPP could not find the control that sends it, so it did not request one. Choose how to receive your code in the secure browser and finish sign-in. PDPP resumes when sign-in succeeds.";
// `classifyUsaaLoginStepFailure` returning `source_unavailable` proves only
// that USAA's page copy matches known outage boilerplate — it does NOT prove
// the provider is actually down. It still reaches manual_action unless this
// exact state exposes exactly one visible semantic Log in/Log On action which,
// when activated once, returns to USAA's same-origin member-ID form. That is a
// proven continuation of the stored-credential flow, not a retry or an uptime
// claim; every absent, ambiguous, foreign, or failed transition falls through
// to the established owner handoff.
const MANUAL_LOGIN_MESSAGE_SOURCE_UNAVAILABLE_SUFFIX = " USAA's page reported its own system as unavailable, but this exact failure has recurred — if USAA works normally in your own browser, this may be an automated sign-in issue rather than a real outage.";
const STACK_TRACE_LOCATION_SUFFIX_RE = /\s+at\s+https?:\/\/\S+$/i;
function errorMessage(err) {
    return err instanceof Error ? err.message : String(err);
}
function firstLine(message) {
    return message.split("\n")[0]?.trim() || message.trim();
}
function trimForDiagnostic(value, maxLength) {
    return value.replace(/\s+/g, " ").trim().slice(0, maxLength);
}
export function classifyUsaaLoginStepFailure(bodyText) {
    return USAA_SOURCE_UNAVAILABLE_TEXT.test(bodyText)
        ? "source_unavailable"
        : "password_field_missing";
}
/**
 * Admit only one visible semantic action.
 *
 * This is intentionally private: the browser recovery owns how candidates are
 * discovered, while this pure policy owns the ambiguity invariant.
 */
function selectSourceUnavailableLoginAction(actions) {
    const visibleActions = actions.filter((action) => action.visible);
    if (visibleActions.length === 0) {
        return "absent";
    }
    if (visibleActions.length !== 1) {
        return "ambiguous";
    }
    return visibleActions[0] ?? "ambiguous";
}
function sourceUnavailableLoginRecoveryDiagnostic(outcome) {
    return `source_unavailable_login_action=${outcome}`;
}
async function captureSourceUnavailableLoginActionStructure(capture, page) {
    await capture
        ?.captureLocatorProbe?.(page, "usaa-source-unavailable-login-action", [
        {
            description: "Exact accessible-name candidate; captures only structural locator evidence.",
            id: "exact-login-button",
            kind: "role",
            namePattern: "^(Log in|Log On)$",
            nameFlags: "i",
            role: "button",
        },
        {
            description: "Exact accessible-name candidate; captures only structural locator evidence.",
            id: "exact-login-link",
            kind: "role",
            namePattern: "^(Log in|Log On)$",
            nameFlags: "i",
            role: "link",
        },
    ])
        .catch(() => undefined);
}
async function sourceUnavailableLoginActions(page) {
    const semanticActions = [
        page.getByRole("button", { name: USAA_LOGIN_ACTION_NAME }),
        page.getByRole("link", { name: USAA_LOGIN_ACTION_NAME }),
    ];
    const candidates = [];
    for (const action of semanticActions) {
        const count = await action.count().catch(() => 0);
        for (let index = 0; index < count; index += 1) {
            const locator = action.nth(index);
            candidates.push({
                locator,
                visible: await locator.isVisible().catch(() => false),
            });
        }
    }
    return candidates;
}
async function attemptSourceUnavailableLoginRecovery(capture, page) {
    await captureSourceUnavailableLoginActionStructure(capture, page);
    const actions = await sourceUnavailableLoginActions(page);
    const selectedAction = selectSourceUnavailableLoginAction(actions);
    if (typeof selectedAction === "string") {
        return selectedAction;
    }
    try {
        await selectedAction.locator.click({ timeout: 10_000 });
        await page
            .waitForLoadState("domcontentloaded", { timeout: 10_000 })
            .catch(() => undefined);
    }
    catch {
        return "action_error";
    }
    let sameOrigin = false;
    try {
        sameOrigin = new URL(page.url()).origin === USAA_ORIGIN;
    }
    catch {
        sameOrigin = false;
    }
    if (!sameOrigin) {
        return "foreign_origin";
    }
    return page
        .waitForSelector(MEMBER_ID_INPUT, { state: "visible", timeout: 10_000 })
        .then(() => "recovered")
        .catch(() => "member_id_form_missing");
}
function passwordStepFailureDiagnostic({ body, inputs, url, }) {
    return `url=${url} inputs=${JSON.stringify(inputs)} body-preview=${trimForDiagnostic(body, 300)}`;
}
function isLoggedInCookie(cookie) {
    if (cookie.name === "UsaaMbWebMemberLoggedIn") {
        return Boolean(cookie.value) && cookie.value !== "false";
    }
    return SESSION_COOKIE.test(cookie.name);
}
async function hasLoggedInCookie(context) {
    const cookies = await context.cookies("https://www.usaa.com/");
    return cookies.some(isLoggedInCookie);
}
async function verifyLoggedIn(context, page) {
    if (!(await hasLoggedInCookie(context))) {
        return false;
    }
    // Verify by hitting a cheap authenticated page.
    await page
        .goto(DASHBOARD_URL, {
        waitUntil: "domcontentloaded",
        timeout: 25_000,
    })
        .catch(() => undefined);
    await page.waitForTimeout(3000);
    const bodyText = (await page
        .locator("body")
        .innerText()
        .catch(() => "")).slice(0, 500);
    return LOGGED_IN_TEXT.test(bodyText);
}
async function requestManualLoginRecovery({ context, page, sendInteraction }, message = MANUAL_LOGIN_MESSAGE) {
    // Re-probe the session after the manual step rather than trusting the
    // interaction's completion status. The operator who completes login in a
    // visible browser may end the interaction as cancelled/error (timeout, or
    // an explicit "I'm already in" cancel) yet still have an active session.
    // Mirrors the chatgpt and reddit fallbacks: completing the manual step is a
    // signal to re-check ground truth, not an instruction to end the run.
    return await manualBrowserLogin({
        message,
        page,
        probe: () => verifyLoggedIn(context, page),
        sendInteraction,
        timeoutSeconds: 1800,
    });
}
async function requestOtp(sendInteraction, attempt) {
    const resp = await sendInteraction({
        kind: "otp",
        message: attempt === 1
            ? "USAA sent a 6-digit security code to your phone. Reply with the code to continue."
            : "USAA did not accept the previous security code. Reply with the newest 6-digit USAA code to continue.",
        schema: {
            type: "object",
            properties: { code: { type: "string", pattern: "^\\d{6}$" } },
            required: ["code"],
        },
        timeout_seconds: 600,
    });
    if (resp.status !== "success" || !resp.data?.code) {
        throw new Error("USAA OTP not provided");
    }
    return resp.data.code;
}
/**
 * The delivery control USAA's method chooser renders for the SMS option.
 *
 * Clicking this is what makes USAA dispatch a real code, so it is deliberately
 * the ONLY way this module reaches that act — there is no positional fallback.
 */
function findUsaaTextCodeChoice(page) {
    return page.locator(TEXT_CODE_CHOICE_SELECTOR).first();
}
/**
 * Whether the page is still a code entry the owner can answer.
 *
 * Requires a usable input, not merely retry-flavoured copy. The old check
 * accepted `OTP_RETRY_TEXT` on its own, so a page carrying the word "expired"
 * or "try again" — including USAA's session-timeout and lockout pages, which
 * have no code entry at all — kept the loop alive and re-prompted the owner
 * for a code that nothing could consume.
 */
async function isStillOnOtpChallenge(page) {
    return await locatorIsUsable(page.locator(OTP_INPUT_SELECTOR));
}
/**
 * Whether USAA positively rejected the code just submitted.
 *
 * This is what makes a further prompt honest. A usable input still on screen
 * proves only that the page did not advance; USAA's own retry copy is the
 * evidence that the previous code was actually consumed and refused. Without
 * it, "no session yet" is indistinguishable from a slow redirect, and asking
 * again would demand a second secret for a code that may still be valid.
 */
async function usaaRejectedPreviousCode(page) {
    const bodyText = await page
        .locator("body")
        .innerText()
        .catch(() => "");
    return OTP_RETRY_TEXT.test(bodyText);
}
async function completeOtpChallenge({ context, page, sendInteraction, }) {
    await page.waitForSelector(OTP_INPUT_SELECTOR, { timeout: 20_000 });
    for (let attempt = 1; attempt <= MAX_OTP_ATTEMPTS; attempt += 1) {
        const code = await requestOtp(sendInteraction, attempt);
        const otpInput = page.locator(OTP_INPUT_SELECTOR).first();
        await otpInput.fill(code);
        await page
            .click('button[type="submit"], #next-button')
            .catch(() => undefined);
        await page
            .waitForLoadState("domcontentloaded", { timeout: 10_000 })
            .catch(() => undefined);
        await page.waitForTimeout(3000);
        if ((await hasLoggedInCookie(context)) &&
            (await verifyLoggedIn(context, page))) {
            return true;
        }
        // Re-prompting costs the owner another trip to their phone, so it needs
        // both halves of the evidence: a code entry that can still accept an
        // answer, AND USAA saying it refused the last one. "No session yet" alone
        // is not a rejection — it is also what a slow redirect looks like.
        if (!((await isStillOnOtpChallenge(page)) &&
            (await usaaRejectedPreviousCode(page)))) {
            return false;
        }
    }
    return false;
}
/**
 * Ask USAA to send a security code, then run the code challenge.
 *
 * The one place in this module that causes a real SMS to a real phone, so the
 * click is gated on the delivery control being usable — visible AND enabled.
 * Matching page copy is not authorization: the phrase appears on pages with no
 * chooser at all, and a disabled control still reports itself visible.
 *
 * Returns true only if the resulting challenge established a session. When the
 * control cannot be found, this hands the browser to the owner and, failing
 * that, throws — it never guesses at a coordinate.
 */
async function dispatchTextCodeAndComplete(args) {
    const { context, page, sendInteraction } = args;
    const textCodeChoice = findUsaaTextCodeChoice(page);
    if (!(await locatorIsUsable(textCodeChoice))) {
        // Previously this fell back to clicking a hardcoded positional element
        // (`#miam-choice-container 0-id`) whenever the text match was wrong —
        // guessing at a bank's UI with the owner's SMS budget, and then looping up
        // to three times. There is no honest way to dispatch a code we cannot
        // locate the control for, so hand the browser to the owner instead.
        if (await requestManualLoginRecovery({ context, page, sendInteraction }, MANUAL_LOGIN_MESSAGE_CHOICE_MISSING)) {
            return true;
        }
        throw new Error(`usaa_text_code_choice_not_found: page text matched but no usable delivery control was present; refused to dispatch a security code. url=${page.url()}`);
    }
    await textCodeChoice.click();
    return await completeOtpChallenge({ context, page, sendInteraction });
}
async function submitMemberId(page, username) {
    // Give React a beat to initialize the form. USAA's SPA renders the
    // memberId input immediately but hasn't bound React event handlers yet —
    // filling in that <1s window produces a value that React discards.
    await page.waitForSelector(MEMBER_ID_INPUT, { timeout: 20_000 });
    await page.waitForTimeout(1500);
    await page.fill(MEMBER_ID_INPUT, username);
    // Wait until Next is enabled; USAA gates it on client-side validation.
    // If it stays disabled, tick a key event to try again, then check.
    try {
        await page
            .locator("#next-button:not([disabled])")
            .waitFor({ state: "visible", timeout: 5000 });
    }
    catch {
        // Fallback: press a throwaway key to nudge React.
        await page
            .locator(MEMBER_ID_INPUT)
            .press("End")
            .catch(() => undefined);
        await page.waitForTimeout(500);
    }
    await page.click("#next-button");
    return page
        .waitForSelector('input[name="password"]', { timeout: 25_000 })
        .then(() => true)
        .catch(() => false);
}
async function handlePasswordFieldStall({ capture, context, page, sendInteraction }, username) {
    const initialBody = await page
        .locator("body")
        .innerText()
        .catch(() => "");
    const initialClassification = classifyUsaaLoginStepFailure(initialBody);
    let recoveryOutcome = null;
    if (initialClassification === "source_unavailable") {
        recoveryOutcome = await attemptSourceUnavailableLoginRecovery(capture, page);
        if (recoveryOutcome === "recovered") {
            try {
                if (await submitMemberId(page, username)) {
                    return "password_ready";
                }
            }
            catch {
                recoveryOutcome = "resume_error";
            }
        }
    }
    const body = await page
        .locator("body")
        .innerText()
        .catch(() => "");
    const classification = classifyUsaaLoginStepFailure(body);
    // The source-unavailable branch already captured only fixed semantic
    // locator probes before the transition. Do not add a raw DOM snapshot after
    // the member ID was filled; it could retain credential-adjacent data.
    if (initialClassification !== "source_unavailable") {
        await capture
            ?.captureDom(page, "usaa-password-field-stall")
            .catch(() => undefined);
    }
    const inputs = await page
        .evaluate(() => {
        const els = document.querySelectorAll("input");
        return Array.from(els).map((i) => ({
            name: i.name,
            type: i.type,
            placeholder: i.placeholder,
        }));
    })
        .catch(() => []);
    const diagnostic = passwordStepFailureDiagnostic({
        body,
        inputs,
        url: page.url(),
    });
    const manualLoginMessage = classification === "source_unavailable"
        ? `${MANUAL_LOGIN_MESSAGE}${MANUAL_LOGIN_MESSAGE_SOURCE_UNAVAILABLE_SUFFIX}`
        : MANUAL_LOGIN_MESSAGE;
    const recoveryDiagnostic = recoveryOutcome
        ? ` ${sourceUnavailableLoginRecoveryDiagnostic(recoveryOutcome)}.`
        : "";
    if (await requestManualLoginRecovery({ context, page, sendInteraction }, `${manualLoginMessage}${recoveryDiagnostic}`)) {
        return "logged_in";
    }
    throw new Error(`USAA login stalled after Next click (${diagnostic}${recoveryOutcome ? ` ${sourceUnavailableLoginRecoveryDiagnostic(recoveryOutcome)}` : ""}); manual action did not establish a session`);
}
export async function ensureUsaaSession({ capture, context, credentials, onCredentialSubmit, page, sendInteraction, }) {
    // Probe first — no need to re-login if session is alive.
    if (await verifyLoggedIn(context, page)) {
        return true;
    }
    // Session is dead or suspect — drive login.
    // Runtime callers always pass the setup-resolved bundle. Keep the omitted
    // argument compatible for direct callers and older connector tests; an
    // explicit (including empty) bundle never consults ambient process.env.
    const resolvedCredentials = credentials ?? process.env;
    const username = resolvedCredentials.USAA_USERNAME;
    const password = resolvedCredentials.USAA_PASSWORD;
    if (!(username && password)) {
        await page
            .goto(LOGIN_URL, { waitUntil: "domcontentloaded", timeout: 30_000 })
            .catch(() => undefined);
        if (await manualBrowserLogin({
            message: MANUAL_LOGIN_WITHOUT_CREDENTIALS_MESSAGE,
            page,
            probe: () => verifyLoggedIn(context, page),
            sendInteraction,
            timeoutSeconds: 1800,
        })) {
            return true;
        }
        throw new Error("USAA manual login did not establish a session");
    }
    try {
        await page.goto(LOGIN_URL, {
            waitUntil: "domcontentloaded",
            timeout: 30_000,
        });
    }
    catch (err) {
        const message = errorMessage(err);
        if (LOGIN_NAVIGATION_INTERVENTION_ERROR.test(message)) {
            const reason = firstLine(message).replace(STACK_TRACE_LOCATION_SUFFIX_RE, "");
            if (await requestManualLoginRecovery({ context, page, sendInteraction })) {
                return true;
            }
            throw new Error(`USAA login page navigation failed (${reason}); manual action did not establish a session`, {
                cause: err,
            });
        }
        throw err;
    }
    if (!(await submitMemberId(page, username)) &&
        (await handlePasswordFieldStall({ capture: capture ?? null, context, page, sendInteraction }, username)) === "logged_in") {
        return true;
    }
    await page.fill('input[name="password"]', password);
    await page.waitForTimeout(500);
    await page.click("#next-button");
    // The password just went out to USAA's real sign-in form. From this line
    // on, ANY throw (OTP failure, verify failure, the final diagnostic below)
    // must be non-retryable — a redispatch would resubmit the saved password.
    onCredentialSubmit?.();
    await page.waitForTimeout(5000);
    const bodyText = (await page.locator("body").innerText()).slice(0, 1000);
    if (TEXT_CODE_PROMPT.test(bodyText) &&
        (await dispatchTextCodeAndComplete({ context, page, sendInteraction }))) {
        return true;
    }
    if (await verifyLoggedIn(context, page)) {
        return true;
    }
    const finalText = await page
        .locator("body")
        .innerText()
        .catch(() => "");
    await capture
        ?.captureDom(page, "usaa-post-password-no-session")
        .catch(() => undefined);
    const classification = classifyUsaaLoginStepFailure(finalText);
    const inputs = await page
        .evaluate(() => {
        const els = document.querySelectorAll("input");
        return Array.from(els).map((i) => ({
            name: i.name,
            type: i.type,
            placeholder: i.placeholder,
        }));
    })
        .catch(() => []);
    // `classification` here is a diagnostic label, not proof of provider
    // uptime — see the comment on MANUAL_LOGIN_MESSAGE_SOURCE_UNAVAILABLE_SUFFIX.
    // It is folded into the thrown diagnostic so downstream classification/logs
    // can see it, but it does not change what error this throws or suppress
    // the owner-visible diagnostic that was already here.
    throw new Error(`USAA login completed but no verified authenticated dashboard session was detected (classification=${classification}). url=${page.url()} inputs=${JSON.stringify(inputs)} body-preview=${trimForDiagnostic(finalText, 300)}`);
}
