/**
 * Venmo automated session management.
 *
 * Ground truth: /tmp/venmo-provider-path-audit-0810.md. Venmo's internal
 * `api.venmo.com` JSON API rejects a synthetic, per-run `device-id` sent
 * over raw HTTP with a hardcoded User-Agent — a documented, multi-year
 * device/session-trust anti-automation gate (github.com/mmohades/Venmo
 * issue #86). The fix is architectural, not a retry: authenticate through
 * a real, owner-driven browser session (same pattern as `reddit`/`amazon`)
 * and read the same JSON endpoints through `page.evaluate(fetch)` under
 * that session's real cookies — no synthetic device identity, no spoofed
 * User-Agent, full Patchright stealth inherited for free.
 *
 * Flow:
 *   1. Probe — page-context fetch to `/account` with `credentials:
 *      "include"`; a 2xx with a `user.id` means the session is live.
 *   2. If dead and setup-supplied credentials are available, drive
 *      venmo.com's own sign-in form (assists login only; never a
 *      substitute for it — the owner may still see a device-approval or
 *      SMS/2FA prompt Venmo serves to its own web app).
 *   3. If dead and no credentials are set, hand the page to the owner via
 *      `manual_action` and re-probe once they respond.
 *   4. OTP: Venmo's web sign-in renders its own 6-digit code input when it
 *      wants SMS/email verification; surfaced via `sendInteraction`, same
 *      shape as reddit/amazon's OTP handoff.
 */
import type { ProgressExtra } from "@pdpp/connector-protocol/connector-runtime-protocol";
import type { Page } from "playwright";
import type { InteractionRequest, InteractionResponse, SessionCheckpointFn } from "../connector-runtime.ts";
import type { CaptureSession } from "../fixture-capture.ts";
/**
 * Fault-class name for a transport failure discovered by the PRE-submit
 * session probe — see {@link probeVenmoAccount}'s B4 doc for why this must
 * stay distinct from the post-submit name below.
 */
export declare const VENMO_PROBE_TRANSPORT_ERROR = "venmo_probe_transport_error";
/** Fault-class name for a transport failure discovered by the POST-submit probe — see the B4 doc. Deliberately excluded from `VENMO_RETRYABLE_PATTERN`. */
export declare const VENMO_POST_SUBMIT_PROBE_TRANSPORT_ERROR = "venmo_post_submit_probe_transport_error";
/** Fault-class name for {@link ensureVenmoOrigin} failing to land the page on the venmo.com origin — see that function's doc (production run_1787101857760). */
export declare const VENMO_ORIGIN_NAVIGATION_FAILED = "venmo_origin_navigation_failed";
/**
 * Fault-class name for the password screen never arriving after a successful
 * identifier submit on Venmo's two-step sign-in — see {@link fillVenmoPassword}.
 *
 * Deliberately a distinct, named, NON-retryable-by-omission class rather than
 * a fall-through: the identifier has been sent to Venmo at this point, so a
 * blind retry re-enters `ensureVenmoSession` and re-submits it. It is also
 * distinct from the OTP vocabulary on purpose — a missing password field is
 * not evidence Venmo asked for a code, and treating it as one is exactly the
 * fabricated-prompt defect class this file's OTP path already guards against.
 *
 * Declared here rather than beside its sibling sign-in constants below because
 * {@link VENMO_DECLARED_REASON_TOKENS} is built eagerly at module load and
 * would read it from the temporal dead zone otherwise.
 */
export declare const VENMO_PASSWORD_SCREEN_TIMEOUT = "venmo_password_screen_timeout";
/**
 * This connector's classifying fault-class names — single source of truth,
 * built from the same constants every throw site below uses, so it cannot
 * drift from the vocabulary it names. Every one of these is >=24 chars and
 * therefore invisible to an owner today: `runtime/connector-gap-bounding.ts`'s
 * `boundConnectorErrorMessage` redacts any bare token this long
 * (`stderr-redact.ts`'s `LONG_OPAQUE_RE`, an entropy heuristic for
 * unlabelled API keys) with no notion that a categorical, PII-free reason
 * code is not the kind of secret that rule exists to catch — the same
 * defect class production hit for HEB (`heb_session_failed: [REDACTED]`,
 * see `runtime/stderr-redact.ts`'s `declaredReasonTokens` doc) and, on
 * 2026-08-18, for Venmo's own first live run (`run_1787101857760`:
 * `venmo_session_failed: [REDACTED]: Failed to fetch` — the eaten token was
 * exactly `VENMO_PROBE_TRANSPORT_ERROR`). Consumed by
 * `runtime/declared-reason-tokens.ts` on the RS side so these survive that
 * redaction pass without a hand-copied, driftable string list on the other
 * side of the process boundary.
 */
export declare const VENMO_DECLARED_REASON_TOKENS: ReadonlySet<string>;
/**
 * The probe hits the SAME endpoint `collect()` does — `api.venmo.com/v1/account`
 * (`connectors/venmo/parsers.ts`'s `API_BASE`), the one that actually returns
 * the `data.user.id` JSON this function parses.
 *
 * It used to point at `https://venmo.com/account`, which is not that endpoint
 * and never returned JSON at all. That URL is Venmo's own web app route, and
 * as of 2026-08-18 it answers a redirect chain that terminates on plain HTTP:
 *
 *   https://venmo.com/account          -> 302 https://account.venmo.com/account
 *   https://account.venmo.com/account  -> 307 http://account.venmo.com:8080/
 *
 * A `fetch` issued from the HTTPS `venmo.com` page follows those redirects and
 * is then blocked by the browser's mixed-content rule on the final http:// hop.
 * A blocked redirect surfaces to page JS as exactly `TypeError: Failed to
 * fetch` — indistinguishable, from inside the callback, from a network
 * failure. That is production `run_1787108832272`'s
 * `venmo_probe_transport_error: Failed to fetch`, on a host where
 * `https://venmo.com/` itself was reachable and returning 200.
 *
 * The origin guard below is still required and still correct: `api.venmo.com`
 * grants a credentialed cross-origin fetch only to `Access-Control-Allow-Origin:
 * https://venmo.com`. The previous URL made that guard look like the whole
 * story, because a same-origin `venmo.com` URL needs no CORS grant at all —
 * so the guard could never have fixed a fault the URL itself was causing.
 */
export declare const ACCOUNT_PROBE_URL = "https://api.venmo.com/v1/account";
/**
 * Whether `url` is a page on Venmo's own https host family.
 *
 * HTTPS is required, not incidental: `venmo.com`'s own redirect chain
 * terminates on `http://account.venmo.com:8080/` (see {@link ACCOUNT_PROBE_URL}),
 * and a plain-http Venmo page is both a downgraded origin and one whose
 * credentialed fetch the browser's mixed-content rule blocks anyway. Treating
 * it as "close enough to Venmo" would re-admit exactly the fault that
 * production `run_1787108832272` recorded.
 */
export declare function isVenmoFamilyUrl(url: string): boolean;
/**
 * Whether `url` is a page the owner can complete sign-in ON, right now.
 *
 * Strictly narrower than {@link isVenmoFamilyUrl}: this asks "is there a live
 * sign-in flow on this page worth preserving", not "is this Venmo". The
 * distinction is load-bearing for {@link waitForManualLogin}, which must
 * navigate a page that CANNOT be signed in from (`about:blank` on a fresh
 * run, or the logged-out `venmo.com/` the pre-handoff probe leaves behind)
 * while leaving a live `id.venmo.com` screen — the captcha or OTP the owner
 * was just asked to solve — exactly as it stands.
 */
export declare function isVenmoSignInUrl(url: string): boolean;
/**
 * Ensure `page` is on the `venmo.com` origin before a credentialed
 * page-context fetch: `api.venmo.com`'s CORS allowlist grants
 * `credentials:"include"` only to `Access-Control-Allow-Origin:
 * https://venmo.com` (confirmed live 2026-08-10, /tmp/review-venmo-
 * browser-redesign-0810.md §1). `about:blank` has an opaque origin and
 * hard-fails the same fetch with `TypeError: Failed to fetch` — not a
 * session signal, a transport precondition. Every sibling browser
 * connector navigates before its first credentialed fetch
 * (reddit.ts:100, amazon.ts:90); this was the one that didn't.
 *
 * Production `run_1787101857760` (2026-08-18, the owner's first-ever Venmo
 * run — a brand-new persistent profile, so `page.url()` starts on
 * `about:blank`): the pre-submit probe threw
 * `venmo_probe_transport_error: Failed to fetch`. The prior version of this
 * function swallowed a failed `page.goto` with `.catch(() => undefined)` and
 * returned regardless of whether the navigation actually landed on
 * `venmo.com` — so a transient failure of THIS `goto` (not the eventual
 * fetch) silently left the page on its opaque `about:blank` origin, and the
 * caller's credentialed fetch then failed for a reason this function was
 * supposed to have already ruled out. Every DOM-probing sibling connector
 * (chase.ts's `probeSession`, reddit.ts's credential-less `isSessionLive`)
 * has the same swallowed `.catch`, but degrades gracefully: a `waitFor`/
 * `count` against an unnavigated page just times out to "not logged in".
 * Venmo's probe is `fetch`-based, so the same swallowed failure surfaces as
 * an opaque transport throw instead of a clean liveness signal — verifying
 * the navigation actually landed is the fix that closes that gap for a
 * fetch-based probe specifically.
 *
 * This function checks TWO different facts, and conflating them is what broke
 * production `run_1787151856448`:
 *
 *   1. PRECONDITION — the page must END on `https://venmo.com`, because that
 *      is the single origin `api.venmo.com` grants a credentialed fetch to
 *      (see {@link VENMO_ORIGIN}). Nothing weaker satisfies CORS.
 *   2. TRUST — landing on another of Venmo's OWN hosts
 *      ({@link VENMO_FAMILY_HOSTS}) is normal, expected behavior after a real
 *      sign-in; landing off that family entirely is not.
 *
 * The first version tested only (1) and treated any miss as fatal, so an owner
 * who genuinely signed in at `id.venmo.com` — the correct flow — had the run
 * terminalled by the guard meant to protect it. A guard that fires on correct
 * behavior teaches operators to ignore it, so the family case now re-navigates
 * instead of throwing, while a landing outside the family still fails loudly.
 */
export declare function ensureVenmoOrigin(page: Page): Promise<void>;
interface EnsureVenmoSessionArgs {
    capture?: CaptureSession | null;
    checkpoint?: SessionCheckpointFn;
    credentials?: Readonly<Record<string, string>>;
    onCredentialSubmit?: () => void;
    page: Page;
    /**
     * Bound on the wait for Venmo's second (password) sign-in screen; defaults
     * to {@link PASSWORD_SCREEN_TIMEOUT_MS}. Exposed so a test can assert the
     * bound is real without sitting through the production one — the same seam
     * `probeVenmoAccount`'s `evaluateTimeoutMs` already provides.
     */
    passwordScreenTimeoutMs?: number;
    /**
     * Emits a `run.progress_reported` spine event. Optional so tests that don't
     * care about the timeline can omit it; production always supplies it (see
     * `connectors/venmo/index.ts`'s `ensureSession`).
     */
    progress?: (message: string, extra?: ProgressExtra) => Promise<void>;
    sendInteraction: (req: InteractionRequest) => Promise<InteractionResponse>;
}
export interface VenmoAccountProbeResult {
    live: boolean;
    ownerId: string | null;
}
/**
 * Which side of an automated credential submission a probe runs on — see
 * {@link probeVenmoAccount}'s "B4" doc for why this determines the thrown
 * error's NAME (and therefore its retryability), not just its message.
 */
export type VenmoProbePhase = "post_submit" | "pre_submit";
/**
 * Page-context probe: fetch `/account` under the real session cookie
 * (`credentials: "include"`, no Authorization header, no device-id, no
 * spoofed User-Agent). A 2xx body carrying `data.user.id` proves the
 * session is live and gives the owner id for free — the same call
 * `fetchProfile`/`collectProfile` will make once collection starts.
 *
 * Navigates to `venmo.com` first when not already there: the page starts
 * on `about:blank` (opaque origin) on a fresh run, and `api.venmo.com`'s
 * CORS allowlist only grants a credentialed fetch from `https://venmo.com`
 * — see {@link ensureVenmoOrigin}. A probe that skipped this would read
 * every live session as dead and never actually test session state.
 *
 * `phase` (default `"pre_submit"`) governs the NAME of a transport-fault
 * throw, not just its text — see the "B4" note above `throw` below.
 */
export declare function probeVenmoAccount(page: Page, phase?: VenmoProbePhase, { evaluateTimeoutMs, }?: {
    readonly evaluateTimeoutMs?: number;
}): Promise<VenmoAccountProbeResult>;
/** Resolve a live Venmo browser session, or throw if establishment fails. */
export declare function ensureVenmoSession({ capture, checkpoint, credentials, onCredentialSubmit, page, passwordScreenTimeoutMs, progress, sendInteraction, }: EnsureVenmoSessionArgs): Promise<VenmoAccountProbeResult>;
export {};
//# sourceMappingURL=venmo.d.ts.map