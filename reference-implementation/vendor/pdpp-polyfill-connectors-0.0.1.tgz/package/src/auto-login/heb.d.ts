/**
 * H-E-B automated session management.
 *
 * Strategy:
 *   1. Probe the live orders page first.
 *   2. If dead and stored sign-in details are present, fill the verified login
 *      form only, submit it, and wait for a bounded post-submit state change
 *      before re-checking the session.
 *   3. If H-E-B shows the post-authentication passkey-enrollment upsell,
 *      decline it automatically and keep waiting for the live session. This
 *      screen is not a challenge: sign-in has already succeeded behind it.
 *   4. If H-E-B shows a verification-code page, emit the shared OTP
 *      interaction, fill and submit the code, then re-probe the live session.
 *   5. If H-E-B shows passkey, CAPTCHA, Incapsula, or any other unexpected
 *      UI, hand the browser to the owner and probe again.
 *
 * The runtime never logs or stores the provider password here. When the owner
 * has opted into credential capture, the connector receives it through the
 * existing connection-scoped secret injection path.
 */
import type { Page } from "playwright";
import type { InteractionRequest, InteractionResponse, SessionCheckpointFn } from "../connector-runtime.ts";
import type { CaptureSession } from "../fixture-capture.ts";
export type HebAuthSurface = "live" | "login_form" | "passkey" | "passkey_enrollment" | "verification_code" | "captcha" | "incapsula" | "unknown";
interface EnsureHebSessionArgs {
    capture?: CaptureSession | null;
    checkpoint?: SessionCheckpointFn;
    /**
     * This connection's resolved sign-in pair, threaded from the runtime (see
     * `login-credentials.ts`). Optional so a direct, non-runtime caller can omit
     * it; an absent pair reports itself as absent rather than blaming the page.
     */
    credentials?: Readonly<Record<string, string | undefined>> | undefined;
    onCredentialSubmit?: () => void;
    page: Page;
    postSubmitWaitClock?: PostSubmitWaitClock;
    sendInteraction: (req: InteractionRequest) => Promise<InteractionResponse>;
}
interface PostSubmitWaitClock {
    now: () => number;
    wait: (ms: number) => Promise<void>;
}
export declare function probeHebSession(page: Page, checkpoint?: SessionCheckpointFn): Promise<boolean>;
export declare function ensureHebSession({ capture, checkpoint, credentials, onCredentialSubmit, page, postSubmitWaitClock, sendInteraction, }: EnsureHebSessionArgs): Promise<boolean>;
export {};
//# sourceMappingURL=heb.d.ts.map