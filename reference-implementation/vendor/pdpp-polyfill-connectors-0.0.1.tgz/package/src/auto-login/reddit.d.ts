/**
 * Reddit automated session management.
 *
 * Reddit killed the OAuth script-app password grant in 2024, so the only
 * durable path for personal data collection is a cookie-authenticated
 * browser session. We keep the session in the shared persistent profile and
 * surface the read-only `reddit_session` cookie to old.reddit.com JSON
 * endpoints — effectively "what a logged-in user sees," no API key needed.
 *
 * Env: REDDIT_USERNAME / REDDIT_PASSWORD. Reddit often serves a 2FA code
 * input (OTP app or SMS) on first login from a new profile; we surface that
 * via INTERACTION so the operator can supply the 6-digit code (ntfy → phone
 * or file drop). Persistent session.
 *
 * Anti-bot: Reddit shows a Cloudflare challenge for residential IPs in the
 * default profile; if we can't reach login inputs we fall back to a
 * manual_action INTERACTION rather than banging on the form.
 */
import type { BrowserContext, Page } from "playwright";
import type { InteractionRequest, InteractionResponse, SessionCheckpointFn } from "../connector-runtime.ts";
import type { CaptureSession } from "../fixture-capture.ts";
type SendInteraction = (req: InteractionRequest) => Promise<InteractionResponse>;
interface ManualHandoffProbeRetryOptions {
    pollIntervalMs?: number;
    retryForMs?: number;
}
interface EnsureRedditSessionArgs {
    capture?: CaptureSession | null;
    /**
     * Mark a session-establishment phase so the runtime watchdog's no-progress
     * message names WHERE establishment stalled. Optional (matching heb.ts's
     * shape) so the many internal/test callers that don't checkpoint keep
     * working; the production hook (`connectors/reddit/index.ts`'s
     * `redditEnsureSession`) forwards the runtime's real one.
     *
     * Production `run_1787109028586` is why this exists: the run hung 120s
     * inside the first liveness probe with `session-establish:begin` — the
     * RUNTIME's own framing checkpoint — as the last marker, so the failure
     * named the whole window rather than the probe that actually stalled.
     */
    checkpoint?: SessionCheckpointFn;
    context: BrowserContext;
    /**
     * Test seam for the manual-handoff post-interaction re-probe window (see
     * `isSessionLiveWithRetry`). Defaults to the production window
     * (`MANUAL_HANDOFF_PROBE_RETRY_MS` / `MANUAL_HANDOFF_PROBE_POLL_INTERVAL_MS`);
     * tests that deliberately exercise the "never becomes live" throw path
     * override this so the assertion doesn't burn the real retry window.
     */
    manualHandoffProbeRetry?: ManualHandoffProbeRetryOptions;
    /**
     * Runtime marker for the post-submit credential-safety invariant: fired at
     * the exact click that sends the saved password to Reddit's real sign-in
     * form (see `EnsureSessionArgs.onCredentialSubmit`). Never fired on the
     * session-reuse early return, the manual hand-off paths, or the OTP
     * resubmit — those never send the saved password.
     */
    onCredentialSubmit?: () => void;
    page: Page;
    sendInteraction: SendInteraction;
    /**
     * Test seam for the per-probe bounds (see {@link SessionProbeOptions}).
     * Production passes nothing and gets the real bounds; tests that prove the
     * hang path shrink `evaluateTimeoutMs` so the assertion doesn't have to
     * spend the production bound in real wall-clock.
     */
    sessionProbe?: SessionProbeOptions;
}
/**
 * The JSON host every in-page `fetch` must be issued to, and — because Reddit
 * grants no cross-origin access to it — the origin the page must already be on
 * when it issues that fetch.
 *
 * `old.reddit.com` and `www.reddit.com` serve the SAME listing JSON, but they
 * are different origins, and neither answers a credentialed cross-origin
 * request: as of 2026-08-19 a request to either host carrying
 * `Origin: https://www.reddit.com` comes back with NO
 * `Access-Control-Allow-Origin` header at all. CORS forbids a wildcard once
 * credentials are sent, so there is no header Reddit could send that would
 * make the cross-origin form work either.
 *
 * That is production `run_1787164349370`. The owner was genuinely signed in as
 * confirmed over CDP, the page sat on `https://www.reddit.com/`, and the probe
 * fetched `https://old.reddit.com/user/{u}/saved.json`. Read from that page,
 * the two calls disagreed completely:
 *
 *   fetch('https://www.reddit.com/user/{u}/saved.json') -> 200
 *   fetch('https://old.reddit.com/user/{u}/saved.json') -> TypeError: Failed to fetch
 *
 * The browser blocks the second before it reaches the network, and a blocked
 * fetch surfaces to page JS as exactly `TypeError: Failed to fetch` — which
 * the probe's `catch` mapped to `status: 0`, i.e. "not live". So a working
 * session read as dead, every run threw `reddit_login_unexpected_ui`, and five
 * of six streams collected nothing from 2026-06-02 onward while Reddit pruned
 * the listings past ~1000 items underneath.
 *
 * Switching the probe to `www.reddit.com` would have fixed THAT page, and only
 * by accident: it would break again the moment the page legitimately sits on
 * `old.reddit.com` (which `isSessionLive`'s own credential-less fallback
 * navigates to). The origin is the invariant, not the hostname — so the fix
 * establishes the origin rather than guessing which one the page is on. The
 * collect path in `connectors/reddit/index.ts` depends on this same origin
 * holding for its own `redditFetch`.
 */
export declare const REDDIT_JSON_ORIGIN = "https://old.reddit.com";
/**
 * Put the page on {@link REDDIT_JSON_ORIGIN} so a credentialed same-origin
 * `fetch` is possible at all, and report whether that succeeded.
 *
 * Returns `false` rather than throwing: a probe that cannot establish its
 * origin has not proven the session is dead, only that it could not ask. Every
 * caller already treats `false` as "could not determine live" and proceeds to
 * login, which is the correct action either way.
 *
 * Bounded like every other step in this probe — `goto` carries an explicit
 * timeout, so this cannot reintroduce an unbounded await.
 */
export declare function ensureRedditJsonOrigin(page: Page): Promise<boolean>;
/**
 * Options for a single liveness probe.
 *
 * `evaluateTimeoutMs` is a test seam of the same kind as
 * `EnsureRedditSessionArgs.manualHandoffProbeRetry`: the bound must be REAL
 * wall-clock in production, so a test that wants to prove "a hang resolves to
 * false" would otherwise have to actually wait the production bound. Tests
 * shrink it instead of sleeping; nothing in production passes it.
 */
export interface SessionProbeOptions {
    readonly evaluateTimeoutMs?: number;
    /**
     * Fired when a probe could not answer within its bound — never fired for a
     * probe that ran and reported a dead session. Keeps "Reddit stopped
     * answering" distinguishable from "you are logged out" in diagnostics, even
     * though both produce the same `false` verdict and the same next action.
     */
    readonly onProbeTimeout?: (stage: string) => void;
}
/**
 * Confirm the session cookie actually grants access — a stale cookie may
 * still exist after logout. Prefer an owner-only JSON endpoint
 * (`/user/{username}/saved.json`) over a DOM guess: it's exactly the data the
 * connector needs downstream anyway, so a 200 there is ground truth rather
 * than a heuristic, and it survives old.reddit.com markup changes that broke
 * a prior logout-link selector check even while a real session was live.
 * Falls back to the logout-link probe when no username is known yet (the
 * credential-less manual hand-off, which runs before any account is chosen).
 *
 * NEVER hangs and NEVER throws: every failure mode — dead session, transport
 * fault, aborted fetch, wedged page context — resolves to a boolean. A probe
 * that could not answer within its bound reports `false` ("I could not
 * determine this session is live"), which is the same ACTIONABLE state as
 * "not live": proceed to login. `onProbeTimeout` exists so that equivalence
 * does not erase the distinction in DIAGNOSTICS — a tarpit and a genuinely
 * logged-out session must not look identical to whoever reads the run later.
 */
export declare function isSessionLive(page: Page, options?: SessionProbeOptions): Promise<boolean>;
/**
 * Re-probe liveness for a bounded window instead of trusting a single check
 * right after the owner's `manual_action` response resolves.
 *
 * The owner's "success" click only means they finished on their end — it is
 * not proof the post-captcha/post-login page has settled. Reddit still has
 * to run its own redirect/render pass after that click (the same class of
 * "second client-side render pass" the post-submit OTP fix in
 * `ensureRedditSession` already accounts for with a `waitFor`, not a
 * one-shot check). `isSessionLive`'s credential-less fallback additionally
 * does a real navigation (`page.goto("https://old.reddit.com/")`), which
 * itself takes time and can transiently fail immediately after a challenge
 * redirect. A single call here read that transient state as "not live" and
 * threw `reddit_login_unexpected_ui` ~300ms after the owner solved the
 * captcha, discarding a login that was already succeeding — see the
 * `run_1787090213822` production evidence this fixes.
 *
 * `retryForMs` bounds the LOOP, and that bound is only real because each
 * `isSessionLive` call is now itself bounded. The deadline is checked between
 * probes, so before `isSessionLive` grew its own timeouts a single hung probe
 * pinned this wrapper open forever and the 15s window here was decorative —
 * the wrapper is not what failed in `run_1787109028586`, but it would not
 * have saved the run either. Worst case is now roughly
 * `retryForMs + SESSION_PROBE_EVALUATE_TIMEOUT_MS` (one in-flight probe may
 * start just under the deadline and run its full bound), which is finite and
 * far under the runtime watchdog's no-progress window.
 */
export declare function isSessionLiveWithRetry(page: Page, { evaluateTimeoutMs, onProbeTimeout, pollIntervalMs, retryForMs, }?: SessionProbeOptions & {
    pollIntervalMs?: number;
    retryForMs?: number;
}): Promise<boolean>;
export declare function ensureRedditSession({ capture, checkpoint, context, manualHandoffProbeRetry, onCredentialSubmit, page, sendInteraction, sessionProbe, }: EnsureRedditSessionArgs): Promise<void>;
export {};
//# sourceMappingURL=reddit.d.ts.map