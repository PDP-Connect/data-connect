/**
 * Amazon automated session management.
 *
 * Strategy:
 *   1. Probe session via deep check (navigate to /your-orders, check no
 *      signin redirect)
 *   2. If dead, drive email + password form through Amazon's two-step flow
 *   3. If 2FA prompted, emit INTERACTION kind=otp — owner replies with the
 *      code from their SMS or authenticator app
 *
 * Selectors notes (updated 2026-04-20):
 *   - Amazon's signin page has a HIDDEN autofill-hint input at
 *     `input[name="password"]#auth-credential-autofill-hint` that matches
 *     `input[name="password"]` but is not fillable. The real password input
 *     appears only after email+continue and uses `input#ap_password`. We
 *     prefer the specific ID and require visibility before filling.
 */
import type { BrowserContext, Page } from "playwright";
import type { InteractionRequest, InteractionResponse, SessionCheckpointFn } from "../connector-runtime.ts";
import type { CaptureSession } from "../fixture-capture.ts";
import { type LoginCredentialFields } from "./login-credentials.ts";
/**
 * Where Amazon's sign-in pair lives in the runtime-resolved `credentials`
 * object. Must match the manifest's `credential_capture` env mapping (see
 * `src/generated/static-secret-registry.generated.ts`).
 */
export declare const AMAZON_LOGIN_FIELDS: LoginCredentialFields;
interface EnsureAmazonSessionArgs {
    capture?: CaptureSession | null;
    /**
     * Session-establishment checkpoint hook from the runtime watchdog. Each call
     * marks an auth phase: it resets the no-progress deadline and captures a
     * phase diagnostic so a hang no longer leaves only an about:blank artifact.
     */
    checkpoint?: SessionCheckpointFn;
    context: BrowserContext;
    /**
     * This connection's resolved sign-in pair, threaded from the runtime (see
     * `login-credentials.ts`). Optional so a direct, non-runtime caller can omit
     * it; an absent pair reports itself as absent rather than blaming the page.
     */
    credentials?: Readonly<Record<string, string | undefined>> | undefined;
    fieldTimeoutMs?: number | undefined;
    onCredentialSubmit?: () => void;
    page: Page;
    sendInteraction: (req: InteractionRequest) => Promise<InteractionResponse>;
}
export declare function ensureAmazonSession({ capture, checkpoint, context: _context, credentials, fieldTimeoutMs, onCredentialSubmit, page, sendInteraction, }: EnsureAmazonSessionArgs): Promise<boolean>;
export {};
//# sourceMappingURL=amazon.d.ts.map