/**
 * USAA automated re-login.
 *
 * Given a Playwright context whose session has died, drives the full login
 * flow using stored credentials. Emits an INTERACTION kind=otp via the
 * provided `sendInteraction` callback; that in turn fires ntfy to
 * the owner's phone. the owner replies with the 6-digit code over the inbox (or by
 * writing to /tmp/usaa-otp.txt during manual testing).
 *
 * Returns true on success; throws on hard failure.
 */
import type { BrowserContext, Page } from "playwright";
import type { InteractionRequest, InteractionResponse } from "../connector-runtime.ts";
import type { CaptureSession } from "../fixture-capture.ts";
interface EnsureUsaaSessionArgs {
    capture?: CaptureSession | null;
    context: BrowserContext;
    credentials?: Readonly<Record<string, string>>;
    onCredentialSubmit?: () => void;
    page: Page;
    sendInteraction: (req: InteractionRequest) => Promise<InteractionResponse>;
}
export declare function classifyUsaaLoginStepFailure(bodyText: string): "source_unavailable" | "password_field_missing";
export declare function ensureUsaaSession({ capture, context, credentials, onCredentialSubmit, page, sendInteraction, }: EnsureUsaaSessionArgs): Promise<boolean>;
export {};
//# sourceMappingURL=usaa.d.ts.map