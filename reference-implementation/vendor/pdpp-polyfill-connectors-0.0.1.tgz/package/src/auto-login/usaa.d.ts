/**
 * USAA automated re-login.
 *
 * Given a Playwright context whose session has died, drives the full login
 * flow using stored credentials. Emits an INTERACTION kind=otp via the
 * provided `sendInteraction` callback; that in turn fires ntfy to
 * the owner's phone. the owner replies with the 6-digit code over the inbox (or by
 * writing to /tmp/usaa-otp.txt during manual testing).
 *
 * Returns true on success; throws on hard failure.
 */
import type { AssistanceCompletionStatus, AssistanceRequest } from "@pdpp/connector-protocol/connector-runtime-protocol";
import type { BrowserContext, Page } from "playwright";
import type { InteractionRequest, InteractionResponse } from "../connector-runtime.ts";
import type { CaptureSession } from "../fixture-capture.ts";
interface EnsureUsaaSessionArgs {
    /**
     * Runtime's `assist`/`completeAssistance` hooks (see `BaseCollectContext`
     * in `connector-runtime.ts`). When both are present, the manual-login
     * handoffs below self-resolve the moment the connector's own probe
     * (`verifyLoggedIn`) proves the session is live — mirroring `chatgpt.ts`'s
     * no-click browser-login flow — instead of always waiting on the owner's
     * manual "Continue collection" click. Optional so the many internal/test
     * callers that predate this keep compiling and keep the prior
     * click-first behavior.
     */
    assist?: (req: AssistanceRequest) => Promise<string>;
    capture?: CaptureSession | null;
    /** Paired with `assist` — see `ManualBrowserLoginArgs.completeAssistance`. */
    completeAssistance?: (assistanceRequestId: string, status: AssistanceCompletionStatus, extra?: {
        message?: string;
    }) => Promise<void>;
    context: BrowserContext;
    credentials?: Readonly<Record<string, string>>;
    onCredentialSubmit?: () => void;
    page: Page;
    sendInteraction: (req: InteractionRequest) => Promise<InteractionResponse>;
}
export declare function classifyUsaaLoginStepFailure(bodyText: string): "source_unavailable" | "password_field_missing";
export declare function ensureUsaaSession({ assist, capture, completeAssistance, context, credentials, onCredentialSubmit, page, sendInteraction, }: EnsureUsaaSessionArgs): Promise<boolean>;
export {};
//# sourceMappingURL=usaa.d.ts.map