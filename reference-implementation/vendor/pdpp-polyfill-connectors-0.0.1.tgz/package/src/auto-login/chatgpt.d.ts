/**
 * ChatGPT automated session management.
 *
 * ChatGPT auth expires after ~30 days. When expired, the user must either
 * sign in via Google SSO (couldn't be fully automated without Google creds)
 * or email+password.
 *
 * Credential fields: CHATGPT_USERNAME / CHATGPT_PASSWORD, resolved for THIS
 * connection from the runtime-supplied `credentials` (never read from
 * process.env — see `login-credentials.ts`). ChatGPT has Cloudflare protection
 * and may demand 2FA (app approval or code entry).
 *
 * If auto-login needs owner help (Cloudflare challenge, unexpected UI, slow
 * post-submit login), emit non-blocking assistance and poll ChatGPT session
 * readiness so the run resumes as soon as login completes.
 */
import type { BrowserContext, Page } from "playwright";
import { type ManualActionReason } from "../browser-handoff.ts";
import type { AssistanceCompletionStatus, AssistanceRequest, InteractionRequest, InteractionResponse, SessionCheckpointFn } from "../connector-runtime.ts";
import type { CaptureSession } from "../fixture-capture.ts";
interface EnsureChatGptSessionArgs {
    allowInteractiveAuthRepair?: boolean;
    assist?: (req: AssistanceRequest) => Promise<string>;
    capture?: CaptureSession | null;
    /**
     * Session-establishment progress hook. The runtime resets the
     * no-progress watchdog deadline on each call. The push-approval poll calls
     * it on every iteration so a long (but progressing) wait on an external app
     * approval is not failed closed by the watchdog. Optional so call sites that
     * do not wire it (older callers, tests) still work — when absent the poll
     * simply does not advance the watchdog, matching pre-change behavior.
     */
    checkpoint?: SessionCheckpointFn;
    completeAssistance?: (assistanceRequestId: string, status: AssistanceCompletionStatus, extra?: {
        message?: string;
    }) => Promise<void>;
    context: BrowserContext;
    /**
     * This connection's resolved sign-in pair, threaded from the runtime (see
     * `login-credentials.ts`). Optional so a direct, non-runtime caller can omit
     * it; an absent pair reports itself as absent rather than blaming the page.
     */
    credentials?: Readonly<Record<string, string | undefined>> | undefined;
    onCredentialSubmit?: () => void;
    page: Page;
    progress?: (message: string, extra?: {
        stream?: string;
    }) => Promise<void>;
    sendInteraction: (req: InteractionRequest) => Promise<InteractionResponse>;
}
export declare const CHATGPT_PUSH_APPROVAL_ASSISTANCE_MESSAGE = "ChatGPT sent an app approval notification. Approve it in the ChatGPT app; PDPP will continue automatically after ChatGPT confirms the session.";
export declare const CHATGPT_PUSH_APPROVAL_PROGRESS_MESSAGE = "ChatGPT sent an app approval notification. Approve it in the ChatGPT app; PDPP will continue automatically after ChatGPT confirms the session.";
export declare const CHATGPT_PUSH_APPROVAL_FALLBACK_MESSAGE = "ChatGPT approval did not complete automatically; open the ChatGPT app to approve it. PDPP resumes when the session continues.";
export declare const CHATGPT_BROWSER_LOGIN_ASSISTANCE_MESSAGE = "ChatGPT could not finish sign-in automatically; open the browser to continue. PDPP resumes when sign-in succeeds.";
export declare const CHATGPT_BROWSER_LOGIN_FALLBACK_MESSAGE = "ChatGPT could not finish sign-in automatically; open the browser to continue. PDPP resumes when sign-in succeeds.";
export declare const CHATGPT_SESSION_REQUIRED_NON_INTERACTIVE_MESSAGE = "chatgpt_session_required: ChatGPT session is not active; start an owner-attended manual refresh to repair authentication.";
export declare const CHATGPT_STORED_CREDENTIAL_REJECTED_MESSAGE = "chatgpt_stored_credential_rejected: ChatGPT rejected the stored username/password credential.";
/**
 * Resolve the push-approval observation budget in ms. Honors a positive-integer
 * `PDPP_CHATGPT_PUSH_APPROVAL_TIMEOUT_MS`; otherwise the raised default.
 */
export declare function resolveChatGptPushApprovalTimeoutMs(env?: NodeJS.ProcessEnv): number;
export declare function resolveChatGptBrowserLoginTimeoutMs(env?: NodeJS.ProcessEnv): number;
export declare function chatGptPushApprovalAssistance(env?: NodeJS.ProcessEnv): AssistanceRequest;
export declare function chatGptBrowserLoginAssistance(env?: NodeJS.ProcessEnv): AssistanceRequest;
export declare function interactionResponseCode(resp: InteractionResponse): string | null;
export declare function chatGptAllowsInteractiveAuthRepair(env?: NodeJS.ProcessEnv): boolean;
export declare function isLikelyChatGptPushApprovalText(text: string): boolean;
export declare function handleBrowserLoginAssistance({ assist, capture, checkpoint, completeAssistance, diagnosticMessage, message, page, progress, reason, sendInteraction, }: Pick<EnsureChatGptSessionArgs, "assist" | "capture" | "checkpoint" | "completeAssistance" | "page" | "progress" | "sendInteraction"> & {
    readonly diagnosticMessage?: string;
    readonly message?: string;
    readonly reason?: ManualActionReason;
}): Promise<boolean>;
/**
 * Drive the ChatGPT app push-approval flow. Exported for focused tests of the
 * non-blocking observation poll (watchdog checkpointing, auto-resume without an
 * interaction, and escalation ordering); production reaches it via
 * `submitPasswordAndHandleSecondFactor`.
 */
export declare function handlePushApproval({ assist, capture, checkpoint, completeAssistance, page, progress, sendInteraction, }: Pick<EnsureChatGptSessionArgs, "assist" | "capture" | "checkpoint" | "completeAssistance" | "page" | "progress" | "sendInteraction">): Promise<boolean>;
export declare function ensureChatGptSession({ assist, allowInteractiveAuthRepair, capture, checkpoint, completeAssistance, context: _context, credentials, onCredentialSubmit, page, progress, sendInteraction, }: EnsureChatGptSessionArgs): Promise<boolean>;
export {};
//# sourceMappingURL=chatgpt.d.ts.map