// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { validateAppleHealthExportArtifactFromFile } from "../connectors/apple_health/validation.js";
import { validateGoogleMapsTimelineArtifact, validateGoogleMapsTimelineArtifactFromFile, } from "../connectors/google_maps/validation.js";
import { validateNetflixExportArtifact, validateNetflixExportArtifactFromFile, } from "../connectors/netflix_export/validation.js";
import { validateStravaAccountExportArtifact, validateStravaAccountExportArtifactFromFile, } from "../connectors/strava/validation.js";
import { validateWhatsAppChatExportArtifact, validateWhatsAppChatExportArtifactFromFile, } from "../connectors/whatsapp/validation.js";
function existingFileHashesOption(existingFileHashes) {
    return existingFileHashes === undefined ? {} : { existingFileHashes };
}
function fileNameOption(fileName) {
    return fileName === undefined ? {} : { fileName };
}
export function validateManualUploadArtifactByKind(kind, input, options = {}) {
    const maxFileBytes = options.maxFileBytes ?? null;
    if (kind === "google_maps_timeline") {
        return validateGoogleMapsTimelineArtifact(input, {
            maxFileBytes,
        });
    }
    if (kind === "strava_account_export") {
        return validateStravaAccountExportArtifact(input, {
            ...existingFileHashesOption(options.existingFileHashes),
            ...fileNameOption(options.fileName),
            maxFileBytes,
        });
    }
    if (kind === "whatsapp_chat_export") {
        return validateWhatsAppChatExportArtifact(input, {
            fileName: options.fileName ?? null,
            maxFileBytes,
        });
    }
    if (kind === "netflix_viewing_activity") {
        return validateNetflixExportArtifact(input, {
            fileName: options.fileName ?? null,
            maxFileBytes,
        });
    }
    return null;
}
/**
 * File-descriptor-backed counterpart to {@link validateManualUploadArtifactByKind}:
 * dispatches to a kind's file-backed validator (never buffers the whole
 * artifact) when one exists, `null` otherwise. This is the ONLY place in the
 * codebase that both knows which `kind` strings have a file-backed validator
 * AND imports the connector modules that implement them -- it is the
 * connector-owned registry (this whole file lives in
 * `packages/polyfill-connectors`, outside the reference implementation), the
 * same architectural role `validateManualUploadArtifactByKind` above already
 * plays for the buffer-based path.
 *
 * RI callers must never branch on a `kind ===` string themselves or import a
 * connector's validation module directly -- they call this function (or its
 * buffer-based sibling) and get back a result or `null`, staying entirely
 * ignorant of which kinds happen to have a file-backed implementation. That
 * is decided here, and only here, driven by whether `kind` is present in
 * this function's own dispatch table -- the manifest's `file_backed: true`
 * flag is what tells an RI CALLER whether to route through this function at
 * all, not what this function itself branches on.
 */
export async function validateManualUploadArtifactFromFileByKind(kind, fd, fileSize, options) {
    if (kind === "apple_health_export") {
        return await validateAppleHealthExportArtifactFromFile(fd, options.filePath, fileSize, {
            fileName: options.fileName,
            fileSha256: options.fileSha256,
            maxFileBytes: options.maxFileBytes ?? null,
        });
    }
    if (kind === "whatsapp_chat_export") {
        return await validateWhatsAppChatExportArtifactFromFile(fd, options.filePath, fileSize, {
            fileName: options.fileName,
            fileSha256: options.fileSha256,
            maxFileBytes: options.maxFileBytes ?? null,
        });
    }
    if (kind === "netflix_viewing_activity") {
        return validateNetflixExportArtifactFromFile(fd, options.fileName, fileSize, {
            fileName: options.fileName,
            fileSha256: options.fileSha256,
            maxFileBytes: options.maxFileBytes ?? null,
        });
    }
    if (kind === "google_maps_timeline") {
        return await validateGoogleMapsTimelineArtifactFromFile(options.filePath, fileSize, {
            fileSha256: options.fileSha256,
            maxFileBytes: options.maxFileBytes ?? null,
        });
    }
    if (kind === "strava_account_export") {
        return await validateStravaAccountExportArtifactFromFile(fd, options.filePath, fileSize, {
            ...existingFileHashesOption(options.existingFileHashes),
            fileName: options.fileName,
            fileSha256: options.fileSha256,
            maxFileBytes: options.maxFileBytes ?? null,
        });
    }
    return null;
}
