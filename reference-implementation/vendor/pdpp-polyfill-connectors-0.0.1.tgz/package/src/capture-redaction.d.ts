/**
 * Credential redaction for connector capture artifacts, applied at WRITE TIME.
 *
 * Why this exists separately from `src/scrub-defaults.ts`:
 *
 * The fixture scrubber answers "what is unsafe to COMMIT?" — it matches PII by
 * shape (email, SSN, card, phone, address, labelled names) and runs as a later
 * pass from raw/ into scrubbed/. This module answers a different question:
 * "what is unsafe to WRITE TO DISK AT ALL?" Two reasons the scrubber cannot be
 * the answer here:
 *
 *   1. Timing. raw/ persists on the volume and is precisely what a diagnostic
 *      agent is pointed at. A later sanitizing pass does not un-write bytes
 *      that already landed. Redaction has to happen before the write.
 *   2. Shape. A credential has no shape. `BG54aFvx` is not an email, an SSN, a
 *      card, or a labelled name, so every rule in scrub-defaults.ts passes it
 *      through verbatim. Secrets are identified by their POSITION (the value
 *      slot of a secret-ish field) or by IDENTITY (equal to a credential the
 *      run actually holds) — never by pattern.
 *
 * So the two are complementary, not duplicative, and this module is the
 * narrower, stricter gate. `credentialScrubRules()` re-exports the value-based
 * half of it as ScrubRules so the commit-time path inherits the same notion of
 * "credential-sensitive" instead of drifting to a second one.
 *
 * Both confirmed leak channels are covered; both were verified empirically
 * against real Playwright output rather than assumed:
 *
 *   ARIA snapshots (page.ariaSnapshot) serialize the live value PROPERTY, so a
 *   password typed by fill() appears in full:
 *       - textbox "Password" [ref=e25]: BG54aFvx
 *
 *   DOM dumps (page.content) serialize the value ATTRIBUTE, not the property.
 *   A typed password therefore does NOT appear, but a value="..." present in
 *   served markup or set via setAttribute DOES. Narrower than ARIA, still real.
 *
 * Redaction preserves diagnostic value. The point of these captures is
 * debugging a failed login, so a redacted field must still show that it
 * EXISTED and whether it was FILLED. We replace only the value text with
 * `[REDACTED]`, never the field, its role, its label, or its ref. An empty
 * field stays visibly empty — "present but empty" vs "present and filled" is
 * exactly the distinction that diagnoses a login failure.
 */
/** Placeholder written in place of a redacted secret value. */
export declare const REDACTED = "[REDACTED]";
/** True when a field's accessible name / attribute names imply a secret value. */
export declare function isSecretFieldName(name: string): boolean;
/**
 * Replace every occurrence of a known credential value with `[REDACTED]`.
 *
 * This is the identity-based rule, and it is the one that catches a secret in
 * a field nobody thought to label — including values echoed into page text,
 * inline scripts, JSON blobs or URLs, where no field-based rule could see it.
 */
export declare function redactKnownSecrets(content: string, secrets: readonly string[]): string;
/**
 * Redact secret values from a Playwright ARIA snapshot (`mode: "ai"`).
 *
 * Playwright emits one node per line as `- <role> "<name>" [attrs]: <value>`,
 * with the value optionally quoted. We rewrite only the text after the final
 * value-introducing colon, leaving indentation, role, accessible name, refs
 * and state flags intact so the tree still reads correctly.
 *
 * A field with no value keeps its empty rendering: an unfilled password box
 * still looks unfilled after redaction.
 */
export declare function redactAriaSnapshot(snapshot: string, secrets?: readonly string[]): string;
/**
 * Redact secret values from a DOM HTML dump (`page.content()`).
 *
 * Only the `value` attribute of a secret-ish `<input>` is rewritten. The tag,
 * its type, name, id and every other attribute survive, so the element is
 * still visible to whoever is debugging the page — it simply no longer carries
 * the credential.
 *
 * `type="password"` is always treated as secret regardless of its name, which
 * catches an unlabelled password box.
 */
export declare function redactDomHtml(html: string, secrets?: readonly string[]): string;
/**
 * The identity-based rule expressed as scrubber `ScrubRule`s, so the
 * commit-time scrubber path shares this module's definition of
 * "credential-sensitive" rather than growing a divergent second one.
 *
 * Field-based rules are intentionally NOT exported this way: they are
 * structural (they need to see an ARIA line or an HTML tag), and the scrubber's
 * flat regex-over-text model cannot express them safely.
 */
export declare function credentialScrubRules(secrets: readonly string[]): {
    pattern: RegExp;
    replacement: string;
    scope: "all";
}[];
//# sourceMappingURL=capture-redaction.d.ts.map