export interface ReferenceBlobRef {
    blob_id: string;
    mime_type: string;
    sha256: string;
    size_bytes: number;
}
export type ReferenceBlobUploadContent = AsyncIterable<Buffer | Uint8Array | string> | Iterable<Buffer | Uint8Array | string>;
export type ReferenceBlobUploadFn = (args: {
    connectorId: string;
    connectorInstanceId?: string | null;
    content: ReferenceBlobUploadContent;
    jsonPath?: string;
    mimeType: string;
    recordKey: string;
    stream: string;
}) => Promise<ReferenceBlobRef>;
/**
 * Sanitized failure classes from the blob-upload boundary. The class carries
 * only the operation family; callers must not retain a status, URL, or body
 * as telemetry.
 */
export type ReferenceBlobUploadFailureKind = "http_4xx" | "http_5xx" | "integrity_mismatch" | "invalid_response" | "source_content_failed" | "transport";
export declare class ReferenceBlobUploadFailure extends Error {
    readonly kind: ReferenceBlobUploadFailureKind;
    constructor(kind: ReferenceBlobUploadFailureKind, message: string, cause?: unknown);
}
export declare function runtimeBlobUploadAvailable(env?: NodeJS.ProcessEnv): boolean;
export declare function makeReferenceBlobUploader(args: {
    connectorInstanceId?: string | null;
    fetchFn?: typeof fetch;
    ownerToken: string;
    rsUrl: string;
}): ReferenceBlobUploadFn;
//# sourceMappingURL=reference-blob-uploader.d.ts.map