// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
import { existsSync } from "node:fs";
import { extname, join } from "node:path";
import { pathToFileURL } from "node:url";
const REDACTION_REPLACEMENT_RE = /^\[REDACTED_[A-Z0-9_]+\]$/;
export function fileScopeOf(path) {
    const ext = extname(path).toLowerCase();
    if (ext === ".html" || ext === ".htm") {
        return "html";
    }
    if (ext === ".json" || ext === ".jsonl") {
        return "json";
    }
    return "all";
}
export function applyScrubRules(content, rules, fileScope) {
    let out = content;
    for (const rule of rules) {
        if (!scopeMatches(fileScope, rule.scope)) {
            continue;
        }
        if (typeof rule.replacement === "string") {
            out = out.replace(rule.pattern, rule.replacement);
        }
        else {
            const { replacement } = rule;
            out = out.replace(rule.pattern, (substring, ...args) => replacement(substring, ...args));
        }
    }
    return out;
}
export function parseStructuredRedactionPlan(value) {
    if (!value || typeof value !== "object") {
        throw new Error("redaction plan must be an object");
    }
    const candidate = value;
    if (candidate.version !== 1) {
        throw new Error("redaction plan version must be 1");
    }
    if (!Array.isArray(candidate.redactions)) {
        throw new Error("redaction plan redactions must be an array");
    }
    return {
        version: 1,
        redactions: candidate.redactions.map(parseStructuredRedaction),
    };
}
export function applyStructuredRedactionPlan(content, plan) {
    let out = content;
    for (const redaction of plan.redactions) {
        if (!out.includes(redaction.text)) {
            throw new Error(`redaction target not found: ${redaction.reason}`);
        }
        out = out.split(redaction.text).join(redaction.replacement);
    }
    return out;
}
export async function loadConnectorScrubRules(packageRoot, connector) {
    const rulesFile = findConnectorRulesFile(packageRoot, connector);
    if (!rulesFile) {
        return [];
    }
    const mod = (await import(__rewriteRelativeImportExtension(pathToFileURL(rulesFile).href)));
    const rules = mod.scrubRules ?? mod.default ?? [];
    if (!Array.isArray(rules)) {
        console.warn(`${rulesFile}: expected scrubRules array; got ${typeof rules}`);
        return [];
    }
    return rules.filter(isScrubRule);
}
function findConnectorRulesFile(packageRoot, connector) {
    const connectorRoot = join(packageRoot, "connectors", connector);
    const candidates = [
        join(connectorRoot, "scrub-rules.ts"),
        join(connectorRoot, "scrub-rules.js"),
    ];
    return candidates.find((candidate) => existsSync(candidate)) ?? null;
}
function scopeMatches(fileScope, ruleScope) {
    return ruleScope === "all" || ruleScope === fileScope;
}
function isScrubRule(value) {
    if (!value || typeof value !== "object") {
        return false;
    }
    const candidate = value;
    return (candidate.pattern instanceof RegExp &&
        (typeof candidate.replacement === "string" ||
            typeof candidate.replacement === "function") &&
        (candidate.scope === "all" ||
            candidate.scope === "html" ||
            candidate.scope === "json"));
}
function parseStructuredRedaction(value, index) {
    if (!value || typeof value !== "object") {
        throw new Error(`redaction ${index} must be an object`);
    }
    const candidate = value;
    if (typeof candidate.text !== "string" || candidate.text.length === 0) {
        throw new Error(`redaction ${index} text must be a non-empty string`);
    }
    if (typeof candidate.replacement !== "string" ||
        !REDACTION_REPLACEMENT_RE.test(candidate.replacement)) {
        throw new Error(`redaction ${index} replacement must be a [REDACTED_*] placeholder`);
    }
    if (typeof candidate.reason !== "string" || candidate.reason.length === 0) {
        throw new Error(`redaction ${index} reason must be a non-empty string`);
    }
    return {
        text: candidate.text,
        replacement: candidate.replacement,
        reason: candidate.reason,
    };
}
