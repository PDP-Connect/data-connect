export declare class ReasonDisplayMessageError extends Error {
}
/**
 * Every shipped polyfill-connector manifest's own `reason_display_messages`,
 * keyed by connector_key. Re-derived on every call (manifests are small,
 * this is not a hot path) rather than cached, so tests can point
 * `PDPP_POLYFILL_MANIFESTS_DIR` at a scratch directory and see it reflected
 * immediately (matches `readPolyfillManifests`'s own behavior).
 */
export declare function connectorReasonDisplayMessages(): Readonly<Record<string, Readonly<Record<string, string>>>>;
/** Looks up one connector's declared copy for one reason code, or `null` if none is declared. */
export declare function connectorReasonDisplayMessage(connectorKey: string | null, reasonCode: string | null): string | null;
//# sourceMappingURL=reason-display-messages.d.ts.map