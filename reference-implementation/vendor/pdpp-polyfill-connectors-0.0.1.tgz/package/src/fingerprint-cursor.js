// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
// Per-record fingerprint cursor for polyfill connectors.
//
// Several connectors (Slack, Gmail, Codex, YNAB) emit records from sources
// that re-derive the full record on every run — slackdump archive rebuilds,
// IMAP `1:*` re-aggregations, sqlite mtime triggers, full-collection refetches.
// Without an emit-side gate, those sources produce a fresh RECORD per (record,
// run) pair even when the source state has not moved, which accumulates into
// hundreds-to-thousands of versions per record downstream.
//
// This module owns the repeated pattern those connectors converged on:
//
//   1. compute a stable fingerprint over the emitted record fields,
//      excluding caller-declared run-clock fields (`fetched_at`, etc.);
//   2. seed the next-run cursor from the prior cursor so a skipped record
//      survives into the next STATE write (carry-forward);
//   3. record every observed id in the seen-set, regardless of whether the
//      record was emitted, so a later prune knows what the source returned;
//   4. on full-scan streams, drop prior ids absent from this run so deleted
//      records do not stay gated as no-ops forever.
//
// Identity, run-clock-field selection, and which streams get pruned remain
// connector-owned. The runtime byte-equivalence check at the storage layer is
// a backstop for cases this gate cannot see (a connector emits the wrong key,
// or the source genuinely returns a byte-identical re-ingest); it is not a
// substitute for this gate.
import { createHash } from "node:crypto";
/** Open a typed carry-forward cursor seeded from a pre-decoded prior map.
 *
 *  Unlike `openFingerprintCursor`, this does not decode a STATE shape or
 *  compute fingerprints — the caller owns both, because the fingerprint
 *  type and its on-disk shape are connector-specific. The cursor only owns
 *  the seed/seen/prune/serialize lifecycle.
 *
 *  The next map is seeded by copying the prior map, so a record the caller
 *  declines to `note` this run still surfaces in `toState()`. */
export function openCarryForwardCursor(prior) {
    const next = new Map(prior);
    const seen = new Set();
    return {
        prior(id) {
            return prior.get(id);
        },
        note(id, value) {
            next.set(id, value);
            seen.add(id);
        },
        dropUnseenIds() {
            for (const id of next.keys()) {
                if (!seen.has(id)) {
                    next.delete(id);
                }
            }
        },
        size() {
            return next.size;
        },
        toState() {
            const out = {};
            for (const [id, value] of next) {
                out[id] = value;
            }
            return out;
        },
    };
}
/** Stable per-record fingerprint over the emitted record's fields. Keys
 *  are sorted recursively so the hash does not depend on incidental key
 *  order in the record builder. SHA-1 is fine for change detection: a
 *  collision between distinct shapes would silently skip one emit per
 *  record, and the run-clock-field risk dominates anyway.
 *
 *  Exposed because the four existing implementations all needed the
 *  same primitive under slightly different names; future migrations can
 *  import it directly without reaching for `openFingerprintCursor`. */
export function recordFingerprint(record, excludeKeys = []) {
    const exclude = new Set(excludeKeys);
    return createHash("sha1")
        .update(stableStringify(record, exclude))
        .digest("hex");
}
/** Open a cursor seeded from a prior STATE shape.
 *
 *  `priorState` is decoded tolerantly. The following shapes all produce
 *  an empty prior map without throwing:
 *    - `undefined` / `null`
 *    - any non-object value
 *    - arrays
 *    - an object missing a `fingerprints` field (legacy cursor shape)
 *    - a `fingerprints` field whose value is not an object
 *    - entries whose value is not a non-empty string
 *
 *  This matches the existing per-connector tolerance for legacy cursors
 *  and corrupt-on-disk state: a broken cursor never blocks a successful
 *  run, it just re-emits everything next time.
 *
 *  The cursor is seeded by copying the prior map into the next map so a
 *  record skipped this run still surfaces in the next STATE write. */
export function openFingerprintCursor(priorState, options = {}) {
    const staticExcludeKeys = options.excludeFromFingerprint ?? [];
    const resolveExcludeKeys = options.resolveExcludeFromFingerprint;
    const prior = options.priorFingerprints ?? decodePriorFingerprints(priorState);
    // The hashed-record specialization is layer 1 (compute the fingerprint,
    // compare against prior) over the shared `T = string` carry-forward
    // lifecycle (layer 2).
    const cursor = openCarryForwardCursor(prior);
    return {
        shouldEmit(data) {
            const rawId = data.id;
            if (rawId === null || rawId === undefined) {
                return true;
            }
            const id = String(rawId);
            if (id.length === 0) {
                return true;
            }
            const record = data;
            const excludeKeys = resolveExcludeKeys
                ? resolveExcludeKeys(record)
                : staticExcludeKeys;
            const fingerprint = recordFingerprint(record, excludeKeys);
            cursor.note(id, fingerprint);
            return cursor.prior(id) !== fingerprint;
        },
        priorFingerprint(id) {
            return cursor.prior(id);
        },
        dropUnseenIds() {
            cursor.dropUnseenIds();
        },
        toState() {
            return cursor.toState();
        },
        size() {
            return cursor.size();
        },
    };
}
// ─── Internals ──────────────────────────────────────────────────────────
function decodePriorFingerprints(priorState) {
    const out = new Map();
    if (!priorState ||
        typeof priorState !== "object" ||
        Array.isArray(priorState)) {
        return out;
    }
    const raw = priorState.fingerprints;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        if (typeof value === "string" && value.length > 0) {
            out.set(id, value);
        }
    }
    return out;
}
function compareKeys(a, b) {
    if (a < b) {
        return -1;
    }
    if (a > b) {
        return 1;
    }
    return 0;
}
function stableStringify(value, exclude) {
    if (value === null || typeof value !== "object") {
        return JSON.stringify(value) ?? "null";
    }
    if (Array.isArray(value)) {
        return `[${value.map((v) => stableStringify(v, exclude)).join(",")}]`;
    }
    const entries = Object.entries(value)
        .filter(([k]) => !exclude.has(k))
        .sort(([a], [b]) => compareKeys(a, b));
    return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v, exclude)}`).join(",")}}`;
}
