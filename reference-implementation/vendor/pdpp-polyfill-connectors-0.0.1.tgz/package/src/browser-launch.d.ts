import type { Browser, BrowserContext } from "playwright";
export declare const BROWSER_HEADLESS_ENV = "PDPP_BROWSER_HEADLESS";
export interface IsolatedBrowser {
    browser: Browser | null;
    context: BrowserContext;
    release: () => Promise<void>;
}
export interface AcquireIsolatedBrowserOptions {
    headless?: boolean;
    /**
     * Skip remote-CDP page-target cleanup before attach. Use only when the
     * connector intentionally preserves successful pages because the page itself
     * carries source auth state.
     */
    preserveRemotePagesOnAcquire?: boolean;
    profileName: string;
    /**
     * When set, the launcher does NOT spawn its own Chromium. Instead it
     * calls `patchright.chromium.connectOverCDP(remoteCdpUrl)` and returns
     * the FIRST existing context as the connector's context. Used for
     * connectors that need a real X server + WebRTC streaming (n.eko-hosted
     * Chromium) so the manual_action handoff goes back to the same browser
     * the connector was driving — not a separate headless Chrome launched
     * inside the reference container.
     *
     * The release function disconnects the Patchright client; it does NOT
     * close the remote browser. The neko container owns that lifecycle.
     *
     * When set, `streamingEnabled` is implied; we register the page-target
     * wsUrl for manual_action via the standard browser-handoff helper, but
     * the wsUrl points at the neko-hosted page through the cdp-proxy.py
     * URL the streaming companion already knows how to attach to.
     */
    remoteCdpUrl?: string;
    /**
     * When true, the launcher launches Chromium in CDP-port mode
     * (`--remote-debugging-port=0` plus `--remote-debugging-address=127.0.0.1`), reads
     * the resolved random port out of `<userDataDir>/DevToolsActivePort`,
     * and publishes `PDPP_BROWSER_CDP_HOST` / `PDPP_BROWSER_CDP_PORT` to
     * `process.env` for the browser-binding-local handoff helper
     * (`browser-handoff.ts`) to compose per-interaction wsUrls at
     * `manual_action` emission time.
     *
     * The launcher itself does NOT register any streaming target — that
     * is interaction-scoped and owned by the binding code that emits the
     * manual_action. See
     * `openspec/changes/add-run-interaction-streaming-companion/`
     * `design-notes/interaction-scoped-target-resolution-2026-05-05.md`.
     *
     * Best-effort port publication: any failure (port not appearing in
     * `DevToolsActivePort`, etc.) logs a warning and lets the browser
     * launch succeed. The honest failure mode is "streaming unavailable
     * for this run; records still flow."
     *
     * Connectors that never need streaming MUST be unaffected — leave
     * this `false` or omit it.
     */
    streamingEnabled?: boolean;
}
/**
 * Stable error code surfaced when a HEADED browser-backed connector is
 * attempted in a container/provider runtime that cannot show a visible
 * browser. The dashboard renders this as a deployment-config error
 * state pointing the operator at the local collector runner.
 */
export declare const HEADED_BROWSER_UNAVAILABLE_CODE = "headed_browser_unavailable";
/**
 * Failure surfaced when a HEADED browser-backed connector is requested
 * inside a container without a local collector runtime that can render
 * the browser. Carries a stable `code` so the dashboard can render the
 * actionable deployment-config error state.
 */
export declare class HeadedBrowserUnavailableError extends Error {
    readonly code: typeof HEADED_BROWSER_UNAVAILABLE_CODE;
    constructor(args: {
        message: string;
    });
}
/**
 * Pure decision helper for the in-container fail-closed gate. Exported
 * so tests can exercise the policy without launching Patchright (the
 * acquire path itself is hard to test without spinning up a real
 * browser).
 *
 * Headed-vs-headless interpretation MUST mirror the effective mode resolved by
 * `acquireBrowserForConnector`, which applies the deployment override when a
 * caller omits `headless`. The baseline is headed, so:
 *
 *   - `headless: true`  → headless (allowed in container)
 *   - `headless: false` → headed   (container gate requires managed display or escape hatch)
 *   - `headless: undefined` (caller omitted the field) → the deployment
 *     choice (`PDPP_BROWSER_HEADLESS=1` means headless; otherwise headed).
 *     A connector's browser config never supplies this field.
 *
 * Returns:
 *   - `{ kind: "fail_closed" }` when the effective request is HEADED,
 *     the runtime is in a container, and the escape hatch is not
 *     asserted. Caller MUST throw `HeadedBrowserUnavailableError`.
 *   - `{ kind: "warn_and_proceed" }` when the same conditions hold
 *     except `PDPP_ALLOW_HEADED_CONTAINER_BROWSER=1` is asserted.
 *     Caller SHOULD emit a per-acquisition stderr warning and proceed.
 *   - `{ kind: "proceed" }` otherwise.
 */
export type ContainerHeadedBrowserGate = {
    readonly kind: "fail_closed";
} | {
    readonly kind: "warn_and_proceed";
} | {
    readonly kind: "proceed";
};
export interface ContainerHeadedBrowserGateInputs {
    readonly escapeHatchEnabled: boolean;
    readonly headless: boolean | undefined;
    readonly inContainer: boolean;
    /**
     * Core's startup supervisor has installed the image-owned browser runtime
     * and waited for its managed Xvfb display. Omitted/false preserves the
     * fail-closed behavior for unrelated container runtimes.
     */
    readonly managedDisplayAvailable?: boolean;
    /**
     * When set, the launcher will NOT spawn a local headed Chromium — it
     * will attach to a remote CDP endpoint (e.g. a n.eko browser surface) which
     * already renders the browser visibly for the operator. In that case
     * the in-container fail-closed gate does not apply: there is no
     * invisible headed browser to fail closed against. Local headed
     * container launches (no remoteCdpUrl) still fail closed as before.
     */
    readonly remoteCdpUrl?: string;
}
/**
 * Resolve the deployment-owned local browser mode. Connector manifests do not
 * call this with an explicit value; the explicit argument remains available to
 * operator-side low-level callers as the existing headless escape hatch.
 */
export declare function resolveDeploymentBrowserHeadless(headless: boolean | undefined, env?: Record<string, string | undefined>): boolean;
export declare function decideContainerHeadedBrowserGate(inputs: ContainerHeadedBrowserGateInputs): ContainerHeadedBrowserGate;
export declare function configuredBrowserChannel(env?: Record<string, string | undefined>): string | undefined;
/**
 * Recognise the transient CDP-attach race that fails `connectOverCDP`
 * against a live n.eko Chromium with:
 *
 *   Protocol error (Network.setCacheDisabled): Internal server error, session closed.
 *       at ... crNetworkManager.setRequestInterception
 *
 * Root cause (verified against patchright-core 1.61.1 internals):
 * Patchright's `CRPage` constructor eagerly calls
 * `this._networkManager.setRequestInterception(true)` so its stealth
 * Fetch-domain hooks are always active (`server/chromium/crPage.js` line 80).
 * Stock Playwright does NOT — it defers to a conditional
 * `updateRequestInterception()`. Critically, that constructor call is FLOATED:
 * no `await`, no `.catch`. Patchright's `setRequestInterception` ends with a
 * patchright-only
 * `_forEachSession(info => info.session.send("Network.setCacheDisabled", …))`
 * (`server/chromium/crNetworkManager.js`). When `connectOverCDP` auto-attaches
 * (`Target.setAutoAttach`) to every existing target, `_onAttachedToTarget`
 * builds a `CRPage` per target — including the short-lived `about:blank` target
 * n.eko opens via `/json/new?about:blank` and immediately tears down via
 * `/json/close`. If that target's session disposes while the send is in flight,
 * the in-flight callback is rejected with `Internal server error, session
 * closed.` (`crConnection.js` `dispose()`). The MAIN-frame branch of
 * `_forEachSession` has no `.catch` guard (only non-main sessions swallow
 * `isSessionClosedError`).
 *
 * Because the offending `setRequestInterception(true)` is floated and
 * `connectOverCDP` only awaits `_waitForAllPagesToBeInitialized()` (NOT the
 * interception promise), `connectOverCDP` RESOLVES successfully and the
 * rejection escapes the entire connect promise chain as a Node UNHANDLED
 * REJECTION (`node:internal/process/promises`), terminating the process a tick
 * or two after attach. This is why a `try/catch` around `connectOverCDP` (v1)
 * never observed it. The catch boundary now lives in
 * `runCdpAttemptWithRaceGuard`, which intercepts the unhandled rejection.
 *
 * The condition is inherently transient: the offending target is on its way
 * out. A bounded retry a moment later — once n.eko's transient target has
 * disposed and only the stable page target remains — attaches cleanly.
 *
 * We deliberately do NOT switch the remote-attach client to stock Playwright:
 * patchright's `Runtime.enable` suppression and isolated-world hiding are
 * CLIENT-driven stealth (sent over CDP by the driving process, not baked into
 * the launched browser). A stock client attaching to the same browser would
 * leak the canonical CDP `Runtime.enable` automation signal on every page —
 * a permanent stealth regression on a bot-hostile target like Amazon, traded
 * for a transient startup race. Retry keeps full patchright stealth.
 *
 * Matched narrowly on the CDP method + the session-closed phrase so unrelated
 * protocol errors (auth, bad URL, real crash) still fail fast.
 */
export declare function isCdpAttachSessionRaceError(err: unknown): boolean;
/**
 * Stable, machine-actionable code carried on the error thrown by
 * `connectOverCdpWithRetry` when it exhausts every bounded attempt of the
 * narrow attach-session race (`isCdpAttachSessionRaceError`). This is the
 * ONLY source boundary that knows the retry budget was exhausted for THIS
 * specific race — not a rate limit, not a credential failure, not a real
 * browser crash. Downstream layers (the connector runtime's terminal error,
 * the reference runtime's connector_error.code, the managed-surface
 * lifecycle) MUST key off this typed code and MUST NOT re-derive the same
 * disposition by re-parsing error message text.
 */
export declare const CDP_ATTACH_SESSION_RACE_EXHAUSTED_CODE = "browser_surface_attach_exhausted";
/**
 * Error subclass thrown when `connectOverCdpWithRetry` gives up after
 * exhausting `maxAttempts` on the narrow attach-session race. Carries the
 * stable `code` so callers can pattern-match on a typed property instead of
 * the underlying race error's message text (which remains available via
 * `cause` for logs/diagnostics only).
 */
export declare class CdpAttachSessionRaceExhaustedError extends Error {
    readonly code: typeof CDP_ATTACH_SESSION_RACE_EXHAUSTED_CODE;
    constructor(lastError: unknown);
}
/**
 * Minimal port of the `process` unhandled-rejection surface the attempt guard
 * needs. Injected so the guard can be unit-tested without touching the real
 * process listeners (the test drives a fake emitter directly).
 */
export interface UnhandledRejectionHost {
    off: (event: "unhandledRejection", listener: (reason: unknown) => void) => void;
    on: (event: "unhandledRejection", listener: (reason: unknown) => void) => void;
}
/**
 * Run ONE remote-CDP attach attempt with a scoped `unhandledRejection` guard.
 *
 * Why this exists (root cause v2): the production failure is NOT the
 * `connectOverCDP` promise rejecting. `connectOverCDP` RESOLVES — it returns a
 * live `Browser`. Patchright's `CRPage` constructor then fires
 * `this._networkManager.setRequestInterception(true)` with NO `await` and NO
 * `.catch` (`server/chromium/crPage.js`). That floated promise runs
 * `_forEachSession(… "Network.setCacheDisabled" …)`, whose MAIN-frame branch has
 * no session-closed guard. When n.eko's transient `about:blank` target disposes
 * mid-send, the floated promise rejects, and because nobody is awaiting it the
 * rejection escapes the entire `connectOverCDP` promise chain as a Node
 * UNHANDLED REJECTION (`node:internal/process/promises`), terminating the
 * process. A `try/catch` around `connectOverCDP` (v1) can never see it.
 *
 * The fix installs a temporary `process.on("unhandledRejection")` listener and
 * races the attach attempt against that signal. If the race lands while
 * `connect()` is still pending, the attempt rejects immediately instead of
 * waiting for Patchright's 30s timeout. If `connect()` resolves first, the
 * guard stays open for a short settle window because the floated rejection can
 * land on a later tick. Either way, a matching unhandled rejection becomes a
 * retryable rejection of this attempt; the caller's bounded retry then
 * re-attaches once n.eko's transient target is gone.
 *
 * Safety rails:
 *   - The listener is ALWAYS removed when the attempt settles (success,
 *     retryable race, or fail-fast), via the `finally` block. We never leave a
 *     global listener installed across attempts.
 *   - Only the narrow race signature is consumed. Any OTHER unhandled rejection
 *     is re-thrown synchronously from the listener after removing ourselves, so
 *     Node's default crash-on-unhandled-rejection behavior is preserved for
 *     unrelated bugs. We do not become a process-wide rejection sink.
 *   - If the race rejection arrives after `connect()` already returned a live
 *     browser, or `connect()` resolves after the guard has already rejected,
 *     the injected `disconnect` is invoked best-effort so we don't leak a CDP
 *     client.
 *
 * `host`, `setTimeoutFn`, and `clearTimeoutFn` are injected for tests.
 */
export declare function runCdpAttemptWithRaceGuard<TBrowser>({ connect, disconnect, settleMs, host, setTimeoutFn, clearTimeoutFn, }: {
    connect: () => Promise<TBrowser>;
    disconnect?: (browser: TBrowser) => Promise<void> | void;
    settleMs?: number;
    host?: UnhandledRejectionHost;
    setTimeoutFn?: typeof setTimeout;
    clearTimeoutFn?: typeof clearTimeout;
}): Promise<TBrowser>;
/**
 * Attach to a remote Chromium with a bounded retry around the transient
 * `connectOverCDP` session-closed race (see `isCdpAttachSessionRaceError`).
 *
 * Each attempt runs inside `runCdpAttemptWithRaceGuard` so the failure can be
 * caught whether it surfaces as a rejected `connect` promise OR as a Node
 * unhandled rejection from patchright's floated `setRequestInterception(true)`
 * (the v2 root cause — v1 only handled the former). Only the race error is
 * retried; every other failure (auth, unreachable endpoint, real browser crash)
 * is rethrown immediately so we never mask a genuine attach failure behind a
 * retry budget.
 *
 * `connect`, `disconnect`, `sleep`, and `runAttempt` are injected so the retry
 * policy can be unit-tested without a live browser.
 */
export declare function connectOverCdpWithRetry<TBrowser>({ connect, disconnect, profileName, redactedUrl, maxAttempts, retryDelayMs, sleep, runAttempt, }: {
    connect: () => Promise<TBrowser>;
    disconnect?: (browser: TBrowser) => Promise<void> | void;
    profileName: string;
    redactedUrl: string;
    maxAttempts?: number;
    retryDelayMs?: number;
    sleep?: (ms: number) => Promise<void>;
    runAttempt?: typeof runCdpAttemptWithRaceGuard;
}): Promise<TBrowser>;
/**
 * Attach to a remote Chromium via the standard DevTools Protocol over
 * WebSocket. Used when the connector should run inside a browser hosted
 * by a different container (e.g. n.eko) so the manual_action streaming
 * handoff lands on the exact same browser process.
 *
 * The returned context is the FIRST existing context on the remote
 * browser — typically the only context, since neko's Chromium runs with
 * a single persistent user-data-dir. The release function disconnects
 * the Patchright client but leaves the remote browser running; lifecycle
 * is owned by whoever launched it.
 *
 * Pages opened by the connector are NOT cleaned up automatically — the
 * connector should close any pages it opened in its own cleanup. This
 * matches `launchPersistentContext` semantics where the context outlives
 * individual pages.
 *
 * The attach itself is wrapped in `connectOverCdpWithRetry` to ride out the
 * transient session-closed race n.eko's transient targets trigger during
 * Patchright's auto-attach. That race does NOT reject `connectOverCDP`; it
 * escapes as a Node unhandled rejection from patchright's floated
 * `setRequestInterception(true)`, so each attempt runs under a scoped
 * `unhandledRejection` guard. See `runCdpAttemptWithRaceGuard` and
 * `isCdpAttachSessionRaceError`.
 */
export declare function shouldCleanRemoteCdpPageTargets({ preserveRemotePagesOnAcquire, }: Pick<AcquireIsolatedBrowserOptions, "preserveRemotePagesOnAcquire">): boolean;
/**
 * Launch an isolated per-connection browser context with its own profile dir.
 * The connector runtime scopes the profile name with the stable connector
 * instance ID when the reference runtime supplies one.
 */
export declare function acquireIsolatedBrowser({ profileName, headless, streamingEnabled, remoteCdpUrl, preserveRemotePagesOnAcquire, }: AcquireIsolatedBrowserOptions): Promise<IsolatedBrowser>;
/**
 * Read Chromium's `DevToolsActivePort` (written to `<userDataDir>` when
 * `--remote-debugging-port=0` is set), then GET `http://127.0.0.1:PORT/json`
 * and pick the first `page` target's `webSocketDebuggerUrl`.
 *
 * Returns `null` when:
 *   - the port file isn't available within the poll window, or
 *   - the `/json` endpoint isn't reachable, or
 *   - no `type === "page"` target is present.
 *
 * Caller treats `null` as "skip registration, log + continue."
 *
 * Why DevToolsActivePort: Chromium writes this file as part of
 * remote-debugging startup (it's how `chrome --remote-debugging-port=0`
 * communicates the chosen random port to the launching process). It is the
 * canonical local-only handshake for "what port did Chromium pick?" and
 * does not require parsing Chromium stderr (which Playwright captures and
 * does not re-expose on launchPersistentContext).
 *
 * `fetchImpl` is injectable so tests can exercise the `/json` parsing
 * branch without a real Chromium.
 */
export declare function resolvePageTargetWsUrl({ userDataDir, fetchImpl, timeoutMs, pollMs, }: {
    userDataDir: string;
    fetchImpl?: typeof fetch;
    timeoutMs?: number;
    pollMs?: number;
}): Promise<string | null>;
export interface RemoteCdpPageTargetCleanupResult {
    readonly closed: number;
    readonly remaining: number;
    readonly replacementCreated: boolean;
    readonly skipped: boolean;
}
export declare function closeRemoteCdpPageTargets({ cdpUrl, fetchImpl, profileName, timeoutMs, pollMs, }: {
    cdpUrl: string;
    fetchImpl?: typeof fetch;
    profileName?: string;
    timeoutMs?: number;
    pollMs?: number;
}): Promise<RemoteCdpPageTargetCleanupResult>;
export declare function fetchPageTargetWsUrl({ port, fetchImpl, }: {
    port: number;
    fetchImpl?: typeof fetch;
}): Promise<string | null>;
/**
 * Acquire a browser context for connector use.
 *
 * Container policy:
 *   - Headless container acquisitions (`headless: true`) remain available as
 *     the advanced deployment-level escape hatch.
 *   - Core's headed local acquisitions proceed when its packaged runtime and
 *     managed Xvfb display are present.
 *   - Other headed container acquisitions fail closed with
 *     `HeadedBrowserUnavailableError` because there is no visible browser
 *     surface. Operators can use a local collector runtime instead — see
 *     `bin/collector-runner.ts`.
 *   - Operators who need to escape the gate (e.g., debugging a headed
 *     container browser locally with X11 forwarding) can set
 *     `PDPP_ALLOW_HEADED_CONTAINER_BROWSER=1`. The runtime emits a loud
 *     per-acquisition warning so the override is visible in logs.
 *   - The host-direct path is unaffected — without any container signal,
 *     the runtime uses `acquireIsolatedBrowser` against
 *     `PDPP_BROWSER_PROFILE_ROOT/<name>/` (default `~/.pdpp/profiles/<name>/`).
 */
export declare function acquireBrowserForConnector(options: AcquireIsolatedBrowserOptions): Promise<IsolatedBrowser>;
//# sourceMappingURL=browser-launch.d.ts.map