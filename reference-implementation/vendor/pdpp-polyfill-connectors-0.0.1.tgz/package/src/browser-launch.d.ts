import type { Browser, BrowserContext } from "playwright";
export declare const BROWSER_HEADLESS_ENV = "PDPP_BROWSER_HEADLESS";
/**
 * Env-var channel for a HAR-recording CLI to request HAR recording from
 * INSIDE the connector subprocess it spawns — mirrors
 * `subprocess-fetch-preloads.ts`'s clock-injection env var exactly: the
 * recorder CLI and the connector's own browser-acquisition call happen in
 * different OS processes (`spawn(process.execPath, ...)`), so a function
 * argument can't cross that boundary — `process.env` (set on the child's
 * `env` at spawn time) is the only channel available. Resolved in
 * `acquireBrowserForConnector` (the entry point every browser-driven
 * connector's subprocess actually calls — see `connector-runtime.ts`'s
 * `acquireBrowser`), not in every individual connector, so no connector
 * needs to know this capability exists.
 */
export declare const HAR_RECORD_PATH_ENV = "PDPP_SCENARIO_HAR_RECORD_PATH";
/**
 * Env-var channel to request a `storageState()` snapshot alongside the HAR
 * — see `storageStateRecording`'s doc comment. Same subprocess-boundary
 * rationale as `HAR_RECORD_PATH_ENV`.
 */
export declare const STORAGE_STATE_RECORD_PATH_ENV = "PDPP_SCENARIO_STORAGE_STATE_RECORD_PATH";
export interface IsolatedBrowser {
    browser: Browser | null;
    context: BrowserContext;
    /**
     * Present only when this context was launched with `harRecording` set
     * (see `AcquireIsolatedBrowserOptions.harRecording`). MUST be called
     * AFTER `release()` resolves — Playwright only flushes the HAR to disk
     * during context close, so calling this before `release()` would race
     * the flush and could report `flushed: false` for a capture that was
     * about to succeed. Absent entirely when `harRecording` was not
     * requested, so a caller that never asked for a HAR has no way to
     * mistakenly read a stale/undefined outcome as a real one.
     */
    harRecordingOutcome?: () => Promise<HarRecordingOutcome>;
    release: () => Promise<void>;
    /**
     * Present only when this context was launched with `storageStateRecording`
     * set. Same MUST-call-after-`release()` ordering rule as
     * `harRecordingOutcome` — `storageState()` itself is called from inside
     * `release()`, before `context.close()`, since Playwright cannot read
     * storage state from an already-closed context.
     */
    storageStateRecordingOutcome?: () => Promise<StorageStateRecordingOutcome>;
}
export interface AcquireIsolatedBrowserOptions {
    /**
     * Opt-in network-level HAR (HTTP Archive) capture for this browser
     * context. OFF by default and zero-cost when omitted: no `recordHar`
     * option is added to `baseLaunchOptions`, so an ordinary connector run's
     * launch options are byte-identical to before this field existed.
     *
     * When set, `path` becomes Playwright's `recordHar.path` — passed through
     * `baseLaunchOptions` at BOTH `launchPersistentContext` call sites (the
     * explicit-channel branch and the default-channel branch), so this option
     * covers every local-launch path the same way `streamingEnabled` does.
     * Does NOT apply to `acquireRemoteCdpBrowser` (n.eko-attached contexts):
     * `connectOverCDP` attaches to an ALREADY-launched remote context, so
     * there is no `launchPersistentContext` call to carry `recordHar` on that
     * path — recording a remote-CDP session's traffic is out of scope here.
     *
     * `content: "embed"` (inline base64/text in the HAR JSON, chosen over
     * Playwright's zip-friendly `"attach"`) is a deliberate choice: a replay
     * half needs a HAR whose response bodies are actually present to route
     * requests from (`context.routeFromHAR`) — `"omit"` would produce a HAR
     * that satisfies nothing downstream. A single embedded JSON file is also
     * the easiest shape for this module's own post-close redaction pass (see
     * `redactHarFileBestEffort`) to reason about: one file, one parse, no
     * companion resource directory to also scrub. The cost is size and secret
     * exposure inside `content.text` — mitigated by the redaction pass
     * stripping `Set-Cookie`/`Authorization`/etc. headers but NOT by touching
     * response bodies.
     *
     * RESIDUAL EXPOSURE: response/request BODIES are embedded verbatim.
     * Unlike the existing fetch-preload's structured per-field JSON body
     * capture (which this harness never applies to HAR — a HAR entry's body
     * is an opaque blob with unknown shape per provider), this driver cannot
     * safely redact arbitrary body content field-by-field. A HAR captured
     * this way is local-only territory, same as every other capture artifact
     * this package's recorders produce — never committed or shared without a
     * scrub pass.
     *
     * Known gap, verified unexercised as of this change: `recordHar` does
     * NOT capture WebSocket frames, and a page's native download flow can
     * bypass HAR capture entirely. Checked against the connector fleet
     * (2026-08-21): zero of the 45 connectors use WebSocket/EventSource/SSE,
     * and none drive a browser download. Both gaps are real limitations of
     * this driver, left unaddressed because nothing currently exercises them
     * — not because they were solved.
     */
    harRecording?: {
        path: string;
    };
    headless?: boolean;
    /**
     * Skip remote-CDP page-target cleanup before attach. Use only when the
     * connector intentionally preserves successful pages because the page itself
     * carries source auth state.
     */
    preserveRemotePagesOnAcquire?: boolean;
    profileName: string;
    /**
     * When set, the launcher does NOT spawn its own Chromium. Instead it
     * calls `patchright.chromium.connectOverCDP(remoteCdpUrl)` and returns
     * the FIRST existing context as the connector's context. Used for
     * connectors that need a real X server + WebRTC streaming (n.eko-hosted
     * Chromium) so the manual_action handoff goes back to the same browser
     * the connector was driving — not a separate headless Chrome launched
     * inside the reference container.
     *
     * The release function disconnects the Patchright client; it does NOT
     * close the remote browser. The neko container owns that lifecycle.
     *
     * When set, `streamingEnabled` is implied; we register the page-target
     * wsUrl for manual_action via the standard browser-handoff helper, but
     * the wsUrl points at the neko-hosted page through the cdp-proxy.py
     * URL the streaming companion already knows how to attach to.
     */
    remoteCdpUrl?: string;
    /**
     * Opt-in capture of this context's `storageState()` (cookies +
     * localStorage/origins) at release time, WRITTEN TO ITS OWN FILE — never
     * embedded in the HAR. Companion to `harRecording`, addressing a gap a
     * HAR alone cannot close: `launchPersistentContext` reuses a WARM
     * profile with existing session cookies, so replaying the HAR's captured
     * requests against a fresh/anonymous context hits the provider's own
     * login wall in the replaying page's JS and never reaches the recorded
     * request shapes at all. Recording the session alongside the HAR lets a
     * replay half seed a matching starting session.
     *
     * DELIBERATELY UNREDACTED, and this is a stated decision, not an
     * oversight: `storageState()`'s cookies ARE the live session — the value
     * of the session cookie is the credential that keeps the replaying page
     * logged in. Blanking it the way `harRecording`'s redaction pass blanks
     * HAR headers/cookies would produce a file that LOOKS like a safety
     * measure but actually just breaks the one thing this capture exists to
     * provide, without removing any real risk (the HAR's own cookie headers
     * are already redacted independently; this file is the one place a real,
     * usable session snapshot must exist for replay to be possible at all).
     * Treat a written storageState file as carrying live, unredacted
     * credentials — AT LEAST as sensitive as a raw capture's local-only
     * bodies, arguably more so (a session cookie is immediately, directly
     * usable by anyone who reads it; a HAR body needs the specific provider
     * context to be useful). Callers MUST NOT commit, share, or embed this
     * file's contents anywhere a HAR or capture JSON might otherwise be
     * shared after a scrub pass — there is no scrub pass that makes a live
     * session cookie safe to publish.
     */
    storageStateRecording?: {
        path: string;
    };
    /**
     * When true, the launcher launches Chromium in CDP-port mode
     * (`--remote-debugging-port=0` plus `--remote-debugging-address=127.0.0.1`), reads
     * the resolved random port out of `<userDataDir>/DevToolsActivePort`,
     * and publishes `PDPP_BROWSER_CDP_HOST` / `PDPP_BROWSER_CDP_PORT` to
     * `process.env` for the browser-binding-local handoff helper
     * (`browser-handoff.ts`) to compose per-interaction wsUrls at
     * `manual_action` emission time.
     *
     * The launcher itself does NOT register any streaming target — that
     * is interaction-scoped and owned by the binding code that emits the
     * manual_action. See
     * `openspec/changes/add-run-interaction-streaming-companion/`
     * `design-notes/interaction-scoped-target-resolution-2026-05-05.md`.
     *
     * Best-effort port publication: any failure (port not appearing in
     * `DevToolsActivePort`, etc.) logs a warning and lets the browser
     * launch succeed. The honest failure mode is "streaming unavailable
     * for this run; records still flow."
     *
     * Connectors that never need streaming MUST be unaffected — leave
     * this `false` or omit it.
     */
    streamingEnabled?: boolean;
}
/**
 * Mirrors `HarRecordingOutcome` for the storageState side — see
 * `storageStateRecording`'s doc comment for why this file is intentionally
 * unredacted and must be handled as live credentials, not a shareable
 * artifact.
 */
export interface StorageStateRecordingOutcome {
    flushed: boolean;
    path: string;
}
/**
 * Per-context-close, best-effort record of whether a requested HAR capture
 * actually reached disk. `acquireIsolatedBrowser`'s caller (via the
 * `harRecording` option) gets this back from an optional method on the
 * returned handle rather than from `release()`'s resolved value, so every
 * existing `release(): Promise<void>` caller keeps compiling unchanged —
 * this is a strictly additive read path, not a signature change to the
 * widely-used `IsolatedBrowser` interface.
 */
export interface HarRecordingOutcome {
    /**
     * True only when `context.close()` completed AND the HAR file was found
     * on disk afterward with nonzero size. A `false` here after a requested
     * `harRecording` option means exactly what it says: no trustworthy HAR
     * exists at `path` — a crash, a SIGKILL (e.g. a recorder's inactivity
     * watchdog), or any other non-graceful teardown before `context.close()`
     * runs leaves NO har file at all (Playwright buffers HAR content in
     * memory and only flushes it during context close — see
     * playwright-core's `HarRecorder.flush()`), never a silently truncated
     * one. Callers MUST check this before treating `path` as a real artifact
     * — never assume success just because `harRecording` was requested.
     */
    flushed: boolean;
    /** Absolute path the HAR was requested at (echoes `harRecording.path`). */
    path: string;
}
/**
 * Stable error code surfaced when a HEADED browser-backed connector is
 * attempted in a container/provider runtime that cannot show a visible
 * browser. The dashboard renders this as a deployment-config error
 * state pointing the operator at the local collector runner.
 */
export declare const HEADED_BROWSER_UNAVAILABLE_CODE = "headed_browser_unavailable";
/**
 * Failure surfaced when a HEADED browser-backed connector is requested
 * inside a container without a local collector runtime that can render
 * the browser. Carries a stable `code` so the dashboard can render the
 * actionable deployment-config error state.
 */
export declare class HeadedBrowserUnavailableError extends Error {
    readonly code: typeof HEADED_BROWSER_UNAVAILABLE_CODE;
    constructor(args: {
        message: string;
    });
}
/**
 * Pure decision helper for the in-container fail-closed gate. Exported
 * so tests can exercise the policy without launching Patchright (the
 * acquire path itself is hard to test without spinning up a real
 * browser).
 *
 * Headed-vs-headless interpretation MUST mirror the effective mode resolved by
 * `acquireBrowserForConnector`, which applies the deployment override when a
 * caller omits `headless`. The baseline is headed, so:
 *
 *   - `headless: true`  → headless (allowed in container)
 *   - `headless: false` → headed   (container gate requires managed display or escape hatch)
 *   - `headless: undefined` (caller omitted the field) → the deployment
 *     choice (`PDPP_BROWSER_HEADLESS=1` means headless; otherwise headed).
 *     A connector's browser config never supplies this field.
 *
 * Returns:
 *   - `{ kind: "fail_closed" }` when the effective request is HEADED,
 *     the runtime is in a container, and the escape hatch is not
 *     asserted. Caller MUST throw `HeadedBrowserUnavailableError`.
 *   - `{ kind: "warn_and_proceed" }` when the same conditions hold
 *     except `PDPP_ALLOW_HEADED_CONTAINER_BROWSER=1` is asserted.
 *     Caller SHOULD emit a per-acquisition stderr warning and proceed.
 *   - `{ kind: "proceed" }` otherwise.
 */
export type ContainerHeadedBrowserGate = {
    readonly kind: "fail_closed";
} | {
    readonly kind: "warn_and_proceed";
} | {
    readonly kind: "proceed";
};
export interface ContainerHeadedBrowserGateInputs {
    readonly escapeHatchEnabled: boolean;
    readonly headless: boolean | undefined;
    readonly inContainer: boolean;
    /**
     * Core's startup supervisor has installed the image-owned browser runtime
     * and waited for its managed Xvfb display. Omitted/false preserves the
     * fail-closed behavior for unrelated container runtimes.
     */
    readonly managedDisplayAvailable?: boolean;
    /**
     * When set, the launcher will NOT spawn a local headed Chromium — it
     * will attach to a remote CDP endpoint (e.g. a n.eko browser surface) which
     * already renders the browser visibly for the operator. In that case
     * the in-container fail-closed gate does not apply: there is no
     * invisible headed browser to fail closed against. Local headed
     * container launches (no remoteCdpUrl) still fail closed as before.
     */
    readonly remoteCdpUrl?: string;
}
/**
 * Resolve the deployment-owned local browser mode. Connector manifests do not
 * call this with an explicit value; the explicit argument remains available to
 * operator-side low-level callers as the existing headless escape hatch.
 */
export declare function resolveDeploymentBrowserHeadless(headless: boolean | undefined, env?: Record<string, string | undefined>): boolean;
export declare function decideContainerHeadedBrowserGate(inputs: ContainerHeadedBrowserGateInputs): ContainerHeadedBrowserGate;
/**
 * Stable error thrown by `failFastOnUnusableViewport` when a HEADED launch's
 * initial page reports a definitively-zero viewport — the observable
 * fingerprint of a display that is set but unusable (Chromium's GPU/
 * compositor init failed silently, so the launch API still returns a live
 * page, but it can never lay out content). Distinct from
 * `HeadedBrowserUnavailableError` (which fires BEFORE any launch attempt,
 * for the container policy gate) — this fires AFTER a launch that
 * "succeeded" by Playwright's own bookkeeping but is unusable in practice.
 */
export declare const UNUSABLE_VIEWPORT_CODE = "browser_viewport_unusable";
export declare class UnusableViewportError extends Error {
    readonly code: typeof UNUSABLE_VIEWPORT_CODE;
    constructor(args: {
        message: string;
    });
}
/**
 * Pure predicate: does this viewport reading indicate a definitively-zero
 * (unusable) display? Exported so the decision can be unit-tested without a
 * real Chromium — `failFastOnUnusableViewport` is not itself practical to
 * exercise headless-in-CI (a real headless launch has a real, non-zero
 * viewport by construction; reproducing a broken-display headed launch
 * needs an actual misconfigured X server).
 *
 * Deliberately conservative: only `0` (not merely small, not undefined/NaN)
 * on BOTH dimensions counts as unusable. `viewportSize()` returning `null`
 * alone is not enough — `viewport: null` (this launcher's own baseline
 * option, matching the window's native size) is Playwright's DOCUMENTED
 * normal behavior for using the OS window size instead of an emulated one,
 * so a null `viewportSize()` is the common case for a perfectly healthy
 * headed launch and must never trip this check by itself. A real broken
 * display must show up as an actual zero measurement from the page itself
 * (`window.innerWidth`/`innerHeight`), not merely the absence of an
 * explicit emulated viewport size.
 */
export declare function isDefinitivelyZeroViewport(measurement: {
    innerHeight: number | undefined;
    innerWidth: number | undefined;
}): boolean;
export declare function configuredBrowserChannel(env?: Record<string, string | undefined>): string | undefined;
/**
 * Recognise the transient CDP-attach race that fails `connectOverCDP`
 * against a live n.eko Chromium with:
 *
 *   Protocol error (Network.setCacheDisabled): Internal server error, session closed.
 *       at ... crNetworkManager.setRequestInterception
 *
 * Root cause (verified against patchright-core 1.61.1 internals):
 * Patchright's `CRPage` constructor eagerly calls
 * `this._networkManager.setRequestInterception(true)` so its stealth
 * Fetch-domain hooks are always active (`server/chromium/crPage.js` line 80).
 * Stock Playwright does NOT — it defers to a conditional
 * `updateRequestInterception()`. Critically, that constructor call is FLOATED:
 * no `await`, no `.catch`. Patchright's `setRequestInterception` ends with a
 * patchright-only
 * `_forEachSession(info => info.session.send("Network.setCacheDisabled", …))`
 * (`server/chromium/crNetworkManager.js`). When `connectOverCDP` auto-attaches
 * (`Target.setAutoAttach`) to every existing target, `_onAttachedToTarget`
 * builds a `CRPage` per target — including the short-lived `about:blank` target
 * n.eko opens via `/json/new?about:blank` and immediately tears down via
 * `/json/close`. If that target's session disposes while the send is in flight,
 * the in-flight callback is rejected with `Internal server error, session
 * closed.` (`crConnection.js` `dispose()`). The MAIN-frame branch of
 * `_forEachSession` has no `.catch` guard (only non-main sessions swallow
 * `isSessionClosedError`).
 *
 * Because the offending `setRequestInterception(true)` is floated and
 * `connectOverCDP` only awaits `_waitForAllPagesToBeInitialized()` (NOT the
 * interception promise), `connectOverCDP` RESOLVES successfully and the
 * rejection escapes the entire connect promise chain as a Node UNHANDLED
 * REJECTION (`node:internal/process/promises`), terminating the process a tick
 * or two after attach. This is why a `try/catch` around `connectOverCDP` (v1)
 * never observed it. The catch boundary now lives in
 * `runCdpAttemptWithRaceGuard`, which intercepts the unhandled rejection.
 *
 * The condition is inherently transient: the offending target is on its way
 * out. A bounded retry a moment later — once n.eko's transient target has
 * disposed and only the stable page target remains — attaches cleanly.
 *
 * We deliberately do NOT switch the remote-attach client to stock Playwright:
 * patchright's `Runtime.enable` suppression and isolated-world hiding are
 * CLIENT-driven stealth (sent over CDP by the driving process, not baked into
 * the launched browser). A stock client attaching to the same browser would
 * leak the canonical CDP `Runtime.enable` automation signal on every page —
 * a permanent stealth regression on a bot-hostile target like Amazon, traded
 * for a transient startup race. Retry keeps full patchright stealth.
 *
 * Matched narrowly on the CDP method + the session-closed phrase so unrelated
 * protocol errors (auth, bad URL, real crash) still fail fast.
 */
export declare function isCdpAttachSessionRaceError(err: unknown): boolean;
/**
 * Stable, machine-actionable code carried on the error thrown by
 * `connectOverCdpWithRetry` when it exhausts every bounded attempt of the
 * narrow attach-session race (`isCdpAttachSessionRaceError`). This is the
 * ONLY source boundary that knows the retry budget was exhausted for THIS
 * specific race — not a rate limit, not a credential failure, not a real
 * browser crash. Downstream layers (the connector runtime's terminal error,
 * the reference runtime's connector_error.code, the managed-surface
 * lifecycle) MUST key off this typed code and MUST NOT re-derive the same
 * disposition by re-parsing error message text.
 */
export declare const CDP_ATTACH_SESSION_RACE_EXHAUSTED_CODE = "browser_surface_attach_exhausted";
/**
 * Error subclass thrown when `connectOverCdpWithRetry` gives up after
 * exhausting `maxAttempts` on the narrow attach-session race. Carries the
 * stable `code` so callers can pattern-match on a typed property instead of
 * the underlying race error's message text (which remains available via
 * `cause` for logs/diagnostics only).
 */
export declare class CdpAttachSessionRaceExhaustedError extends Error {
    readonly code: typeof CDP_ATTACH_SESSION_RACE_EXHAUSTED_CODE;
    constructor(lastError: unknown);
}
/**
 * Minimal port of the `process` unhandled-rejection surface the attempt guard
 * needs. Injected so the guard can be unit-tested without touching the real
 * process listeners (the test drives a fake emitter directly).
 */
export interface UnhandledRejectionHost {
    off: (event: "unhandledRejection", listener: (reason: unknown) => void) => void;
    on: (event: "unhandledRejection", listener: (reason: unknown) => void) => void;
}
/**
 * Run ONE remote-CDP attach attempt with a scoped `unhandledRejection` guard.
 *
 * Why this exists (root cause v2): the production failure is NOT the
 * `connectOverCDP` promise rejecting. `connectOverCDP` RESOLVES — it returns a
 * live `Browser`. Patchright's `CRPage` constructor then fires
 * `this._networkManager.setRequestInterception(true)` with NO `await` and NO
 * `.catch` (`server/chromium/crPage.js`). That floated promise runs
 * `_forEachSession(… "Network.setCacheDisabled" …)`, whose MAIN-frame branch has
 * no session-closed guard. When n.eko's transient `about:blank` target disposes
 * mid-send, the floated promise rejects, and because nobody is awaiting it the
 * rejection escapes the entire `connectOverCDP` promise chain as a Node
 * UNHANDLED REJECTION (`node:internal/process/promises`), terminating the
 * process. A `try/catch` around `connectOverCDP` (v1) can never see it.
 *
 * The fix installs a temporary `process.on("unhandledRejection")` listener and
 * races the attach attempt against that signal. If the race lands while
 * `connect()` is still pending, the attempt rejects immediately instead of
 * waiting for Patchright's 30s timeout. If `connect()` resolves first, the
 * guard stays open for a short settle window because the floated rejection can
 * land on a later tick. Either way, a matching unhandled rejection becomes a
 * retryable rejection of this attempt; the caller's bounded retry then
 * re-attaches once n.eko's transient target is gone.
 *
 * Safety rails:
 *   - The listener is ALWAYS removed when the attempt settles (success,
 *     retryable race, or fail-fast), via the `finally` block. We never leave a
 *     global listener installed across attempts.
 *   - Only the narrow race signature is consumed. Any OTHER unhandled rejection
 *     is re-thrown synchronously from the listener after removing ourselves, so
 *     Node's default crash-on-unhandled-rejection behavior is preserved for
 *     unrelated bugs. We do not become a process-wide rejection sink.
 *   - If the race rejection arrives after `connect()` already returned a live
 *     browser, or `connect()` resolves after the guard has already rejected,
 *     the injected `disconnect` is invoked best-effort so we don't leak a CDP
 *     client.
 *
 * `host`, `setTimeoutFn`, and `clearTimeoutFn` are injected for tests.
 */
export declare function runCdpAttemptWithRaceGuard<TBrowser>({ connect, disconnect, settleMs, host, setTimeoutFn, clearTimeoutFn, }: {
    connect: () => Promise<TBrowser>;
    disconnect?: (browser: TBrowser) => Promise<void> | void;
    settleMs?: number;
    host?: UnhandledRejectionHost;
    setTimeoutFn?: typeof setTimeout;
    clearTimeoutFn?: typeof clearTimeout;
}): Promise<TBrowser>;
/**
 * Attach to a remote Chromium with a bounded retry around the transient
 * `connectOverCDP` session-closed race (see `isCdpAttachSessionRaceError`).
 *
 * Each attempt runs inside `runCdpAttemptWithRaceGuard` so the failure can be
 * caught whether it surfaces as a rejected `connect` promise OR as a Node
 * unhandled rejection from patchright's floated `setRequestInterception(true)`
 * (the v2 root cause — v1 only handled the former). Only the race error is
 * retried; every other failure (auth, unreachable endpoint, real browser crash)
 * is rethrown immediately so we never mask a genuine attach failure behind a
 * retry budget.
 *
 * `connect`, `disconnect`, `sleep`, and `runAttempt` are injected so the retry
 * policy can be unit-tested without a live browser.
 */
export declare function connectOverCdpWithRetry<TBrowser>({ connect, disconnect, profileName, redactedUrl, maxAttempts, retryDelayMs, sleep, runAttempt, }: {
    connect: () => Promise<TBrowser>;
    disconnect?: (browser: TBrowser) => Promise<void> | void;
    profileName: string;
    redactedUrl: string;
    maxAttempts?: number;
    retryDelayMs?: number;
    sleep?: (ms: number) => Promise<void>;
    runAttempt?: typeof runCdpAttemptWithRaceGuard;
}): Promise<TBrowser>;
/**
 * Attach to a remote Chromium via the standard DevTools Protocol over
 * WebSocket. Used when the connector should run inside a browser hosted
 * by a different container (e.g. n.eko) so the manual_action streaming
 * handoff lands on the exact same browser process.
 *
 * The returned context is the FIRST existing context on the remote
 * browser — typically the only context, since neko's Chromium runs with
 * a single persistent user-data-dir. The release function disconnects
 * the Patchright client but leaves the remote browser running; lifecycle
 * is owned by whoever launched it.
 *
 * Pages opened by the connector are NOT cleaned up automatically — the
 * connector should close any pages it opened in its own cleanup. This
 * matches `launchPersistentContext` semantics where the context outlives
 * individual pages.
 *
 * The attach itself is wrapped in `connectOverCdpWithRetry` to ride out the
 * transient session-closed race n.eko's transient targets trigger during
 * Patchright's auto-attach. That race does NOT reject `connectOverCDP`; it
 * escapes as a Node unhandled rejection from patchright's floated
 * `setRequestInterception(true)`, so each attempt runs under a scoped
 * `unhandledRejection` guard. See `runCdpAttemptWithRaceGuard` and
 * `isCdpAttachSessionRaceError`.
 */
export declare function shouldCleanRemoteCdpPageTargets({ preserveRemotePagesOnAcquire, }: Pick<AcquireIsolatedBrowserOptions, "preserveRemotePagesOnAcquire">): boolean;
interface HarNameValue {
    name: string;
    value: string;
}
interface HarPostDataParam {
    name: string;
    value?: string;
}
interface HarRequestOrResponse {
    cookies?: HarNameValue[];
    headers?: HarNameValue[];
    postData?: {
        mimeType?: string;
        params?: HarPostDataParam[];
        text?: string;
    };
}
interface HarEntry {
    request?: HarRequestOrResponse;
    response?: HarRequestOrResponse;
}
interface HarDocument {
    log?: {
        entries?: HarEntry[];
    };
}
/** Pure redaction of one parsed HAR document — exported so this exact
 *  transform is independently unit-testable against a synthetic HAR
 *  without touching the filesystem. See the module-scope "HAR secret-
 *  hygiene pass" comment above for the full posture and what is
 *  deliberately NOT redacted (response/request body content). */
export declare function redactHarDocument(har: HarDocument): HarDocument;
/**
 * Reads the HAR JSON at `path`, applies `redactHarDocument`, and writes it
 * back 0600 — best-effort: a missing file (the honest "context.close()
 * never ran / HAR was never flushed" case — see `HarRecordingOutcome`'s doc
 * comment) or an unparseable file logs a warning and returns without
 * throwing, so a redaction-pass failure never turns into an unhandled
 * rejection that crashes the caller's `release()`. The mode is set
 * EXPLICITLY (not left to Playwright's own create-time umask-dependent
 * default) — this package never trusts umask for a file that may hold real
 * captured data.
 *
 * EXPORTED so test fixtures that simulate a browser-driven connector
 * WITHOUT a real Chromium (this package's convention — see
 * `browser-launch.test.ts`'s module comment) can call the SAME redaction
 * `acquireIsolatedBrowser`'s `release()` runs, instead of a test double
 * re-implementing (and potentially drifting from) this logic.
 */
export declare function redactHarFileBestEffort(path: string): Promise<void>;
/**
 * Reports whether a file this module was supposed to write actually reached
 * disk, nonempty — shared by `HarRecordingOutcome` and
 * `StorageStateRecordingOutcome` (both are the same "did the expected
 * side-effect file land" question). Checks for a nonempty file rather than
 * mere existence: a zero-byte file at this path is not a real capture (a
 * write raced with a read, or a placeholder was created some other way) —
 * treated the same as "does not exist" rather than reported as a false
 * success.
 *
 * EXPORTED so a recorder CLI can call this directly: HAR/storageState
 * recording is requested via an env var that crosses into a SEPARATE OS
 * process (the spawned connector subprocess), so the CLI has no live
 * `IsolatedBrowser` handle to call `harRecordingOutcome()`/
 * `storageStateRecordingOutcome()` on — it must independently re-check the
 * same path after the subprocess exits, using the identical honesty rule
 * (nonempty file, not mere existence) rather than a second, potentially
 * divergent implementation.
 */
export declare function fileFlushOutcome(path: string): Promise<{
    flushed: boolean;
    path: string;
}>;
/**
 * Launch an isolated per-connection browser context with its own profile dir.
 * The connector runtime scopes the profile name with the stable connector
 * instance ID when the reference runtime supplies one.
 */
export declare function acquireIsolatedBrowser({ profileName, headless, streamingEnabled, remoteCdpUrl, preserveRemotePagesOnAcquire, harRecording, storageStateRecording, }: AcquireIsolatedBrowserOptions): Promise<IsolatedBrowser>;
/**
 * Read Chromium's `DevToolsActivePort` (written to `<userDataDir>` when
 * `--remote-debugging-port=0` is set), then GET `http://127.0.0.1:PORT/json`
 * and pick the first `page` target's `webSocketDebuggerUrl`.
 *
 * Returns `null` when:
 *   - the port file isn't available within the poll window, or
 *   - the `/json` endpoint isn't reachable, or
 *   - no `type === "page"` target is present.
 *
 * Caller treats `null` as "skip registration, log + continue."
 *
 * Why DevToolsActivePort: Chromium writes this file as part of
 * remote-debugging startup (it's how `chrome --remote-debugging-port=0`
 * communicates the chosen random port to the launching process). It is the
 * canonical local-only handshake for "what port did Chromium pick?" and
 * does not require parsing Chromium stderr (which Playwright captures and
 * does not re-expose on launchPersistentContext).
 *
 * `fetchImpl` is injectable so tests can exercise the `/json` parsing
 * branch without a real Chromium.
 */
export declare function resolvePageTargetWsUrl({ userDataDir, fetchImpl, timeoutMs, pollMs, }: {
    userDataDir: string;
    fetchImpl?: typeof fetch;
    timeoutMs?: number;
    pollMs?: number;
}): Promise<string | null>;
export interface RemoteCdpPageTargetCleanupResult {
    readonly closed: number;
    readonly remaining: number;
    readonly replacementCreated: boolean;
    readonly skipped: boolean;
}
export declare function closeRemoteCdpPageTargets({ cdpUrl, fetchImpl, profileName, timeoutMs, pollMs, }: {
    cdpUrl: string;
    fetchImpl?: typeof fetch;
    profileName?: string;
    timeoutMs?: number;
    pollMs?: number;
}): Promise<RemoteCdpPageTargetCleanupResult>;
export declare function fetchPageTargetWsUrl({ port, fetchImpl, }: {
    port: number;
    fetchImpl?: typeof fetch;
}): Promise<string | null>;
/**
 * Acquire a browser context for connector use.
 *
 * Container policy:
 *   - Headless container acquisitions (`headless: true`) remain available as
 *     the advanced deployment-level escape hatch.
 *   - Core's headed local acquisitions proceed when its packaged runtime and
 *     managed Xvfb display are present.
 *   - Other headed container acquisitions fail closed with
 *     `HeadedBrowserUnavailableError` because there is no visible browser
 *     surface. Operators can use a local collector runtime instead — see
 *     `bin/collector-runner.ts`.
 *   - Operators who need to escape the gate (e.g., debugging a headed
 *     container browser locally with X11 forwarding) can set
 *     `PDPP_ALLOW_HEADED_CONTAINER_BROWSER=1`. The runtime emits a loud
 *     per-acquisition warning so the override is visible in logs.
 *   - The host-direct path is unaffected — without any container signal,
 *     the runtime uses `acquireIsolatedBrowser` against
 *     `PDPP_BROWSER_PROFILE_ROOT/<name>/` (default `~/.pdpp/profiles/<name>/`).
 */
export declare function acquireBrowserForConnector(options: AcquireIsolatedBrowserOptions): Promise<IsolatedBrowser>;
export {};
//# sourceMappingURL=browser-launch.d.ts.map