/**
 * Page-level download queue for multi-download runs.
 *
 * WHY: Chromium's headed download-bubble and the CDP-based
 * `Playwright.download` interception compete for ownership of each stream
 * (microsoft/playwright#40158). We already mitigate the race with
 * `--disable-features=DownloadBubble` on the daemon's launch args — but
 * we also want a listener surface that tolerates multiple downloads
 * fired back-to-back without needing one `waitForEvent` per click.
 *
 * Verified 2026-04-21: `context.on('download')` is NOT dispatched when
 * attached over CDP to
 *   a freshly-created BrowserContext (`browser.newContext(...)`). Events
 *   reliably reach page-level listeners only.
 * - `page.on('download', ...)` DOES fire for every download from that page,
 *   in order, across multiple sequential clicks.
 *
 * So the queue is page-scoped. Callers must pass the page they're clicking
 * on. If they navigate to a new page, they need a new queue (because the
 * listener is wired to the old one).
 *
 * Usage:
 *   const q = attachDownloadQueue(page);
 *   await q.ready();                   // wait for listener setup
 *   await clickSomethingThatDownloads();
 *   const dl = await q.waitForNextDownload({ timeoutMs: 180_000 });
 *   q.detach();
 *
 * The queue preserves event-delivery order.
 */
import type { Download, Page } from "playwright";
export interface DownloadQueue {
    detach: () => void;
    pendingCount: () => number;
    waitForNextDownload: (opts?: {
        timeoutMs?: number;
    }) => Promise<Download>;
}
export declare function attachDownloadQueue(target: Page): DownloadQueue;
//# sourceMappingURL=download-queue.d.ts.map