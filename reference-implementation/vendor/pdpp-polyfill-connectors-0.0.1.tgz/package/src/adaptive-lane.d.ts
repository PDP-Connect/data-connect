export type AdaptiveLaneOutcomeKind = "ok" | "retryable" | "rate_limited" | "terminal";
export type AdaptiveLanePressureKind = "rate_limited" | "transient_error";
export interface AdaptiveLanePressure {
    /**
     * Set when the reporting task has *already* slept `delayMs` itself before
     * reporting (e.g. a per-request retry loop that sleeps and then succeeds on
     * a later attempt). In that case the lane still reduces concurrency and emits
     * the pressure event, but does NOT mirror the same wait into the next launch
     * cooldown — that would double-pay the backoff the request already absorbed.
     *
     * Leave unset (the default) when the next launch genuinely still owes the
     * wait, i.e. the reporting task observed pressure without sleeping for it.
     */
    absorbedByRequestWait?: boolean;
    delayMs?: number;
    kind: AdaptiveLanePressureKind;
    retryAfterMs?: number;
}
export interface AdaptiveLaneOutcome {
    kind: AdaptiveLaneOutcomeKind;
    reason?: string;
    retryAfterMs?: number;
}
export interface AdaptiveLaneSnapshot {
    activeCount: number;
    concurrency: number;
    maxConcurrency: number;
    minConcurrency: number;
    name: string;
    pendingCount: number;
    queueSize: number;
}
export interface AdaptiveLaneEvent extends AdaptiveLaneSnapshot {
    attempt?: number;
    delayMs?: number;
    errorName?: string;
    outcome?: AdaptiveLaneOutcomeKind;
    reason?: string;
    retryAfterMs?: number;
    type: "queued" | "started" | "completed" | "retry_scheduled" | "cooldown" | "concurrency_decreased" | "concurrency_increased" | "cancelled" | "queue_rejected";
}
export interface AdaptiveLaneRunContext {
    attempt: number;
    reportPressure: (pressure: AdaptiveLanePressure) => Promise<void>;
    signal?: AbortSignal;
}
export interface AdaptiveLaneRunOptions {
    onBeforeStart?: () => void;
    onFailure?: (error: unknown) => void;
    signal?: AbortSignal;
}
export interface AdaptiveLaneOptions<T> {
    attemptTimeoutMs?: number;
    classifyOutcome: (input: {
        error?: unknown;
        result?: T;
    }) => AdaptiveLaneOutcome;
    emitProgress?: (event: AdaptiveLaneEvent) => void | Promise<void>;
    emitTelemetry?: (event: AdaptiveLaneEvent) => void | Promise<void>;
    initialConcurrency: number;
    /**
     * Optional pre-flight delay signal folded into the lane's single launch wait.
     * Called once per launch; the launch waits `max(launchDelay, cooldown,
     * launchDelayHint())`, NOT the sum — so a paced signal (e.g. GCRA
     * `pacingDelayHint()`) influences send velocity through the ONE governor
     * instead of adding a second pre-flight `await`. This is the converged
     * single-gate composition: the lane is the sole send governor; the hint is a
     * signal input. Absent → the lane uses only its own launch delay/cooldown
     * (unchanged).
     */
    launchDelayHint?: () => number;
    maxAttempts?: number;
    maxConcurrency: number;
    maxDelayMs: number;
    maxQueueSize: number;
    minConcurrency: number;
    minDelayMs: number;
    name: string;
    pressureMaxDelayMs?: number;
    pressureMinDelayMs?: number;
    random?: () => number;
    sleep?: (ms: number) => void | Promise<void>;
    successWindow?: number;
}
export interface AdaptiveLane<T> {
    cancel: (reason?: string) => void;
    readonly name: string;
    run: (task: (context: AdaptiveLaneRunContext) => T | Promise<T>, options?: AdaptiveLaneRunOptions) => Promise<T>;
    runAll: <I>(items: readonly I[], task: (item: I, context: AdaptiveLaneRunContext) => T | Promise<T>, options?: AdaptiveLaneRunOptions) => Promise<T[]>;
    snapshot: () => AdaptiveLaneSnapshot;
}
export declare class AdaptiveLaneQueueFullError extends Error {
    constructor(name: string, maxQueueSize: number);
}
export declare class AdaptiveLaneCancelledError extends Error {
    constructor(name: string, reason?: string);
}
export declare class AdaptiveLaneAttemptTimeoutError extends Error {
    readonly attempt: number;
    constructor(name: string, attempt: number, timeoutMs: number);
}
export declare function currentAdaptiveLaneRunContext(): AdaptiveLaneRunContext | undefined;
export declare function createAdaptiveLane<T>(options: AdaptiveLaneOptions<T>): AdaptiveLane<T>;
//# sourceMappingURL=adaptive-lane.d.ts.map