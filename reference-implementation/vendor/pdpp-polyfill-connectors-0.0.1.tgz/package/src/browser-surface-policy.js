// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
const BROWSER_SURFACE_POLICY_REGISTRY = {
    // ChatGPT's authenticated provider API session is held in the live browser
    // process, not durable browser storage. It preserves both pages and retains
    // its surface process; true process loss remains an owner browser-session
    // repair condition rather than a silent auth loss.
    chatgpt: {
        preservePageOnSuccess: true,
        preservePageOnFailure: true,
        retainSurfaceProcess: true,
    },
};
/**
 * Returns the browser-surface policy for a connector runtime name, or null when
 * the connector declares none (default cleanup semantics, no process retention).
 */
export function browserSurfacePolicyFor(connectorName) {
    if (typeof connectorName !== "string" || !connectorName) {
        return null;
    }
    return BROWSER_SURFACE_POLICY_REGISTRY[connectorName] ?? null;
}
/**
 * The `BrowserConfig` page-preservation fields for a connector, ready to spread
 * into `runConnector({ browser: { ...browserConfigPreservationFor(name), ... } })`.
 * Empty when the connector declares no policy.
 */
export function browserConfigPreservationFor(connectorName) {
    const policy = browserSurfacePolicyFor(connectorName);
    if (!policy) {
        return {};
    }
    return {
        preservePageOnSuccess: policy.preservePageOnSuccess,
        preservePageOnFailure: policy.preservePageOnFailure,
    };
}
/**
 * Whether the connector's managed surface process must be retained across routine
 * idle/capacity reap. Consumed by the reference implementation's lease caller.
 */
export function connectorRetainsSurfaceProcess(connectorName) {
    return browserSurfacePolicyFor(connectorName)?.retainSurfaceProcess === true;
}
export { BROWSER_SURFACE_POLICY_REGISTRY };
