import type { Page } from "playwright";
import type { InteractionRequest, InteractionResponse } from "./connector-runtime.ts";
import type { CaptureSession } from "./fixture-capture.ts";
import { type StreamingTargetRegistrationHooks } from "./streaming-target-registration.ts";
export interface ResolveWsUrlOptions {
    readonly host: string;
    readonly port: number;
}
/**
 * Resolve the CDP page-target webSocketDebuggerUrl for the EXACT `Page`
 * passed in. Distinguishes pages by Playwright object identity, not by
 * URL/title (which can collide on `about:blank` or duplicate tabs).
 * Stable across navigations within the same page.
 *
 * Throws when the page is closed/detached (Playwright surfaces an error
 * along the lines of "browserContext.newCDPSession: page: no object with
 * guid …"). Callers in this module catch and treat as "skip registration".
 */
export declare function resolveWsUrlForExactPage(page: Page, opts: ResolveWsUrlOptions): Promise<string>;
declare const BROWSER_CDP_HOST_ENV = "PDPP_BROWSER_CDP_HOST";
declare const BROWSER_CDP_PORT_ENV = "PDPP_BROWSER_CDP_PORT";
declare const BROWSER_SURFACE_ID_ENV = "PDPP_BROWSER_SURFACE_ID";
declare const BROWSER_SURFACE_LEASE_ID_ENV = "PDPP_BROWSER_SURFACE_LEASE_ID";
declare const BROWSER_SURFACE_PROFILE_KEY_ENV = "PDPP_BROWSER_SURFACE_PROFILE_KEY";
declare const BROWSER_SURFACE_REQUIRED_ENV = "PDPP_BROWSER_SURFACE_REQUIRED";
declare const BROWSER_SURFACE_REMOTE_CDP_URL_ENV = "PDPP_BROWSER_SURFACE_REMOTE_CDP_URL";
declare const BROWSER_SURFACE_STREAM_BASE_URL_ENV = "PDPP_BROWSER_SURFACE_STREAM_BASE_URL";
export type ManualActionReason = "login" | "2fa" | "captcha" | "oauth_popup" | "manual_action";
export interface PrepareBrowserInteractionTargetArgs {
    /**
     * Test/integration seam. Defaults to `process.env`. The launcher mutates
     * `process.env` directly after a successful patchright launch, so the
     * default is the right thing in production.
     */
    readonly env?: NodeJS.ProcessEnv;
    readonly interactionId?: string;
    readonly page: Page;
    readonly reason?: ManualActionReason;
    /**
     * Test seam. Defaults to `resolveStreamingRegistrationFromEnv`, which
     * reads `PDPP_RUN_ID` + `PDPP_REFERENCE_BASE_URL` + a registration token
     * from env and returns a real client. Tests inject a fake to assert the
     * register payload without spinning up a server.
     */
    readonly resolveStreamingRegistration?: (env?: NodeJS.ProcessEnv) => Promise<StreamingTargetRegistrationHooks | undefined>;
    /**
     * Test seam. Defaults to `resolveWsUrlForExactPage`. Tests inject a fake
     * so the registration payload can be asserted without a real CDP session.
     */
    readonly resolveWsUrl?: (page: Page, opts: ResolveWsUrlOptions) => Promise<string>;
}
export type PrepareManualActionArgs = PrepareBrowserInteractionTargetArgs;
export interface PrepareBrowserInteractionTargetResult {
    /** Generated interactionId; the connector then includes this in its INTERACTION envelope. */
    readonly interactionId: string;
    /**
     * `true` if registration succeeded with the reference server. `false`
     * means streaming will fail closed for this interaction — the connector
     * can still emit it, the operator just won't have a working browser
     * stream. The honest failure mode.
     */
    readonly registered: boolean;
}
export type PrepareManualActionResult = PrepareBrowserInteractionTargetResult;
/**
 * Bound `work` by a local deadline. Resolves with `work`'s value when it wins,
 * or with `DEADLINE_TIMEOUT` (and runs `onTimeout`) when the deadline wins.
 * Never rejects on timeout. The timer is cleared the moment `work` settles.
 *
 * This exists for the session-establishment hang case: against a wedged
 * renderer, CDP-backed reads such as `page.title()` can hang indefinitely
 * with no per-call timeout. Racing them against a deadline keeps the
 * manual-action handoff bounded so the INTERACTION still reaches the owner.
 */
export declare const DEADLINE_TIMEOUT: unique symbol;
export declare function withDeadline<T>(work: Promise<T>, ms: number, onTimeout?: () => void): Promise<T | typeof DEADLINE_TIMEOUT>;
/**
 * Prepare a browser handoff for an interaction tied to the current page.
 *
 * Generates or accepts an interactionId, resolves the CDP page-target wsUrl
 * for the exact `Page`, and registers `(runId, interactionId) -> wsUrl` with
 * the reference server's run-target registry. Returns the interactionId so the
 * caller can include it as the request_id on its INTERACTION envelope.
 *
 * Best-effort by design: if the env isn't wired up for streaming, if the
 * page is closed mid-resolve, or if registration fails over the network,
 * the helper returns `{ registered: false }` rather than throwing. The
 * connector run continues; only streaming for that specific interaction
 * is unavailable.
 */
export declare function prepareBrowserInteractionTarget(args: PrepareBrowserInteractionTargetArgs): Promise<PrepareBrowserInteractionTargetResult>;
export declare function prepareManualAction(args: PrepareManualActionArgs): Promise<PrepareManualActionResult>;
/**
 * Remove the interaction-scoped target after its owner interaction reaches a
 * terminal state. The helper deliberately resolves the same run-scoped
 * registration client as preparation; callers never handle a registry URL,
 * CDP endpoint, or bearer token directly.
 *
 * Cleanup is best-effort. The reference server also removes every target for
 * a terminal run, so a connector killed between registration and this call
 * cannot leave an indefinitely controllable page behind.
 */
export declare function unregisterBrowserInteractionTarget(args: {
    readonly env?: NodeJS.ProcessEnv;
    readonly interactionId: string;
    readonly resolveStreamingRegistration?: (env?: NodeJS.ProcessEnv) => Promise<StreamingTargetRegistrationHooks | undefined>;
}): Promise<boolean>;
export interface ManualActionArgs extends PrepareManualActionArgs {
    /** Optional fixture capture session; when enabled, captures this exact page before notifying the operator. */
    readonly capture?: CaptureSession | null;
    /** Human-facing prompt the operator sees in the streaming companion / interaction surface. */
    readonly message: string;
    /** Optional schema for the response payload — mirrors INTERACTION.schema. */
    readonly schema?: Record<string, unknown>;
    /** Optional timeout passthrough — mirrors INTERACTION.timeout_seconds. */
    readonly timeoutSeconds?: number;
}
export type SendInteraction = (req: InteractionRequest) => Promise<InteractionResponse>;
/**
 * Convenience wrapper for the manual-action handoff. Prepares the streaming
 * target (so the operator can attach), then emits a `manual_action` INTERACTION
 * envelope through the connector runtime's `sendInteraction` and returns its
 * response.
 *
 * Connector usage:
 *
 *   await manualAction(
 *     { page, message: "Solve the captcha", reason: "captcha" },
 *     sendInteraction
 *   );
 *
 * The two-arg shape (args + sendInteraction) keeps the helper composable
 * without leaking the runtime's emit machinery into `args` (which would
 * make `args` impossible to construct in tests that don't have a runtime).
 */
export declare function manualAction(args: ManualActionArgs, sendInteraction: SendInteraction): Promise<InteractionResponse>;
/**
 * Hand the current browser page to the owner for sign-in, then let the
 * connector prove whether the session is live. The owner response is only a
 * signal to re-probe; site-specific session evidence stays with the connector.
 */
export interface ManualBrowserLoginArgs<Result> {
    readonly capture?: CaptureSession | null;
    readonly env?: NodeJS.ProcessEnv;
    readonly message: string;
    readonly page: Page;
    readonly probe: () => Promise<Result>;
    readonly reason?: ManualActionReason;
    readonly sendInteraction: SendInteraction;
    readonly timeoutSeconds?: number;
}
export declare function manualBrowserLogin<Result>({ capture, env, message, page, probe, reason, sendInteraction, timeoutSeconds, }: ManualBrowserLoginArgs<Result>): Promise<Result>;
export { BROWSER_CDP_HOST_ENV, BROWSER_CDP_PORT_ENV, BROWSER_SURFACE_ID_ENV, BROWSER_SURFACE_LEASE_ID_ENV, BROWSER_SURFACE_PROFILE_KEY_ENV, BROWSER_SURFACE_REMOTE_CDP_URL_ENV, BROWSER_SURFACE_REQUIRED_ENV, BROWSER_SURFACE_STREAM_BASE_URL_ENV, };
//# sourceMappingURL=browser-handoff.d.ts.map