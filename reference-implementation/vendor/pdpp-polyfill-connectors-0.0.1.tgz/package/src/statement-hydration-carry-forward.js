// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
// Carry-forward of prior hydrated statement PDF pointers across runs.
//
// Both statement connectors (chase, usaa) emit one `statements` record per
// index row. On a successful PDF download the body carries
// `document_url`/`pdf_path`/`pdf_sha256`; on a failed download they fall back
// to an all-null index-only body. The three hydrated fields are
// content-addressed (the path embeds the sha256 prefix; the bytes never move)
// and the statement identity is immutable, so the only thing that makes a
// previously-hydrated statement re-version is a hydration-availability flip:
//
//   run A: hydrate  -> {document_url: U, pdf_path: P, pdf_sha256: S}  (version 1)
//   run B: fail     -> {null, null, null}                            (version 2)  ← flap
//   run C: hydrate  -> {U, P, S}                                     (version 3)  ← flap-back
//
// Versions 2 and 3 are not real history: the PDF at path P still exists after
// run B; run B merely failed to re-fetch it, and the per-run `SKIP_RESULT`
// already records that failure honestly. The per-statement fingerprint cursor
// excludes only `fetched_at`, so a `value -> null` move on `pdf_path` is a
// genuine fingerprint change it must NOT collapse — a blanket exclusion would
// also swallow the legitimate `null -> value` first hydration. The flap can
// only be removed at the emit layer, by not producing it: on a hydration
// failure for a statement that was previously hydrated, re-emit the prior
// pointers instead of null.
//
// This is NOT a new runtime primitive. It is a second application of the
// existing `openCarryForwardCursor<T>` derived-field-preservation surface that
// Codex already consumes (`makeThreadFingerprint` carries the prior
// `message_count`/`function_call_count` forward rather than clobbering them
// with null). Here the carried fields are `{document_url, pdf_path, pdf_sha256}`
// keyed by statement `id`.
//
// Body-honesty invariant: a carried-forward body asserts the artifact's last
// known *content-addressed* location (a pointer to bytes a prior run did
// store), NOT that this run re-verified it. The per-run `SKIP_RESULT` for the
// failed download remains the authoritative record that this run did not
// re-fetch the PDF. Carrying forward a pointer to bytes a prior run stored is
// permitted; fabricating a pointer to bytes no run stored is not — a
// never-hydrated statement stays all-null.
import { openCarryForwardCursor, } from "./fingerprint-cursor.js";
/** The all-null index-only triple a never-hydrated statement emits. */
export const NEVER_HYDRATED = {
    document_url: null,
    pdf_path: null,
    pdf_sha256: null,
    pdf_text_sha256: null,
    pdf_page_count: null,
};
/** True iff this hydration entry carries a real (non-null) pointer. A prior
 *  entry whose `pdf_path` is null was itself an index-only emit — there is
 *  nothing to carry forward, so the statement stays index-only. */
export function isHydrated(h) {
    return Boolean(h &&
        h.pdf_path !== null &&
        h.pdf_sha256 !== null &&
        h.document_url !== null);
}
/** Open a statement hydration carry-forward cursor seeded from the prior
 *  STATE cursor's decoded `hydration` map. Reuses the shared
 *  `openCarryForwardCursor` seed/seen/prune/serialize lifecycle. */
export function openStatementHydrationCursor(prior) {
    const cursor = openCarryForwardCursor(prior);
    return {
        note(id, value) {
            cursor.note(id, value);
        },
        resolveOnFailure(id) {
            const prev = cursor.prior(id);
            return isHydrated(prev) ? { ...prev } : { ...NEVER_HYDRATED };
        },
        dropUnseenIds() {
            cursor.dropUnseenIds();
        },
        size() {
            return cursor.size();
        },
        toState() {
            return cursor.toState();
        },
    };
}
/** Coerce one persisted hydration entry, tolerating legacy / corrupt shapes.
 *  Only the three known pointer fields are kept; a missing or wrong-typed
 *  field decodes to null (which `isHydrated` then treats as not-carriable). */
function coerceHydrationEntry(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return null;
    }
    const v = value;
    const str = (x) => typeof x === "string" && x.length > 0 ? x : null;
    const num = (x) => typeof x === "number" && Number.isFinite(x) && x > 0 ? x : null;
    return {
        document_url: str(v.document_url),
        pdf_path: str(v.pdf_path),
        pdf_sha256: str(v.pdf_sha256),
        pdf_text_sha256: str(v.pdf_text_sha256),
        pdf_page_count: num(v.pdf_page_count),
    };
}
/** Decode the prior `statements` STATE cursor's `hydration` map. Keyed by
 *  statement `id`. Tolerant of legacy cursors (no `hydration`), missing
 *  field, wrong types, or values from a partially-different schema — bad
 *  entries are silently dropped rather than failing the whole run. A legacy
 *  cursor decodes to an empty map, so the first post-deploy run rebuilds it
 *  and any statement that fails hydration before it has ever been seen
 *  hydrated stays honestly index-only. */
export function readPriorStatementHydration(streamState) {
    const out = new Map();
    if (!streamState ||
        typeof streamState !== "object" ||
        Array.isArray(streamState)) {
        return out;
    }
    const raw = streamState.hydration;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        return out;
    }
    for (const [id, value] of Object.entries(raw)) {
        const entry = coerceHydrationEntry(value);
        // Only retain entries that actually carry pointers; an all-null prior
        // entry has nothing to carry forward, so it need not be persisted.
        if (entry && isHydrated(entry)) {
            out.set(id, entry);
        }
    }
    return out;
}
