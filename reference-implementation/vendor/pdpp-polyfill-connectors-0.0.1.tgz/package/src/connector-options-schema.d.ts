/**
 * Resolves a connector's owner-facing config form: the SHAPE it declares in
 * its own manifest `options_schema`, merged with the KIND the platform
 * decides in `connector-config-option-kind-registry.ts`.
 *
 * The split is the whole point, and it is deliberately asymmetric:
 *
 *   SHAPE is connector-owned. Field names, types, labels, defaults and
 *   validation bounds are that connector's own facts, declared as data in
 *   its manifest exactly like `streams` and `reason_display_messages`. This
 *   is what lets the config surface reach all 45 connectors without a
 *   core-repo edit per connector.
 *
 *   KIND is platform-owned. Whether a knob is `transport` (self-activates)
 *   or `collection_scope` (lands `proposed`, inert until the owner
 *   confirms) is decided ONLY by the registry. A manifest's
 *   `declared_option_kind` is never read by this module at all. It exists
 *   so `connector-config-option-kind-honesty.test.ts` can fail the build on
 *   a connector whose claim disagrees with the registry -- a documentation
 *   claim under test, not an input to any runtime decision.
 *
 * If a manifest value could influence the kind, a connector could label its
 * own collection-shaping knob `transport` and thereby self-activate it,
 * bypassing owner confirmation entirely. So this module fails closed twice
 * over: `resolveEnforcedOptionKind` returns `collection_scope` for any key
 * the registry does not know, and the manifest's claim is never consulted
 * as an input to that decision. An unregistered connector gets a fully
 * renderable form in which EVERY field requires owner confirmation -- the
 * safe direction to be wrong in.
 *
 * Shape validation is intentionally thin. It covers what a form actually
 * needs to render a control and reject bad input before it reaches the
 * config store, and nothing more; this is not a JSON Schema implementation
 * and should not grow into one.
 */
import { type ConfigOptionKind } from "./connector-config-option-kind-registry.ts";
/** The control a form renders, and how `readOptions` will coerce the value. */
export type ConfigOptionType = "boolean" | "integer" | "string" | "string_array";
export declare class ConnectorOptionsSchemaError extends Error {
}
/** One option, after the connector's declared shape is merged with the platform's decided kind. */
export interface ResolvedConfigOption {
    /** Value used when the owner has set nothing. Always present and type-correct. */
    readonly defaultValue: boolean | number | string | readonly string[];
    /** Owner-facing explanation, from the manifest. */
    readonly description: string;
    /** Closed set of accepted values, when the connector declares one. */
    readonly enumValues: readonly string[] | null;
    /** Inclusive upper bound for `integer`, when declared. */
    readonly maximum: number | null;
    /** Inclusive lower bound for `integer`, when declared. */
    readonly minimum: number | null;
    /** The option key, matching `readOptions`' field name (e.g. `LOOKBACK_DAYS`). */
    readonly optionKey: string;
    /**
     * PLATFORM-DECIDED, never manifest-supplied. `transport` self-activates;
     * `collection_scope` requires an explicit owner confirm.
     */
    readonly optionKind: ConfigOptionKind;
    /**
     * True when the platform registry actually classified this key. False
     * means `optionKind` is the fail-closed `collection_scope` default, which
     * an owner-facing surface may want to say out loud.
     */
    readonly platformClassified: boolean;
    readonly type: ConfigOptionType;
}
/** One connector's whole owner-facing config form. */
export interface ResolvedConnectorOptionsSchema {
    readonly connectorKey: string;
    readonly description: string;
    /** Sorted by option key, so a rendered form and its tests are order-stable. */
    readonly options: readonly ResolvedConfigOption[];
}
/** Parses one manifest's `options_schema`, or returns null when it declares none. */
export declare function resolveOptionsSchemaFromManifest(manifest: unknown, file: string): ResolvedConnectorOptionsSchema | null;
/**
 * Every shipped connector's resolved config form, keyed by connector_key.
 * Connectors declaring no `options_schema` are absent. Re-derived per call
 * (manifests are small, this is not a hot path) so a test pointing
 * `PDPP_POLYFILL_MANIFESTS_DIR` at a scratch directory sees it immediately.
 */
export declare function connectorOptionsSchemas(): Readonly<Record<string, ResolvedConnectorOptionsSchema>>;
/** One connector's resolved config form, or `null` when it declares no options. */
export declare function connectorOptionsSchema(connectorKey: string | null): ResolvedConnectorOptionsSchema | null;
//# sourceMappingURL=connector-options-schema.d.ts.map