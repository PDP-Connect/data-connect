// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0
import { manualAction } from "./browser-handoff.js";
import { isConnectorErrorCodeShaped, TerminalError, } from "./terminal-error.js";
export const DEFAULT_RETRYABLE_PATTERN = /ECONN|ETIMEDOUT|timeout/i;
function retryablePatternMatches(pattern, value) {
    pattern.lastIndex = 0;
    const matched = pattern.test(value);
    pattern.lastIndex = 0;
    return matched;
}
/**
 * `postSubmit` forces `retryable: false` unconditionally, WITHOUT consulting
 * `retryablePattern` at all — a saved credential was already submitted to the
 * provider's real sign-in form, so a fault occurring after that point can
 * never be safely retried from a fresh process, no matter what vocabulary the
 * error message happens to share with the connector's legitimate pre-submit
 * retry patterns (e.g. a bare "timeout" or a shared transport-error term).
 * This is the single point that closes the naming-collision defect class: it
 * decides "did the credential already go out" once, centrally, instead of
 * leaving every connector's regex to (fail to) encode that distinction.
 */
export function buildSessionEstablishTerminalError(name, message, retryablePattern = DEFAULT_RETRYABLE_PATTERN, postSubmit = false) {
    const terminalMessage = `${name}_session_failed: ${message}`;
    return {
        message: terminalMessage,
        retryable: !postSubmit &&
            (retryablePatternMatches(retryablePattern, message) ||
                retryablePatternMatches(retryablePattern, terminalMessage)),
    };
}
/**
 * Run whichever session-management flow the connector configured.
 * Throws TerminalError if the session is dead and we couldn't recover.
 *
 * Priority: ensureSession (automated re-auth) > probeSession (read-only
 * + manual_action fallback) > nothing (connector assumes session is live).
 *
 * The runtime frames the window with a `begin` checkpoint before delegating
 * and a `probe` checkpoint around the read-only probe path so the watchdog
 * has progress markers even for connectors that do not checkpoint themselves.
 */
export async function establishSession(hooks, args) {
    const { ensureSession, probeSession } = hooks;
    const { assist, capture, checkpoint, completeAssistance, context, credentials = {}, page, name, retryablePattern, sendInteraction, progress, } = args;
    await checkpoint("session-establish:begin");
    if (typeof ensureSession === "function") {
        // Set once `ensureSession` reports it has submitted a saved credential to
        // the provider's real sign-in form. Scoped to this one establishSession()
        // call — a fresh process gets a fresh `false`, which is correct: the
        // credential wasn't submitted yet IN THIS process, even if a prior
        // process's submission is what's being retried. That's exactly the case
        // this primitive exists to stop: this call is the resubmission risk.
        let credentialSubmitted = false;
        try {
            await ensureSession({
                assist,
                capture,
                checkpoint,
                completeAssistance,
                context,
                credentials,
                onCredentialSubmit: () => {
                    credentialSubmitted = true;
                },
                page,
                sendInteraction,
                progress,
            });
            return;
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            const terminalError = buildSessionEstablishTerminalError(name, message, retryablePattern, credentialSubmitted);
            // `message` is about to be redacted (`boundConnectorErrorMessage`) before
            // it reaches the owner — free-form text is untrusted by contract. Most
            // connector ensureSession throw sites (heb.ts, usaa.ts, etc.) already
            // throw a bare `Error("some_snake_case_reason")`: the ENTIRE thrown
            // message is already a short, non-PII, machine-actionable token — the
            // exact shape the unredacted `code` channel exists for (terminal-error.ts).
            // Recover it as `code` here so the redaction below cannot destroy it: a
            // long/opaque-looking-but-innocuous token like
            // "heb_verification_code_not_provided" (35 chars) would otherwise be
            // wholesale-matched by stderr-redact.ts's LONG_OPAQUE_RE and collapsed to
            // a bare "[REDACTED]" with zero diagnostic value. A compound message
            // (anything with a space or colon, e.g. "source_unavailable: USAA
            // reported...") fails the code charset and is correctly left to the
            // redacted `message` channel only.
            const code = isConnectorErrorCodeShaped(message) ? message : undefined;
            throw new TerminalError(terminalError.message, {
                retryable: terminalError.retryable,
                cause: err,
                ...(code ? { code } : {}),
            });
        }
    }
    if (typeof probeSession !== "function") {
        return;
    }
    await checkpoint("session-establish:probe");
    if (await probeSession({ context, page })) {
        return;
    }
    await manualAction({
        page,
        reason: "login",
        message: `${name} session expired. Open the browser and re-authenticate, then continue.`,
        timeoutSeconds: 1800,
    }, sendInteraction);
    await checkpoint("session-establish:probe-after-manual");
    if (await probeSession({ context, page })) {
        return;
    }
    throw new TerminalError(`${name}_session_required`);
}
