export interface InteractionMessage {
    kind: string;
    message?: string;
    request_id?: string;
    schema?: {
        properties?: Record<string, {
            description?: string;
        }>;
    };
    timeout_seconds?: number;
}
export interface InteractionResponseInner {
    data?: Record<string, string>;
    error?: {
        code?: string;
        message?: string;
    };
    status?: string;
    value?: string;
}
export type InteractionResponseStatus = "success" | "cancelled" | "timeout";
export interface InteractionResponse {
    data?: Record<string, string>;
    error?: {
        code?: string;
        message?: string;
    };
    request_id: string;
    status: InteractionResponseStatus;
    type: "INTERACTION_RESPONSE";
}
declare function normalizeStatus(raw: string | undefined): InteractionResponseStatus;
export interface HandleInteractionOptions {
    connectorName?: string;
    runId?: string;
}
declare function buildClickUrl(runId: string | undefined, kind: string, interactionId: string | undefined): string | undefined;
export declare function handleInteraction(msg: InteractionMessage, { connectorName, runId }?: HandleInteractionOptions): Promise<InteractionResponse>;
export declare const __testing: {
    buildClickUrl: typeof buildClickUrl;
    normalizeStatus: typeof normalizeStatus;
};
export {};
//# sourceMappingURL=interaction-handler.d.ts.map