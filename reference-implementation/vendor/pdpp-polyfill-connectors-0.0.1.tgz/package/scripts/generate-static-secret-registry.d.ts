export {};
//# sourceMappingURL=generate-static-secret-registry.d.ts.map