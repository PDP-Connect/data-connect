// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import test from "node:test";

import { hasResponseSchema, validateRequest, validateResponse } from "../src/index.ts";

// `getRsDiscoveryIndex` is a stable JSON discovery operation whose
// declared 200 response schema does not drift from the reference
// implementation. These tests exercise validateResponse against that
// manifest because it is the canonical "exact-schema" candidate for
// the response-validation canary allowlist in the reference transport.

test("hasResponseSchema reports declared response statuses", () => {
  assert.equal(hasResponseSchema("getRsDiscoveryIndex", 200), true);
  // The discovery operation does not declare a 418 response.
  assert.equal(hasResponseSchema("getRsDiscoveryIndex", 418), false);
  // Unknown operation ids report no schema.
  assert.equal(hasResponseSchema("definitely-not-a-real-op", 200), false);
});

test("validateResponse passes a valid discovery envelope unchanged", () => {
  const payload = {
    links: {
      connectors: "/v1/connectors",
      core_query_base: "/v1",
      schema: "/v1/schema",
      well_known: "/.well-known/oauth-protected-resource",
    },
    object: "pdpp_discovery_index",
    reference_revision: "dev",
    resource_name: "PDPP Reference",
    role: "resource_server",
  };
  const before = JSON.stringify(payload);
  const result = validateResponse("getRsDiscoveryIndex", {
    body: payload,
    status: 200,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
  // Validation must not mutate the input payload.
  assert.equal(JSON.stringify(payload), before);
});

test("validateResponse reports skip with reason for unknown operation ids", () => {
  const result = validateResponse("definitely-not-a-real-op", {
    body: {},
    status: 200,
  });
  assert.deepEqual(result, {
    ok: true,
    reason: "unknown_operation_id",
    skipped: true,
  });
});

test("validateResponse reports skip when no schema is declared for a status", () => {
  const result = validateResponse("getRsDiscoveryIndex", {
    body: undefined,
    status: 204,
  });
  assert.deepEqual(result, {
    ok: true,
    reason: "no_schema_for_status",
    skipped: true,
  });
});

test("validateResponse fails closed when payload violates declared response schema", () => {
  // Missing required `links` field.
  const invalidPayload = {
    object: "pdpp_discovery_index",
    reference_revision: "dev",
    resource_name: "PDPP Reference",
    role: "resource_server",
  };
  const result = validateResponse("getRsDiscoveryIndex", {
    body: invalidPayload,
    status: 200,
  });
  assert.equal(result.ok, false);
  assert.ok(Array.isArray(result.errors));
  assert.ok(result.errors.length > 0);
  // Each error carries a structured message — useful for operator logs
  // even though the wire envelope is intentionally opaque.
  for (const err of result.errors) {
    assert.equal(typeof err.message, "string");
  }
});

test("approveConsent accepts the closed batch approval response", () => {
  const result = validateResponse("approveConsent", {
    body: {
      grant: {
        child_grants: [{ grant_id: "grant_child_1", source: { id: "spotify" } }],
        grant_id: "grant_package",
        package: true,
        package_id: "package_1",
      },
      package_id: "package_1",
      token: "token_1",
    },
    status: 200,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
});

test("OAuth token error contract accepts the refresh-reuse recovery marker", () => {
  const result = validateResponse("exchangeOwnerDeviceToken", {
    body: {
      error: "invalid_grant",
      error_description: "Refresh token reuse revoked its family; fresh authorization is required",
      fresh_authorization_required: true,
      request_id: "req_refresh_reuse",
    },
    status: 400,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
});

test("approveConsent rejects extra fields in a batch approval response", () => {
  const result = validateResponse("approveConsent", {
    body: {
      grant: {
        child_grants: [{ grant_id: "grant_child_1", source: { id: "spotify" } }],
        grant_id: "grant_package",
        package: true,
        package_id: "package_1",
      },
      package_id: "package_1",
      token: "token_1",
      unexpected: true,
    },
    status: 200,
  });
  assert.equal(result.ok, false);
});

test("introspection contract declares confidential caller authentication failure", () => {
  const result = validateResponse("introspectToken", {
    body: {
      error: {
        code: "context.authentication_failed",
        message: "Introspection client authentication failed",
        request_id: "req_introspection_auth",
        type: "https://pdpp.dev/errors/context.authentication_failed",
      },
    },
    status: 401,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
});

// `expand_capabilities` target-naming contract. Each entry SHALL carry both
// `target_stream` (the related child stream) and `child_parent_key_field` (the
// field on the child holding the parent's key). Pinned via getStreamMetadata's
// declared 200 response schema. See
//   openspec/changes/add-record-relationship-navigation/.

interface ExpandCapabilityEntry {
  cardinality: string;
  child_parent_key_field?: string;
  foreign_key: string;
  granted: boolean;
  name: string;
  reason?: string;
  stream: string;
  target_stream?: string;
  usable: boolean;
}

function streamMetadataWithExpandEntry(entry: ExpandCapabilityEntry) {
  return {
    expand_capabilities: [entry],
    field_capabilities: {},
    name: "user",
    object: "stream_metadata",
  };
}

const VALID_EXPAND_ENTRY: ExpandCapabilityEntry = {
  cardinality: "has_many",
  child_parent_key_field: "user_id",
  foreign_key: "user_id",
  granted: true,
  name: "user_stats",
  stream: "user_stats",
  target_stream: "user_stats",
  usable: true,
};

test("getStreamMetadata accepts an expand_capabilities entry carrying target_stream and child_parent_key_field", () => {
  const result = validateResponse("getStreamMetadata", {
    body: streamMetadataWithExpandEntry({ ...VALID_EXPAND_ENTRY }),
    status: 200,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
});

test("getStreamMetadata rejects an expand_capabilities entry missing target_stream", () => {
  const entry = { ...VALID_EXPAND_ENTRY };
  // biome-ignore lint/performance/noDelete: test must construct a genuinely absent JSON property.
  delete entry.target_stream;
  const result = validateResponse("getStreamMetadata", {
    body: streamMetadataWithExpandEntry(entry),
    status: 200,
  });
  assert.equal(result.ok, false);
  assert.ok(Array.isArray(result.errors) && result.errors.length > 0);
});

test("getStreamMetadata rejects an expand_capabilities entry missing child_parent_key_field", () => {
  const entry = { ...VALID_EXPAND_ENTRY };
  // biome-ignore lint/performance/noDelete: test must construct a genuinely absent JSON property.
  delete entry.child_parent_key_field;
  const result = validateResponse("getStreamMetadata", {
    body: streamMetadataWithExpandEntry(entry),
    status: 200,
  });
  assert.equal(result.ok, false);
  assert.ok(Array.isArray(result.errors) && result.errors.length > 0);
});

test("getStreamMetadata rejects an expand_capabilities entry with an out-of-enum reason", () => {
  const result = validateResponse("getStreamMetadata", {
    body: streamMetadataWithExpandEntry({
      ...VALID_EXPAND_ENTRY,
      granted: false,
      reason: "not_a_declared_reason",
      usable: false,
    }),
    status: 200,
  });
  assert.equal(result.ok, false);
  assert.ok(Array.isArray(result.errors) && result.errors.length > 0);
});

test("getStreamMetadata accepts each declared reason enum value on an inert entry", () => {
  for (const reason of ["related_stream_not_granted", "related_stream_unknown", "related_stream_not_loaded"]) {
    const result = validateResponse("getStreamMetadata", {
      body: streamMetadataWithExpandEntry({
        ...VALID_EXPAND_ENTRY,
        granted: false,
        reason,
        usable: false,
      }),
      status: 200,
    });
    assert.deepEqual(result, { ok: true, skipped: false }, `reason ${reason} should validate`);
  }
});

// Public contract tests use Core §§7–8 and draft #387/#388/#392 as truth sources.
// They exercise route validators because standalone-schema success cannot prove
// that a new shape is connected to the public manifest used by the RI.
const prototypeGrant = {
  access_mode: "continuous",
  client: { client_id: "app" },
  grant_id: "grant",
  issued_at: "2026-10-10T00:00:00Z",
  purpose_code: "https://example.com/research",
  source: { id: "https://example.com/source", kind: "connector" },
  source_declaration: { version: "v1" },
  streams: [{ fields: ["id"], instance_ids: ["instance"], name: "issues" }],
  subject: { id: "subject" },
  version: "0.1.0",
};

test("token manifest accepts legacy responses and immutable grant authorization details", () => {
  const legacy = { access_token: "token", expires_in: 3600, token_type: "Bearer" };
  assert.equal(validateResponse("exchangeOwnerDeviceToken", { body: legacy, status: 200 }).ok, true);
  const body = {
    access_token: "token",
    refresh_token: "refresh",
    token_type: "Bearer",
    authorization_details: [{ type: "https://pdpp.dev/data-access", grant: prototypeGrant }],
  };
  assert.equal(validateResponse("exchangeOwnerDeviceToken", { body, status: 200 }).ok, true);
  assert.equal(
    validateResponse("exchangeOwnerDeviceToken", {
      body: { ...body, authorization_details: [{ type: "wrong", grant: prototypeGrant }] },
      status: 200,
    }).ok,
    false
  );
  assert.equal(
    validateResponse("exchangeOwnerDeviceToken", {
      body: { ...body, authorization_details: [{ type: "https://pdpp.dev/data-access", grant: { streams: [] } }] },
      status: 200,
    }).ok,
    false
  );
});

test("legacy flattened RAR remains accepted by token and open introspection contracts", () => {
  // Mirrors buildGrantedAuthorizationDetail in the flag-off RI, not a request
  // convenience shape: its stream rows contain resolved instance and field sets.
  const detail = {
    access_mode: prototypeGrant.access_mode,
    purpose_code: prototypeGrant.purpose_code,
    source: prototypeGrant.source,
    streams: prototypeGrant.streams,
    type: "https://pdpp.dev/data-access",
  };
  assert.equal(
    validateResponse("exchangeOwnerDeviceToken", {
      body: { access_token: "token", grant_id: "grant", token_type: "Bearer", authorization_details: [detail] },
      status: 200,
    }).ok,
    true
  );
  assert.equal(
    validateResponse("introspectToken", {
      body: { active: true, authorization_details: [detail] },
      status: 200,
    }).ok,
    true
  );
  assert.equal(
    validateResponse("introspectToken", {
      body: { active: true, authorization_details: [{ type: "https://pdpp.dev/data-access", grant: prototypeGrant }] },
      status: 200,
    }).ok,
    true
  );
});

test("introspection validates RS-only owner and client instance bindings", () => {
  const ownerBinding = { source_id: "https://example.com/source", instance_id: "instance", rs_instance: "stored" };
  const body = { active: true, pdpp_instance_bindings: [ownerBinding, { ...ownerBinding, stream: "issues" }] };
  assert.equal(validateResponse("introspectToken", { body, status: 200 }).ok, true);
  assert.equal(
    validateResponse("introspectToken", {
      body: { ...body, pdpp_instance_bindings: [{ ...ownerBinding, rs_instance: "" }] },
      status: 200,
    }).ok,
    false
  );
  assert.equal(
    validateResponse("introspectToken", {
      body: { ...body, pdpp_instance_bindings: [{ instance_id: "instance" }] },
      status: 200,
    }).ok,
    false
  );
});

test("record manifest accepts new freshness array and optional instance handle while retaining legacy freshness", () => {
  const record = { object: "record", id: "1", stream: "issues" };
  const body = {
    object: "list",
    data: [
      { ...record, instance_id: "instance" },
      { ...record, deleted: true, instance_id: "instance" },
    ],
    has_more: false,
    freshness: [{ instance_id: "instance", last_success_at: null }],
  };
  assert.equal(validateResponse("listRecords", { body, status: 200 }).ok, true);
  assert.equal(
    validateResponse("listRecords", {
      body: { ...body, data: [record], freshness: { status: "unknown" } },
      status: 200,
    }).ok,
    true
  );
  assert.equal(
    validateResponse("listRecords", {
      body: { ...body, freshness: [{ instance_id: "instance", last_success_at: "yesterday" }] },
      status: 200,
    }).ok,
    false
  );
  assert.equal(
    validateResponse("listRecords", { body: { ...body, freshness: [{ instance_id: "instance" }] }, status: 200 }).ok,
    false
  );
  assert.equal(
    validateResponse("listRecords", { body: { ...body, data: [{ ...record, instance_id: 1 }] }, status: 200 }).ok,
    false
  );
});

test("review manifest binds processing permissions, grantors and exact shown declaration text", () => {
  const artifact = {
    access_mode: "continuous",
    ai_training_consented: null,
    client: { client_id: "app", registration_mode: "dynamic", client_display: { name: "Shown app" } },
    client_claims: null,
    expires_at: null,
    purpose_code: prototypeGrant.purpose_code,
    purpose_description: null,
    resolved_streams: prototypeGrant.streams,
    retention: null,
    selection_preset: null,
    source: prototypeGrant.source,
    source_declaration: { digest: "digest", version: "v1" },
    subject: prototypeGrant.subject,
    version: "reference.approval-review.v1",
  };
  const envelope = {
    approval_review: artifact,
    approval_review_revision: "revision",
    batch: false,
    request_uri: "request",
  };
  assert.equal(validateResponse("reviewConsent", { body: envelope, status: 200 }).ok, true);
  const approval_review = {
    ...artifact,
    processing_permissions: ["https://pdpp.dev/processing/ai_training"],
    grantors: [{ id: "rep", capacity: "https://example.com/parent" }],
    declaration_display: [{ path: "/streams/0/display/label", text: "Incidencias", language: "es" }],
  };
  assert.equal(validateResponse("reviewConsent", { body: { ...envelope, approval_review }, status: 200 }).ok, true);
  assert.equal(
    validateResponse("reviewConsent", {
      body: {
        ...envelope,
        approval_review: { ...approval_review, declaration_display: [{ path: "/display/name", language: "es" }] },
      },
      status: 200,
    }).ok,
    false
  );
});

test("revoke accepts optional draft disposition body and preserves legacy response", () => {
  assert.equal(validateRequest("revokeGrant", {}).ok, true);
  assert.equal(validateRequest("revokeGrant", { body: { pdpp_disposition: "keep" } }).ok, true);
  assert.equal(
    validateRequest("revokeGrant", { body: { pdpp_disposition: "delete", reported_at: "2026-10-10T00:00:00Z" } }).ok,
    true
  );
  assert.equal(validateRequest("revokeGrant", { body: { pdpp_disposition: "erase" } }).ok, false);
  assert.equal(
    validateRequest("revokeGrant", { body: { pdpp_disposition: "delete", reported_at: "yesterday" } }).ok,
    false
  );
  assert.equal(validateResponse("revokeGrant", { body: { revoked: true }, status: 200 }).ok, true);
});
