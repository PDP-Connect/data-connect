// Copyright The PDP-Connect Contributors
// SPDX-License-Identifier: Apache-2.0

import assert from "node:assert/strict";
import test from "node:test";

import { hasResponseSchema, validateResponse } from "../src/index.ts";

// `getRsDiscoveryIndex` is a stable JSON discovery operation whose
// declared 200 response schema does not drift from the reference
// implementation. These tests exercise validateResponse against that
// manifest because it is the canonical "exact-schema" candidate for
// the response-validation canary allowlist in the reference transport.

test("hasResponseSchema reports declared response statuses", () => {
  assert.equal(hasResponseSchema("getRsDiscoveryIndex", 200), true);
  // The discovery operation does not declare a 418 response.
  assert.equal(hasResponseSchema("getRsDiscoveryIndex", 418), false);
  // Unknown operation ids report no schema.
  assert.equal(hasResponseSchema("definitely-not-a-real-op", 200), false);
});

test("validateResponse passes a valid discovery envelope unchanged", () => {
  const payload = {
    links: {
      connectors: "/v1/connectors",
      core_query_base: "/v1",
      schema: "/v1/schema",
      well_known: "/.well-known/oauth-protected-resource",
    },
    object: "pdpp_discovery_index",
    reference_revision: "dev",
    resource_name: "PDPP Reference",
    role: "resource_server",
  };
  const before = JSON.stringify(payload);
  const result = validateResponse("getRsDiscoveryIndex", {
    body: payload,
    status: 200,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
  // Validation must not mutate the input payload.
  assert.equal(JSON.stringify(payload), before);
});

test("validateResponse reports skip with reason for unknown operation ids", () => {
  const result = validateResponse("definitely-not-a-real-op", {
    body: {},
    status: 200,
  });
  assert.deepEqual(result, {
    ok: true,
    reason: "unknown_operation_id",
    skipped: true,
  });
});

test("validateResponse reports skip when no schema is declared for a status", () => {
  const result = validateResponse("getRsDiscoveryIndex", {
    body: undefined,
    status: 204,
  });
  assert.deepEqual(result, {
    ok: true,
    reason: "no_schema_for_status",
    skipped: true,
  });
});

test("validateResponse fails closed when payload violates declared response schema", () => {
  // Missing required `links` field.
  const invalidPayload = {
    object: "pdpp_discovery_index",
    reference_revision: "dev",
    resource_name: "PDPP Reference",
    role: "resource_server",
  };
  const result = validateResponse("getRsDiscoveryIndex", {
    body: invalidPayload,
    status: 200,
  });
  assert.equal(result.ok, false);
  assert.ok(Array.isArray(result.errors));
  assert.ok(result.errors.length > 0);
  // Each error carries a structured message — useful for operator logs
  // even though the wire envelope is intentionally opaque.
  for (const err of result.errors) {
    assert.equal(typeof err.message, "string");
  }
});

test("approveConsent accepts the closed batch approval response", () => {
  const result = validateResponse("approveConsent", {
    body: {
      grant: {
        child_grants: [{ grant_id: "grant_child_1", source: { id: "spotify" } }],
        grant_id: "grant_package",
        package: true,
        package_id: "package_1",
      },
      package_id: "package_1",
      token: "token_1",
    },
    status: 200,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
});

test("OAuth token error contract accepts the refresh-reuse recovery marker", () => {
  const result = validateResponse("exchangeOwnerDeviceToken", {
    body: {
      error: "invalid_grant",
      error_description: "Refresh token reuse revoked its family; fresh authorization is required",
      fresh_authorization_required: true,
      request_id: "req_refresh_reuse",
    },
    status: 400,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
});

test("approveConsent rejects extra fields in a batch approval response", () => {
  const result = validateResponse("approveConsent", {
    body: {
      grant: {
        child_grants: [{ grant_id: "grant_child_1", source: { id: "spotify" } }],
        grant_id: "grant_package",
        package: true,
        package_id: "package_1",
      },
      package_id: "package_1",
      token: "token_1",
      unexpected: true,
    },
    status: 200,
  });
  assert.equal(result.ok, false);
});

test("introspection contract declares confidential caller authentication failure", () => {
  const result = validateResponse("introspectToken", {
    body: {
      error: {
        code: "context.authentication_failed",
        message: "Introspection client authentication failed",
        request_id: "req_introspection_auth",
        type: "https://pdpp.dev/errors/context.authentication_failed",
      },
    },
    status: 401,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
});

// `expand_capabilities` target-naming contract. Each entry SHALL carry both
// `target_stream` (the related child stream) and `child_parent_key_field` (the
// field on the child holding the parent's key). Pinned via getStreamMetadata's
// declared 200 response schema. See
//   openspec/changes/add-record-relationship-navigation/.

interface ExpandCapabilityEntry {
  cardinality: string;
  child_parent_key_field?: string;
  foreign_key: string;
  granted: boolean;
  name: string;
  reason?: string;
  stream: string;
  target_stream?: string;
  usable: boolean;
}

function streamMetadataWithExpandEntry(entry: ExpandCapabilityEntry) {
  return {
    expand_capabilities: [entry],
    field_capabilities: {},
    name: "user",
    object: "stream_metadata",
  };
}

const VALID_EXPAND_ENTRY: ExpandCapabilityEntry = {
  cardinality: "has_many",
  child_parent_key_field: "user_id",
  foreign_key: "user_id",
  granted: true,
  name: "user_stats",
  stream: "user_stats",
  target_stream: "user_stats",
  usable: true,
};

test("getStreamMetadata accepts an expand_capabilities entry carrying target_stream and child_parent_key_field", () => {
  const result = validateResponse("getStreamMetadata", {
    body: streamMetadataWithExpandEntry({ ...VALID_EXPAND_ENTRY }),
    status: 200,
  });
  assert.deepEqual(result, { ok: true, skipped: false });
});

test("getStreamMetadata rejects an expand_capabilities entry missing target_stream", () => {
  const entry = { ...VALID_EXPAND_ENTRY };
  // biome-ignore lint/performance/noDelete: test must construct a genuinely absent JSON property.
  delete entry.target_stream;
  const result = validateResponse("getStreamMetadata", {
    body: streamMetadataWithExpandEntry(entry),
    status: 200,
  });
  assert.equal(result.ok, false);
  assert.ok(Array.isArray(result.errors) && result.errors.length > 0);
});

test("getStreamMetadata rejects an expand_capabilities entry missing child_parent_key_field", () => {
  const entry = { ...VALID_EXPAND_ENTRY };
  // biome-ignore lint/performance/noDelete: test must construct a genuinely absent JSON property.
  delete entry.child_parent_key_field;
  const result = validateResponse("getStreamMetadata", {
    body: streamMetadataWithExpandEntry(entry),
    status: 200,
  });
  assert.equal(result.ok, false);
  assert.ok(Array.isArray(result.errors) && result.errors.length > 0);
});

test("getStreamMetadata rejects an expand_capabilities entry with an out-of-enum reason", () => {
  const result = validateResponse("getStreamMetadata", {
    body: streamMetadataWithExpandEntry({
      ...VALID_EXPAND_ENTRY,
      granted: false,
      reason: "not_a_declared_reason",
      usable: false,
    }),
    status: 200,
  });
  assert.equal(result.ok, false);
  assert.ok(Array.isArray(result.errors) && result.errors.length > 0);
});

test("getStreamMetadata accepts each declared reason enum value on an inert entry", () => {
  for (const reason of ["related_stream_not_granted", "related_stream_unknown", "related_stream_not_loaded"]) {
    const result = validateResponse("getStreamMetadata", {
      body: streamMetadataWithExpandEntry({
        ...VALID_EXPAND_ENTRY,
        granted: false,
        reason,
        usable: false,
      }),
      status: 200,
    });
    assert.deepEqual(result, { ok: true, skipped: false }, `reason ${reason} should validate`);
  }
});

// Run-order and coverage members that the reference server emits and this contract must list.
// Defect: the contract is closed (additionalProperties: false), so a member it does not list fails
// validation of a live server response. Oracle: the server's own emission, LocalCoverageAsOf in
// PDP-Connect/data-connect reference-implementation/server/ref-control.ts and responseFor() in
// reference-implementation/server/stores/terminal-run-commit-store.ts. The data-connect contract
// test runs only after a re-vendor, so this suite is the first check that can catch a missing
// member. Suite: reference-contract.

const LOCAL_COVERAGE_AS_OF = {
  artifact_digest: "sha256:bbbb",
  collection_revision: 12,
  committed_at: "2026-10-21T12:00:00.000Z",
  evidence: "terminal_run",
  run_id: "run_a",
  run_sequence: 3,
};

function ownerDiagnosticsWithCoverage(asOf: Record<string, unknown> | null) {
  return {
    connection_id: "conn_1",
    connector_id: "gmail",
    connector_key: "gmail",
    coverage_as_of: asOf,
    display_name: null,
    freshness: {},
    health: {
      axes: {},
      badges: {},
      coverage_as_of: asOf,
      last_success_at: null,
      next_attempt_at: null,
      reason_code: null,
      state: "healthy",
    },
    last_ingest_at: null,
    last_run: null,
    last_successful_run: null,
    object: "owner_connection_diagnostics",
    recovery: {
      admission: { admitted: 0, candidates: 0, deferred: 0 },
      read_limit: null,
      stall: { eligibleCandidates: 0, lastAttemptAt: null, stalled: false },
      unreadable: false,
    },
    rendered_verdict: {},
    schedule: null,
  };
}

test("owner diagnostics lists coverage_as_of at the top level and in health, as a proof or null", () => {
  const proven = validateResponse("ownerInspectConnectionDiagnostics", {
    body: ownerDiagnosticsWithCoverage(LOCAL_COVERAGE_AS_OF),
    status: 200,
  });
  assert.deepEqual(proven, { ok: true, skipped: false });
  const unproven = validateResponse("ownerInspectConnectionDiagnostics", {
    body: ownerDiagnosticsWithCoverage(null),
    status: 200,
  });
  assert.deepEqual(unproven, { ok: true, skipped: false });
});

test("owner diagnostics rejects an as-of member the server does not emit", () => {
  const result = validateResponse("ownerInspectConnectionDiagnostics", {
    body: ownerDiagnosticsWithCoverage({ ...LOCAL_COVERAGE_AS_OF, release_digest: "sha256:bbbb" }),
    status: 200,
  });
  assert.equal(result.ok, false);
});

// The terminal-run receipt (200 and 201) stores the run's place in run order. Receipts stored
// before run order omit the three members, so the members stay optional.
test("terminal run receipt lists collection_revision, run_sequence and storage_epoch", () => {
  const receipt = {
    commit_id: "commit_1",
    envelope_hash: "a".repeat(64),
    object: "device_terminal_run_commit",
    run_id: "run_a",
    terminal_event_id: "evt_local_terminal_commit_1",
  };
  const committed = validateResponse("refCommitDeviceExporterTerminalRun", {
    body: { ...receipt, collection_revision: 12, run_sequence: 3, storage_epoch: 1 },
    status: 201,
  });
  assert.deepEqual(committed, { ok: true, skipped: false });
  const noSequence = validateResponse("refCommitDeviceExporterTerminalRun", {
    body: { ...receipt, collection_revision: 12, run_sequence: null, storage_epoch: 1 },
    status: 201,
  });
  assert.deepEqual(noSequence, { ok: true, skipped: false });
  const legacy = validateResponse("refCommitDeviceExporterTerminalRun", {
    body: receipt,
    status: 200,
  });
  assert.deepEqual(legacy, { ok: true, skipped: false });
});

test("terminal run receipt rejects a run_sequence that is neither an integer nor null", () => {
  const result = validateResponse("refCommitDeviceExporterTerminalRun", {
    body: {
      commit_id: "commit_1",
      envelope_hash: "a".repeat(64),
      object: "device_terminal_run_commit",
      run_id: "run_a",
      run_sequence: "3",
      terminal_event_id: "evt_local_terminal_commit_1",
    },
    status: 201,
  });
  assert.equal(result.ok, false);
});
