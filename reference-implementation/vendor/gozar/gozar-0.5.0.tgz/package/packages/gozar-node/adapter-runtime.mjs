// Adapter runtime: loads registered adapter modules and wraps existing recipe definitions as Adapters.
//
// One adapter is one directory under adapters/providers/ plus one `{id, module, definition}` entry in
// the manifest `providers` list. Nothing in core, the CLI or an app names a provider. The runtime is a
// uniform layer over the EXISTING admitted recipe engine: it never builds an executable payload. It
// hands recipe references to the contexts the engine supplies (`probe`, `executePlan`,
// `compareAndRemove`) and rejects every method or kind that has no recipe with `unsupported`.
//
// Context fields this runtime reads are contract fields, with no defaults. A context that lacks one is
// a host bug and fails with `provider_unavailable` instead of being guessed:
//   ctx.platform   string   host platform, injected so logic never reads process.platform itself
//   ctx.home       string   canonical Gozar home; the durable plan needs it for durablePlanFacts()
//   ctx.generation number   generation recorded on receipts built by an adapter
// `ctx.probe(recipe)` resolves `{ ok: boolean, detail?: string }`: the engine ran the recipe and its parser said yes.
import { networkInterfaces } from 'node:os';
import { readFileSync } from 'node:fs';
import { readFile, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { supportedPlatform } from './platform.mjs';
import { bindConfiguration } from './adapter-configuration.mjs';

const packageRoot = fileURLToPath(new URL('../../', import.meta.url));
const defaultAdaptersRoot = resolve(packageRoot, 'adapters');
const adapterSchema = JSON.parse(readFileSync(resolve(packageRoot, 'runtime/adapter.schema.json'), 'utf8'));

const sha = value => createHash('sha256').update(typeof value === 'string' ? value : JSON.stringify(canonical(value))).digest('hex');
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  return value;
}

// --- Errors -------------------------------------------------------------------------------------------

/** What an adapter operation rejects with. Only the four frozen AdapterEffectError codes are used. */
export function effectError(code, message) { return Object.assign(new Error(message), { code }); }
const effectCodes = new Set(['precondition_failed', 'unsupported', 'provider_unavailable', 'setup_required']);
const isEffectError = error => effectCodes.has(error?.code);
// Provider codes map onto the frozen list (route contract revision 3 (f)). Anything else is a generic
// provider failure: the provider's own message is never forwarded, so it cannot carry a secret.
export function mapProviderError(error) {
  if (isEffectError(error)) return error;
  if (['provider_denied', 'provider_not_running'].includes(error?.code)) return effectError('setup_required', 'The provider needs an operator action before this can proceed');
  if (error?.code === 'provider_unsupported') return effectError('unsupported', 'The provider does not support this operation');
  return effectError('provider_unavailable', 'The provider operation failed');
}
// A load failure is a Gozar fault: the frozen consumer code `internal_error`.
const loadError = (id, message) => Object.assign(new Error(`Adapter ${id}: ${message}`), { code: 'internal_error', adapterId: id });

// --- Schema validation (only the keywords adapter.schema.json uses) ------------------------------------

const kinds = {
  string: v => typeof v === 'string', number: v => typeof v === 'number' && Number.isFinite(v), integer: v => Number.isInteger(v),
  boolean: v => typeof v === 'boolean', null: v => v === null, array: Array.isArray,
  object: v => typeof v === 'object' && v !== null && !Array.isArray(v),
};
function validate(schema, value, defs, path = '$') {
  const errors = [];
  for (const key of Object.keys(schema)) {
    if (['$schema', '$id', 'title', 'description', '$defs'].includes(key)) continue;
    switch (key) {
      case '$ref': errors.push(...validate(defs[schema.$ref.replace('#/$defs/', '')], value, defs, path)); break;
      case 'type': if (![].concat(schema.type).some(type => kinds[type](value))) errors.push(`${path}: expected ${[].concat(schema.type).join('|')}`); break;
      case 'const': if (!isDeepStrictEqual(value, schema.const)) errors.push(`${path}: expected const`); break;
      case 'enum': if (!schema.enum.some(item => isDeepStrictEqual(item, value))) errors.push(`${path}: not in enum`); break;
      case 'required': if (kinds.object(value)) for (const name of schema.required) if (!(name in value)) errors.push(`${path}: missing ${name}`); break;
      case 'properties': if (kinds.object(value)) for (const [name, sub] of Object.entries(schema.properties)) if (name in value) errors.push(...validate(sub, value[name], defs, `${path}.${name}`)); break;
      case 'additionalProperties': if (kinds.object(value)) for (const name of Object.keys(value)) if (!(name in (schema.properties ?? {}))) errors.push(`${path}: unknown property ${name}`); break;
      case 'items': if (Array.isArray(value)) value.forEach((item, index) => errors.push(...validate(schema.items, item, defs, `${path}[${index}]`))); break;
      case 'minimum': if (typeof value === 'number' && value < schema.minimum) errors.push(`${path}: below minimum`); break;
      case 'pattern': if (typeof value === 'string' && !new RegExp(schema.pattern).test(value)) errors.push(`${path}: pattern mismatch`); break;
      default: throw new Error(`Unsupported schema keyword ${key}`);
    }
  }
  return errors;
}
/** Errors for a value against one `$defs` shape of runtime/adapter.schema.json; empty means valid. */
export const validateShape = (shape, value) => validate(adapterSchema.$defs[shape], value, adapterSchema.$defs);

/** An AdapterDefinition must validate and its declared lifetimes must equal its supported kinds. */
export function definitionErrors(definition) {
  const errors = validateShape('AdapterDefinition', definition);
  if (errors.length) return errors;
  for (const fact of definition.facts ?? []) if (!fact.known && !fact.reason) errors.push(`fact ${fact.id}: unknown needs a reason`);
  const kindsDeclared = [...definition.supportedKinds].sort(), lifetimes = [...definition.capabilities.lifetimes].sort();
  if (new Set(kindsDeclared).size !== kindsDeclared.length) errors.push('supportedKinds has duplicates');
  if (!isDeepStrictEqual(kindsDeclared, lifetimes)) errors.push('capabilities.lifetimes must equal supportedKinds');
  for (const kind of Object.keys(definition.byUsage ?? {})) if (!definition.supportedKinds.includes(kind)) errors.push(`byUsage.${kind} is not a supported kind`);
  return errors;
}

// --- Loading -------------------------------------------------------------------------------------------

/**
 * The optional `durable` facet: provider I/O for durable routes. Core owns state; see durable-route.mjs.
 * `read(snapshot, slot, identity?)` and `delete(ctx, { snapshot, slot, rule, identity?, version })` take the
 * identity the rule was written under when core knows it (removal); without it they use the observed identity.
 * `slots(snapshot, { target })` lists `{ slot, origin, permitted, forwards, adoptOnly? }`. A slot with `adoptOnly: true` can
 * hold an adopted rule but is never allocated or restored.
 */
export const durableFacetMethods = ['observe', 'slots', 'read', 'foreign', 'occupied', 'put', 'delete', 'expand'];
function durableFacetErrors(facet) {
  if (facet === undefined) return [];
  if (facet === null || typeof facet !== 'object') return ['not an object'];
  const errors = durableFacetMethods.filter(name => typeof facet[name] !== 'function').map(name => `missing ${name}`);
  for (const name of ['renew', 'expiresAt']) if (facet[name] !== undefined && typeof facet[name] !== 'function') errors.push(`${name} is not a function`);
  if (facet.renew && !facet.expiresAt) errors.push('renew needs expiresAt');
  if (typeof facet.definition !== 'object' || facet.definition === null) errors.push('missing definition');
  return errors;
}

const methods = ['detect', 'properties', 'setupActions', 'setup', 'plan', 'create', 'observe', 'verify', 'remove', 'runtimeFacts'];

function declaredContext(context,definition,interfaceRecipe=null){
  if(!context)return context;
  if(!context.dispatchEffect)return typeof context.observeInterfaces==='function'?context:{...context,observeInterfaces:async()=>({interfaces:networkInterfaces()})};
  const dispatch=async request=>{
    if(!(definition.effectOperations??[]).some(item=>item.kind===request?.kind&&item.operation===request?.operation))throw effectError('unsupported','The adapter has not declared this fixture effect operation');
    return context.dispatchEffect(request);
  };
  // Under fixture effects the interface inventory is the host's declared recipe/probe observation of the adapter's own
  // interfaces recipe: source-shaped data the host supplies, never read from this computer.
  return {...context,dispatchEffect:dispatch,probe:recipe=>probeWithEffects(recipe,dispatch),observeInterfaces:fixtureInterfaceObserver(interfaceRecipe,dispatch)};
}
/** The host's declared interface inventory for one adapter, read through the adapter's own `interfaces` recipe and a declared recipe/probe effect. */
export function fixtureInterfaceObserver(recipe,dispatch){
  return async()=>{
    if(recipe?.kind!=='interfaces')throw effectError('unsupported','This adapter declares no interface observation');
    return parseInterfaceInventory(boundedObservation(await dispatch({kind:'recipe',operation:'probe',input:{recipe}}),recipe));
  };
}
function scopedAdapter(adapter){
  const wrapped={...adapter};
  for(const name of ['detect','setup','plan','create','observe','verify','remove','runtimeFacts','prepareProof','hostChoices','observeSetup','executeSetup','routeGuidance'])if(typeof adapter[name]==='function')wrapped[name]=(...args)=>adapter[name](bindConfiguration(declaredContext(args[0],adapter.definition,adapter.interfaceRecipe),adapter.id),...args.slice(1));
  if(adapter.durable){wrapped.durable={...adapter.durable};for(const name of ['observe','put','delete'])wrapped.durable[name]=(...args)=>adapter.durable[name](bindConfiguration(declaredContext(args[0],adapter.definition,adapter.interfaceRecipe),adapter.id),...args.slice(1));}
  return wrapped;
}

async function inside(root, path, label, id) {
  const providers = await realpath(resolve(root, 'providers')).catch(() => { throw loadError(id, 'providers directory is missing'); });
  const target = resolve(root, path);
  if (!target.startsWith(resolve(root, 'providers') + sep)) throw loadError(id, `${label} is outside providers/`);
  const real = await realpath(target).catch(() => { throw loadError(id, `${label} is missing`); });
  if (!real.startsWith(providers + sep)) throw loadError(id, `${label} resolves outside providers/`);
  return real;
}

/**
 * Loads every `providers` entry of a manifest. An entry that is invalid, incomplete or missing is a load
 * error, never a skipped adapter. `manifest` is a path, an object `{providers}` or omitted (the packaged
 * adapters/manifest.json). `root` is the directory holding `providers/`; it defaults to the manifest's
 * directory. Only files that resolve inside `<root>/providers/` are loadable.
 */
export async function loadAdapters({ manifest, root } = {}) {
  let data = manifest, base = root;
  if (data === undefined || typeof data === 'string') {
    const path = resolve(data ?? resolve(defaultAdaptersRoot, 'manifest.json'));
    data = JSON.parse(await readFile(path, 'utf8'));
    base ??= dirname(path);
  }
  base = resolve(base ?? defaultAdaptersRoot);
  if (!Array.isArray(data?.providers)) throw loadError('(manifest)', 'manifest has no providers list');
  const adapters = [], seen = new Set();
  for (const entry of data.providers) {
    const id = entry?.id ?? '(unnamed)';
    const entryErrors = validateShape('ProviderEntry', entry);
    if (entryErrors.length) throw loadError(id, `invalid registry entry: ${entryErrors.join('; ')}`);
    if (seen.has(id)) throw loadError(id, 'duplicate registry id');
    seen.add(id);
    const modulePath = await inside(base, entry.module, 'module', id);
    const definitionPath = await inside(base, entry.definition, 'definition', id);
    let file;
    try { file = JSON.parse(await readFile(definitionPath, 'utf8')); } catch { throw loadError(id, 'definition is not readable JSON'); }
    const errors = definitionErrors(file?.adapter);
    if (errors.length) throw loadError(id, `invalid definition: ${errors.join('; ')}`);
    let adapter;
    try { adapter = (await import(pathToFileURL(modulePath).href)).default; } catch (error) { throw loadError(id, `module failed to load: ${error?.code ?? 'error'}`); }
    const missing = methods.filter(name => typeof adapter?.[name] !== 'function');
    if (missing.length) throw loadError(id, `incomplete adapter, missing ${missing.join(', ')}`);
    const facetErrors = durableFacetErrors(adapter.durable);
    if (facetErrors.length) throw loadError(id, `invalid durable facet: ${facetErrors.join('; ')}`);
    if (adapter.id !== id || file.adapter.id !== id || !isDeepStrictEqual(adapter.definition, file.adapter)) throw loadError(id, 'registry entry, module and definition disagree');
    adapters.push(scopedAdapter(adapter));
  }
  return adapters;
}

// --- recipeAdapter ------------------------------------------------------------------------------------

// `load` loads the durable engine. `serve` optionally loads a transport module handed to the facet's `inspect`; a facet
// that has its own transport uses it when none is given.
const durableState = { load: () => import('./durable-route.mjs'), serve: null };
/** Test seam: replace the durable engine / facet transport loaders. Returns a restore function. */
export function setDurableDepsForTest(deps) {
  const saved = { ...durableState };
  Object.assign(durableState, deps);
  return () => Object.assign(durableState, saved);
}

const hasBinding = value => /\{[A-Za-z]\w*\}/.test(JSON.stringify(value ?? null));
const plainPointer = spec => typeof spec?.pointer === 'string' && spec.pointer !== '' && !spec.pointer.includes('*') && !hasBinding(spec) && spec.optional !== true && !['record', 'port-set'].includes(spec.type);
/**
 * The read-only steps a create recipe runs before it changes anything, as detect probes: each asks the parser
 * the exact question the session asks (the step's own assertion, and that every value it captures is present).
 * A step that asks nothing of the document, or whose assertion needs a value captured by an earlier step, is left out.
 */
function preflightProbes(recipes) {
  const asks = step => step.assert !== undefined || Object.values(step.captures ?? {}).some(plainPointer);
  return (recipes.create?.before ?? []).filter(step => step.recipe?.kind === 'spawn' && !hasBinding(step.assert) && asks(step)).map(({ recipe, assert, captures }) => ({
    ...recipe,
    parser: { ...recipe.parser, predicate: { op: 'all', items: [recipe.parser.predicate, ...(assert ? [assert] : []),
      ...Object.values(captures ?? {}).filter(plainPointer).map(({ pointer }) => ({ op: 'exists', pointer }))] } },
  }));
}

const toAction = (action, disclosure) => {
  const body = { id: action.id, kind: action.url ? 'open-url' : 'instructions', label: action.label, disclosure,
    ...(action.url ? { href: action.url } : { instructions: action.command ? `${action.reason} Run: ${action.command.join(' ')}` : action.reason }) };
  return { ...body, digest: sha(body) };
};

/** Reads `<definition file>`: `{ wraps?, adapter }`. `wraps` names the existing recipe definition it wraps. */
function readDefinition(location) {
  const url = typeof location === 'string' ? pathToFileURL(location) : location;
  const file = JSON.parse(readFileSync(url, 'utf8'));
  const errors = definitionErrors(file.adapter);
  if (errors.length) throw loadError(file.adapter?.id ?? '(unknown)', `invalid definition: ${errors.join('; ')}`);
  let wrapped = null;
  if (file.wraps) {
    if (!/^(\.\/|(\.\.\/)+)[A-Za-z0-9_.-]+\.definition\.json$/.test(file.wraps)) throw loadError(file.adapter.id, 'wraps must name an adapters/*.definition.json file');
    wrapped = JSON.parse(readFileSync(new URL(file.wraps, url), 'utf8')).definition;
    if (wrapped?.id !== file.adapter.id) throw loadError(file.adapter.id, 'wrapped recipe definition has a different id');
  }
  return { adapter: file.adapter, wrapped };
}

const requireReceipt = (plan, receipt, id) => {
  if (receipt?.schemaVersion !== 1 || receipt.adapterId !== id || receipt.resourceKey !== plan.resourceKey || !Number.isSafeInteger(receipt.generation) ||
      validateShape('Receipt', receipt).length) {
    throw effectError('provider_unavailable', 'The engine returned a receipt that does not match the plan');
  }
  return receipt;
};

/**
 * Implements every Adapter method through the existing admitted recipe engine. `extend({base, ...})`
 * returns method replacements for providers with a custom protocol (they still receive the frozen contexts).
 * Options: `definition` (URL or path of definition.json), `excludeActions` (definition action ids that
 * are consent steps, covered by the consent token, not setup), `externalOwned` (the route is owner-managed;
 * nothing is created or deleted) and `extend` (per-adapter methods layered on the base).
 */
export function recipeAdapter({ definition: location, excludeActions = [], externalOwned = false, extend = null }) {
  const { adapter: definition, wrapped } = readDefinition(location);
  const recipes = wrapped?.recipes ?? {};
  const platformOf = ctx => {
    if (typeof ctx?.platform !== 'string' || !ctx.platform) throw effectError('provider_unavailable', 'The context carries no platform');
    return ctx.platform;
  };
  const kinds = new Set(definition.supportedKinds);
  const durableRecipe = wrapped?.durableRecipe ?? null;
  const allActions = (wrapped?.actions ?? []).map(action => toAction(action, definition.disclosure));
  const shown = allActions.filter(action => !excludeActions.includes(action.id));
  const unsupported = what => effectError('unsupported', `${definition.id} does not support ${what}`);

  // Read-only state of the durable listener for a request: the facet reads, this shapes the adapter's observe result.
  async function listener(request,context) {
    try { return await adapter.durable.inspect(request, { transport: durableState.serve ? await durableState.serve() : undefined,context }); }
    catch (error) { throw mapProviderError(error); }
  }

  const adapter = {
    id: definition.id,
    definition,
    // Explicit recipe provenance survives scopedAdapter wrapping; unknown modules use the generic controller.
    sessionExecution: wrapped?.recipes?.create ? 'recipe' : 'generic',
    // The recipe through which this adapter observes the interface inventory, when it declares one.
    interfaceRecipe: wrapped?.recipes?.detect?.kind === 'interfaces' ? wrapped.recipes.detect : null,
    // The operational plan this adapter wraps. A session runs the plan of the adapter the owner approved, from whichever registry holds it.
    operationalDefinition: wrapped ?? null,

    async detect(ctx) {
      const os = platformOf(ctx);
      if (!supportedPlatform(os)) return { state: 'unsupported', facts: { platform: os, detected: false, setupNeeded: false } };
      if (externalOwned) return { state: 'ready', facts: { platform: os, detected: true, setupNeeded: false, externalOwned: true } };
      if (!recipes.detect) return { state: 'unknown', facts: { platform: os, detected: null, setupNeeded: false } };
      let result;
      try {
        result = await ctx.probe(recipes.detect);
        // A session runs these read-only steps first. Readiness is their verdict, so the catalog cannot say `ready` for a route the session then refuses.
        for (const probe of result?.ok === true ? preflightProbes(recipes) : []) if ((result = await ctx.probe(probe))?.ok !== true) break;
      } catch (e) { return { state: 'unknown', facts: { platform: os, detected: null, setupNeeded: false } }; }
      const detected = result?.ok === true;
      const setupNeeded = !detected && shown.length > 0;
      return { state: detected ? 'ready' : setupNeeded ? 'action-required' : 'unsupported', facts: { platform: os, detected, setupNeeded } };
    },

    properties: () => structuredClone(definition.capabilities),

    setupActions: facts => (facts?.setupNeeded ? structuredClone(shown) : []),

    async setup(ctx, actionId) {
      const action = allActions.find(item => item.id === actionId);
      if (!action) throw unsupported(`setup action ${String(actionId).slice(0, 64)}`);
      return { state: 'pending', nextAction: structuredClone(action) };
    },

    async plan(ctx, request) {
      const kind = request?.usage?.kind;
      if (!supportedPlatform(platformOf(ctx))) throw unsupported('this platform');
      if (!kinds.has(kind)) throw unsupported(`the ${kind} kind`);
      if (kind === 'durable') {
        if (!durableRecipe || !adapter.durable) throw unsupported('the durable kind');
        if (typeof ctx.home !== 'string' || !ctx.home) throw effectError('provider_unavailable', 'A durable plan needs the Gozar home');
        const engine = await durableState.load();
        if (typeof engine.durablePlanFacts !== 'function') throw unsupported('the durable engine');
        let facts, seen;
        try { facts = await engine.durablePlanFacts({ home: ctx.home, adapterId: definition.id, target: request.target, origin: request.origin, adapters: [adapter] }); seen = await listener(request,ctx); }
        catch (error) { throw mapProviderError(error); }
        return { digest: facts.planDigest, origin: facts.origin ?? request.origin, resourceKey: facts.observedResource, effects: [],
          readback: { kind: 'durable', origin: facts.origin ?? request.origin, target: request.target }, cleanup: { kind: 'durable' }, precondition: { revision: seen.revision } };
      }
      if (externalOwned) {
        if (!request.origin) throw effectError('setup_required', 'Provide the owner-managed HTTPS origin first');
      } else if (!recipes.create) throw unsupported('create');
      const effects = externalOwned ? [] : [{ adapterId: definition.id, operation: 'create', recipeRef: 'create/execute' }];
      const resourceKey = `${definition.id}:${sha({ target: request.target, origin: request.origin }).slice(0, 16)}`;
      const body = { adapterId: definition.id, kind, target: request.target, origin: request.origin, effects, resourceKey };
      return { digest: sha(body), origin: request.origin, resourceKey, effects, readback: { kind, origin: request.origin, target: request.target },
        cleanup: externalOwned ? { kind: 'external-owned' } : { operation: 'remove', recipeRef: 'remove/execute' }, precondition: null };
    },

    async create(ctx, plan) {
      if (plan?.readback?.kind === 'durable') throw unsupported('create for the durable kind: the durable engine owns it');
      if (!externalOwned && !recipes.create) throw unsupported('create');
      if (!kinds.has(plan?.readback?.kind)) throw unsupported('this kind');
      try { await ctx.assertGeneration(); return requireReceipt(plan, await ctx.executePlan(plan), definition.id); }
      catch (error) { throw mapProviderError(error); }
    },

    async observe(ctx, request) {
      if (request?.usage?.kind === 'durable' && durableRecipe && adapter.durable) return listener(request,ctx);
      const resourceKey = `${definition.id}:${sha({ target: request.target, origin: request.origin }).slice(0, 16)}`;
      return { present: false, resourceKey, identity: null, revision: null };
    },

    async verify(ctx, receipt) {
      const { origin, target } = receipt?.readback ?? {};
      if (typeof origin !== 'string' || typeof target !== 'string') return { status: 'unverified', checkedAt: null };
      return ctx.verifyChallenge(origin, target);
    },

    async remove(ctx, receipt, observed) {
      if (receipt?.readback?.kind === 'durable') throw unsupported('remove for the durable kind: the durable engine owns it');
      if (externalOwned) return { removed: true, debt: null };
      if (!recipes.remove) throw unsupported('remove');
      try { await ctx.assertGeneration(); return await ctx.compareAndRemove(receipt, observed); }
      catch (error) { throw mapProviderError(error); }
    },

    async runtimeFacts() {
      const idle = wrapped?.idleTimeoutMs ?? null;
      return { properties: structuredClone(definition.capabilities), ingress: null,
        limits: { recommendedPollIntervalMs: idle ? Math.max(1000, Math.floor(idle / 2)) : 60000, idleTimeoutMs: idle } };
    },
  };
  return extend ? Object.assign(adapter, extend({ base: { ...adapter }, definition, wrapped, allActions, platformOf, unsupported })) : adapter;
}

// --- ReadContext -----------------------------------------------------------------------------------------

// The core WASM module and its effect driver load on first use: detecting nothing never pays for them.
let coreStep = null;
async function runDetectRecipe(recipe,dispatchEffect) {
  const [{ loadCore }, { EffectDriver }] = await Promise.all([import('./core.mjs'), import('./driver.mjs')]);
  coreStep ??= await loadCore();
  const adapters = [{ id: 'probe', audience: 'local', ownership: 'external-owned', recipes: { detect: recipe } }];
  const requirements = { clientReach: 'this-device' };
  const journal = { value: { owned: {}, intents: {} }, async save() {}, async intent() { throw new Error('A probe cannot persist a mutation intent'); } };
  const driver = new EffectDriver({ adapters, journal, sessionId: 'probe', targetPort: 0 });
  let output = coreStep({ command: { type: 'detect', sessionId: 'probe' }, adapters, requirements, host: { ...driver.host, nowMs: driver.nowMs() } });
  // Read-only detection yields one spawn effect per round; a bounded loop keeps a misbehaving recipe finite.
  for (let round = 0; round < 8 && output.effects.length; round += 1) {
    const [effect] = output.effects;
    let completion;
    if(dispatchEffect){
      if(effect.operation!=='detect'||!['spawn','interfaces'].includes(effect.kind))throw effectError('unsupported','Fixture detection accepts only declared read-only process or interface observations');
      const observed=boundedObservation(await dispatchEffect({kind:'recipe',operation:'probe',input:{recipe}}),recipe);
      // An interface inventory is source-shaped output: the JSON document {interfaces:{name:[{address,internal,...}]}} on stdout.
      const result=effect.kind==='interfaces'?parseInterfaceInventory(observed):observed;
      completion={type:'effect-result',effectId:effect.id,sessionId:effect.sessionId,generation:effect.generation,ok:true,result};
    }else completion=await driver.execute(effect);
    output = coreStep({ state: output.state, command: { sessionId: 'probe', ...completion }, adapters, requirements, host: { ...driver.host, nowMs: driver.nowMs() } });
  }
  const observation=output.snapshot.observations?.probe;
  if(observation===undefined||observation==='unknown')throw effectError('provider_unavailable','The read-only probe did not establish its prerequisite');
  return observation === 'present';
}
function boundedObservation(observed,recipe){
  if(typeof observed?.stdout!=='string'||typeof observed?.stderr!=='string'||!Number.isInteger(observed?.exitCode)||Buffer.byteLength(observed.stdout)+Buffer.byteLength(observed.stderr)>Math.min(recipe.maxOutputBytes??65536,65536))throw effectError('provider_unavailable','The fixture probe returned an invalid bounded observation');
  return observed;
}
/** The interface inventory a host declares through recipe/probe: exit 0 and a JSON document {interfaces:{name:[{address,internal,...}]}}. */
export function parseInterfaceInventory(observed){
  let document;
  try{document=JSON.parse(observed.stdout);}catch{throw effectError('provider_unavailable','The fixture interface inventory is not JSON');}
  const inventory=document?.interfaces;
  if(observed.exitCode!==0||inventory===null||typeof inventory!=='object'||Array.isArray(inventory)||
    !Object.values(inventory).every(rows=>Array.isArray(rows)&&rows.every(row=>row&&typeof row==='object'&&typeof row.address==='string'&&typeof row.internal==='boolean')))
    throw effectError('provider_unavailable','The fixture interface inventory is invalid');
  return {interfaces:inventory};
}
export async function probeWithEffects(recipe,dispatchEffect){return {ok:await runDetectRecipe(recipe,dispatchEffect)};}

/**
 * The read-only ReadContext an engine hands to adapters. `probe` runs a read-only detect recipe through the same
 * core and effect driver the session path uses, so `ok` is the Rust parser's verdict, never a second parser.
 * `verifyChallenge` is the service-challenge verifier that durable publication also uses (a nonce proof served by
 * the app, read at the target and at the public origin); its `failed` outcome is `unverified` in the contract.
 * `configuration` is Gozar's private lookup for a named route: a named route Gozar does not know is
 * `route_not_found` before any provider is asked. The values a user gave one adapter during setup are added
 * per adapter by `bindConfiguration`, which every context goes through before an adapter sees it.
 * Every field can be replaced, which is how tests supply fakes.
 */
export function createReadContext({ home, platform = process.platform, now = Date.now, configuration, probe, verifyChallenge } = {}) {
  return {
    now, home, platform,
    configuration: configuration ?? (async ref => {
      if (ref === null || ref === undefined) return null;
      throw Object.assign(new Error('Unknown route name'), { code: 'route_not_found' });
    }),
    probe: probe ?? (async recipe => {
      return { ok: await runDetectRecipe(recipe) };
    }),
    verifyChallenge: verifyChallenge ?? (async (origin, target) => {
      const { verification } = await import('./service-state.mjs');
      const checked = await verification({ origin, target, verifyCmd: null });
      return { status: checked.status === 'verified' ? 'verified' : 'unverified', checkedAt: checked.checkedAt ?? null };
    }),
  };
}

/**
 * Runs the one `gozar-runs` action a user approved. No adapter in this build declares such an action, and Gozar
 * runs no app-supplied command and no installer, so an action id that reaches this runner is refused as `unsupported`.
 */
export async function executeApprovedAction(id) {
  throw effectError('unsupported', `No approved action is runnable in this build (${String(id).slice(0, 64)})`);
}

// --- AdmittedEffectContext -----------------------------------------------------------------------------

/**
 * Builds the AdmittedEffectContext an engine hands to adapters. It holds no ownership logic. It honours
 * `plan.precondition` (executePlan) and the observed revision (compareAndRemove): when the provider
 * revision moved, nothing is changed and the call rejects with `precondition_failed`.
 *   readRevision(resourceKey) -> string | null   the provider's current revision
 *   applyPlan(plan) -> { identity, readback }    the engine's admitted effect (the only writer)
 *   cleanupPlan(plan) -> void                    undo a partly applied effect
 *   removeResource(receipt, observed) -> Removal the engine's identity-checked removal
 *   journal { begin(plan), commit(receipt), abort(resourceKey) }  intent first, then a complete receipt
 * After a failure the state is clean (cleanup ran, intent aborted) or an intent stays as recorded debt;
 * a receipt is only ever written whole.
 */
export function createAdmittedContext({ read, adapterId, generation, assertGeneration = async () => {}, readRevision, applyPlan, cleanupPlan, removeResource, journal }) {
  if (!Number.isSafeInteger(generation)) throw effectError('provider_unavailable', 'An admitted context needs a generation');
  return {
    ...bindConfiguration(read, adapterId),
    generation,
    assertGeneration,
    async executePlan(plan) {
      if (plan.precondition) {
        const current = await readRevision(plan.resourceKey);
        if (current !== plan.precondition.revision) throw effectError('precondition_failed', 'The provider revision moved; nothing was changed');
      }
      await assertGeneration();
      await journal.begin(plan);
      try {
        const applied = await applyPlan(plan);
        // `origin` is the address the provider allocated at create; a plan that names one is the fallback (amendment 2).
        const receipt = { schemaVersion: 1, adapterId, resourceKey: plan.resourceKey, generation, identity: applied.identity,
          readback: { ...plan.readback, ...(applied.readback ?? {}) }, origin: applied.origin ?? plan.origin ?? null };
        await journal.commit(receipt);
        return receipt;
      } catch (error) {
        let clean = true;
        try { await cleanupPlan(plan); } catch { clean = false; }
        if (clean) await journal.abort(plan.resourceKey);
        throw mapProviderError(error);
      }
    },
    async compareAndRemove(receipt, observed) {
      const current = await readRevision(receipt.resourceKey);
      if (current !== (observed?.revision ?? null)) throw effectError('precondition_failed', 'The provider revision moved; nothing was removed');
      return removeResource(receipt, observed);
    },
  };
}

/**
 * The effect context an attached route's controller gives its adapter. An attached provider owns its own runtime
 * (an SDK listener the controller process holds), so it needs the generation and a fence, not the recipe engine:
 * `executePlan` and `compareAndRemove` are the recipe engine's, and an attached route has no recipe, so they
 * refuse with `unsupported` instead of pretending to run one.
 */
export function createAttachedEffectContext({ generation = 1, assertGeneration = async () => {}, adapter, readContext } = {}) {
  const lacks = what => effectError('unsupported', `An attached route has no recipe engine for ${what}`);
  const effects = { generation, assertGeneration, executePlan: async () => { throw lacks('executePlan'); }, compareAndRemove: async () => { throw lacks('compareAndRemove'); } };
  // With the adapter and its read context the effect context carries the adapter's own configuration, as every context does.
  return adapter && readContext ? bindConfiguration({ ...readContext, ...effects }, adapter.id) : effects;
}
